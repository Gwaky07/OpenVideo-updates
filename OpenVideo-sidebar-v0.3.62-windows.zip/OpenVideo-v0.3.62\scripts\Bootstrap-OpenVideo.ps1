﻿[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [switch]$NoBrowser,
    [switch]$Replace,
    [switch]$PrerequisitesOnly
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
# powershell.exe resets cmd.exe's chcp 65001. Re-apply UTF-8 before any host
# output, otherwise Chinese Write-Host is emitted as UTF-8 into a CP936 console.
& "$env:SystemRoot\System32\chcp.com" 65001 | Out-Null
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
# Keep the setting in the outer launcher too so every detached supervisor and
# Gateway process inherits the Windows system certificate store configuration.
$env:NODE_USE_SYSTEM_CA = '1'
$introStopwatch = [Diagnostics.Stopwatch]::StartNew()

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)

# REL-056：更新被中断（断电、杀毒软件锁定）时，用户的 runtime/data 可能还留在
# program.__backup 或 program.__failed-* 里，而新程序目录缺少它们。启动前只做“搬回缺失目录”，
# 不删除、不覆盖任何东西；源码仓库（有 .git）不处理。顺序与更新程序一致：先 __backup，
# 再按目录名里的时间戳从新到旧；__next* 是安装包，不含用户数据。node_modules 由启动流程重建，不搬。
# 搬不回来时直接停止启动，避免在缺少 runtime 的程序上继续运行、让用户以为数据丢了。
function Restore-OpenVideoPreservedState {
    param([Parameter(Mandatory = $true)][string]$ProgramRoot)
    if (Test-Path -LiteralPath (Join-Path $ProgramRoot '.git')) { return }
    $parent = Split-Path -Parent $ProgramRoot
    $leaf = Split-Path -Leaf $ProgramRoot
    if ([string]::IsNullOrWhiteSpace($parent) -or -not (Test-Path -LiteralPath $parent -PathType Container)) { return }
    $escapedLeaf = [WildcardPattern]::Escape($leaf)
    $leftovers = @(Get-ChildItem -LiteralPath $parent -Directory -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "$escapedLeaf.__backup*" -or $_.Name -like "$escapedLeaf.__failed*" } |
        Sort-Object -Property @(
            @{ Expression = { if ($_.Name -ceq "$leaf.__backup") { 0 } else { 1 } } },
            @{ Expression = { if ($_.Name -match '-(\d+)$') { [long]$Matches[1] } else { [long]0 } }; Descending = $true }
        ))
    # 更新程序在交换前写下这个标记；这里搬回的目录也要记进去，回滚时它们才会被当作用户数据保留。
    $pendingMarker = "$ProgramRoot.__swap-pending"
    foreach ($name in @('runtime', 'data', 'runtime-data')) {
        $target = Join-Path $ProgramRoot $name
        if (Test-Path -LiteralPath $target) { continue }
        foreach ($leftover in $leftovers) {
            $source = Join-Path $leftover.FullName $name
            if (-not (Test-Path -LiteralPath $source -PathType Container)) { continue }
            # 失败版本里只有记录在案的目录属于用户；其它是该版本自带的副本。
            $stateList = Join-Path $leftover.FullName 'openvideo-preserved-state.txt'
            if ((Test-Path -LiteralPath $stateList -PathType Leaf) -and
                -not (@(Get-Content -LiteralPath $stateList -Encoding UTF8 | ForEach-Object { $_.Trim() }) -ccontains $name)) { continue }
            try {
                Move-Item -LiteralPath $source -Destination $target -ErrorAction Stop
            } catch {
                throw "OPENVIDEO_RECOVER_PRESERVED_STATE_FAILED: $name is still in $($leftover.Name) and could not be moved back ($($_.Exception.GetType().Name)). Close programs that may be using it (antivirus, Explorer) and start OpenVideo again."
            }
            if (Test-Path -LiteralPath $pendingMarker -PathType Leaf) {
                Add-Content -LiteralPath $pendingMarker -Value "`n$name" -Encoding UTF8 -NoNewline
            }
            Write-Host "OPENVIDEO_RECOVERED_PRESERVED_STATE: $name from $($leftover.Name)"
            break
        }
    }
}
# REL-056：上一次更新在交换后、健康检查通过前中断（或回滚失败）时，program 里是没有被证明可用的版本，
# 上一个版本还在 program.__backup。日常启动不能直接运行它：交给更新程序的“只做恢复”模式回滚，
# 它会在回滚后启动恢复出来的版本。更新程序自己拉起的健康检查进程带 OPENVIDEO_UPDATE_HEALTH_CHILD，不在此列。
function Remove-OpenVideoStaleRecoveryCopy {
    param([Parameter(Mandatory = $true)][string]$ProgramRoot)
    # 更新程序在交换前放在 program 旁的恢复副本（“更新未完成-双击恢复”）。
    # 能从 program 正常启动且没有待恢复的备份时，它只会误导用户，删掉。
    if (Test-Path -LiteralPath "$ProgramRoot.__backup" -PathType Container) { return }
    $suffix = '.' + (-join ([char[]](0x66f4, 0x65b0, 0x672a, 0x5b8c, 0x6210))) + '-' + (-join ([char[]](0x53cc, 0x51fb, 0x6062, 0x590d))) + '.exe'
    $copy = $ProgramRoot.TrimEnd('\') + $suffix
    if (Test-Path -LiteralPath $copy -PathType Leaf) {
        Remove-Item -LiteralPath $copy -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-OpenVideoPendingRollback {
    param([Parameter(Mandatory = $true)][string]$ProgramRoot)
    if ($env:OPENVIDEO_UPDATE_HEALTH_CHILD -eq '1') { return $false }
    if (Test-Path -LiteralPath (Join-Path $ProgramRoot '.git')) { return $false }
    if (-not (Test-Path -LiteralPath "$ProgramRoot.__swap-pending" -PathType Leaf)) { return $false }
    if (-not (Test-Path -LiteralPath "$ProgramRoot.__backup" -PathType Container)) { return $false }
    $updater = Join-Path $ProgramRoot 'OpenVideo.exe'
    if (-not (Test-Path -LiteralPath $updater -PathType Leaf)) {
        throw 'OPENVIDEO_UPDATE_ROLLBACK_PENDING: the last update did not finish and the previous version is waiting in program.__backup, but the updater is missing. Reinstall OpenVideo from the full package.'
    }
    # 更新程序会替换 program 目录，因此从 program 外的副本运行。
    $stage = Join-Path (Split-Path -Parent $ProgramRoot) 'update-staging'
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    # 每次启动用自己的副本：重复双击时上一个恢复进程可能还占着它的文件。旧副本能删就删。
    Get-ChildItem -LiteralPath $stage -Filter 'OpenVideo-recover-*.exe' -File -ErrorAction SilentlyContinue |
        ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    $copy = Join-Path $stage "OpenVideo-recover-$PID.exe"
    Copy-Item -LiteralPath $updater -Destination $copy -Force
    Write-Host 'OPENVIDEO_UPDATE_ROLLBACK_PENDING: restoring the previous version after an unfinished update'
    # 只传给恢复进程，不留在本进程里（同时运行的恢复进程由更新程序的互斥锁排队）。
    $previousRoot = $env:OPENVIDEO_PROGRAM_ROOT
    try {
        $env:OPENVIDEO_PROGRAM_ROOT = $ProgramRoot
        $env:OPENVIDEO_UPDATE_RECOVER_ONLY = '1'
        Start-Process -FilePath $copy -WorkingDirectory $stage -WindowStyle Hidden | Out-Null
    } finally {
        $env:OPENVIDEO_UPDATE_RECOVER_ONLY = $null
        $env:OPENVIDEO_PROGRAM_ROOT = $previousRoot
    }
    return $true
}
try {
    if (Invoke-OpenVideoPendingRollback -ProgramRoot $resolvedRoot) { exit 0 }
    Restore-OpenVideoPreservedState -ProgramRoot $resolvedRoot
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($env:OPENVIDEO_LAUNCHER_INTERACTIVE -eq '1' -and -not [Console]::IsInputRedirected -and $env:OPENVIDEO_UPDATE_HEALTH_CHILD -ne '1') {
        Write-Host 'Press any key to close this window...' -ForegroundColor Cyan
        [void][Console]::ReadKey($true)
    }
    exit 12
}

# 端口占用等前置错误可能发生在 supervisor 创建之前，这两个值必须先初始化。
$isInteractiveConsole = (
    $env:OPENVIDEO_LAUNCHER_INTERACTIVE -eq '1' -or
    ([Environment]::UserInteractive -and -not [Console]::IsOutputRedirected)
)
# 更新程序的健康检查进程没有人能按键；失败时立即退出，让更新程序马上回滚。
$canReadConsoleKey = $isInteractiveConsole -and -not [Console]::IsInputRedirected -and $env:OPENVIDEO_UPDATE_HEALTH_CHILD -ne '1'
$autoReplaceOlderRelease = $false

function Write-OpenVideoIntroState {
    param(
        [string]$Path,
        [string]$LaunchId,
        [string]$Target,
        [double]$Progress = 0,
        [string]$Phase = 'gateway-starting',
        [bool]$Ready = $false
    )
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    $temporaryPath = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        $snapshot = [ordered]@{
            launchId = $LaunchId
            target = $Target
            ready = $Ready
            startup = [ordered]@{
                phase = $Phase
                progress = [Math]::Max(0, [Math]::Min(100, $Progress))
            }
        }
        $javascript = 'window.__OPENVIDEO_LAUNCH_STATE__ = ' +
            ($snapshot | ConvertTo-Json -Compress -Depth 4) + ';' + [Environment]::NewLine
        [IO.File]::WriteAllText($temporaryPath, $javascript, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    } catch {
        # The visible intro is best effort; launcher readiness remains authoritative.
    } finally {
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
    }
}

function Set-OpenVideoConsoleVisible {
    param([bool]$Visible)
    if (
        $env:OPENVIDEO_LAUNCHER_INTERACTIVE -ne '1' -and
        -not (
            [Environment]::UserInteractive -and
            -not [Console]::IsOutputRedirected
        )
    ) { return }
    try {
        if (-not ('OpenVideo.Native.ConsoleWindow' -as [type])) {
            Add-Type -Namespace OpenVideo.Native -Name ConsoleWindow -MemberDefinition @'
[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
'@
        }
        $hwnd = [OpenVideo.Native.ConsoleWindow]::GetConsoleWindow()
        if ($hwnd -eq [IntPtr]::Zero) { return }
        [void][OpenVideo.Native.ConsoleWindow]::ShowWindow($hwnd, $(if ($Visible) { 5 } else { 0 }))
    } catch {
        # A missing console handle must not block the workbench launch.
    }
}

function Start-OpenVideoIntro {
    param(
        [Parameter(Mandatory = $true)][string]$Url
    )
    # ShellExecute drops query parameters from file:// URLs on some Windows
    # browser associations. Route through `start` with one quoted argument so
    # embed, target, state and launch identity arrive intact.
    $quotedUrl = '"' + $Url.Replace('"', '\"') + '"'
    Start-Process -FilePath $env:ComSpec `
        -ArgumentList @('/d', '/c', 'start', '""', $quotedUrl) `
        -WindowStyle Hidden | Out-Null
}

function Update-ProcessPath {
    $pathParts = [System.Collections.Generic.List[string]]::new()
    foreach ($pathValue in @(
        $env:Path,
        [Environment]::GetEnvironmentVariable('Path', 'User'),
        [Environment]::GetEnvironmentVariable('Path', 'Machine')
    )) {
        if ([string]::IsNullOrWhiteSpace($pathValue)) { continue }
        foreach ($part in $pathValue -split ';') {
            if ([string]::IsNullOrWhiteSpace($part)) { continue }
            $trimmed = $part.Trim()
            if ($pathParts -notcontains $trimmed) {
                $pathParts.Add($trimmed)
            }
        }
    }
    $env:Path = $pathParts -join ';'
}

function Set-ExecutableDirectoryOnPath {
    param([string]$Executable)
    if ([string]::IsNullOrWhiteSpace($Executable)) { return }
    $directory = Split-Path -Parent ([IO.Path]::GetFullPath($Executable))
    if ([string]::IsNullOrWhiteSpace($directory)) { return }
    $pathParts = @($directory) + @(
        ($env:Path -split ';') |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and $_.Trim() -ne $directory }
    )
    $env:Path = ($pathParts | Select-Object -Unique) -join ';'
}

function Add-CommandDirectoryToPath {
    param([string]$Name)
    $command = Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $command -or [string]::IsNullOrWhiteSpace($command.Source)) { return }
    $directory = Split-Path -Parent $command.Source
    if ([string]::IsNullOrWhiteSpace($directory)) { return }
    $parts = @($directory) + @($env:Path -split ';' |
        Where-Object {
            -not [string]::IsNullOrWhiteSpace($_) -and
            -not $_.Equals($directory, [StringComparison]::OrdinalIgnoreCase)
        })
    $env:Path = $parts -join ';'
}

function Test-CommandAvailable {
    param([string]$Name)
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Install-WingetPackage {
    param(
        [string]$Id,
        [string]$DisplayName
    )
    Write-Host "Installing $DisplayName for the current Windows user..." -ForegroundColor Cyan
    & winget upgrade `
        --id $Id `
        --exact `
        --scope user `
        --silent `
        --accept-package-agreements `
        --accept-source-agreements `
        --disable-interactivity
    if ($LASTEXITCODE -ne 0) {
        & winget install `
            --id $Id `
            --exact `
            --scope user `
            --silent `
            --accept-package-agreements `
            --accept-source-agreements `
            --disable-interactivity
        if ($LASTEXITCODE -ne 0) {
            Write-Host "Current-user installation was unavailable for $DisplayName; retrying the package's default supported scope." -ForegroundColor Yellow
            & winget install `
                --id $Id `
                --exact `
                --silent `
                --accept-package-agreements `
                --accept-source-agreements `
                --disable-interactivity
            if ($LASTEXITCODE -ne 0) {
                throw "OPENVIDEO_PREREQUISITE_INSTALL_FAILED: $DisplayName ($Id)"
            }
        }
    }
    Update-ProcessPath
}

function Test-SupportedNodeVersion {
    # A shareable ZIP carries the exact Node runtime under runtime\node. Add it
    # before looking at PATH so a clean colleague machine does not trigger an
    # unnecessary package-manager install or pick an incompatible global Node.
    $bundledNode = Join-Path $resolvedRoot 'runtime\node\node.exe'
    if (Test-Path -LiteralPath $bundledNode -PathType Leaf) {
        Set-ExecutableDirectoryOnPath -Executable $bundledNode
        try {
            $bundledVersionText = (& $bundledNode --version 2>$null).Trim().TrimStart('v')
            $bundledVersion = [version]$bundledVersionText
            if ($bundledVersion -ge [version]'22.22.0') { return $true }
        } catch {
            # Fall through to the normal PATH/installation probe.
        }
    }
    $commandInfo = Get-Command node -ErrorAction SilentlyContinue
    if ($null -eq $commandInfo -or [string]::IsNullOrWhiteSpace($commandInfo.Source)) {
        $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
        $candidateRoots = [System.Collections.Generic.List[string]]::new()
        if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
            $candidateRoots.Add((Join-Path $env:LOCALAPPDATA 'Programs\nodejs'))
        }
        if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
            $candidateRoots.Add((Join-Path $env:ProgramFiles 'nodejs'))
        }
        if (-not [string]::IsNullOrWhiteSpace($programFilesX86)) {
            $candidateRoots.Add((Join-Path $programFilesX86 'nodejs'))
        }
        foreach ($candidateRoot in $candidateRoots) {
            if ([string]::IsNullOrWhiteSpace($candidateRoot)) { continue }
            $candidate = Join-Path $candidateRoot 'node.exe'
            if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                Set-ExecutableDirectoryOnPath -Executable $candidate
                $commandInfo = Get-Command node -ErrorAction SilentlyContinue
                break
            }
        }
    }
    if ($null -eq $commandInfo -or [string]::IsNullOrWhiteSpace($commandInfo.Source)) { return $false }
    Set-ExecutableDirectoryOnPath -Executable $commandInfo.Source
    try {
        $versionText = (& $commandInfo.Source --version 2>$null).Trim().TrimStart('v')
        $version = [version]$versionText
        return $version -ge [version]'22.22.0'
    } catch {
        return $false
    }
}

function Invoke-PythonProbe {
    param(
        [string]$Command,
        [string[]]$Arguments = @(),
        [string]$Code
    )
    try {
        $output = & $Command @Arguments -c $Code 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        $text = (@($output) -join [Environment]::NewLine).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }
        return $text
    } catch {
        return $null
    }
}

function Test-PythonVersionTextSupported {
    param([string]$VersionText)
    try {
        $version = [version]$VersionText
        return $version.Major -eq 3 -and $version.Minor -eq 12
    } catch {
        return $false
    }
}

function Resolve-PythonExecutableFromProbe {
    param(
        [string]$Command,
        [string[]]$Arguments = @()
    )
    $versionText = Invoke-PythonProbe -Command $Command -Arguments $Arguments -Code "import sys; print('.'.join(map(str, sys.version_info[:3])))"
    if (-not (Test-PythonVersionTextSupported -VersionText $versionText)) { return $null }

    $executable = Invoke-PythonProbe -Command $Command -Arguments $Arguments -Code "import sys; print(sys.executable)"
    if ([string]::IsNullOrWhiteSpace($executable)) {
        if ($Arguments.Count -eq 0) {
            $commandInfo = Get-Command $Command -ErrorAction SilentlyContinue
            if ($null -ne $commandInfo) {
                $executable = $commandInfo.Source
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($executable)) { return $null }
    return [IO.Path]::GetFullPath($executable)
}

function Resolve-SupportedPythonExecutable {
    $bundledPython = Join-Path $resolvedRoot 'runtime\python\python.exe'
    if (Test-Path -LiteralPath $bundledPython -PathType Leaf) {
        $resolved = Resolve-PythonExecutableFromProbe -Command $bundledPython
        if (-not [string]::IsNullOrWhiteSpace($resolved)) { return $resolved }
    }
    if (Test-CommandAvailable -Name 'python') {
        $python = Resolve-PythonExecutableFromProbe -Command 'python'
        if (-not [string]::IsNullOrWhiteSpace($python)) { return $python }
    }

    if (Test-CommandAvailable -Name 'py') {
        $python = Resolve-PythonExecutableFromProbe -Command 'py' -Arguments @('-3.12')
        if (-not [string]::IsNullOrWhiteSpace($python)) { return $python }
    }

    return $null
}

function Set-SupportedPythonEnvironment {
    param([string]$PythonExecutable)
    if ([string]::IsNullOrWhiteSpace($PythonExecutable)) { return }
    $pythonDirectory = Split-Path -Parent $PythonExecutable
    if (-not [string]::IsNullOrWhiteSpace($pythonDirectory)) {
        $env:Path = (@($pythonDirectory, $env:Path) |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join ';'
    }
    $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE = $PythonExecutable
}

function Test-SupportedPythonVersion {
    $python = Resolve-SupportedPythonExecutable
    if ([string]::IsNullOrWhiteSpace($python)) { return $false }
    Set-SupportedPythonEnvironment -PythonExecutable $python
    return $true
}

$launcherHelperPath = Join-Path $resolvedRoot 'scripts\OpenVideo-LauncherPort.ps1'
$launcherContextReady = $false
if (-not $PrerequisitesOnly -and (Test-Path -LiteralPath $launcherHelperPath -PathType Leaf)) {
    . $launcherHelperPath
    $primaryGatewayPort = 8787
    $launcherConfigPath = if (-not [string]::IsNullOrWhiteSpace($env:OPENVIDEO_CONFIG_PATH)) {
        [IO.Path]::GetFullPath($env:OPENVIDEO_CONFIG_PATH)
    } else {
        Join-Path $env:LOCALAPPDATA 'OpenVideo\config.json'
    }
    $launcherConfig = $null
    if (Test-Path -LiteralPath $launcherConfigPath -PathType Leaf) {
        try {
            $launcherConfig = Get-Content -Encoding UTF8 -LiteralPath $launcherConfigPath -Raw | ConvertFrom-Json
            if ($launcherConfig.PSObject.Properties.Name -contains 'gateway_port') {
                $configuredPort = 0
                if (
                    [int]::TryParse([string]$launcherConfig.gateway_port, [ref]$configuredPort) -and
                    $configuredPort -ge 1 -and
                    $configuredPort -le 65535
                ) {
                    $primaryGatewayPort = $configuredPort
                }
            }
        } catch {
            # Start-OpenVideo.ps1 owns config recovery and will report any unrecoverable error.
        }
    }
    $effectivePort = Resolve-OpenVideoGatewayPort `
        -Root $resolvedRoot `
        -PrimaryPort $primaryGatewayPort
    # Freeze the selected port for the hidden supervisor. Without this handoff,
    # Bootstrap and Start-OpenVideo could choose different fallback ports.
    $env:OPENVIDEO_LAUNCH_PORT = [string]$effectivePort
    $workbenchUrl = "http://127.0.0.1:$effectivePort/"
    $workbenchLivenessUrl = "${workbenchUrl}api/live"
    $launcherContextReady = $true
    $progressRuntimeRoot = $null
    if (
        $null -ne $launcherConfig -and
        $launcherConfig.PSObject.Properties.Name -contains 'runtime_data_root' -and
        -not [string]::IsNullOrWhiteSpace([string]$launcherConfig.runtime_data_root)
    ) {
        try {
            $progressRuntimeRoot = [IO.Path]::GetFullPath([string]$launcherConfig.runtime_data_root)
        } catch {
            $progressRuntimeRoot = $null
        }
    }
    if ([string]::IsNullOrWhiteSpace($progressRuntimeRoot)) {
        $progressRuntimeRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo\data'
    }
    $progressLogRoot = Join-Path $progressRuntimeRoot 'launcher-logs'
    $introLaunchId = [guid]::NewGuid().ToString('N')
    $introStatePath = $null
    try {
        New-Item -ItemType Directory -Path $progressLogRoot -Force | Out-Null
        $introStatePath = Join-Path $progressLogRoot "intro-state.$effectivePort.$introLaunchId.js"
        Write-OpenVideoIntroState `
            -Path $introStatePath `
            -LaunchId $introLaunchId `
            -Target $workbenchUrl
    } catch {
        $introStatePath = $null
    }
    # A static-only loopback host opens before any slow runtime probes. The
    # launch-bound state selects the workbench; the browser never sees file paths.
    $env:OPENVIDEO_INTRO_LAUNCH_ID = $introLaunchId
    $env:OPENVIDEO_INTRO_STATE_PATH = $introStatePath
    $env:OPENVIDEO_INTRO_TARGET = $workbenchUrl
    $env:OPENVIDEO_INTRO_OPENED = $null
    Write-Host 'OPENVIDEO_LAUNCHER_STARTING: checking the local workbench...' -ForegroundColor Cyan
    # Open only the canonical intro from the Gateway supervisor after its port is live.
    # Starting a temporary intro server here creates a second window and a random port.
    $initialBootId = $null
    $initialLive = $null
    try {
        $initialLive = Invoke-RestMethod -Uri $workbenchLivenessUrl -TimeoutSec 2
        if (
            $initialLive.live -eq $true -and
            $initialLive.PSObject.Properties.Name -contains 'bootId'
        ) {
            $initialBootId = [string]$initialLive.bootId
        }
    } catch {
        $initialBootId = $null
        $initialLive = $null
    }
    # Do not open a Gateway selected for explicit replacement: its ready=true
    # belongs to the old boot. Ordinary clicks reuse verified ownership below;
    # otherwise the supervisor
    # opens the root page when the selected startup shell begins listening.

    $canFastReuse = $false
    if (
        $null -ne $launcherConfig -and
        $null -ne $initialLive -and
        $initialLive.live -eq $true -and
        $initialLive.mode -eq 'production' -and
        $initialLive.PSObject.Properties.Name -contains 'releaseRevision'
    ) {
        $currentReleaseRevision = Read-OpenVideoCachedReleaseRevision `
            -Root $resolvedRoot `
            -Port $effectivePort
        # A cache miss (e.g. a dirty development tree) must not put a full source
        # hash on the reopen path. It only means update status is not current.
        $initialOwnership = Get-OpenVideoPortOwnership `
            -Port $effectivePort `
            -ExpectedRoot $resolvedRoot
        $recordPidMatches = (
            $null -ne $initialOwnership.Record -and
            $initialOwnership.Record.PSObject.Properties.Name -contains 'pid' -and
            [int]$initialOwnership.Record.pid -eq [int]$initialOwnership.Pid
        )
        $canFastReuse = (
            -not $Replace -and
            $initialOwnership.State -eq 'same_root' -and
            $recordPidMatches
        )
    }
    if ($canFastReuse) {
        if ([string]$initialLive.releaseRevision -ne $currentReleaseRevision) {
            Write-Host 'OPENVIDEO_UPDATE_PENDING: 已保留正在运行的工作台；代码更新将在明确重启后生效。' -ForegroundColor Yellow
        }
        $runtimeRoot = [IO.Path]::GetFullPath([string]$launcherConfig.runtime_data_root)
        $localApiTokenPath = Join-Path $runtimeRoot 'local-api-token.json'
        if (-not $NoBrowser -and $env:OPENVIDEO_INTRO_OPENED -ne '1') {
            Start-OpenVideoIntro -Url $workbenchUrl
            $env:OPENVIDEO_INTRO_OPENED = '1'
        }
        if ($env:OPENVIDEO_INTRO_OPENED -eq '1') {
            Set-OpenVideoConsoleVisible -Visible $false
        }
        Write-Host (
            "OPENVIDEO_FAST_REUSED: $workbenchUrl is already serving a verified running release " +
            "(revision=$($initialLive.releaseRevision) pid=$($initialOwnership.Pid))."
        ) -ForegroundColor Green
        if ($initialLive.PSObject.Properties.Name -notcontains 'ready' -or $initialLive.ready -ne $false) {
            Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
                -Target $workbenchUrl -Progress 100 -Phase 'workbench-ready' -Ready $true
            Remove-OpenVideoStaleRecoveryCopy -ProgramRoot $resolvedRoot
            Write-Host "OPENVIDEO_READY: workbench is reachable at $workbenchUrl" -ForegroundColor Green
            exit 0
        }
    }
}

# LAUNCHER-HOTFIX-001: diagnose (and, where safe, take over) ports that are still occupied
# when fast-reuse could not help. The previous behaviour silently spawned a supervisor that
# failed with EADDRINUSE, so the user saw a flash-and-close window instead of a real cause.
# The OpenVideo-LauncherPort helpers are dot-sourced only when the launcher actually starts
# the supervisor (PrerequisitesOnly skips them); mirror that guard so the diagnostic does not
# rely on functions that were never loaded.
$zombieCheckRoot = $resolvedRoot
$zombiePortOwnership = $null
$zombieCheckEnabled = (-not $PrerequisitesOnly) -and (Get-Command -Name Get-OpenVideoPortOwnership -ErrorAction SilentlyContinue)
if ($zombieCheckEnabled) {
    try {
        $zombiePortOwnership = Get-OpenVideoPortOwnership -Port $effectivePort -ExpectedRoot $zombieCheckRoot
    } catch {
        $zombiePortOwnership = $null
    }
}
$isPrimaryWorktree = $false
if ($zombieCheckEnabled -and (Get-Command -Name Test-OpenVideoPrimaryWorktree -ErrorAction SilentlyContinue)) {
    $isPrimaryWorktree = Test-OpenVideoPrimaryWorktree -Root $zombieCheckRoot
} elseif (-not $PrerequisitesOnly) {
    # Fallback: a worktree is primary when its root contains the .git directory.
    $isPrimaryWorktree = Test-Path -LiteralPath (Join-Path $zombieCheckRoot '.git') -PathType Container
}

function Write-OpenVideoPortOccupantDescription {
    param([int]$ProcessId)
    if ($null -eq $ProcessId -or $ProcessId -lt 1) { return 'unknown' }
    try {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId" -ErrorAction SilentlyContinue
        if ($null -eq $proc) { return "pid=$ProcessId (process gone)" }
        $image = [string]$proc.Name
        $cmd = [string]$proc.CommandLine
        if ($cmd.Length -gt 160) { $cmd = $cmd.Substring(0, 157) + '...' }
        return "pid=$ProcessId image=$image command=$cmd"
    } catch {
        return "pid=$ProcessId"
    }
}

function Format-OpenVideoPortSlug {
    param($Ownership)
    if ($null -eq $Ownership.RepositoryRoot) { return '(unknown worktree)' }
    $trimmed = ([string]$Ownership.RepositoryRoot).TrimEnd('\')
    return (Split-Path -Leaf $trimmed)
}

if ($zombieCheckEnabled -and $null -ne $zombiePortOwnership) {
    switch ($zombiePortOwnership.State) {
        'free' { } # No-op: the supervisor below will start cleanly.
        'same_root' { } # No-op: already handled by the fast-reuse path above; this branch is defensive.
        'other_root' {
            $slug = Format-OpenVideoPortSlug -Ownership $zombiePortOwnership
            $desc = Write-OpenVideoPortOccupantDescription -ProcessId $zombiePortOwnership.Pid
            if (
                $isPrimaryWorktree -and
                (Test-OpenVideoFullPackageReplacementCandidate `
                    -CurrentRoot $resolvedRoot `
                    -Ownership $zombiePortOwnership)
            ) {
                Write-Host (
                    "OPENVIDEO_RELEASE_TAKEOVER: 正在关闭当前用户运行的旧版 OpenVideo " +
                    "(root=$slug revision=$($zombiePortOwnership.ReleaseRevision) $desc)，" +
                    "新版本将继续使用 127.0.0.1:$effectivePort。"
                ) -ForegroundColor Yellow
                $autoReplaceOlderRelease = $true
            } else {
                Write-Host (
                    "OPENVIDEO_PORT_SELECTION_CHANGED: 127.0.0.1:$effectivePort was claimed before startup; " +
                    "retry the launcher to select another available port."
                ) -ForegroundColor Yellow
                Set-OpenVideoConsoleVisible -Visible $true
                Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
                    -Target $workbenchUrl -Phase 'port-selection-race'
                if ($canReadConsoleKey) {
                    Write-Host 'Press any key to close this window...' -ForegroundColor Cyan
                    [void][Console]::ReadKey($true)
                }
                exit 9
            }
        }
        'openvideo_unknown_root' {
            $desc = Write-OpenVideoPortOccupantDescription -ProcessId $zombiePortOwnership.Pid
            Write-Host (
                "OPENVIDEO_PORT_SELECTION_CHANGED: 127.0.0.1:$effectivePort is now served by an OpenVideo " +
                "instance whose current-user package root cannot be verified (revision=$($zombiePortOwnership.ReleaseRevision) $desc). " +
                "No process will be stopped; retry the launcher to select another available port."
            ) -ForegroundColor Yellow
            Set-OpenVideoConsoleVisible -Visible $true
            Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
                -Target $workbenchUrl -Phase 'port-selection-race'
            if ($canReadConsoleKey) {
                Write-Host 'Press any key to close this window...' -ForegroundColor Cyan
                [void][Console]::ReadKey($true)
            }
            exit 10
        }
        'unknown' {
            $desc = Write-OpenVideoPortOccupantDescription -ProcessId $zombiePortOwnership.Pid
            Write-Host (
                "OPENVIDEO_PORT_HELD_BY_OTHER_PROCESS: 127.0.0.1:$effectivePort is occupied by a non-OpenVideo " +
                "process ($desc). OpenVideo will NOT take it over automatically; close that process first " +
                "and retry the launcher."
            ) -ForegroundColor Yellow
            Set-OpenVideoConsoleVisible -Visible $true
            Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
                -Target $workbenchUrl -Phase 'port-held-by-other-process'
            if ($canReadConsoleKey) {
                Write-Host 'Press any key to close this window...' -ForegroundColor Cyan
                [void][Console]::ReadKey($true)
            }
            exit 11
        }
        default {
            Write-Host (
                "OPENVIDEO_PORT_OCCUPANCY_UNRECOGNIZED: 127.0.0.1:$effectivePort state=$($zombiePortOwnership.State) pid=$($zombiePortOwnership.Pid). " +
                "Falling through to the supervisor; it will report a clear error if the port cannot be bound."
            ) -ForegroundColor Yellow
        }
    }
}

Update-ProcessPath
$hasBundledProviders = (
    (Test-Path -LiteralPath (Join-Path $resolvedRoot 'runtime\providers\short-video-factory\openvideo-portable-provider.json') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $resolvedRoot 'runtime\providers\pyJianYingDraft\openvideo-portable-provider.json') -PathType Leaf)
)
if (-not (Test-CommandAvailable -Name 'winget')) {
    $missing = @(
        if (-not (Test-SupportedNodeVersion)) { 'Node.js >= 22.22.0' }
        if (-not (Test-SupportedPythonVersion)) { 'Python 3.12' }
        if (-not $hasBundledProviders -and -not (Test-CommandAvailable -Name 'git')) { 'Git' }
    )
    if ($missing.Count -gt 0) {
        throw "WINDOWS_PACKAGE_MANAGER_REQUIRED: Install Microsoft App Installer, then run this launcher again. Missing: $($missing -join ', ')."
    }
}

if (-not (Test-SupportedNodeVersion)) {
    Install-WingetPackage -Id 'OpenJS.NodeJS.LTS' -DisplayName 'Node.js LTS'
    if (-not (Test-SupportedNodeVersion)) {
        throw 'NODE_VERSION_UNSUPPORTED_AFTER_INSTALL: OpenVideo requires Node.js 22.22.0 or newer.'
    }
}
if (-not (Test-SupportedPythonVersion)) {
    Install-WingetPackage -Id 'Python.Python.3.12' -DisplayName 'Python 3.12'
    if (-not (Test-SupportedPythonVersion)) {
        throw 'PYTHON_VERSION_UNSUPPORTED_AFTER_INSTALL: OpenVideo requires Python 3.12.'
    }
}
if (-not $hasBundledProviders -and -not (Test-CommandAvailable -Name 'git')) {
    Install-WingetPackage -Id 'Git.Git' -DisplayName 'Git'
    if (-not (Test-CommandAvailable -Name 'git')) {
        throw 'GIT_UNAVAILABLE_AFTER_INSTALL'
    }
}
Add-CommandDirectoryToPath -Name 'node'
Add-CommandDirectoryToPath -Name 'corepack'
Add-CommandDirectoryToPath -Name 'git'
if (-not [string]::IsNullOrWhiteSpace($env:OPENVIDEO_JY002_PYTHON_EXECUTABLE)) {
    Set-SupportedPythonEnvironment -PythonExecutable $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE
}

if ($PrerequisitesOnly) {
    Write-Host 'OPENVIDEO_PREREQUISITES_READY: Node.js, Git and Python 3.12 are available.' -ForegroundColor Green
    exit 0
}
if (-not $launcherContextReady) {
    throw 'OPENVIDEO_LAUNCHER_HELPER_MISSING'
}

# PROD-HOTFIX-007: the supervisor is started hidden, so its progress output never reaches this
# window. Truncating the progress log here — before the supervisor exists — means the tail below can
# read from offset 0 without racing the writer, and stale lines from an earlier launch can never be
# replayed as if they belonged to this one. The supervisor and the gateway both append to this path.
$launchProgressLog = $null
if ($launcherContextReady) {
    try {
        New-Item -ItemType Directory -Path $progressLogRoot -Force | Out-Null
        $launchProgressLog = Join-Path $progressLogRoot "launch-progress.$effectivePort.log"
        # Truncate without a BOM. Set-Content -Encoding UTF8 emits one on Windows PowerShell 5.1,
        # and the byte-offset tail below would then read a lone continuation byte as a replacement
        # character and drift the offset, eating the head of the following line.
        [IO.File]::WriteAllText($launchProgressLog, '', [Text.UTF8Encoding]::new($false))
        $env:OPENVIDEO_LAUNCH_PROGRESS_LOG = $launchProgressLog
    } catch {
        # Without a writable progress log the launcher still works; it just waits quietly.
        $launchProgressLog = $null
        $env:OPENVIDEO_LAUNCH_PROGRESS_LOG = $null
    }
}

# 依赖由 supervisor 在独立 staging 中校验并发布，外层不提前写入私有目录。
# A package extracted outside the managed `%LOCALAPPDATA%\OpenVideo` install
# keeps its large runtime tree beside the package so an external drive remains
# the effective data drive from the first launch onward.
$isBundledRelease =
    (Test-Path -LiteralPath (Join-Path $resolvedRoot 'apps\gateway\dist\bundle.mjs') -PathType Leaf) -and
    -not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'apps\gateway\src\server.mjs') -PathType Leaf)
if ($isBundledRelease) {
    $packageParent = Split-Path -Parent $resolvedRoot
    $packageParentName = Split-Path -Leaf $packageParent
    $runtimeDataRoot = if ($packageParentName -ieq 'OpenVideo') {
        Join-Path $packageParent 'data'
    } else {
        Join-Path $packageParent 'OpenVideoData'
    }
} else {
    $runtimeDataRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo\data'
}

# REL-HOTFIX-010: when the colleague ZIP ships bundled build receipts under
# either `<installRoot>\release\*.json` (when Build-OpenVideoArtifacts was
# run in this checkout) or `<installRoot>\*.json` (when the developer box
# only has the per-port receipts under ``$env:LOCALAPPDATA\OpenVideo\data``
# — the ship script strips the per-port suffix and drops them in the ZIP
# root so they live next to the install root), copy them into the per-user
# private root. The supervisor (Start-OpenVideo.ps1) then sees them as
# OPENVIDEO_*_BUILD_CACHE_HIT and skips the first-launch pnpm build (which
# needs corepack + pnpm + node_modules and can take 5-30 minutes on a fresh
# Windows machine). The receipts are re-minted against the actual
# $runtimeRoot on the next supervisor start, so the cache survives across
# package upgrades.
$bundledReceiptRoots = @(
    (Join-Path $resolvedRoot 'release'),
    $resolvedRoot
)
$probePort = 8787
$configPath = Join-Path $runtimeDataRoot 'config.json'
if (Test-Path -LiteralPath $configPath -PathType Leaf) {
    try {
        $cfg = Get-Content -Encoding UTF8 -LiteralPath $configPath -Raw | ConvertFrom-Json
        if ($cfg.PSObject.Properties.Name -contains 'gateway_port' -and
            [int]$cfg.gateway_port -gt 0) {
            $probePort = [int]$cfg.gateway_port
        }
    } catch { }
}
$receiptMap = @(
    @{ Bundle = 'gateway-build-receipt.json';        Supervisor = "launcher-gateway-build-receipt.$probePort.json" }
    @{ Bundle = 'web-build-receipt.json';            Supervisor = "launcher-web-build-receipt.$probePort.json" }
    @{ Bundle = 'dependency-install-receipt.json';   Supervisor = "launcher-dependency-receipt.$probePort.json" }
    @{ Bundle = 'build-receipt.json';                Supervisor = "launcher-build-receipt.$probePort.json" }
)
foreach ($entry in $receiptMap) {
    $bundled = $null
    foreach ($rootTry in $bundledReceiptRoots) {
        $probe = Join-Path $rootTry $entry.Bundle
        if (Test-Path -LiteralPath $probe -PathType Leaf) {
            $bundled = $probe
            break
        }
    }
    if ($null -eq $bundled) { continue }
    $target = Join-Path $runtimeDataRoot $entry.Supervisor
    # Don't clobber a fresh per-port receipt we already minted in this
    # exact session on a developer box.
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        try {
            $existing = Get-Content -Encoding UTF8 -LiteralPath $target -Raw | ConvertFrom-Json
            if ($existing.PSObject.Properties.Name -notcontains 'bundle') {
                continue
            }
        } catch { }
    }
    try {
        $receipt = Get-Content -Encoding UTF8 -LiteralPath $bundled -Raw | ConvertFrom-Json
        if ($null -ne $receipt.PSObject.Properties['repository_root']) {
            $receipt.PSObject.Properties.Remove('repository_root')
        }
        if ($null -ne $receipt.PSObject.Properties['required_paths']) {
            $receipt.PSObject.Properties.Remove('required_paths')
        }
        if ($null -eq $receipt.PSObject.Properties['bundle']) {
            $receipt | Add-Member -NotePropertyName 'bundle' -NotePropertyValue $true -Force
        }
        $receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $target -Encoding UTF8
        Write-Host "OPENVIDEO_BUNDLED_RECEIPT_INSTALLED: $($entry.Supervisor)"
    } catch {
        Write-Host "OPENVIDEO_BUNDLED_RECEIPT_FAILED: $($entry.Bundle) $($_.Exception.Message)"
    }
}

$escapedStartScript = (Join-Path $resolvedRoot 'scripts\Start-OpenVideo.ps1').Replace("'", "''")
$escapedRoot = $resolvedRoot.Replace("'", "''")
$supervisorCommand = (
    "`$ProgressPreference = 'SilentlyContinue'; " +
    "`$InformationPreference = 'SilentlyContinue'; " +
    "& '$escapedStartScript' -RepositoryRoot '$escapedRoot'"
)
if (-not [string]::IsNullOrWhiteSpace($env:OPENVIDEO_CONFIG_PATH)) {
    $escapedConfigPath = $env:OPENVIDEO_CONFIG_PATH.Replace("'", "''")
    $supervisorCommand += " -ConfigPath '$escapedConfigPath'"
}
if ($NoBrowser) { $supervisorCommand += ' -NoBrowser' }
if ($Replace) { $supervisorCommand += ' -Replace' }
if ($autoReplaceOlderRelease) { $supervisorCommand += ' -AutoReplaceOlderRelease' }
# 每次启动使用独立退出结果，避免 Windows 已退出进程丢失 ExitCode 后空等。
$supervisorOutcomePath = if (-not [string]::IsNullOrWhiteSpace($launchProgressLog)) {
    Join-Path (Split-Path -Parent $launchProgressLog) ("supervisor-outcome.$introLaunchId.json")
} else { $null }
if ($null -ne $supervisorOutcomePath) {
    $escapedOutcome = $supervisorOutcomePath.Replace("'", "''")
    $wrapper = @'
$ErrorActionPreference = 'Stop'
$global:LASTEXITCODE = 0
$exitCode = 0
try {
    __CALL__
    $exitCode = $LASTEXITCODE
} catch {
    $exitCode = 1
    [Console]::Error.WriteLine($_.Exception.Message)
} finally {
    $result = @{ exitCode=$exitCode; launchId='__ID__'; pid=$PID } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText('__PATH__.tmp', $result, [Text.UTF8Encoding]::new($false))
    [IO.File]::Move('__PATH__.tmp', '__PATH__')
}
exit $exitCode
'@
    $supervisorCommand = $wrapper.Replace('__CALL__', $supervisorCommand).Replace('__ID__', $introLaunchId).Replace('__PATH__', $escapedOutcome)
}

$supervisorEncodedCommand = [Convert]::ToBase64String(
    [Text.Encoding]::Unicode.GetBytes($supervisorCommand)
)
$launcherArguments = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-EncodedCommand', $supervisorEncodedCommand
)

$launcherProcess = $null
$launcherExitCode = $null
$supervisorStdoutLog = $null
$supervisorStderrLog = $null

if (-not [string]::IsNullOrWhiteSpace($launchProgressLog)) {
    $supervisorLogRoot = Split-Path -Parent $launchProgressLog
    $supervisorStdoutLog = Join-Path $supervisorLogRoot "supervisor.$effectivePort.$introLaunchId.stdout.log"
    $supervisorStderrLog = Join-Path $supervisorLogRoot "supervisor.$effectivePort.$introLaunchId.stderr.log"
}

try {
    $startProcessArguments = @{
        FilePath = 'powershell.exe'
        ArgumentList = $launcherArguments
        WindowStyle = 'Hidden'
        PassThru = $true
    }
    if (
        -not [string]::IsNullOrWhiteSpace($supervisorStdoutLog) -and
        -not [string]::IsNullOrWhiteSpace($supervisorStderrLog)
    ) {
        $startProcessArguments.RedirectStandardOutput = $supervisorStdoutLog
        $startProcessArguments.RedirectStandardError = $supervisorStderrLog
    }
    $launcherProcess = Start-Process @startProcessArguments
    Write-Host (
        "OPENVIDEO_SUPERVISOR_STARTED: pid=$($launcherProcess.Id) url=$workbenchUrl"
    ) -ForegroundColor DarkGray
} catch {
    $launcherProcess = $null
    $launcherExitCode = 1
    Write-Host ('OPENVIDEO_LAUNCHER_CRASH: ' + $_.Exception.Message) -ForegroundColor Red
}

if ($null -eq $launcherProcess) {
    Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
        -Target $workbenchUrl -Phase 'startup-failed'
    Set-OpenVideoConsoleVisible -Visible $true
    if ($canReadConsoleKey) {
        Write-Host 'Press any key to close this window...' -ForegroundColor Cyan
        [void][Console]::ReadKey($true)
    }
    exit 1
}

# The supervisor owns the cold-start browser launch. It waits until the
# startup shell answers /api/live, so the browser's first visible page is the
# OpenVideo intro instead of ERR_CONNECTION_REFUSED. Fast reuse above may open
# immediately because that path has already verified a live local Gateway.

$bootTimeoutSeconds = 900
if (-not [string]::IsNullOrWhiteSpace($env:OPENVIDEO_BOOT_TIMEOUT)) {
    [int]::TryParse($env:OPENVIDEO_BOOT_TIMEOUT, [ref]$bootTimeoutSeconds) | Out-Null
}
if ($bootTimeoutSeconds -lt 60) { $bootTimeoutSeconds = 60 }
if ($bootTimeoutSeconds -gt 3600) { $bootTimeoutSeconds = 3600 }
$pollDeadline = (Get-Date).AddSeconds($bootTimeoutSeconds)
$ready = $false
$waitStopwatch = [Diagnostics.Stopwatch]::StartNew()
$progressOffset = 0
$counterVisible = $false

# Reads whatever the hidden supervisor and the gateway have appended since the last poll. Byte
# offsets are tracked so a partially written line is re-read whole on the next pass instead of being
# printed twice. Failures are swallowed: a launch must not die because its progress log is busy.
function Show-OpenVideoLaunchProgress {
    if ([string]::IsNullOrWhiteSpace($script:launchProgressLog)) { return }
    try {
        $stream = [IO.File]::Open(
            $script:launchProgressLog,
            [IO.FileMode]::Open,
            [IO.FileAccess]::Read,
            [IO.FileShare]::ReadWrite
        )
    } catch {
        return
    }
    try {
        if ($stream.Length -le $script:progressOffset) { return }
        $null = $stream.Seek($script:progressOffset, [IO.SeekOrigin]::Begin)
        $pending = [int]($stream.Length - $script:progressOffset)
        $buffer = [byte[]]::new($pending)
        $read = 0
        while ($read -lt $pending) {
            $chunk = $stream.Read($buffer, $read, $pending - $read)
            if ($chunk -le 0) { break }
            $read += $chunk
        }
        if ($read -le 0) { return }
        # Stop at the last newline so a half-written record is re-read on the next tick instead of
        # being displayed truncated.
        $lastBreak = -1
        for ($index = $read - 1; $index -ge 0; $index--) {
            if ($buffer[$index] -eq 0x0A) { $lastBreak = $index; break }
        }
        if ($lastBreak -lt 0) { return }
        $byteCount = $lastBreak + 1
        # Advance by bytes actually consumed rather than by re-encoding the decoded text. Those two
        # differ for a BOM or any malformed byte, and the difference would shift every later read.
        $script:progressOffset += $byteCount
        $complete = [Text.Encoding]::UTF8.GetString($buffer, 0, $byteCount)
        foreach ($rawLine in $complete -split "`r?`n") {
            # An older log may still start with a BOM written before this was fixed.
            $line = $rawLine.Trim([char]0xFEFF)
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            if ($script:counterVisible) {
                Write-Host ''
                $script:counterVisible = $false
            }
            Write-Host "  $line" -ForegroundColor DarkGray
            if (
                -not $NoBrowser -and
                $env:OPENVIDEO_INTRO_OPENED -ne '1' -and
                $line -match '^OPENVIDEO_FRONTEND_OPENED:'
            ) {
                $env:OPENVIDEO_INTRO_OPENED = '1'
                Set-OpenVideoConsoleVisible -Visible $false
            }
        }
    } catch {
    } finally {
        $stream.Dispose()
    }
}

function Show-OpenVideoSupervisorFailure {
    param(
        [int]$TailLines = 80,
        [switch]$PrecheckOnly
    )

    $diagnosticLines = [Collections.Generic.List[string]]::new()
    foreach ($path in @($script:supervisorStderrLog, $script:supervisorStdoutLog)) {
        if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) {
            continue
        }
        try {
            foreach ($rawLine in @(Get-Content -Encoding UTF8 -LiteralPath $path -Tail $TailLines -ErrorAction Stop)) {
                $line = [string]$rawLine
                if ($PrecheckOnly) {
                    if (
                        $line -match '^\s+-\s+(?:[A-Z][A-Z0-9_]+(?::|\s)|short-video-factory\b|pyJianYingDraft\b)' -or
                        $line -match 'OPENVIDEO_PRECHECK_FAILED:\s+\d+ issue\(s\)\.'
                    ) {
                        $diagnosticLines.Add($line.Trim())
                    }
                    continue
                }
                if ($line -match '^#< CLIXML|^<Objs') {
                    foreach ($match in [regex]::Matches($line, '<S S="Error">(.*?)</S>')) {
                        $decoded = [Net.WebUtility]::HtmlDecode($match.Groups[1].Value)
                        $decoded = $decoded -replace '_x000D__x000A_', "`n"
                        $decoded = $decoded -replace '_x000D_', "`r"
                        $decoded = $decoded -replace '_x000A_', "`n"
                        foreach ($errorLine in ($decoded -split "`r?`n")) {
                            if (-not [string]::IsNullOrWhiteSpace($errorLine)) {
                                $diagnosticLines.Add($errorLine.Trim())
                            }
                        }
                    }
                    continue
                }
                if (-not [string]::IsNullOrWhiteSpace($line)) {
                    $diagnosticLines.Add($line)
                }
            }
        } catch {
            # The exiting supervisor may still be releasing its redirected handles.
        }
    }
    if ($diagnosticLines.Count -eq 0) { return }

    Write-Host 'OPENVIDEO_LAUNCHER_FAILURE_DETAILS:' -ForegroundColor Red
    foreach ($line in $diagnosticLines) {
        Write-Host "  $line" -ForegroundColor Yellow
    }
}

function Get-OpenVideoSupervisorFailureSignal {
    $runtimeFailurePattern = 'RUNTIME_(?:FILE_CONFLICT|REPARSE_POINT_REJECTED|PATH_ESCAPES_ROOT|SOURCE_MISSING|RELATIVE_PATH_INVALID|COPY_HASH_MISMATCH|MANIFEST_INVALID|RECOVERY_INVALID|MANIFEST_PATH_INVALID|STAGED_HASH_MISMATCH|STAGED_EXTRA_FILE|STAGE_NOT_OWNED|INSTALL_BUSY)'
    $failurePattern = "(?:OPENVIDEO_(?:$runtimeFailurePattern|PRECHECK_FAILED|PORT_(?:OWNED_BY_OTHER_INSTANCE|OWNED_BY_OTHER_WORKTREE|IN_USE)|PORT_CONFLICT|GATEWAY_(?:START_FAILED|HEALTH_TIMEOUT)|WEB_BUILD_FAILED|GATEWAY_BUILD_FAILED|DEPENDENCY_INSTALL_FAILED)|MATERIAL_ANALYSIS_DEPENDENCY_INSTALL_FAILED)"
    foreach ($path in @($script:supervisorStderrLog, $script:supervisorStdoutLog)) {
        if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) {
            continue
        }
        try {
            $lines = @(Get-Content -Encoding UTF8 -LiteralPath $path -Tail 40 -ErrorAction Stop)
            foreach ($line in $lines) {
                if ($line -match $failurePattern) {
                    $marker = [regex]::Match(
                        [string]$line,
                        "$failurePattern[^<\r\n]*"
                    )
                    if ($marker.Success) {
                        return (($marker.Value -replace '_x000D__x000A_', ' ' -replace '_x000D_', ' ' -replace '_x000A_', ' ') -replace '\s+', ' ').Trim()
                    }
                    return 'Supervisor reported an OpenVideo startup failure; see private launcher logs.'
                }
            }
        } catch {
            # The supervisor may still be writing its redirected log.
        }
    }
    return $null
}

while ((Get-Date) -lt $pollDeadline) {
    Show-OpenVideoLaunchProgress
    $supervisorFailureSignal = Get-OpenVideoSupervisorFailureSignal
    if ($null -ne $supervisorFailureSignal) {
        $launcherExitCode = 1
        try { [void]$launcherProcess.WaitForExit(2000) } catch { }
        Set-OpenVideoConsoleVisible -Visible $true
        Write-Host ''
        Write-Host "OPENVIDEO_LAUNCHER_FAILURE: $supervisorFailureSignal" -ForegroundColor Red
        break
    }
    if ($isInteractiveConsole -and $env:OPENVIDEO_INTRO_OPENED -ne '1') {
        Write-Host (
            "`r  OPENVIDEO_WAITING: {0:F0}s elapsed (up to {1}s)   " -f
            $waitStopwatch.Elapsed.TotalSeconds, $bootTimeoutSeconds
        ) -NoNewline -ForegroundColor DarkGray
        $counterVisible = $true
    }
    $launcherHasExited = $false
    if ($null -ne $supervisorOutcomePath -and (Test-Path -LiteralPath $supervisorOutcomePath -PathType Leaf)) {
        try {
            $outcome = Get-Content -Encoding UTF8 -LiteralPath $supervisorOutcomePath -Raw | ConvertFrom-Json
            if ($outcome.launchId -eq $introLaunchId -and [int]$outcome.pid -eq $launcherProcess.Id) {
                $launcherExitCode = [int]$outcome.exitCode
                $launcherHasExited = $true
            }
        } catch { }
    }
    try {
        $launcherProcess.Refresh()
        if ($launcherProcess.HasExited) {
            $launcherHasExited = $true
            if ($null -ne $launcherProcess.ExitCode) { $launcherExitCode = $launcherProcess.ExitCode }
            elseif ($null -eq $launcherExitCode) { $launcherExitCode = 1 }
        }
    } catch {
        # The supervisor may exit while the readiness probe is still completing.
    }
    try {
        $liveProbe = Invoke-RestMethod -Uri $workbenchLivenessUrl -TimeoutSec 2
        $currentBootId = if (
            $liveProbe.live -eq $true -and
            $liveProbe.PSObject.Properties.Name -contains 'bootId'
        ) {
            [string]$liveProbe.bootId
        } else {
            ''
        }
        $replacementReady = (
            [string]::IsNullOrWhiteSpace($initialBootId) -or
            (
                -not [string]::IsNullOrWhiteSpace($currentBootId) -and
                $currentBootId -ne $initialBootId
            )
        )
        $reuseReady = $launcherHasExited -and $launcherExitCode -eq 0
        $runtimeReady = (
            $liveProbe.PSObject.Properties.Name -notcontains 'ready' -or
            $liveProbe.ready -eq $true
        )
        $currentRuntimeSelected = ($replacementReady -or $reuseReady)
        $reportedProgress = if (
            $currentRuntimeSelected -and
            $liveProbe.PSObject.Properties.Name -contains 'startup' -and
            $null -ne $liveProbe.startup -and
            $liveProbe.startup.PSObject.Properties.Name -contains 'progress'
        ) { [double]$liveProbe.startup.progress } else { 0 }
        $reportedPhase = if (
            $currentRuntimeSelected -and
            $liveProbe.PSObject.Properties.Name -contains 'startup' -and
            $null -ne $liveProbe.startup -and
            $liveProbe.startup.PSObject.Properties.Name -contains 'phase'
        ) { [string]$liveProbe.startup.phase } else { 'gateway-starting' }
        Write-OpenVideoIntroState `
            -Path $introStatePath `
            -LaunchId $introLaunchId `
            -Target $workbenchUrl `
            -Progress $reportedProgress `
            -Phase $reportedPhase `
            -Ready $false
        if (($replacementReady -or $reuseReady) -and $runtimeReady) {
            $probe = Invoke-WebRequest -Uri $workbenchUrl -UseBasicParsing -TimeoutSec 2
            if ($probe.StatusCode -eq 200) {
                Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
                    -Target $workbenchUrl -Progress 100 -Phase 'workbench-ready' -Ready $true
                $ready = $true
                break
            }
        }
    } catch {
        # gateway not yet responding; keep polling until budget runs out
    }
    if ($launcherHasExited) { break }
    Start-Sleep -Milliseconds 500
}

Show-OpenVideoLaunchProgress
if ($counterVisible) {
    Write-Host ''
    $counterVisible = $false
}

if ($ready) {
    Remove-OpenVideoStaleRecoveryCopy -ProgramRoot $resolvedRoot
    Write-Host ''
    Write-Host (
        "OPENVIDEO_READY: workbench is reachable at $workbenchUrl " +
        ("(took {0:F0}s)" -f $waitStopwatch.Elapsed.TotalSeconds)
    ) -ForegroundColor Green
    exit 0
}

if ($null -eq $launcherExitCode) {
    $launcherExitCode = 1
    Write-Host "OPENVIDEO_READY_TIMEOUT: gateway did not respond on $workbenchUrl within ${bootTimeoutSeconds}s. Check private launcher-logs." -ForegroundColor Yellow
} else {
    Write-Host "OPENVIDEO_LAUNCHER_EXIT_CODE=$launcherExitCode" -ForegroundColor Yellow
    Write-Host "The hidden supervisor exited before the workbench became reachable at $workbenchUrl." -ForegroundColor Yellow
    Show-OpenVideoSupervisorFailure -PrecheckOnly:($supervisorFailureSignal -match 'OPENVIDEO_PRECHECK_FAILED')
}
Write-OpenVideoIntroState -Path $introStatePath -LaunchId $introLaunchId `
    -Target $workbenchUrl -Phase 'startup-failed'
Set-OpenVideoConsoleVisible -Visible $true
if ($canReadConsoleKey) {
    Write-Host 'Press any key to close this window...' -ForegroundColor Cyan
    [void][Console]::ReadKey($true)
}
exit $launcherExitCode
