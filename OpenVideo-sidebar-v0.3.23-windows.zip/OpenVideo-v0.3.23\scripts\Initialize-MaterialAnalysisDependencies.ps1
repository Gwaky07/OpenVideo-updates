[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,
    [string]$HuggingFaceMirror = 'https://hf-mirror.com'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Get-Sha256 {
    param([string]$Path)
    $stream = [System.IO.File]::OpenRead([System.IO.Path]::GetFullPath($Path))
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([System.BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
        $stream.Dispose()
    }
}

function Assert-NoReparsePath {
    param([string]$Root, [string]$Path)
    $rootFull = [System.IO.Path]::GetFullPath($Root).TrimEnd('\')
    $pathFull = [System.IO.Path]::GetFullPath($Path)
    Assert-True (
        $pathFull.StartsWith($rootFull + '\', [System.StringComparison]::OrdinalIgnoreCase)
    ) 'Runtime dependency path escapes the private root.'
    $current = $rootFull
    $rootItem = Get-Item -LiteralPath $current -Force
    Assert-True (
        ($rootItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0
    ) 'Private runtime root must not be a reparse point.'
    foreach ($part in $pathFull.Substring($rootFull.Length + 1).Split('\')) {
        $current = Join-Path $current $part
        $item = Get-Item -LiteralPath $current -Force
        Assert-True (
            ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0
        ) 'Runtime dependency path contains a reparse point.'
    }
}

function Assert-NoReparseAncestors {
    param([string]$Path)
    $pathFull = [System.IO.Path]::GetFullPath($Path)
    $current = [System.IO.Path]::GetPathRoot($pathFull)
    foreach ($part in $pathFull.Substring([System.IO.Path]::GetPathRoot($pathFull).Length).Split('\')) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $current = Join-Path $current $part
        if (-not (Test-Path -LiteralPath $current)) { break }
        $item = Get-Item -LiteralPath $current -Force
        Assert-True (
            ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0
        ) 'Runtime data path contains a reparse point.'
    }
}

function Invoke-IsolatedVersion {
    param([string]$Executable)
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $Executable
    $startInfo.Arguments = '-version'
    $startInfo.WorkingDirectory = Split-Path $Executable -Parent
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.EnvironmentVariables.Clear()
    foreach ($key in @('SystemRoot', 'WINDIR', 'TEMP', 'TMP')) {
        $value = [Environment]::GetEnvironmentVariable($key)
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            $startInfo.EnvironmentVariables[$key] = $value
        }
    }
    $startInfo.EnvironmentVariables['PATH'] = $startInfo.WorkingDirectory
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    Assert-True ($process.Start()) 'Failed to start isolated dependency verification.'
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    Assert-True ($process.ExitCode -eq 0) 'Isolated dependency verification failed.'
    return ($stdout + "`n" + $stderr)
}

function Resolve-DownloadUrl {
    param([string]$Url)
    if ($Url.StartsWith('https://huggingface.co/', [System.StringComparison]::OrdinalIgnoreCase)) {
        return $Url.Replace('https://huggingface.co', $HuggingFaceMirror.TrimEnd('/'))
    }
    return $Url
}

function Download-Verified {
    param([string]$Url, [string]$Destination, [string]$ExpectedSha256, [long]$ExpectedSize)
    New-Item -ItemType Directory -Path (Split-Path $Destination -Parent) -Force | Out-Null
    $resolvedUrl = Resolve-DownloadUrl -Url $Url
    if ($ExpectedSize -ge 8MB) {
        $connectionCount = 8
        $chunkSize = [long][Math]::Ceiling($ExpectedSize / $connectionCount)
        $jobs = @()
        for ($index = 0; $index -lt $connectionCount; $index += 1) {
            $start = [long]$index * $chunkSize
            if ($start -ge $ExpectedSize) { break }
            $end = [Math]::Min($ExpectedSize - 1, $start + $chunkSize - 1)
            $partPath = $Destination + ('.part-{0:D2}' -f $index)
            $jobs += Start-Job -ScriptBlock {
                param($DownloadUrl, $OutputPath, $RangeStart, $RangeEnd)
                & curl.exe --silent --show-error --fail --location --retry 5 --retry-all-errors `
                    --connect-timeout 30 --max-time 900 --speed-limit 1024 --speed-time 120 --ssl-no-revoke `
                    --range "$RangeStart-$RangeEnd" --output $OutputPath $DownloadUrl
                if ($LASTEXITCODE -ne 0) { throw 'Segmented dependency download failed.' }
            } -ArgumentList $resolvedUrl, $partPath, $start, $end
        }
        $jobs | Wait-Job | Receive-Job
        if (@($jobs | Where-Object State -ne 'Completed').Count -gt 0) {
            $jobs | Remove-Job -Force
            throw 'Segmented dependency download failed.'
        }
        $output = [System.IO.File]::Create($Destination)
        try {
            for ($index = 0; $index -lt $jobs.Count; $index += 1) {
                $partPath = $Destination + ('.part-{0:D2}' -f $index)
                $expectedPartSize = [Math]::Min($chunkSize, $ExpectedSize - ([long]$index * $chunkSize))
                $part = Get-Item -LiteralPath $partPath
                Assert-True ($part.Length -eq $expectedPartSize) 'Dependency server returned an invalid byte range.'
                $input = [System.IO.File]::OpenRead($partPath)
                try { $input.CopyTo($output) } finally { $input.Dispose() }
            }
        } finally {
            $output.Dispose()
            $jobs | Remove-Job -Force
            Get-ChildItem -LiteralPath (Split-Path $Destination -Parent) -Filter ((Split-Path $Destination -Leaf) + '.part-*') |
                Remove-Item -Force
        }
    } else {
        & curl.exe --silent --show-error --fail --location --retry 5 --retry-all-errors `
            --connect-timeout 30 --max-time 900 --speed-limit 1024 --speed-time 120 --ssl-no-revoke `
            --output $Destination $resolvedUrl
        if ($LASTEXITCODE -ne 0) { throw "Dependency download failed." }
    }
    Assert-True ((Get-Item -LiteralPath $Destination).Length -eq $ExpectedSize) 'Dependency size mismatch.'
    Assert-True ((Get-Sha256 -Path $Destination) -eq $ExpectedSha256) 'Dependency hash mismatch.'
}

function Acquire-Verified {
    param(
        [string]$Url,
        [string]$Destination,
        [string]$ExpectedSha256,
        [long]$ExpectedSize,
        [string]$CacheKey
    )
    $cachePath = Join-Path $script:cacheRoot $CacheKey
    $cacheValid = (Test-Path -LiteralPath $cachePath -PathType Leaf) -and
        ((Get-Item -LiteralPath $cachePath).Length -eq $ExpectedSize) -and
        ((Get-Sha256 -Path $cachePath) -eq $ExpectedSha256)
    if (-not $cacheValid) {
        Remove-Item -LiteralPath $cachePath -Force -ErrorAction SilentlyContinue
        Download-Verified -Url $Url -Destination $cachePath -ExpectedSha256 $ExpectedSha256 -ExpectedSize $ExpectedSize
    }
    New-Item -ItemType Directory -Path (Split-Path $Destination -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $cachePath -Destination $Destination -Force
}

$repositoryRoot = [System.IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$runtimeRoot = [System.IO.Path]::GetFullPath($RuntimeDataRoot)
$privateRoot = Join-Path $runtimeRoot 'material-analysis'
$script:cacheRoot = Join-Path $privateRoot 'download-cache'
$manifestPath = Join-Path $repositoryRoot 'config/material-analysis-dependencies.json'
$manifest = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json
Assert-True ([System.IO.Path]::IsPathRooted($runtimeRoot)) 'RuntimeDataRoot must be absolute.'
Assert-True (-not $runtimeRoot.StartsWith($repositoryRoot, [System.StringComparison]::OrdinalIgnoreCase)) 'RuntimeDataRoot must be outside the repository.'
Assert-True ($manifest.schema_version -eq 1) 'Dependency manifest schema is invalid.'
Assert-NoReparseAncestors -Path $runtimeRoot
Assert-NoReparseAncestors -Path $privateRoot
New-Item -ItemType Directory -Path $privateRoot -Force | Out-Null
Assert-NoReparseAncestors -Path $privateRoot
if (Test-Path -LiteralPath $privateRoot -PathType Container) {
    Get-ChildItem -LiteralPath $privateRoot -Directory -Filter '.install-*' | Remove-Item -Recurse -Force
}
New-Item -ItemType Directory -Path $script:cacheRoot -Force | Out-Null

$installRoot = Join-Path $privateRoot ('.install-' + [guid]::NewGuid().ToString('N'))
$downloadRoot = Join-Path $installRoot 'downloads'
$stageRoot = Join-Path $installRoot 'stage'
New-Item -ItemType Directory -Path $downloadRoot, $stageRoot -Force | Out-Null
Assert-NoReparsePath -Root $privateRoot -Path $downloadRoot
Assert-NoReparsePath -Root $privateRoot -Path $stageRoot

# REL-HOTFIX-010: when the published full ZIP ships a prebuilt
# `<repositoryRoot>/runtime/material-analysis` tree, mirror the dependency and
# model sub-trees into the private root **before** any download attempt. The
# per-file SHA-256 check below will then reuse these files and skip the
# network download, which would otherwise try to fetch a disk-snapshot URL
# that is not reachable from a colleague's machine. The same payload is also
# mirrored into the stage directory so the post-move private root (after the
# final Move-Item below) still contains the bundled binaries and models.
# Seed additively. Identical existing files are reused, new files are added,
# and different bytes at a managed path fail closed without replacing data.
$bundledMaterialAnalysisRoot = Join-Path $repositoryRoot 'runtime\material-analysis'
if (Test-Path -LiteralPath $bundledMaterialAnalysisRoot -PathType Container) {
    & (Join-Path $PSScriptRoot 'Merge-OpenVideoRuntimeFiles.ps1') `
        -SourceRoot $bundledMaterialAnalysisRoot `
        -DestinationRoot $privateRoot `
        -RelativePaths @('dependencies', 'models') | Out-Null
    & (Join-Path $PSScriptRoot 'Merge-OpenVideoRuntimeFiles.ps1') `
        -SourceRoot $bundledMaterialAnalysisRoot `
        -DestinationRoot $stageRoot `
        -RelativePaths @('dependencies', 'models') | Out-Null
    $bundleFileCount = (Get-ChildItem -LiteralPath $privateRoot -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count
    # Bundle seed logged to private receipt; no console noise.
    # [Console]::WriteLine("OPENVIDEO_BUNDLED_MATERIAL_ANALYSIS_SEEDED: source=$bundledMaterialAnalysisRoot files=$bundleFileCount")
}

$receiptDependencies = @()
try {
    $runtimeDependencies = @($manifest.dependencies | Where-Object { $_.kind -ne 'npm-package' })
    foreach ($dependency in $runtimeDependencies) {
        $expectedRuntimeArtifacts = @()
        if ($dependency.kind -eq 'executable-bundle') {
            $expectedRuntimeArtifacts = @($dependency.runtime_artifacts)
        } elseif ($dependency.kind -eq 'npm-package') {
            # npm-packages are installed separately via package manager
            # Record minimal receipt entry and skip file-based processing
            $receiptEntry = [ordered]@{
                id = $dependency.id
                license = $dependency.license
                revision = $dependency.revision
                npm_package = $true
            }
            if ($dependency.PSObject.Properties.Name -contains 'artifact_sha256') {
                $receiptEntry['artifact_sha256'] = $dependency.artifact_sha256
            }
            $receiptDependencies += $receiptEntry
            continue
        } else {
            foreach ($runtimeFile in $dependency.runtime_files) {
                if ($runtimeFile -eq $dependency.runtime_files[0]) {
                    $expectedRuntimeArtifacts += [pscustomobject]@{
                        path = $runtimeFile
                        size = $dependency.artifact_size
                        sha256 = $dependency.artifact_sha256
                    }
                } else {
                    $supporting = @($dependency.supporting_artifacts) |
                        Where-Object { $runtimeFile.Replace('\', '/').EndsWith('/' + $_.path) } |
                        Select-Object -First 1
                    Assert-True ($null -ne $supporting) 'Supporting dependency file is not pinned.'
                    $expectedRuntimeArtifacts += [pscustomobject]@{
                        path = $runtimeFile
                        size = $supporting.size
                        sha256 = $supporting.sha256
                    }
                }
            }
        }
        $reuseInstalled = $true
        foreach ($runtimeArtifact in $expectedRuntimeArtifacts) {
            $installedFile = Join-Path $privateRoot $runtimeArtifact.path
            if (Test-Path -LiteralPath $installedFile -PathType Leaf) {
                Assert-NoReparsePath -Root $privateRoot -Path $installedFile
            }
            if (
                -not (Test-Path -LiteralPath $installedFile -PathType Leaf) -or
                (Get-Item -LiteralPath $installedFile).Length -ne $runtimeArtifact.size -or
                (Get-Sha256 -Path $installedFile) -ne $runtimeArtifact.sha256
            ) {
                $reuseInstalled = $false
                break
            }
        }
        if ($reuseInstalled) {
            foreach ($runtimeArtifact in $expectedRuntimeArtifacts) {
                $sourceFile = Join-Path $privateRoot $runtimeArtifact.path
                Assert-NoReparsePath -Root $privateRoot -Path $sourceFile
                $target = Join-Path $stageRoot $runtimeArtifact.path
                New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
                Copy-Item -LiteralPath $sourceFile -Destination $target -Force
            }
        } else {
        $archivePath = Join-Path $downloadRoot $dependency.artifact
        Acquire-Verified -Url $dependency.artifact_url -Destination $archivePath -ExpectedSha256 $dependency.artifact_sha256 `
            -ExpectedSize $dependency.artifact_size -CacheKey ($dependency.id + '-' + $dependency.artifact)

        if ($dependency.id -eq 'ffmpeg' -or $dependency.id -eq 'whisper-cpp') {
            $expanded = Join-Path $downloadRoot ($dependency.id + '-expanded')
            Expand-Archive -LiteralPath $archivePath -DestinationPath $expanded -Force
            Assert-True ($null -ne $dependency.runtime_artifacts) 'Executable bundle requires pinned runtime_artifacts.'
            Assert-True ($dependency.runtime_artifacts.Count -eq $dependency.runtime_files.Count) 'Every runtime file requires a pinned artifact.'
            foreach ($runtimeArtifact in $dependency.runtime_artifacts) {
                Assert-True ($dependency.runtime_files -contains $runtimeArtifact.path) 'Pinned runtime artifact is not declared in runtime_files.'
                $artifactName = Split-Path $runtimeArtifact.path -Leaf
                $sourceFile = Get-ChildItem -LiteralPath $expanded -Filter $artifactName -File -Recurse | Select-Object -First 1
                Assert-True ($null -ne $sourceFile) ('Dependency archive does not contain ' + $artifactName + '.')
                Assert-True ($sourceFile.Length -eq $runtimeArtifact.size) ('Extracted size mismatch for ' + $artifactName + '.')
                Assert-True ((Get-Sha256 -Path $sourceFile.FullName) -eq $runtimeArtifact.sha256) ('Extracted hash mismatch for ' + $artifactName + '.')
                $target = Join-Path $stageRoot $runtimeArtifact.path
                New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
                Copy-Item -LiteralPath $sourceFile.FullName -Destination $target -Force
            }
        } else {
            $primaryTarget = Join-Path $stageRoot $dependency.runtime_files[0]
            New-Item -ItemType Directory -Path (Split-Path $primaryTarget -Parent) -Force | Out-Null
            Copy-Item -LiteralPath $archivePath -Destination $primaryTarget -Force
            $supportingArtifacts = if ($dependency.PSObject.Properties.Name -contains 'supporting_artifacts') {
                @($dependency.supporting_artifacts)
            } else {
                @()
            }
            foreach ($supporting in $supportingArtifacts) {
                $runtimeFile = @($dependency.runtime_files) | Where-Object { $_.Replace('\', '/').EndsWith('/' + $supporting.path) } | Select-Object -First 1
                Assert-True (-not [string]::IsNullOrWhiteSpace($runtimeFile)) 'Supporting dependency file is not declared in runtime_files.'
                $supportingTarget = Join-Path $stageRoot $runtimeFile
                $supportingUrl = $dependency.source.TrimEnd('/') + '/resolve/' + $dependency.revision + '/' + $supporting.path
                Acquire-Verified -Url $supportingUrl -Destination $supportingTarget -ExpectedSha256 $supporting.sha256 `
                    -ExpectedSize $supporting.size -CacheKey ($dependency.id + '-' + $supporting.path.Replace('/', '-'))
            }
        }
        }

        $runtimeHashes = [ordered]@{}
        foreach ($runtimeFile in $dependency.runtime_files) {
            $stagedFile = Join-Path $stageRoot $runtimeFile
            Assert-True (Test-Path -LiteralPath $stagedFile -PathType Leaf) 'Required runtime dependency file is missing after extraction.'
            $expectedRuntimeArtifact = @($expectedRuntimeArtifacts) |
                Where-Object { $_.path -eq $runtimeFile } |
                Select-Object -First 1
            Assert-True ($null -ne $expectedRuntimeArtifact) 'Runtime dependency is not pinned by the repository manifest.'
            Assert-True ((Get-Item -LiteralPath $stagedFile).Length -eq $expectedRuntimeArtifact.size) 'Staged runtime dependency size mismatch.'
            Assert-True ((Get-Sha256 -Path $stagedFile) -eq $expectedRuntimeArtifact.sha256) 'Staged runtime dependency hash mismatch.'
            $runtimeHashes[$runtimeFile] = Get-Sha256 -Path $stagedFile
        }
        $receiptDependencies += [ordered]@{
            id = $dependency.id
            license = $dependency.license
            revision = $dependency.revision
            artifact_sha256 = $dependency.artifact_sha256
            runtime_files = $runtimeHashes
        }
    }

    foreach ($dependency in @($manifest.dependencies | Where-Object { $_.kind -eq 'executable-bundle' })) {
        $bundleDirectory = Split-Path (Join-Path $stageRoot $dependency.runtime_files[0]) -Parent
        $expectedNames = @($dependency.runtime_files | ForEach-Object { Split-Path $_ -Leaf } | Sort-Object)
        $actualNames = @(Get-ChildItem -LiteralPath $bundleDirectory -File | ForEach-Object { $_.Name } | Sort-Object)
        Assert-True (
            @(Compare-Object -ReferenceObject $expectedNames -DifferenceObject $actualNames).Count -eq 0
        ) 'Staged executable bundle contains an undeclared file.'
        foreach ($runtimeArtifact in $dependency.runtime_artifacts) {
            $stagedFile = Join-Path $stageRoot $runtimeArtifact.path
            Assert-NoReparsePath -Root $stageRoot -Path $stagedFile
            Assert-True ((Get-Item -LiteralPath $stagedFile).Length -eq $runtimeArtifact.size) 'Executable bundle size changed before execution.'
            Assert-True ((Get-Sha256 -Path $stagedFile) -eq $runtimeArtifact.sha256) 'Executable bundle hash changed before execution.'
        }
    }
    $ffmpegPath = Join-Path $stageRoot 'dependencies/ffmpeg/bin/ffmpeg.exe'
    $ffmpegVersion = (Invoke-IsolatedVersion -Executable $ffmpegPath).ToLowerInvariant()
    Assert-True ($ffmpegVersion.Contains('ffmpeg version')) 'FFmpeg version evidence is missing.'
    Assert-True (-not $ffmpegVersion.Contains('--enable-gpl')) 'GPL FFmpeg builds are not admitted.'
    Assert-True (-not $ffmpegVersion.Contains('--enable-nonfree')) 'Nonfree FFmpeg builds are not admitted.'

    New-Item -ItemType Directory -Path $privateRoot -Force | Out-Null
    & (Join-Path $PSScriptRoot 'Merge-OpenVideoRuntimeFiles.ps1') `
        -SourceRoot $stageRoot `
        -DestinationRoot $privateRoot `
        -RelativePaths @('dependencies', 'models')
    $receipt = [ordered]@{
        schema_version = 1
        installed_at = [DateTimeOffset]::UtcNow.ToString('O')
        manifest_sha256 = Get-Sha256 -Path $manifestPath
        dependencies = $receiptDependencies
    }
    $receiptTemporary = Join-Path $privateRoot ('dependency-installation.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $receiptPath = Join-Path $privateRoot 'dependency-installation.json'
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText(
        $receiptTemporary,
        (($receipt | ConvertTo-Json -Depth 8) + "`n"),
        $utf8NoBom
    )
    Move-Item -LiteralPath $receiptTemporary -Destination $receiptPath -Force
    Write-Output 'Material analysis dependencies are installed and verified.'
} finally {
    Remove-Item -LiteralPath $installRoot -Recurse -Force -ErrorAction SilentlyContinue
}
