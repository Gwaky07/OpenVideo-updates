[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SourceRoot,
    [Parameter(Mandatory = $true)][string]$DestinationRoot,
    [Parameter(Mandatory = $true)][string[]]$RelativePaths
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-Sha256 {
    param([string]$Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [IO.File]::OpenRead($Path)
        return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '')
    } finally {
        if ($null -ne $stream) { $stream.Dispose() }
        $algorithm.Dispose()
    }
}

function Get-TreeFiles {
    param([string]$Root, [string]$RelativePath)
    $relativeFull = [IO.Path]::GetFullPath((Join-Path $Root $RelativePath))
    $rootPrefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $relativeFull.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'OPENVIDEO_RUNTIME_PATH_ESCAPES_ROOT'
    }
    if (-not (Test-Path -LiteralPath $relativeFull -PathType Container)) {
        return @()
    }
    Assert-NoReparseAncestors -Path $relativeFull
    $items = @(Get-ChildItem -LiteralPath $relativeFull -Recurse -Force)
    foreach ($item in $items) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'OPENVIDEO_RUNTIME_REPARSE_POINT_REJECTED'
        }
    }
    return @($items | Where-Object { -not $_.PSIsContainer })
}

function Assert-NoReparseAncestors {
    param([string]$Path)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $current = [IO.Path]::GetPathRoot($fullPath)
    foreach ($part in $fullPath.Substring($current.Length).Split([char[]]@('\', '/'), [StringSplitOptions]::RemoveEmptyEntries)) {
        $current = Join-Path $current $part
        if (-not (Test-Path -LiteralPath $current)) { break }
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'OPENVIDEO_RUNTIME_REPARSE_POINT_REJECTED'
        }
    }
}

$source = [IO.Path]::GetFullPath($SourceRoot).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
$destination = [IO.Path]::GetFullPath($DestinationRoot).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
if (-not (Test-Path -LiteralPath $source -PathType Container)) { throw 'OPENVIDEO_RUNTIME_SOURCE_MISSING' }
Assert-NoReparseAncestors -Path $source
Assert-NoReparseAncestors -Path $destination
New-Item -ItemType Directory -Path $destination -Force | Out-Null
Assert-NoReparseAncestors -Path $destination

$plan = @()
$conflicts = @()
foreach ($relativePath in $RelativePaths) {
    if ([string]::IsNullOrWhiteSpace($relativePath) -or [IO.Path]::IsPathRooted($relativePath) -or $relativePath.Split([char[]]@('\', '/')) -contains '..') {
        throw 'OPENVIDEO_RUNTIME_RELATIVE_PATH_INVALID'
    }
    foreach ($sourceFile in (Get-TreeFiles -Root $source -RelativePath $relativePath)) {
        $relativeFile = $sourceFile.FullName.Substring($source.Length).TrimStart('\', '/')
        $destinationFile = Join-Path $destination $relativeFile
        $destinationFull = [IO.Path]::GetFullPath($destinationFile)
        $destinationPrefix = $destination + [IO.Path]::DirectorySeparatorChar
        if (-not $destinationFull.StartsWith($destinationPrefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'OPENVIDEO_RUNTIME_PATH_ESCAPES_ROOT'
        }
        Assert-NoReparseAncestors -Path (Split-Path -Parent $destinationFull)
        if (Test-Path -LiteralPath $destinationFull) {
            $existing = Get-Item -LiteralPath $destinationFull -Force
            if (($existing.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'OPENVIDEO_RUNTIME_REPARSE_POINT_REJECTED'
            }
            if ($existing.PSIsContainer) {
                $conflicts += $relativeFile
                continue
            }
            $sourceHash = Get-Sha256 -Path $sourceFile.FullName
            $destinationHash = Get-Sha256 -Path $destinationFull
            if ($sourceHash -ne $destinationHash) { $conflicts += $relativeFile }
        } else {
            $plan += [pscustomobject]@{ Source = $sourceFile.FullName; Destination = $destinationFull }
        }
    }
}

if ($conflicts.Count -gt 0) {
    throw ('OPENVIDEO_RUNTIME_FILE_CONFLICT: ' + ($conflicts -join ', '))
}

foreach ($entry in $plan) {
    $parent = Split-Path -Parent $entry.Destination
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    Assert-NoReparseAncestors -Path $parent
    $temporary = Join-Path $parent ('.openvideo-merge-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $input = [IO.File]::OpenRead($entry.Source)
        try { $input.CopyTo($stream) } finally { $input.Dispose() }
        $stream.Dispose()
        $stream = $null
        if ((Get-Sha256 -Path $temporary) -ne (Get-Sha256 -Path $entry.Source)) {
            throw 'OPENVIDEO_RUNTIME_COPY_HASH_MISMATCH'
        }
        Assert-NoReparseAncestors -Path $parent
        [IO.File]::Move($temporary, $entry.Destination)
    } catch {
        throw
    } finally {
        if ($null -ne $stream) { $stream.Dispose() }
        Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
    }
}

Write-Output "OPENVIDEO_RUNTIME_FILES_MERGED: added=$($plan.Count) conflicts=0 existing_preserved=true"
