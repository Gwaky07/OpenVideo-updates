# OpenVideo Windows 本地运行说明

同事先读根目录的 `先看这里.md`（英文系统读 `START-HERE.md`）。解压后双击包根目录带 Logo 的 `OpenVideo.lnk` 即可打开本机工作台；模型、剪映和素材仍要在自己电脑上准备。

## 交付形态

当前交付是可执行的 Windows 发行 ZIP，不是 MSI 安装器。包内只带前端构建产物和 Gateway bundle，不带 OpenVideo 的 Gateway/Web 源码或 Git 历史。获得包权限的用户可从 GitHub Releases 下载 ZIP、解压，然后双击根目录带 Logo 的 `OpenVideo.lnk`；它启动同目录的 `OpenVideo.cmd`。日常使用不需要 Docker Desktop、WSL、Compose，也不需要手动运行前端或 Gateway 开发命令。

OpenVideo 会在本机启动一个仅监听 `127.0.0.1` 的后台，并从同一 Origin 提供浏览器 UI 与 `/api/*`。项目、授权引用、任务、最终 MP4 和恢复状态保存在仓库外的当前 Windows 用户私有运行目录。

## 首次运行

1. 从当前私有 GitHub Release 下载 `OpenVideo-<version>-windows.zip`，校验同一 Release 中 metadata 记录的 SHA256，然后完整解压到普通本地目录（不要直接在压缩包内运行）。压缩包可以解压到任意电脑、任意目录。
2. 双击带 Logo 的 `OpenVideo.lnk`。这是压缩包内的入口，不会创建桌面快捷方式；它指向同目录 `OpenVideo.cmd`。启动入口会先复用当前用户已安装的 Node.js LTS、Git，以及 Windows Python Launcher 中登记的 `py -3.12`；只有确实缺少 Node.js LTS、Python 3.12 或 Git 时，才通过 Windows Package Manager 为当前用户安装官方包。如果系统缺少 `winget` 且仍有依赖未安装，先从 Microsoft Store 安装“应用安装程序”。
3. 也可以直接双击 `OpenVideo.cmd` 作为备用入口。根目录 `OpenVideo.exe` 是为兼容已安装的旧版更新器而保留的无 Logo 更新程序，不作为用户入口；日常启动请认准带 OpenVideo Logo 的 `OpenVideo.lnk`。
4. 当前 v0.3.23 包首次普通启动会从各自官方 GitHub 仓库获取并校验两个固定依赖，在本机生成所需运行产物：
   - `short-video-factory`：`9ad4c1df201538a3bdd05760e65153a8ce714bf8`（AGPL-3.0）
   - `pyJianYingDraft`：`c3318066d964744e2bfc66f75c71745fe8cea52a`（Apache-2.0）
   已存在但 URL、commit 或 clean tree 不匹配的目录会 fail closed，启动器不会覆盖。
4. 启动器会在 `%LOCALAPPDATA%\OpenVideo\config.json` 创建仓库外私有配置并直接打开工作台；不要求先填写 LLM，也不会在终端询问 API Key。
5. 进入工作台“系统设置 → 模型设置”，填写 HTTPS Base URL、API Key 和 text/vision/json 模型。API Key 只在本次同源请求中进入本机 Gateway，随后以 Windows CurrentUser DPAPI 密文保存；页面、日志和公共 DTO 均不会回显明文。
6. 保存成功后 Gateway 会以受控退出码自动重启。页面同时确认新进程 `bootId` 和配置 `revision` 后才报告生效；工作台页面不关闭。
7. 启动器会检查 Node/Corepack、Python、专用私有运行根、provider 固定 URL/commit/clean tree、Web 构建和本地分析依赖；缺失的 OpenVideo Node 依赖、Web 构建及固定素材分析依赖会自动安装、校验或生成。素材分析安装收据绑定仓库 manifest SHA256，未变化时跳过约 600 MB 模型与二进制的重复安装；Gateway 使用前仍逐文件校验固定大小和 SHA256，校验失败会 fail closed。任意已有非空目录必须带有效 OpenVideo owner marker，旧运行根仅在包含完整项目、授权、任务和素材分析结构时自动迁移；不会递归改写任意普通目录 ACL。
   Windows 启动器还会分别缓存 Node 依赖、Gateway 校验和 Web 构建；仅修改某一侧源码时只重做受影响阶段。所有收据均绑定规范化仓库根和精确内容指纹，损坏、跨 worktree、依赖变化或产物缺失时自动失效，不会用启动速度换取旧代码复用。
8. 未配置 LLM 时 Gateway 仍提供 UI、项目和非 AI 功能；素材 AI 分析、智能分镜等操作会明确引导到模型设置。生产 readiness 仍会如实报告缺失 capability，不会降级为 synthetic，也不阻塞本地页面启动。

Edit Mind 不属于最终发行依赖，不应放入配置，也不会由启动器下载或启动。

## 日常使用

双击 `OpenVideo.cmd`（总控台 / 主 worktree）。启动器完成检查和构建后会打开 `http://127.0.0.1:8787/`。保持启动窗口开启；关闭窗口会停止本地后台，但不会删除项目、任务、最终 MP4 或授权记录。

侧栏「更新」是整产品更新通道：一次点击覆盖页面 + Gateway 源码 + 启动器 + 配置 + 剪映 Writer，已在 v0.3.11 全链路验证（`docs/tasks/REL-019.md`）。开发推完私有 `origin/main` 后必须在这台电脑跑 `scripts\Ship-OpenVideoColleagueUpdate.ps1`；脚本会把当前 build 写到公开仓 `OpenVideo-updates/main/latest.json`，同事下次启动即可看到。同事不用登录 GitHub，也不要为此付费开 GitHub Actions。同事需先用 v0.3.11+ 的包（旧版本没有更新按钮）。

## 在另一台电脑继续开发

普通使用请下载 Release ZIP 并双击包根目录的 Logo 入口 `OpenVideo.lnk`（也可直接运行 `OpenVideo.cmd`）；继续开发请优先 `git clone` 私有仓库，这样会保留 Git 历史、远端、分支和后续 push/pull 能力。Release ZIP 可以阅读和修改源码，但不包含 `.git` 历史，不适合作为长期开发基线。

```powershell
git clone https://github.com/Gwaky07/OpenVideo.git
cd OpenVideo
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/Setup-OpenVideoDeveloper.ps1 -RepositoryRoot . -InstallBrowsers
```

根目录只保留日常使用的 `OpenVideo.cmd`。开发环境准备不再提供第二个根目录启动器；需要继续开发时，请直接运行上面的 `scripts/Setup-OpenVideoDeveloper.ps1` 命令。开发自举会：

- 复用普通启动器同一套 Node.js LTS、Git、Python 3.12 检查；缺失时按 Windows Package Manager 路线补齐。
- 使用 Corepack/pnpm 安装锁定的 workspace 依赖。
- 安装并校验固定的 `short-video-factory` 与 `pyJianYingDraft` 本地上游。
- 执行一次生产构建验证；传 `-SkipBuild` 可只准备依赖。
- 传 `-InstallBrowsers` 时额外安装 Playwright Chromium，用于 `pnpm test:e2e`。

开发常用命令：

```powershell
pnpm dev          # Web-only Vite development
pnpm start:local  # Gateway 同源托管的完整本地工作台
pnpm test
pnpm build
pnpm test:e2e
```

### 并行 task worktree

开发任务使用 `git worktree` 时，在该 worktree 目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\Start-OpenVideo.ps1
```

linked worktree **不会**改写全局 `config.json` 的 `gateway_port`；启动器按仓库路径稳定映射到 `8790–8889` 中的端口，并与主树 `8787` 并行共存、互不抢占。终端会打印：

- `OPENVIDEO_PORT_RESOLVED: port=...`
- `OPENVIDEO_STARTED: http://127.0.0.1:<port>/ (revision=... root=...)`

请打开日志中的地址，不要默认打开 `8787`。可用实例登记目录 `%LOCALAPPDATA%\OpenVideo\instances\` 对照当前端口与 worktree。

仅当主 worktree 需要强制接管已被其它 OpenVideo 实例占用的配置端口时，才使用：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\Start-OpenVideo.ps1 -Replace
```

日常双击 `OpenVideo.cmd` **不会**带 `-Replace`。

工作台中的正常顺序是：

1. 新建项目。
2. 由 Windows 可信选择器授权本地素材文件夹，并确认只读。
3. 扫描、分析和索引素材。
4. 填写主题、标题、商品卖点、脚本/文案和风格；或在 Storyboard / Editor 输入自然语言创作与微调要求。
5. 生成分镜，查看每句 Top 3 并按需替换镜头；可选进入 Editor 阶段由白名单 Agent 修订同一 RichTimeline revision。
6. 生成真实预览，确认后固化并下载最终 MP4。
7. 选择已批准模板（或无模板自动创作）并生成剪映草稿；在受支持剪映专业版中人工打开、播放并继续编辑。剪映 11.1 仅支持受治理的草稿生成与人工打开，不提供桌面自动化、自动导出或 `template_read`。

能力边界：

- 对外只宣传 Preview 与 Jianying 双侧均为 `implemented` 的能力，见 `docs/RELEASE-NOTES-AI-EDITOR-MVP.md`。
- Preview 标注 `degraded` 的能力（例如 dissolve、花字近似、部分 transform）不得视为预览与剪映视觉等价。
- 滤镜、贴纸、命名特效等 `unsupported` 能力不可用，也不会被 Agent 静默完成。
- 升级与回滚步骤见 `docs/WINDOWS-UPGRADE-ROLLBACK.md`。

## 只执行检查

排障时可在发行目录运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/Start-OpenVideo.ps1 -RepositoryRoot . -CheckOnly
```

该命令不会启动服务，也不会用 synthetic 结果替代真实 provider。

## 常见故障

- `OPENVIDEO_INITIAL_CONFIG_READY`：私有配置已创建；工作台仍会继续启动，LLM 请在前端“模型设置”中完成。
- `NODE_NOT_FOUND` / `NODE_VERSION_UNSUPPORTED`：安装受支持 Node.js。
- `WINDOWS_PACKAGE_MANAGER_REQUIRED`：系统缺少 `winget`，且启动器没有发现受支持的 Node.js、Git 或 Python 3.12。若已安装多个 Python 版本，启动器会优先使用 `py -3.12`；仍报错时请确认 `py -3.12 -c "import sys; print(sys.executable)"` 能输出 Python 3.12 路径，否则从 Microsoft Store 安装“应用安装程序”后重试。
- `OPENVIDEO_PREREQUISITE_INSTALL_FAILED`：Windows Package Manager 安装 Node/Python/Git 失败；检查网络、企业安装策略和磁盘后重试。
- `OPENVIDEO_UPSTREAM_INSTALL_FAILED`：固定第三方 provider 下载或本机构建失败；检查 GitHub/npm/PyPI 网络与磁盘，已有目录不会被覆盖。
- `OPENVIDEO_PRECHECK_FAILED`：逐项修复其上方列出的固定上游、运行目录或依赖问题；LLM 未配置本身不属于启动失败。
- `PRIVATE_CONFIG_PATH_UNSAFE`：配置必须位于当前用户 `%LOCALAPPDATA%` 下、仓库外且路径中不得包含 reparse point。
- `RUNTIME_ROOT_UNOWNED`：配置指向了非空且不属于 OpenVideo 的目录；改用 `%LOCALAPPDATA%\OpenVideo\data` 或新的专用空目录，不要绕过 ACL 保护。
- `pinned commit does not match` / `working tree is not clean`：对应正式 provider 已 fail closed；恢复固定干净检出，不要绕过检查。
- `MATERIAL_ANALYSIS_DEPENDENCY_INSTALL_FAILED`：检查网络和剩余磁盘后重试；下载产物会按固定 SHA256 校验。
- `OPENVIDEO_GATEWAY_START_FAILED`：查看私有运行根下 `launcher-logs`，日志不应包含 API Key、素材路径或用户文案。
- `OPENVIDEO_REPLACING_SAME_WORKTREE` / `OPENVIDEO_REPLACING_WITH_EXPLICIT_FLAG`：启动器正在结束**同一 worktree** 的旧监听，或主树在显式 `-Replace` 下接管端口；等待出现 `OPENVIDEO_STARTED` 即可。
- `OPENVIDEO_PORT_OWNED_BY_OTHER_WORKTREE` / `OPENVIDEO_PORT_OWNED_BY_OTHER_INSTANCE`：目标端口已被其它 worktree 或其它 OpenVideo 实例占用；打开对方 URL，或仅在主树使用 `-Replace` 明确接管。启动器不再因 `releaseRevision` 不同而静默抢端口。
- `OPENVIDEO_PORT_IN_USE`：端口被非 OpenVideo 进程占用。关闭该进程，或在私有 `config.json` 中把 `gateway_port` 改为其他本机端口（仅影响主 worktree）；task worktree 也可设置环境变量 `OPENVIDEO_GATEWAY_PORT` 临时覆盖。
- 剪映版本不受支持：草稿 capability 会 fail closed；不得通过修改配置绕过版本、签名、发布者或固定上游检查。

不要把 `%LOCALAPPDATA%\OpenVideo`、API Key、真实素材、草稿、最终视频、索引、模型或日志复制进 Git 仓库或发行源码包。
