import { existsSync } from 'node:fs'
import { copyFile, mkdtemp, readFile, rm, writeFile, mkdir, readdir } from 'node:fs/promises'
import { spawn, execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { promisify } from 'node:util'
import { dirname, join, resolve } from 'node:path'
import { tmpdir } from 'node:os'

const execFileAsync = promisify(execFile)
const [packagePathArg, installRootArg] = process.argv.slice(2)
if (!packagePathArg || !installRootArg) throw new Error('OPENVIDEO_FULL_UPDATE_ARGUMENTS_MISSING')

const packagePath = resolve(packagePathArg)
const installRoot = resolve(installRootArg).replace(/[\\/]+$/u, '')
const localAppData = process.env.LOCALAPPDATA ?? ''
const expectedRoot = resolve(
  process.env.OPENVIDEO_PROGRAM_ROOT ?? join(localAppData, 'OpenVideo', 'program'),
).replace(/[\\/]+$/u, '')
if (installRoot.toLowerCase() !== expectedRoot.toLowerCase()) {
  throw new Error('OPENVIDEO_FULL_UPDATE_INSTALL_ROOT_FORBIDDEN')
}
if (existsSync(join(installRoot, '.git'))) {
  throw new Error('OPENVIDEO_FULL_UPDATE_SOURCE_TREE_FORBIDDEN')
}
if (!existsSync(packagePath)) throw new Error('OPENVIDEO_FULL_UPDATE_PACKAGE_MISSING')

const readGatewayPort = async () => {
  const configPath = process.env.OPENVIDEO_CONFIG_PATH ?? join(localAppData, 'OpenVideo', 'config.json')
  try {
    const config = JSON.parse(await readFile(configPath, 'utf8'))
    const port = Number(config.gateway_port)
    if (Number.isInteger(port) && port >= 1 && port <= 65535) return { port, configPath }
  } catch {}
  const fallback = Number(process.env.OPENVIDEO_GATEWAY_PORT)
  return { port: Number.isInteger(fallback) && fallback > 0 ? fallback : 8787, configPath }
}

const processIdsForRoot = async () => {
  const escapedRoot = installRoot.replaceAll("'", "''")
  const command = `Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf('${escapedRoot}', [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -ExpandProperty ProcessId`
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-Command', command], {
      windowsHide: true,
      timeout: 5_000,
    })
    return stdout.split(/\r?\n/u)
      .map((line) => Number(line.trim()))
      .filter((pid) => Number.isInteger(pid) && pid > 0 && pid !== process.pid)
  } catch {
    return []
  }
}

const stopPreviousSupervisor = async ({ port }) => {
  const instancesPath = join(localAppData, 'OpenVideo', 'instances', `${port}.json`)
  let record
  try {
    record = JSON.parse(await readFile(instancesPath, 'utf8'))
  } catch {
    return
  }
  if (!record || String(record.repositoryRoot ?? '').replace(/[\\/]+$/u, '').toLowerCase() !== installRoot.toLowerCase()) return
  const gatewayPid = Number(record.pid)
  const supervisorPid = Number(record.supervisorPid)
  if (!Number.isInteger(gatewayPid) || gatewayPid < 1 || !Number.isInteger(supervisorPid) || supervisorPid < 1) return
  const escapedRoot = installRoot.replaceAll("'", "''")
  const script = [
    `$gateway = Get-CimInstance Win32_Process -Filter "ProcessId=${gatewayPid}"`,
    `$supervisor = Get-CimInstance Win32_Process -Filter "ProcessId=${supervisorPid}"`,
    `if ($null -eq $gateway -or $null -eq $supervisor -or [int]$gateway.ParentProcessId -ne ${supervisorPid}) { exit 0 }`,
    `$command = [string]$gateway.CommandLine`,
    `if ($command.IndexOf('${escapedRoot}', [StringComparison]::OrdinalIgnoreCase) -lt 0 -or [string]$supervisor.Name -notin @('powershell.exe','pwsh.exe')) { exit 0 }`,
    `Stop-Process -Id ${supervisorPid} -Force -ErrorAction SilentlyContinue`,
    `Start-Sleep -Milliseconds 500`,
    `Stop-Process -Id ${gatewayPid} -Force -ErrorAction SilentlyContinue`,
  ].join('; ')
  const encoded = Buffer.from(script, 'utf16le').toString('base64')
  try {
    await execFileAsync('powershell.exe', ['-NoProfile', '-EncodedCommand', encoded], {
      windowsHide: true,
      timeout: 20_000,
    })
  } catch {}
}

const stopRootNodeProcesses = async () => {
  for (const pid of await processIdsForRoot()) {
    try { process.kill(pid, 'SIGKILL') } catch {}
  }
  // A killed Gateway may still hold the old directory briefly. Wait until its
  // command line disappears before asking the launcher to move that directory.
  for (let attempt = 0; attempt < 40; attempt += 1) {
    if ((await processIdsForRoot()).length === 0) return
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 250))
  }
}

// Development/build callers set OPENVIDEO_UPDATE_WORK_ROOT to the repository
// `.openvideo-work` directory so a full ZIP never expands into C:\Temp. A
// packaged colleague install has no source checkout, so it falls back to its
// private OpenVideo data directory; the atomic swap itself remains there.
const updateWorkRoot = resolve(
  process.env.OPENVIDEO_UPDATE_WORK_ROOT ?? join(dirname(installRoot), 'update-work'),
)
await mkdir(updateWorkRoot, { recursive: true })
const stage = await mkdtemp(join(updateWorkRoot, 'openvideo-update-'))
try {
  const unpacked = join(stage, 'unpacked')
  await execFileAsync('powershell.exe', [
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-Command',
    `Expand-Archive -LiteralPath '${packagePath.replaceAll("'", "''")}' -DestinationPath '${unpacked.replaceAll("'", "''")}' -Force`,
  ], { windowsHide: true, timeout: 120_000 })
  const entries = await readdir(unpacked, { withFileTypes: true })
  const rootEntry = entries.find((entry) => entry.isDirectory())
  const payload = rootEntry ? join(unpacked, rootEntry.name) : unpacked
  const launcher = join(payload, 'OpenVideo.exe')
  if (!existsSync(launcher)) throw new Error('OPENVIDEO_FULL_UPDATE_RUNTIME_MISSING')

  const stableStage = join(localAppData || tmpdir(), 'OpenVideo', 'update-staging')
  await mkdir(stableStage, { recursive: true })
  const launcherCopy = join(stableStage, 'OpenVideo-update.exe')
  await copyFile(launcher, launcherCopy)
  const logRoot = join(localAppData || tmpdir(), 'OpenVideo', 'launcher-logs')
  await mkdir(logRoot, { recursive: true })
  await writeFile(join(logRoot, 'controlled-restart.marker'), '')

  // REL-017 / decision 2: preserve the colleague's running product-update.json.
  // The full ZIP carries a fresh config, but a user who has explicitly toggled
  // fullUpdateEnabled / publicManifestUrl / fallbackRemote on their install
  // must not have those choices silently overwritten by the published default.
  const existingConfigPath = join(installRoot, 'config', 'product-update.json')
  const incomingConfigPath = join(payload, 'config', 'product-update.json')
  let preservedConfig = false
  try {
    if (existsSync(existingConfigPath) && existsSync(incomingConfigPath)) {
      const [existingRaw, incomingRaw] = await Promise.all([
        readFile(existingConfigPath, 'utf8'),
        readFile(incomingConfigPath, 'utf8'),
      ])
      const existingHash = createHash('sha256').update(existingRaw).digest('hex')
      const incomingHash = createHash('sha256').update(incomingRaw).digest('hex')
      if (existingHash !== incomingHash) {
        await mkdir(join(payload, 'config'), { recursive: true })
        await copyFile(existingConfigPath, incomingConfigPath)
        preservedConfig = true
        const preservedNote = `[Apply-OpenVideoFullUpdate] preserved colleague product-update.json at ${new Date().toISOString()} sha256=${existingHash}`
        console.log('OPENVIDEO_UPDATE_PRODUCT_CONFIG_PRESERVED')
        try {
          await writeFile(
            join(logRoot, 'product-update-config-preserved.log'),
            `${preservedNote}\n`,
            { flag: 'a' }
          )
        } catch {}
      }
    }
  } catch (preserveError) {
    console.log(`OPENVIDEO_UPDATE_PRODUCT_CONFIG_PRESERVE_FAILED: ${preserveError.message}`)
  }

  const { port, configPath } = await readGatewayPort()
  await stopPreviousSupervisor({ port })
  await stopRootNodeProcesses()

  // Keep the updater process outside the tree it must atomically replace.
  // Windows refuses to move a directory while a process current directory is
  // inside that directory.
  spawn(launcherCopy, [], {
    cwd: resolve(installRoot, '..'),
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
    env: {
      ...process.env,
      OPENVIDEO_PROGRAM_ROOT: installRoot,
      OPENVIDEO_CONFIG_PATH: configPath,
      OPENVIDEO_GATEWAY_PORT: String(port),
    },
  }).unref()
  // The portable launcher owns backup cleanup after its own health check.
} finally {
  await rm(stage, { recursive: true, force: true })
  await rm(packagePath, { force: true })
}
