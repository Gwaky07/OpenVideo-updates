# OpenVideo startup intro

The controlled Three.js/Canvas intro in this directory was supplied by the OpenVideo product owner on 2026-09-03. `style.css` is preserved from that source package; `launch.html`, `launch.css`, and `launch-bridge.js` contain the OpenVideo product integration. `app.bundle.js` is rebuilt from the supplied source with product adjustments for the full-viewport workstation composition and bounded controlled-stage motion. The editable source remains in the owner's source package and is intentionally not duplicated here.

The desktop bootstrap opens a same-machine static intro as soon as Node can serve `openvideo-intro-server.mjs`. That helper is loopback-only and identity-bound; it never exposes private paths. The splash polls sanitized `/api/live` progress, waits for the authored opening plus real readiness, then hands off with `window.name = openvideo:intro-external` so StartupGate does not replay. The supervisor must not open a second browser when `OPENVIDEO_INTRO_OPENED=1`. The interactive console hides after the splash opens and returns only on failure. `-NoBrowser` suppresses the browser entirely.

Direct workbench navigation still uses StartupGate's intro iframe, which reads same-origin `/api/live` and signals completion to its parent. Stage progress follows real runtime state. A first launcher navigation keeps the authored opening for 12 seconds when the Gateway is already ready; a browser reload uses the 6-second reprise. A slow Gateway keeps the animation at its reported phase until the backend is ready. The legacy file integration remains only for compatibility.

Ordinary launcher clicks reuse a verified running instance, even when development source changes. They must not interrupt active work to apply an update. Applying changed backend code requires an explicit restart (`-Replace`) after active work completes. A full source hash must not block reopening the workbench.

Three.js remains covered by `vendor/THREE-LICENSE.txt`.

Startup HTML and fixed-name public scripts must use `Cache-Control: no-cache`.
Only bundled assets under `/assets/` may be immutable. The v16 resource URLs
invalidate older v9 bridge responses that were mistakenly cached for one year;
those responses navigated to `/` without the external-intro handoff marker and
caused StartupGate to play a second intro. Do not revert those URLs to v9.
