(() => {
  const POLL_INTERVAL_MS = 250;
  const FINAL_READY_HOLD_MS = 750;
  const query = new URLSearchParams(window.location.search);
  // Honor the real startup phase: when the Gateway reports ready we hand off
  // without padding the timeline. The very first desktop launch is still
  // authored for 12s, but a browser refresh (mode=refresh) lets the splash
  // follow the live progress so a warm Gateway does not stall the user.
  const introMode = query.get('mode') === 'refresh' ? 'refresh' : 'launch';
  const MINIMUM_PRODUCT_INTRO_MS = introMode === 'refresh' ? 0 : 12_000;
  const targetValue = query.get('target');
  const launchId = query.get('launch');
  const stateValue = query.get('state');
  const previewMode = query.get('preview') === '1';
  const bootstrapMode = query.get('bootstrap') === '1';
  const detail = document.getElementById('startup-detail');
  const phaseLabel = document.getElementById('startup-phase-label');
  let target;
  let stateUrl;
  let pollTimer;
  let previewTimer;
  let completionTimer;
  let navigationStarted = false;
  const introStartedAt = Date.now();
  let lastVisualProgress = 0;
  let readyHandoff;
  let elapsedTimecodeFrame;

  function formatElapsedTimecode() {
    const elapsedMs = Math.max(0, Date.now() - introStartedAt);
    const totalSeconds = Math.floor(elapsedMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const frames = Math.floor((elapsedMs % 1000) / 40);
    return [hours, minutes, seconds, frames].map((value) => String(value).padStart(2, '0')).join(':');
  }

  function updateElapsedTimecode() {
    if (!previewMode) {
      const timecode = document.getElementById('timecode');
      if (timecode) timecode.textContent = formatElapsedTimecode();
    }
    elapsedTimecodeFrame = window.requestAnimationFrame(updateElapsedTimecode);
  }

  const phaseLabels = Object.freeze({
    'gateway-starting': '正在启动本机服务',
    repositories: '正在恢复本地数据',
    'local-api-token': '正在建立安全会话',
    'static-web': '正在准备界面资源',
    'startup-listen': '界面已连接，后台继续启动',
    'creative-knowledge': '正在加载创作知识',
    'material-analysis': '正在连接素材分析能力',
    'material-review-overlay': '正在恢复素材复核状态',
    'tts-studio': '正在连接配音能力',
    'narration-provider': '正在准备旁白能力',
    'preview-provider': '正在准备视频预览',
    'template-capabilities': '正在加载模板与包装能力',
    'jianying-capability': '正在检查剪映环境',
    'workbench-runtime': '正在组装创作工作台',
    'startup-recovery': '正在恢复未完成任务',
    factories: '正在完成运行时检查',
    'native-evidence-preflight': '正在核验剪映写入环境',
    'runtime-root-acl-finalize': '正在确认本机数据安全',
    'workbench-ready': '工作台已就绪',
  });

  function parseTarget(value) {
    try {
      const parsed = new URL(value || '');
      if (parsed.protocol !== 'http:' || parsed.hostname !== '127.0.0.1') return null;
      if (parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/') return null;
      return parsed;
    } catch {
      return null;
    }
  }

  function resolveTarget(value) {
    if (window.location.protocol === 'http:' && window.location.origin) {
      return parseTarget(`${window.location.origin}/`);
    }
    const parsed = parseTarget(value);
    if (parsed) return parsed;
    // Windows browser associations can drop the query string from a file://
    // launch. Keep the recovery target strictly loopback so the intro can
    // still hand off to the local workbench without accepting external URLs.
    return window.location.protocol === 'file:'
      ? parseTarget('http://127.0.0.1:8787/')
      : null;
  }

  function parseStateUrl(value) {
    if (!value || !launchId || !target) return null;
    try {
      const parsed = new URL(value);
      const expectedPrefix = `intro-state.${target.port}.`;
      const normalizedPath = decodeURIComponent(parsed.pathname).replaceAll('\\', '/');
      const fileName = normalizedPath.slice(normalizedPath.lastIndexOf('/') + 1);
      if (
        parsed.protocol !== 'file:' ||
        parsed.username || parsed.password || parsed.search || parsed.hash ||
        !fileName.startsWith(expectedPrefix) ||
        !fileName.endsWith('.js') ||
        (launchId && fileName !== `${expectedPrefix}${launchId}.js`)
      ) return null;
      return parsed;
    } catch {
      return null;
    }
  }

  function setDetail(message, error = false) {
    if (detail) detail.textContent = message;
    if (phaseLabel) phaseLabel.textContent = message;
    document.body.classList.toggle('startup-error', error);
    document.body.classList.toggle('startup-ready', message === '工作台已就绪');
  }

  function schedulePoll() {
    pollTimer = window.setTimeout(poll, POLL_INTERVAL_MS);
  }

  function navigateToWorkbench() {
    if (navigationStarted) return;
    navigationStarted = true;
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'openvideo:intro-complete' }, window.location.origin === 'null' ? '*' : window.location.origin);
      return;
    }
    // The desktop launcher owns this first intro. window.name survives the
    // loopback-port navigation without exposing a handoff marker in the URL.
    window.name = 'openvideo:intro-external';
    if (bootstrapMode) window.navigator?.sendBeacon('/complete', '');
    window.location.replace(target.href);
  }

  function readLocalState() {
    return new Promise((resolve, reject) => {
      const probe = document.createElement('script');
      delete window.__OPENVIDEO_LAUNCH_STATE__;
      probe.src = `${stateUrl.href}?at=${Date.now()}`;
      probe.onload = () => {
        probe.remove();
        const snapshot = window.__OPENVIDEO_LAUNCH_STATE__;
        delete window.__OPENVIDEO_LAUNCH_STATE__;
        if (snapshot?.launchId === launchId && snapshot?.target === target.href) resolve(snapshot);
        else reject(new Error('OpenVideo startup state identity mismatch'));
      };
      probe.onerror = () => {
        probe.remove();
        reject(new Error('OpenVideo startup state unavailable'));
      };
      document.head.appendChild(probe);
    });
  }

  function monitorPreview() {
    const state = window.OpenVideoIntro?.getState?.();
    previewTimer = window.setTimeout(
      state?.finished ? startPreview : monitorPreview,
      state?.finished ? 1200 : POLL_INTERVAL_MS,
    );
  }

  function startPreview() {
    if (!window.OpenVideoIntro) {
      previewTimer = window.setTimeout(startPreview, 50);
      return;
    }
    window.OpenVideoIntro.reset();
    window.OpenVideoIntro.preview();
    setDetail('自动演示 · 正式启动跟随真实进度');
    previewTimer = window.setTimeout(monitorPreview, POLL_INTERVAL_MS);
  }

  function scheduleReadyHandoff() {
    if (navigationStarted || completionTimer) return;
    completionTimer = window.setTimeout(() => {
      completionTimer = undefined;
      if (navigationStarted) return;
      window.addEventListener('openvideo:intro-complete', navigateToWorkbench, { once: true });
      if (window.OpenVideoIntro?.complete() !== true) navigateToWorkbench();
    }, FINAL_READY_HOLD_MS);
  }

  function applySnapshot(snapshot) {
    if (snapshot?.startup?.phase === 'startup-failed') {
      setDetail('启动失败，请查看启动器中的错误信息后重试', true);
      return true;
    }
    const now = Date.now();
    const reportedProgress = Number(snapshot?.startup?.progress);
    const backendReady = snapshot?.ready === true;
    if (Number.isFinite(reportedProgress)) {
      let visualProgress = Math.min(99.99, Math.max(0, reportedProgress));
      if (backendReady && reportedProgress >= 100) {
        if (!readyHandoff) {
          readyHandoff = {
            startedAt: now,
            progress: Math.max(
              lastVisualProgress,
              Math.min(99.99, ((now - introStartedAt) / MINIMUM_PRODUCT_INTRO_MS) * 100),
            ),
          };
        }
        const requiredDuration = Math.max(
          1,
          MINIMUM_PRODUCT_INTRO_MS - (readyHandoff.startedAt - introStartedAt),
        );
        const elapsedSinceReady = Math.max(0, now - readyHandoff.startedAt);
        visualProgress = readyHandoff.progress +
          ((100 - readyHandoff.progress) * Math.min(1, elapsedSinceReady / requiredDuration));
        if (now - introStartedAt < MINIMUM_PRODUCT_INTRO_MS) visualProgress = Math.min(99.99, visualProgress);
      } else {
        readyHandoff = undefined;
      }
      window.OpenVideoIntro?.setProgress(visualProgress);
      lastVisualProgress = visualProgress;
    }
    const introComplete = backendReady && reportedProgress >= 100 &&
      now - introStartedAt >= MINIMUM_PRODUCT_INTRO_MS;
    setDetail(
      introComplete
        ? (phaseLabels[snapshot?.startup?.phase] || '工作台已就绪')
        : backendReady
          ? '开场收尾中'
          : (phaseLabels[snapshot?.startup?.phase] || '正在准备工作台'),
    );
    if (introComplete) {
      window.OpenVideoIntro?.setProgress(100);
      lastVisualProgress = 100;
      setDetail('工作台已就绪');
      scheduleReadyHandoff();
      return true;
    }
    return false;
  }

  async function poll() {
    if (navigationStarted || !target) return;
    try {
      let snapshot;
      if (window.location.protocol === 'file:' && stateUrl) {
        snapshot = await readLocalState();
      } else {
        const response = await fetch(new URL('api/live', bootstrapMode ? window.location.origin : target), { cache: 'no-store' });
        if (!response.ok) throw new Error('Gateway liveness unavailable');
        snapshot = await response.json();
      }
      if (applySnapshot(snapshot)) return;
    } catch {
      setDetail('正在连接本机服务');
    }
    schedulePoll();
  }

  function destroy() {
    if (pollTimer) window.clearTimeout(pollTimer);
    if (previewTimer) window.clearTimeout(previewTimer);
    if (completionTimer) window.clearTimeout(completionTimer);
    if (elapsedTimecodeFrame && typeof window.cancelAnimationFrame === 'function') {
      window.cancelAnimationFrame(elapsedTimecodeFrame);
    }
  }

  target = resolveTarget(targetValue);
  stateUrl = parseStateUrl(stateValue);
  window.OpenVideoStartupBridge = Object.freeze({
    parseTarget, resolveTarget, parseStateUrl, readLocalState, startPreview, destroy,
  });
  if (previewMode) {
    startPreview();
    window.addEventListener('pagehide', destroy, { once: true });
    return;
  }
  if (!target) {
    setDetail('启动目标无效，请重新运行启动器', true);
    return;
  }
  if (typeof window.requestAnimationFrame === 'function') {
    elapsedTimecodeFrame = window.requestAnimationFrame(updateElapsedTimecode);
  }
  window.addEventListener('pagehide', destroy, { once: true });
  async function start() {
    if (bootstrapMode) {
      try {
        const response = await fetch('/launch-config.json', { cache: 'no-store' });
        if (!response.ok) throw new Error('launch_config_unavailable');
        const config = await response.json();
        target = parseTarget(config.target);
        if (!target || !/^[a-f0-9]{32}$/.test(config.launchId)) throw new Error('invalid_launch_config');
      } catch {
        setDetail('启动状态不可用，请重新运行启动器', true);
        return;
      }
    }
    void poll();
  }
  void start();
})();
