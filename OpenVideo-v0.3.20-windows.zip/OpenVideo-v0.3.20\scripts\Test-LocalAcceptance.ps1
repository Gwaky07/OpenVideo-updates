[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot),
    [switch]$IncludeEditMindBoundary,
    [switch]$IncludeTPL003Real,
    [switch]$RequireJY003Desktop,
    [switch]$GenerateJY003RealDraft
)

$ErrorActionPreference = 'Stop'

function Invoke-Check {
    param(
        [string]$Name,
        [scriptblock]$Action
    )

    Write-Host "==> $Name" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Action
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
if ($IncludeTPL003Real -and [string]::IsNullOrWhiteSpace($env:OPENVIDEO_TPL003_REFERENCE_ROOT)) {
    throw 'OPENVIDEO_TPL003_REFERENCE_ROOT is required when IncludeTPL003Real is enabled.'
}

Invoke-Check 'Governance' {
    & (Join-Path $resolvedRoot 'scripts/Test-Governance.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'Governance negative gates' {
    & (Join-Path $resolvedRoot 'scripts/Test-Governance-Negative.ps1') -RepositoryRoot $resolvedRoot
}

if ($IncludeEditMindBoundary) {
    Invoke-Check 'Edit Mind read-only boundary (non-Docker)' {
        & (Join-Path $resolvedRoot 'scripts/Test-EditMindReadonlyBoundary.ps1') -RepositoryRoot $resolvedRoot
    }
}

Invoke-Check 'Edit Mind authorized sample synthetic tests' {
    & (Join-Path $resolvedRoot 'scripts/Test-EditMindAuthorizedSamples.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'Edit Mind scene search synthetic tests' {
    & (Join-Path $resolvedRoot 'scripts/Test-EditMindSceneSearch.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo web' {
    & (Join-Path $resolvedRoot 'scripts/Test-OpenVideoWeb.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo PROD-001 private runtime' {
    & (Join-Path $resolvedRoot 'scripts/Test-PROD001.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo LLM Gateway' {
    & (Join-Path $resolvedRoot 'scripts/Test-LLMGateway.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo LLM Director' {
    & (Join-Path $resolvedRoot 'scripts/Test-LLMDirector.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo JY-001 draft preparation contract' {
    & (Join-Path $resolvedRoot 'scripts/Test-JY001.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo TPL-001 fixed template library' {
    & (Join-Path $resolvedRoot 'scripts/Test-TPL001.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo TPL-002 reference template contracts' {
    & (Join-Path $resolvedRoot 'scripts/Test-TPL002.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo TPL-003 real reference template adapter' {
    & (Join-Path $resolvedRoot 'scripts/Test-TPL003.ps1') `
        -RepositoryRoot $resolvedRoot `
        -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
        -ReferenceRoot $env:OPENVIDEO_TPL003_REFERENCE_ROOT `
        -Real:$IncludeTPL003Real
}

Invoke-Check 'OpenVideo JY-002 Jianying adapter' {
    & (Join-Path $resolvedRoot 'scripts/Test-JY002.ps1') -RepositoryRoot $resolvedRoot
}

Invoke-Check 'OpenVideo JY-003 real Workbench draft bridge' {
    & (Join-Path $resolvedRoot 'scripts/Test-JY003.ps1') `
        -RepositoryRoot $resolvedRoot `
        -RequireDesktop:$RequireJY003Desktop `
        -GenerateRealDraft:$GenerateJY003RealDraft
}

Invoke-Check 'Git diff check' {
    & git -C $resolvedRoot diff --check
    & git -C $resolvedRoot diff --check origin/main..HEAD
}

Write-Host 'All local acceptance checks passed.' -ForegroundColor Green
exit 0
