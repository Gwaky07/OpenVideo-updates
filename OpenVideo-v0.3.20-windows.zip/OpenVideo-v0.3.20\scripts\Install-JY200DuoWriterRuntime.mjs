import { constants as fsConstants } from 'node:fs'
import { execFile as execFileCallback } from 'node:child_process'
import { createHash } from 'node:crypto'
import { copyFile, lstat, mkdir, mkdtemp, readFile, readdir, realpath, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'

import {
  buildJY200DuoWriterRuntime,
  validateInstalledDuoWriterRuntime,
} from './Build-JY200DuoWriterRuntime.mjs'
import { validateJY200DuoPrivateJavaRuntime } from './JY200DuoPrivateJavaRuntime.mjs'

const repositoryRoot = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const execFile = promisify(execFileCallback)
const fingerprintPattern = /^[a-f0-9]{64}$/u
const productCliClassName = 'OpenVideoJY200DuoProductRunner'
const productCliManifestName = 'openvideo-duo-product-cli.json'
const productCliSource = `
import com.duoec.video.builder.ProjectBuilder;
import com.duoec.video.jy.JianyingBuilder;
import com.duoec.video.jy.JianyingProjectBuildState;
import com.duoec.video.jy.utils.JianyingResourceUtils;
import com.duoec.video.project.VideoProject;
import com.duoec.video.project.material.BaseMaterial;
import com.duoec.video.project.material.BaseTextMaterial;
import com.duoec.base.core.util.JsonUtils;
import java.io.File;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class OpenVideoJY200DuoProductRunner {
    private static String text(Map<String, Object> value, String key) {
        Object actual = value.get(key);
        if (!(actual instanceof String result) || result.isBlank()) throw new IllegalArgumentException("JY200_DUO_PRODUCT_PLAN_INVALID");
        return result;
    }
    private static long number(Map<String, Object> value, String key) {
        Object actual = value.get(key);
        if (!(actual instanceof Number result)) throw new IllegalArgumentException("JY200_DUO_PRODUCT_PLAN_INVALID");
        return result.longValue();
    }
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> list(Map<String, Object> value, String key) {
        Object actual = value.get(key);
        if (!(actual instanceof List<?> result)) throw new IllegalArgumentException("JY200_DUO_PRODUCT_PLAN_INVALID");
        return (List<Map<String, Object>>) result;
    }
    private static File localFile(Map<String, Object> value) {
        URI uri = URI.create(text(value, "url"));
        if (!"file".equalsIgnoreCase(uri.getScheme())) throw new IllegalArgumentException("JY200_DUO_PRODUCT_PLAN_INVALID");
        File file = Path.of(uri).toFile();
        if (!file.isAbsolute() || !file.isFile()) throw new IllegalArgumentException("JY200_DUO_PRODUCT_PLAN_INVALID");
        return file;
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("JY200_DUO_PRODUCT_ARGUMENT_INVALID");
        String outputRoot = args[0];
        @SuppressWarnings("unchecked")
        Map<String, Object> plan = JsonUtils.getObjectMapper().readValue(
            Files.readString(Path.of(args[1])), Map.class);
        String draftName = text(plan, "draftName");
        Map<String, Object> font = (Map<String, Object>) plan.get("font");
        if (font == null) throw new IllegalArgumentException("JY200_DUO_PRODUCT_PLAN_INVALID");
        String fontName = text(font, "name");
        File fontFile = localFile(font);
        Path fontTarget = Path.of("tmp", "rs", "fonts", fontFile.getName());
        Files.createDirectories(fontTarget.getParent());
        if (Files.exists(fontTarget)) {
            if (Files.mismatch(fontFile.toPath(), fontTarget) != -1L) {
                throw new IllegalArgumentException("JY200_DUO_PRODUCT_FONT_REPLACED");
            }
        } else {
            Files.copy(fontFile.toPath(), fontTarget);
        }
        String fontUri = fontTarget.toFile().toURI().toString();
        JianyingResourceUtils.setFontMap(Map.of(
            fontName, fontUri,
            JianyingResourceUtils.DEFAULT_FONT_NAME, fontUri));
        AtomicLong materialId = new AtomicLong(200000000000000011L);
        Map<Long, File> localFiles = new HashMap<>();
        JianyingProjectBuildState.DEBUG_JY_DRAFT_DIR = outputRoot + File.separator;
        VideoProject project = ProjectBuilder.createProject(200000000000000001L, draftName, 1080, 1920)
            .setTest(true)
            .buildScript(0, script -> {
                for (Map<String, Object> video : list(plan, "videos")) {
                    long id = materialId.getAndIncrement();
                    localFiles.put(id, localFile(video));
                    script.buildNewVideo(id, text(video, "url"), number(video, "start"), number(video, "duration"),
                        builder -> builder.setMaterialTime(number(video, "sourceStart"), number(video, "sourceDuration")));
                }
                for (Map<String, Object> item : list(plan, "texts")) {
                    String value = text(item, "text");
                    Object flower = item.get("flowerId");
                    script.buildNewText(value, number(item, "start"), number(item, "duration"), builder -> {
                        builder.setPosition(0, flower == null ? 620 : 120)
                            .setStyle(new BaseTextMaterial.TextStyle()
                                .setFontName(fontName).setFontSize(flower == null ? 30 : 28).setBold(flower == null).setItalic(false).setTextAlign(1)
                                .setFillColor("#FFFFFF").setStrokeColor("#000000").setStrokeWidth(4));
                        if (flower instanceof String id) builder.addWord(0, value.length(), word -> word.setFlowerId(Long.parseLong(id)));
                    });
                }
                for (Map<String, Object> audio : list(plan, "audios")) {
                    long id = materialId.getAndIncrement();
                    localFiles.put(id, localFile(audio));
                    script.buildNewAudio(id, text(audio, "url"), number(audio, "start"), number(audio, "duration"),
                        builder -> builder.setMaterialTime(number(audio, "sourceStart"), number(audio, "sourceDuration"))
                            .setVolume((int) number(audio, "volume")));
                }
                for (Map<String, Object> sticker : list(plan, "stickers")) {
                    script.buildNewSticker(Long.parseLong(text(sticker, "resourceId")), number(sticker, "start"), number(sticker, "duration"),
                        builder -> builder.setPosition(240, -300).setZoom(7000, 7000));
                }
                for (Map<String, Object> effect : list(plan, "videoEffects")) {
                    script.builderNewVideoEffect(Long.parseLong(text(effect, "resourceId")), number(effect, "start"), number(effect, "duration"), builder -> {});
                }
            })
            .getProject();
        for (BaseMaterial material : project.getMaterials()) {
            File file = localFiles.get(material.getId());
            if (file != null) material.setLocalFile(file);
        }
        new JianyingBuilder().build(project);
    }
}
`.trimStart()
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const productCliSourceSha256 = sha256(Buffer.from(productCliSource))

const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const observed = await lstat(actual, { bigint: true })
  return requestedMetadata.dev === observed.dev && requestedMetadata.ino === observed.ino
}

const errorCode = (error) => error && typeof error === 'object' && 'code' in error ? error.code : undefined
const immutableIdentity = (metadata) => Object.freeze({
  dev: metadata.dev.toString(),
  ino: metadata.ino.toString(),
  birthtimeNs: metadata.birthtimeNs.toString(),
  size: metadata.size.toString(),
})
const allowedWriterModules = Object.freeze(['duo-server-base', 'duo-video-base', 'duo-video-jy'])
const allowedRenameRaceCodes = new Set(['EEXIST', 'ENOTEMPTY', 'EPERM', 'EACCES'])

const assertSafeRelativePath = (value) => {
  if (typeof value !== 'string' || value.length === 0 || path.isAbsolute(value)) {
    throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_INVALID')
  }
  const normalized = value.split(/[\\/]+/u)
  if (normalized.some((segment) => segment.length === 0 || segment === '.' || segment === '..')) {
    throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_INVALID')
  }
  return normalized.join('/')
}

const ensureOrdinaryDirectory = async (target) => {
  await mkdir(target, { recursive: true, mode: 0o700 })
  const [metadata, actual] = await Promise.all([lstat(target, { bigint: true }), realpath(target)])
  if (!metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameResolvedObject(target, actual, metadata)) {
    throw new Error('JY200_DUO_INSTALL_ROOT_UNSAFE')
  }
}

const observeOrdinaryDirectory = async (target) => {
  await ensureOrdinaryDirectory(target)
  const metadata = await lstat(target, { bigint: true })
  return Object.freeze({ path: path.resolve(target), ...immutableIdentity(metadata) })
}

const assertObservedDirectoryCurrent = async (identity) => {
  const metadata = await lstat(identity.path, { bigint: true })
  if (!metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameResolvedObject(identity.path, await realpath(identity.path), metadata)) {
    throw new Error('JY200_DUO_INSTALL_ROOT_UNSAFE')
  }
  const current = immutableIdentity(metadata)
  if (current.dev !== identity.dev || current.ino !== identity.ino || current.birthtimeNs !== identity.birthtimeNs) {
    throw new Error('JY200_DUO_INSTALL_ROOT_UNSAFE')
  }
}

const snapshotOrdinaryTree = async ({ root }) => {
  const rootIdentity = await observeOrdinaryDirectory(root)
  /** @type {Array<{relativePath: string, identity: ReturnType<typeof immutableIdentity>}>} */
  const entries = []
  const visit = async (current) => {
    const children = await readdir(current, { withFileTypes: true })
    children.sort((left, right) => left.name.localeCompare(right.name))
    for (const child of children) {
      const candidate = path.join(current, child.name)
      const metadata = await lstat(candidate, { bigint: true })
      const actual = await realpath(candidate)
      if (metadata.isSymbolicLink() || !await sameResolvedObject(candidate, actual, metadata)) {
        throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_INVALID')
      }
      if (metadata.isDirectory()) {
        await visit(candidate)
        continue
      }
      if (!metadata.isFile()) {
        throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_INVALID')
      }
      entries.push(Object.freeze({
        relativePath: assertSafeRelativePath(path.relative(rootIdentity.path, candidate).split(path.sep).join('/')),
        identity: immutableIdentity(metadata),
      }))
    }
  }
  await visit(rootIdentity.path)
  return Object.freeze({ rootIdentity, entries: Object.freeze(entries) })
}

const assertSnapshotCurrent = async (snapshot) => {
  await assertObservedDirectoryCurrent(snapshot.rootIdentity)
  const current = await snapshotOrdinaryTree({ root: snapshot.rootIdentity.path })
  if (current.entries.length !== snapshot.entries.length) {
    throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_REPLACED')
  }
  for (let index = 0; index < snapshot.entries.length; index += 1) {
    const expected = snapshot.entries[index]
    const actual = current.entries[index]
    if (!actual || actual.relativePath !== expected.relativePath ||
        actual.identity.dev !== expected.identity.dev ||
        actual.identity.ino !== expected.identity.ino ||
        actual.identity.birthtimeNs !== expected.identity.birthtimeNs ||
        actual.identity.size !== expected.identity.size) {
      throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_REPLACED')
    }
  }
}

const writerRuntimePathAllowed = (relativePath) => relativePath === 'openvideo-duo-writer-runtime.json' ||
  /^runtime-dependencies\/[^/]+\.jar$/u.test(relativePath) ||
  new RegExp(`^(?:${allowedWriterModules.join('|')})/target/[^/]+\\.jar$`, 'u').test(relativePath)

const copyVerifiedOrdinaryTree = async ({
  sourceRoot,
  destinationRoot,
  validateSource,
  validateDestination,
  includeEntry = () => true,
  onBeforeSourceRecheck = undefined,
}) => {
  const before = await validateSource(sourceRoot)
  const snapshot = await snapshotOrdinaryTree({ root: sourceRoot })
  await mkdir(destinationRoot, { recursive: true, mode: 0o700 })
  for (const entry of snapshot.entries) {
    if (!includeEntry(entry.relativePath)) continue
    const destination = path.join(destinationRoot, ...entry.relativePath.split('/'))
    await mkdir(path.dirname(destination), { recursive: true, mode: 0o700 })
    await copyFile(path.join(sourceRoot, ...entry.relativePath.split('/')), destination, fsConstants.COPYFILE_EXCL)
  }
  if (typeof onBeforeSourceRecheck === 'function') {
    await onBeforeSourceRecheck({ sourceRoot: path.resolve(sourceRoot), destinationRoot: path.resolve(destinationRoot) })
  }
  await assertSnapshotCurrent(snapshot)
  const after = await validateSource(sourceRoot)
  if (JSON.stringify(before) !== JSON.stringify(after)) {
    throw new Error('JY200_DUO_INSTALL_COPY_SOURCE_REPLACED')
  }
  return validateDestination(destinationRoot)
}

const promoteInstalledTree = async ({
  destination,
  stagingRoot,
  inspectInstalled,
  validateDestination,
  invalidCode,
}) => {
  try {
    await rename(stagingRoot, destination)
    return await validateDestination(destination)
  } catch (error) {
    if (!allowedRenameRaceCodes.has(errorCode(error) ?? '')) throw error
    const reused = await inspectInstalled()
    if (reused.available) return reused
    throw new Error(invalidCode)
  } finally {
    await rm(stagingRoot, { recursive: true, force: true }).catch(() => {})
  }
}

export const resolveJY200DuoInstalledRuntimeRoot = ({ dataRoot, manifest }) => {
  const fingerprint = manifest?.writer_only_runtime?.verified_build?.manifest_fingerprint
  if (typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot) || !fingerprintPattern.test(fingerprint ?? '')) {
    throw new Error('JY200_DUO_INSTALL_INPUT_INVALID')
  }
  return path.join(path.resolve(dataRoot), 'providers', 'duo-video', 'installed', fingerprint)
}

export const resolveJY200DuoPrivateJavaRoot = ({ dataRoot, manifest }) => {
  const fingerprint = manifest?.writer_only_runtime?.private_java_distribution?.inventory_fingerprint
  if (typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot) || !fingerprintPattern.test(fingerprint ?? '')) {
    throw new Error('JY200_DUO_PRIVATE_JAVA_INSTALL_INPUT_INVALID')
  }
  return path.join(path.resolve(dataRoot), 'providers', 'duo-video', 'java', fingerprint)
}

const productCliIdentity = (installedRuntime) => {
  const runtimeRoot = path.resolve(installedRuntime?.runtimeRoot ?? '')
  const classpathEntries = Array.isArray(installedRuntime?.classpathEntries)
    ? installedRuntime.classpathEntries.map((entry) => {
      const relative = path.relative(runtimeRoot, path.resolve(entry)).split(path.sep).join('/')
      if (!relative || relative === '..' || relative.startsWith('../') || path.isAbsolute(relative)) {
        throw new Error('JY200_DUO_PRODUCT_CLI_INPUT_INVALID')
      }
      return relative
    })
    : []
  const writerBuildDigest = installedRuntime?.buildDigest
  const javaInventoryFingerprint = installedRuntime?.privateJava?.inventoryFingerprint
  if (!fingerprintPattern.test(writerBuildDigest ?? '') ||
      !fingerprintPattern.test(javaInventoryFingerprint ?? '') || classpathEntries.length === 0) {
    throw new Error('JY200_DUO_PRODUCT_CLI_INPUT_INVALID')
  }
  const identity = Object.freeze({
    schema_version: 1,
    class_name: productCliClassName,
    source_sha256: productCliSourceSha256,
    writer_build_digest: writerBuildDigest,
    java_inventory_fingerprint: javaInventoryFingerprint,
    classpath_entries: Object.freeze(classpathEntries),
  })
  return Object.freeze({ ...identity, cli_fingerprint: sha256(Buffer.from(JSON.stringify(identity))) })
}

export const resolveJY200DuoProductCliRoot = ({ dataRoot, installedRuntime }) => {
  if (typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot)) {
    throw new Error('JY200_DUO_PRODUCT_CLI_INPUT_INVALID')
  }
  return path.join(path.resolve(dataRoot), 'providers', 'duo-video', 'product-cli',
    productCliIdentity(installedRuntime).cli_fingerprint)
}

const validateJY200DuoProductCli = async ({ runtimeRoot, installedRuntime }) => {
  const expected = productCliIdentity(installedRuntime)
  const [rootMetadata, actualRoot] = await Promise.all([lstat(runtimeRoot, { bigint: true }), realpath(runtimeRoot)])
  if (!rootMetadata.isDirectory() || rootMetadata.isSymbolicLink() ||
      !await sameResolvedObject(runtimeRoot, actualRoot, rootMetadata)) {
    throw new Error('JY200_DUO_PRODUCT_CLI_IDENTITY_INVALID')
  }
  const snapshot = await snapshotOrdinaryTree({ root: runtimeRoot })
  const expectedFiles = [`${productCliClassName}.class`, productCliManifestName].sort()
  const actualFiles = snapshot.entries.map((entry) => entry.relativePath).sort()
  if (JSON.stringify(actualFiles) !== JSON.stringify(expectedFiles)) {
    throw new Error('JY200_DUO_PRODUCT_CLI_IDENTITY_INVALID')
  }
  const [manifestBytes, classBytes] = await Promise.all([
    readFile(path.join(runtimeRoot, productCliManifestName)),
    readFile(path.join(runtimeRoot, `${productCliClassName}.class`)),
  ])
  await assertSnapshotCurrent(snapshot)
  const manifest = JSON.parse(manifestBytes.toString('utf8'))
  if (JSON.stringify({
    schema_version: manifest?.schema_version,
    class_name: manifest?.class_name,
    source_sha256: manifest?.source_sha256,
    writer_build_digest: manifest?.writer_build_digest,
    java_inventory_fingerprint: manifest?.java_inventory_fingerprint,
    classpath_entries: manifest?.classpath_entries,
    cli_fingerprint: manifest?.cli_fingerprint,
  }) !== JSON.stringify(expected) || !fingerprintPattern.test(manifest?.class_sha256 ?? '') ||
      manifest.class_sha256 !== sha256(classBytes)) {
    throw new Error('JY200_DUO_PRODUCT_CLI_IDENTITY_INVALID')
  }
  return Object.freeze({
    runtimeRoot: path.resolve(runtimeRoot),
    classRoot: path.resolve(runtimeRoot),
    classFile: path.join(path.resolve(runtimeRoot), `${productCliClassName}.class`),
    className: productCliClassName,
    classSha256: manifest.class_sha256,
    ...expected,
  })
}

export const inspectJY200DuoProductCli = async ({ dataRoot, installedRuntime }) => {
  const runtimeRoot = resolveJY200DuoProductCliRoot({ dataRoot, installedRuntime })
  try {
    return Object.freeze({
      available: true,
      ...await validateJY200DuoProductCli({ runtimeRoot, installedRuntime }),
    })
  } catch {
    return Object.freeze({ available: false, runtimeRoot })
  }
}

const compileJY200DuoProductCli = async ({ stagingRoot, installedRuntime }) => {
  const sourcePath = path.join(stagingRoot, `${productCliClassName}.java`)
  await writeFile(sourcePath, productCliSource, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
  const environment = {}
  for (const expected of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP']) {
    const actual = Object.keys(process.env).find((key) => key.toLowerCase() === expected.toLowerCase())
    if (actual && typeof process.env[actual] === 'string') environment[expected] = process.env[actual]
  }
  try {
    await execFile(installedRuntime.privateJava.javacExecutable, [
      '-encoding', 'UTF-8', '-cp', installedRuntime.classpathEntries.join(path.delimiter),
      '-d', stagingRoot, sourcePath,
    ], {
      cwd: installedRuntime.runtimeRoot,
      env: environment,
      windowsHide: true,
      timeout: 60_000,
      maxBuffer: 64 * 1024,
    })
  } catch {
    throw new Error('JY200_DUO_PRODUCT_CLI_COMPILE_FAILED')
  } finally {
    await rm(sourcePath, { force: true })
  }
}

export const installJY200DuoProductCli = async ({
  dataRoot,
  installedRuntime,
  compile = compileJY200DuoProductCli,
} = {}) => {
  const existing = await inspectJY200DuoProductCli({ dataRoot, installedRuntime })
  if (existing.available) return existing
  const identity = productCliIdentity(installedRuntime)
  const destination = resolveJY200DuoProductCliRoot({ dataRoot, installedRuntime })
  const installParent = path.dirname(destination)
  await ensureOrdinaryDirectory(installParent)
  try {
    await lstat(destination)
    throw new Error('JY200_DUO_PRODUCT_CLI_INSTALLED_INVALID')
  } catch (error) {
    if (error instanceof Error && error.message === 'JY200_DUO_PRODUCT_CLI_INSTALLED_INVALID') throw error
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw error
  }
  const stagingRoot = await mkdtemp(path.join(installParent, '.cli-install-'))
  try {
    await compile({ stagingRoot, installedRuntime, source: productCliSource })
    const classFile = path.join(stagingRoot, `${productCliClassName}.class`)
    const classBytes = await readFile(classFile)
    if (classBytes.length === 0) throw new Error('JY200_DUO_PRODUCT_CLI_COMPILE_FAILED')
    await writeFile(path.join(stagingRoot, productCliManifestName), `${JSON.stringify({
      ...identity,
      class_sha256: sha256(classBytes),
    }, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await validateJY200DuoProductCli({ runtimeRoot: stagingRoot, installedRuntime })
    return await promoteInstalledTree({
      destination,
      stagingRoot,
      inspectInstalled: () => inspectJY200DuoProductCli({ dataRoot, installedRuntime }),
      validateDestination: (runtimeRoot) => validateJY200DuoProductCli({ runtimeRoot, installedRuntime })
        .then((validated) => Object.freeze({ available: true, ...validated })),
      invalidCode: 'JY200_DUO_PRODUCT_CLI_INSTALLED_INVALID',
    })
  } catch (error) {
    await rm(stagingRoot, { recursive: true, force: true }).catch(() => {})
    throw error
  }
}

const resolveJY200DuoBundledJavaRoot = ({ root, manifest }) => {
  const distribution = manifest?.writer_only_runtime?.private_java_distribution
  if (!distribution || !fingerprintPattern.test(distribution.inventory_fingerprint ?? '') ||
      typeof distribution.archive_root !== 'string' || !/^[A-Za-z0-9+._-]+$/u.test(distribution.archive_root)) {
    throw new Error('JY200_DUO_PRIVATE_JAVA_INSTALL_INPUT_INVALID')
  }
  return path.join(path.resolve(root), 'runtime-assets', 'duo-video', 'java',
    distribution.inventory_fingerprint, distribution.archive_root)
}

export const inspectJY200DuoInstalledPrivateJava = async ({ dataRoot, manifest, execute = true }) => {
  const runtimeRoot = resolveJY200DuoPrivateJavaRoot({ dataRoot, manifest })
  try {
    const validated = await validateJY200DuoPrivateJavaRuntime({
      runtimeRoot,
      distribution: manifest.writer_only_runtime.private_java_distribution,
      execute,
    })
    return Object.freeze({ available: true, ...validated })
  } catch {
    return Object.freeze({ available: false, runtimeRoot })
  }
}

export const installJY200DuoPrivateJava = async ({
  root,
  dataRoot,
  manifest,
  execute = true,
  onBeforeSourceRecheck = undefined,
} = {}) => {
  const existing = await inspectJY200DuoInstalledPrivateJava({ dataRoot, manifest, execute })
  if (existing.available) return existing
  const sourceRoot = resolveJY200DuoBundledJavaRoot({ root, manifest })
  const destination = resolveJY200DuoPrivateJavaRoot({ dataRoot, manifest })
  const installParent = path.dirname(destination)
  await ensureOrdinaryDirectory(installParent)
  try {
    await lstat(destination)
    throw new Error('JY200_DUO_PRIVATE_JAVA_INSTALLED_INVALID')
  } catch (error) {
    if (error instanceof Error && error.message === 'JY200_DUO_PRIVATE_JAVA_INSTALLED_INVALID') throw error
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw error
  }
  const stagingRoot = await mkdtemp(path.join(installParent, '.java-install-'))
  try {
    await copyVerifiedOrdinaryTree({
      sourceRoot,
      destinationRoot: stagingRoot,
      validateSource: (runtimeRoot) => validateJY200DuoPrivateJavaRuntime({
        runtimeRoot,
        distribution: manifest.writer_only_runtime.private_java_distribution,
        execute,
      }),
      validateDestination: (runtimeRoot) => validateJY200DuoPrivateJavaRuntime({
        runtimeRoot,
        distribution: manifest.writer_only_runtime.private_java_distribution,
        execute,
      }),
      onBeforeSourceRecheck,
    })
    return await promoteInstalledTree({
      destination,
      stagingRoot,
      inspectInstalled: () => inspectJY200DuoInstalledPrivateJava({ dataRoot, manifest, execute }),
      validateDestination: (runtimeRoot) => validateJY200DuoPrivateJavaRuntime({
        runtimeRoot,
        distribution: manifest.writer_only_runtime.private_java_distribution,
        execute,
      }).then((validated) => Object.freeze({ available: true, ...validated })),
      invalidCode: 'JY200_DUO_PRIVATE_JAVA_INSTALLED_INVALID',
    })
  } catch (error) {
    throw error
  }
}

export const inspectJY200DuoInstalledRuntime = async ({
  dataRoot,
  manifest,
  executePrivateJava = true,
  requireProductCli = executePrivateJava,
}) => {
  const runtimeRoot = resolveJY200DuoInstalledRuntimeRoot({ dataRoot, manifest })
  try {
    const [validated, privateJava] = await Promise.all([
      validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
      inspectJY200DuoInstalledPrivateJava({ dataRoot, manifest, execute: executePrivateJava }),
    ])
    if (!privateJava.available) throw new Error('JY200_DUO_PRIVATE_JAVA_UNAVAILABLE')
    const base = Object.freeze({ available: true, runtimeRoot, ...validated, privateJava })
    if (!requireProductCli) return base
    const productCli = await inspectJY200DuoProductCli({ dataRoot, installedRuntime: base })
    if (!productCli.available) throw new Error('JY200_DUO_PRODUCT_CLI_UNAVAILABLE')
    return Object.freeze({ ...base, productCli })
  } catch {
    return Object.freeze({ available: false, runtimeRoot })
  }
}

export const stageJY200DuoBundledWriterRuntime = async ({ root, outputParent, manifest }) => {
  const fingerprint = manifest?.writer_only_runtime?.verified_build?.manifest_fingerprint
  if (typeof root !== 'string' || !path.isAbsolute(root) ||
      typeof outputParent !== 'string' || !path.isAbsolute(outputParent) ||
      !fingerprintPattern.test(fingerprint ?? '')) {
    throw new Error('JY200_DUO_BUNDLED_RUNTIME_INPUT_INVALID')
  }
  const sourceRoot = path.join(path.resolve(root), 'runtime-assets', 'duo-video', 'writer', fingerprint)
  await validateInstalledDuoWriterRuntime({ runtimeRoot: sourceRoot, manifest })
  await ensureOrdinaryDirectory(outputParent)
  const stagingRoot = await mkdtemp(path.join(outputParent, '.writer-install-'))
  try {
    await copyVerifiedOrdinaryTree({
      sourceRoot,
      destinationRoot: stagingRoot,
      validateSource: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
      validateDestination: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
      includeEntry: writerRuntimePathAllowed,
    })
    return Object.freeze({ stagingRoot })
  } catch (error) {
    await rm(stagingRoot, { recursive: true, force: true }).catch(() => {})
    throw error
  }
}

export const installJY200DuoWriterRuntime = async ({
  root = repositoryRoot,
  dataRoot,
  build = stageJY200DuoBundledWriterRuntime,
  executePrivateJava = true,
} = {}) => {
  const manifest = JSON.parse(await readFile(path.join(root, 'config', 'duo-video-upstream.json'), 'utf8'))
  const privateJava = await installJY200DuoPrivateJava({
    root,
    dataRoot,
    manifest,
    execute: executePrivateJava,
  })
  const destination = resolveJY200DuoInstalledRuntimeRoot({ dataRoot, manifest })
  const existing = await inspectJY200DuoInstalledRuntime({
    dataRoot,
    manifest,
    executePrivateJava,
    requireProductCli: false,
  })
  if (existing.available) {
    if (!executePrivateJava) return existing
    const productCli = await installJY200DuoProductCli({ dataRoot, installedRuntime: existing })
    return Object.freeze({ ...existing, productCli })
  }

  const installParent = path.dirname(destination)
  await ensureOrdinaryDirectory(installParent)
  try {
    const metadata = await lstat(destination)
    if (metadata) throw new Error('JY200_DUO_INSTALLED_RUNTIME_INVALID')
  } catch (error) {
    if (error instanceof Error && error.message === 'JY200_DUO_INSTALLED_RUNTIME_INVALID') throw error
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw error
  }
  const built = await build({
    root,
    manifest,
    runtimeDataRoot: dataRoot,
    outputParent: path.join(path.dirname(installParent), 'install-staging'),
  })
  await validateInstalledDuoWriterRuntime({ runtimeRoot: built.stagingRoot, manifest })
  const installed = await promoteInstalledTree({
    destination,
    stagingRoot: built.stagingRoot,
    inspectInstalled: () => inspectJY200DuoInstalledRuntime({
      dataRoot,
      manifest,
      executePrivateJava,
      requireProductCli: false,
    }),
    validateDestination: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest })
      .then((validated) => Object.freeze({ available: true, runtimeRoot, ...validated, privateJava })),
    invalidCode: 'JY200_DUO_INSTALLED_RUNTIME_INVALID',
  })
  const base = Object.freeze({ ...installed, privateJava })
  if (!executePrivateJava) return base
  const productCli = await installJY200DuoProductCli({ dataRoot, installedRuntime: base })
  return Object.freeze({ ...base, productCli })
}

export const prepareJY200DuoBundledWriterRuntime = async ({ root = repositoryRoot } = {}) => {
  const manifest = JSON.parse(await readFile(path.join(root, 'config', 'duo-video-upstream.json'), 'utf8'))
  await validateJY200DuoPrivateJavaRuntime({
    runtimeRoot: resolveJY200DuoBundledJavaRoot({ root, manifest }),
    distribution: manifest.writer_only_runtime.private_java_distribution,
    execute: false,
  })
  const destination = path.join(path.resolve(root), 'runtime-assets', 'duo-video', 'writer',
    manifest.writer_only_runtime.verified_build.manifest_fingerprint)
  try {
    const validated = await validateInstalledDuoWriterRuntime({ runtimeRoot: destination, manifest })
    return Object.freeze({ runtimeRoot: destination, ...validated })
  } catch {}
  const outputParent = path.dirname(destination)
  await ensureOrdinaryDirectory(outputParent)
  const temporaryRoot = await mkdtemp(path.join(path.resolve(root), '.jy200-duo-writer-build-'))
  const buildDataRoot = path.join(temporaryRoot, 'runtime-data')
  const buildOutputParent = path.join(temporaryRoot, 'build-staging')
  const stagingRoot = await mkdtemp(path.join(outputParent, '.writer-bundle-'))
  try {
    const built = await buildJY200DuoWriterRuntime({
      root,
      runtimeDataRoot: buildDataRoot,
      outputParent: buildOutputParent,
    })
    await copyVerifiedOrdinaryTree({
      sourceRoot: built.stagingRoot,
      destinationRoot: stagingRoot,
      validateSource: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
      validateDestination: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
      includeEntry: writerRuntimePathAllowed,
    })
    return await promoteInstalledTree({
      destination,
      stagingRoot,
      inspectInstalled: async () => {
        try {
          const validated = await validateInstalledDuoWriterRuntime({ runtimeRoot: destination, manifest })
          return Object.freeze({ available: true, runtimeRoot: destination, ...validated })
        } catch {
          return Object.freeze({ available: false, runtimeRoot: destination })
        }
      },
      validateDestination: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest })
        .then((validated) => Object.freeze({ runtimeRoot, ...validated })),
      invalidCode: 'JY200_DUO_INSTALLED_RUNTIME_INVALID',
    })
  } finally {
    await rm(temporaryRoot, { recursive: true, force: true }).catch(() => {})
  }
}

export const stageJY200DuoReleaseAssets = async ({ root = repositoryRoot, releaseRoot }) => {
  if (typeof releaseRoot !== 'string' || !path.isAbsolute(releaseRoot)) {
    throw new Error('JY200_DUO_RELEASE_STAGE_INPUT_INVALID')
  }
  const manifest = JSON.parse(await readFile(path.join(root, 'config', 'duo-video-upstream.json'), 'utf8'))
  const javaDistribution = manifest.writer_only_runtime.private_java_distribution
  const javaSourceRoot = resolveJY200DuoBundledJavaRoot({ root, manifest })
  const javaReleaseRoot = path.join(releaseRoot, 'runtime-assets', 'duo-video', 'java',
    javaDistribution.inventory_fingerprint, javaDistribution.archive_root)
  await copyVerifiedOrdinaryTree({
    sourceRoot: javaSourceRoot,
    destinationRoot: javaReleaseRoot,
    validateSource: (runtimeRoot) => validateJY200DuoPrivateJavaRuntime({
      runtimeRoot,
      distribution: javaDistribution,
      execute: false,
    }),
    validateDestination: (runtimeRoot) => validateJY200DuoPrivateJavaRuntime({
      runtimeRoot,
      distribution: javaDistribution,
      execute: false,
    }),
  })
  const writerReleaseRoot = path.join(releaseRoot, 'runtime-assets', 'duo-video', 'writer',
    manifest.writer_only_runtime.verified_build.manifest_fingerprint)
  await copyVerifiedOrdinaryTree({
    sourceRoot: path.join(path.resolve(root), 'runtime-assets', 'duo-video', 'writer',
      manifest.writer_only_runtime.verified_build.manifest_fingerprint),
    destinationRoot: writerReleaseRoot,
    validateSource: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
    validateDestination: (runtimeRoot) => validateInstalledDuoWriterRuntime({ runtimeRoot, manifest }),
    includeEntry: writerRuntimePathAllowed,
  })
  const noticeSource = path.join(path.resolve(root), 'docs', 'licenses', 'THIRD-PARTY-NOTICES.md')
  const noticeTarget = path.join(path.resolve(releaseRoot), 'docs', 'licenses', 'THIRD-PARTY-NOTICES.md')
  await ensureOrdinaryDirectory(path.dirname(noticeTarget))
  try {
    await copyFile(noticeSource, noticeTarget, fsConstants.COPYFILE_EXCL)
  } catch (error) {
    if (errorCode(error) !== 'EEXIST') throw error
  }
  await writeFile(path.join(releaseRoot, 'runtime-assets', 'duo-video', '.release-ready'), 'ready\n', {
    encoding: 'utf8',
    mode: 0o600,
  })
  return Object.freeze({
    ok: true,
    provider: 'duo-video',
    releaseRoot: path.resolve(releaseRoot),
    writerManifestFingerprint: manifest.writer_only_runtime.verified_build.manifest_fingerprint,
    privateJavaInventoryFingerprint: javaDistribution.inventory_fingerprint,
  })
}

const main = async () => {
  try {
    const args = process.argv.slice(2)
    if (args[0] === '--prepare-bundled-writer-runtime') {
      const rootIndex = args.indexOf('--root')
      const root = rootIndex >= 0 ? args[rootIndex + 1] : repositoryRoot
      const result = await prepareJY200DuoBundledWriterRuntime({ root: path.resolve(root) })
      process.stdout.write(`${JSON.stringify({
        ok: true,
        provider: 'duo-video',
        runtimeRoot: result.runtimeRoot,
        buildDigest: result.buildDigest,
      })}\n`)
      return
    }
    if (args[0] === '--stage-release-assets') {
      const releaseRoot = args[1]
      const rootIndex = args.indexOf('--root')
      const root = rootIndex >= 0 ? args[rootIndex + 1] : repositoryRoot
      const result = await stageJY200DuoReleaseAssets({ root: path.resolve(root), releaseRoot: path.resolve(releaseRoot) })
      process.stdout.write(`${JSON.stringify(result)}\n`)
      return
    }
    const { loadLauncherRuntimeConfig } = await import('../apps/gateway/src/launcher-runtime-config.mjs')
    const runtime = await loadLauncherRuntimeConfig({ repositoryRoot })
    const result = await installJY200DuoWriterRuntime({ dataRoot: runtime.dataRoot })
    process.stdout.write(`${JSON.stringify({
      ok: true,
      provider: 'duo-video',
      buildDigest: result.buildDigest,
      admission: 'deferred',
      writerEligible: false,
    })}\n`)
  } catch (error) {
    const reason = error instanceof Error && /^JY200_[A-Z0-9_]+$/u.test(error.message)
      ? error.message
      : 'JY200_DUO_INSTALL_FAILED'
    process.stdout.write(`${JSON.stringify({ ok: false, provider: 'duo-video', reason })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
