import { execFile } from 'node:child_process'
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { createScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'
import { parseJianyingBackgroundCatalog } from '../apps/gateway/src/jianying-background-catalog.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const run = promisify(execFile)
const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== 'jianying-11-1-provisional') throw new Error('JY062_PROFILE_UNSUPPORTED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const catalog = parseJianyingBackgroundCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy062-background-catalog.json'), 'utf8')))
  const entry = catalog?.entries.find((item) => item.fill_type === 'blur')
  if (!entry) throw new Error('JY062_BACKGROUND_CATALOG_MISSING')
  const draft = structuredClone(createScaleEvidenceTimeline())
  delete draft.contentFingerprint
  delete draft.revisionFingerprint
  draft.status = 'draft'
  draft.tracks[0].segments[0].effects.push({ capabilityId: 'background.video', offsetRange: { startUs: 0, durationUs: 4_000_000 }, intensity: 1, parameters: { fillToken: entry.fill_token } })
  draft.capabilityRequirements = computeCapabilityRequirements(draft.tracks)
  const timeline = finalizeRichTimeline(sealRichTimeline(draft))
  const projected = projectRichTimelineToJianyingExport(timeline, { capabilityRegistry: createEditorCapabilityRegistry({ jianyingProfileId: desktop.profileId, privateCatalogCapabilities: ['background.video'] }) })
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy062-background-'))
  const video = path.join(mediaRoot, 'video.mp4')
  const audio = path.join(mediaRoot, 'voice.wav')
  await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', video])
  await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audio])
  const background = { fill_type: entry.fill_type, blur: entry.blur, color: entry.color, target_start_us: 0, target_duration_us: 4_000_000 }
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments: [], trackInsertionProfile: desktop.profileId, timelinePackaging: { ...projected.packaging, background_segments: [background], sfx_segments: [], effect_segments: [], sticker_segments: [], filter_segments: [], animation_segments: [], mask_segments: [], blend_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
  const draftId = `OpenVideo-JY062-background-${Date.now()}`
  const request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: video }], voiceovers: [{ path: audio }] }
  const result = await writer.writeDraft(request)
  if (!await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result })) throw new Error('JY062_VERIFY_FAILED')
  if (!await writer.releaseDraft({ job_id: request.job_id, write_result: result })) throw new Error('JY062_RELEASE_FAILED')
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy062-background')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 }); await securePrivateRuntimeRoot(evidenceRoot)
  await writeFile(path.join(evidenceRoot, 'pending.json'), `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, profile_id: desktop.profileId, app_version: desktop.version, catalog_fingerprint: catalog.fingerprint, initial_blur: entry.blur })}\n`, { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(`${JSON.stringify({ ok: true, draft_name: draftId, initial_background: 'blur', initial_blur: entry.blur, manual_open_required: true, version: desktop.version })}\n`)
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY062_FAILED' })}\n`); process.exitCode = 1 })
