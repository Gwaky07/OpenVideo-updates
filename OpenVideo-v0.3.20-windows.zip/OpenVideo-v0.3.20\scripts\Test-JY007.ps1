[CmdletBinding()]
param(
    [string]$DraftId = '',
    [int]$TimeoutMs = 30000
)

$ErrorActionPreference = 'Stop'
$OutputEncoding = [Text.UTF8Encoding]::new($false)
$env:PYTHONIOENCODING = 'utf-8'
$repositoryRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$workerPath = Join-Path $repositoryRoot 'apps\gateway\src\jianying6-visible-render-worker.py'
$privateRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo'
$settingsPath = Join-Path $privateRoot 'jianying6-renderer.json'
$draftRoot = Join-Path $env:LOCALAPPDATA 'JianyingPro\User Data\Projects\com.lveditor.draft'
$python = (Get-Command python -ErrorAction Stop).Source

if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
    throw 'JY007_RENDERER_UNCONFIGURED'
}
if (-not (Test-Path -LiteralPath $workerPath -PathType Leaf)) {
    throw 'JY007_WORKER_MISSING'
}
$settings = Get-Content -Raw -Encoding UTF8 -LiteralPath $settingsPath | ConvertFrom-Json
if (-not $settings.enabled) {
    throw 'JY007_RENDERER_DISABLED'
}

if ($DraftId) {
    if ($DraftId -notmatch '^openvideo-[a-z0-9._-]{1,150}$') {
        throw 'JY007_DRAFT_ID_INVALID'
    }
    $draft = Get-Item -LiteralPath (Join-Path $draftRoot $DraftId) -ErrorAction Stop
} else {
    $draft = Get-ChildItem -LiteralPath $draftRoot -Directory -Filter 'openvideo-*' |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
}
if ($null -eq $draft -or -not $draft.PSIsContainer) {
    throw 'JY007_OPENVIDEO_DRAFT_MISSING'
}

$runtimeRoot = Join-Path $privateRoot ('jy007-spike-' + [guid]::NewGuid().ToString('N'))
$outputPath = Join-Path $runtimeRoot 'preview.mp4'
[void](New-Item -ItemType Directory -Path $runtimeRoot)
try {
    $manifest = @{
        schema_version = 1
        draft_path = $draft.FullName
        executable_path = [string]$settings.executable_path
        executable_sha256 = [string]$settings.executable_sha256
        output_path = $outputPath
        timeout_ms = $TimeoutMs
    } | ConvertTo-Json -Compress
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $python
    $startInfo.Arguments = '"' + $workerPath.Replace('"', '\"') + '"'
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    [void]$process.Start()
    $process.StandardInput.Write($manifest)
    $process.StandardInput.Close()
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    if ($process.ExitCode -ne 0) {
        $reason = ([string]$stderr).Trim()
        if ($reason -notmatch '^JY007_[A-Z0-9_]{1,100}$') {
            $reason = 'JY007_VISIBLE_RENDER_FAILED'
        }
        Write-Output ('JY007_REAL_SPIKE=' + $reason)
        exit 2
    }
    $result = [string]$stdout
    $parsed = $result | ConvertFrom-Json
    if (
        $parsed.schema_version -ne 1 -or
        $parsed.status -ne 'completed' -or
        $parsed.focusStealObserved -isnot [bool] -or
        -not (Test-Path -LiteralPath $outputPath -PathType Leaf)
    ) {
        throw 'JY007_RESULT_INVALID'
    }
    Write-Output ('JY007_REAL_SPIKE=PASS focus_steal=' + $parsed.focusStealObserved)
} finally {
    $resolvedRuntime = [IO.Path]::GetFullPath($runtimeRoot)
    $allowedPrefix = [IO.Path]::GetFullPath($privateRoot).TrimEnd('\') + '\'
    if ($resolvedRuntime.StartsWith($allowedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        Remove-Item -LiteralPath $resolvedRuntime -Recurse -Force -ErrorAction SilentlyContinue
    }
}
