import { execFile } from 'node:child_process'
import { once } from 'node:events'
import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { createServer as createNetServer } from 'node:net'
import { isAbsolute, resolve } from 'node:path'
import { promisify } from 'node:util'

import { loadGatewayConfig } from '../apps/gateway/src/config.mjs'
import { createGateway } from '../apps/gateway/src/gateway.mjs'
import { createJsonRepositories } from '../apps/gateway/src/local-runtime.mjs'
import { createPermissiveMaterialAnalyzer } from '../apps/gateway/src/permissive-material-analyzer.mjs'
import { runShortVideoFactoryElectronBridge } from '../apps/gateway/src/short-video-factory-electron-bridge.mjs'
import { createShortVideoFactoryProvider } from '../apps/gateway/src/short-video-factory-provider.mjs'
import { startGatewayServer } from '../apps/gateway/src/server.mjs'
import { createWorkbenchJobCoordinator } from '../apps/gateway/src/workbench-job-coordinator.mjs'
import {
  createEditPlanRepository,
  createWorkbenchJobRepository,
} from '../apps/gateway/src/workbench-job-repository.mjs'

const execFileAsync = promisify(execFile)
const dataRoot = process.argv[2]
const upstreamRoot = process.argv[3]
const voice = process.argv[4]
if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('VID002_RUNTIME_ROOT_INVALID')
if (!upstreamRoot || !isAbsolute(upstreamRoot)) throw new Error('VID002_UPSTREAM_ROOT_INVALID')
if (!voice || voice.includes('/') || voice.includes('\\')) throw new Error('VID002_VOICE_INVALID')

const privateProvider = JSON.parse(await readFile(resolve(dataRoot, 'gateway/provider.json'), 'utf8'))
if (
  privateProvider?.schema_version !== 1 ||
  privateProvider?.provider !== 'openai-compatible' ||
  typeof privateProvider.base_url !== 'string' ||
  typeof privateProvider.api_key !== 'string' ||
  typeof privateProvider.text_model !== 'string' ||
  typeof privateProvider.vision_model !== 'string' ||
  typeof privateProvider.json_model !== 'string'
) throw new Error('VID002_GATEWAY_CONFIG_INVALID')
process.env.OPENVIDEO_LLM_PROVIDER = privateProvider.provider
process.env.OPENVIDEO_LLM_BASE_URL = privateProvider.base_url
process.env.OPENVIDEO_LLM_API_KEY = privateProvider.api_key
process.env.OPENVIDEO_LLM_TEXT_MODEL = privateProvider.text_model
process.env.OPENVIDEO_LLM_VISION_MODEL = privateProvider.vision_model
process.env.OPENVIDEO_LLM_JSON_MODEL = privateProvider.json_model

const repositories = await createJsonRepositories({ dataRoot })
const authorization = repositories.authorizationRepository
  .list()
  .filter((record) => record.status === 'authorized' && record.readOnly === true && record.total >= 1)
  .sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))[0]
if (!authorization) throw new Error('VID002_AUTHORIZATION_NOT_FOUND')
const originalProject = repositories.projectRepository.get(authorization.projectId)
if (
  !originalProject ||
  originalProject.materials?.authorizationId !== authorization.id ||
  originalProject.materials?.authorized !== true
) throw new Error('VID002_PROJECT_BINDING_INVALID')

const logEvent = (event) => console.error(JSON.stringify(event))
const gateway = createGateway({ config: loadGatewayConfig(), logger: logEvent })
const analyzer = await createPermissiveMaterialAnalyzer({
  dataRoot,
  authorizationRepository: repositories.authorizationRepository,
  gateway,
})
if (!analyzer.getStatus().available) throw new Error('VID002_ANALYZER_UNAVAILABLE')
await analyzer.restoreAnalysis({
  projectId: authorization.projectId,
  authorizationId: authorization.id,
})

const evidenceRoot = resolve(dataRoot, 'evidence/vid-002')
await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
const bgmPath = resolve(evidenceRoot, 'acceptance-bgm.mp3')
const ffmpegPath = resolve(upstreamRoot, 'node_modules/ffmpeg-static/ffmpeg.exe')
const ffprobePath = resolve(dataRoot, 'material-analysis/dependencies/ffmpeg/bin/ffprobe.exe')
const manifest = JSON.parse(await readFile(
  new URL('../config/short-video-factory-upstream.json', import.meta.url),
  'utf8',
))
await createShortVideoFactoryProvider({
  dataRoot,
  upstreamRoot,
  manifest,
  bridge: runShortVideoFactoryElectronBridge,
  voice,
})
await execFileAsync(ffmpegPath, [
  '-y',
  '-hide_banner',
  '-loglevel',
  'error',
  '-f',
  'lavfi',
  '-i',
  'sine=frequency=220:sample_rate=48000:duration=20',
  '-filter:a',
  'volume=0.08',
  bgmPath,
], { windowsHide: true, timeout: 60_000 })

const acceptanceBridgeTimeoutMs = 15 * 60_000
const previewProvider = await createShortVideoFactoryProvider({
  dataRoot,
  upstreamRoot,
  manifest,
  bridge: (input) => runShortVideoFactoryElectronBridge({
    ...input,
    timeoutMs: acceptanceBridgeTimeoutMs,
  }),
  voice,
  voiceRate: 0,
  bgmPath,
})
if (!previewProvider.getStatus().available) throw new Error('VID002_PROVIDER_UNAVAILABLE')

const scriptSentences = [
  '展示产品外观和材质细节。',
  '人物在室内自然使用产品。',
  '最后给出完整产品展示。',
]
const nonce = Date.now().toString(36)
const planId = `vid002-real-storyboard-${nonce}`
const storyboardSentences = []
const privatePlanItems = []
const selectedCandidateIds = new Set()
for (let index = 0; index < scriptSentences.length; index += 1) {
  const text = scriptSentences[index]
  const candidates = await analyzer.searchCandidates({
    projectId: authorization.projectId,
    authorizationId: authorization.id,
    query: text,
  })
  const selected = candidates.find((candidate) => !selectedCandidateIds.has(candidate.id))
  if (!selected) throw new Error('VID002_CANDIDATE_NOT_FOUND')
  selectedCandidateIds.add(selected.id)
  storyboardSentences.push({
    id: `vid002-sentence-${index + 1}`,
    order: index + 1,
    text,
    selectedCandidateId: selected.id,
    status: 'selected',
    candidates: [{
      id: selected.id,
      assetLabel: selected.assetLabel,
      start: selected.start,
      end: selected.end,
      summary: selected.summary,
      matchScore: selected.matchScore,
      reason: selected.reason,
    }],
  })
  privatePlanItems.push({
    sentence_id: `vid002-sentence-${index + 1}`,
    order: index + 1,
    voiceover_text: text,
    status: 'selected',
    selected_candidate_id: selected.id,
    candidates: [{
      candidate_id: selected.id,
      asset_id: selected.assetId,
      scene_id: selected.id,
      source: 'material_analysis',
      start: selected.start,
      end: selected.end,
      summary: selected.summary,
      tags: [],
      search_score: selected.matchScore,
      director_score: selected.matchScore,
      reason: selected.reason,
    }],
  })
}
const acceptanceProject = {
  ...structuredClone(originalProject),
  brief: {
    theme: '真实素材正式预览',
    title: 'short-video-factory 正式预览验收',
    sellingPoints: ['真实素材', '可恢复任务'],
    script: scriptSentences.join(''),
    style: '自然、清晰、节奏稳定',
    durationSeconds: 20,
    orientation: 'portrait',
    voiceover: 'required',
    captions: 'auto',
    savedAt: new Date().toISOString(),
  },
  storyboard: {
    id: planId,
    title: 'short-video-factory 正式预览验收',
    updatedAt: new Date().toISOString(),
    sentences: storyboardSentences,
  },
  preview: {
    status: 'not_started',
    resourceId: null,
    durationSeconds: null,
    updatedAt: null,
  },
  currentStage: 'storyboard',
  updatedAt: new Date().toISOString(),
}
repositories.projectRepository.save(acceptanceProject)

const jobRepository = await createWorkbenchJobRepository({ dataRoot })
const editPlanRepository = await createEditPlanRepository({ dataRoot })
const privatePlanIdentity = {
  projectId: authorization.projectId,
  jobId: `vid002-private-plan-${nonce}`,
  fingerprint: 'a'.repeat(64),
  generation: 1,
}
const privatePlanTimestamp = new Date().toISOString()
await editPlanRepository.draft({
  ...privatePlanIdentity,
  draft: { sentences: scriptSentences },
  updatedAt: privatePlanTimestamp,
})
await editPlanRepository.candidates({
  ...privatePlanIdentity,
  candidates: [],
  updatedAt: privatePlanTimestamp,
})
await editPlanRepository.finalize({
  ...privatePlanIdentity,
  final: {
    schema_version: 1,
    plan_id: planId,
    project_id: authorization.projectId,
    created_at: privatePlanTimestamp,
    items: privatePlanItems,
  },
  updatedAt: privatePlanTimestamp,
})
const director = {
  async segmentScript() {
    throw new Error('VID002_DIRECTOR_NOT_EXPECTED')
  },
  async rankCandidates() {
    throw new Error('VID002_DIRECTOR_NOT_EXPECTED')
  },
}
const acceptanceJobTimeoutMs = acceptanceBridgeTimeoutMs + 60_000
const createCoordinator = (ownerId) => createWorkbenchJobCoordinator({
  jobRepository,
  editPlanRepository,
  projectRepository: repositories.projectRepository,
  materialAnalysisProvider: analyzer,
  director,
  previewProvider,
  ownerId,
  concurrency: 1,
  leaseDurationMs: 30_000,
  heartbeatIntervalMs: 10_000,
  jobTimeoutMs: acceptanceJobTimeoutMs,
  logger: logEvent,
})
const waitFor = async (
  coordinator,
  jobId,
  accepted,
  timeoutMs = acceptanceJobTimeoutMs + 5_000,
  minimumProgress = 0,
) => {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const job = await coordinator.getJob(authorization.projectId, jobId)
    if (job && accepted.includes(job.status) && job.progressPercent >= minimumProgress) return job
    await new Promise((resolveDelay) => setTimeout(resolveDelay, 100))
  }
  throw new Error('VID002_JOB_POLL_TIMEOUT')
}
const reserveLoopbackPort = async () => {
  const probe = createNetServer()
  probe.listen(0, '127.0.0.1')
  await once(probe, 'listening')
  const address = probe.address()
  if (!address || typeof address === 'string') throw new Error('VID002_PORT_RESERVATION_FAILED')
  const port = address.port
  const closed = once(probe, 'close')
  probe.close()
  await closed
  return port
}

let coordinator = createCoordinator('vid002-real-first')
let restartedGateway = null
/** @type {string[]} */
const generatedResources = []
try {
  await coordinator.start()
  const previewJob = await coordinator.createJob({
    projectId: authorization.projectId,
    type: 'preview_generation',
    idempotencyKey: `vid002-preview-${nonce}`,
  })
  const previewResult = await waitFor(
    coordinator,
    previewJob.jobId,
    ['succeeded', 'failed', 'cancelled', 'timed_out'],
  )
  if (previewResult.status !== 'succeeded') {
    console.error(JSON.stringify({ previewResult }))
    throw new Error('VID002_REAL_PREVIEW_JOB_FAILED')
  }
  generatedResources.push(previewResult.result.resourceId)
  const resource = await previewProvider.getResource({
    projectId: authorization.projectId,
    resourceId: previewResult.result.resourceId,
  })
  const resourceBytes = resource
    ? Buffer.from(await new Response(resource.createStream({
        start: 0,
        end: resource.size - 1,
      })).arrayBuffer())
    : null
  if (
    !resource ||
    !resourceBytes ||
    resource.contentType !== 'video/mp4' ||
    resource.size !== resourceBytes.length ||
    resourceBytes.length < 100_000 ||
    !resourceBytes.subarray(0, 64).includes(Buffer.from('ftyp'))
  ) throw new Error('VID002_REAL_PREVIEW_RESOURCE_INVALID')
  const validationPath = resolve(evidenceRoot, `preview-validation-${nonce}.mp4`)
  await writeFile(validationPath, resourceBytes, { mode: 0o600 })
  try {
    await execFileAsync(ffmpegPath, [
      '-v',
      'error',
      '-i',
      validationPath,
      '-map',
      '0:v:0',
      '-map',
      '0:a:0',
      '-f',
      'null',
      'NUL',
    ], { windowsHide: true, timeout: 120_000 })
  } finally {
    await rm(validationPath, { force: true })
  }
  const storedPreview = await jobRepository.get(authorization.projectId, previewJob.jobId)
  if (
    storedPreview.checkpoint?.stage !== 'preview_published' ||
    storedPreview.checkpoint?.data?.features?.voiceover !== true ||
    storedPreview.checkpoint?.data?.features?.captions !== true ||
    storedPreview.checkpoint?.data?.features?.bgm !== true
  ) throw new Error('VID002_REAL_PREVIEW_FEATURES_MISSING')

  await coordinator.stop()
  coordinator = createCoordinator('vid002-real-restart')
  await coordinator.start()
  const recovered = await coordinator.getJob(authorization.projectId, previewJob.jobId)
  const recoveredResource = await previewProvider.getResource({
    projectId: authorization.projectId,
    resourceId: previewResult.result.resourceId,
  })
  if (recovered?.status !== 'succeeded' || !recoveredResource) {
    throw new Error('VID002_REAL_PREVIEW_RECOVERY_FAILED')
  }

  await coordinator.stop()
  const gatewayEnvironment = {
    ...process.env,
    OPENVIDEO_RUNTIME_DATA_ROOT: dataRoot,
    OPENVIDEO_SHORT_VIDEO_FACTORY_ROOT: upstreamRoot,
    OPENVIDEO_SHORT_VIDEO_FACTORY_VOICE: voice,
    OPENVIDEO_SHORT_VIDEO_FACTORY_VOICE_RATE: '0',
    OPENVIDEO_SHORT_VIDEO_FACTORY_BGM_PATH: bgmPath,
    OPENVIDEO_WORKBENCH_MODE: 'production',
  }
  /** @param {number} port @param {string} localApiToken */
  const trustedHeadersFor = (port, localApiToken) => ({
    origin: `http://127.0.0.1:${port}`,
    'sec-fetch-site': 'same-origin',
    'x-openvideo-local-token': localApiToken,
  })
  const firstPort = await reserveLoopbackPort()
  let firstGateway = null
  let finalizeResponse
  try {
    firstGateway = await startGatewayServer({
      environment: {
        ...gatewayEnvironment,
        OPENVIDEO_GATEWAY_PORT: String(firstPort),
      },
      log: () => {},
      warn: logEvent,
    })
    const localApiToken = JSON.parse(
      await readFile(resolve(dataRoot, 'local-api-token.json'), 'utf8'),
    ).token
    if (typeof localApiToken !== 'string' || !/^[a-f0-9]{64}$/u.test(localApiToken)) {
      throw new Error('VID002_LOCAL_API_TOKEN_INVALID')
    }
    finalizeResponse = await fetch(
      `http://127.0.0.1:${firstPort}/api/workbench/projects/${authorization.projectId}/delivery/finalize`,
      {
        method: 'POST',
        headers: { ...trustedHeadersFor(firstPort, localApiToken), 'content-type': 'application/json' },
        body: '{}',
      },
    )
  } finally {
    await firstGateway?.stop()
  }
  if (finalizeResponse.status !== 200) {
    throw new Error('VID002_WORKBENCH_FINALIZE_FAILED')
  }
  const finalizedProject = await finalizeResponse.json()
  const finalVideo = finalizedProject.delivery?.finalVideo
  if (
    finalVideo?.resourceId === previewResult.result.resourceId ||
    !/^final-[a-f0-9]{32}$/u.test(finalVideo?.resourceId ?? '')
  ) throw new Error('VID002_FINAL_RESOURCE_ID_INVALID')
  generatedResources.push(finalVideo.resourceId)

  const restartPort = await reserveLoopbackPort()
  restartedGateway = await startGatewayServer({
    environment: {
      ...gatewayEnvironment,
      OPENVIDEO_GATEWAY_PORT: String(restartPort),
    },
    log: () => {},
    warn: logEvent,
  })
  coordinator = restartedGateway.jobCoordinator
  const finalContentUrl =
    `http://127.0.0.1:${restartPort}/api/workbench/projects/${authorization.projectId}/final/content`
  const persistedLocalApiToken = JSON.parse(
    await readFile(resolve(dataRoot, 'local-api-token.json'), 'utf8'),
  ).token
  const trustedHeaders = trustedHeadersFor(restartPort, persistedLocalApiToken)
  const untrustedResponse = await fetch(finalContentUrl, {
    headers: { origin: 'https://attacker.example', 'sec-fetch-site': 'cross-site' },
  })
  const headResponse = await fetch(finalContentUrl, {
    method: 'HEAD',
    headers: trustedHeaders,
  })
  const rangeResponse = await fetch(finalContentUrl, {
    headers: { ...trustedHeaders, range: 'bytes=0-1023' },
  })
  const downloadResponse = await fetch(finalContentUrl, { headers: trustedHeaders })
  if (
    untrustedResponse.status !== 403 ||
    headResponse.status !== 200 ||
    rangeResponse.status !== 206 ||
    downloadResponse.status !== 200 ||
    downloadResponse.headers.get('content-disposition') !==
      'attachment; filename="openvideo-final.mp4"' ||
    downloadResponse.headers.get('cross-origin-resource-policy') !== 'same-origin' ||
    !rangeResponse.headers.get('content-range')?.startsWith('bytes 0-1023/')
  ) throw new Error('VID002_FINAL_DOWNLOAD_BOUNDARY_INVALID')
  const persistedFinal = {
    bytes: Buffer.from(await downloadResponse.arrayBuffer()),
    contentType: downloadResponse.headers.get('content-type'),
  }

  await previewProvider.deleteResource({
    projectId: authorization.projectId,
    resourceId: previewResult.result.resourceId,
  })
  const deletedPreview = await previewProvider.getResource({
    projectId: authorization.projectId,
    resourceId: previewResult.result.resourceId,
  })
  const persistedDownload = await fetch(finalContentUrl, { headers: trustedHeaders })
  if (
    deletedPreview !== null ||
    persistedDownload.status !== 200 ||
    persistedFinal.contentType !== 'video/mp4' ||
    persistedFinal.bytes.length < 100_000
  ) {
    throw new Error('VID002_FINAL_RESOURCE_PERSISTENCE_FAILED')
  }
  const finalValidationPath = resolve(evidenceRoot, `final-validation-${nonce}.mp4`)
  await writeFile(finalValidationPath, persistedFinal.bytes, { mode: 0o600 })
  let mediaProbe
  try {
    const { stdout } = await execFileAsync(ffprobePath, [
      '-v',
      'error',
      '-show_streams',
      '-show_format',
      '-of',
      'json',
      finalValidationPath,
    ], { windowsHide: true, timeout: 120_000 })
    mediaProbe = JSON.parse(stdout)
  } finally {
    await rm(finalValidationPath, { force: true })
  }
  const videoStream = mediaProbe.streams?.find((stream) => stream.codec_type === 'video')
  const audioStream = mediaProbe.streams?.find((stream) => stream.codec_type === 'audio')
  const probedDuration = Number(mediaProbe.format?.duration)
  if (
    !String(mediaProbe.format?.format_name ?? '').includes('mp4') ||
    !videoStream ||
    !audioStream ||
    !Number.isFinite(probedDuration) ||
    probedDuration <= 0 ||
    Math.abs(probedDuration - previewResult.result.durationSeconds) > 1
  ) throw new Error('VID002_FINAL_MEDIA_VALIDATION_FAILED')

  const cancelJob = await coordinator.createJob({
    projectId: authorization.projectId,
    type: 'preview_generation',
    idempotencyKey: `vid002-cancel-${nonce}`,
  })
  const running = await waitFor(
    coordinator,
    cancelJob.jobId,
    ['running', 'succeeded'],
    60_000,
    20,
  )
  let cancelled = running
  if (running.status === 'running') {
    await coordinator.cancelJob(authorization.projectId, cancelJob.jobId)
    cancelled = await waitFor(
      coordinator,
      cancelJob.jobId,
      ['cancelled', 'failed', 'timed_out', 'succeeded'],
      60_000,
    )
  }
  if (cancelled.status !== 'cancelled') throw new Error('VID002_REAL_CANCEL_FAILED')
  const workEntries = await readdir(resolve(dataRoot, 'short-video-factory/work'))
  if (workEntries.length !== 0) throw new Error('VID002_TEMPORARY_FILES_REMAIN')

  const publicPayload = JSON.stringify({ previewResult, recovered, project: repositories.projectRepository.get(authorization.projectId) }).toLowerCase()
  for (const forbidden of [
    authorization.absolutePath.toLowerCase(),
    upstreamRoot.toLowerCase(),
    privateProvider.api_key.toLowerCase(),
    'privateinput',
    'sourcepath',
    'bgmpath',
    'file://',
  ]) {
    if (publicPayload.includes(forbidden)) throw new Error('VID002_PUBLIC_RESPONSE_LEAK')
  }

  const evidence = {
    schema_version: 1,
    completed_at: new Date().toISOString(),
    provider: 'short-video-factory',
    upstream_commit: manifest.commit,
    license: manifest.license,
    preview_job_status: previewResult.status,
    restart_recovery: true,
    cancellation_status: cancelled.status,
    voiceover: true,
    captions: true,
    bgm: true,
    preview_bytes: resourceBytes.length,
    final_resource_distinct: true,
    final_resource_persisted_after_preview_delete: true,
    final_resource_id_safe: true,
    final_container: 'mp4',
    final_video_stream_verified: true,
    final_audio_stream_verified: true,
    final_duration_seconds: probedDuration,
    media_decode_verified: true,
    audio_stream_verified: true,
    public_response_leak_count: 0,
    temporary_file_count: 0,
  }
  await writeFile(
    resolve(evidenceRoot, 'acceptance.json'),
    `${JSON.stringify(evidence, null, 2)}\n`,
    { encoding: 'utf8', mode: 0o600 },
  )
  console.log(JSON.stringify(evidence))
} finally {
  if (restartedGateway) await restartedGateway.stop().catch(() => {})
  else await coordinator.stop().catch(() => {})
  repositories.projectRepository.save(originalProject)
  for (const resourceId of generatedResources) {
    await previewProvider.deleteResource({
      projectId: authorization.projectId,
      resourceId,
    }).catch(() => {})
  }
  await rm(bgmPath, { force: true })
}
