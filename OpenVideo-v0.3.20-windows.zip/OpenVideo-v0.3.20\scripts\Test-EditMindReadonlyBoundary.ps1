[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [string]$UpstreamRoot,
    [string]$TestRoot = (Join-Path ([IO.Path]::GetTempPath()) ("openvideo-em001-" + [guid]::NewGuid().ToString('N'))),
    [switch]$Docker,
    [string]$EvidenceRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
if (-not $RepositoryRoot) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
if (-not $UpstreamRoot) { $UpstreamRoot = Join-Path $RepositoryRoot 'upstream/edit-mind' }
$pathComparison = if ($env:OS -eq 'Windows_NT') { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Get-FixtureSnapshot {
    param([string]$Root)
    return @(Get-ChildItem -LiteralPath $Root -File -Recurse | Sort-Object FullName | ForEach-Object {
        [pscustomobject]@{
            Name = $_.FullName.Substring($Root.Length).TrimStart([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
            Length = $_.Length
            LastWriteTimeUtc = $_.LastWriteTimeUtc.ToString('O')
            Sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
        }
    })
}

function Assert-SnapshotEqual {
    param($Before, $After)
    $beforeJson = $Before | ConvertTo-Json -Depth 4 -Compress
    $afterJson = $After | ConvertTo-Json -Depth 4 -Compress
    Assert-True ($beforeJson -ceq $afterJson) 'Material fixture count, names, sizes, mtimes, or SHA256 changed.'
}

function Get-EnvironmentKeyEvidence {
    param($Environment)
    if ($null -eq $Environment) { return @() }
    if ($Environment -is [Array]) {
        return @($Environment | ForEach-Object {
            $entry = [string]$_
            $separatorIndex = $entry.IndexOf('=')
            if ($separatorIndex -le 0) { throw 'Compose environment array contains an invalid entry.' }
            $entry.Substring(0, $separatorIndex)
        } | Sort-Object -Unique)
    }
    if ($Environment -is [Collections.IDictionary] -or $Environment -is [pscustomobject]) {
        return @($Environment.PSObject.Properties.Name | Sort-Object -Unique)
    }
    throw "Unsupported Compose environment representation: $($Environment.GetType().FullName)"
}

function Invoke-ComposeJson {
    param([string]$ComposePath, $Runtime, [string]$OutputPath)
    $previousMaterialRoot = $env:OPENVIDEO_MATERIAL_ROOT
    $previousRuntimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
    $env:OPENVIDEO_MATERIAL_ROOT = $Runtime.MaterialRoot
    $env:OPENVIDEO_RUNTIME_DATA_ROOT = $Runtime.RuntimeDataRoot
    try {
        $json = & docker compose --env-file $Runtime.ComposeEnvironmentPath -f $ComposePath -f (Join-Path $RepositoryRoot 'deploy/edit-mind/docker-compose.readonly.yml') config --format json
        if ($LASTEXITCODE -ne 0) { throw "Compose rendering failed for $ComposePath" }
        $jsonText = $json -join [Environment]::NewLine
        $compose = $jsonText | ConvertFrom-Json
        $evidence = [ordered]@{
            compose_file = [IO.Path]::GetFileName($ComposePath)
            services = [ordered]@{}
        }
        foreach ($serviceName in @($compose.services.PSObject.Properties.Name | Sort-Object)) {
            $service = $compose.services.$serviceName
            $mountEvidence = @()
            foreach ($mount in @($service.volumes)) {
                $sourceClass = if ($mount.target -eq '/media/videos') {
                    '<MATERIAL_ROOT>'
                } else {
                    $sourcePath = [IO.Path]::GetFullPath([string]$mount.source)
                    $runtimeRootPath = $Runtime.RuntimeDataRoot.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar))
                    $runtimePrefix = $runtimeRootPath + [IO.Path]::DirectorySeparatorChar
                    if (-not $sourcePath.StartsWith($runtimePrefix, $pathComparison)) {
                        throw "Compose mount target $($mount.target) is outside the runtime data root."
                    }
                    $relativeSource = $sourcePath.Substring($runtimePrefix.Length).Replace([IO.Path]::DirectorySeparatorChar, '/')
                    '<RUNTIME_DATA_ROOT>/' + $relativeSource
                }
                $mountEvidence += [ordered]@{
                    source = $sourceClass
                    target = [string]$mount.target
                    type = [string]$mount.type
                    read_only = if ($mount.PSObject.Properties.Name -contains 'read_only') { [bool]$mount.read_only } else { $false }
                }
            }
            $environmentKeys = Get-EnvironmentKeyEvidence $service.environment
            $evidence.services[$serviceName] = [ordered]@{
                environment_keys = $environmentKeys
                volumes = $mountEvidence
            }
        }
        [IO.File]::WriteAllText($OutputPath, ($evidence | ConvertTo-Json -Depth 8), $utf8)
        return $compose
    } finally {
        $env:OPENVIDEO_MATERIAL_ROOT = $previousMaterialRoot
        $env:OPENVIDEO_RUNTIME_DATA_ROOT = $previousRuntimeRoot
    }
}

function Assert-RenderedCompose {
    param($Compose, $Runtime)
    foreach ($serviceName in @('background-jobs','web','ml')) {
        $mounts = @($Compose.services.$serviceName.volumes | Where-Object { $_.target -eq '/media/videos' })
        Assert-True ($mounts.Count -eq 1) "$serviceName must have exactly one /media/videos mount."
        Assert-True ([bool]$mounts[0].read_only) "$serviceName /media/videos mount must be read-only."
        Assert-True ($mounts[0].type -eq 'bind') "$serviceName /media/videos mount must be a bind mount."
    }
    foreach ($variableName in @('YOLO_CONFIG_DIR','DEEPFACE_HOME','TRANSCRIPTION_MODEL_CACHE','TORCH_HOME','HF_HOME')) {
        $modelPath = [string]$Compose.services.ml.environment.$variableName
        Assert-True ($modelPath.StartsWith('/ml-models/', [StringComparison]::Ordinal)) "ml environment $variableName does not use /ml-models."
    }
    foreach ($serviceName in @('background-jobs','web','ml','postgres','redis','chroma')) {
        foreach ($mount in @($Compose.services.$serviceName.volumes | Where-Object { $_.target -ne '/media/videos' })) {
            Assert-True ($mount.type -eq 'bind') "$serviceName runtime storage must use bind mounts."
            $source = [IO.Path]::GetFullPath([string]$mount.source)
            $runtimePrefix = $Runtime.RuntimeDataRoot.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)) + [IO.Path]::DirectorySeparatorChar
            Assert-True ($source.StartsWith($runtimePrefix, [StringComparison]::Ordinal)) "$serviceName writes outside RuntimeDataRoot: $source"
        }
    }
}

function Wait-ContainerHealth {
    param([string]$ContainerName, [int]$TimeoutSeconds = 120)
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    do {
        $status = (& docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' $ContainerName 2>$null).Trim()
        if ($status -eq 'healthy' -or $status -eq 'running') { return $status }
        if ($status -eq 'unhealthy' -or $status -eq 'exited' -or $status -eq 'dead') { throw "$ContainerName entered $status state" }
        Start-Sleep -Seconds 2
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "$ContainerName did not become healthy within $TimeoutSeconds seconds"
}

function Wait-HttpHealth {
    param([string]$Uri, [int]$TimeoutSeconds = 120)
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    do {
        try {
            $response = Invoke-WebRequest -Uri $Uri -UseBasicParsing -TimeoutSec 10
            if ($response.StatusCode -ge 200 -and $response.StatusCode -lt 300) { return "http-$($response.StatusCode)" }
        } catch {}
        Start-Sleep -Seconds 2
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "$Uri did not return a successful health response within $TimeoutSeconds seconds"
}

function Wait-TcpHealth {
    param([string]$HostName, [int]$Port, [int]$TimeoutSeconds = 120)
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    do {
        $client = New-Object Net.Sockets.TcpClient
        try {
            $connection = $client.BeginConnect($HostName, $Port, $null, $null)
            if ($connection.AsyncWaitHandle.WaitOne(2000) -and $client.Connected) { return 'tcp-connected' }
        } catch {} finally { $client.Dispose() }
        Start-Sleep -Seconds 2
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "${HostName}:$Port did not accept TCP connections within $TimeoutSeconds seconds"
}

$materialRoot = Join-Path $TestRoot 'material-fixture'
$runtimeRoot = Join-Path $TestRoot 'runtime-data'
if (-not $EvidenceRoot) { $EvidenceRoot = Join-Path $TestRoot 'evidence' }
New-Item -ItemType Directory -Path $materialRoot,$EvidenceRoot -Force | Out-Null
[IO.File]::WriteAllText((Join-Path $materialRoot 'clip-a.txt'), 'synthetic fixture alpha', $utf8)
[IO.File]::WriteAllText((Join-Path $materialRoot 'clip-b.txt'), 'synthetic fixture beta', $utf8)
$before = Get-FixtureSnapshot $materialRoot

$arrayEnvironmentEvidence = Get-EnvironmentKeyEvidence @('SAFE_KEY=value','SECOND_KEY=another=value')
Assert-True (($arrayEnvironmentEvidence -join ',') -eq 'SAFE_KEY,SECOND_KEY') 'Environment evidence leaked array-form values.'
$invalidEnvironmentRejected = $false
try { Get-EnvironmentKeyEvidence @('INVALID_ENTRY') | Out-Null } catch { $invalidEnvironmentRejected = $true }
Assert-True $invalidEnvironmentRejected 'Environment evidence accepted an entry without a key/value separator.'

try {
    $runtime = & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -PassThru
    $pin = Get-Content -LiteralPath (Join-Path $RepositoryRoot 'config/edit-mind-upstream.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $actualUpstreamSha = (& git -C $UpstreamRoot rev-parse HEAD).Trim()
    Assert-True ($LASTEXITCODE -eq 0 -and $actualUpstreamSha -eq $pin.commit) "Upstream checkout is not pinned to $($pin.commit)."
    foreach ($relativeDirectory in @('database/postgres','indexes/chroma','cache/redis','models','logs','tmp','app-data','config')) {
        Assert-True (Test-Path -LiteralPath (Join-Path $runtime.RuntimeDataRoot $relativeDirectory) -PathType Container) "Missing runtime directory: $relativeDirectory"
    }
    if ($env:OS -eq 'Windows_NT') {
        $runtimeAcl = Get-Acl -LiteralPath $runtime.RuntimeDataRoot
        $allowedSids = @(
            [Security.Principal.WindowsIdentity]::GetCurrent().User.Value,
            'S-1-5-18',
            'S-1-5-32-544'
        )
        $runtimeSids = @($runtimeAcl.Access | ForEach-Object {
            $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
        } | Sort-Object -Unique)
        Assert-True $runtimeAcl.AreAccessRulesProtected 'Runtime root must disable inherited access rules before secrets are written.'
        Assert-True ($runtimeSids.Count -eq $allowedSids.Count) 'Runtime root ACL contains an unexpected principal.'
        Assert-True (@($runtimeSids | Where-Object { $allowedSids -notcontains $_ }).Count -eq 0) 'Runtime root ACL is broader than the private principal set.'
    }
    $repeatedRuntime = & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -PassThru
    Assert-True ($repeatedRuntime.RuntimeDataRoot -eq $runtime.RuntimeDataRoot) 'Runtime ACL initialization is not idempotent.'
    $composeEnvironment = Get-Content -LiteralPath $runtime.ComposeEnvironmentPath -Encoding UTF8
    Assert-True ($composeEnvironment -contains 'USE_OLLAMA_MODEL=true') 'Runtime must enable the private Ollama bridge.'
    Assert-True ($composeEnvironment -contains 'USE_GEMINI=false') 'Runtime must not bypass the LLM Gateway through Gemini.'
    Assert-True ($composeEnvironment -contains 'OLLAMA_HOST=http://ollama-bridge') 'Runtime must route Ollama requests to the private bridge.'
    $modelAlias = @($composeEnvironment | Where-Object { $_ -match '^OPENVIDEO_OLLAMA_MODEL_ALIAS=' })
    Assert-True ($modelAlias.Count -eq 1) 'Runtime must generate one opaque Ollama model alias.'
    Assert-True ($composeEnvironment -contains ('OLLAMA_MODEL=' + $modelAlias[0].Substring('OPENVIDEO_OLLAMA_MODEL_ALIAS='.Length))) 'Edit Mind and the bridge must use the same model alias.'
    $legacyRuntimeRoot = Join-Path $TestRoot 'legacy-runtime'
    $legacyConfigRoot = Join-Path $legacyRuntimeRoot 'config'
    New-Item -ItemType Directory -Path $legacyConfigRoot -Force | Out-Null
    $legacyEnvironment = @($composeEnvironment | Where-Object { $_ -notmatch '^(?:USE_OLLAMA_MODEL|OLLAMA_HOST|OLLAMA_PORT|OLLAMA_MODEL|OPENVIDEO_OLLAMA_MODEL_ALIAS)=' })
    $legacyEnvironment += 'USE_OLLAMA_MODEL=false'
    [IO.File]::WriteAllLines((Join-Path $legacyConfigRoot 'compose.env'), $legacyEnvironment, $utf8)
    $legacyRuntime = & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $legacyRuntimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -PassThru
    $migratedEnvironment = Get-Content -LiteralPath $legacyRuntime.ComposeEnvironmentPath -Encoding UTF8
    Assert-True ($migratedEnvironment -contains 'USE_OLLAMA_MODEL=true') 'Legacy runtime must migrate from disabled Ollama mode.'
    Assert-True ($migratedEnvironment -contains 'OLLAMA_HOST=http://ollama-bridge') 'Legacy runtime migration must add the private bridge host.'
    Assert-True (@($migratedEnvironment | Where-Object { $_ -match '^OPENVIDEO_OLLAMA_MODEL_ALIAS=ov-' }).Count -eq 1) 'Legacy runtime migration must add one opaque bridge alias.'
    $duplicateRuntimeRoot = Join-Path $TestRoot 'duplicate-runtime'
    $duplicateConfigRoot = Join-Path $duplicateRuntimeRoot 'config'
    New-Item -ItemType Directory -Path $duplicateConfigRoot -Force | Out-Null
    [IO.File]::WriteAllLines((Join-Path $duplicateConfigRoot 'compose.env'), @($composeEnvironment + 'USE_GEMINI=false'), $utf8)
    $duplicateSettingRejected = $false
    try {
        & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $duplicateRuntimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null
    } catch {
        $duplicateSettingRejected = $_.Exception.Message -match 'duplicate USE_GEMINI'
    }
    Assert-True $duplicateSettingRejected 'Runtime migration accepted a duplicate bridge setting.'
    foreach ($invalidPort in @('00000','99999')) {
        $invalidPortRuntimeRoot = Join-Path $TestRoot "invalid-port-$invalidPort"
        $invalidPortConfigRoot = Join-Path $invalidPortRuntimeRoot 'config'
        New-Item -ItemType Directory -Path $invalidPortConfigRoot -Force | Out-Null
        $invalidPortEnvironment = @($composeEnvironment | ForEach-Object {
            if ($_ -match '^CHROMA_HOST_PORT=') { "CHROMA_HOST_PORT=$invalidPort" } else { $_ }
        })
        [IO.File]::WriteAllLines((Join-Path $invalidPortConfigRoot 'compose.env'), $invalidPortEnvironment, $utf8)
        $invalidPortRejected = $false
        try {
            & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $invalidPortRuntimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null
        } catch {
            $invalidPortRejected = $_.Exception.Message -match 'invalid CHROMA_HOST_PORT'
        }
        Assert-True $invalidPortRejected "Runtime migration accepted invalid CHROMA_HOST_PORT=$invalidPort."
    }
    $nativeResetRoot = Join-Path $TestRoot 'native-reset-runtime'
    & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $nativeResetRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null
    & (Join-Path $PSScriptRoot 'Reset-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $nativeResetRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -Force | Out-Null
    Assert-True (-not (Test-Path -LiteralPath $nativeResetRoot)) 'Native runtime reset did not remove an accessible runtime root.'

    $overrideText = Get-Content -LiteralPath (Join-Path $RepositoryRoot 'deploy/edit-mind/docker-compose.readonly.yml') -Raw -Encoding UTF8
    Assert-True ($overrideText -match '(?m)^\s+volumes: !override\s*$') 'Compose volume lists must use !override.'
    Assert-True (($overrideText | Select-String -Pattern 'target: /media/videos' -AllMatches).Matches.Count -eq 3) 'Override must define exactly three media mounts.'
    Assert-True (($overrideText | Select-String -Pattern '(?m)^\s+target: /media/videos\s*\r?\n\s+read_only: true\s*$' -AllMatches).Matches.Count -eq 3) 'Every media mount must be read-only.'
    Assert-True (($overrideText | Select-String -Pattern 'image: .+@sha256:[a-f0-9]{64}' -AllMatches).Matches.Count -eq 7) 'Every runtime image must be pinned by digest.'
    Assert-True (($overrideText | Select-String -Pattern '127\.0\.0\.1:\$\{' -AllMatches).Matches.Count -eq 6) 'Every published service port must bind only to localhost.'
    Assert-True ($overrideText -match '(?ms)ollama-bridge:.*?networks:\s+- ollama-internal\s+- bridge-egress') 'Ollama bridge must use isolated ingress and egress networks.'
    $startScriptText = Get-Content -LiteralPath (Join-Path $RepositoryRoot 'scripts/Start-EditMindReadonly.ps1') -Raw -Encoding UTF8
    Assert-True ($startScriptText -match 'remote get-url origin') 'Runtime start must verify the pinned upstream remote before Compose.'
    Assert-True ($startScriptText -match 'status --porcelain --untracked-files=all') 'Runtime start must reject dirty or untracked upstream content before Compose.'

    $sameRootRejected = $false
    try { & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $materialRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null } catch { $sameRootRejected = $true }
    Assert-True $sameRootRejected 'Initializer accepted identical material and runtime roots.'

    $nestedRootRejected = $false
    try { & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot (Join-Path $materialRoot 'runtime') -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null } catch { $nestedRootRejected = $true }
    Assert-True $nestedRootRejected 'Initializer accepted nested material and runtime roots.'

    $unsafeMountPathRejected = $false
    try { & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot (Join-Path $TestRoot 'unsafe,runtime') -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null } catch { $unsafeMountPathRejected = $true }
    Assert-True $unsafeMountPathRejected 'Initializer accepted a Docker-unsafe comma in a runtime path.'

    $repositoryRuntimeRejected = $false
    try { & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot (Join-Path $RepositoryRoot '.em001-rejected-runtime') -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null } catch { $repositoryRuntimeRejected = $true }
    Assert-True $repositoryRuntimeRejected 'Initializer accepted a runtime root inside the repository.'

    $repositoryMaterialRejected = $false
    try { & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $RepositoryRoot -RuntimeDataRoot (Join-Path $TestRoot 'repository-material-runtime') -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null } catch { $repositoryMaterialRejected = $true }
    Assert-True $repositoryMaterialRejected 'Initializer accepted the repository as a material root.'

    $linkPath = Join-Path $TestRoot 'material-link'
    try {
        New-Item -ItemType SymbolicLink -Path $linkPath -Target $materialRoot -ErrorAction Stop | Out-Null
        $linkRejected = $false
        try { & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $linkPath -RuntimeDataRoot (Join-Path $TestRoot 'linked-runtime') -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot | Out-Null } catch { $linkRejected = $true }
        Assert-True $linkRejected 'Initializer accepted a symbolic-link material boundary.'
    } catch [System.UnauthorizedAccessException] {}

    if ($Docker) {
        $composeVersionText = (& docker compose version --short).Trim().TrimStart('v')
        Assert-True ($LASTEXITCODE -eq 0) 'Docker Compose is unavailable.'
        $composeVersionMatch = [regex]::Match($composeVersionText, '^\d+\.\d+\.\d+')
        Assert-True $composeVersionMatch.Success "Unrecognized Docker Compose version: $composeVersionText"
        Assert-True ([version]$composeVersionMatch.Value -ge [version]'2.24.4') 'Docker Compose 2.24.4 or newer is required.'

        foreach ($composeName in @('docker-compose.yml','docker-compose.cuda.yml')) {
            $outputName = [IO.Path]::GetFileNameWithoutExtension($composeName) + '.evidence.json'
            $rendered = Invoke-ComposeJson -ComposePath (Join-Path $UpstreamRoot $composeName) -Runtime $runtime -OutputPath (Join-Path $EvidenceRoot $outputName)
            Assert-RenderedCompose -Compose $rendered -Runtime $runtime
        }

        & docker run --rm --mount "type=bind,src=$materialRoot,dst=/media/videos,readonly" --mount "type=bind,src=$runtimeRoot,dst=/runtime" alpine:3.20 sh -ceu 'test -r /media/videos/clip-a.txt; if touch /media/videos/new.txt 2>/dev/null; then exit 11; fi; if mv /media/videos/clip-a.txt /media/videos/renamed.txt 2>/dev/null; then exit 12; fi; if rm /media/videos/clip-b.txt 2>/dev/null; then exit 13; fi; if printf x >> /media/videos/clip-a.txt 2>/dev/null; then exit 14; fi; touch /runtime/tmp/container-write-probe'
        Assert-True ($LASTEXITCODE -eq 0) 'Container read-only boundary probe failed.'

        $previousMaterialRoot = $env:OPENVIDEO_MATERIAL_ROOT
        $previousRuntimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
        $env:OPENVIDEO_MATERIAL_ROOT = $runtime.MaterialRoot
        $env:OPENVIDEO_RUNTIME_DATA_ROOT = $runtime.RuntimeDataRoot
        $projectName = 'openvideo-em001-' + [guid]::NewGuid().ToString('N').Substring(0,12)
        $composeArguments = @('compose','--env-file',$runtime.ComposeEnvironmentPath,'--project-name',$projectName,'-f',(Join-Path $UpstreamRoot 'docker-compose.yml'),'-f',(Join-Path $RepositoryRoot 'deploy/edit-mind/docker-compose.readonly.yml'))
        try {
            & docker @composeArguments up -d
            Assert-True ($LASTEXITCODE -eq 0) 'Edit Mind CPU stack failed to start.'
            $mountEvidence = [ordered]@{}
            foreach ($serviceName in @('background-jobs','web','ml')) {
                $containerId = (& docker @composeArguments ps -q $serviceName).Trim()
                Assert-True ([bool]$containerId) "No running container found for $serviceName."
                $mountJson = & docker inspect --format '{{json .Mounts}}' $containerId
                Assert-True ($LASTEXITCODE -eq 0) "Unable to inspect $serviceName mounts."
                $mediaMounts = @(($mountJson | ConvertFrom-Json) | Where-Object { $_.Destination -eq '/media/videos' })
                Assert-True ($mediaMounts.Count -eq 1) "$serviceName must have exactly one runtime /media/videos mount."
                Assert-True (-not [bool]$mediaMounts[0].RW) "$serviceName runtime /media/videos mount is writable."
                $mountEvidence[$serviceName] = [ordered]@{ destination = '/media/videos'; read_only = $true; type = $mediaMounts[0].Type }
            }
            [IO.File]::WriteAllText((Join-Path $EvidenceRoot 'runtime-mounts.json'), ($mountEvidence | ConvertTo-Json -Depth 5), $utf8)
            $healthEvidence = [ordered]@{
                postgres = Wait-ContainerHealth ((& docker @composeArguments ps -q postgres).Trim())
                redis = Wait-ContainerHealth ((& docker @composeArguments ps -q redis).Trim())
                chroma_container = Wait-ContainerHealth ((& docker @composeArguments ps -q chroma).Trim())
                chroma_heartbeat = Wait-HttpHealth 'http://127.0.0.1:8000/api/v2/heartbeat'
                ml = Wait-TcpHealth '127.0.0.1' 8765 300
                background_jobs = Wait-HttpHealth 'http://127.0.0.1:4000/health' 300
                web = Wait-HttpHealth 'http://127.0.0.1:3745/health' 300
            }
            [IO.File]::WriteAllText((Join-Path $EvidenceRoot 'health.json'), ($healthEvidence | ConvertTo-Json), $utf8)
            $serviceEvidence = [ordered]@{}
            foreach ($serviceName in @('background-jobs','web','ml','postgres','redis','chroma')) {
                $containerId = (& docker @composeArguments ps -q $serviceName).Trim()
                Assert-True ([bool]$containerId) "No running container found for $serviceName."
                $serviceEvidence[$serviceName] = (& docker inspect --format '{{.State.Status}}' $containerId).Trim()
            }
            [IO.File]::WriteAllText((Join-Path $EvidenceRoot 'service-status.json'), ($serviceEvidence | ConvertTo-Json), $utf8)
        } finally {
            & docker @composeArguments down --remove-orphans --volumes | Out-Null
            $env:OPENVIDEO_MATERIAL_ROOT = $previousMaterialRoot
            $env:OPENVIDEO_RUNTIME_DATA_ROOT = $previousRuntimeRoot
        }
    }

    Assert-SnapshotEqual $before (Get-FixtureSnapshot $materialRoot)
    [IO.File]::WriteAllText((Join-Path $runtime.RuntimeDataRoot 'models/rebuild-probe.txt'), 'delete me', $utf8)
    if ($Docker) {
        & docker run --rm --mount "type=bind,src=$runtimeRoot,dst=/runtime" alpine:3.20 sh -ceu 'mkdir -p /runtime/models/root-owned && touch /runtime/models/root-owned/probe.txt && chmod 700 /runtime/models/root-owned'
        Assert-True ($LASTEXITCODE -eq 0) 'Unable to create the root-owned runtime cleanup fixture.'
        $runtime = & (Join-Path $PSScriptRoot 'Reset-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -Recreate -Force
    } else {
        $resolvedRuntime = [IO.Path]::GetFullPath($runtime.RuntimeDataRoot)
        $resolvedTestRoot = [IO.Path]::GetFullPath($TestRoot)
        Assert-True ($resolvedRuntime.StartsWith($resolvedTestRoot + [IO.Path]::DirectorySeparatorChar, $pathComparison)) 'Unsafe runtime cleanup target.'
        Remove-Item -LiteralPath $resolvedRuntime -Recurse -Force
        $runtime = & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -PassThru
    }
    Assert-True (Test-Path -LiteralPath $runtime.ComposeEnvironmentPath -PathType Leaf) 'Runtime root was not independently recreated.'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $runtime.RuntimeDataRoot 'models/rebuild-probe.txt'))) 'Runtime model content survived deletion and recreation.'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $runtime.RuntimeDataRoot 'models/root-owned/probe.txt'))) 'Root-owned runtime content survived deletion and recreation.'
    Assert-SnapshotEqual $before (Get-FixtureSnapshot $materialRoot)
    Write-Host 'Edit Mind read-only boundary tests passed.' -ForegroundColor Green
} finally {
    if (Test-Path -LiteralPath $TestRoot) {
        $resolved = [IO.Path]::GetFullPath($TestRoot)
        $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
        if (-not $resolved.StartsWith($tempRoot, $pathComparison)) { throw 'Unsafe test cleanup target.' }
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
