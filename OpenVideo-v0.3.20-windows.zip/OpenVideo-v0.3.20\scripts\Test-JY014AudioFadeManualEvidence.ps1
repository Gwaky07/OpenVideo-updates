[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,
    [Parameter(Mandatory = $true)]
    [string]$GeneratedEvidencePath,
    [Parameter(Mandatory = $true)]
    [string]$ManualEvidencePath
)

$ErrorActionPreference = 'Stop'

function Assert-PrivatePath {
    param([string]$CandidatePath, [string]$BoundaryPath)
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if ($candidate -eq $boundary -or -not $candidate.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'JY014_EVIDENCE_OUTSIDE_PRIVATE_RUNTIME_ROOT'
    }
}

function Assert-NoReparseBoundary {
    param([string]$CandidatePath, [string]$BoundaryPath)
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if (-not (Test-Path -LiteralPath $candidate) -or -not (Test-Path -LiteralPath $boundary)) {
        throw 'JY014_EVIDENCE_PATH_MISSING'
    }
    $currentPath = $candidate
    while ($true) {
        $current = Get-Item -LiteralPath $currentPath -Force
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'JY014_EVIDENCE_REPARSE_POINT_REJECTED'
        }
        if ([IO.Path]::GetFullPath($currentPath).TrimEnd('\') -eq $boundary) { break }
        $currentPath = [IO.Path]::GetDirectoryName($currentPath.TrimEnd('\'))
        if ([string]::IsNullOrWhiteSpace($currentPath)) { throw 'JY014_EVIDENCE_OUTSIDE_PRIVATE_RUNTIME_ROOT' }
    }
}

function Test-NonNegativePair {
    param([object]$Value)
    return @($Value).Count -eq 2 -and @($Value | Where-Object { $_ -isnot [long] -and $_ -isnot [int] -or $_ -lt 0 }).Count -eq 0
}

function Test-ExactFadeObject {
    param([object]$Value)
    $expectedKeys = @('voiceover', 'sfx', 'bgm')
    if ($null -eq $Value -or @(Compare-Object ($expectedKeys | Sort-Object) @($Value.PSObject.Properties.Name | Sort-Object)).Count -ne 0) {
        return $false
    }
    return (Test-NonNegativePair $Value.voiceover) -and (Test-NonNegativePair $Value.sfx) -and (Test-NonNegativePair $Value.bgm)
}

function Get-SupportedProfile {
    param([string]$VersionText)
    $manifestPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'config/jianying-compatibility.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $version = [Version]$VersionText
    $matches = @($manifest.profiles | Where-Object {
        $profile = $_
        $version -ge [Version]$profile.minimum_version -and
        $version -lt [Version]$profile.maximum_version_exclusive -and
        $profile.capabilities.draft_generation -eq $true -and
        $profile.capabilities.manual_open -eq $true
    })
    if ($matches.Count -ne 1) { throw 'JY014_SUPPORTED_VERSION_REQUIRED' }
    return $matches[0]
}

$runtimeRoot = [IO.Path]::GetFullPath($RuntimeDataRoot)
$generatedPath = [IO.Path]::GetFullPath($GeneratedEvidencePath)
$manualPath = [IO.Path]::GetFullPath($ManualEvidencePath)
Assert-PrivatePath -CandidatePath $generatedPath -BoundaryPath $runtimeRoot
Assert-PrivatePath -CandidatePath $manualPath -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $runtimeRoot -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $generatedPath -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $manualPath -BoundaryPath $runtimeRoot
if ($generatedPath -eq $manualPath) { throw 'JY014_EVIDENCE_PATH_COLLISION' }

$generated = Get-Content -LiteralPath $generatedPath -Raw -Encoding UTF8 | ConvertFrom-Json
$manual = Get-Content -LiteralPath $manualPath -Raw -Encoding UTF8 | ConvertFrom-Json
$supportedProfile = Get-SupportedProfile -VersionText ([string]$generated.desktop_version)
$generatedKeys = @('schema_version', 'kind', 'generated_at', 'draft_label', 'desktop_version', 'profile_id', 'handoff_mode', 'desktop_opened', 'edit_confirmed', 'output_fingerprint', 'structures', 'isolation', 'media_policy')
$manualKeys = @('schema_version', 'kind', 'recorded_at', 'desktop_version', 'compatibility_profile', 'user_authorized', 'draft_fingerprint', 'opened_in_supported_jianying', 'observed_fades_us', 'edited_fades_us', 'saved_after_audio_fade_edit')
if (
    @(Compare-Object ($generatedKeys | Sort-Object) @($generated.PSObject.Properties.Name | Sort-Object)).Count -ne 0 -or
    @(Compare-Object ($manualKeys | Sort-Object) @($manual.PSObject.Properties.Name | Sort-Object)).Count -ne 0
) { throw 'JY014_EVIDENCE_SCHEMA_INVALID' }

$observed = @($manual.observed_fades_us.voiceover) + @($manual.observed_fades_us.sfx) + @($manual.observed_fades_us.bgm)
$edited = @($manual.edited_fades_us.voiceover) + @($manual.edited_fades_us.sfx) + @($manual.edited_fades_us.bgm)
$expected = @($generated.structures.voiceover_fade) + @($generated.structures.sfx_fade) + @($generated.structures.bgm_fade)
if (
    $generated.schema_version -ne 1 -or
    $generated.kind -ne 'jy008_capability_acceptance_evidence' -or
    $generated.output_fingerprint -notmatch '^[a-f0-9]{64}$' -or
    $manual.schema_version -ne 1 -or
    $manual.kind -ne 'jy014_audio_fade_manual_evidence' -or
    [string]::IsNullOrWhiteSpace($manual.desktop_version) -or
    $manual.desktop_version -ne $generated.desktop_version -or
    $manual.compatibility_profile -ne $supportedProfile.id -or
    $manual.user_authorized -ne $true -or
    $manual.draft_fingerprint -ne $generated.output_fingerprint -or
    $manual.opened_in_supported_jianying -ne $true -or
    $manual.saved_after_audio_fade_edit -ne $true -or
    -not (Test-ExactFadeObject $manual.observed_fades_us) -or
    -not (Test-ExactFadeObject $manual.edited_fades_us) -or
    -not (Test-NonNegativePair $generated.structures.voiceover_fade) -or
    -not (Test-NonNegativePair $generated.structures.sfx_fade) -or
    -not (Test-NonNegativePair $generated.structures.bgm_fade) -or
    @(Compare-Object $expected $observed -SyncWindow 0).Count -ne 0 -or
    @(Compare-Object $observed $edited -SyncWindow 0).Count -eq 0
) { throw 'JY014_AUDIO_FADE_MANUAL_EVIDENCE_INVALID' }

Write-Output 'JY-014 private audio-fade manual evidence verified.'
