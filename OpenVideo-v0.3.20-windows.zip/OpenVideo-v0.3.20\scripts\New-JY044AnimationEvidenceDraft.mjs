import { createRequire } from 'node:module'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { createScaleEvidenceTimeline, projectScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'

const require = createRequire(import.meta.url); const manifest = require('../config/jianying-compatibility.json'); const execFileAsync = promisify(execFile)
const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== 'jianying-11-1-provisional') throw new Error('JY044_PROFILE_UNSUPPORTED')
  const root = loadLocalRuntimeConfig().dataRoot; const catalog = JSON.parse(await readFile(path.join(root, 'catalogs', 'jy044-animation-catalog.json'), 'utf8')); const entry = catalog.entries?.[0]
  if (!entry?.resource_id || !entry?.animation_token) throw new Error('JY044_PRIVATE_CATALOG_MISSING')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy044-animation-')); const video = path.join(mediaRoot, 'video.mp4'); const audio = path.join(mediaRoot, 'voice.wav')
  await execFileAsync('ffmpeg', ['-hide_banner','-loglevel','error','-y','-f','lavfi','-i','color=c=blue:s=360x640:r=30','-t','4','-pix_fmt','yuv420p',video])
  await execFileAsync('ffmpeg', ['-hide_banner','-loglevel','error','-y','-f','lavfi','-i','anullsrc=r=16000:cl=mono','-t','4','-ac','1',audio])
  const projected = projectScaleEvidenceTimeline(desktop.profileId, createScaleEvidenceTimeline()); const draftId = `OpenVideo-JY044-animation-${Date.now()}`
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT, getRenderOptions: () => ({ captions:false,bgmPath:null,subtitleStyle:'default',keywordHighlights:[],captionSegments:[],titleSegments:[],timelinePackaging:{...projected.packaging,animation_segments:[{resource_id:entry.resource_id,target_start_us:0,target_duration_us:4_000_000,duration_us:entry.duration_us}],sfx_segments:[],effect_segments:[],sticker_segments:[],filter_segments:[],voiceover_segments:[],bgm:{fade_in_us:0,fade_out_us:0}} }) })
  const request = { job_id:`job-${draftId}`,request_id:`request-${draftId}`,output_policy:{draft_id:draftId},export_request:{preparation:projected.preparation},orientation:'portrait',materials:[{path:video}],voiceovers:[{path:audio}] }
  const result = await writer.writeDraft(request); if (await writer.verifyDraft({ job_id:request.job_id,request:{export_request:request.export_request},write_result:result }) !== true) throw new Error('JY044_VERIFY_FAILED')
  if (await writer.releaseDraft({ job_id:request.job_id,write_result:result }) !== true) throw new Error('JY044_RELEASE_FAILED')
  const evidence = path.join(root,'evidence','jy044-animation'); await (await import('node:fs/promises')).mkdir(evidence,{recursive:true}); await writeFile(path.join(evidence,'pending.json'), JSON.stringify({schema_version:1,draftId,profileId:desktop.profileId,draftRoot:desktop.draftRoot,mediaRoot,animationToken:entry.animation_token}),{encoding:'utf8',mode:0o600})
  process.stdout.write(JSON.stringify({ok:true,manual_open_required:true,draft_prefix:'OpenVideo-JY044-animation-',animation_name:entry.display_name,initial_duration_seconds:0.5,profile:desktop.profileId,version:desktop.version})+'\n')
}
main().catch((error)=>{process.stdout.write(JSON.stringify({ok:false,code:error?.message??'JY044_FAILED'})+'\n');process.exitCode=1})
