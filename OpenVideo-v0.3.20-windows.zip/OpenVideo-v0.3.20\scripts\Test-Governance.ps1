[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$failures = [System.Collections.Generic.List[string]]::new()

function Add-Failure([string]$Message) {
    $failures.Add($Message)
    Write-Host "[FAIL] $Message" -ForegroundColor Red
}

function Add-Pass([string]$Message) {
    Write-Host "[PASS] $Message" -ForegroundColor Green
}

function Invoke-Git([string[]]$Arguments) {
    $previousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $output = @(& git -C $RepositoryRoot @Arguments 2>$null)
        $exitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    return [pscustomobject]@{ Output = $output; ExitCode = $exitCode }
}

function Read-StatusAtRef([string]$Ref) {
    $result = Invoke-Git @('show', "$Ref`:docs/tasks/STATUS.json")
    if ($result.ExitCode -ne 0 -or -not $result.Output) {
        Add-Failure "Unable to read previous STATUS.json from $Ref"
        return $null
    }
    try {
        return (($result.Output -join "`n") | ConvertFrom-Json)
    } catch {
        Add-Failure "STATUS.json from $Ref cannot be parsed"
        return $null
    }
}

function Normalize-RepositoryUrl([string]$Url) {
    if (-not $Url) { return '' }
    $normalized = $Url.Trim().TrimEnd('/')
    if ($normalized.EndsWith('.git', [StringComparison]::OrdinalIgnoreCase)) {
        $normalized = $normalized.Substring(0, $normalized.Length - 4)
    }
    return $normalized
}

function Test-StatusTransition($PreviousStatus, $CurrentStatus) {
    if (-not $PreviousStatus -or -not $CurrentStatus) { return }
    foreach ($task in @($CurrentStatus.tasks)) {
        $previousTask = @($PreviousStatus.tasks | Where-Object { $_.id -eq $task.id }) | Select-Object -First 1
        if (-not $previousTask) { continue }
        $previousHistory = @($previousTask.status_history)
        $currentHistory = @($task.status_history)
        if ($currentHistory.Count -lt $previousHistory.Count -or $currentHistory.Count -gt ($previousHistory.Count + 1)) {
            Add-Failure "Task $($task.id) must append at most one lifecycle state per change"
            continue
        }
        for ($historyIndex = 0; $historyIndex -lt $previousHistory.Count; $historyIndex++) {
            if ($currentHistory[$historyIndex] -ne $previousHistory[$historyIndex]) {
                Add-Failure "Task $($task.id) rewrote existing status_history"
                break
            }
        }
    }
}

$requiredFiles = @(
    'AGENTS.md',
    '.gitignore',
    'docs/tasks/ROADMAP.md',
    'docs/tasks/STATUS.json',
    'docs/tasks/TASK-TEMPLATE.md',
    'docs/tasks/REVIEW-CHECKLIST.md',
    'docs/tasks/HANDOFF-TEMPLATE.md',
    '.github/workflows/governance.yml',
    'scripts/Test-LocalAcceptance.ps1',
    'scripts/Test-Governance-Negative.ps1'
)

foreach ($relativePath in $requiredFiles) {
    $path = Join-Path $RepositoryRoot $relativePath
    if (Test-Path -LiteralPath $path -PathType Leaf) { Add-Pass "Required file exists: $relativePath" }
    else { Add-Failure "Missing required file: $relativePath" }
}

$workflowPath = Join-Path $RepositoryRoot '.github/workflows/governance.yml'
if (Test-Path -LiteralPath $workflowPath -PathType Leaf) {
    $workflowContent = Get-Content -LiteralPath $workflowPath -Raw -Encoding UTF8
    if ($workflowContent -notmatch '(?m)^[ \t]{2}workflow_dispatch\s*:') {
        Add-Failure 'Governance workflow must expose workflow_dispatch for optional remote review'
    }
    if ($workflowContent -match '(?m)^[ \t]{2}(push|pull_request)\s*:') {
        Add-Failure 'Governance workflow must not run automatically on push or pull_request'
    }
    if (-not ($failures | Where-Object { $_ -match 'Governance workflow' })) {
        Add-Pass 'GitHub Actions is manual-only and cannot block local task completion'
    }
}

$status = $null
$statusPath = Join-Path $RepositoryRoot 'docs/tasks/STATUS.json'
if (Test-Path -LiteralPath $statusPath) {
    try {
        $status = Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $allowedStatuses = @('planned', 'in_progress', 'implemented', 'verified', 'reviewed', 'documented', 'committed', 'pushed', 'handed_off')
        if (-not $status.current_task) { Add-Failure 'STATUS.json current_task is empty' }
        if ($status.current_status -notin $allowedStatuses) { Add-Failure "Invalid current_status: $($status.current_status)" }

        $ids = @($status.tasks | ForEach-Object { $_.id })
        if ($ids.Count -ne (@($ids | Sort-Object -Unique)).Count) { Add-Failure 'STATUS.json contains duplicate task IDs' }
        if ($status.current_task -notin $ids) { Add-Failure 'current_task is not present in tasks' }
        if ($status.next_task -and $status.next_task -notin $ids) { Add-Failure 'next_task is not present in tasks' }

        $currentTaskRecord = @($status.tasks | Where-Object { $_.id -eq $status.current_task }) | Select-Object -First 1
        if ($currentTaskRecord -and $currentTaskRecord.status -ne $status.current_status) {
            Add-Failure "current_status does not match the current task record: $($status.current_status) != $($currentTaskRecord.status)"
        }

        $currentTaskDocumentRelativePath = 'docs/tasks/{0}.md' -f $status.current_task
        $currentTaskDocumentPath = Join-Path $RepositoryRoot $currentTaskDocumentRelativePath
        $taskDocumentValid = $true
        if (-not (Test-Path -LiteralPath $currentTaskDocumentPath -PathType Leaf)) {
            Add-Failure ('Missing current task document: {0}' -f $currentTaskDocumentRelativePath)
            $taskDocumentValid = $false
        } else {
            $taskDocumentContent = Get-Content -LiteralPath $currentTaskDocumentPath -Raw -Encoding UTF8
            $sectionMatches = [regex]::Matches($taskDocumentContent, '(?m)^## (?<name>.+?)\s*$')
            $duplicateSectionNames = @(
                $sectionMatches |
                    ForEach-Object { $_.Groups['name'].Value } |
                    Group-Object |
                    Where-Object Count -gt 1 |
                    ForEach-Object { $_.Name }
            )
            foreach ($duplicateSectionName in $duplicateSectionNames) {
                Add-Failure ('Task document {0} contains duplicate ## {1} section' -f $currentTaskDocumentRelativePath, $duplicateSectionName)
                $taskDocumentValid = $false
            }

            $taskDocumentStatusMatches = [regex]::Matches($taskDocumentContent, '(?m)^- Status:\s*\x60(?<status>[^\x60]+)\x60\s*$')
            if ($taskDocumentStatusMatches.Count -ne 1) {
                Add-Failure ('Task document {0} must contain exactly one Status line' -f $currentTaskDocumentRelativePath)
                $taskDocumentValid = $false
            } elseif ($taskDocumentStatusMatches[0].Groups['status'].Value -ne $status.current_status) {
                Add-Failure ('Task document {0} status {1} does not match STATUS.json current_status {2}' -f $currentTaskDocumentRelativePath, $taskDocumentStatusMatches[0].Groups['status'].Value, $status.current_status)
                $taskDocumentValid = $false
            }
        }
        if ($taskDocumentValid) { Add-Pass ('Current task document is unique and matches STATUS.json: {0}' -f $currentTaskDocumentRelativePath) }

        foreach ($task in @($status.tasks)) {
            if ($task.status -notin $allowedStatuses) { Add-Failure "Invalid task status for $($task.id): $($task.status)" }
            foreach ($dependency in @($task.depends_on)) {
                if ($dependency -notin $ids) { Add-Failure "Task $($task.id) references missing dependency: $dependency" }
            }
            $history = @($task.status_history)
            $currentIndex = [Array]::IndexOf($allowedStatuses, [string]$task.status)
            if ($history.Count -ne ($currentIndex + 1)) {
                Add-Failure "Task $($task.id) status_history length does not match current status $($task.status)"
            } else {
                for ($historyIndex = 0; $historyIndex -lt $history.Count; $historyIndex++) {
                    if ($history[$historyIndex] -ne $allowedStatuses[$historyIndex]) {
                        Add-Failure "Task $($task.id) status_history is not a contiguous lifecycle prefix"
                        break
                    }
                }
            }
        }

        $comparisonRef = $null
        if ($env:GOVERNANCE_DIFF_BASE -and $env:GOVERNANCE_DIFF_BASE -match '^[0-9a-fA-F]{40}$' -and $env:GOVERNANCE_DIFF_BASE -notmatch '^0+$') {
            $comparisonRef = $env:GOVERNANCE_DIFF_BASE
        } else {
            $headCheck = Invoke-Git @('rev-parse','--verify','HEAD')
            if ($headCheck.ExitCode -eq 0) { $comparisonRef = 'HEAD' }
        }

        if ($comparisonRef) {
            $previousStatus = Read-StatusAtRef $comparisonRef
            $rangeHead = $null
            if ($env:GOVERNANCE_DIFF_HEAD -and $env:GOVERNANCE_DIFF_HEAD -match '^[0-9a-fA-F]{40}$' -and $env:GOVERNANCE_DIFF_HEAD -notmatch '^0+$') {
                $rangeHead = $env:GOVERNANCE_DIFF_HEAD
            }

            if ($rangeHead -and $rangeHead -ne $comparisonRef) {
                $commitRange = Invoke-Git @('rev-list','--reverse',"$comparisonRef..$rangeHead")
                if ($commitRange.ExitCode -ne 0) {
                    Add-Failure "Unable to enumerate governance commit range $comparisonRef..$rangeHead"
                } else {
                    foreach ($commitRef in @($commitRange.Output)) {
                        $commitRef = ([string]$commitRef).Trim()
                        if ($commitRef -notmatch '^[0-9a-fA-F]{40}$') {
                            Add-Failure "Invalid commit SHA returned by rev-list: $commitRef"
                            continue
                        }
                        $commitStatus = Read-StatusAtRef $commitRef
                        Test-StatusTransition $previousStatus $commitStatus
                        if ($commitStatus) { $previousStatus = $commitStatus }
                    }
                    Test-StatusTransition $previousStatus $status
                }
            } else {
                Test-StatusTransition $previousStatus $status
            }
        } else {
            if ($status.current_task -ne 'GOV-001' -or $status.current_status -notin @('planned','in_progress','implemented','verified','reviewed','documented')) {
                Add-Failure 'A repository without a baseline commit may only bootstrap GOV-001 through documented'
            }
            foreach ($task in @($status.tasks | Where-Object { $_.id -ne 'GOV-001' -and $_.status -ne 'planned' })) {
                Add-Failure "Bootstrap task $($task.id) must remain planned before the first commit"
            }
            if ($status.current_status -in @('reviewed','documented')) {
                $governanceRecordPath = Join-Path $RepositoryRoot 'docs/tasks/GOV-001.md'
                $governanceRecord = Get-Content -LiteralPath $governanceRecordPath -Raw -Encoding UTF8
                if ($governanceRecord -notmatch '(?m)^- Review-Gate: passed$') {
                    Add-Failure 'Bootstrap review state requires completed independent review evidence in GOV-001.md'
                }
            }
        }

        $startedStatuses = @('in_progress', 'implemented', 'verified', 'reviewed', 'documented', 'committed', 'pushed', 'handed_off')
        foreach ($task in @($status.tasks | Where-Object { $_.status -in $startedStatuses })) {
            foreach ($dependency in @($task.depends_on)) {
                $dependencyRecord = @($status.tasks | Where-Object { $_.id -eq $dependency }) | Select-Object -First 1
                if ($dependencyRecord.status -ne 'handed_off') {
                    Add-Failure "Task $($task.id) started before dependency $dependency was handed off"
                }
            }
        }

        if ($status.current_status -in @('pushed', 'handed_off')) {
            if (-not $status.remote_repository) { Add-Failure 'A pushed or handed-off task requires remote_repository' }
            if ($status.last_pushed_commit -notmatch '^[0-9a-fA-F]{40}$') { Add-Failure 'A pushed or handed-off task requires a full 40-character last_pushed_commit' }
        }
        foreach ($task in @($status.tasks | Where-Object { $_.status -eq 'handed_off' })) {
            $uuidPattern = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$'
            if ($task.handoff_kind -eq 'cursor') {
                if ($task.handoff_id -notmatch $uuidPattern) { Add-Failure "Cursor handed-off task $($task.id) requires a UUID-format handoff_id" }
                if ($null -ne $task.handoff_thread_id) { Add-Failure "Cursor handed-off task $($task.id) must not set handoff_thread_id" }
            } elseif (-not $task.handoff_kind -or $task.handoff_kind -eq 'codex') {
                if ($task.handoff_thread_id -notmatch $uuidPattern) { Add-Failure "Handed-off task $($task.id) requires a UUID-format handoff_thread_id" }
            } else {
                Add-Failure "Handed-off task $($task.id) has unsupported handoff_kind $($task.handoff_kind)"
            }
        }

        if ($failures.Count -eq 0) { Add-Pass 'STATUS.json schema, dependencies, and lifecycle gates are valid' }
    } catch {
        Add-Failure "STATUS.json cannot be parsed: $($_.Exception.Message)"
    }
}

$trackedResult = Invoke-Git @('ls-files','--cached','--others','--exclude-standard')
if ($trackedResult.ExitCode -ne 0) { Add-Failure 'Unable to list Git tracked files'; $tracked = @() }
else { $tracked = @($trackedResult.Output) }

$forbiddenExtensions = @('.mp4','.mov','.mkv','.avi','.m4v','.wmv','.flv','.webm','.mp3','.wav','.aac','.flac','.jpg','.jpeg','.png','.gif','.webp','.db','.sqlite','.sqlite3')
$forbiddenLocalNames = @('.env','.env.local','.env.development','.env.production','.env.test','config.local.json','config.local.yaml','config.local.yml')
foreach ($relativePath in $tracked) {
    $normalized = $relativePath.Replace('\','/')
    $extension = [IO.Path]::GetExtension($relativePath).ToLowerInvariant()
    $leaf = [IO.Path]::GetFileName($relativePath).ToLowerInvariant()
    if ($extension -in $forbiddenExtensions) { Add-Failure "Forbidden generated/media/database file is tracked: $relativePath" }
    if ($leaf -in $forbiddenLocalNames -or $normalized -match '(?i)(^|/)[^/]+\.local\.(json|ya?ml|toml|js|ts)$') {
        Add-Failure "Forbidden local runtime configuration is tracked: $relativePath"
    }
    $fullPath = Join-Path $RepositoryRoot $relativePath
    if (Test-Path -LiteralPath $fullPath -PathType Leaf) {
        $size = (Get-Item -LiteralPath $fullPath).Length
        if ($size -gt 5MB) { Add-Failure "Tracked file exceeds 5 MiB: $relativePath ($size bytes)" }
    }
}
if ($tracked.Count -gt 0 -and -not ($failures | Where-Object { $_ -match 'Forbidden generated|Forbidden local|exceeds 5 MiB' })) {
    Add-Pass 'Tracked files contain no forbidden media, databases, local configs, or files above 5 MiB'
}

$secretPatterns = @(
    '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----',
    '\bsk-[A-Za-z0-9_-]{20,}\b',
    '\bghp_[A-Za-z0-9]{20,}\b',
    '\bgithub_pat_[A-Za-z0-9_]{20,}\b',
    '\bAKIA[0-9A-Z]{16}\b',
    '(?im)^\s*[A-Za-z0-9_]*(api[_-]?key|token|password|client[_-]?secret)\s*[:=]\s*(?:(?:"(?!<|example|sample|changeme|your[_-])[A-Za-z0-9_./+=-]{8,}")|(?:''(?!<|example|sample|changeme|your[_-])[A-Za-z0-9_./+=-]{8,}'')|(?:(?!<|example|sample|changeme|your[_-])[A-Za-z0-9_+/=-]{8,}\s*$))'
)
$machinePathPatterns = @(
    '(?im)(?<![<A-Za-z0-9_])[A-Z]:[\\/](?![>])',
    '(?im)\\\\[^\\\s]+\\[^\\\s]+'
)
foreach ($relativePath in $tracked) {
    $fullPath = Join-Path $RepositoryRoot $relativePath
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) { continue }
    $extension = [IO.Path]::GetExtension($relativePath).ToLowerInvariant()
    if ($extension -in $forbiddenExtensions) { continue }
    $content = Get-Content -LiteralPath $fullPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    foreach ($pattern in $secretPatterns) {
        if ($content -match $pattern) { Add-Failure "Potential secret detected in $relativePath"; break }
    }
    foreach ($pattern in $machinePathPatterns) {
        if ($content -match $pattern) { Add-Failure "Machine-specific absolute path detected in $relativePath"; break }
    }
}
if (-not ($failures | Where-Object { $_ -match 'secret|Machine-specific' })) {
    Add-Pass 'No known credential formats or machine-specific absolute paths detected'
}

if ($status -and $status.current_status -in @('pushed', 'handed_off') -and $status.last_pushed_commit -match '^[0-9a-fA-F]{40}$') {
    $originResult = Invoke-Git @('remote','get-url','origin')
    if ($originResult.ExitCode -ne 0 -or -not $originResult.Output) { Add-Failure 'Pushed state requires a configured origin remote' }
    else {
        $originUrl = [string]$originResult.Output[0]
        if (-not [string]::Equals((Normalize-RepositoryUrl $status.remote_repository), (Normalize-RepositoryUrl $originUrl), [StringComparison]::OrdinalIgnoreCase)) { Add-Failure 'STATUS.json remote_repository does not match git origin URL' }
        $commitResult = Invoke-Git @('cat-file','-e',"$($status.last_pushed_commit)^{commit}")
        if ($commitResult.ExitCode -ne 0) { Add-Failure 'last_pushed_commit is not a local commit object' }
        $remoteResult = Invoke-Git @('ls-remote','origin',"refs/heads/$($status.default_branch)")
        if ($remoteResult.ExitCode -ne 0 -or -not $remoteResult.Output) { Add-Failure 'Unable to verify the default branch on origin' }
        else {
            $remoteTip = ([string]$remoteResult.Output[0] -split '\s+')[0]
            $ancestorResult = Invoke-Git @('merge-base','--is-ancestor',$status.last_pushed_commit,$remoteTip)
            if ($ancestorResult.ExitCode -ne 0) { Add-Failure 'last_pushed_commit is not contained in the remote default branch' }
            else { Add-Pass 'Git origin and pushed commit evidence are valid' }
        }
    }
}

$diffChecks = @(
    @{ Name = 'working tree'; Args = @('diff','--check') },
    @{ Name = 'staged changes'; Args = @('diff','--cached','--check') }
)
$headResult = Invoke-Git @('rev-parse','--verify','HEAD')
if ($headResult.ExitCode -eq 0) { $diffChecks += @{ Name = 'HEAD commit'; Args = @('show','--check','--format=','HEAD') } }
if ($env:GOVERNANCE_DIFF_BASE -and $env:GOVERNANCE_DIFF_BASE -match '^[0-9a-fA-F]{40}$' -and $env:GOVERNANCE_DIFF_BASE -notmatch '^0+$') {
    $diffChecks += @{ Name = 'workflow change range'; Args = @('diff','--check',"$env:GOVERNANCE_DIFF_BASE..HEAD") }
}
foreach ($check in $diffChecks) {
    $result = Invoke-Git $check.Args
    if ($result.ExitCode -eq 0) { Add-Pass "git diff check passed: $($check.Name)" }
    else { Add-Failure "git diff check failed: $($check.Name)" }
}

if ($failures.Count -gt 0) {
    Write-Host "Governance validation failed with $($failures.Count) issue(s)." -ForegroundColor Red
    exit 1
}

Write-Host 'Governance validation passed.' -ForegroundColor Green
