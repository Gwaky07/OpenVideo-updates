import { readFile, mkdtemp, rm } from 'node:fs/promises'
import { createRequire } from 'node:module'
import path from 'node:path'
import os from 'node:os'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
const require = createRequire(import.meta.url); const manifest = require('../config/jianying-compatibility.json')
const main = async () => {
  const root = loadLocalRuntimeConfig().dataRoot; const lease = JSON.parse(await readFile(path.join(root,'evidence','jy044-animation','pending.json'),'utf8')); const catalog = JSON.parse(await readFile(path.join(root,'catalogs','jy044-animation-catalog.json'),'utf8')); const desktop = await detectJianyingDesktop({compatibilityManifest:manifest})
  if (desktop?.profileId !== lease.profileId || !catalog.entries?.[0]?.resource_id) throw new Error('JY044_BINDING_INVALID')
  const temp = await mkdtemp(path.join(os.tmpdir(),'openvideo-jy044-verify-'))
  try { const plain=path.join(temp,'draft_content.json'); const meta=await createJianyingDraftDecryptor({installRoot:desktop.installRoot,appVersion:desktop.version}).ensurePlaintextFile(path.join(lease.draftRoot,lease.draftId,'draft_content.json'),plain); const content=JSON.parse(await readFile(plain,'utf8')); const animations=content?.materials?.material_animations??[]; const target=animations.filter((entry)=>entry?.animations?.some((item)=>String(item?.resource_id)===String(catalog.entries[0].resource_id)&&item?.duration===1_000_000)); const video=content?.tracks?.find((track)=>track?.name==='video-primary'); const attached=(video?.segments??[]).some((segment)=>(segment?.extra_material_refs??[]).some((id)=>target.some((entry)=>entry?.id===id))); if ((meta.scheme??meta.decryptedFrom)!=='encrypt_v2'||target.length!==1||!attached) { process.stdout.write(JSON.stringify({ok:false,code:'JY044_ANIMATION_PERSISTENCE_INVALID',materialAnimationCount:animations.length,matchingDurationCount:target.length,attached,durationsUs:animations.flatMap((entry)=>Array.isArray(entry?.animations)?entry.animations.map((item)=>item?.duration):[])})+'\n'); return }; process.stdout.write(JSON.stringify({ok:true,scheme:'encrypt_v2',animationCount:1,normalizedDurationUs:1_000_000,attached:true})+'\n') } finally { await rm(temp,{recursive:true,force:true}) }
}; main().catch((error)=>{process.stdout.write(JSON.stringify({ok:false,code:error?.message??'JY044_VERIFY_FAILED'})+'\n');process.exitCode=1})
