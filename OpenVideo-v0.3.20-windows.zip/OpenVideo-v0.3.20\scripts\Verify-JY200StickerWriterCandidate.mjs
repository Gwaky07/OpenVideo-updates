import { createHash, randomUUID } from 'node:crypto'
import { link, mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  assertJY200StickerEvidenceIdentityStable,
  fingerprintCanonicalJY200Draft,
  inspectArtistEffectStickerLifecycle,
  parseArtistEffectStickerLifecycleReceipt,
  parseArtistEffectStickerProbeReceipt,
  probeArtistEffectPayload,
  sanitizeJY200ProbeError,
  signArtistEffectStickerReceipt,
} from '../apps/gateway/src/jianying-artist-effect-probe.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { createJianyingDesktopBinding, parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import { loadPackagingResourceEvidenceIntegrityKey } from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const runIdPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u
const sha256 = (value) => createHash('sha256').update(value).digest('hex')

/**
 * Publish immutable lifecycle evidence with create-if-absent semantics. A
 * complete temporary file is linked into place atomically, so concurrent
 * first publishers can only converge on the same signed receipt.
 * @param {{lifecycleRoot: string, runId: string, lifecycle: Record<string, any>, integrityKey: string}} input
 */
export const publishStickerLifecycleReceipt = async ({ lifecycleRoot, runId, lifecycle, integrityKey }) => {
  if (!parseArtistEffectStickerLifecycleReceipt(lifecycle, runId, integrityKey)) {
    throw new Error('JY200_STICKER_LIFECYCLE_RECEIPT_INVALID')
  }
  await mkdir(lifecycleRoot, { recursive: true, mode: 0o700 })
  const output = path.join(lifecycleRoot, `${runId}.json`)
  const staged = `${output}.${process.pid}.${randomUUID()}.tmp`
  const stable = ({ verified_at: _verifiedAt, integrity_signature: _signature, ...record }) => JSON.stringify(record)
  try {
    await writeFile(staged, `${JSON.stringify(lifecycle, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    try {
      await link(staged, output)
      return lifecycle
    } catch (error) {
      if (/** @type {{code?: string}} */ (error)?.code !== 'EEXIST') throw error
      const existing = parseArtistEffectStickerLifecycleReceipt(
        JSON.parse(await readFileNoReparse(output, lifecycleRoot, 1024 * 1024)), runId, integrityKey,
      )
      if (!existing || stable(existing) !== stable(lifecycle)) {
        throw new Error('JY200_STICKER_LIFECYCLE_RECEIPT_CONFLICT')
      }
      return existing
    }
  } finally {
    await rm(staged, { force: true })
  }
}

/** @param {{dataRoot: string, compatibilityManifest: Record<string, any>, packagingToken: string}} input */
const observeCurrentIdentity = async ({ dataRoot, compatibilityManifest, packagingToken }) => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  const catalogRoot = path.join(dataRoot, 'catalogs')
  const catalog = parsePrivatePackagingResourceIndex(
    JSON.parse(await readFileNoReparse(path.join(catalogRoot, 'native018-private-draft-catalog.json'), catalogRoot, 32 * 1024 * 1024)),
    { profileId: desktop.profileId, appVersion: desktop.version },
  )
  const entry = catalog.entries.find((candidate) => candidate.packaging_token === packagingToken &&
    candidate.family === 'sticker' && candidate.writer_eligible === false && candidate.state === 'discoverable')
  if (!entry) throw new Error('JY200_STICKER_CANDIDATE_UNAVAILABLE')
  const payload = await probeArtistEffectPayload({ desktop, resourceId: entry.private_binding.resourceId })
  if (!payload) throw new Error('JY200_STICKER_PAYLOAD_UNAVAILABLE')
  return Object.freeze({ desktop, catalog, entry, payload, desktopBindingFingerprint: createJianyingDesktopBinding(desktop).binding_fingerprint })
}

/** @param {string[]} [argv] */
export const runStickerLifecycleVerifier = async (argv = process.argv.slice(2)) => {
  const runId = argv[0]
  const expectedRotation = Number(argv.find((argument) => argument.startsWith('--rotation='))?.slice('--rotation='.length))
  const attested = argv.includes('--manual-attestation=opened-edited-saved-closed-reopened')
  if (!runIdPattern.test(runId ?? '') || !Number.isFinite(expectedRotation) || !attested) {
    throw new Error('JY200_STICKER_LIFECYCLE_ARGUMENTS_INVALID')
  }
  const runtime = await loadLauncherRuntimeConfig({ repositoryRoot: root })
  const dataRoot = runtime.dataRoot
  const compatibilityManifest = JSON.parse(await readFileNoReparse(path.join(root, 'config', 'jianying-compatibility.json'), root))
  const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({
    evidenceRoot: path.join(dataRoot, 'evidence', 'jy132-packaging-resources'),
  })
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy200-sticker-probes')
  const sourceBytes = await readFileNoReparseBuffer(path.join(evidenceRoot, `${runId}.json`), evidenceRoot, 1024 * 1024)
  const source = parseArtistEffectStickerProbeReceipt(JSON.parse(sourceBytes.toString('utf8')), runId, integrityKey)
  if (!source) throw new Error('JY200_STICKER_PROBE_RECEIPT_INVALID')

  const initial = await observeCurrentIdentity({ dataRoot, compatibilityManifest, packagingToken: source.packaging_token })
  if (initial.catalog.catalogFingerprint !== source.catalog_fingerprint ||
      initial.desktopBindingFingerprint !== source.desktop_binding_fingerprint ||
      initial.payload.resourceIdFingerprint !== source.resource_id_fingerprint ||
      initial.payload.payloadFingerprint !== source.payload_fingerprint) {
    throw new Error('JY200_STICKER_PROBE_IDENTITY_DRIFT')
  }
  const draftRoot = path.resolve(initial.desktop.draftRoot, source.publish.draft_id)
  if (path.dirname(draftRoot) !== path.resolve(initial.desktop.draftRoot)) throw new Error('JY200_STICKER_DRAFT_BINDING_INVALID')
  const encryptedPath = path.join(draftRoot, 'draft_content.json')
  const encryptedSnapshot = await readFileNoReparseBuffer(encryptedPath, initial.desktop.draftRoot, 16 * 1024 * 1024)
  const encryptedDraftFingerprint = sha256(encryptedSnapshot)
  const expectedIdentity = Object.freeze({
    desktopBindingFingerprint: initial.desktopBindingFingerprint,
    catalogFingerprint: initial.catalog.catalogFingerprint,
    packagingToken: source.packaging_token,
    resourceIdFingerprint: initial.payload.resourceIdFingerprint,
    payloadFingerprint: initial.payload.payloadFingerprint,
    encryptedDraftFingerprint,
  })

  const temporaryRoot = await mkdtemp(path.join(os.tmpdir(), 'openvideo-jy200-sticker-verify-'))
  try {
    const snapshotPath = path.join(temporaryRoot, 'draft_content.encrypt_v2')
    const plaintextPath = path.join(temporaryRoot, 'draft_content.json')
    await writeFile(snapshotPath, encryptedSnapshot, { flag: 'wx', mode: 0o600 })
    const decryptResult = await createJianyingDraftDecryptor({
      installRoot: initial.desktop.installRoot,
      appVersion: initial.desktop.version,
      expectedDllFingerprint: initial.desktop.dllFingerprint,
    }).ensurePlaintextFile(snapshotPath, plaintextPath)
    if (decryptResult.scheme !== 'encrypt_v2' && decryptResult.decryptedFrom !== 'encrypt_v2') {
      throw new Error('JY200_STICKER_ENCRYPT_V2_REQUIRED')
    }
    const plaintext = await readFileNoReparse(plaintextPath, temporaryRoot, 32 * 1024 * 1024)
    const draft = JSON.parse(plaintext)
    const postSavePlaintextFingerprint = fingerprintCanonicalJY200Draft(draft)
    if (postSavePlaintextFingerprint === source.readback.initial_plaintext_fingerprint) {
      throw new Error('JY200_STICKER_EDIT_NOT_OBSERVED')
    }
    const readback = inspectArtistEffectStickerLifecycle({
      draft,
      expectedResourceIdFingerprint: source.resource_id_fingerprint,
      initialRotation: source.readback.initial_rotation,
      expectedRotation,
    })
    if (!readback) throw new Error('JY200_STICKER_LIFECYCLE_READBACK_INVALID')

    const final = await observeCurrentIdentity({ dataRoot, compatibilityManifest, packagingToken: source.packaging_token })
    const finalDraftRoot = path.resolve(final.desktop.draftRoot, source.publish.draft_id)
    if (path.dirname(finalDraftRoot) !== path.resolve(final.desktop.draftRoot)) throw new Error('JY200_STICKER_DRAFT_BINDING_INVALID')
    const finalEncrypted = await readFileNoReparseBuffer(path.join(finalDraftRoot, 'draft_content.json'), final.desktop.draftRoot, 16 * 1024 * 1024)
    assertJY200StickerEvidenceIdentityStable(expectedIdentity, {
      desktopBindingFingerprint: final.desktopBindingFingerprint,
      catalogFingerprint: final.catalog.catalogFingerprint,
      packagingToken: source.packaging_token,
      resourceIdFingerprint: final.payload.resourceIdFingerprint,
      payloadFingerprint: final.payload.payloadFingerprint,
      encryptedDraftFingerprint: sha256(finalEncrypted),
    })

    const unsignedLifecycle = {
      schema_version: 1,
      kind: 'jy200_sticker_probe_lifecycle',
      source_run_id: runId,
      source_receipt_fingerprint: sha256(sourceBytes),
      admission: 'deferred',
      writer_eligible: false,
      profile_id: final.desktop.profileId,
      app_version: final.desktop.version,
      catalog_fingerprint: final.catalog.catalogFingerprint,
      desktop_binding_fingerprint: final.desktopBindingFingerprint,
      packaging_token: source.packaging_token,
      resource_id_fingerprint: source.resource_id_fingerprint,
      payload_fingerprint: source.payload_fingerprint,
      draft_id_fingerprint: sha256(source.publish.draft_id),
      initial_plaintext_fingerprint: source.readback.initial_plaintext_fingerprint,
      post_save_plaintext_fingerprint: postSavePlaintextFingerprint,
      draft_content_fingerprint: encryptedDraftFingerprint,
      scheme: 'encrypt_v2',
      readback,
      manual_attestation: 'opened-edited-saved-closed-reopened',
      opened: true,
      edited: true,
      saved: true,
      closed: true,
      reopened: true,
      same_draft: true,
      persisted_rotation: expectedRotation,
      verified_at: new Date().toISOString(),
      integrity_revision: 1,
    }
    let lifecycle = { ...unsignedLifecycle, integrity_signature: signArtistEffectStickerReceipt(unsignedLifecycle, integrityKey) }
    if (!parseArtistEffectStickerLifecycleReceipt(lifecycle, runId, integrityKey)) throw new Error('JY200_STICKER_LIFECYCLE_RECEIPT_INVALID')
    const lifecycleRoot = path.join(dataRoot, 'evidence', 'jy200-sticker-lifecycle')
    lifecycle = await publishStickerLifecycleReceipt({ lifecycleRoot, runId, lifecycle, integrityKey })
    return Object.freeze({
      ok: true,
      status: 'lifecycle_verified',
      admission: 'deferred',
      writerEligible: false,
      scheme: lifecycle.scheme,
      readback,
      lifecycle: { opened: true, edited: true, saved: true, closed: true, reopened: true, sameDraft: true },
      runId,
    })
  } finally {
    await rm(temporaryRoot, { recursive: true, force: true })
  }
}

const main = async () => {
  try {
    process.stdout.write(`${JSON.stringify(await runStickerLifecycleVerifier())}\n`)
  } catch (error) {
    process.stdout.write(`${JSON.stringify({ ok: false, status: 'deferred', reason: sanitizeJY200ProbeError(error), writerEligible: false })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
