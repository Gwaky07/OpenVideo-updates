[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [switch]$SkipRuntimeBuild
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
$upstreamRoot = Join-Path $resolvedRoot 'upstream'

function Get-NormalizedRepositoryUrl {
    param([string]$Value)
    return $Value.Trim().TrimEnd('/').ToLowerInvariant()
}

function Assert-PinnedCheckout {
    param(
        [string]$DisplayName,
        [string]$Root,
        [object]$Manifest
    )
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
        throw "UPSTREAM_MISSING_AFTER_INSTALL: $DisplayName"
    }
    $commit = (& git -C $Root rev-parse HEAD 2>$null).Trim()
    $remote = (& git -C $Root remote get-url origin 2>$null).Trim()
    $status = (& git -C $Root status --porcelain=v1 2>$null) -join ''
    if ($LASTEXITCODE -ne 0) { throw "UPSTREAM_NOT_GIT_CHECKOUT: $DisplayName" }
    if ($commit -ne [string]$Manifest.commit) { throw "UPSTREAM_COMMIT_MISMATCH: $DisplayName" }
    if ((Get-NormalizedRepositoryUrl $remote) -ne (Get-NormalizedRepositoryUrl ([string]$Manifest.repository))) {
        throw "UPSTREAM_REPOSITORY_MISMATCH: $DisplayName"
    }
    if (-not [string]::IsNullOrWhiteSpace($status)) { throw "UPSTREAM_WORKTREE_DIRTY: $DisplayName" }
}

function Install-PinnedCheckout {
    param(
        [string]$DisplayName,
        [string]$Root,
        [object]$Manifest
    )
    if (Test-Path -LiteralPath $Root) {
        Assert-PinnedCheckout -DisplayName $DisplayName -Root $Root -Manifest $Manifest
        Write-Host "OPENVIDEO_UPSTREAM_CURRENT: $DisplayName" -ForegroundColor Green
        return
    }

    New-Item -ItemType Directory -Path (Split-Path $Root -Parent) -Force | Out-Null
    $temporaryRoot = "$Root.installing-$([guid]::NewGuid().ToString('N'))"
    try {
        Write-Host "Downloading pinned $DisplayName source..." -ForegroundColor Cyan
        & git clone --filter=blob:none --no-checkout ([string]$Manifest.repository) $temporaryRoot
        if ($LASTEXITCODE -ne 0) { throw "UPSTREAM_CLONE_FAILED: $DisplayName" }
        & git -C $temporaryRoot fetch --depth 1 origin ([string]$Manifest.commit)
        if ($LASTEXITCODE -ne 0) { throw "UPSTREAM_FETCH_FAILED: $DisplayName" }
        & git -C $temporaryRoot checkout --detach ([string]$Manifest.commit)
        if ($LASTEXITCODE -ne 0) { throw "UPSTREAM_CHECKOUT_FAILED: $DisplayName" }
        Assert-PinnedCheckout -DisplayName $DisplayName -Root $temporaryRoot -Manifest $Manifest
        Move-Item -LiteralPath $temporaryRoot -Destination $Root
        Write-Host "OPENVIDEO_UPSTREAM_INSTALLED: $DisplayName commit=$($Manifest.commit) license=$($Manifest.license)" -ForegroundColor Green
    } finally {
        if (Test-Path -LiteralPath $temporaryRoot) {
            Remove-Item -LiteralPath $temporaryRoot -Recurse -Force
        }
    }
}

function Assert-ShortVideoFactoryRuntime {
    param(
        [string]$Root,
        [object]$Manifest
    )
    foreach ($artifact in @($Manifest.artifacts)) {
        $relativePath = [string]$artifact.path
        if ([IO.Path]::IsPathRooted($relativePath) -or ($relativePath -split '[\\/]' -contains '..')) {
            throw "SHORT_VIDEO_FACTORY_ARTIFACT_PATH_UNSAFE: $relativePath"
        }
        $canonicalRoot = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
        $artifactPath = [IO.Path]::GetFullPath((Join-Path $canonicalRoot $relativePath))
        $rootPrefix = $canonicalRoot + [IO.Path]::DirectorySeparatorChar
        if (-not $artifactPath.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw "SHORT_VIDEO_FACTORY_ARTIFACT_PATH_UNSAFE: $relativePath"
        }
        if (-not (Test-Path -LiteralPath $artifactPath -PathType Leaf)) {
            throw "SHORT_VIDEO_FACTORY_ARTIFACT_MISSING: $relativePath"
        }
        $file = Get-Item -LiteralPath $artifactPath -Force
        $actualHash = (Get-FileHash -LiteralPath $artifactPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($file.Length -ne [long]$artifact.size -or $actualHash -ne [string]$artifact.sha256) {
            throw "SHORT_VIDEO_FACTORY_ARTIFACT_INTEGRITY_MISMATCH: $relativePath"
        }
    }
}

function Get-PackageManagerVersion {
    param(
        [string]$Root,
        [string]$Fallback = 'pnpm'
    )
    $packageJsonPath = Join-Path $Root 'package.json'
    if (-not (Test-Path -LiteralPath $packageJsonPath -PathType Leaf)) { return $Fallback }
    try {
        $packageJson = Get-Content -LiteralPath $packageJsonPath -Raw | ConvertFrom-Json
        $packageManager = [string]$packageJson.packageManager
        if ($packageManager -match '^pnpm@[0-9]+\.[0-9]+\.[0-9]+$') {
            return $packageManager
        }
    } catch {
        return $Fallback
    }
    return $Fallback
}

function Resolve-Python312Executable {
    if (-not [string]::IsNullOrWhiteSpace($env:OPENVIDEO_JY002_PYTHON_EXECUTABLE)) {
        return $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE
    }
    $pyLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($null -ne $pyLauncher) {
        $candidate = (& py -3.12 -c "import sys; print(sys.executable)" 2>$null).Trim()
        if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($candidate)) {
            return $candidate
        }
    }
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($null -ne $python) { return 'python' }
    throw 'PYTHON312_REQUIRED_FOR_PYJIANYINGDRAFT_INSTALL'
}

if ($null -eq (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'GIT_REQUIRED_FOR_PINNED_UPSTREAM_INSTALL'
}

$shortManifest = Get-Content -LiteralPath (Join-Path $resolvedRoot 'config\short-video-factory-upstream.json') -Raw | ConvertFrom-Json
$jianyingManifest = Get-Content -LiteralPath (Join-Path $resolvedRoot 'config\pyjianyingdraft-upstream.json') -Raw | ConvertFrom-Json
$shortRoot = Join-Path $upstreamRoot 'short-video-factory'
$jianyingRoot = Join-Path $upstreamRoot 'pyJianYingDraft'

Install-PinnedCheckout -DisplayName 'short-video-factory' -Root $shortRoot -Manifest $shortManifest
Install-PinnedCheckout -DisplayName 'pyJianYingDraft' -Root $jianyingRoot -Manifest $jianyingManifest

if (-not $SkipRuntimeBuild) {
    if ($null -eq (Get-Command corepack -ErrorAction SilentlyContinue)) {
        throw 'COREPACK_REQUIRED_FOR_SHORT_VIDEO_FACTORY_INSTALL'
    }
    $shortVideoFactoryPackageManager = Get-PackageManagerVersion -Root $shortRoot -Fallback 'pnpm'
    Write-Host 'Installing pinned short-video-factory runtime dependencies...' -ForegroundColor Cyan
    & corepack $shortVideoFactoryPackageManager --dir $shortRoot --ignore-workspace install --frozen-lockfile
    if ($LASTEXITCODE -ne 0) { throw 'SHORT_VIDEO_FACTORY_DEPENDENCY_INSTALL_FAILED' }
    Write-Host 'Building short-video-factory runtime bridge...' -ForegroundColor Cyan
    & corepack $shortVideoFactoryPackageManager --dir $shortRoot --ignore-workspace exec vite build
    if ($LASTEXITCODE -ne 0) { throw 'SHORT_VIDEO_FACTORY_RUNTIME_BUILD_FAILED' }
    Assert-ShortVideoFactoryRuntime -Root $shortRoot -Manifest $shortManifest

    Write-Host 'Installing pyJianYingDraft Python runtime dependencies...' -ForegroundColor Cyan
    $python312 = Resolve-Python312Executable
    & $python312 -m pip install --user --disable-pip-version-check `
        'pymediainfo==7.0.1' `
        'imageio==2.37.0' `
        'uiautomation==2.0.20' `
        'numpy==2.4.4' `
        'pillow==11.3.0' `
        'comtypes==1.4.16'
    if ($LASTEXITCODE -ne 0) { throw 'PYJIANYINGDRAFT_DEPENDENCY_INSTALL_FAILED' }
}

Assert-PinnedCheckout -DisplayName 'short-video-factory' -Root $shortRoot -Manifest $shortManifest
Assert-PinnedCheckout -DisplayName 'pyJianYingDraft' -Root $jianyingRoot -Manifest $jianyingManifest
Write-Host 'OPENVIDEO_UPSTREAMS_READY' -ForegroundColor Green
