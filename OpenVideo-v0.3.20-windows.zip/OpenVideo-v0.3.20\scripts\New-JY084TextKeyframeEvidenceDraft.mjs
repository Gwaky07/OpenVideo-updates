import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'

const execFileAsync = promisify(execFile)

const createTextKeyframeEvidenceTimeline = () => {
  const tracks = [
    { trackId: 'video-jy084', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary', segments: [{ segmentId: 'video-jy084', kind: 'video', asset: { authorizationId: 'jy084-auth', assetId: 'jy084-video', sceneId: 'jy084-scene' }, sourceRange: { startUs: 0, durationUs: 4_000_000 }, targetRange: { startUs: 0, durationUs: 4_000_000 }, fit: 'cover', volume: 1, speed: { numerator: 1, denominator: 1 }, keyframes: [], effects: [], audit: { origin: 'editor', candidateId: 'jy084-candidate', instructionFingerprint: null }, transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} } }] },
    { trackId: 'title-jy084', order: 1, enabled: true, locked: false, kind: 'title', segments: [{ segmentId: 'title-jy084', kind: 'title', capabilityId: 'title.card', targetRange: { startUs: 0, durationUs: 4_000_000 }, text: 'OpenVideo text keyframe', styleToken: 'title_card', keyframes: [{ capabilityId: 'transform.text.keyframe', offsetUs: 500_000, value: 1, interpolation: 'linear' }, { capabilityId: 'transform.text.keyframe', offsetUs: 1_000_000, value: 1.2, interpolation: 'linear' }], animationIn: null, animationOut: null, templateToken: null }] },
  ]
  return finalizeRichTimeline(sealRichTimeline({ schemaVersion: 1, timelineId: 'jy084-text-keyframe-evidence', projectId: 'jy084-evidence', revision: 1, parentRevision: null, parentRevisionFingerprint: null, status: 'draft', createdAt: '2026-08-13T00:00:00.000Z', durationUs: 4_000_000, orientation: 'portrait', fps: { numerator: 30, denominator: 1 }, source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null }, tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks) }))
}

const projectTextKeyframeEvidenceTimeline = (profileId) => projectRichTimelineToJianyingExport(
  createTextKeyframeEvidenceTimeline(),
  { capabilityRegistry: createEditorCapabilityRegistry({ jianyingProfileId: profileId, privateCatalogCapabilities: ['transform.text.keyframe'] }) },
)

const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  if (!((desktop?.profileId === 'jianying-11-1-provisional' && desktop.version === '11.1.0.14287') || (desktop?.profileId === 'jianying-11-2-provisional' && desktop.version === '11.2.0.14339'))) throw new Error('JY084_PROFILE_UNSUPPORTED')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy084-text-keyframe-'))
  const mediaOwner = randomUUID(); let writer = null; let request = null; let released = false; let pendingPath = null
  try {
    await writeFile(path.join(mediaRoot, '.openvideo-jy084-owner'), mediaOwner, { encoding: 'utf8', mode: 0o600 })
    const video = path.join(mediaRoot, 'video.mp4'); const audio = path.join(mediaRoot, 'voice.wav')
    await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', video])
    await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audio])
    const projected = projectTextKeyframeEvidenceTimeline(desktop.profileId)
    const draftId = `OpenVideo-JY084-text-keyframe-${Date.now()}`
    const titleSegments = [{ segment_id: 'title-jy084', text: 'OpenVideo text keyframe', target_start_us: 0, target_duration_us: 4_000_000, keyframes: [{ capability_id: 'transform.text.keyframe', offset_us: 500_000, value: 1, interpolation: 'linear' }, { capability_id: 'transform.text.keyframe', offset_us: 1_000_000, value: 1.2, interpolation: 'linear' }]}]
    writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments, timelinePackaging: { ...projected.packaging, title_segments: titleSegments, text_animation_segments: [], sfx_segments: [], effect_segments: [], sticker_segments: [], filter_segments: [], animation_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
    request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: video }], voiceovers: [{ path: audio }] }
    const result = await writer.writeDraft(request)
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY084_WRITE_VERIFY_FAILED')
    const encrypted = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
    const inspectRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy084-text-keyframe-generate-'))
    let keyframeIds
    try {
      const plainPath = path.join(inspectRoot, 'draft_content.json')
      await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'), plainPath)
      const content = JSON.parse(await readFile(plainPath, 'utf8'))
      const title = content?.tracks?.find((track) => track?.name === 'title-primary')?.segments?.find((segment) => segment?.material_id)
      const keyframeList = title?.common_keyframes?.find((list) => list?.property_type === 'KFTypeScaleX')?.keyframe_list
      if (!Array.isArray(keyframeList) || keyframeList.length !== 2 || keyframeList.some((point) => typeof point?.id !== 'string' || !/^[a-f0-9]{32}$/u.test(point.id))) throw new Error('JY084_GENERATED_KEYFRAME_IDS_INVALID')
      keyframeIds = keyframeList.map((point, index) => ({ id: point.id, offset_us: index === 0 ? 500_000 : 1_000_000, initial_value: index === 0 ? 1 : 1.2 }))
    } finally { await rm(inspectRoot, { recursive: true, force: true }) }
    const root = loadLocalRuntimeConfig().dataRoot; const evidenceRoot = path.join(root, 'evidence', 'jy084-text-keyframe'); await mkdir(evidenceRoot, { recursive: true, mode: 0o700 }); pendingPath = path.join(evidenceRoot, 'pending.json')
    await writeFile(pendingPath, `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, media_owner: mediaOwner, profile_id: desktop.profileId, app_version: desktop.version, target_text: titleSegments[0].text, target_start_us: 0, target_duration_us: 4_000_000, keyframe_ids: keyframeIds, pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
    if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY084_RELEASE_FAILED')
    released = true
    process.stdout.write(JSON.stringify({ ok: true, manual_open_required: true, draft_prefix: 'OpenVideo-JY084-text-keyframe-', text: 'OpenVideo text keyframe', initial_scale_percent: 120, change_scale_percent: 140, time_seconds: 1, profile: desktop.profileId, version: desktop.version }) + '\n')
  } catch (error) {
    if (!released && pendingPath) await rm(pendingPath, { force: true })
    if (!released && writer && request) { try { await writer.cleanupDraft({ job_id: request.job_id }) } catch {} }
    if (!released) await rm(mediaRoot, { recursive: true, force: true })
    throw error
  }
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY084_DRAFT_FAILED' }) + '\n'); process.exitCode = 1 })
