import { execFile } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { createScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'

const execFileAsync = promisify(execFile)
const require = createRequire(import.meta.url)
const compatibilityManifest = require('../config/jianying-compatibility.json')
const durationUs = 4_000_000
const opacityOffsetUs = 1_000_000
const initialOpacity = 0.7
const persistedOpacity = 0.4
const evidenceProfileId = 'jianying-11-1-provisional'
const mediaRootPrefix = 'openvideo-jy029-opacity-'

const leasePath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy029-opacity', 'pending.json')
const privateAuditPath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy029-opacity', 'post-save.json')

export const createOpacityEvidenceTimeline = () => {
  const timeline = structuredClone(createScaleEvidenceTimeline())
  const video = timeline.tracks.find((track) => track.role === 'primary')
  video.segments[0].keyframes[0] = {
    capabilityId: 'opacity', offsetUs: opacityOffsetUs,
    value: initialOpacity, interpolation: 'linear',
  }
  timeline.status = 'draft'
  delete timeline.contentFingerprint
  delete timeline.revisionFingerprint
  timeline.capabilityRequirements = computeCapabilityRequirements(timeline.tracks)
  // Importing the canonical contract here keeps this evidence draft on the
  // same finalized RichTimeline path as production Planner output.
  return finalizeRichTimeline(sealRichTimeline(timeline))
}

const assertOwnedMediaRoot = (root) => {
  if (!path.isAbsolute(root) || path.dirname(root) !== tmpdir() || !path.basename(root).startsWith(mediaRootPrefix)) {
    throw Object.assign(new Error('unsafe JY-029 media root'), { code: 'JY029_MEDIA_ROOT_INVALID', stage: 'cleanup' })
  }
}

export const resolveOwnedOpacityMedia = (root, catalog, token) => {
  assertOwnedMediaRoot(root)
  const candidate = catalog[token]
  if (typeof candidate !== 'string' || !path.isAbsolute(candidate) || path.dirname(candidate) !== root) {
    throw Object.assign(new Error('JY-029 opaque media token unavailable'), { code: 'JY029_MEDIA_TOKEN_MISSING', stage: 'private-catalog' })
  }
  return candidate
}

const createSyntheticMedia = async (root) => {
  const videoPath = path.join(root, 'opacity-evidence.mp4')
  const audioPath = path.join(root, 'silent.wav')
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=green:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath])
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audioPath])
  return { videoPath, audioPath }
}

export const hasInitialOpacity = (content, expected = initialOpacity) => {
  const track = content?.tracks?.find((entry) => entry?.name === 'video-primary')
  const entries = track?.segments?.flatMap((segment) => segment?.common_keyframes ?? []) ?? []
  const alpha = entries.filter((entry) => entry?.property_type === 'KFTypeAlpha')
  const exact = (list, value) => list.length === 1 && list[0].keyframe_list?.length === 1 &&
    list[0].keyframe_list[0]?.time_offset === opacityOffsetUs &&
    Math.abs(list[0].keyframe_list[0]?.values?.[0] - value) <= 1e-9
  return exact(alpha, expected)
}

const persistLease = async (lease) => {
  assertOwnedMediaRoot(lease.mediaRoot)
  const target = leasePath()
  const root = path.dirname(target)
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(root)
  try {
    assertNoPendingOpacityLease(JSON.parse(await readFile(target, 'utf8')))
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  await writeFile(target, `${JSON.stringify({
    mediaRoot: lease.mediaRoot, draftId: lease.draftId, draftRoot: path.resolve(lease.draftRoot),
    profileId: lease.profileId, createdAt: new Date().toISOString(),
  })}\n`, { encoding: 'utf8', mode: 0o600 })
}

export const assertNoPendingOpacityLease = (lease) => {
  if (lease !== null && lease !== undefined) {
    throw Object.assign(new Error('pending JY-029 media cleanup required'), {
      code: 'JY029_PENDING_MEDIA_CLEANUP_REQUIRED', stage: 'cleanup',
    })
  }
}

const assertNoPendingOpacityLeaseOnDisk = async () => {
  try {
    assertNoPendingOpacityLease(JSON.parse(await readFile(leasePath(), 'utf8')))
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
}

export const assertBoundOpacityManualLease = (lease, desktop) => {
  if (
    typeof lease?.draftId !== 'string' || !/^OpenVideo-JY029-opacity-[0-9]+$/u.test(lease.draftId) ||
    typeof lease?.draftRoot !== 'string' || lease?.profileId !== evidenceProfileId ||
    desktop?.profileId !== evidenceProfileId || typeof desktop?.draftRoot !== 'string' ||
    path.resolve(lease.draftRoot) !== path.resolve(desktop.draftRoot)
  ) {
    throw Object.assign(new Error('bound JY-029 evidence lease required'), {
      code: 'JY029_EVIDENCE_BINDING_REQUIRED', stage: 'manual-evidence',
    })
  }
  return lease.draftId
}

const boundLease = async (desktop) => {
  let lease
  try { lease = JSON.parse(await readFile(leasePath(), 'utf8')) } catch (error) {
    if (error?.code === 'ENOENT') throw Object.assign(new Error('JY-029 evidence lease missing'), { code: 'JY029_EVIDENCE_BINDING_REQUIRED', stage: 'manual-evidence' })
    throw error
  }
  return { ...lease, draftId: assertBoundOpacityManualLease(lease, desktop) }
}

const verifyManual = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  const lease = await boundLease(desktop)
  const source = path.join(desktop.draftRoot, lease.draftId, 'draft_content.json')
  const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy029-opacity-verify-'))
  const plain = path.join(tempRoot, 'draft_content.json')
  try {
    const decryptMeta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(source, plain)
    if (decryptMeta.scheme !== 'encrypt_v2' && decryptMeta.decryptedFrom !== 'encrypt_v2') throw Object.assign(new Error('encrypt_v2 required'), { code: 'JY029_ENCRYPT_V2_REQUIRED', stage: 'manual-evidence' })
    const content = JSON.parse(await readFile(plain, 'utf8'))
    if (!hasInitialOpacity(content, persistedOpacity)) throw Object.assign(new Error('opacity edit mismatch'), { code: 'JY029_OPACITY_MISMATCH', stage: 'manual-evidence' })
    const audit = privateAuditPath()
    const root = path.dirname(audit)
    await mkdir(root, { recursive: true, mode: 0o700 })
    await securePrivateRuntimeRoot(root)
    await writeFile(audit, `${JSON.stringify({ profileId: desktop.profileId, desktopVersion: desktop.version ?? null, scheme: 'encrypt_v2', opacityOffsetUs, persistedOpacity, opened: true, edited: true, saved: true, reopened: true, keyframeCount: 1, verifiedAt: new Date().toISOString() })}\n`, { encoding: 'utf8', mode: 0o600 })
    return { scheme: 'encrypt_v2' }
  } finally { await rm(tempRoot, { recursive: true, force: true, maxRetries: 3 }) }
}

const cleanup = async () => {
  const lease = JSON.parse(await readFile(leasePath(), 'utf8'))
  assertOwnedMediaRoot(lease.mediaRoot)
  assertBoundOpacityManualLease(lease, {
    profileId: lease.profileId,
    draftRoot: lease.draftRoot,
  })
  await rm(lease.mediaRoot, { recursive: true, force: true, maxRetries: 3 })
  await rm(leasePath(), { force: true })
  return true
}

const main = async () => {
  if (process.argv.includes('--cleanup')) { process.stdout.write(`${JSON.stringify({ ok: true, cleanup_completed: await cleanup() })}\n`); return }
  if (process.argv.includes('--verify-manual')) { if (!['--opened', '--edited', '--saved', '--reopened'].every((flag) => process.argv.includes(flag))) throw Object.assign(new Error('manual flags required'), { code: 'JY029_MANUAL_EVIDENCE_REQUIRED', stage: 'manual-evidence' }); process.stdout.write(`${JSON.stringify({ ok: true, manual_evidence_verified: true, scheme: (await verifyManual()).scheme })}\n`); return }
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  if (desktop?.available !== true || desktop.profileId !== evidenceProfileId || typeof desktop.draftRoot !== 'string') throw Object.assign(new Error('unsupported Jianying profile'), { code: 'JY029_PROFILE_UNSUPPORTED', stage: 'desktop' })
  await assertNoPendingOpacityLeaseOnDisk()
  let mediaRoot = null; let retain = false
  try {
    const timeline = createOpacityEvidenceTimeline()
    const projected = projectRichTimelineToJianyingExport(timeline, { jianyingProfileId: desktop.profileId })
    mediaRoot = await mkdtemp(path.join(tmpdir(), mediaRootPrefix))
    const media = await createSyntheticMedia(mediaRoot)
    const draftId = `OpenVideo-JY029-opacity-${Date.now()}`
    const exportRequest = { preparation: projected.preparation }
    const pythonModuleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
    if (typeof pythonModuleRoot !== 'string' || !path.isAbsolute(pythonModuleRoot)) throw Object.assign(new Error('governed pyJianyingDraft root missing'), { code: 'JY029_UPSTREAM_MISSING', stage: 'runtime' })
    const catalog = { jy029_video: media.videoPath, jy029_voiceover: media.audioPath }
    const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonExecutable: process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE ?? 'python', pythonModuleRoot, timeoutMs: 90_000, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments: [], timelinePackaging: { ...projected.packaging, sfx_segments: [], effect_segments: [], sticker_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
    const input = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: exportRequest, orientation: 'portrait', materials: [{ path: resolveOwnedOpacityMedia(mediaRoot, catalog, 'jy029_video') }], voiceovers: [{ path: resolveOwnedOpacityMedia(mediaRoot, catalog, 'jy029_voiceover') }] }
    const result = await writer.writeDraft(input)
    if (await writer.verifyDraft({ job_id: input.job_id, request: { export_request: exportRequest }, write_result: result }) !== true || await writer.releaseDraft({ job_id: input.job_id, write_result: result }) !== true) throw Object.assign(new Error('draft write failed'), { code: 'JY029_DRAFT_WRITE_FAILED', stage: 'writer' })
    const content = JSON.parse(await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'), 'utf8'))
    if (!hasInitialOpacity(content)) throw Object.assign(new Error('initial opacity evidence absent'), { code: 'JY029_OPACITY_MISMATCH', stage: 'verify-content' })
    await persistLease({ mediaRoot, draftId, draftRoot: desktop.draftRoot, profileId: desktop.profileId }); retain = true
    process.stdout.write(`${JSON.stringify({ ok: true, manual_open_required: true, desktop_version: desktop.version ?? null, profile_id: desktop.profileId ?? null, initial_opacity: initialOpacity, opacity_offset_us: opacityOffsetUs })}\n`)
  } finally { if (mediaRoot && !retain) { assertOwnedMediaRoot(mediaRoot); await rm(mediaRoot, { recursive: true, force: true, maxRetries: 3 }) } }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? 'JY029_DRAFT_WRITE_FAILED', stage: error?.stage ?? 'generate' })}\n`); process.exitCode = 1 })
