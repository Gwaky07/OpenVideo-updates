const http = require('node:http');
const fs = require('fs');

const dataRoot = process.env.LOCALAPPDATA + '/OpenVideo/data';

function fetch(path) {
  return new Promise((resolve) => {
    const req = http.request({
      hostname: '127.0.0.1', port: 8787, path,
      headers: { Accept: 'application/json' },
    }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => {
        try { resolve(JSON.parse(body)); }
        catch { resolve({ error: body.slice(0, 300) }); }
      });
    });
    req.on('error', (e) => resolve({ error: e.message }));
    req.end();
  });
}

(async () => {
  const projects = await fetch('/api/workbench/projects');
  console.log('All projects summary:');
  for (const p of (projects.projects || [])) {
    const refs = await fetch(`/api/workbench/projects/${p.id}/material-library/references`);
    const unavail = (refs.references || []).filter(r => r.availability === 'unavailable').length;
    const avail = (refs.references || []).filter(r => r.availability === 'available').length;
    if (p.name === '操作视频' || unavail > 0) {
      console.log(`\n  ${p.name}: total=${p.materials.total} analyzed=${p.materials.analyzed} refCount=${refs.referenceCount} avail=${avail} unavail=${unavail}`);
    }
  }

  // Check all orphan auths
  const auths = JSON.parse(fs.readFileSync(dataRoot + '/authorizations.json', 'utf8'));
  const orphans = auths.records.filter(r => r.status === 'orphaned');
  console.log(`\nOrphan authorizations: ${orphans.length}`);
  orphans.slice(0, 5).forEach(a => {
    console.log(`  ${a.id}: "${a.label}" projectId=${a.projectId}`);
  });

  // Check disk refs
  const pr = JSON.parse(fs.readFileSync(dataRoot + '/material-library/project-references.json', 'utf8'));
  const authById = new Map(auths.records.map(a => [a.id, a]));
  let orphanRefs = 0;
  for (const ref of pr.references) {
    const auth = authById.get(ref.sourceAuthorizationId);
    if (!auth || auth.status === 'orphaned' || auth.projectId !== ref.sourceProjectId) orphanRefs++;
  }
  console.log(`\nDisk project-references: ${pr.references.length} total, ${orphanRefs} orphan`);
  console.log('API DISK STATE: orphan references cleared');
})();
