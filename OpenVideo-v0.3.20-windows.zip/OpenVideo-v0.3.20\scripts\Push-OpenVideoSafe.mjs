// REL-HOTFIX-021b / Push-OpenVideoSafe.mjs
//
// Node-based retry wrapper around `git push` for the OpenVideo rolling
// pipeline. It mirrors the PowerShell shim but runs cross-platform so
// the gateway test suite (which already uses node:test) can mock the
// spawn() without spawning a real PowerShell process.
//
// Hard constraints (see docs/tasks/REL-HOTFIX-021b-ssl-proxy-passthrough-push.md):
//   * Never invoke `git config --global`.
//   * Never edit any file outside `logRoot` (the OPENVIDEO_RUNTIME_DATA_ROOT path).
//   * Stay at the per-process level when overriding `http.proxy` (use
//     `git -c http.proxy= ...`).
//
// Parameters:
//   spawnImpl      optional override for spawn (tests inject a fake).
//   cwd            working directory for the inner git push (defaults to repo root).
//   remote         remote name (default 'origin').
//   refspec        refspec (default 'main').
//   env            optional extra env to merge in for spawned processes.
//   logRoot        directory for the regression log (defaults to
//                  `${OPENVIDEO_RUNTIME_DATA_ROOT || LOCALAPPDATA}/OpenVideo/logs/push-helper`).
//   logger         optional logger ({ info, warn, error }) for the caller.
//
// Returns: { ok: boolean, exit_code: number, log_file: string|null, attempts: [...] }.

import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync, statSync } from "node:fs";
import path from "node:path";
import os from "node:os";

// Mirrors scripts/Push-OpenVideoSafe.ps1's token list. Keep both in sync.
export const RETRY_TOKENS = Object.freeze([
  "Connection was reset",
  "OpenSSL SSL_read",
  "SSL_read: Connection",
  "Failed to connect",
  "Timed out",
  "Could not resolve host",
  "proxyconnect",
  "Port 443",
  "Connection aborted",
  "unexpected EOF",
  "gnutls_handshake"
]);

const PROXY_OFF_ENV = Object.freeze({
  GIT_HTTP_LOW_TIME_LIMIT: "20",
  // Use the per-process -c override form so we never persist anything.
});

export function classifyPushOutput(stderrText) {
  if (!stderrText) return false;
  for (const token of RETRY_TOKENS) {
    if (stderrText.includes(token)) return true;
  }
  return false;
}

export function redactStderr(stderrText) {
  if (!stderrText) return "";
  return String(stderrText)
    // GitHub Personal Access Tokens embedded as userinfo in a URL.
    .replace(/([a-z]+:\/\/[^:@\/\s]+:)(ghp_[A-Za-z0-9]+|gho_[A-Za-z0-9]+|ghu_[A-Za-z0-9]+|ghs_[A-Za-z0-9]+|ghr_[A-Za-z0-9]+|github_pat_[A-Za-z0-9_]+)(@)/g, "$1<redacted>$3")
    // Generic password-style userinfo (alice:verylongsecret@host).
    .replace(/([a-z]+:\/\/[^:@\/\s]+:)([^@]{6,})(@)/g, "$1<redacted>$3")
    // Query string tokens.
    .replace(/[?&](?:gh_[a-z0-9_]+|access_token|token|password)=[^&\r\n\s]+/g, "$1=<redacted>")
    // ssh://user@host
    .replace(/ssh:\/\/[^@\s]+@/g, "ssh://<redacted>@");
}

export function resolveLogRoot(env = process.env) {
  const runtimeRoot = env.OPENVIDEO_RUNTIME_DATA_ROOT || path.join(env.LOCALAPPDATA || os.homedir(), "OpenVideo");
  const root = path.join(runtimeRoot, "logs", "push-helper");
  if (!existsSync(root)) mkdirSync(root, { recursive: true });
  return root;
}

function runGit(args, { cwd, env, spawnImpl = spawn }) {
  return new Promise((resolve) => {
    const child = spawnImpl("git", args, {
      cwd,
      env: { ...process.env, ...PROXY_OFF_ENV, ...(env || {}) },
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => (stdout += chunk.toString("utf8")));
    child.stderr.on("data", (chunk) => (stderr += chunk.toString("utf8")));
    child.on("error", (error) => {
      resolve({ exit_code: -1, stdout, stderr: stderr + `\nspawn_error: ${error.message}` });
    });
    child.on("close", (code) => resolve({ exit_code: typeof code === "number" ? code : 1, stdout, stderr }));
  });
}

function gitArgs({ remote, refspec, proxyOff, allowForce }) {
  const args = ["push"];
  if (allowForce) args.push("--force-with-lease");
  // Per-process override: never written to .gitconfig.
  if (proxyOff) {
    args.splice(args.length, 0, "-c", "http.proxy=", "-c", "https.proxy=", "-c", "http.sslverify=true");
  }
  args.push(remote, refspec);
  return args;
}

function buildLogEntry({ event, remote, refspec, attempt, proxyMode, outcome, durationMs, exitCode, stderr }) {
  const timestamp = new Date().toISOString();
  return JSON.stringify({
    timestamp,
    event,
    remote,
    refspec,
    attempt,
    proxy_mode: proxyMode,
    outcome,
    duration_ms: durationMs,
    exit_code: exitCode,
    last_stderr: redactStderr(stderr)
  });
}

function appendLog(logRoot, entry) {
  // Append all entries from a single push() invocation to the same
  // JSONL file so callers can `tail -1` for the latest attempt or
  // `wc -l` for the full call. File name uses the invocation's first
  // timestamp and the current PID; subsequent entries reuse it.
  const target = pushOpenVideoSafe._activeLogFile
    || (pushOpenVideoSafe._activeLogFile = (() => {
      // Use a UTC stamp filename-safe across Windows/macOS/Linux.
      const d = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const stamp = `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
      return path.join(logRoot, `${stamp}-pid${process.pid}.jsonl`);
    })());
  if (!existsSync(target)) {
    writeFileSync(target, entry + "\n", { encoding: "utf8", mode: 0o600 });
  } else {
    appendFileSync(target, entry + "\n", { encoding: "utf8" });
  }
  return target;
}

export async function pushOpenVideoSafe({
  spawnImpl,
  cwd = process.cwd(),
  remote = "origin",
  refspec = "main",
  refspecAlias,
  logRoot,
  env,
  logger = console,
  skipRetry = false,
  forceWithLease = false,
  forceWithLeaseToken = process.env.OPENVIDEO_FORCE_WITH_LEASE_TOKEN || null,
  dryRun = false
} = {}) {
  // Each invocation gets a fresh log file (PID + initial timestamp).
  pushOpenVideoSafe._activeLogFile = null;
  if (refspecAlias && refspec === "main") refspec = `task/${refspecAlias}`;

  if (refspec === "main" && forceWithLease && !forceWithLeaseToken) {
    return { ok: false, exit_code: 2, log_file: null, attempts: [], error: "OPENVIDEO_PUSH_FORCE_TOKEN_MISSING" };
  }

  const resolvedLogRoot = logRoot || resolveLogRoot(process.env);
  const attemptOneArgs = gitArgs({ remote, refspec, proxyOff: false, allowForce: forceWithLease });
  if (dryRun) attemptOneArgs.splice(1, 0, "--dry-run");

  const startFirst = Date.now();
  const first = await runGit(attemptOneArgs, { cwd, env, spawnImpl });
  const durationFirst = Date.now() - startFirst;
  if (first.exit_code === 0) {
    logger.info?.(`OPENVIDEO_PUSH_FIRST_ATTEMPT_OK remote=${remote} refspec=${refspec} duration_ms=${durationFirst}`);
    return { ok: true, exit_code: 0, log_file: null, attempts: [{ index: 1, mode: "inherit", exit_code: 0, duration_ms: durationFirst }] };
  }

  const shouldRetry = classifyPushOutput(first.stderr) && !skipRetry;
  if (!shouldRetry) {
    logger.error?.(`OPENVIDEO_PUSH_BLOCKED first_attempt remote=${remote} refspec=${refspec} stderr=${redactStderr(first.stderr).slice(0, 240)}`);
    return { ok: false, exit_code: first.exit_code, log_file: null, attempts: [{ index: 1, mode: "inherit", exit_code: first.exit_code, duration_ms: durationFirst, stderr: redactStderr(first.stderr) }] };
  }

  // Fall back to per-process proxy override.
  const logEntry1 = buildLogEntry({
    event: "retry_invoked_proxy_offline",
    remote,
    refspec,
    attempt: 1,
    proxyMode: "inherit",
    outcome: "failed",
    durationMs: durationFirst,
    exitCode: first.exit_code,
    stderr: first.stderr
  });
  const logFile1 = appendLog(resolvedLogRoot, logEntry1);

  const attemptTwoArgs = gitArgs({ remote, refspec, proxyOff: true, allowForce: forceWithLease });
  if (dryRun) attemptTwoArgs.splice(1, 0, "--dry-run");
  const startSecond = Date.now();
  const second = await runGit(attemptTwoArgs, { cwd, env, spawnImpl });
  const durationSecond = Date.now() - startSecond;
  const outcome = second.exit_code === 0 ? "succeeded" : "failed";
  const logEntry2 = buildLogEntry({
    event: `retry_${outcome}_proxy_offline`,
    remote,
    refspec,
    attempt: 2,
    proxyMode: "override_off",
    outcome,
    durationMs: durationSecond,
    exitCode: second.exit_code,
    stderr: second.stderr
  });
  const logFile2 = appendLog(resolvedLogRoot, logEntry2);

  if (second.exit_code === 0) {
    logger.info?.(`OPENVIDEO_PUSH_RETRY_OK remote=${remote} refspec=${refspec} duration_ms=${durationSecond}`);
    return {
      ok: true,
      exit_code: 0,
      log_file: logFile2,
      attempts: [
        { index: 1, mode: "inherit", exit_code: first.exit_code, duration_ms: durationFirst, log_file: logFile1 },
        { index: 2, mode: "override_off", exit_code: second.exit_code, duration_ms: durationSecond, log_file: logFile2 }
      ]
    };
  }

  logger.error?.(`OPENVIDEO_PUSH_BLOCKED_PROXY_AND_DIRECT_BOTH_FAILED remote=${remote} refspec=${refspec}`);
  return {
    ok: false,
    exit_code: 100,
    log_file: logFile2,
    attempts: [
      { index: 1, mode: "inherit", exit_code: first.exit_code, duration_ms: durationFirst, log_file: logFile1 },
      { index: 2, mode: "override_off", exit_code: second.exit_code, duration_ms: durationSecond, log_file: logFile2 }
    ]
  };
}

// CLI entry: `node scripts/Push-OpenVideoSafe.mjs [remote refspec]`.
// Exit codes mirror the PowerShell shim (0 / 2 / 100).
if (process.argv[1] && process.argv[1].endsWith("Push-OpenVideoSafe.mjs")) {
  const [, , remoteArg, refspecArg] = process.argv;
  const result = await pushOpenVideoSafe({
    remote: remoteArg || "origin",
    refspec: refspecArg || "main",
    dryRun: process.argv.includes("--dry-run"),
    skipRetry: process.argv.includes("--skip-retry")
  });
  process.stdout.write(JSON.stringify(result) + "\n");
  process.exit(result.ok ? 0 : result.exit_code);
}
