import { isAbsolute, normalize, sep } from 'node:path'

const finiteNumber = (value) => typeof value === 'number' && Number.isFinite(value)

export const QA009_MINIMUM_LONG_VIDEO_SECONDS = 60
export const QA009_MAXIMUM_SHORT_SCENE_SECONDS = 10

export const QA009R_QUALITY_PROFILE = 'qa009r-education-long-video-v1'

export const QA009R_QUALITY_THRESHOLDS = Object.freeze({
  ocrKeywordRecallRate: 0.9,
  asrSceneHitRate: 0.85,
  top1HitRate: 0.85,
  top3HitRate: 0.95,
  hardQueryRangeIou: 0.7,
  negativeFalseRecallRate: 0.05,
  acceptedAsrHallucinationCount: 0,
})

const QA009R_MINIMUM_QUERY_COUNTS = Object.freeze({
  positive: 20,
  negative: 20,
  ocr: 10,
  asr: 10,
  hard: 10,
})

const RUN_CONFIGURATIONS = Object.freeze({
  'long-acceptance': Object.freeze({
    acceptanceEligible: true,
    projectId: 'qa009-real-material-analysis',
    evidenceFileName: 'acceptance.json',
  }),
  'short-regression': Object.freeze({
    acceptanceEligible: false,
    projectId: 'qa009-short-material-regression',
    evidenceFileName: 'short-regression.json',
  }),
})

const validRelativePath = (value) => {
  if (typeof value !== 'string' || value.trim().length === 0 || isAbsolute(value)) return false
  const normalized = normalize(value)
  return normalized !== '..' && !normalized.startsWith(`..${sep}`)
}

export const parseQa009RunArguments = (arguments_) => {
  if (!Array.isArray(arguments_)) throw new Error('QA009_RUN_ARGUMENTS_INVALID')
  const positionalArguments = arguments_.filter((argument) => !argument.startsWith('--'))
  const optionArguments = arguments_.filter((argument) => argument.startsWith('--'))
  const modeArguments = optionArguments.filter((argument) => argument.startsWith('--mode='))
  if (
    positionalArguments.length !== 3 ||
    optionArguments.length !== modeArguments.length ||
    modeArguments.length > 1
  ) throw new Error('QA009_RUN_ARGUMENTS_INVALID')
  if (!positionalArguments.every((argument) => isAbsolute(argument))) {
    throw new Error('QA009_ABSOLUTE_ROOTS_REQUIRED')
  }

  const runMode = modeArguments[0]?.slice('--mode='.length) || 'long-acceptance'
  const configuration = RUN_CONFIGURATIONS[runMode]
  if (!configuration) throw new Error('QA009_RUN_MODE_INVALID')
  return {
    runMode,
    acceptanceEligible: configuration.acceptanceEligible,
    dataRootArgument: positionalArguments[0],
    materialRootArgument: positionalArguments[1],
    benchmarkSpecArgument: positionalArguments[2],
    projectId: configuration.projectId,
    evidenceFileName: configuration.evidenceFileName,
  }
}

export const validateQa009BenchmarkSpec = (benchmarkSpec, { runMode }) => {
  if (!RUN_CONFIGURATIONS[runMode]) throw new Error('QA009_RUN_MODE_INVALID')
  const isLongAcceptance = runMode === 'long-acceptance'
  const modeSpecificFieldsAreValid = isLongAcceptance
    ? (
        validRelativePath(benchmarkSpec?.targetRelativePath) &&
        finiteNumber(benchmarkSpec?.minimumAssetDurationSeconds) &&
        benchmarkSpec.minimumAssetDurationSeconds >= QA009_MINIMUM_LONG_VIDEO_SECONDS
      )
    : (
        benchmarkSpec?.targetRelativePath === undefined &&
        benchmarkSpec?.minimumAssetDurationSeconds === undefined
      )
  if (
    ![2, 3].includes(benchmarkSpec?.schemaVersion) ||
    benchmarkSpec?.benchmarkMode !== runMode ||
    !modeSpecificFieldsAreValid ||
    !finiteNumber(benchmarkSpec.negativeConfidenceThreshold) ||
    benchmarkSpec.negativeConfidenceThreshold <= 0 ||
    benchmarkSpec.negativeConfidenceThreshold >= 1 ||
    !Array.isArray(benchmarkSpec.queries) ||
    benchmarkSpec.queries.filter((query) => query?.expectation === 'positive').length < 3 ||
    benchmarkSpec.queries.filter((query) => query?.expectation === 'negative').length < 1
  ) throw new Error('QA009_BENCHMARK_SPEC_INVALID')

  const queries = benchmarkSpec.queries.map((query) => {
    if (
      typeof query?.text !== 'string' ||
      query.text.trim().length === 0 ||
      !['positive', 'negative'].includes(query.expectation) ||
      !Array.isArray(query.evidenceKeywords) ||
      query.evidenceKeywords.length === 0 ||
      !query.evidenceKeywords.every((keyword) => typeof keyword === 'string' && keyword.trim().length > 0)
    ) throw new Error('QA009_BENCHMARK_SPEC_INVALID')
    if (query.expectation === 'positive') {
      const targetRelativePath = query.targetRelativePath ?? benchmarkSpec.targetRelativePath
      if (
        !validRelativePath(targetRelativePath) ||
        (!isLongAcceptance && query.targetRelativePath === undefined) ||
        (isLongAcceptance && query.targetRelativePath !== undefined && query.targetRelativePath !== benchmarkSpec.targetRelativePath) ||
        !finiteNumber(query.expectedWindow?.start) ||
        !finiteNumber(query.expectedWindow?.end) ||
        query.expectedWindow.start < 0 ||
        query.expectedWindow.end <= query.expectedWindow.start ||
        !finiteNumber(query.minimumOverlapSeconds ?? 1) ||
        (query.minimumOverlapSeconds ?? 1) <= 0
      ) throw new Error('QA009_BENCHMARK_SPEC_INVALID')
      if (
        query.evidenceChannel !== undefined &&
        !['ocr', 'asr', 'either'].includes(query.evidenceChannel)
      ) throw new Error('QA009_BENCHMARK_SPEC_INVALID')
      if (query.difficulty !== undefined && !['standard', 'hard'].includes(query.difficulty)) {
        throw new Error('QA009_BENCHMARK_SPEC_INVALID')
      }
      return { ...query, targetRelativePath }
    }
    if (query.targetRelativePath !== undefined || query.expectedWindow !== undefined) {
      throw new Error('QA009_BENCHMARK_SPEC_INVALID')
    }
    return query
  })

  if (benchmarkSpec.qualityProfile === QA009R_QUALITY_PROFILE) {
    const positiveQueries = queries.filter((query) => query.expectation === 'positive')
    const negativeQueries = queries.filter((query) => query.expectation === 'negative')
    const counts = {
      positive: positiveQueries.length,
      negative: negativeQueries.length,
      ocr: positiveQueries.filter((query) => query.evidenceChannel === 'ocr').length,
      asr: positiveQueries.filter((query) => query.evidenceChannel === 'asr').length,
      hard: positiveQueries.filter((query) => query.difficulty === 'hard').length,
    }
    const normalizedQueries = queries.map((query) =>
      query.text.trim().toLocaleLowerCase('zh-CN').replace(/\s+/gu, ' '))
    const positiveWindows = positiveQueries.map((query) => [
      query.targetRelativePath,
      query.expectedWindow.start,
      query.expectedWindow.end,
      query.evidenceChannel,
      [...query.evidenceKeywords].map((keyword) => keyword.trim().toLocaleLowerCase('zh-CN')).sort().join('\u0001'),
    ].join('\u0000'))
    if (
      benchmarkSpec.schemaVersion !== 3 ||
      !['long-acceptance', 'short-regression'].includes(runMode) ||
      !Array.isArray(benchmarkSpec.asrHallucinationPhrases) ||
      benchmarkSpec.asrHallucinationPhrases.length === 0 ||
      !benchmarkSpec.asrHallucinationPhrases.every((phrase) => (
        typeof phrase === 'string' && phrase.trim().length > 0
      )) ||
      new Set(normalizedQueries).size !== normalizedQueries.length ||
      new Set(positiveWindows).size !== positiveWindows.length ||
      Object.entries(QA009R_MINIMUM_QUERY_COUNTS).some(([key, minimum]) => counts[key] < minimum)
    ) throw new Error('QA009R_BENCHMARK_SPEC_INVALID')
  } else if (benchmarkSpec.qualityProfile !== undefined) {
    throw new Error('QA009_QUALITY_PROFILE_INVALID')
  }

  return queries
}

export const evaluateQa009RQuality = (metrics) => {
  const gates = Object.fromEntries(Object.entries(QA009R_QUALITY_THRESHOLDS).map(([key, threshold]) => {
    const value = metrics?.[key]
    const passed = key === 'negativeFalseRecallRate'
      ? finiteNumber(value) && value <= threshold
      : key === 'acceptedAsrHallucinationCount'
        ? Number.isInteger(value) && value === threshold
        : finiteNumber(value) && value >= threshold
    return [key, { value: value ?? null, threshold, passed }]
  }))
  return {
    profile: QA009R_QUALITY_PROFILE,
    passed: Object.values(gates).every((gate) => gate.passed),
    gates,
  }
}

export const rerankCandidateIdsAreApplicable = (candidateIds, submittedCandidateIds) => (
  Array.isArray(candidateIds) &&
  candidateIds.length > 0 &&
  Array.isArray(submittedCandidateIds) &&
  submittedCandidateIds.length > 0 &&
  candidateIds.every((id) => typeof id === 'string' && submittedCandidateIds.includes(id)) &&
  new Set(candidateIds).size === candidateIds.length
)

export const classifyQa009Verdicts = ({ runMode, hardSafetyPassed, qualityPassed }) => {
  if (!RUN_CONFIGURATIONS[runMode]) throw new Error('QA009_RUN_MODE_INVALID')
  const regressionVerdict = hardSafetyPassed && qualityPassed
    ? 'PASS'
    : hardSafetyPassed ? 'PARTIAL' : 'FAIL'
  return {
    qa009Verdict: runMode === 'long-acceptance'
      ? regressionVerdict
      : 'NOT_EVALUATED',
    regressionVerdict,
  }
}

export const createQa009ReportClassification = ({
  runMode,
  hardSafetyPassed,
  qualityPassed,
  longVideoGatePassed,
}) => {
  if (!RUN_CONFIGURATIONS[runMode]) throw new Error('QA009_RUN_MODE_INVALID')
  const configuration = RUN_CONFIGURATIONS[runMode]
  const acceptanceQualityPassed = qualityPassed && (
    runMode !== 'long-acceptance' || longVideoGatePassed === true
  )
  const { qa009Verdict, regressionVerdict } = classifyQa009Verdicts({
    runMode,
    hardSafetyPassed,
    qualityPassed: acceptanceQualityPassed,
  })
  return {
    runMode,
    acceptanceEligible: configuration.acceptanceEligible,
    qa009Verdict,
    regressionVerdict,
    evidenceFileName: configuration.evidenceFileName,
    benchmark: {
      benchmarkMode: runMode,
      datasetKind: runMode === 'long-acceptance'
        ? 'qa009-long-video-acceptance'
        : 'user-specified-short-materials',
      longVideoBenchmark: runMode === 'long-acceptance',
      longVideoRequirementSeconds: QA009_MINIMUM_LONG_VIDEO_SECONDS,
      longVideoGateEvaluated: runMode === 'long-acceptance',
      longVideoGateSatisfied: runMode === 'long-acceptance' && Boolean(longVideoGatePassed),
    },
  }
}

// Benchmark evidence must come from independently observable OCR/ASR signals.
// Model-generated summaries and taxonomy labels are intentionally excluded so
// a hallucinated tag cannot prove its own retrieval hit.
const normalizedEvidenceText = (value) => [value]
  .filter((value) => typeof value === 'string')
  .join('\n')
  .toLocaleLowerCase('zh-CN')

const evidenceText = (candidate) => normalizedEvidenceText([
  candidate?.ocrText,
  candidate?.asrTranscript,
].filter((value) => typeof value === 'string').join('\n'))

export const rangeOverlapSeconds = (left, right) => {
  if (
    !finiteNumber(left?.start) ||
    !finiteNumber(left?.end) ||
    !finiteNumber(right?.start) ||
    !finiteNumber(right?.end) ||
    left.end <= left.start ||
    right.end <= right.start
  ) return 0
  return Math.max(0, Math.min(left.end, right.end) - Math.max(left.start, right.start))
}

export const rangeIntersectionOverUnion = (left, right) => {
  const intersection = rangeOverlapSeconds(left, right)
  if (intersection === 0) return 0
  const union = Math.max(left.end, right.end) - Math.min(left.start, right.start)
  return union > 0 ? intersection / union : 0
}

const hasKeywordEvidence = (candidate, keywords) => {
  if (!Array.isArray(keywords) || keywords.length === 0) return false
  const haystack = evidenceText(candidate)
  return keywords.some((keyword) => (
    typeof keyword === 'string' &&
    keyword.trim().length > 0 &&
    haystack.includes(keyword.trim().toLocaleLowerCase('zh-CN'))
  ))
}

const hasKeywordEvidenceIn = (value, keywords) => {
  if (!Array.isArray(keywords) || keywords.length === 0) return false
  const haystack = normalizedEvidenceText(value)
  return keywords.some((keyword) => (
    typeof keyword === 'string' &&
    keyword.trim().length > 0 &&
    haystack.includes(keyword.trim().toLocaleLowerCase('zh-CN'))
  ))
}

const validCandidateRange = (candidate) => (
  finiteNumber(candidate?.start) &&
  finiteNumber(candidate?.end) &&
  candidate.end > candidate.start
)

export const evaluateQa009Query = ({
  query,
  candidates,
  expectedAssetId,
  negativeConfidenceThreshold,
}) => {
  const topThree = candidates.slice(0, 3)
  if (query.expectation === 'positive') {
    const expectedWindow = query.expectedWindow
    const minimumOverlapSeconds = query.minimumOverlapSeconds ?? 1
    const evaluatedCandidates = topThree.map((candidate) => {
      const overlapSeconds = rangeOverlapSeconds(candidate, expectedWindow)
      const intersectionOverUnion = rangeIntersectionOverUnion(candidate, expectedWindow)
      const assetMatches = candidate.assetId === expectedAssetId
      const ocrEvidenceMatches = hasKeywordEvidenceIn(candidate.ocrText, query.evidenceKeywords)
      const asrEvidenceMatches = hasKeywordEvidenceIn(candidate.asrTranscript, query.evidenceKeywords)
      const evidenceMatches = query.evidenceChannel === 'ocr'
        ? ocrEvidenceMatches
        : query.evidenceChannel === 'asr'
          ? asrEvidenceMatches
          : ocrEvidenceMatches || asrEvidenceMatches
      return {
        ...candidate,
        benchmark: {
          assetMatches,
          evidenceMatches,
          ocrEvidenceMatches,
          asrEvidenceMatches,
          overlapSeconds,
          intersectionOverUnion,
          hit: assetMatches && evidenceMatches && overlapSeconds >= minimumOverlapSeconds,
        },
      }
    })
    return {
      query: query.text,
      expectation: query.expectation,
      evidenceChannel: query.evidenceChannel,
      difficulty: query.difficulty,
      expectedWindow,
      minimumOverlapSeconds,
      top1Hit: evaluatedCandidates[0]?.benchmark.hit === true,
      top3Hit: evaluatedCandidates.some((candidate) => candidate.benchmark.hit),
      correctlyRejected: false,
      negativeReturnedCandidateCount: 0,
      negativeUnsafeCandidateCount: 0,
      candidates: evaluatedCandidates,
      allCandidates: candidates,
    }
  }

  // A returned candidate is consumable by downstream callers. Confidence
  // cannot retroactively turn it into a rejection; production search must
  // filter it before this policy sees it.
  const evaluatedCandidates = candidates.map((candidate) => {
    const evidenceMatches = hasKeywordEvidence(candidate, query.evidenceKeywords)
    const belowConfidenceThreshold = (
      finiteNumber(candidate.matchScore) &&
      candidate.matchScore < negativeConfidenceThreshold
    )
    return {
      ...candidate,
      benchmark: {
        evidenceMatches,
        belowConfidenceThreshold,
        // Returned candidates below the configured confidence threshold are
        // rejected by search. Keep incidental keyword matches for audit, but
        // do not turn low-confidence substrings into false positive recalls.
        safelyRejected: false,
      },
    }
  })
  const unsafeCandidates = evaluatedCandidates
  return {
    query: query.text,
    expectation: query.expectation,
    evidenceChannel: query.evidenceChannel,
    difficulty: query.difficulty,
    top1Hit: false,
    top3Hit: false,
    correctlyRejected: evaluatedCandidates.length === 0,
    negativeReturnedCandidateCount: evaluatedCandidates.length,
    negativeUnsafeCandidateCount: unsafeCandidates.length,
    candidates: evaluatedCandidates,
    allCandidates: candidates,
  }
}

export const candidateIsInternalAssetRange = ({
  candidate,
  assetDurationSeconds,
}) => (
  validCandidateRange(candidate) &&
  finiteNumber(assetDurationSeconds) &&
  assetDurationSeconds > 0 &&
  candidate.start > 0 &&
  candidate.end < assetDurationSeconds &&
  candidate.end - candidate.start < assetDurationSeconds
)

export const candidateIsBoundedSourceRange = ({
  candidate,
  assetDurationSeconds,
  maximumDurationSeconds = 8,
}) => (
  validCandidateRange(candidate) &&
  finiteNumber(assetDurationSeconds) &&
  assetDurationSeconds > 0 &&
  finiteNumber(maximumDurationSeconds) &&
  maximumDurationSeconds > 0 &&
  candidate.start >= 0 &&
  candidate.end <= assetDurationSeconds &&
  candidate.end - candidate.start <= maximumDurationSeconds
)

export const candidateIsWholeAssetRange = ({
  candidate,
  assetDurationSeconds,
  toleranceSeconds = 0.05,
}) => (
  validCandidateRange(candidate) &&
  finiteNumber(assetDurationSeconds) &&
  assetDurationSeconds > 0 &&
  finiteNumber(toleranceSeconds) &&
  toleranceSeconds >= 0 &&
  candidate.start <= toleranceSeconds &&
  candidate.end >= assetDurationSeconds - toleranceSeconds
)

export const candidateIsInternalLongVideoRange = ({
  candidate,
  assetDurationSeconds,
  minimumAssetDurationSeconds,
}) => (
  candidateIsInternalAssetRange({ candidate, assetDurationSeconds }) &&
  finiteNumber(minimumAssetDurationSeconds) &&
  assetDurationSeconds >= Math.max(
    QA009_MINIMUM_LONG_VIDEO_SECONDS,
    minimumAssetDurationSeconds,
  )
)

export const selectedCandidateIsBenchmarkHit = ({ selectedCandidate, benchmarkCandidates }) => {
  if (!selectedCandidate || !Array.isArray(benchmarkCandidates)) return false
  return benchmarkCandidates.some((candidate) => (
    candidate?.benchmark?.hit === true &&
    candidate.id === selectedCandidate.candidate_id &&
    candidate.assetId === selectedCandidate.asset_id &&
    candidate.id === selectedCandidate.scene_id &&
    candidate.start === selectedCandidate.start &&
    candidate.end === selectedCandidate.end
  ))
}
