param(
    [int]$MaxFiles = 4096,
    [int]$MaxFileBytes = 4194304,
    [int]$MaxTotalBytes = 67108864
)
$ErrorActionPreference = 'Stop'
$type = @"
using System;
using System.IO;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
public static class OpenVideoNativeBatchRead {
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern uint GetFinalPathNameByHandle(SafeFileHandle handle, System.Text.StringBuilder path, uint length, uint flags);
  [StructLayout(LayoutKind.Sequential)]
  struct ByHandleFileInformation { public uint FileAttributes; public System.Runtime.InteropServices.ComTypes.FILETIME CreationTime; public System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime; public System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime; public uint VolumeSerialNumber; public uint FileSizeHigh; public uint FileSizeLow; public uint NumberOfLinks; public uint FileIndexHigh; public uint FileIndexLow; }
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool GetFileInformationByHandle(SafeFileHandle handle, out ByHandleFileInformation information);
  static string FinalPath(SafeFileHandle handle) { var b=new System.Text.StringBuilder(32768); var n=GetFinalPathNameByHandle(handle,b,(uint)b.Capacity,0); if(n==0 || n>=b.Capacity) throw new IOException("path failed"); return b.ToString(); }
  public static byte[] Read(string name, string rootName, int maxBytes) {
    const uint GENERIC_READ=0x80000000, FILE_READ_ATTRIBUTES=0x80, FILE_SHARE_READ=1, FILE_SHARE_WRITE=2, FILE_SHARE_DELETE=4, OPEN_EXISTING=3, OPEN_REPARSE_POINT=0x00200000, BACKUP_SEMANTICS=0x02000000;
    using (var root=CreateFile(rootName, FILE_READ_ATTRIBUTES, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE, IntPtr.Zero, OPEN_EXISTING, OPEN_REPARSE_POINT|BACKUP_SEMANTICS, IntPtr.Zero))
    using (var handle=CreateFile(name, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE, IntPtr.Zero, OPEN_EXISTING, OPEN_REPARSE_POINT, IntPtr.Zero)) {
      if (root.IsInvalid || handle.IsInvalid) throw new IOException("open failed");
      var rootFinal=FinalPath(root).TrimEnd('\\');
      var fileFinal=FinalPath(handle);
      if (!fileFinal.StartsWith(rootFinal+"\\", StringComparison.OrdinalIgnoreCase)) throw new IOException("outside root");
      ByHandleFileInformation information;
      if (!GetFileInformationByHandle(handle, out information) || information.NumberOfLinks != 1) throw new IOException("link invalid");
      using (var stream=new FileStream(handle, FileAccess.Read)) {
        if (stream.Length < 0 || stream.Length > maxBytes) throw new IOException("JY018_NATIVE_FILE_TOO_LARGE");
        using (var memory=new MemoryStream()) {
          var buffer = new byte[81920];
          long total = 0;
          while (true) {
            var remaining = maxBytes - total;
            if (remaining <= 0) {
              if (stream.ReadByte() >= 0) throw new IOException("JY018_NATIVE_FILE_TOO_LARGE");
              break;
            }
            var requested = (int)Math.Min((long)buffer.Length, remaining);
            var read = stream.Read(buffer, 0, requested);
            if (read <= 0) break;
            total += read;
            memory.Write(buffer, 0, read);
          }
          return memory.ToArray();
        }
      }
    }
  }
}
"@
if (-not ('OpenVideoNativeBatchRead' -as [type])) { Add-Type -TypeDefinition $type }

try {
    $encoded = [Console]::In.ReadToEnd()
    $payload = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($encoded)) | ConvertFrom-Json
    $items = @($payload.items)
    if ($payload.schema_version -ne 1 -or $items.Count -gt $MaxFiles) { throw 'invalid input' }
    [long]$total = 0
    for ($index = 0; $index -lt $items.Count; $index += 1) {
        try {
            $item = $items[$index]
            if ([string]::IsNullOrWhiteSpace([string]$item.path) -or [string]::IsNullOrWhiteSpace([string]$item.root)) { throw 'invalid item' }
            $bytes = [OpenVideoNativeBatchRead]::Read([string]$item.path, [string]$item.root, $MaxFileBytes)
            $total += $bytes.Length
            if ($total -gt $MaxTotalBytes) { throw 'JY018_NATIVE_TOTAL_TOO_LARGE' }
            @{ index = $index; content = [Convert]::ToBase64String($bytes) } | ConvertTo-Json -Compress
        } catch {
            $errorMatch = [regex]::Match($_.Exception.ToString(), '\b(?:JY018|JY135)_NATIVE_[A-Z_]+\b')
            $errorCode = if ($errorMatch.Success) { $errorMatch.Value } else { 'JY135_NATIVE_READ_FAILED' }
            @{ index = $index; error = $errorCode } | ConvertTo-Json -Compress
            exit 2
        }
    }
} catch {
    @{ index = -1; error = 'JY135_NATIVE_READ_FAILED' } | ConvertTo-Json -Compress
    exit 2
}
