import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rename, rm, rmdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { validateJianyingChromaContent } from '../apps/gateway/src/jianying-chroma-evidence.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY082_MANUAL_ATTESTATION_REQUIRED')
  const root = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy082-chroma')
  const pendingPath = path.join(root, 'pending.json'); const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  if (desktop?.profileId !== pending.profile_id || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root)) throw new Error('JY082_EVIDENCE_BINDING_INVALID')
  const mediaRoot = path.resolve(pending.media_root); const canonicalTemp = await realpath(tmpdir()); const canonicalMedia = await realpath(mediaRoot)
  const relative = path.relative(canonicalTemp, canonicalMedia); const metadata = await lstat(mediaRoot)
  const mediaOwner = await readFile(path.join(mediaRoot, '.openvideo-jy082-owner'), 'utf8')
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative) || !path.basename(canonicalMedia).startsWith('openvideo-jy082-chroma-') || !metadata.isDirectory() || metadata.isSymbolicLink() || mediaOwner !== pending.media_owner) throw new Error('JY082_TEMP_OWNERSHIP_INVALID')
  const encryptedPath = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json'); const encrypted = await readFile(encryptedPath)
  const postFingerprint = createHash('sha256').update(encrypted).digest('hex'); if (postFingerprint === pending.pre_open_fingerprint) throw new Error('JY082_MANUAL_EDIT_NOT_PERSISTED')
  const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy082-verify-'))
  try {
    const plain = path.join(tempRoot, 'draft_content.json'); const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(encryptedPath, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY082_ENCRYPT_V2_REQUIRED')
    const persisted = validateJianyingChromaContent(JSON.parse(await readFile(plain, 'utf8')))
    if (persisted.color !== '#00FF00FF' || persisted.intensity !== 30 || persisted.shadow !== 0 || persisted.edgeSmooth !== 0 || persisted.spill !== 0) throw new Error('JY082_CHROMA_PARAMETER_NOT_EDITED')
    const record = { schema_version: 1, manual_evidence_verified: true, manual_attestation: 'opened-edited-saved-reopened', profile_id: pending.profile_id, app_version: pending.app_version, draft_id: pending.draft_id, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, persisted, pre_open_fingerprint: pending.pre_open_fingerprint, post_save_fingerprint: postFingerprint, temporary_media_cleaned: true }
    await securePrivateRuntimeRoot(root)
    const stagedPath = path.join(root, 'post-save.pending.json')
    await writeFile(stagedPath, `${JSON.stringify(record)}\n`, { encoding: 'utf8', mode: 0o600 })
    await rm(path.join(mediaRoot, 'video.mp4'), { force: true }); await rm(path.join(mediaRoot, '.openvideo-jy082-owner'), { force: true }); await rmdir(mediaRoot)
    await rename(stagedPath, path.join(root, 'post-save.json')); await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, capability: 'chroma.video', persisted, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, temporaryMediaCleaned: true })}\n`)
  } finally { await rm(tempRoot, { recursive: true, force: true }) }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.message ?? 'JY082_VERIFY_FAILED' })}\n`); process.exitCode = 1 })
