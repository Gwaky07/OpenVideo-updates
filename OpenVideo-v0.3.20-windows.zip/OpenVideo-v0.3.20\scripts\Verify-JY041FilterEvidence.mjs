import { readFile, mkdtemp, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import { pathToFileURL } from 'node:url'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const manifest = require('../config/jianying-compatibility.json')
const capabilityId = process.env.OPENVIDEO_FILTER_EVIDENCE_CAPABILITY ?? 'filter.video.named'
if (!['filter.video.named', 'filter.video.track_named'].includes(capabilityId)) throw new Error('FILTER_EVIDENCE_CAPABILITY_INVALID')
const trackMode = capabilityId === 'filter.video.track_named'

/**
 * Publish manual evidence only after the retained media has been validated
 * and removed. Removing an older verification first ensures a failed cleanup
 * cannot leave stale evidence that promotes a new pending lease.
 * @param {{evidencePath: string, leasePath: string, mediaRoot: string, evidence: Record<string, unknown>, cleanup?: typeof rm, remove?: typeof rm, write?: typeof writeFile}} input
 */
export const publishFilterEvidenceAfterCleanup = async ({
  evidencePath,
  leasePath,
  mediaRoot,
  evidence,
  cleanup = rm,
  remove = rm,
  write = writeFile,
}) => {
  const owned = typeof mediaRoot === 'string' && path.dirname(mediaRoot) === os.tmpdir() && path.basename(mediaRoot).startsWith('openvideo-jy041-filter-')
  if (!owned) throw new Error('FILTER_EVIDENCE_MEDIA_CLEANUP_REJECTED')
  await remove(evidencePath, { force: true })
  await cleanup(mediaRoot, { recursive: true, force: true, maxRetries: 3 })
  await write(evidencePath, `${JSON.stringify(evidence)}\n`, { encoding: 'utf8', mode: 0o600 })
  await remove(leasePath, { force: true })
}

const main = async () => {
  const evidenceName = trackMode ? 'jy042-filter-track' : 'jy041-filter'
  const catalogName = trackMode ? 'jy042-filter-track-catalog.json' : 'jy041-filter-catalog.json'
  const leasePath = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', evidenceName, 'pending.json')
  const lease = JSON.parse(await readFile(leasePath, 'utf8'))
  const catalogPath = path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs', catalogName)
  const catalog = JSON.parse(await readFile(catalogPath, 'utf8'))
  const binding = catalog.entries?.find((entry) => entry.filter_token === lease.filterToken)
  if (!binding?.resource_id || binding.capability_id !== capabilityId) throw new Error('JY041_PRIVATE_BINDING_MISSING')
  if (lease.capabilityId && (lease.capabilityId !== capabilityId || lease.catalogVersion !== catalog.catalog_version || lease.catalogFingerprint !== catalog.catalog_fingerprint)) throw new Error('JY041_LEASE_CATALOG_MISMATCH')
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest }).catch(() => null)
  if (!lease || lease.profileId !== 'jianying-11-1-provisional' || !desktop || desktop.profileId !== lease.profileId) throw new Error('JY041_PROFILE_MISMATCH')
  const source = path.join(lease.draftRoot, lease.draftId, 'draft_content.json')
  const temp = await mkdtemp(path.join(os.tmpdir(), 'openvideo-jy041-verify-'))
  try {
    const plain = path.join(temp, 'draft_content.json')
    const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(source, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY041_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8'))
    const effects = Array.isArray(content?.materials?.effects) ? content.materials.effects : []
    const filters = effects.filter((item) => item?.type === 'filter')
    const targetTrack = content?.tracks?.find((track) => trackMode ? track?.name === 'filter-1' : track?.name === 'video-primary')
    const segments = Array.isArray(targetTrack?.segments) ? targetTrack.segments : []
    const matching = filters.filter((item) => String(item.resource_id) === String(binding.resource_id))
    const attached = trackMode
      ? segments.some((segment) => matching.some((item) => item.id === segment?.material_id))
      : segments.flatMap((item) => Array.isArray(item?.extra_material_refs) ? item.extra_material_refs : [])
        .some((id) => matching.some((item) => item.id === id))
    const intensity = matching.length === 1 ? matching[0].value : null
    const expectedIntensity = trackMode ? 0.65 : 0.7
    if (filters.length !== 1 || matching.length !== 1 || !attached || intensity !== expectedIntensity) throw new Error('FILTER_PERSISTENCE_INVALID')
    if (typeof lease.draftFingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(lease.draftFingerprint)) throw new Error('FILTER_DRAFT_FINGERPRINT_MISSING')
    await publishFilterEvidenceAfterCleanup({
      evidencePath: path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', evidenceName, 'verified.json'),
      leasePath,
      mediaRoot: lease.mediaRoot,
      evidence: {
        schema_version: 1,
        capabilityId,
        filterToken: lease.filterToken,
        profileId: lease.profileId,
        desktopVersion: desktop.version,
        catalogFingerprint: catalog.catalog_fingerprint,
        draftFingerprint: lease.draftFingerprint,
        scheme: 'encrypt_v2',
        opened: true,
        edited: true,
        saved: true,
        reopened: true,
        filterCount: 1,
        normalizedIntensity: expectedIntensity,
        verifiedAt: new Date().toISOString(),
      },
    })
    process.stdout.write(JSON.stringify({ ok: true, capability: capabilityId, profile: lease.profileId, version: desktop.version, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, filterCount: 1, normalizedIntensity: expectedIntensity, temporaryMediaCleaned: true }) + '\n')
  } finally { await rm(temp, { recursive: true, force: true }) }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY041_VERIFY_FAILED' }) + '\n'); process.exitCode = 1 })
}
