[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,
    [Parameter(Mandatory = $true)]
    [ValidateSet('before', 'after')]
    [string]$Stage
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$runtimeRoot = [System.IO.Path]::GetFullPath($RuntimeDataRoot)
$evidenceRoot = Join-Path $runtimeRoot 'evidence/em-005/private'
$authorizationPath = Join-Path $evidenceRoot 'authorization.json'
& node (Join-Path $PSScriptRoot 'resolve-em005-authorization.mjs') $runtimeRoot $authorizationPath
if ($LASTEXITCODE -ne 0) { throw 'No authorized 20-video material set is available.' }
$authorization = Get-Content -LiteralPath $authorizationPath -Raw -Encoding utf8 | ConvertFrom-Json

$materialRoot = [System.IO.Path]::GetFullPath($authorization.absolutePath)
$files = Get-ChildItem -LiteralPath $materialRoot -File -Recurse |
    Sort-Object FullName
$materialPrefix = $materialRoot.TrimEnd('\') + '\'
$records = @()
for ($index = 0; $index -lt $files.Count; $index += 1) {
    $file = $files[$index]
    if (-not $file.FullName.StartsWith($materialPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Material enumeration escaped the authorized root.'
    }
    $relativePath = $file.FullName.Substring($materialPrefix.Length).Replace('\', '/')
    $records += [ordered]@{
        relative_path = $relativePath
        size = $file.Length
        mtime_utc = $file.LastWriteTimeUtc.ToString('O')
        sha256 = if ($index -lt 5) { (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null }
    }
}

New-Item -ItemType Directory -Path $evidenceRoot -Force | Out-Null
$snapshot = [ordered]@{
    schema_version = 1
    authorization_id = $authorization.id
    captured_at = [DateTimeOffset]::UtcNow.ToString('O')
    file_count = $records.Count
    permanent_scene_file_count = @($files | Where-Object { $_.Name -like 'Scene-*.mp4' }).Count
    files = $records
}
$snapshotPath = Join-Path $evidenceRoot ('source-snapshot.' + $Stage + '.json')
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($snapshotPath, (($snapshot | ConvertTo-Json -Depth 6) + "`n"), $utf8NoBom)

if ($Stage -eq 'after') {
    $beforePath = Join-Path $evidenceRoot 'source-snapshot.before.json'
    if (-not (Test-Path -LiteralPath $beforePath -PathType Leaf)) { throw 'Before snapshot is missing.' }
    $before = Get-Content -LiteralPath $beforePath -Raw -Encoding utf8 | ConvertFrom-Json
    if ($before.authorization_id -ne $snapshot.authorization_id) { throw 'Authorization changed during acceptance.' }
    if ($before.file_count -ne $snapshot.file_count) { throw 'Material file count changed.' }
    if ($snapshot.permanent_scene_file_count -ne 0) { throw 'Permanent scene files were created.' }
    $afterByPath = @{}
    foreach ($record in @($snapshot.files)) { $afterByPath[$record.relative_path] = $record }
    foreach ($record in @($before.files)) {
        $candidate = $afterByPath[$record.relative_path]
        if (
            $null -eq $candidate -or
            [long]$candidate.size -ne [long]$record.size -or
            [string]$candidate.mtime_utc -ne [string]$record.mtime_utc -or
            [string]$candidate.sha256 -ne [string]$record.sha256
        ) {
            throw 'Material names, sizes, mtimes, or sample hashes changed.'
        }
    }
}

Write-Output ("EM-005 material snapshot {0}: {1} files; permanent scene files: {2}." -f $Stage, $records.Count, $snapshot.permanent_scene_file_count)
