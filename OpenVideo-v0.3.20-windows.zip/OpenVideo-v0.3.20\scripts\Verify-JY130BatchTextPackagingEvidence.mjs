import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

import {
  createJianyingBatchTextPackagingCatalog,
  parseJianyingBatchTextPackagingCatalog,
  parseJianyingBatchTextPackagingEvidence,
} from '../apps/gateway/src/jianying-batch-text-packaging-catalog.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { publishJianyingBatchTextEvidence } from '../apps/gateway/src/jianying-batch-text-evidence-publication.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const fingerprintPattern = /^[a-f0-9]{64}$/u
const draftNamePattern = /^OpenVideo-JY130-batch-text-[0-9]{10,20}$/u
const evidenceRootName = 'jy130-batch-text'
const requiredAttestation = '--manual-attestation=opened-edited-saved-reopened'

const exactKeys = (value, expected) =>
  value && typeof value === 'object' && !Array.isArray(value) &&
  Object.keys(value).sort().join('\0') === [...expected].sort().join('\0')

const textOf = (material) => {
  try {
    const parsed = JSON.parse(material?.content)
    return typeof parsed?.text === 'string' ? parsed.text : null
  } catch {
    return null
  }
}

export const timerangeMatches = (segment, binding) => {
  const timerange = segment?.target_timerange
  const persistedStart = timerange?.start
  const startOmitted = timerange && typeof timerange === 'object' && !Object.hasOwn(timerange, 'start')
  return (
    (persistedStart === binding.target_start_us ||
      (binding.target_start_us === 0 && startOmitted)) &&
    timerange?.duration === binding.target_duration_us
  )
}

const assertPending = (pending) => {
  const legacyKeys = [
    'schema_version',
    'draft_id',
    'draft_root',
    'profile_id',
    'app_version',
    'catalog_fingerprint',
    'selected_bindings',
    'draft_content_fingerprint_before_manual',
    'required_manual_actions',
    'manual_evidence_verified',
  ]
  const hasCatalogFileName = Object.hasOwn(pending, 'catalog_file_name')
  const keys = hasCatalogFileName ? [...legacyKeys, 'catalog_file_name'] : legacyKeys
  const catalogFileName = hasCatalogFileName
    ? pending.catalog_file_name
    : 'jy130-batch-text-packaging-catalog.json'
  if (
    !exactKeys(pending, keys) ||
    pending.schema_version !== 1 ||
    typeof pending.draft_id !== 'string' ||
    !draftNamePattern.test(pending.draft_id) ||
    typeof pending.draft_root !== 'string' ||
    !path.isAbsolute(pending.draft_root) ||
    typeof pending.profile_id !== 'string' ||
    typeof pending.app_version !== 'string' ||
    !fingerprintPattern.test(pending.catalog_fingerprint) ||
    !['jy130-batch-text-packaging-catalog.json', 'jy131-batch-sticker-bubble-candidate.json'].includes(catalogFileName) ||
    !fingerprintPattern.test(pending.draft_content_fingerprint_before_manual) ||
    !Array.isArray(pending.required_manual_actions) ||
    pending.required_manual_actions.join('\0') !== 'opened\0edited\0saved\0reopened' ||
    pending.manual_evidence_verified !== false ||
    !Array.isArray(pending.selected_bindings) ||
    pending.selected_bindings.length < 2
  ) throw new Error('JY130_EVIDENCE_LEASE_INVALID')
  const tokens = new Set()
  for (const binding of pending.selected_bindings) {
    if (
      !exactKeys(binding, ['packaging_token', 'kind', 'text', 'target_start_us', 'target_duration_us']) ||
      typeof binding.packaging_token !== 'string' ||
      !/^ovjpack_v1_[A-Za-z0-9_-]{12,160}$/u.test(binding.packaging_token) ||
      !['flower', 'bubble', 'sticker'].includes(binding.kind) ||
      typeof binding.text !== 'string' ||
      binding.text.length < 1 ||
      binding.text.length > 500 ||
      !Number.isSafeInteger(binding.target_start_us) ||
      binding.target_start_us < 0 ||
      !Number.isSafeInteger(binding.target_duration_us) ||
      binding.target_duration_us <= 0 ||
      tokens.has(binding.packaging_token)
    ) throw new Error('JY130_EVIDENCE_LEASE_INVALID')
    tokens.add(binding.packaging_token)
  }
}

export const verifyPersistedBindings = (content, catalog, bindings) => {
  const materials = content?.materials ?? {}
  const effects = Array.isArray(materials.effects) ? materials.effects : []
  const texts = Array.isArray(materials.texts) ? materials.texts : []
  const stickers = Array.isArray(materials.stickers) ? materials.stickers : []
  const titleTracks = Array.isArray(content?.tracks)
    ? content.tracks.filter((track) => track?.name === 'title-primary' && track?.type === 'text')
    : []
  const stickerTracks = Array.isArray(content?.tracks)
    ? content.tracks.filter((track) => track?.type === 'sticker')
    : []
  const textBindingCount = bindings.filter((binding) => binding.kind !== 'sticker').length
  const stickerBindingCount = bindings.length - textBindingCount
  if (titleTracks.length !== (textBindingCount > 0 ? 1 : 0)) throw new Error('JY130_POST_SAVE_TITLE_TRACK_INVALID')
  const titleSegments = titleTracks.length === 1 && Array.isArray(titleTracks[0].segments)
    ? titleTracks[0].segments
    : []
  const expectedStickerTrackNames = Array.from(
    { length: stickerBindingCount },
    (_, index) => `sticker-${index + 1}`,
  )
  const stickerTrackNames = stickerTracks.map((track) => track?.name)
  if (
    stickerTracks.length !== stickerBindingCount ||
    new Set(stickerTrackNames).size !== stickerBindingCount ||
    expectedStickerTrackNames.some((name) => !stickerTrackNames.includes(name))
  ) throw new Error('JY130_POST_SAVE_STICKER_TRACK_INVALID')
  const orderedStickerTracks = expectedStickerTrackNames.map(
    (name) => stickerTracks.find((track) => track.name === name),
  )
  if (
    titleSegments.length !== textBindingCount ||
    orderedStickerTracks.some((track) => !Array.isArray(track?.segments) || track.segments.length !== 1)
  ) {
    throw new Error('JY130_POST_SAVE_BINDING_COUNT_INVALID')
  }
  const stickerSegments = orderedStickerTracks.map((track) => track.segments[0])

  const usedEffectMaterialIds = new Set()
  const usedStickerMaterialIds = new Set()
  const selected = []
  let stickerBindingIndex = 0
  for (const [bindingIndex, binding] of bindings.entries()) {
    const entry = catalog.entries.filter((candidate) => candidate.packaging_token === binding.packaging_token)
    if (entry.length !== 1 || entry[0].kind !== binding.kind) throw new Error('JY130_TOKEN_RESOLUTION_INVALID')
    const expected = entry[0]
    if (binding.kind === 'sticker') {
      const segment = stickerSegments[stickerBindingIndex]
      stickerBindingIndex += 1
      if (!timerangeMatches(segment, binding)) throw new Error('JY130_POST_SAVE_RANGE_INVALID')
      const matchingMaterials = stickers.filter((material) => {
        const resourceId = material?.resource_id ?? null
        const stickerId = material?.sticker_id ?? null
        const effectiveResourceId = resourceId ?? stickerId
        return effectiveResourceId === expected.resource_id &&
          !(resourceId !== null && stickerId !== null && resourceId !== stickerId)
      })
      if (matchingMaterials.length !== 1) throw new Error('JY130_POST_SAVE_RESOURCE_INVALID')
      const attachedMaterialId = segment?.material_id
      const expectedMaterialId = matchingMaterials[0]?.id
      const referenceCount = stickerSegments.filter(
        (candidate) => candidate?.material_id === expectedMaterialId,
      ).length
      if (
        typeof attachedMaterialId !== 'string' ||
        attachedMaterialId !== expectedMaterialId ||
        referenceCount !== 1 ||
        usedStickerMaterialIds.has(attachedMaterialId)
      ) throw new Error('JY130_POST_SAVE_ATTACHMENT_INVALID')
      usedStickerMaterialIds.add(attachedMaterialId)
      selected.push({
        packaging_token: binding.packaging_token,
        kind: binding.kind,
        text: binding.text,
        target_start_us: binding.target_start_us,
        target_duration_us: binding.target_duration_us,
      })
      continue
    }
    const segmentMatches = titleSegments.filter((segment) => timerangeMatches(segment, binding))
    if (segmentMatches.length !== 1) {
      const ranges = titleSegments.map((candidate) => ({
        start: candidate?.target_timerange?.start ?? null,
        duration: candidate?.target_timerange?.duration ?? null,
      }))
      throw new Error(`JY130_POST_SAVE_RANGE_INVALID:${JSON.stringify({
        expected: {
          start: binding.target_start_us,
          duration: binding.target_duration_us,
        },
        actual: ranges,
      })}`)
    }
    const segment = segmentMatches[0]
    const textMaterial = texts.filter((material) => material?.id === segment.material_id)
    if (textMaterial.length !== 1 || textOf(textMaterial[0]) !== binding.text) {
      throw new Error('JY130_POST_SAVE_TEXT_INVALID')
    }
    const effectType = binding.kind === 'flower' ? 'text_effect' : 'text_shape'
    const effectMatches = effects.filter((effect) =>
      effect?.type === effectType &&
      effect?.resource_id === expected.resource_id &&
      effect?.effect_id === expected.effect_id,
    )
    if (effectMatches.length < 1) {
      const typedEffects = effects.filter((effect) => effect?.type === effectType)
      throw new Error(`JY130_POST_SAVE_RESOURCE_INVALID:${JSON.stringify({
        binding_index: bindingIndex,
        kind: binding.kind,
        typed_count: typedEffects.length,
        resource_match_count: typedEffects.filter((effect) => effect?.resource_id === expected.resource_id).length,
        effect_match_count: typedEffects.filter((effect) => effect?.effect_id === expected.effect_id).length,
        pair_match_count: effectMatches.length,
      })}`)
    }
    const refs = Array.isArray(segment.extra_material_refs) ? segment.extra_material_refs : []
    const matchingMaterialIds = new Set(effectMatches.map((effect) => effect.id))
    const attachedMaterialIds = new Set(refs.filter((reference) => matchingMaterialIds.has(reference)))
    if (attachedMaterialIds.size !== 1) {
      const matchingReferenceCount = titleSegments.reduce(
        (count, candidate) => count + (Array.isArray(candidate.extra_material_refs)
          ? candidate.extra_material_refs.filter((reference) => matchingMaterialIds.has(reference)).length
          : 0),
        0,
      )
      throw new Error(`JY130_POST_SAVE_ATTACHMENT_INVALID:${JSON.stringify({
        binding_index: bindingIndex,
        kind: binding.kind,
        matching_material_count: effectMatches.length,
        attached_material_id_count: attachedMaterialIds.size,
        per_material_reference_counts: effectMatches.map(
          (effect) => refs.filter((reference) => reference === effect.id).length,
        ),
        current_matching_reference_count: refs.filter((reference) => matchingMaterialIds.has(reference)).length,
        track_matching_reference_count: matchingReferenceCount,
      })}`)
    }
    const attachedMaterialId = [...attachedMaterialIds][0]
    const currentReferenceCount = refs.filter((reference) => matchingMaterialIds.has(reference)).length
    const referenceCount = titleSegments.reduce(
      (count, candidate) => count + (Array.isArray(candidate.extra_material_refs)
        ? candidate.extra_material_refs.filter((reference) => matchingMaterialIds.has(reference)).length
        : 0),
      0,
    )
    if (
      currentReferenceCount < 1 ||
      referenceCount !== currentReferenceCount ||
      usedEffectMaterialIds.has(attachedMaterialId)
    ) {
      throw new Error('JY130_POST_SAVE_ATTACHMENT_INVALID')
    }
    usedEffectMaterialIds.add(attachedMaterialId)
    selected.push({
      packaging_token: binding.packaging_token,
      kind: binding.kind,
      text: binding.text,
      target_start_us: binding.target_start_us,
      target_duration_us: binding.target_duration_us,
    })
  }
  return selected
}

export const matchesPublishedRecovery = (pending, publishedCatalog, publishedEvidence) =>
  publishedCatalog?.evidence_profile?.manual_verified === true &&
  publishedEvidence?.catalog_fingerprint === publishedCatalog.catalog_fingerprint &&
  publishedCatalog.profile_id === publishedEvidence.profile_id &&
  publishedCatalog.evidence_profile.app_version === publishedEvidence.app_version &&
  publishedCatalog.evidence_profile.scheme === publishedEvidence.scheme &&
  publishedCatalog.evidence_profile.draft_fingerprint === publishedEvidence.post_save_fingerprint &&
  Array.isArray(publishedCatalog.entries) &&
  Array.isArray(publishedEvidence.admitted_tokens) &&
  publishedCatalog.entries.length === publishedEvidence.admitted_tokens.length &&
  new Set(publishedCatalog.entries.map((entry) => entry.packaging_token)).size === publishedCatalog.entries.length &&
  new Set(publishedEvidence.admitted_tokens).size === publishedEvidence.admitted_tokens.length &&
  publishedCatalog.entries.every((entry) => publishedEvidence.admitted_tokens.includes(entry.packaging_token)) &&
  (pending === null || (
    pending.catalog_fingerprint === publishedCatalog.catalog_fingerprint &&
    pending.draft_id === publishedEvidence.draft_id
  ))

const writePublishedRecovery = (publishedCatalog, publishedEvidence) => {
  process.stdout.write(`${JSON.stringify({
    ok: true,
    recovered: true,
    manual_evidence_verified: true,
    entry_count: publishedCatalog.entries.length,
    selected_count: publishedEvidence.selected_bindings.length,
    catalog_fingerprint: publishedCatalog.catalog_fingerprint,
    draft_content_fingerprint: publishedEvidence.post_save_fingerprint,
    scheme: publishedEvidence.scheme,
  })}\n`)
}

const main = async () => {
  const preflightOnly = process.argv.includes('--preflight-only')
  if (!preflightOnly && !process.argv.includes(requiredAttestation)) throw new Error('JY130_MANUAL_ATTESTATION_REQUIRED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const evidenceRoot = path.join(dataRoot, 'evidence', evidenceRootName)
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const catalogsRoot = path.join(dataRoot, 'catalogs')
  const catalogPath = path.join(catalogsRoot, 'jy130-batch-text-packaging-catalog.json')
  const evidencePath = path.join(evidenceRoot, 'post-save.json')
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  let pending
  try {
    pending = JSON.parse(await readFileNoReparse(pendingPath, dataRoot))
  } catch (pendingError) {
    const pendingMissing = await lstat(pendingPath)
      .then(() => false)
      .catch((error) => error?.code === 'ENOENT')
    if (!pendingMissing) throw pendingError
    const publishedCatalog = await readFileNoReparse(catalogPath, dataRoot)
      .then((source) => parseJianyingBatchTextPackagingCatalog(JSON.parse(source)))
      .catch(() => null)
    const publishedEvidence = publishedCatalog === null
      ? null
      : await readFileNoReparse(evidencePath, dataRoot)
        .then((source) => parseJianyingBatchTextPackagingEvidence(
          JSON.parse(source),
          publishedCatalog.catalog_fingerprint,
          desktop,
        ))
        .catch(() => null)
    if (!matchesPublishedRecovery(null, publishedCatalog, publishedEvidence)) throw pendingError
    writePublishedRecovery(publishedCatalog, publishedEvidence)
    return
  }
  assertPending(pending)

  if (
    desktop?.profileId !== pending.profile_id ||
    desktop.version !== pending.app_version ||
    path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root)
  ) throw new Error('JY130_EVIDENCE_BINDING_INVALID')
  const sourceCatalogPath = path.join(
    catalogsRoot,
    pending.catalog_file_name ?? 'jy130-batch-text-packaging-catalog.json',
  )
  const currentCatalog = parseJianyingBatchTextPackagingCatalog(
    JSON.parse(await readFileNoReparse(sourceCatalogPath, dataRoot)),
  )
  const publishedCatalog = await readFileNoReparse(catalogPath, dataRoot)
    .then((source) => parseJianyingBatchTextPackagingCatalog(JSON.parse(source)))
    .catch(() => null)
  if (publishedCatalog?.evidence_profile.manual_verified === true) {
    const publishedEvidence = await readFileNoReparse(evidencePath, dataRoot)
      .then((source) => parseJianyingBatchTextPackagingEvidence(
        JSON.parse(source),
        publishedCatalog.catalog_fingerprint,
        desktop,
      ))
      .catch(() => null)
    if (matchesPublishedRecovery(pending, publishedCatalog, publishedEvidence)) {
      await rm(pendingPath, { force: true })
      writePublishedRecovery(publishedCatalog, publishedEvidence)
      return
    }
  }
  const draftFolder = path.resolve(desktop.draftRoot, pending.draft_id)
  if (path.dirname(draftFolder) !== path.resolve(desktop.draftRoot)) throw new Error('JY130_EVIDENCE_BINDING_INVALID')
  const draftContentPath = path.join(draftFolder, 'draft_content.json')
  const encrypted = await readFileNoReparseBuffer(draftContentPath, desktop.draftRoot)
  const postSaveFingerprint = createHash('sha256').update(encrypted).digest('hex')
  if (preflightOnly) {
    if (postSaveFingerprint !== pending.draft_content_fingerprint_before_manual) {
      throw new Error('JY131_PREFLIGHT_DRAFT_CHANGED')
    }
    const temporary = await mkdtemp(path.join(tmpdir(), 'openvideo-jy131-preflight-'))
    try {
      const sourceSnapshot = path.join(temporary, 'draft_content.encrypted')
      const plaintextPath = path.join(temporary, 'draft_content.json')
      await writeFile(sourceSnapshot, encrypted, { mode: 0o600 })
      const meta = await createJianyingDraftDecryptor({
        installRoot: desktop.installRoot,
        appVersion: desktop.version,
      }).ensurePlaintextFile(sourceSnapshot, plaintextPath)
      if (
        !(
          (meta.scheme === 'plaintext' && meta.contentEncoding === 'plaintext') ||
          meta.scheme === 'encrypt_v2' ||
          meta.decryptedFrom === 'encrypt_v2'
        )
      ) throw new Error('JY131_PREFLIGHT_CONTENT_ENCODING_INVALID')
      const content = JSON.parse(await readFile(plaintextPath, 'utf8'))
      const selected = verifyPersistedBindings(content, currentCatalog, pending.selected_bindings)
      process.stdout.write(`${JSON.stringify({
        ok: true,
        preflight_only: true,
        structure_verified: true,
        selected_count: selected.length,
        flower_count: selected.filter((binding) => binding.kind === 'flower').length,
        bubble_count: selected.filter((binding) => binding.kind === 'bubble').length,
        sticker_count: selected.filter((binding) => binding.kind === 'sticker').length,
        manual_evidence_verified: false,
      })}\n`)
      return
    } finally {
      await rm(temporary, { recursive: true, force: true })
    }
  }
  if (postSaveFingerprint === pending.draft_content_fingerprint_before_manual) {
    throw new Error('JY130_MANUAL_EDIT_NOT_PERSISTED')
  }

  const initialCatalog = currentCatalog
  if (initialCatalog.catalog_fingerprint !== pending.catalog_fingerprint) {
    throw new Error('JY130_CATALOG_BINDING_INVALID')
  }
  const temporary = await mkdtemp(path.join(tmpdir(), 'openvideo-jy130-verify-'))
  try {
    const sourceSnapshot = path.join(temporary, 'draft_content.encrypted')
    const plaintextPath = path.join(temporary, 'draft_content.json')
    await writeFile(sourceSnapshot, encrypted, { mode: 0o600 })
    const meta = await createJianyingDraftDecryptor({
      installRoot: desktop.installRoot,
      appVersion: desktop.version,
    }).ensurePlaintextFile(sourceSnapshot, plaintextPath)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') {
      throw new Error('JY130_ENCRYPT_V2_REQUIRED')
    }
    const content = JSON.parse(await readFile(plaintextPath, 'utf8'))
    const selected = verifyPersistedBindings(content, initialCatalog, pending.selected_bindings)
    const admittedTokens = selected.map((binding) => binding.packaging_token)
    const admittedEntries = initialCatalog.entries.filter((entry) => admittedTokens.includes(entry.packaging_token))
    if (admittedEntries.length !== admittedTokens.length) throw new Error('JY130_TOKEN_RESOLUTION_INVALID')
    const admittedCatalog = createJianyingBatchTextPackagingCatalog(admittedEntries, {
      catalogVersion: initialCatalog.catalog_version,
      upstreamCommit: initialCatalog.upstream_commit,
      profileId: initialCatalog.profile_id,
      evidenceProfile: {
        manual_verified: true,
        scheme: 'encrypt_v2',
        app_version: initialCatalog.evidence_profile.app_version,
        draft_fingerprint: postSaveFingerprint,
      },
    })
    const evidence = {
      schema_version: 1,
      manual_evidence_verified: true,
      manual_attestation: 'opened-edited-saved-reopened',
      profile_id: desktop.profileId,
      app_version: desktop.version,
      catalog_fingerprint: admittedCatalog.catalog_fingerprint,
      scheme: 'encrypt_v2',
      opened: true,
      edited: true,
      saved: true,
      reopened: true,
      draft_id: pending.draft_id,
      pre_open_fingerprint: pending.draft_content_fingerprint_before_manual,
      post_save_fingerprint: postSaveFingerprint,
      selected_bindings: selected,
      admitted_tokens: admittedTokens,
      temporary_media_cleaned: true,
    }
    const parsedEvidence = parseJianyingBatchTextPackagingEvidence(
      evidence,
      admittedCatalog.catalog_fingerprint,
      desktop,
    )
    if (!parsedEvidence) throw new Error('JY130_EVIDENCE_BINDING_INVALID')

    await securePrivateRuntimeRoot(catalogsRoot)
    await securePrivateRuntimeRoot(evidenceRoot)
    await publishJianyingBatchTextEvidence({
      catalogPath,
      evidencePath,
      pendingPath,
      catalog: admittedCatalog,
      evidence: parsedEvidence,
    })
    process.stdout.write(`${JSON.stringify({
      ok: true,
      manual_evidence_verified: true,
      entry_count: admittedCatalog.entries.length,
      selected_count: selected.length,
      catalog_fingerprint: admittedCatalog.catalog_fingerprint,
      draft_content_fingerprint: postSaveFingerprint,
      scheme: 'encrypt_v2',
    })}\n`)
  } finally {
    await rm(temporary, { recursive: true, force: true })
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch((error) => {
    process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY130_VERIFY_FAILED' })}\n`)
    process.exitCode = 1
  })
}
