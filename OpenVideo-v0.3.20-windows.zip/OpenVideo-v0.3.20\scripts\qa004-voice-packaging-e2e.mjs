import { randomUUID } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const origin = process.env.OPENVIDEO_ORIGIN || 'http://127.0.0.1:8787'
const projectId = process.env.OPENVIDEO_PROJECT_ID || 'd197b6e3-575b-4603-bc8c-7be162ab6d9f'
const runtimeDataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
const localApiToken = process.env.OPENVIDEO_LOCAL_API_TOKEN
  || (runtimeDataRoot
    ? JSON.parse(await readFile(join(runtimeDataRoot, 'local-api-token.json'), 'utf8')).token
    : null)
if (typeof localApiToken !== 'string' || !/^[a-f0-9]{64}$/u.test(localApiToken)) {
  throw new Error('OPENVIDEO_LOCAL_API_TOKEN_REQUIRED')
}
const headers = {
  origin,
  'content-type': 'application/json; charset=utf-8',
  'x-openvideo-local-token': localApiToken,
}

const request = async (method, path, body, extraHeaders = {}) => {
  const response = await fetch(`${origin}${path}`, {
    method,
    headers: { ...headers, ...extraHeaders },
    body: body === undefined ? undefined : Buffer.from(JSON.stringify(body), 'utf8'),
  })
  const text = await response.text()
  let json = null
  try {
    json = text ? JSON.parse(text) : null
  } catch {
    json = { raw: text }
  }
  if (!response.ok) {
    const error = new Error(`${method} ${path} -> ${response.status}`)
    error.status = response.status
    error.body = json
    throw error
  }
  return json
}

const waitJob = async (jobId, timeoutMs = 10 * 60_000) => {
  const started = Date.now()
  while (Date.now() - started < timeoutMs) {
    const job = await request('GET', `/api/workbench/projects/${projectId}/jobs/${jobId}`)
    if (['succeeded', 'failed', 'cancelled'].includes(job.status)) return job
    await new Promise((resolve) => setTimeout(resolve, 1500))
  }
  throw new Error(`job timeout: ${jobId}`)
}

const evidence = {
  origin,
  projectId,
  startedAt: new Date().toISOString(),
  steps: [],
}

const step = async (name, fn) => {
  const startedAt = new Date().toISOString()
  try {
    const result = await fn()
    evidence.steps.push({ name, ok: true, startedAt, finishedAt: new Date().toISOString(), result })
    return result
  } catch (error) {
    evidence.steps.push({
      name,
      ok: false,
      startedAt,
      finishedAt: new Date().toISOString(),
      error: {
        message: error.message,
        status: error.status ?? null,
        body: error.body ?? null,
      },
    })
    throw error
  }
}

const voices = await step('voices', () => request('GET', '/api/workbench/voices'))
const voiceId = voices.voices.find((voice) => voice.id === 'zh-CN-YunxiNeural')?.id ||
  voices.voices[0]?.id

const project = await step('load-project', () => request('GET', `/api/workbench/projects/${projectId}`))

const brief = {
  theme: '夏季通勤水杯，轻盈可靠的日常仪式感',
  title: '夏日随身杯',
  sellingPoints: ['轻量便携', '磨砂不留指纹', '开盖顺手'],
  script: [
    '打开包装，第一眼就能看到简洁完整的产品组合。',
    '细看杯身，磨砂质感会随着柔光慢慢显现。',
    '放回日常桌面，它自然融入清晨的使用节奏。',
  ].join('\n'),
  style: '自然明亮，节奏克制',
  durationSeconds: 30,
  orientation: 'portrait',
  voiceover: 'required',
  voiceId,
  voiceRate: 0,
  captions: 'auto',
  packaging: {
    bgm: 'none',
    bgmAuthorizationId: null,
    bgmLabel: null,
    keywordHighlights: ['轻量便携', '磨砂质感'],
    intro: 'title_card',
    outro: 'title_card',
    subtitleStyle: 'bottom_safe',
    packagingNotes: '需要花字贴纸和剪映曲库自动配乐（应标记为暂不支持）',
  },
}

const sameBrief =
  project.brief?.voiceId === brief.voiceId &&
  project.brief?.theme === brief.theme &&
  project.brief?.script === brief.script &&
  JSON.stringify(project.brief?.packaging ?? {}) === JSON.stringify(brief.packaging)

const saved = await step('save-brief-utf8', () =>
  sameBrief && project.storyboard?.sentences?.length
    ? Promise.resolve(project)
    : request('POST', `/api/workbench/projects/${projectId}/brief/save`, brief))

const mojibake = JSON.stringify(saved.brief).includes('?') &&
  !saved.brief.theme.includes('夏季')
evidence.utf8Ok = saved.brief.theme.includes('夏季') &&
  saved.brief.title.includes('夏日') &&
  !mojibake
evidence.packagingCapabilities = saved.brief.packagingCapabilities || saved.packagingCapabilities
evidence.voiceId = saved.brief.voiceId
evidence.supported = evidence.packagingCapabilities?.supported ?? []
evidence.unsupported = evidence.packagingCapabilities?.unsupported ?? []

let storyboardProject = saved
if (!saved.storyboard?.sentences?.length) {
  const storyboardJob = await step('storyboard-job', async () => {
    const job = await request(
      'POST',
      `/api/workbench/projects/${projectId}/jobs`,
      { type: 'storyboard_generation' },
      { 'idempotency-key': randomUUID() },
    )
    return waitJob(job.jobId)
  })
  if (storyboardJob.status !== 'succeeded') {
    throw Object.assign(new Error('storyboard failed'), { body: storyboardJob })
  }
  storyboardProject = await step('reload-after-storyboard', () =>
    request('GET', `/api/workbench/projects/${projectId}`))
}

evidence.sentenceCount = storyboardProject.storyboard?.sentences?.length ?? 0
evidence.sentenceSample = storyboardProject.storyboard?.sentences?.slice(0, 3).map((sentence) => ({
  id: sentence.id,
  text: sentence.text,
  selectedCandidateId: sentence.selectedCandidateId,
}))

const previewJob = await step('preview-job', async () => {
  const job = await request(
    'POST',
    `/api/workbench/projects/${projectId}/jobs`,
    { type: 'preview_generation' },
    { 'idempotency-key': randomUUID() },
  )
  return waitJob(job.jobId, 12 * 60_000)
})
evidence.previewJob = {
  status: previewJob.status,
  error: previewJob.error ?? null,
  result: previewJob.result ?? null,
}

const afterPreview = await step('reload-after-preview', () =>
  request('GET', `/api/workbench/projects/${projectId}`))
evidence.preview = afterPreview.preview
evidence.pathLeak = JSON.stringify(afterPreview).includes(':\\') ||
  JSON.stringify(afterPreview).includes('S:/')

const outDir = join(tmpdir(), 'openvideo-qa004-evidence')
await mkdir(outDir, { recursive: true })
const outPath = join(outDir, `voice-packaging-${Date.now()}.json`)
evidence.finishedAt = new Date().toISOString()
await writeFile(outPath, `${JSON.stringify(evidence, null, 2)}\n`, 'utf8')
console.log(JSON.stringify({
  ok: evidence.utf8Ok && previewJob.status === 'succeeded' && !evidence.pathLeak,
  outPath,
  utf8Ok: evidence.utf8Ok,
  voiceId: evidence.voiceId,
  sentenceCount: evidence.sentenceCount,
  previewStatus: previewJob.status,
  supported: evidence.supported,
  unsupported: evidence.unsupported,
  pathLeak: evidence.pathLeak,
}, null, 2))

if (!(evidence.utf8Ok && previewJob.status === 'succeeded' && !evidence.pathLeak)) {
  process.exitCode = 1
}
