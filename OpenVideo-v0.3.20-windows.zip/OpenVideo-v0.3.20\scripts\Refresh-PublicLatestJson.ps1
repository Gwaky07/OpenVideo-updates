[CmdletBinding()]
param(
    [string]$FeedRoot = 'S:\Codex\releases\openvideo-updates',
    [string]$Commit = '0bd772e3b5b03b13ef2739243ef4e2e12fccfa6a',
    [string]$Version = 'v0.2.6'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Push-Location $FeedRoot
try {
    $candidates = @(
        (Join-Path (Split-Path -Parent $PSScriptRoot) ('release\OpenVideo-' + $Version + '-windows.zip')),
        (Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) ('release\OpenVideo-' + $Version + '-windows.zip'))
    )
    $zipLocal = $null
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath $c -PathType Leaf) { $zipLocal = (Resolve-Path $c).Path; break }
    }
    if (-not $zipLocal) { throw 'OPENVIDEO_FULL_UPDATE_ZIP_MISSING' }
    if (-not (Test-Path -LiteralPath $zipLocal)) { throw 'OPENVIDEO_FULL_UPDATE_ZIP_MISSING' }
    $sha = (Get-FileHash $zipLocal -Algorithm SHA256).Hash.ToLowerInvariant()
    $bytes = (Get-Item $zipLocal).Length

    $manifest = [ordered]@{
        schema_version = 1
        scope = 'full'
        commit = $Commit
        version = $Version
        summary = 'OpenVideo whole-product update'
        notes = @('Page, Gateway and launcher upgrade together', 'Failed apply rolls back to the previous release')
        package = [ordered]@{
            # PROD-HOTFIX-022: media.githubusercontent.com renders LFS binaries;
            # raw.githubusercontent.com only returns the 133-byte LFS pointer.
            url = ('https://media.githubusercontent.com/media/Gwaky07/OpenVideo-updates/main/OpenVideo-' + $Version + '-windows.zip')
            sha256 = $sha
            bytes = $bytes
        }
        publishedAt = '2026-09-13T09:00:00Z'
    }

    $zipDest = Join-Path $FeedRoot ('OpenVideo-' + $Version + '-windows.zip')
    Copy-Item -LiteralPath $zipLocal -Destination $zipDest -Force
    $manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $FeedRoot 'latest.json') -Encoding utf8
    Remove-Item -LiteralPath (Join-Path $FeedRoot 'frontend.zip') -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $FeedRoot 'frontend-update.json') -Force -ErrorAction SilentlyContinue
    git add latest.json ($zipName = (Split-Path $zipDest -Leaf))
    git commit -m ('OpenVideo ' + $Version + ' whole-product update') --quiet
    git push origin HEAD:main
    Write-Host ('OPENVIDEO_FULL_UPDATE_FEED_READY: ' + $FeedRoot)
} finally {
    Pop-Location
}
