# Test-REL007TemplateDemoEvidence.ps1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,
    [Parameter(Mandatory = $true)]
    [string]$ManualEvidencePath
)

$ErrorActionPreference = 'Stop'
$runtimeRoot = [IO.Path]::GetFullPath($RuntimeDataRoot).TrimEnd('\') + '\'
$manualPath = [IO.Path]::GetFullPath($ManualEvidencePath)
$evidenceRoot = [IO.Path]::GetFullPath((Join-Path $runtimeRoot 'evidence\rel-007'))

function Assert-NoReparseBoundary {
    param(
        [Parameter(Mandatory = $true)][string]$CandidatePath,
        [Parameter(Mandatory = $true)][string]$BoundaryPath
    )
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if (
        $candidate -ne $boundary `
        -and -not $candidate.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)
    ) {
        throw 'REL-007 template evidence escaped its private boundary.'
    }
    $currentPath = $candidate
    while ($true) {
        $current = Get-Item -LiteralPath $currentPath -Force
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'REL-007 template evidence cannot traverse a reparse point.'
        }
        if ([IO.Path]::GetFullPath($currentPath).TrimEnd('\') -eq $boundary) { break }
        $currentPath = [IO.Path]::GetDirectoryName($currentPath.TrimEnd('\'))
        if ([string]::IsNullOrWhiteSpace($currentPath)) {
            throw 'REL-007 template evidence boundary could not be verified.'
        }
    }
}

Assert-NoReparseBoundary -CandidatePath $evidenceRoot -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $manualPath -BoundaryPath $runtimeRoot
if (-not $manualPath.StartsWith($evidenceRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'REL-007 template evidence must live under evidence/rel-007.'
}

$manual = Get-Content -LiteralPath $manualPath -Raw -Encoding UTF8 | ConvertFrom-Json
$expectedKeys = @(
    'schema_version',
    'kind',
    'library_template_id',
    'template_revision',
    'template_fingerprint',
    'demo_sha256',
    'demo_duration_seconds',
    'demo_renderer',
    'demo_authentic',
    'approve_ready',
    'style_analysis_complete',
    'binding_fingerprint',
    'playback_confirmed',
    'confirmed_at'
)
if (@(Compare-Object ($expectedKeys | Sort-Object) @($manual.PSObject.Properties.Name | Sort-Object)).Count -ne 0) {
    throw 'REL-007 template evidence schema is not exact.'
}

$mediaPath = Join-Path $runtimeRoot ("template-library-media\{0}\media.json" -f $manual.library_template_id)
Assert-NoReparseBoundary -CandidatePath $mediaPath -BoundaryPath $runtimeRoot
$media = Get-Content -LiteralPath $mediaPath -Raw -Encoding UTF8 | ConvertFrom-Json
$demoPath = Join-Path $runtimeRoot ("template-library-media\{0}\{1}" -f $manual.library_template_id, $media.demo.fileName)
Assert-NoReparseBoundary -CandidatePath $demoPath -BoundaryPath $runtimeRoot
$fileHash = (Get-FileHash -LiteralPath $demoPath -Algorithm SHA256).Hash.ToLowerInvariant()

$templatesPath = Join-Path $runtimeRoot 'reusable-templates.json'
$store = Get-Content -LiteralPath $templatesPath -Raw -Encoding UTF8 | ConvertFrom-Json
$record = @($store.records) |
    Where-Object { $_.libraryTemplateId -eq $manual.library_template_id } |
    Sort-Object revision -Descending |
    Select-Object -First 1

$openedAt = [DateTimeOffset]::Parse($manual.confirmed_at)
if (
    $manual.schema_version -ne 1 `
    -or $manual.kind -ne 'rel007_template_authentic_demo_playback_evidence' `
    -or $manual.demo_renderer -ne 'template_demo_renderer' `
    -or $manual.demo_authentic -ne $true `
    -or $manual.approve_ready -ne $true `
    -or $manual.style_analysis_complete -ne $true `
    -or $manual.playback_confirmed -ne $true `
    -or $manual.template_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $manual.demo_sha256 -notmatch '^[a-f0-9]{64}$' `
    -or $manual.binding_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $manual.demo_duration_seconds -lt 8 `
    -or $manual.demo_duration_seconds -gt 15 `
    -or $manual.demo_sha256 -ne $fileHash `
    -or $manual.demo_sha256 -ne ([string]$media.demo.sha256).ToLowerInvariant() `
    -or $manual.binding_fingerprint -ne [string]$media.demo.bindingFingerprint `
    -or $manual.template_revision -ne [int]$record.revision `
    -or $manual.template_fingerprint -ne [string]$record.fingerprint `
    -or $media.demo.renderer -ne 'template_demo_renderer' `
    -or $media.demo.authentic -ne $true `
    -or $media.demo.status -ne 'ready' `
    -or $media.styleAnalysis.analysisComplete -ne $true `
    -or $openedAt -gt [DateTimeOffset]::UtcNow.AddMinutes(5)
) {
    throw 'REL-007 template evidence values failed cross-checks.'
}

Write-Host 'REL-007 template authentic demo evidence verified.'
