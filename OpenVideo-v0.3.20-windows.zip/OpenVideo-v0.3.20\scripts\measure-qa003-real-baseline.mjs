import { createHash } from 'node:crypto'
import { lstat, mkdir, readFile, readdir, stat, statfs, writeFile } from 'node:fs/promises'
import { basename, isAbsolute, resolve } from 'node:path'

const dataRoot = process.argv[2]
if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('QA003_RUNTIME_ROOT_INVALID')
const startedAt = Date.now()
const optionalBudget = (name) => {
  const raw = process.env[name]
  if (raw === undefined || raw === '') return null
  const value = Number(raw)
  if (!Number.isSafeInteger(value) || value < 1) throw new Error('QA003_RESOURCE_BUDGET_INVALID')
  return value
}
const resourceSafetyBudget = {
  minimum_free_disk_bytes: optionalBudget('OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES'),
  maximum_process_rss_bytes: optionalBudget('OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES'),
  maximum_elapsed_ms: optionalBudget('OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS'),
}

const readJson = async (path) => JSON.parse(await readFile(path, 'utf8'))
const hashLines = (values) => {
  const hash = createHash('sha256')
  for (const value of values) hash.update(String(value)).update('\n')
  return hash.digest('hex')
}
const countEntries = async (path) => {
  try {
    return (await readdir(path, { recursive: true })).length
  } catch (error) {
    if (error?.code === 'ENOENT') return 0
    throw error
  }
}
const directoryBytes = async (path) => {
  let total = 0
  try {
    const entries = await readdir(path, { recursive: true, withFileTypes: true })
    for (const entry of entries) {
      if (!entry.isFile()) continue
      total += (await stat(resolve(entry.parentPath, entry.name))).size
    }
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  return total
}

const authorizations = await readJson(resolve(dataRoot, 'authorizations.json'))
const authorization = authorizations.records
  .filter((record) => record.status === 'authorized' && record.readOnly === true)
  .sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))[0]
if (!authorization) throw new Error('QA003_AUTHORIZATION_NOT_FOUND')

const indexPath = resolve(dataRoot, 'material-analysis/analysis-index.json')
const index = await readJson(indexPath)
const record = index.records.find((candidate) =>
  candidate.authorization_id === authorization.id &&
  candidate.project_id === authorization.projectId)
if (!record) throw new Error('QA003_ANALYSIS_RECORD_NOT_FOUND')

const sourceMetadata = []
for (const asset of [...record.assets].sort((left, right) =>
  left.relative_path.localeCompare(right.relative_path, 'en'))) {
  const metadata = await lstat(asset.source_path)
  if (!metadata.isFile() || metadata.isSymbolicLink()) {
    throw new Error('QA003_SOURCE_ENTRY_INVALID')
  }
  sourceMetadata.push({
    relativePath: asset.relative_path,
    size: metadata.size,
    mtimeMs: metadata.mtimeMs,
  })
}
const sourceBytes = sourceMetadata.reduce((total, entry) => total + entry.size, 0)
const totalDurationSeconds = record.assets.reduce(
  (total, asset) => total + asset.duration_seconds,
  0,
)
const sceneCount = record.assets.reduce(
  (total, asset) => total + asset.scenes.length,
  0,
)
const materialAnalysisBytes = await directoryBytes(resolve(dataRoot, 'material-analysis'))
const temporaryEntryCount =
  await countEntries(resolve(dataRoot, 'material-analysis/tmp')) +
  await countEntries(resolve(dataRoot, 'short-video-factory/work'))
const failedOutputEntryCount = (await readdir(
  resolve(dataRoot, 'short-video-factory/resources'),
  { recursive: true },
).catch((error) => error?.code === 'ENOENT' ? [] : Promise.reject(error)))
  .filter((entry) => /\.(?:tmp|partial)$/iu.test(String(entry))).length
const permanentSceneFileCount = record.assets.filter((asset) =>
  /^scene-.*\.mp4$/iu.test(basename(asset.source_path))).length
const filesystem = await statfs(dataRoot)
const freeDiskBytes = Number(filesystem.bavail) * Number(filesystem.bsize)
const processPeakRssBytes = process.resourceUsage().maxRSS * 1024
const elapsedMs = Date.now() - startedAt
const scaleStopReasons = [
  resourceSafetyBudget.minimum_free_disk_bytes !== null &&
    freeDiskBytes < resourceSafetyBudget.minimum_free_disk_bytes
    ? 'minimum_free_disk_budget'
    : null,
  resourceSafetyBudget.maximum_process_rss_bytes !== null &&
    processPeakRssBytes > resourceSafetyBudget.maximum_process_rss_bytes
    ? 'maximum_process_rss_budget'
    : null,
  resourceSafetyBudget.maximum_elapsed_ms !== null &&
    elapsedMs > resourceSafetyBudget.maximum_elapsed_ms
    ? 'maximum_elapsed_budget'
    : null,
].filter(Boolean)

const evidence = {
  schema_version: 1,
  completed_at: new Date().toISOString(),
  scale_policy: 'current_real_baseline_no_fixed_capacity_gate',
  scale_stage: 'current_real_baseline',
  concurrency_level: 1,
  elapsed_ms: elapsedMs,
  resource_safety_budget: resourceSafetyBudget,
  resource_safety_observation: {
    free_disk_bytes: freeDiskBytes,
    process_peak_rss_bytes: processPeakRssBytes,
  },
  scale_stop_required: scaleStopReasons.length > 0,
  scale_stop_reasons: scaleStopReasons,
  authorization_id_hash: hashLines([authorization.id]),
  source_file_count: sourceMetadata.length,
  source_total_bytes: sourceBytes,
  source_total_gib: Number((sourceBytes / 1024 ** 3).toFixed(3)),
  source_name_fingerprint: hashLines(sourceMetadata.map((entry) => entry.relativePath)),
  source_metadata_fingerprint: hashLines(sourceMetadata.map((entry) =>
    `${entry.relativePath}\u0000${entry.size}\u0000${entry.mtimeMs}`)),
  total_duration_seconds: Number(totalDurationSeconds.toFixed(3)),
  scene_count: sceneCount,
  material_analysis_bytes: materialAnalysisBytes,
  temporary_entry_count: temporaryEntryCount,
  failed_output_entry_count: failedOutputEntryCount,
  permanent_scene_file_count: permanentSceneFileCount,
  process_peak_rss_bytes: processPeakRssBytes,
}
const evidenceRoot = resolve(dataRoot, 'evidence/qa-003')
await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
await writeFile(
  resolve(evidenceRoot, 'real-baseline.json'),
  `${JSON.stringify(evidence, null, 2)}\n`,
  { encoding: 'utf8', mode: 0o600 },
)
console.log(JSON.stringify(evidence))
