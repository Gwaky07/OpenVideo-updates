@echo off
chcp 65001 >NUL
echo ============================================================
echo  OpenVideo 一键安装依赖检查
echo ============================================================
echo.

:: Check Node.js
where node >NUL 2>&1
if %errorlevel% neq 0 (
    echo [缺失] Node.js 未安装
    echo 请下载: https://nodejs.org (LTS 版本)
    echo 安装后重新运行此脚本
    echo.
) else (
    for /f "delims=" %%v in ('node -v') do set NODE_VER=%%v
    echo [OK] Node.js %NODE_VER%
)

:: Check Python
where python >NUL 2>&1
if %errorlevel% neq 0 (
    where py >NUL 2>&1
    if %errorlevel% neq 0 (
        echo [缺失] Python 未安装
        echo 请下载: https://www.python.org/downloads/
        echo 重要：安装时勾选 "Add Python to PATH"
        echo.
    ) else (
        for /f "delims=" %%v in ('py -V') do set PY_VER=%%v
        echo [OK] Python %PY_VER%
    )
) else (
    for /f "delims=" %%v in ('python -V 2^>^&1') do set PY_VER=%%v
    echo [OK] Python %PY_VER%
)

:: Check corepack / pnpm
where corepack >NUL 2>&1
if %errorlevel% neq 0 (
    echo [缺失] corepack 未启用 (Node.js 自带)
    echo 请以管理员身份运行: corepack enable
    echo.
) else (
    echo [OK] corepack 已就绪
)

echo.
echo ============================================================
echo 检查完毕
echo ============================================================
echo.
echo 下一步：解压 OpenVideo-v0.3.11-windows.zip 到任意目录
echo        双击根目录 OpenVideo.cmd 启动
echo.
echo 首次启动会下载 pnpm 依赖，请保持网络连接
echo.
pause
