# Test-OpenVideoAllowList.ps1
# Isolated unit test that verifies Build-OpenVideoFullUpdate.ps1's $allow list
# behavior without running the full build pipeline. Runs in repo .openvideo-work/.

[CmdletBinding()]
param(
  [string]$RepositoryRoot,
  [string]$OutputRoot
)
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
if([string]::IsNullOrWhiteSpace($RepositoryRoot)){$RepositoryRoot = (Resolve-Path '.').Path}
$root = [IO.Path]::GetFullPath($RepositoryRoot)
if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
  # Default output root lives under the repo's local work area so it never
  # touches %TEMP% or drive roots. The previous default resolved to
  # 'S:\.openvideo-work\...' which fails when the dev tree is checked out
  # anywhere other than the drive root.
  $OutputRoot = Join-Path $root '.openvideo-work\bundle-allow-list-check'
}
$OutputRoot = [IO.Path]::GetFullPath($OutputRoot)
$opRoot = Join-Path $OutputRoot ('allow-list-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $opRoot -Force | Out-Null
$stage = Join-Path $opRoot 'payload'
$payload = Join-Path $stage 'OpenVideo-test'; New-Item -ItemType Directory -Path $payload -Force | Out-Null

# Mirror the allow list and dev-only exclusions exactly as defined in the
# production script so any drift surfaces immediately here.
$allow = @(
  'apps\web\dist',
  'apps\web\public\openvideo.ico',
  'apps\web\index.html',
  'apps\web\vite.config.ts',
  'apps\web\tsconfig.json',
  'apps\web\tsconfig.app.json',
  'apps\web\tsconfig.node.json',
  'apps\gateway\dist',
  'apps\gateway\package.json',
  'apps\gateway\tsconfig.json',
  'scripts',
  'config',
  'package.json',
  'pnpm-lock.yaml',
  'pnpm-workspace.yaml',
  'OpenVideo.cmd',
  'README-WINDOWS.md',
  'README.md',
  'START-HERE.md',
  'DESIGN.md',
  'docs\licenses',
  'scripts\0-precheck.cmd'
)
$devOnlyScripts = @(
  'Apply-OpenVideoFullUpdate.ps1',
  'Build-OpenVideoFullUpdate.ps1',
  'Publish-OpenVideoFullUpdate.ps1',
  'Build-OpenVideoPortableExe.ps1',
  'New-OpenVideoShortcut.ps1',
  'Validate-OpenVideoUpdatePackage.ps1',
  'Ship-OpenVideoColleagueUpdate.ps1',
  'Bundle-OpenVideoGateway.mjs',
  'logs'
)

foreach ($rel in $allow) {
  $src = Join-Path $root $rel
  if (-not (Test-Path -LiteralPath $src)) {
    Write-Host "OPENVIDEO_ALLOWLIST_MISSING: $rel" -ForegroundColor Yellow
    continue
  }
  $dst = Join-Path $payload $rel
  if (Test-Path -PathType Container $src) {
    New-Item -ItemType Directory -Path $dst -Force | Out-Null
    if ($rel -eq 'scripts') {
      Get-ChildItem -LiteralPath $src -Force | Where-Object {
        $devOnlyScripts -notcontains $_.Name
      } | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $dst $_.Name) -Recurse -Force
      }
    } else {
      Get-ChildItem -LiteralPath $src -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $dst $_.Name) -Recurse -Force
      }
    }
  } else {
    New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
  }
}

# Show summary of what landed inside the simulated payload.
$srcTreeCount = (Get-ChildItem -LiteralPath (Join-Path $root 'apps\gateway\src') -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count
$distTreeCount = (Get-ChildItem -LiteralPath (Join-Path $root 'apps\gateway\dist') -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count
$payloadHasSrc = Test-Path -LiteralPath (Join-Path $payload 'apps\gateway\src\server.mjs')
$payloadHasBundle = Test-Path -LiteralPath (Join-Path $payload 'apps\gateway\dist\bundle.mjs')
$payloadHasMap = Test-Path -LiteralPath (Join-Path $payload 'apps\gateway\dist\bundle.mjs.map')
$payloadHasScripts = Test-Path -LiteralPath (Join-Path $payload 'apps\gateway\scripts')
$payloadScriptsCount = if ($payloadHasScripts) {
  (Get-ChildItem -LiteralPath (Join-Path $payload 'apps\gateway\scripts') -Recurse -File | Measure-Object).Count
} else { 0 }
$payloadHasBuildScript = Test-Path -LiteralPath (Join-Path $payload 'scripts\Build-OpenVideoFullUpdate.ps1')
$payloadHasBundleScript = Test-Path -LiteralPath (Join-Path $payload 'scripts\Bundle-OpenVideoGateway.mjs')
$payloadHasLauncher = Test-Path -LiteralPath (Join-Path $payload 'scripts\Start-OpenVideo.ps1')
$payloadAnyMapFiles = @(Get-ChildItem -LiteralPath $payload -Recurse -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.Extension -eq '.map' }).Count

Write-Host ""
Write-Host "OPENVIDEO_ALLOWLIST_REPORT: stage=$stage"
Write-Host "  src tree file count: $srcTreeCount (expect to be present in repo)"
Write-Host "  dist tree file count: $distTreeCount (expect to be present in repo)"
Write-Host "  payload has apps\gateway\src: $payloadHasSrc (expect False)"
Write-Host "  payload has apps\gateway\dist\bundle.mjs: $payloadHasBundle (expect True)"
Write-Host "  payload has apps\gateway\dist\bundle.mjs.map: $payloadHasMap (expect False)"
Write-Host "  payload any .map files: $payloadAnyMapFiles (expect 0)"
Write-Host "  payload has apps\gateway\scripts: $payloadHasScripts (expect False - dev tools excluded)"
Write-Host "  payload has scripts\Start-OpenVideo.ps1: $payloadHasLauncher (expect True)"
Write-Host "  payload has scripts\Build-OpenVideoFullUpdate.ps1: $payloadHasBuildScript (expect False)"
Write-Host "  payload has scripts\Bundle-OpenVideoGateway.mjs: $payloadHasBundleScript (expect False)"
Write-Host ""

$failures = @()
if ($payloadHasSrc)            { $failures += 'apps\gateway\src leaked into payload' }
if (-not $payloadHasBundle)    { $failures += 'apps\gateway\dist\bundle.mjs missing from payload' }
if ($payloadHasMap)            { $failures += 'apps\gateway\dist\bundle.mjs.map leaked into payload (sourcesContent would expose src)' }
if ($payloadAnyMapFiles -gt 0) { $failures += "$payloadAnyMapFiles source map file(s) leaked into payload" }
if ($payloadHasScripts)        { $failures += 'apps\gateway\scripts (dev tools) leaked into payload' }
if (-not $payloadHasLauncher)  { $failures += 'scripts\Start-OpenVideo.ps1 missing from payload' }
if ($payloadHasBuildScript)    { $failures += 'dev-only Build-OpenVideoFullUpdate.ps1 leaked into payload' }
if ($payloadHasBundleScript)   { $failures += 'dev-only Bundle-OpenVideoGateway.mjs leaked into payload' }

if ($failures.Count -gt 0) {
  Write-Host "OPENVIDEO_ALLOWLIST_FAILED:" -ForegroundColor Red
  foreach ($f in $failures) { Write-Host "  - $f" }
  exit 2
}
Write-Host "OPENVIDEO_ALLOWLIST_PASSED: src excluded, bundle included, dev tools excluded" -ForegroundColor Green
exit 0
