# Auto-Cut-CopyA 行为参考与许可证边界

## 审计对象

- 本地参考目录：`<AUTO_CUT_REFERENCE_ROOT>`（仅用于本机审计，不写入真实绝对路径）
- 审计时本地 HEAD：`1b0277044814eb88ad4df22059254c8dc3b2659e`
- 根许可证：MIT，`Copyright (c) 2026 Auto-Cut Contributors`
- 本地版本文件：`VERSION` = `1.5.0`
- canonical remote：不可确认；本地 Git 配置无 `remote.origin`，README 使用 `<your-repo-url>` 占位符。

本文件只记录开发期行为参考结论。Auto-Cut 不是 OpenVideo 正式上游、运行依赖或发行组件。

## 只读审计证据

审计于 2026-07-26 执行，命令中的路径必须由审计者在本机替换，输出不得记录真实绝对路径：

```powershell
$root = "<AUTO_CUT_REFERENCE_ROOT>"
git -C "$root" rev-parse HEAD
git -C "$root" status --short
git -C "$root" remote -v
Get-FileHash -Algorithm SHA256 "$root\LICENSE"
git -C "$root" ls-files "*LICENSE*" "*NOTICE*" "*COPYING*"
$utf8 = [System.Text.UTF8Encoding]::new($false)
function Get-ManifestHash([string[]]$Lines) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = $utf8.GetBytes(($Lines -join "`n") + "`n")
    ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace("-", "")
  } finally {
    $sha.Dispose()
  }
}
$all = @(git -C "$root" ls-files)
$vendor = @(git -C "$root" ls-files "scripts/vendor/pyJianYingDraft/**")
$all.Count
Get-ManifestHash $all
$vendor.Count
Get-ManifestHash $vendor
```

结果：

- HEAD：`1b0277044814eb88ad4df22059254c8dc3b2659e`
- worktree：clean
- remotes：空
- 根 `LICENSE` SHA-256：`F845991479D5269F3C28E01640E78A5FAE9EEF7669F8B19427E0EF3EF4A26B31`
- license/notice/copying 清单：只有根 `LICENSE`
- tracked files：259；按 `git ls-files` 输出顺序、UTF-8 无 BOM、LF 分隔且末尾 LF 的清单 SHA-256：`0B9DF27484C8055AE409516A67561E13DCD6984FB9961F4182CC53CA3C15FA33`
- vendored pyJianYingDraft tracked files：37；对应清单 SHA-256：`7773FB4ACC5AA1CEE9E115B539176518414DA36AB107F2B871A5A831B207A938`

这些证据只证明该本地快照的文件状态，不证明 canonical 来源、提交历史真实性、作者权属或根许可证覆盖所有 vendor/资源。

## 准入裁决

1. 本地根目录存在 MIT 文本；只有能独立证明由该权利人拥有且受该文本覆盖的内容，才可能按 MIT 条款使用。当前审计不把根许可证扩展为全树权属结论。
2. 当前 CopyA 无可审计 canonical repository URL，无法证明本地历史、所有文件和发布版本与权利来源一致。
3. `scripts/vendor/pyJianYingDraft` 未随本地 vendor 树提供独立 LICENSE/NOTICE；不得从该目录复制或再分发。
4. OpenVideo 已有受控 `upstream/pyJianYingDraft` 和完整性门禁，任何剪映能力只能基于该正式边界或 OpenVideo 自有代码实现。
5. 因上游来源和 vendor 许可链不完整，Auto-Cut 整体接入、打包、下载、启动和源码迁移保持 fail closed。

## Clean-room 行为需求

以下内容来自用户明确提出的能力和可从产品界面观察的黑盒工作流，可作为验收需求；不得把源文件、提示词、函数名、内部 DTO 或实现顺序转述给实现者。OpenVideo 必须使用自有 contract、命名、测试和实现重新表达：

- 自然语言请求路由到确定性编辑动作；
- 从长素材中 trim/cut 精确子片段并保留可编辑切口；
- 视频、配音、BGM、SFX、字幕、标题、花字、特效和关键帧分轨；
- 资源按名称或安全 token 解析，不猜测版本敏感内部 ID；
- 输出可继续二创的剪映草稿，而不是仅生成压平成片；
- 模板保存、应用和批量生成的用户工作流；
- 环境自检失败时不写草稿；
- 修订任务保留审计记录、操作 manifest 和可恢复错误。

这些行为进入 OpenVideo 的 `RichTimeline`、capability matrix 和 Agent 白名单，不保留 Auto-Cut 的具体 API、CLI 或 prompt 表达。

## 禁止复制或依赖的内容

- `skills/**/SKILL.md`、`rules/*.md` 的提示词、风格规则、示例正文和业务术语组合；
- `scripts/jy_wrapper.py`、`scripts/core/**`、`scripts/utils/**` 等实现；
- `scripts/vendor/pyJianYingDraft/**`；
- 剪映内部资源 ID、metadata 快照、收藏缓存和本地 CSV；
- 示例业务脚本、项目代号、用户草稿名和本机配置；
- 任何真实素材、草稿、缓存、模型、密钥或机器路径；
- 把 Auto-Cut 作为 OpenVideo 安装器、运行时、submodule 或 `upstream/` 正式依赖。

根许可证文本形式为 MIT 不证明它覆盖全树。OpenVideo 选择独立实现，以保证来源可审计、发行依赖最小化、命名和数据结构自有、测试边界明确。

## 黑盒能力观察

用户工作流与可见界面表现出以下范围，仅作为验收需求来源：

- 自然语言 / skill 路由；
- trim、cut、shift、批处理；
- 多轨剪映草稿；
- 本地 BGM、曲库检索思路、TTS、字幕；
- rich text / flower text；
- 视频特效、人脸特效、滤镜、转场；
- scale、position、rotation、opacity 关键帧；
- 文字模板和草稿片段模板；
- Windows 剪映桌面导出自动化，但文档仅宣称旧版本兼容。

OpenVideo 不据此宣称对应能力已经实现。真实支持状态只以 `docs/architecture/PACKAGING-CAPABILITY-MATRIX.md`、自动化测试和真实验收证据为准。

## 实现者隔离

- 后续 `PROD-003` 至 `REL-007` 主写者不得打开、搜索、复制或运行 `<AUTO_CUT_REFERENCE_ROOT>`。
- 实现输入只允许来自用户需求、本文件的黑盒需求、OpenVideo 自有架构 contract 和正式上游文档。
- 如需重新审计参考仓，必须由不参与对应实现的独立许可证审计者执行，并只回传许可结论与黑盒验收行为。
- code review 必须搜索 Auto-Cut 专有命名、prompt 片段、vendor 内容和清单 hash；发现相似表达时 fail closed 并要求来源证明。

## 未来重新评估条件

只有同时满足以下条件，才能提议把 Auto-Cut 由行为参考提升为受控第三方来源：

1. 获得 canonical repository URL 和维护者身份；
2. 固定公开 commit/tag，并验证 clean worktree；
3. 完成全树 license、NOTICE、vendor 和资源文件清单；
4. 证明所有拟使用文件均受兼容许可覆盖；
5. 形成与 OpenVideo 定位、发行方式和依赖模型相容的书面结论；
6. 通过独立法律/许可证审核；
7. 更新 `AGENTS.md`、第三方清单和发行门禁。

在这些条件满足前，结论保持：**行为参考可用，代码/提示词/vendor/运行依赖不可迁入。**
