import { readFile, mkdtemp, rm } from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'

const manifest = (await import('../config/jianying-compatibility.json', { with: { type: 'json' } })).default
const main = async () => {
  const root = loadLocalRuntimeConfig().dataRoot
  const leasePath = path.join(root, 'evidence', 'jy045-mask', 'pending.json')
  const lease = JSON.parse(await readFile(leasePath, 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== lease.profileId) throw new Error('JY045_PROFILE_MISMATCH')
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), 'openvideo-jy045-verify-'))
  try {
    const plain = path.join(tempRoot, 'draft_content.json')
    const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(path.join(lease.draftRoot, lease.draftId, 'draft_content.json'), plain)
    const content = JSON.parse(await readFile(plain, 'utf8'))
    const masks = Array.isArray(content?.materials?.common_mask) ? content.materials.common_mask : []
    const mask = masks[0]
    const attached = (content?.tracks ?? []).flatMap(track => track?.segments ?? []).some(segment => Array.isArray(segment?.extra_material_refs) && segment.extra_material_refs.includes(mask?.id))
    const width = mask?.config?.width
    const height = mask?.config?.height
    const ok = (meta.scheme ?? meta.decryptedFrom) === 'encrypt_v2' && masks.length === 1 && attached && width === 0.65 && Math.abs(height - 0.3640625) < 0.00001
    process.stdout.write(JSON.stringify(ok ? { ok: true, scheme: 'encrypt_v2', commonMaskCount: 1, attached: true, normalizedWidth: 0.65, normalizedHeight: 0.3640625 } : { ok: false, code: 'JY045_MASK_EVIDENCE_INVALID', commonMaskCount: masks.length, attached: Boolean(attached) }) + '\n')
  } finally {
    await rm(tempRoot, { recursive: true, force: true })
  }
}
main().catch(error => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY045_VERIFY_FAILED' }) + '\n'); process.exitCode = 1 })
