import { execFile } from 'node:child_process'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { parseJianyingBlendCatalog } from '../apps/gateway/src/jianying-blend-catalog.mjs'
import { createScaleEvidenceTimeline, projectScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'

const run = promisify(execFile)
const manifest = (await import('../config/jianying-compatibility.json', { with: { type: 'json' } })).default
const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== 'jianying-11-1-provisional') throw new Error('JY046_PROFILE_UNSUPPORTED')
  const root = loadLocalRuntimeConfig().dataRoot
  const catalog = parseJianyingBlendCatalog(JSON.parse(await readFile(path.join(root, 'catalogs', 'jy046-blend-catalog.json'), 'utf8')))
  const entry = catalog?.entries.find((item) => item.role === 'initial')
  const expectedPost = catalog?.entries.find((item) => item.role === 'expected_post')
  if (!entry?.resource_id || !expectedPost?.resource_id) throw new Error('JY046_CATALOG_MISSING')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy046-blend-'))
  const video = path.join(mediaRoot, 'video.mp4'); const audio = path.join(mediaRoot, 'voice.wav')
  await run('ffmpeg', ['-hide_banner','-loglevel','error','-y','-f','lavfi','-i','color=c=red:s=360x640:r=30','-t','4','-pix_fmt','yuv420p',video])
  await run('ffmpeg', ['-hide_banner','-loglevel','error','-y','-f','lavfi','-i','anullsrc=r=16000:cl=mono','-t','4','-ac','1',audio])
  const projected = projectScaleEvidenceTimeline(desktop.profileId, createScaleEvidenceTimeline())
  const draftId = `OpenVideo-JY046-blend-${Date.now()}`
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT, getRenderOptions: () => ({ captions:false,bgmPath:null,subtitleStyle:'default',captionSegments:[],titleSegments:[],keywordHighlights:[],timelinePackaging:{...projected.packaging,blend_segments:[{resource_id:entry.resource_id,target_start_us:0,target_duration_us:4_000_000}],sfx_segments:[],effect_segments:[],sticker_segments:[],filter_segments:[],animation_segments:[],mask_segments:[],voiceover_segments:[],bgm:{fade_in_us:0,fade_out_us:0}} }) })
  const request = { job_id:`job-${draftId}`,request_id:`request-${draftId}`,output_policy:{draft_id:draftId},export_request:{preparation:projected.preparation},orientation:'portrait',materials:[{path:video}],voiceovers:[{path:audio}] }
  const result = await writer.writeDraft(request)
  if (await writer.verifyDraft({ job_id:request.job_id,request:{export_request:request.export_request},write_result:result }) !== true) throw new Error('JY046_VERIFY_FAILED')
  if (await writer.releaseDraft({ job_id:request.job_id,write_result:result }) !== true) throw new Error('JY046_RELEASE_FAILED')
  const draftContent = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
  const evidence = path.join(root,'evidence','jy046-blend'); await (await import('node:fs/promises')).mkdir(evidence,{recursive:true}); await writeFile(path.join(evidence,'pending.json'),JSON.stringify({schema_version:3,draftId,profileId:desktop.profileId,draftRoot:desktop.draftRoot,mediaRoot,blendToken:entry.blend_token,expectedPostBlendToken:expectedPost.blend_token,catalogFingerprint:catalog.catalog_fingerprint,expectedResourceId:entry.resource_id,expectedPostResourceId:expectedPost.resource_id,targetStartUs:0,targetDurationUs:4_000_000,preOpenFingerprint:createHash('sha256').update(draftContent).digest('hex')}),{encoding:'utf8',mode:0o600})
  process.stdout.write(JSON.stringify({ok:true,manual_open_required:true,draft_prefix:'OpenVideo-JY046-blend-',profile:desktop.profileId,version:desktop.version})+'\n')
}
main().catch(error=>{process.stdout.write(JSON.stringify({ok:false,code:error?.message??'JY046_FAILED'})+'\n');process.exitCode=1})
