import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { lstat, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import {
  assertPackagingWriterBinding,
  computePackagingEntryBindingFingerprint,
  parsePrivatePackagingResourceIndex,
  resolvePrivatePackagingResourceToken,
} from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import {
  planPrivatePackagingBatch,
  projectPrivatePackagingBatchForWriter,
} from '../apps/gateway/src/jianying-private-batch-packaging.mjs'
import { buildFamilyVersionBatchRefreshPlan } from '../apps/gateway/src/jianying-private-batch-refresh.mjs'
import { securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { deriveRenderBundleIdentity } from '../apps/gateway/src/jianying-workbench-bridge.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const run = promisify(execFile)
const segmentDurationUs = 2_000_000
const genericFamilies = new Set(['video_effect', 'sticker', 'video_animation', 'mask', 'blend'])
const evidenceFamilies = new Set([...genericFamilies, 'flower'])
const capabilityByFamily = Object.freeze({
  video_effect: 'effect.video.named',
  sticker: 'sticker.named',
  video_animation: 'animation.video.named',
  mask: 'mask.video.named',
  blend: 'blend.video.named',
})
const generatorLockStaleMs = 30 * 60 * 1000
const safeFailureCodePattern = /^JY[0-9A-Z_]+$/u

/**
 * Acquire the private generator lock. A lock directory is intentionally used
 * for atomic creation; only an old, ordinary directory can be reclaimed.
 * @param {string} lockPath
 * @param {{now?: number, staleMs?: number}} [options]
 */
export const acquireJY138GeneratorLock = async (lockPath, { now = Date.now(), staleMs = generatorLockStaleMs } = {}) => {
  const create = async () => {
    await mkdir(lockPath, { recursive: false, mode: 0o700 })
    await writeFile(path.join(lockPath, 'owner.json'), `${JSON.stringify({ pid: process.pid, created_at: now })}\n`, {
      encoding: 'utf8', mode: 0o600, flag: 'wx',
    })
  }
  try {
    await create()
    return true
  } catch (error) {
    if (error?.code !== 'EEXIST') throw error
  }
  let lockStat
  try { lockStat = await lstat(lockPath) } catch (error) {
    if (error?.code === 'ENOENT') return acquireJY138GeneratorLock(lockPath, { now, staleMs })
    throw error
  }
  let ownerPid = null
  if (lockStat.isDirectory() && !lockStat.isSymbolicLink()) {
    try {
      const owner = JSON.parse(await readFile(path.join(lockPath, 'owner.json'), 'utf8'))
      ownerPid = Number.isSafeInteger(owner?.pid) ? owner.pid : null
    } catch {
      ownerPid = null
    }
  }
  const stale = lockStat.isDirectory() && !lockStat.isSymbolicLink() && now - lockStat.mtimeMs > staleMs
  if (!stale) throw new Error('JY138_EVIDENCE_GENERATOR_BUSY')
  if (Number.isSafeInteger(ownerPid) && ownerPid > 0) {
    try {
      process.kill(ownerPid, 0)
      throw new Error('JY138_EVIDENCE_GENERATOR_BUSY')
    } catch (error) {
      if (error?.message === 'JY138_EVIDENCE_GENERATOR_BUSY' || error?.code === 'EPERM') throw error
    }
  }
  await rm(lockPath, { recursive: true, force: true })
  try {
    await create()
    return true
  } catch (error) {
    if (error?.code === 'EEXIST') throw new Error('JY138_EVIDENCE_GENERATOR_BUSY')
    throw error
  }
}

export const publicFailureCode = (error) => {
  const message = typeof error?.message === 'string' ? error.message : ''
  return safeFailureCodePattern.test(message) ? message : 'JY138_EVIDENCE_DRAFT_FAILED'
}

/**
 * Build an ephemeral writer candidate view for a one-use evidence draft.
 * It is never persisted or passed to production bootstrap: only signed,
 * live-draft evidence can make the original discovery index writer-eligible.
 * @param {any} index
 */
export const buildPrivateBatchEvidenceCandidateIndex = (index) => Object.freeze({
  ...index,
  entries: Object.freeze(index.entries.map((entry) => {
    if (entry?.state !== 'discoverable' || !evidenceFamilies.has(entry.family)) return entry
    try {
      assertPackagingWriterBinding(entry.family, entry.private_binding)
      return Object.freeze({ ...entry, state: 'writer_eligible', writer_eligible: true })
    } catch {
      return entry
    }
  })),
})

/**
 * Keep the evidence writer bound to the ephemeral, evidence-only candidate
 * view. The discovery index is never promoted or exposed by this resolver.
 * @param {any} candidateIndex
 */
export const createPrivateBatchEvidenceTokenResolver = (candidateIndex) =>
  (packagingToken) => resolvePrivatePackagingResourceToken(candidateIndex, packagingToken)

/**
 * Select several distinct candidates per writer family for one bounded smoke
 * draft. This is evidence collection, not admission: every selected binding
 * remains discovery-only until the signed same-draft verifier accepts it.
 * @param {any} candidateIndex
 * @param {ReadonlySet<string> | null} [familyFilter]
 * @param {{maxPerFamily?: number, maxTotal?: number}} [options]
 */
export const buildPrivateBatchEvidenceRequests = (candidateIndex, familyFilter = null, { maxPerFamily = 3, maxTotal = 15 } = {}) => {
  if (!Number.isSafeInteger(maxPerFamily) || maxPerFamily < 1 || maxPerFamily > 4 ||
      !Number.isSafeInteger(maxTotal) || maxTotal < 1 || maxTotal > 24) {
    throw new Error('JY172_EVIDENCE_BATCH_LIMIT_INVALID')
  }
  const selected = []
  for (const family of ['video_effect', 'sticker', 'video_animation', 'mask', 'blend']) {
    if (familyFilter && !familyFilter.has(family)) continue
    // Keep the same catalog order as JY-179's refresh plan. The generator
    // intersects this request list with that plan below; sorting by opaque
    // token here can select a different subset and collapse to zero requests.
    const entries = candidateIndex.entries
      .filter((item) => item.family === family && item.state === 'writer_eligible')
      .slice(0, maxPerFamily)
    selected.push(...entries)
    if (selected.length >= maxTotal) break
  }
  return Object.freeze(selected.slice(0, maxTotal).map((entry, index) => Object.freeze({
    packagingToken: entry.packaging_token,
    targetStartUs: index * segmentDurationUs,
    targetDurationUs: segmentDurationUs,
  })))
}

/**
 * Build flower placements beside, but never inside, the generic private batch
 * plan. Flower is written through the established title-segment path.
 * @param {any} candidateIndex
 * @param {{startIndex?: number, max?: number, selectedTokens?: ReadonlySet<string>|null}} [options]
 */
export const buildJY138FlowerEvidencePlan = (candidateIndex, { startIndex = 0, max = 3, selectedTokens = null } = {}) => {
  if (!Number.isSafeInteger(startIndex) || startIndex < 0 || !Number.isSafeInteger(max) || max < 1 || max > 4) {
    throw new Error('JY138_FLOWER_EVIDENCE_LIMIT_INVALID')
  }
  return Object.freeze(candidateIndex.entries
    .filter((entry) => entry.family === 'flower' && entry.state === 'writer_eligible' &&
      (!selectedTokens || selectedTokens.has(entry.packaging_token)))
    .slice(0, max)
    .map((entry, index) => {
      assertPackagingWriterBinding(entry.family, entry.private_binding)
      const targetStartUs = (startIndex + index) * segmentDurationUs
      return Object.freeze({
        packagingToken: entry.packaging_token,
        placementId: `${entry.packaging_token}:${targetStartUs}:${segmentDurationUs}`,
        family: 'flower',
        kind: 'flower',
        privateBinding: structuredClone(entry.private_binding),
        bindingFingerprint: computePackagingEntryBindingFingerprint({ family: entry.family, privateBinding: entry.private_binding }),
        targetStartUs,
        targetDurationUs: segmentDurationUs,
      })
    }))
}

/** @param {ReadonlyArray<Record<string, any>>} writerPlan */
export const buildJY138PrivateBatchEvidenceTimeline = (writerPlan) => {
  if (!Array.isArray(writerPlan) || writerPlan.length === 0) throw new Error('JY138_EVIDENCE_BATCH_EMPTY')
  const durationUs = writerPlan.reduce((maximum, entry) => Math.max(maximum, entry.targetStartUs + entry.targetDurationUs), 0)
  const effects = writerPlan.filter((entry) => entry.family !== 'flower').map((entry, index) => {
    const capabilityId = capabilityByFamily[entry.family]
    if (!capabilityId) throw new Error('JY138_EVIDENCE_FAMILY_UNSUPPORTED')
    const parameters = entry.family === 'video_animation'
      ? { animationToken: entry.packagingToken }
      : entry.family === 'mask'
        ? { maskToken: entry.packagingToken, size: 0.5 }
        : entry.family === 'blend'
          ? { blendToken: entry.packagingToken }
          : { packagingToken: entry.packagingToken }
    return {
      segmentId: `jy138-packaging-${index + 1}`,
      kind: 'effect',
      capabilityId,
      targetRange: { startUs: entry.targetStartUs, durationUs: entry.targetDurationUs },
      intensity: 1,
      parameters,
      keyframes: [],
    }
  })
  const flowers = writerPlan.filter((entry) => entry.family === 'flower').map((entry, index) => ({
    segmentId: `jy138-flower-${index + 1}`,
    kind: 'rich_text',
    capabilityId: 'text.flower.private',
    targetRange: { startUs: entry.targetStartUs, durationUs: entry.targetDurationUs },
    text: `OpenVideo packaging evidence ${index + 1}`,
    styleToken: 'rich-emphasis',
    keyframes: [],
    animationIn: null,
    animationOut: null,
    templateToken: entry.packagingToken,
  }))
  const videoSegments = writerPlan.map((entry, index) => ({
    segmentId: `jy138-video-${index + 1}`, kind: 'video',
    asset: { authorizationId: 'jy138-auth', assetId: 'jy138-asset', sceneId: `jy138-scene-${index + 1}` },
    sourceRange: { startUs: 0, durationUs: entry.targetDurationUs },
    targetRange: { startUs: entry.targetStartUs, durationUs: entry.targetDurationUs },
    fit: 'cover', volume: 1, speed: { numerator: 1, denominator: 1 }, keyframes: [], effects: [],
    audit: { origin: 'editor', candidateId: 'jy138-candidate', instructionFingerprint: null },
    transitionOut: index === writerPlan.length - 1
      ? { capabilityId: 'transition.none', durationUs: 0, parameters: {} }
      : { capabilityId: 'transition.cut', durationUs: 0, parameters: {} },
  }))
  const tracks = [
    {
      trackId: 'video-primary', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary',
      segments: videoSegments,
    },
    ...(effects.length > 0
      ? [{ trackId: 'packaging-evidence', order: 1, enabled: true, locked: false, kind: 'effect', segments: effects }]
      : []),
    ...(flowers.length > 0
      ? [{ trackId: 'title-primary', order: 2, enabled: true, locked: false, kind: 'title', segments: flowers }]
      : []),
  ]
  return finalizeRichTimeline(sealRichTimeline({
    schemaVersion: 1, timelineId: 'jy138-private-batch-evidence', projectId: 'jy138-evidence', revision: 1,
    parentRevision: null, parentRevisionFingerprint: null, status: 'draft',
    createdAt: '2026-08-18T00:00:00.000Z', durationUs, orientation: 'portrait',
    fps: { numerator: 30, denominator: 1 },
    source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null },
    tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks),
  }))
}

/** @param {ReadonlyArray<Record<string, any>>} writerPlan */
export const buildJY138EvidenceBindings = (writerPlan) => Object.freeze(writerPlan.map((entry) => Object.freeze({
  packaging_token: entry.packagingToken,
  family: entry.family,
  binding_fingerprint: computePackagingEntryBindingFingerprint({ family: entry.family, privateBinding: entry.privateBinding }),
  target_start_us: entry.targetStartUs,
  target_duration_us: entry.targetDurationUs,
})))

const main = async () => {
  const launcherConfig = await loadLauncherRuntimeConfig()
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true) throw new Error('JY138_PROFILE_UNAVAILABLE')
  const { dataRoot } = launcherConfig
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy132-packaging-resources')
  const generatorLock = path.join(evidenceRoot, '.generator-lock')
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  // Use the same candidate-first private fallback order as production. A
  // malformed or stale candidate must not prevent an already verified legacy
  // catalog from being used for a fresh bounded evidence draft.
  let discoveryIndex = null
  for (const fileName of ['native018-private-draft-catalog.json', 'jy172-private-packaging-catalog.json', 'jy132-packaging-resource-catalog.json']) {
    try {
      const catalogRaw = JSON.parse(await readFileNoReparse(path.join(dataRoot, 'catalogs', fileName), dataRoot))
      discoveryIndex = parsePrivatePackagingResourceIndex(catalogRaw, { profileId: desktop.profileId, appVersion: desktop.version })
      break
    } catch { /* try the next private catalog */ }
  }
  if (!discoveryIndex) throw new Error('JY138_EVIDENCE_CATALOG_EMPTY')
  const candidateIndex = buildPrivateBatchEvidenceCandidateIndex(discoveryIndex)
  const requestedFamilies = process.argv.includes('--family')
    ? new Set([process.argv[process.argv.indexOf('--family') + 1]])
    : null
  const refreshPlan = buildFamilyVersionBatchRefreshPlan(candidateIndex, { maxPerFamily: 3, maxTotal: 15 })
  const selectedTokens = new Set(refreshPlan.groups
    .filter((group) => !requestedFamilies || requestedFamilies.has(group.family))
    .flatMap((group) => group.selected))
  const requests = buildPrivateBatchEvidenceRequests(candidateIndex, requestedFamilies)
    .filter((request) => selectedTokens.has(request.packagingToken))
  if (requests.length === 0) throw new Error('JY138_EVIDENCE_CATALOG_EMPTY')
  const batch = planPrivatePackagingBatch(candidateIndex, requests)
  if (batch.summary.some((entry) => entry.status !== 'accepted')) {
    throw new Error('JY138_EVIDENCE_BATCH_UNWRITABLE')
  }
  const flowerPlan = !requestedFamilies || requestedFamilies.has('flower')
    ? buildJY138FlowerEvidencePlan(candidateIndex, {
        startIndex: batch.writerPlan.length,
        selectedTokens,
      })
    : Object.freeze([])
  const evidencePlan = Object.freeze([...batch.writerPlan, ...flowerPlan])
  if (evidencePlan.length === 0) throw new Error('JY138_EVIDENCE_BATCH_UNWRITABLE')
  const writerProjection = projectPrivatePackagingBatchForWriter(batch.writerPlan)
  const timeline = buildJY138PrivateBatchEvidenceTimeline(evidencePlan)
  const evidenceCapabilities = new Set(evidencePlan.map((entry) => entry.family === 'flower' ? 'text.flower.private' : capabilityByFamily[entry.family]))
  const productionRegistry = createEditorCapabilityRegistry({ jianyingProfileId: desktop.profileId })
  const evidenceRegistry = {
    assertWriterCapability: (capabilityId, target) => {
      // The bounded evidence draft necessarily adds one packaging track. The
      // direct writer already has an append-track path, so permit only that
      // structural operation in this evidence harness; production admission
      // still requires the signed same-draft receipt below.
      if (target === 'jianying' && (evidenceCapabilities.has(capabilityId) || capabilityId === 'track.insert' || capabilityId === 'track.insert_many')) return {}
      return productionRegistry.assertWriterCapability(capabilityId, target)
    },
    assertAllowedParameters: (...args) => productionRegistry.assertAllowedParameters(...args),
  }
  const projected = projectRichTimelineToJianyingExport(timeline, {
    jianyingProfileId: desktop.profileId,
    capabilityRegistry: evidenceRegistry,
    allowAppendTrackFallback: true,
  })
  const titleSegments = projected.packaging.rich_text_segments.map((segment) => {
    const entry = evidencePlan.find((candidate) => candidate.packagingToken === segment.template_token && candidate.family === 'flower')
    if (!entry) throw new Error('JY138_FLOWER_BINDING_UNAVAILABLE')
    return {
      text: segment.text,
      target_start_us: segment.target_start_us,
      target_duration_us: segment.target_duration_us,
      flower_effect_id: entry.privateBinding.effectId,
      flower_resource_id: entry.privateBinding.resourceId,
    }
  })
  const pythonModuleRoot = launcherConfig.pyJianyingDraftRoot
  if (!pythonModuleRoot || !path.isAbsolute(pythonModuleRoot)) throw new Error('JY002_PATH_PERMISSION_DENIED')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(evidenceRoot)
  await acquireJY138GeneratorLock(generatorLock)
  try {
    await lstat(pendingPath)
    throw new Error('JY138_PENDING_EVIDENCE_EXISTS')
  } catch (error) {
    if (error?.message === 'JY138_PENDING_EVIDENCE_EXISTS') {
      await rm(generatorLock, { recursive: true, force: true })
      throw error
    }
    if (error?.code !== 'ENOENT') {
      await rm(generatorLock, { recursive: true, force: true })
      throw error
    }
  }

  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy138-private-batch-'))
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const draftId = `OpenVideo-JY138-private-batch-${Date.now()}`
  const request = {
    job_id: `job-${draftId}`,
    request_id: `request-${draftId}`,
    output_policy: { draft_id: draftId },
    export_request: { preparation: projected.preparation },
    orientation: 'portrait',
    materials: evidencePlan.map(() => ({ path: videoPath })),
    voiceovers: [],
  }
  const writer = createPyJianyingDraftWriter({
    draftRoot: desktop.draftRoot,
    pythonModuleRoot,
    resolvePrivatePackagingToken: createPrivateBatchEvidenceTokenResolver(candidateIndex),
    getRenderOptions: () => ({
      captions: false, bgmPath: null, subtitleStyle: 'default', captionSegments: [], titleSegments, keywordHighlights: [],
      renderBundleIdentity: deriveRenderBundleIdentity({
        timeline,
        preparation: projected.preparation,
        timelinePackaging: { ...writerProjection, private_batch_plan: batch.writerPlan, video: [], voiceover_segments: [], sfx_segments: [], audio_effect_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 }, filter_segments: [], chroma_segments: [], text_animation_segments: [], background_segments: [] },
        desktopProfile: desktop,
        packagingResourceIndex: candidateIndex,
      }),
      timelinePackaging: { ...writerProjection, private_batch_plan: batch.writerPlan, video: [], voiceover_segments: [], sfx_segments: [], audio_effect_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 }, filter_segments: [], chroma_segments: [], text_animation_segments: [], background_segments: [] },
    }),
  })
  try {
    await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', String(timeline.durationUs / 1_000_000), '-pix_fmt', 'yuv420p', videoPath])
    const result = await writer.writeDraft(request)
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) {
      throw new Error('JY138_DRAFT_VERIFY_FAILED')
    }
    if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY138_DRAFT_RELEASE_FAILED')
    const owner = JSON.parse(await readFileNoReparse(path.join(desktop.draftRoot, draftId, '.openvideo-owner.json'), desktop.draftRoot))
    if (typeof owner?.bundle_fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(owner.bundle_fingerprint)) {
      throw new Error('QA010_CANONICAL_BUNDLE_METADATA_MISSING')
    }
    const encrypted = await readFileNoReparseBuffer(path.join(desktop.draftRoot, draftId, 'draft_content.json'), desktop.draftRoot)
    await writeFile(pendingPath, `${JSON.stringify({
      schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, profile_id: desktop.profileId,
      app_version: desktop.version, catalog_fingerprint: discoveryIndex.catalogFingerprint,
      bundle_fingerprint: owner.bundle_fingerprint,
       admitted_bindings: buildJY138EvidenceBindings(evidencePlan),
      pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex'), media_root: mediaRoot,
    })}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    process.stdout.write(JSON.stringify({
      ok: true, manual_open_required: true, draft_prefix: 'OpenVideo-JY138-private-batch-',
       families: [...new Set(evidencePlan.map((entry) => entry.family))], placements: evidencePlan.length,
      refresh_groups: refreshPlan.groups.map(({ family, total, ready, discoveryOnly, selected }) => ({ family, total, ready, discoveryOnly, selected })),
      profile: desktop.profileId, version: desktop.version,
      next: 'Open this exact draft, confirm every listed package is present, change one visible packaging setting without adding a new resource, save, fully close and reopen Jianying, then run Verify-JY132PackagingResourceEvidence.mjs with the required manual attestation.',
    }) + '\n')
  } catch (error) {
    await writer.cleanupDraft({ job_id: request.job_id }).catch(() => {})
    await rm(mediaRoot, { recursive: true, force: true })
    throw error
  } finally {
    await rm(generatorLock, { recursive: true, force: true })
  }
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  main().catch((error) => {
    process.stdout.write(JSON.stringify({ ok: false, code: publicFailureCode(error) }) + '\n')
    process.exitCode = 1
  })
}
