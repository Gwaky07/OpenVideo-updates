import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const sourceDraft = process.env.OPENVIDEO_JY064_SOURCE_DRAFT
const effectName = process.env.OPENVIDEO_JY064_EFFECT_NAME
const manifest = JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8'))
const catalogPath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs', 'jy064-audio-effect-catalog.json')
const canonical = (value) => JSON.stringify(value)

const main = async () => {
  if (typeof sourceDraft !== 'string' || !/^[^\\/:*?"<>|]+$/u.test(sourceDraft) || typeof effectName !== 'string' || effectName.trim().length === 0) throw new Error('JY064_SOURCE_DRAFT_REQUIRED')
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true || !['jianying-11-1-provisional', 'jianying-11-2-provisional'].includes(desktop.profileId)) throw new Error('JY064_PROFILE_UNSUPPORTED')
  const temporary = await mkdtemp(path.join(tmpdir(), 'openvideo-jy064-audio-catalog-'))
  try {
    const plain = path.join(temporary, 'draft_content.json')
    const source = path.join(desktop.draftRoot, sourceDraft, 'draft_content.json')
    const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(source, plain)
    if ((meta.scheme ?? meta.decryptedFrom) !== 'encrypt_v2') throw new Error('JY064_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8'))
    const effects = (content.materials?.audio_effects ?? []).filter((item) => item?.type === 'audio_effect' && item?.name === effectName && typeof item?.resource_id === 'string')
    if (effects.length !== 1) throw new Error('JY064_AUDIO_EFFECT_CARDINALITY_INVALID')
    const effect = effects[0]
    const token = `ovjaudfx_v1_${createHash('sha256').update(effect.resource_id).digest('hex')}`
    const body = { schema_version: 1, kind: 'jy064_audio_effect_catalog', catalog_version: '1.0.0', entries: [{ capability_id: 'audio.effect.named', effect_token: token, resource_id: effect.resource_id, category_id: effect.category_id ?? null, audio_adjust_params: effect.audio_adjust_params ?? [] }] }
    const catalog = { ...body, catalog_fingerprint: createHash('sha256').update(canonical(body)).digest('hex') }
    const root = path.dirname(catalogPath())
    await mkdir(root, { recursive: true, mode: 0o700 }); await securePrivateRuntimeRoot(root)
    await writeFile(catalogPath(), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
    process.stdout.write(JSON.stringify({ ok: true, binding_count: 1, profile: desktop.profileId }) + '\n')
  } finally { await rm(temporary, { recursive: true, force: true }) }
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY064_CATALOG_IMPORT_FAILED' }) + '\n'); process.exitCode = 1 })
