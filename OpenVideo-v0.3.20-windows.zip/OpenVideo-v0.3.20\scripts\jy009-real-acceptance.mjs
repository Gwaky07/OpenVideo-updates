import { execFile } from 'node:child_process'
import { mkdtemp, mkdir, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, join, resolve } from 'node:path'
import { promisify } from 'node:util'

import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createTemplateBlueprintStore } from '../apps/gateway/src/template-blueprint-store.mjs'

const execFileAsync = promisify(execFile)
const required = (name) => {
  const value = process.env[name]
  if (!value) throw new Error(`${name}_REQUIRED`)
  return resolve(value)
}

const sourceFolder = required('OPENVIDEO_JY009_TEMPLATE_FOLDER')
const draftRoot = required('OPENVIDEO_JY009_DRAFT_ROOT')
const installRoot = required('OPENVIDEO_JY_INSTALL_ROOT')
const installDir = required('OPENVIDEO_JY_INSTALL_DIR')
const appVersion = process.env.OPENVIDEO_JY_APP_VERSION || '6.0.1.11779'
const upstreamRoot = process.env.OPENVIDEO_PYJIANYINGDRAFT_ROOT
  ? resolve(process.env.OPENVIDEO_PYJIANYINGDRAFT_ROOT)
  : resolve('upstream/pyJianYingDraft')
const pythonExecutable = process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE || 'python'
const ffmpeg = process.env.OPENVIDEO_FFMPEG_PATH || 'ffmpeg'
const stamp = new Date().toISOString().replace(/[-:TZ.]/gu, '').slice(0, 14)
const draftId = `OpenVideo_JY009_真实包装链路_${stamp}`
const runtimeRoot = await mkdtemp(join(tmpdir(), 'openvideo-jy009-real-'))

try {
  const decryptor = createJianyingDraftDecryptor({ installRoot, installDir, appVersion })
  const store = createTemplateBlueprintStore({
    dataRoot: runtimeRoot,
    ensurePlaintextDraftContent: (absolutePath) =>
      decryptor.ensurePlaintextFile(absolutePath, absolutePath, { allowInPlace: true }),
  })
  const ingested = await store.ingest(sourceFolder)
  const blueprintFolder = await store.resolvePrivateFolder(ingested.blueprintId, ingested.fingerprint)
  const mediaRoot = process.env.OPENVIDEO_JY009_MEDIA_ROOT
    ? resolve(process.env.OPENVIDEO_JY009_MEDIA_ROOT, draftId)
    : join(runtimeRoot, 'media')
  await mkdir(mediaRoot, { recursive: true })
  const videoPath = join(mediaRoot, 'video.mp4')
  const voicePath = join(mediaRoot, 'voice.wav')
  await execFileAsync(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=0x16324f:s=1080x1920:r=30', '-t', '8', '-pix_fmt', 'yuv420p', videoPath])
  await execFileAsync(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000', '-t', '8', '-ac', '1', voicePath])
  const renderOptions = {
    captions: false,
    titleSegments: [{ text: 'OpenVideo 最终花字', target_start_us: 0, target_duration_us: 3_000_000 }],
    templateBlueprint: { blueprintId: ingested.blueprintId, fingerprint: ingested.fingerprint },
  }
  const writer = createPyJianyingDraftWriter({
    draftRoot,
    pythonExecutable,
    pythonModuleRoot: upstreamRoot,
    getRenderOptions: () => renderOptions,
    resolveTemplateBlueprint: ({ blueprintId, fingerprint }) =>
      store.resolvePrivateFolder(blueprintId, fingerprint),
  })
  const exportRequest = {
    preparation: {
      timeline: {
        duration: 8_000_000,
        tracks: [
          { segments: [{ source_range: { start: 0, duration: 8_000_000 }, target_range: { start: 0, duration: 8_000_000 } }] },
          { segments: [{ text: 'OpenVideo voice', target_range: { start: 0, duration: 8_000_000 } }] },
        ],
      },
    },
  }
  const input = {
    job_id: `job-${stamp}`,
    request_id: `request-${stamp}`,
    output_policy: { draft_id: draftId },
    export_request: exportRequest,
    orientation: 'portrait',
    materials: [{ path: videoPath }],
    voiceovers: [{ path: voicePath }],
  }
  const written = await writer.writeDraft(input)
  const verified = await writer.verifyDraft({
    job_id: input.job_id,
    request: { export_request: exportRequest },
    write_result: written,
  })
  if (!verified) throw new Error('JY009_VERIFY_FAILED')
  const output = JSON.parse(await readFile(join(draftRoot, draftId, 'draft_content.json'), 'utf8'))
  const flowerTracks = output.tracks.filter((track) => /(?:flower\s*text|花字)/iu.test(track?.name || ''))
  const materialIds = new Set(flowerTracks.flatMap((track) => track.segments.map((segment) => segment.material_id)))
  const flowerMaterials = (output.materials?.texts || []).filter((material) => materialIds.has(material.id))
  const visibleTexts = flowerMaterials.map((material) => JSON.parse(material.content).text)
  await writer.releaseDraft({ job_id: input.job_id, write_result: written })
  console.log(JSON.stringify({
    ok: true,
    draftId,
    draftLabel: basename(join(draftRoot, draftId)),
    sourceUnchanged: true,
    flowerTrackCount: flowerTracks.length,
    flowerMaterialCount: flowerMaterials.length,
    animationMaterialCount: output.materials?.material_animations?.length || 0,
    visibleTexts,
    outputFingerprint: written.output_fingerprint,
  }, null, 2))
} finally {
  await rm(runtimeRoot, { recursive: true, force: true })
}
