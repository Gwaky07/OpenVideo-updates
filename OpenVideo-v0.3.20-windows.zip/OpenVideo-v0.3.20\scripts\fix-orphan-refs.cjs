// One-shot data fix: remove orphan references from project-references.json.
//
// Orphan references point to a sourceAuthorizationId that no longer has a valid
// `authorized` authorization (e.g. the source folder was re-authorized, the
// authorization status was marked `orphaned`, or the authorization was deleted).
// The Gateway UI renders these as `availability: unavailable` and counts them
// toward "待分析" — this script removes them so the UI shows the real picture.
//
// Usage:
//   node scripts/fix-orphan-refs.cjs                      # dry-run by default
//   node scripts/fix-orphan-refs.cjs --apply             # actually write
//   node scripts/fix-orphan-refs.cjs --dataRoot=X:\path --apply
//
// The script reads the data root from (in order):
//   1. --dataRoot=<path> command line arg
//   2. process.env.OPENVIDEO_RUNTIME_DATA_ROOT
//   3. process.env.LOCALAPPDATA + '/OpenVideo/data' (Windows default)

const fs = require('node:fs');
const path = require('node:path');

const args = process.argv.slice(2);
const apply = args.includes('--apply');
let customRoot = args.find(function(a) { return a.startsWith('--dataRoot='); });
if (customRoot) customRoot = customRoot.slice('--dataRoot='.length);

const dataRoot =
  customRoot ||
  process.env.OPENVIDEO_RUNTIME_DATA_ROOT ||
  (process.env.LOCALAPPDATA ? process.env.LOCALAPPDATA + '\\OpenVideo\\data' : null);

if (!dataRoot) {
  console.error('Could not resolve data root. Pass --dataRoot=<path> or set OPENVIDEO_RUNTIME_DATA_ROOT.');
  process.exit(1);
}

const prPath = path.join(dataRoot, 'material-library/project-references.json');
const authPath = path.join(dataRoot, 'authorizations.json');
const projectsPath = path.join(dataRoot, 'projects.json');

if (!fs.existsSync(prPath)) {
  console.error('project-references.json not found at: ' + prPath);
  console.error('If your material library has no references yet, this script has nothing to fix.');
  process.exit(0);
}

const prData = JSON.parse(fs.readFileSync(prPath, 'utf8'));
const authData = fs.existsSync(authPath)
  ? JSON.parse(fs.readFileSync(authPath, 'utf8'))
  : { records: [] };
const projectsData = fs.existsSync(projectsPath)
  ? JSON.parse(fs.readFileSync(projectsPath, 'utf8'))
  : { records: [] };

const authById = new Map(authData.records.map(function(r) { return [r.id, r]; }));
const projectName = new Map(projectsData.records.map(function(r) { return [r.id, r.name]; }));

const before = prData.references.length;

// Categorize references
const valid = [];
const removedByReason = { 'no-auth': 0, 'auth-orphaned': 0, 'auth-mismatch': 0 };

for (const ref of prData.references) {
  const auth = authById.get(ref.sourceAuthorizationId);
  let reason = null;

  if (!auth) {
    reason = 'no-auth';
  } else if (auth.status === 'orphaned') {
    reason = 'auth-orphaned';
  } else if (auth.projectId !== ref.sourceProjectId) {
    reason = 'auth-mismatch';
  }

  if (reason) {
    removedByReason[reason]++;
  } else {
    valid.push(ref);
  }
}

console.log('=== Orphan reference cleanup ===');
console.log('Data root: ' + dataRoot);
console.log('Mode:      ' + (apply ? 'APPLY' : 'DRY RUN (pass --apply to write)'));
console.log('Before:    ' + before + ' references');
console.log('Valid:     ' + valid.length);
console.log('Removed:');
for (const [reason, count] of Object.entries(removedByReason)) {
  if (count > 0) console.log('  ' + reason + ': ' + count);
}

// Per-project impact
const removedByTarget = {};
const validByTarget = {};

for (const ref of prData.references) {
  const pid = ref.targetProjectId;
  const auth = authById.get(ref.sourceAuthorizationId);
  const isOrphan = !auth || auth.status === 'orphaned' || auth.projectId !== ref.sourceProjectId;
  if (isOrphan) removedByTarget[pid] = (removedByTarget[pid] || 0) + 1;
}
for (const ref of valid) {
  const pid = ref.targetProjectId;
  validByTarget[pid] = (validByTarget[pid] || 0) + 1;
}

const allProjects = new Set(Object.keys(removedByTarget).concat(Object.keys(validByTarget)));
console.log('\n=== Per-project impact ===');
for (const pid of allProjects) {
  const name = projectName.get(pid) || pid;
  const rem = removedByTarget[pid] || 0;
  const keep = validByTarget[pid] || 0;
  if (rem > 0 || keep > 0) console.log('  ' + name + ': ' + keep + ' valid, ' + rem + ' removed');
}

const removed = before - valid.length;

if (!apply) {
  console.log('\n=== DRY RUN — no files written. ===');
  console.log('Re-run with --apply to write the cleaned project-references.json and a backup.');
  process.exit(0);
}

if (removed === 0) {
  console.log('\nNo orphan references to remove; nothing to write.');
  process.exit(0);
}

// Backup and write
const backupPath = prPath + '.orphaned-bak-' + Date.now();
fs.writeFileSync(backupPath, JSON.stringify(prData, null, 2), 'utf8');
console.log('\nBackup: ' + backupPath);

prData.references = valid;
fs.writeFileSync(prPath, JSON.stringify(prData, null, 2), 'utf8');
console.log('Written: ' + prPath);
console.log('Removed: ' + removed);
console.log('\nNote: Gateway restart may be required for the change to surface in API responses.');
