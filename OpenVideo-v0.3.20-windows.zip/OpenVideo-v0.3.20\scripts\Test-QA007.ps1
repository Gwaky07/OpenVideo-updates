[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [string]$RuntimeDataRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT,
    [string]$Origin = 'http://127.0.0.1:8787',
    [string]$ProjectId,
    [string]$EditorInstruction,
    [switch]$RealAcceptance,
    [string]$GeneratedEvidencePath,
    [string]$JianyingManualOpenEvidencePath,
    [Nullable[long]]$MinimumFreeDiskBytes,
    [Nullable[long]]$MaximumProcessRssBytes,
    [Nullable[long]]$MaximumElapsedMs
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$root = [IO.Path]::GetFullPath($RepositoryRoot)

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [scriptblock]$Action
    )
    Write-Host "==> $Name" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Action
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

Push-Location $root
try {
    Invoke-Checked 'QA-007 Editor harness contract tests' {
        & node --test `
            'apps/gateway/test/qa007-real-editor-e2e-script.test.mjs' `
            'apps/gateway/test/editor-agent-security.test.mjs' `
            'apps/gateway/test/short-video-factory-editorbound-preview.test.mjs' `
            'apps/gateway/test/rich-timeline-jianying-projection.test.mjs'
    }

    if (-not $RealAcceptance) {
        Write-Output 'QA-007 focused synthetic verification passed.'
        exit 0
    }

    if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
        $RuntimeDataRoot = [Environment]::GetEnvironmentVariable(
            'OPENVIDEO_RUNTIME_DATA_ROOT',
            'User'
        )
    }
    if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
        throw 'RuntimeDataRoot is required for real acceptance.'
    }
    if ([string]::IsNullOrWhiteSpace($ProjectId)) {
        throw 'ProjectId is required for real acceptance.'
    }
    if ([string]::IsNullOrWhiteSpace($EditorInstruction)) {
        throw 'EditorInstruction is required for real acceptance.'
    }

    $previousRuntimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
    $previousOrigin = $env:OPENVIDEO_ORIGIN
    $previousProjectId = $env:OPENVIDEO_PROJECT_ID
    $previousInstruction = $env:OPENVIDEO_QA007_EDITOR_INSTRUCTION
    $previousMinimumFreeDiskBytes = $env:OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES
    $previousMaximumProcessRssBytes = $env:OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES
    $previousMaximumElapsedMs = $env:OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS
    $env:OPENVIDEO_RUNTIME_DATA_ROOT = [IO.Path]::GetFullPath($RuntimeDataRoot)
    $env:OPENVIDEO_ORIGIN = $Origin
    $env:OPENVIDEO_PROJECT_ID = $ProjectId
    $env:OPENVIDEO_QA007_EDITOR_INSTRUCTION = $EditorInstruction
    $env:OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES = if ($null -eq $MinimumFreeDiskBytes) {
        $null
    } else {
        [string]$MinimumFreeDiskBytes
    }
    $env:OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES = if ($null -eq $MaximumProcessRssBytes) {
        $null
    } else {
        [string]$MaximumProcessRssBytes
    }
    $env:OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS = if ($null -eq $MaximumElapsedMs) {
        $null
    } else {
        [string]$MaximumElapsedMs
    }

    & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') `
        -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
        -Stage before
    if ($LASTEXITCODE -ne 0) { throw 'QA-007 before snapshot failed.' }

    try {
        Invoke-Checked 'QA-007 real Editor, Preview, and Jianying chain' {
            & node (Join-Path $PSScriptRoot 'qa007-real-editor-e2e.mjs')
        }
        Invoke-Checked 'QA-007 sanitized scale and cleanup evidence' {
            & node (Join-Path $PSScriptRoot 'measure-qa003-real-baseline.mjs') `
                $env:OPENVIDEO_RUNTIME_DATA_ROOT
        }
        if (
            [string]::IsNullOrWhiteSpace($GeneratedEvidencePath) -or
            [string]::IsNullOrWhiteSpace($JianyingManualOpenEvidencePath)
        ) {
            throw 'QA-007 requires generated-chain and private manual-open evidence paths after the draft is opened and edited.'
        }
        Invoke-Checked 'QA-007 Jianying manual-open evidence' {
            & (Join-Path $PSScriptRoot 'Test-QA007JianyingEvidence.ps1') `
                -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
                -GeneratedEvidencePath $GeneratedEvidencePath `
                -ManualEvidencePath $JianyingManualOpenEvidencePath
        }
    }
    finally {
        & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') `
            -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
            -Stage after
        $env:OPENVIDEO_RUNTIME_DATA_ROOT = $previousRuntimeRoot
        $env:OPENVIDEO_ORIGIN = $previousOrigin
        $env:OPENVIDEO_PROJECT_ID = $previousProjectId
        $env:OPENVIDEO_QA007_EDITOR_INSTRUCTION = $previousInstruction
        $env:OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES = $previousMinimumFreeDiskBytes
        $env:OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES = $previousMaximumProcessRssBytes
        $env:OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS = $previousMaximumElapsedMs
    }
}
finally {
    Pop-Location
}
