import path from 'node:path'
import { pathToFileURL } from 'node:url'

import { createCapCutCatalogService } from '../apps/gateway/src/jianying-capcut-catalog-service.mjs'
import {
  createDirectIdResolutionEvidence,
  parseDirectIdResolutionEvidence,
  publishDirectIdResolutionEvidence,
  signDirectIdResolutionEvidence,
} from '../apps/gateway/src/jianying-direct-id-resolution-evidence.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import {
  loadPackagingResourceEvidenceIntegrityKey,
  verifyPackagingResourceEvidenceRegistry,
} from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import { readFileNoReparse } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import compatibilityManifest from '../config/jianying-compatibility.json' with { type: 'json' }

const fingerprintPattern = /^[a-f0-9]{64}$/u

/** @param {string} family */
const visualFingerprintForFamily = (family) => {
  const prefix = `--${family}=`
  const value = process.argv.find((argument) => argument.startsWith(prefix))?.slice(prefix.length)
  if (!fingerprintPattern.test(value ?? '')) throw new Error('PACKAGING_DIRECT_ID_VISUAL_FINGERPRINT_REQUIRED')
  return value
}

const main = async () => {
  const { dataRoot } = await loadLauncherRuntimeConfig()
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  if (desktop?.available !== true) throw new Error('PACKAGING_DIRECT_ID_DESKTOP_UNAVAILABLE')
  const evidenceRoot = path.join(dataRoot, 'evidence', 'packaging-catalog-001-direct-id')
  const catalogRaw = JSON.parse(await readFileNoReparse(
    path.join(dataRoot, 'catalogs', 'packaging-catalog-001-direct-id-catalog.json'),
    dataRoot,
  ))
  const index = parsePrivatePackagingResourceIndex(catalogRaw, {
    profileId: desktop.profileId,
    appVersion: desktop.version,
  })
  const baseEvidence = JSON.parse(await readFileNoReparse(path.join(evidenceRoot, 'post-save.json'), dataRoot))
  const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({ evidenceRoot })
  const verified = await verifyPackagingResourceEvidenceRegistry({
    evidence: baseEvidence,
    index,
    desktop,
    integrityKey,
  })
  if (!verified) throw new Error('PACKAGING_DIRECT_ID_BASE_EVIDENCE_INVALID')
  const service = createCapCutCatalogService({ dataRoot })
  const sourceIdentity = await service.currentPrivateIdentity()
  const observations = verified.admitted_bindings.map((binding) => ({
    family: binding.family,
    binding_fingerprint: binding.binding_fingerprint,
    target_start_us: binding.target_start_us,
    target_duration_us: binding.target_duration_us,
    status: 'resolved',
    visual_fingerprint: visualFingerprintForFamily(binding.family),
  }))
  const unsigned = createDirectIdResolutionEvidence({
    sourceCatalogFingerprint: sourceIdentity.manifestFingerprint,
    desktop,
    evidence: verified,
    observations,
  })
  const receipt = Object.freeze({
    ...unsigned,
    integrity_signature: signDirectIdResolutionEvidence(unsigned, integrityKey),
  })
  if (!parseDirectIdResolutionEvidence(receipt, {
    sourceCatalogFingerprint: sourceIdentity.manifestFingerprint,
    desktop,
    integrityKey,
  })) throw new Error('PACKAGING_DIRECT_ID_RECEIPT_VERIFY_FAILED')
  await securePrivateRuntimeRoot(evidenceRoot)
  await publishDirectIdResolutionEvidence({ evidenceRoot, receipt })
  process.stdout.write(`${JSON.stringify({
    ok: true,
    status: 'resolved',
    families: receipt.results.map((result) => result.family),
    bindings: receipt.results.length,
    profile: receipt.profile_id,
    version: receipt.app_version,
    source_catalog_bound: true,
    visual_observations_bound: receipt.results.length,
  })}\n`)
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  main().catch((error) => {
    process.stdout.write(`${JSON.stringify({
      ok: false,
      code: /^PACKAGING_DIRECT_ID_[A-Z0-9_]+$/u.test(error?.message ?? '')
        ? error.message
        : 'PACKAGING_DIRECT_ID_EVIDENCE_FAILED',
    })}\n`)
    process.exitCode = 1
  })
}
