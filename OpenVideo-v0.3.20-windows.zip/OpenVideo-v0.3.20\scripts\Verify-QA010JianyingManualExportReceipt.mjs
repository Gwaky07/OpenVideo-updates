import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import {
  createManualExportReceipt,
  fingerprintExportBytes,
  parseManualExportReceipt,
  parseMp4Probe,
  parseBoundDraftOwner,
  publicManualExportReceipt,
  publishManualExportReceipt,
  readOrdinaryExportCandidate,
  signManualExportReceipt,
} from '../apps/gateway/src/jianying-manual-export-receipt.mjs'
import {
  loadPackagingResourceEvidenceIntegrityKey,
  verifyPackagingResourceEvidenceRegistry,
} from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const run = promisify(execFile)
const requiredAttestation = '--manual-attestation=opened-edited-saved-reopened-exported'
const safeCodes = new Set([
  'QA010_MANUAL_EXPORT_ATTESTATION_REQUIRED', 'QA010_EXPORT_FILE_REQUIRED', 'QA010_EXPORT_CANDIDATE_INVALID',
  'QA010_EXPORT_PROBE_INVALID', 'QA010_MANUAL_EXPORT_RECEIPT_INVALID', 'QA010_SAME_DRAFT_EVIDENCE_INVALID',
  'QA010_CANONICAL_BUNDLE_METADATA_MISMATCH', 'QA010_FFPROBE_UNAVAILABLE',
])

const publicFailureCode = (error) => safeCodes.has(error?.message) ? error.message : 'QA010_MANUAL_EXPORT_RECEIPT_FAILED'

const argument = (name, argv = process.argv) => {
  const index = argv.indexOf(name)
  return index >= 0 ? argv[index + 1] ?? null : null
}

const resolveFfprobe = (env = process.env) => {
  const configured = env.OPENVIDEO_FFPROBE_PATH?.trim()
  const candidates = [configured, 'C:\\ffmpeg\\bin\\ffprobe.exe'].filter((value) => typeof value === 'string' && path.isAbsolute(value))
  return candidates.find((candidate) => existsSync(candidate)) ?? null
}

/**
 * Probe only an owned copy of exactly the bytes already fingerprinted by the
 * receipt caller. Dependency injection keeps the file-replacement boundary
 * regression-testable without opening a real user export path in tests.
 */
const probeMp4 = async (ffprobePath, exportBytes, {
  createTemporaryDirectory = mkdtemp,
  removeTemporaryDirectory = rm,
  writeTemporaryFile = writeFile,
  runFfprobe = run,
} = {}) => {
  if (!ffprobePath) throw new Error('QA010_FFPROBE_UNAVAILABLE')
  if (!Buffer.isBuffer(exportBytes) || exportBytes.length === 0) throw new Error('QA010_EXPORT_PROBE_INVALID')
  const probeRoot = await createTemporaryDirectory(path.join(tmpdir(), 'openvideo-qa010-export-probe-'))
  const probeFile = path.join(probeRoot, 'candidate.mp4')
  try {
    await writeTemporaryFile(probeFile, exportBytes, { mode: 0o600, flag: 'wx' })
    const { stdout } = await runFfprobe(ffprobePath, ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', probeFile], {
      encoding: 'utf8', windowsHide: true, timeout: 15_000, maxBuffer: 1_024 * 1_024,
    })
    const parsed = parseMp4Probe(JSON.parse(stdout))
    if (!parsed) throw new Error('QA010_EXPORT_PROBE_INVALID')
    return parsed
  } catch (error) {
    if (error?.message === 'QA010_EXPORT_PROBE_INVALID') throw error
    throw new Error('QA010_EXPORT_PROBE_INVALID')
  } finally { await removeTemporaryDirectory(probeRoot, { recursive: true, force: true }) }
}

const runVerifier = async ({
  argv = process.argv,
  detectDesktopImpl = detectJianyingDesktop,
  loadConfigImpl = loadLocalRuntimeConfig,
  readFileImpl = readFileNoReparse,
  readBufferImpl = readFileNoReparseBuffer,
  parseCatalogImpl = parsePrivatePackagingResourceIndex,
  verifyEvidenceImpl = verifyPackagingResourceEvidenceRegistry,
  loadIntegrityKeyImpl = loadPackagingResourceEvidenceIntegrityKey,
  candidateImpl = readOrdinaryExportCandidate,
  probeImpl = probeMp4,
  resolveFfprobeImpl = resolveFfprobe,
  publishReceiptImpl = publishManualExportReceipt,
  writeOutput = (value) => process.stdout.write(`${value}\n`),
} = {}) => {
  if (!argv.includes(requiredAttestation)) throw new Error('QA010_MANUAL_EXPORT_ATTESTATION_REQUIRED')
  const exportFile = argument('--export-file', argv)
  if (!exportFile) throw new Error('QA010_EXPORT_FILE_REQUIRED')

  const desktop = await detectDesktopImpl({ compatibilityManifest: manifest })
  const { dataRoot } = loadConfigImpl()
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy132-packaging-resources')
  const registry = JSON.parse(await readFileImpl(path.join(evidenceRoot, 'post-save.json'), dataRoot))
  const catalog = JSON.parse(await readFileImpl(path.join(dataRoot, 'catalogs', 'jy132-packaging-resource-catalog.json'), dataRoot))
  const index = parseCatalogImpl(catalog, { profileId: desktop.profileId, appVersion: desktop.version })
  const integrityKey = await loadIntegrityKeyImpl({ evidenceRoot })
  const verifiedEvidence = await verifyEvidenceImpl({ evidence: registry, index, desktop, integrityKey })
  if (!verifiedEvidence) throw new Error('QA010_SAME_DRAFT_EVIDENCE_INVALID')

  const draftRoot = path.join(desktop.draftRoot, verifiedEvidence.draft_id)
  const owner = parseBoundDraftOwner(JSON.parse(await readFileImpl(path.join(draftRoot, '.openvideo-owner.json'), desktop.draftRoot)))
  if (!owner || owner.draft_id !== verifiedEvidence.draft_id || owner.bundle_fingerprint !== verifiedEvidence.bundle_fingerprint) {
    throw new Error('QA010_CANONICAL_BUNDLE_METADATA_MISMATCH')
  }

  const candidate = await candidateImpl({ exportFile, readNoReparse: readBufferImpl })
  const probe = await probeImpl(resolveFfprobeImpl(), candidate.bytes)
  const media = { sha256: fingerprintExportBytes(candidate.bytes), byte_length: candidate.byte_length, ...probe }
  const evidence = {
    ...verifiedEvidence,
    // This is a private file fingerprint, not a public catalog or draft identifier.
    evidence_fingerprint: createHash('sha256').update(JSON.stringify(verifiedEvidence)).digest('hex'),
  }
  const receipt = createManualExportReceipt({ evidence, owner, media })
  const signedReceipt = { ...receipt, integrity_signature: signManualExportReceipt(receipt, integrityKey) }
  if (!parseManualExportReceipt(signedReceipt, integrityKey)) throw new Error('QA010_MANUAL_EXPORT_RECEIPT_INVALID')
  // Reuse the already DPAPI-keyed, no-reparse JY-132 evidence root. Creating
  // a new ACL root at receipt time would make a real export depend on Windows
  // shell ACL-module availability and cannot strengthen the existing trust
  // boundary. The receipt still has its own signed schema and fixed filename.
  await publishReceiptImpl({ receiptRoot: evidenceRoot, receipt: signedReceipt, filename: 'qa010-export-receipt.json' })
  writeOutput(JSON.stringify(publicManualExportReceipt(signedReceipt)))
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  runVerifier().catch((error) => {
    process.stdout.write(`${JSON.stringify({ ok: false, code: publicFailureCode(error) })}\n`)
    process.exitCode = 1
  })
}

export { probeMp4, publicFailureCode, requiredAttestation, runVerifier }
