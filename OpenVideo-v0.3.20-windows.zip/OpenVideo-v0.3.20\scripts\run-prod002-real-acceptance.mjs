import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { isAbsolute, resolve } from 'node:path'

import { loadGatewayConfig } from '../apps/gateway/src/config.mjs'
import { createDirector } from '../apps/gateway/src/director.mjs'
import { createGateway } from '../apps/gateway/src/gateway.mjs'
import { createJsonRepositories } from '../apps/gateway/src/local-runtime.mjs'
import { createPermissiveMaterialAnalyzer } from '../apps/gateway/src/permissive-material-analyzer.mjs'
import { createWorkbenchJobCoordinator } from '../apps/gateway/src/workbench-job-coordinator.mjs'
import {
  createEditPlanRepository,
  createWorkbenchJobRepository,
} from '../apps/gateway/src/workbench-job-repository.mjs'

const dataRoot = process.argv[2]
if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('PROD002_RUNTIME_ROOT_INVALID')

const privateProvider = JSON.parse(await readFile(resolve(dataRoot, 'gateway/provider.json'), 'utf8'))
if (
  privateProvider?.schema_version !== 1 ||
  privateProvider?.provider !== 'openai-compatible' ||
  typeof privateProvider.base_url !== 'string' ||
  typeof privateProvider.api_key !== 'string' ||
  typeof privateProvider.text_model !== 'string' ||
  typeof privateProvider.vision_model !== 'string' ||
  typeof privateProvider.json_model !== 'string'
) throw new Error('PROD002_GATEWAY_CONFIG_INVALID')

process.env.OPENVIDEO_LLM_PROVIDER = privateProvider.provider
process.env.OPENVIDEO_LLM_BASE_URL = privateProvider.base_url
process.env.OPENVIDEO_LLM_API_KEY = privateProvider.api_key
process.env.OPENVIDEO_LLM_TEXT_MODEL = privateProvider.text_model
process.env.OPENVIDEO_LLM_VISION_MODEL = privateProvider.vision_model
process.env.OPENVIDEO_LLM_JSON_MODEL = privateProvider.json_model

const repositories = await createJsonRepositories({ dataRoot })
const authorization = repositories.authorizationRepository
  .list()
  .filter((record) => record.status === 'authorized' && record.readOnly === true && record.total >= 20)
  .sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))[0]
if (!authorization) throw new Error('PROD002_AUTHORIZATION_NOT_FOUND')

const originalProject = repositories.projectRepository.get(authorization.projectId)
if (
  !originalProject ||
  originalProject.materials?.authorizationId !== authorization.id ||
  originalProject.materials?.authorized !== true
) throw new Error('PROD002_PROJECT_BINDING_INVALID')

const logEvent = (event) => console.error(JSON.stringify(event))
const gateway = createGateway({
  config: loadGatewayConfig(),
  logger: logEvent,
})
const director = createDirector({ gateway, logger: logEvent })
const analyzer = await createPermissiveMaterialAnalyzer({
  dataRoot,
  authorizationRepository: repositories.authorizationRepository,
  gateway,
})
if (!analyzer.getStatus().available) throw new Error('PROD002_ANALYZER_UNAVAILABLE')

const jobRepository = await createWorkbenchJobRepository({ dataRoot })
const editPlanRepository = await createEditPlanRepository({ dataRoot })
const acceptanceProject = {
  ...structuredClone(originalProject),
  brief: {
    theme: '真实素材产品展示',
    title: '真实素材可恢复分镜验收',
    sellingPoints: ['展示产品外观', '突出真实使用场景'],
    script: '展示产品外观和材质细节。人物在室内使用产品。最后给出完整产品展示。',
    style: '自然、清晰、节奏稳定',
    durationSeconds: 30,
    orientation: 'portrait',
    voiceover: 'none',
    captions: 'auto',
    savedAt: new Date().toISOString(),
  },
  storyboard: null,
  currentStage: 'brief',
  updatedAt: new Date().toISOString(),
}
repositories.projectRepository.save(acceptanceProject)

const createCoordinator = (ownerId) => createWorkbenchJobCoordinator({
  jobRepository,
  editPlanRepository,
  projectRepository: repositories.projectRepository,
  materialAnalysisProvider: analyzer,
  director,
  previewProvider: {
    async renderPreview() {
      throw new Error('PROD002_PREVIEW_NOT_IN_SCOPE')
    },
    async getResource() {
      return null
    },
    async deleteResource() {
      return true
    },
  },
  ownerId,
  concurrency: 1,
  leaseDurationMs: 30_000,
  heartbeatIntervalMs: 10_000,
  jobTimeoutMs: 30 * 60_000,
  logger: logEvent,
})
const waitForTerminal = async (coordinator, jobId) => {
  const deadline = Date.now() + 30 * 60_000
  while (Date.now() < deadline) {
    const job = await coordinator.getJob(authorization.projectId, jobId)
    if (['succeeded', 'failed', 'cancelled', 'timed_out'].includes(job?.status)) return job
    await new Promise((resolveDelay) => setTimeout(resolveDelay, 250))
  }
  throw new Error('PROD002_JOB_POLL_TIMEOUT')
}

let coordinator = createCoordinator('prod002-real-acceptance-first')
try {
  await coordinator.start()
  const nonce = Date.now().toString(36)
  const materialJob = await coordinator.createJob({
    projectId: authorization.projectId,
    type: 'material_analysis',
    idempotencyKey: `prod002-material-${nonce}`,
  })
  const materialResult = await waitForTerminal(coordinator, materialJob.jobId)
  if (materialResult.status !== 'succeeded') throw new Error('PROD002_REAL_MATERIAL_JOB_FAILED')

  const storyboardJob = await coordinator.createJob({
    projectId: authorization.projectId,
    type: 'storyboard_generation',
    idempotencyKey: `prod002-storyboard-${nonce}`,
  })
  const storyboardResult = await waitForTerminal(coordinator, storyboardJob.jobId)
  if (storyboardResult.status !== 'succeeded') throw new Error('PROD002_REAL_STORYBOARD_JOB_FAILED')
  await coordinator.stop()

  coordinator = createCoordinator('prod002-real-acceptance-restart')
  await coordinator.start()
  const recoveredJobs = await coordinator.listJobs(authorization.projectId)
  const recoveredStoryboard = await coordinator.getJob(authorization.projectId, storyboardJob.jobId)
  const publishedProject = repositories.projectRepository.get(authorization.projectId)
  const storedStoryboardJob = await jobRepository.get(authorization.projectId, storyboardJob.jobId)
  const privatePlan = await editPlanRepository.get({
    projectId: authorization.projectId,
    jobId: storyboardJob.jobId,
    fingerprint: storedStoryboardJob.privateInput.inputFingerprint,
    generation: storedStoryboardJob.attempts.at(-1).generation,
  })
  if (
    recoveredJobs.length < 2 ||
    recoveredStoryboard?.status !== 'succeeded' ||
    !publishedProject?.storyboard ||
    publishedProject.storyboard.sentences.length !== 3 ||
    privatePlan?.status !== 'finalized'
  ) throw new Error('PROD002_REAL_RESTART_RECOVERY_FAILED')

  const publicPayload = JSON.stringify({
    materialResult,
    storyboardResult,
    recoveredStoryboard,
    storyboard: publishedProject.storyboard,
  }).toLowerCase()
  for (const forbidden of [
    authorization.absolutePath.toLowerCase(),
    privateProvider.api_key.toLowerCase(),
    'privateinput',
    'checkpoint',
    'lease',
    'transcript',
    'provider',
    'api_key',
    'source_path',
    'relative_path',
    'file://',
  ]) {
    if (publicPayload.includes(forbidden)) throw new Error('PROD002_PUBLIC_RESPONSE_LEAK')
  }

  const evidenceRoot = resolve(dataRoot, 'evidence/prod-002')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const evidence = {
    schema_version: 1,
    completed_at: new Date().toISOString(),
    material_job_status: materialResult.status,
    storyboard_job_status: storyboardResult.status,
    restart_recovery: true,
    project_scoped_job_count: recoveredJobs.length,
    storyboard_sentence_count: publishedProject.storyboard.sentences.length,
    private_edit_plan_persisted: true,
    public_response_leak_count: 0,
  }
  await writeFile(
    resolve(evidenceRoot, 'acceptance.json'),
    `${JSON.stringify(evidence, null, 2)}\n`,
    { encoding: 'utf8', mode: 0o600 },
  )
  console.log(JSON.stringify(evidence))
} finally {
  await coordinator.stop().catch(() => {})
  repositories.projectRepository.save(originalProject)
}
