import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY062_MANUAL_ATTESTATION_REQUIRED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy062-background')
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== pending.profile_id || desktop?.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root)) throw new Error('JY062_EVIDENCE_BINDING_INVALID')
  const encrypted = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json')
  const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy062-verify-'))
  const plaintext = path.join(tempRoot, 'draft_content.json')
  try {
    const decryptor = createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
    const meta = await decryptor.ensurePlaintextFile(encrypted, plaintext)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY062_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plaintext, 'utf8'))
    const videoTrack = content.tracks?.find((track) => track?.name === 'video-primary')
    const video = videoTrack?.segments?.[0]
    const canvases = content.materials?.canvases ?? []
    const matches = canvases.filter((item) => item?.type === 'canvas_blur' && video?.extra_material_refs?.includes(item.id))
    if (matches.length !== 1 || Math.abs(Number(matches[0].blur) - 0.75) > 1e-9 || Math.abs(Number(pending.initial_blur) - 0.75) <= 1e-9) throw new Error('JY062_POST_SAVE_BACKGROUND_MISMATCH')
    const contentFingerprint = createHash('sha256').update(await readFile(plaintext)).digest('hex')
    await writeFile(path.join(evidenceRoot, 'post-save.json'), `${JSON.stringify({ schema_version: 1, manual_evidence_verified: true, profile_id: pending.profile_id, app_version: pending.app_version, catalog_fingerprint: pending.catalog_fingerprint, draft_id: pending.draft_id, initial_blur: pending.initial_blur, persisted_blur: 0.75, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, content_fingerprint: contentFingerprint })}\n`, { encoding: 'utf8', mode: 0o600 })
    await rm(pending.media_root, { recursive: true, force: true })
    await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, manual_evidence_verified: true, persisted_blur: 0.75, scheme: 'encrypt_v2' })}\n`)
  } finally { await rm(tempRoot, { recursive: true, force: true }) }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY062_VERIFY_FAILED' })}\n`); process.exitCode = 1 })
