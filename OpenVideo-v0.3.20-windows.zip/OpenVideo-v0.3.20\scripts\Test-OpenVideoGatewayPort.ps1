# Stable port resolution smoke test for worktree isolation helpers.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'OpenVideo-LauncherPort.ps1')

$failures = 0
function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) {
        Write-Host "FAIL: $Message" -ForegroundColor Red
        $script:failures += 1
    } else {
        Write-Host "PASS: $Message" -ForegroundColor Green
    }
}

$primary = 'S:\Agent\open video'
$worktreeA = 'S:\Agent\open-video-vid006'
$worktreeB = 'S:\Agent\open-video-ui-hotfix007'

# Primary detection uses .git directory vs file; skip if path missing.
if (Test-Path -LiteralPath (Join-Path $primary '.git')) {
    Assert-True (Test-OpenVideoPrimaryWorktree -Root $primary) 'primary worktree detected for console root'
}
if (Test-Path -LiteralPath $worktreeA) {
    Assert-True (-not (Test-OpenVideoPrimaryWorktree -Root $worktreeA)) 'linked worktree is not primary'
    $port1 = Get-StableWorktreeGatewayPort -Root $worktreeA
    $port2 = Get-StableWorktreeGatewayPort -Root $worktreeA
    Assert-True ($port1 -eq $port2) 'stable port is deterministic for same root'
    Assert-True ($port1 -ge 8790 -and $port1 -le 8889) 'stable port is in 8790-8889'
    Assert-True ($port1 -ne 8787) 'linked worktree stable port is not 8787'
}
if ((Test-Path -LiteralPath $worktreeA) -and (Test-Path -LiteralPath $worktreeB)) {
    $a = Get-StableWorktreeGatewayPort -Root $worktreeA
    $b = Get-StableWorktreeGatewayPort -Root $worktreeB
    Assert-True ($a -ne $b) 'distinct worktree roots map to distinct stable ports (expected for these paths)'
}

$env:OPENVIDEO_GATEWAY_PORT = '8899'
try {
    $resolved = Resolve-OpenVideoGatewayPort -Root $worktreeA -PrimaryPort 8787
    Assert-True ($resolved -eq 8899) 'OPENVIDEO_GATEWAY_PORT env override wins'
} finally {
    Remove-Item Env:OPENVIDEO_GATEWAY_PORT -ErrorAction SilentlyContinue
}

if ($failures -gt 0) {
    throw "OpenVideo gateway port tests failed: $failures"
}
Write-Host 'OPENVIDEO_GATEWAY_PORT_TESTS_PASSED' -ForegroundColor Green
