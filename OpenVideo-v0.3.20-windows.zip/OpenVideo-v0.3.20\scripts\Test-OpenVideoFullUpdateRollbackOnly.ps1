[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [int]$Port = 8807,
    [int]$HealthSeconds = 25
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
$root = [IO.Path]::GetFullPath($RepositoryRoot)
$exe = Join-Path $root 'dist\OpenVideo.exe'
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'OPENVIDEO_FULL_UPDATE_EXE_MISSING' }
if ($Port -eq 8787) { throw 'OPENVIDEO_ISOLATED_QA_MUST_NOT_USE_PRODUCT_PORT' }

$iso = Join-Path $env:LOCALAPPDATA ('OpenVideo-iso-' + [guid]::NewGuid().ToString('N'))
$dataRoot = Join-Path $iso 'data'
$program = Join-Path $iso 'program'
$configPath = Join-Path $iso 'config.json'
New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
New-Item -ItemType Directory -Path $program -Force | Out-Null
$utf8 = [Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText((Join-Path $dataRoot '.openvideo-runtime-owner.json'), (@{ schema_version = 1; owner = 'openvideo-local-runtime' } | ConvertTo-Json), $utf8)

# Force an immediate health-check failure by pointing at a free, unused port.
[IO.File]::WriteAllText($configPath, (@{
    schema_version = 1
    runtime_data_root = $dataRoot
    short_video_factory_root = (Join-Path $root 'upstream\short-video-factory')
    pyjianyingdraft_root = (Join-Path $root 'upstream\pyJianYingDraft')
    gateway_port = $Port
} | ConvertTo-Json), $utf8)
[IO.File]::WriteAllText((Join-Path $program 'OLD_MARKER.txt'), 'old', $utf8)
[IO.File]::WriteAllText((Join-Path $program 'OpenVideo.cmd'), "@echo off`r`nexit /b 0`r`n", $utf8)

# Block the chosen port so the gateway never binds a healthy listener.
# TcpListener without exclusive start still races; pick an unused port first
# and rebind it as a holder that the test never releases.
$holder = [Net.Sockets.Socket]::new([Net.Sockets.AddressFamily]::InterNetwork, [Net.Sockets.SocketType]::Stream, [Net.Sockets.ProtocolType]::Tcp)
$holder.SetSocketOption([Net.Sockets.SocketOptionLevel]::Socket, [Net.Sockets.SocketOptionName]::ReuseAddress, $false)
$holder.Bind([Net.IPEndPoint]::new([Net.IPAddress]::Loopback, $Port))
$holder.Listen(1)
Write-Host "OPENVIDEO_FULL_UPDATE_PORT_BLOCKED: $Port"

$env:OPENVIDEO_PROGRAM_ROOT = $program
$env:OPENVIDEO_CONFIG_PATH = $configPath
$env:OPENVIDEO_GATEWAY_PORT = [string]$Port
$env:OPENVIDEO_PORTABLE_HEALTH_SECONDS = [string]$HealthSeconds
try {
    $process = Start-Process -FilePath $exe -PassThru -WindowStyle Hidden
    $null = $process.WaitForExit(($HealthSeconds + 60) * 1000)
} finally {
    Remove-Item Env:OPENVIDEO_PROGRAM_ROOT -ErrorAction SilentlyContinue
    Remove-Item Env:OPENVIDEO_CONFIG_PATH -ErrorAction SilentlyContinue
    Remove-Item Env:OPENVIDEO_GATEWAY_PORT -ErrorAction SilentlyContinue
    Remove-Item Env:OPENVIDEO_PORTABLE_HEALTH_SECONDS -ErrorAction SilentlyContinue
    $holder.Close()
}

if (Test-Path -LiteralPath (Join-Path $program 'OLD_MARKER.txt')) {
    Write-Host "OPENVIDEO_FULL_UPDATE_ROLLBACK_OK: old marker restored at $program"
    exit 0
}
Write-Host "OPENVIDEO_FULL_UPDATE_ROLLBACK_FAILED: program=$program"
cmd /c "dir /b /a `"$program`" 2>nul"
exit 1
