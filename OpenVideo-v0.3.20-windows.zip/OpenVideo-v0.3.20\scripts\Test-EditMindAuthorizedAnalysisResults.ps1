[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ManifestPath,
    [Parameter(Mandatory)][string]$ResultsPath,
    [Parameter(Mandatory)][string]$RuntimeDataRoot
)

$ErrorActionPreference = 'Stop'
$pathComparison = [StringComparison]::OrdinalIgnoreCase
$utf8 = New-Object Text.UTF8Encoding($false)

function Get-FullPath {
    param([string]$Path, [string]$Name, [bool]$MustExist)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "$Name is required." }
    if (-not [IO.Path]::IsPathRooted($Path) -or $Path -match '^[A-Za-z]:[^\\/]') { throw "$Name must be an absolute path." }
    $full = [IO.Path]::GetFullPath($Path)
    if ($MustExist -and -not (Test-Path -LiteralPath $full)) { throw "$Name does not exist: $full" }
    $root = [IO.Path]::GetPathRoot($full)
    if ($full.Equals($root, $pathComparison)) { return $root }
    return $full.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
}
function Test-Within([string]$Root, [string]$Candidate) {
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($Root, $pathComparison) -or $Candidate.StartsWith($prefix, $pathComparison)
}

function Assert-NoReparseBoundary {
    param([string]$Root, [string]$Candidate)
    $cursor = $Candidate
    while ($true) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "Path crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        if ($cursor.Equals($Root, $pathComparison)) { break }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor -or -not (Test-Within -Root $Root -Candidate $parent)) {
            throw 'Private evidence must be inside RuntimeDataRoot.'
        }
        $cursor = $parent
    }
}

function Assert-NoReparseAncestors {
    param([string]$Path, [string]$Name)
    $cursor = $Path
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "$Name crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-NotReparsePath {
    param([string]$Path, [string]$Name)
    $item = Get-Item -LiteralPath $Path -Force
    $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw "$Name must not be a symbolic link or reparse point: $Path"
    }
}

function Get-SourceSnapshot {
    param([string[]]$Paths)
    $items = @()
    foreach ($path in $Paths) {
        $item = Get-Item -LiteralPath $path -Force
        if ($item.PSIsContainer) { throw "Authorized sample must be a file: $path" }
        $items += [ordered]@{
            path = $path
            name = $item.Name
            length = [int64]$item.Length
            last_write_time_utc = $item.LastWriteTimeUtc.ToString('o')
            sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    }
    return $items
}

$repositoryPath = Get-FullPath -Path (Split-Path -Parent $PSScriptRoot) -Name 'RepositoryRoot' -MustExist $true
$runtimePath = Get-FullPath -Path $RuntimeDataRoot -Name 'RuntimeDataRoot' -MustExist $true
Assert-NotReparsePath -Path $repositoryPath -Name 'RepositoryRoot'
if (-not (Test-Path -LiteralPath $runtimePath -PathType Container)) { throw 'RuntimeDataRoot must be an existing directory.' }
$runtimeItem = Get-Item -LiteralPath $runtimePath -Force
$runtimeHasLinkType = $null -ne $runtimeItem.PSObject.Properties['LinkType'] -and [bool]$runtimeItem.LinkType
if (($runtimeItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $runtimeHasLinkType) {
    throw 'RuntimeDataRoot must not be a symbolic link or reparse point.'
}
if ((Test-Within -Root $repositoryPath -Candidate $runtimePath) -or (Test-Within -Root $runtimePath -Candidate $repositoryPath)) {
    throw 'RuntimeDataRoot and the repository must be separate and must not contain one another.'
}
Assert-NoReparseAncestors -Path $runtimePath -Name 'RuntimeDataRoot'
$manifestPathFull = Get-FullPath -Path $ManifestPath -Name 'ManifestPath' -MustExist $true
$resultsPathFull = Get-FullPath -Path $ResultsPath -Name 'ResultsPath' -MustExist $true
foreach ($privatePath in @($manifestPathFull, $resultsPathFull)) {
    if (-not (Test-Path -LiteralPath $privatePath -PathType Leaf)) { throw 'ManifestPath and ResultsPath must be existing files.' }
    if (-not (Test-Within -Root $runtimePath -Candidate $privatePath)) { throw 'ManifestPath and ResultsPath must be inside RuntimeDataRoot.' }
    Assert-NoReparseBoundary -Root $runtimePath -Candidate $privatePath
}
$manifest = Get-Content -LiteralPath $manifestPathFull -Raw -Encoding utf8 | ConvertFrom-Json
if ($manifest.schema_version -ne 1 -or $manifest.authorization -ne 'read_only_analysis') { throw 'Manifest authorization contract is invalid.' }
$authorized = @($manifest.files | ForEach-Object { Get-FullPath -Path $_ -Name 'Authorized sample' -MustExist $true })
if ($authorized.Count -ne 5) { throw 'Manifest must contain exactly five files.' }
$beforePath = Join-Path $runtimePath 'evidence/em-002/source-snapshot.before.json'
$afterPath = Join-Path $runtimePath 'evidence/em-002/source-snapshot.after.json'
$sourceVerificationPath = Join-Path $runtimePath 'evidence/em-002/source-verification.json'
foreach ($requiredEvidence in @($beforePath, $afterPath, $sourceVerificationPath)) {
    if (-not (Test-Path -LiteralPath $requiredEvidence -PathType Leaf)) { throw 'Source verification is required before analysis result validation.' }
    Assert-NoReparseBoundary -Root $runtimePath -Candidate $requiredEvidence
}
$before = Get-Content -LiteralPath $beforePath -Raw -Encoding utf8 | ConvertFrom-Json
$after = Get-Content -LiteralPath $afterPath -Raw -Encoding utf8 | ConvertFrom-Json
$sourceVerification = Get-Content -LiteralPath $sourceVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
if ($sourceVerification.unchanged -ne $true -or [int]$sourceVerification.sample_count -ne 5) {
    throw 'Source verification must confirm five unchanged files.'
}
$snapshotPaths = @($before.files | ForEach-Object { Get-FullPath -Path ([string]$_.path) -Name 'Before snapshot source' -MustExist $true })
if ($snapshotPaths.Count -ne 5 -or (($snapshotPaths | ConvertTo-Json -Compress) -ne ($authorized | ConvertTo-Json -Compress))) {
    throw 'Authorized manifest does not match the recorded source snapshot.'
}
$beforeJson = $before.files | ConvertTo-Json -Depth 8 -Compress
$afterJson = $after.files | ConvertTo-Json -Depth 8 -Compress
if ($beforeJson -ne $afterJson) { throw 'Before and after source snapshots do not match.' }
$materialRoot = Get-FullPath -Path ([string]$before.material_root) -Name 'Snapshot material root' -MustExist $true
if ((Test-Within -Root $repositoryPath -Candidate $materialRoot) -or (Test-Within -Root $materialRoot -Candidate $repositoryPath)) {
    throw 'Recorded material root and the repository must be separate and must not contain one another.'
}
if ((Test-Within -Root $runtimePath -Candidate $materialRoot) -or (Test-Within -Root $materialRoot -Candidate $runtimePath)) {
    throw 'Recorded material root and RuntimeDataRoot must be separate and must not contain one another.'
}
Assert-NoReparseAncestors -Path $materialRoot -Name 'Snapshot material root'
foreach ($source in $authorized) {
    if (-not (Test-Within -Root $materialRoot -Candidate $source)) { throw 'Authorized source is outside the recorded material root.' }
    Assert-NoReparseBoundary -Root $materialRoot -Candidate $source
}
$currentJson = (Get-SourceSnapshot -Paths $authorized) | ConvertTo-Json -Depth 8 -Compress
if ($currentJson -ne $beforeJson) { throw 'Authorized source files changed since the recorded snapshot.' }
$results = Get-Content -LiteralPath $resultsPathFull -Raw -Encoding utf8 | ConvertFrom-Json
if ($results.schema_version -ne 1) { throw 'Analysis results schema_version must be 1.' }
$samples = @($results.samples)
if ($samples.Count -ne 5) { throw 'Analysis results must contain exactly five samples.' }
$durationBySource = @{}
$seenSources = @{}
foreach ($sample in $samples) {
    $source = Get-FullPath -Path ([string]$sample.source) -Name 'Analysis result source' -MustExist $true
    if ($authorized -notcontains $source) { throw 'Analysis result source is not in the authorized manifest.' }
    if ($seenSources.ContainsKey($source)) { throw 'Analysis results contain duplicate sources.' }
    $seenSources[$source] = $true
    if ([string]$sample.status -ne 'indexed') { throw 'Every analysis result must have indexed status.' }
    if ([string]::IsNullOrWhiteSpace([string]$sample.summary)) { throw 'Every analysis result needs a one-sentence summary.' }
    if (@($sample.tags).Count -eq 0 -and @($sample.key_facts).Count -eq 0) { throw 'Every analysis result needs tags or key facts.' }
    $duration = [double]$sample.duration
    if ($duration -le 0) { throw 'Every analysis result needs a positive duration.' }
    $durationBySource[$source] = $duration
    foreach ($scene in @($sample.scenes)) {
        $sceneProperties = @($scene.PSObject.Properties.Name | Sort-Object)
        if (($sceneProperties -join ',') -ne 'end,source,start') { throw 'Scenes may only contain source, start and end.' }
        if ([string]$scene.source -ne $source) { throw 'Scene source must match its sample source.' }
        $start = [double]$scene.start
        $end = [double]$scene.end
        if ($start -lt 0 -or $end -le $start -or $end -gt $duration) { throw 'Scene timecode exceeds the source duration.' }
    }
}
if ($seenSources.Count -ne 5) { throw 'Analysis results must cover all five authorized sources.' }
$videoExtensions = @('.mp4', '.mov', '.mkv', '.avi', '.m4v', '.webm', '.mts', '.m2ts')
$permanentClips = @(
    Get-ChildItem -LiteralPath $runtimePath -Recurse -File -Filter 'Scene-*' -ErrorAction SilentlyContinue |
        Where-Object { [IO.Path]::GetExtension($_.Name).ToLowerInvariant() -in $videoExtensions }
)
if ($permanentClips.Count -gt 0) { throw 'Permanent scene clip files are forbidden.' }
$tmpPath = Join-Path $runtimePath 'tmp'
if (Test-Path -LiteralPath $tmpPath -PathType Container) {
    $temporaryFiles = @(Get-ChildItem -LiteralPath $tmpPath -Recurse -File -Force -ErrorAction SilentlyContinue)
    if ($temporaryFiles.Count -gt 0) { throw 'Runtime temporary files must be cleaned before verification.' }
}
$evidenceDir = Join-Path $runtimePath 'evidence/em-002'
New-Item -ItemType Directory -Path $evidenceDir -Force | Out-Null
$evidence = [ordered]@{
    schema_version = 1
    sample_count = 5
    indexed_count = 5
    all_timecodes_within_duration = $true
    scene_representation = 'source+start+end'
    permanent_scene_clips = 0
}
$evidencePath = Join-Path $evidenceDir 'analysis-verification.json'
[IO.File]::WriteAllText($evidencePath, ($evidence | ConvertTo-Json -Depth 6), $utf8)
[pscustomobject]@{ sample_count = 5; evidence_path = $evidencePath }
