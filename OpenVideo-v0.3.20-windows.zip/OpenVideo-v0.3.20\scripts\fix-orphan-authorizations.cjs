#!/usr/bin/env node
/**
 * UI-HOTFIX-131c / data follow-up
 *
 * Removes orphan authorization records that are flagged with status='orphaned'
 * and which are NOT referenced by any surviving project reference, task,
 * BGM backing, voice reference or jianying draft.
 *
 * Idempotent. Safe to re-run.
 */
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const dataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
  || path.join(os.homedir(), 'AppData', 'Local', 'OpenVideo', 'data');
const apply = process.argv.includes('--apply');

const authFile = path.join(dataRoot, 'authorizations.json');
const refFile = path.join(dataRoot, 'material-library', 'project-references.json');
const bgmFile = path.join(dataRoot, 'workbench-projects.json');
const repos = [
  'material-library',
  'projects.json',
  'projects',
].map(f => path.join(dataRoot, f));

function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; }
}
function listDir(dir) {
  try { return fs.readdirSync(dir, { withFileTypes: true }); } catch { return []; }
}

const auth = readJson(authFile, { records: [] });
const refs = readJson(refFile, { references: [] });

const referencedAuthIds = new Set();
for (const r of (refs.references || [])) {
  if (r.sourceAuthorizationId) referencedAuthIds.add(r.sourceAuthorizationId);
  if (r.targetAuthorizationId) referencedAuthIds.add(r.targetAuthorizationId);
}

// Scan BGM, voice reference and jianying draft metadata too.
const projectsDir = path.join(dataRoot, 'workbench-projects.json');
const projects = readJson(projectsDir, null);
if (Array.isArray(projects)) {
  for (const p of projects) {
    for (const k of ['bgmAuthorizationId', 'sfxAuthorizationId', 'voiceAuthorizationId', 'voiceReferenceAuthorizationId']) {
      if (p?.[k]) referencedAuthIds.add(p[k]);
    }
    for (const t of (p.tasks || [])) {
      if (t.authorizationId) referencedAuthIds.add(t.authorizationId);
    }
  }
}

const records = auth.records || [];
const candidates = [];
const kept = [];
for (const r of records) {
  if (r.status === 'orphaned' && !referencedAuthIds.has(r.id)) {
    candidates.push(r);
  } else {
    kept.push(r);
  }
}

console.log(JSON.stringify({
  dataRoot,
  apply,
  total: records.length,
  orphanCandidate: candidates.length,
  orphanKeptReferenced: records.filter(r => r.status === 'orphaned' && referencedAuthIds.has(r.id)).length,
  kept: kept.length,
}, null, 2));

if (!apply) {
  console.log('\nDRY RUN — pass --apply to rewrite authorizations.json');
  process.exit(0);
}

if (candidates.length === 0) {
  console.log('\nNothing to clean up.');
  process.exit(0);
}

// Backup
const backupPath = authFile + '.orphan-cleanup-bak-' + new Date().toISOString().replace(/[:.]/g, '-');
fs.copyFileSync(authFile, backupPath);
console.log('Backup:', backupPath);

auth.records = kept;
fs.writeFileSync(authFile, JSON.stringify(auth, null, 2));
console.log(`Removed ${candidates.length} orphan authorization records.`);
