import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, readdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'

const manifest = JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8'))
const canonical = (value) => JSON.stringify(value)
const catalogPath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs', 'jy041-filter-catalog.json')

const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true || desktop.profileId !== 'jianying-11-1-provisional') throw new Error('JY041_PROFILE_UNSUPPORTED')
  const drafts = (await readdir(desktop.draftRoot, { withFileTypes: true }))
    .filter((entry) => entry.isDirectory() && entry.name.startsWith('OpenVideo-JY027-scale-'))
    .map((entry) => entry.name).sort()
  const draftId = drafts.at(-1)
  if (!draftId) throw new Error('JY041_EVIDENCE_DRAFT_MISSING')
  const temporary = await mkdtemp(path.join(tmpdir(), 'ov-jy041-catalog-'))
  try {
    const plaintext = path.join(temporary, 'draft.json')
    const source = path.join(desktop.draftRoot, draftId, 'draft_content.json')
    const decrypt = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
      .ensurePlaintextFile(source, plaintext)
    if (decrypt.scheme !== 'encrypt_v2' && decrypt.decryptedFrom !== 'encrypt_v2') throw new Error('JY041_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plaintext, 'utf8'))
    const filters = (content.materials?.effects ?? []).filter((item) => item?.type === 'filter' && typeof item?.resource_id === 'string' && typeof item?.value === 'number')
    if (filters.length !== 1 || Math.abs(filters[0].value - 0.5) > 0.001) throw new Error('JY041_FILTER_EVIDENCE_INVALID')
    const token = `ovjflt_v1_segment_${createHash('sha256').update(filters[0].resource_id).digest('hex')}`
    const entries = [{ capability_id: 'filter.video.named', filter_token: token, resource_id: filters[0].resource_id }]
    const body = { schema_version: 1, kind: 'jy017_filter_catalog', catalog_version: '1.0.0', upstream_commit: 'c3318066d964744e2bfc66f75c71745fe8cea52a', entries }
    const catalog = { ...body, catalog_fingerprint: createHash('sha256').update(canonical(body)).digest('hex') }
    await mkdir(path.dirname(catalogPath()), { recursive: true })
    await writeFile(catalogPath(), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
    process.stdout.write(JSON.stringify({ ok: true, binding_count: 1, profile: desktop.profileId }) + '\n')
  } finally { await rm(temporary, { recursive: true, force: true }) }
}

main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY041_CATALOG_IMPORT_FAILED' }) + '\n'); process.exitCode = 1 })
