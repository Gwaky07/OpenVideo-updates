[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$EditPlanPath,
  [Parameter(Mandatory=$true)][string]$OutputPath,
  [Parameter(Mandatory=$true)][string]$OutputRoot
)
$ErrorActionPreference = 'Stop'
$maxItems = 90
$maxSegmentSeconds = 60
$maxTotalSeconds = 600
function Fail([string]$Message) { throw "VID-001: $Message" }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { Fail 'ffmpeg is required' }
if (-not (Get-Command ffprobe -ErrorAction SilentlyContinue)) { Fail 'ffprobe is required' }
if (-not (Test-Path -LiteralPath $EditPlanPath -PathType Leaf)) { Fail 'edit_plan.json was not found' }
$root = [IO.Path]::GetFullPath((New-Item -ItemType Directory -Force -Path $OutputRoot).FullName)
$output = [IO.Path]::GetFullPath($OutputPath)
if ([IO.Path]::GetExtension($output) -ne '.mp4') { Fail 'OutputPath must use .mp4 extension' }
if (-not $output.StartsWith($root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { Fail 'OutputPath must stay inside OutputRoot' }
if (Test-Path -LiteralPath $output) { Fail 'OutputPath already exists' }
$plan = Get-Content -Raw -LiteralPath $EditPlanPath | ConvertFrom-Json
if ($null -eq $plan -or $plan.schema_version -ne 1 -or $plan.kind -ne 'edit_plan' -or $null -eq $plan.items -or -not ($plan.items -is [Array]) -or @($plan.items).Count -eq 0 -or @($plan.items).Count -gt $maxItems) { Fail 'expected non-empty edit_plan schema_version 1 with bounded items array' }
$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('openvideo-vid001-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempRoot | Out-Null
try {
  $concat = Join-Path $tempRoot 'concat.txt'
  $lines = [Collections.Generic.List[string]]::new()
  $ids = [Collections.Generic.HashSet[string]]::new()
  $index = 0
  $total = 0.0
  foreach ($item in @($plan.items)) {
    if ($null -eq $item -or -not $item.PSObject.Properties['item_id'] -or [string]::IsNullOrWhiteSpace([string]$item.item_id)) { Fail 'item_id is required' }
    $id = [string]$item.item_id
    if ($id.Length -gt 120 -or $id -notmatch '^[A-Za-z0-9._-]+$' -or -not $ids.Add($id)) { Fail 'item_id must be unique and safe' }
    if ($item.status -ne 'selected') { continue }
    if (-not $item.PSObject.Properties['start'] -or -not $item.PSObject.Properties['end'] -or $null -eq $item.start -or $null -eq $item.end) { Fail 'start and end are required' }
    $start = [double]$item.start
    $end = [double]$item.end
    if ([double]::IsNaN($start) -or [double]::IsInfinity($start) -or [double]::IsNaN($end) -or [double]::IsInfinity($end) -or $start -lt 0 -or $end -le $start) { Fail 'invalid selected item timing' }
    $duration = $end - $start
    if ($duration -gt $maxSegmentSeconds -or $end -gt 86400) { Fail 'selected item duration exceeds safety limit' }
    $total += $duration
    if ($total -gt $maxTotalSeconds) { Fail 'total preview duration exceeds safety limit' }
    $color = @('0f172a','164e63','365314','581c87','7c2d12')[$index % 5]
    $segment = Join-Path $tempRoot ("segment-{0}.mp4" -f $index)
    & ffmpeg -hide_banner -loglevel error -f lavfi -i "color=c=#${color}:s=1280x720:r=30" -t $duration -an -c:v libx264 -pix_fmt yuv420p -movflags +faststart $segment
    if ($LASTEXITCODE -ne 0) { Fail "ffmpeg failed for item $id" }
    $lines.Add(("file '{0}'" -f $segment.Replace("'", "'\''")))
    $index++
  }
  if ($index -eq 0) { Fail 'edit_plan contains no selected items' }
  [IO.File]::WriteAllLines($concat, $lines)
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $output) | Out-Null
  & ffmpeg -n -hide_banner -loglevel error -f concat -safe 0 -i $concat -c copy -movflags +faststart $output
  if ($LASTEXITCODE -ne 0) { Fail 'ffmpeg concat failed' }
  $probe = & ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $output 2>$null
  if (-not $probe) { Fail 'output MP4 could not be probed' }
  ConvertTo-Json @{ output=$output; selected_items=$index; duration_seconds=[double]$probe } -Compress
} finally {
  Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
}