[CmdletBinding()]
param(
    [string]$RuntimeDataRoot,
    [switch]$RealAcceptance
)

$ErrorActionPreference = 'Stop'
$repositoryRoot = Split-Path -Parent $PSScriptRoot

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [scriptblock]$Command,
        [Parameter(Mandatory = $true)]
        [string]$Failure
    )

    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Failure (exit $LASTEXITCODE)"
    }
}

Push-Location $repositoryRoot
try {
    Push-Location 'apps/gateway'
    try {
        Invoke-Checked {
            node --test `
                'test/gateway.test.mjs' `
                'test/director.test.mjs' `
                'test/material-analysis-contracts.test.mjs' `
                'test/permissive-material-analyzer.test.mjs' `
                'test/workbench-job-contracts.test.mjs' `
                'test/workbench-job-repository.test.mjs' `
                'test/workbench-job-coordinator.test.mjs' `
                'test/workbench.test.mjs' `
                'test/server.test.mjs'
        } 'PROD-002 Gateway focused tests failed'
    }
    finally {
        Pop-Location
    }

    $env:NODE_ENV = 'test'
    Invoke-Checked { corepack pnpm --filter '@openvideo/web' test } 'PROD-002 Web tests failed'
    Invoke-Checked { corepack pnpm typecheck } 'PROD-002 typecheck failed'
    Invoke-Checked { corepack pnpm lint } 'PROD-002 lint failed'
    Invoke-Checked { corepack pnpm build } 'PROD-002 build failed'
    Invoke-Checked { & (Join-Path $PSScriptRoot 'Test-Governance.ps1') } 'Governance validation failed'
    Invoke-Checked { & (Join-Path $PSScriptRoot 'Test-Governance-Negative.ps1') } 'Governance negative validation failed'
    Invoke-Checked { git diff --check } 'Git diff validation failed'

    if ($RealAcceptance) {
        if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
            throw 'RuntimeDataRoot is required for real acceptance.'
        }
        & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') -RuntimeDataRoot $RuntimeDataRoot -Stage before
        try {
            Invoke-Checked {
                node (Join-Path $PSScriptRoot 'run-prod002-real-acceptance.mjs') $RuntimeDataRoot
            } 'PROD-002 real acceptance failed'
        }
        finally {
            & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') -RuntimeDataRoot $RuntimeDataRoot -Stage after
        }
    }

    Write-Output 'PROD-002 verification passed.'
}
finally {
    Pop-Location
}
