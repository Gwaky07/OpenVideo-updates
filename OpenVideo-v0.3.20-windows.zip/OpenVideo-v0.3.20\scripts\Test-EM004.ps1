[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Invoke-Checked {
    param([string]$Name, [scriptblock]$Action)
    Write-Host "==> $Name" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Action
    if ($LASTEXITCODE -ne 0) { throw "$Name failed with exit code $LASTEXITCODE" }
}

$root = [IO.Path]::GetFullPath($RepositoryRoot)
$pinPath = Join-Path $root 'config/edit-mind-upstream.json'
$commonGitDirectory = (& git -C $root rev-parse --git-common-dir).Trim()
Assert-True ($LASTEXITCODE -eq 0) 'Unable to resolve the OpenVideo common Git directory.'
$totalProjectRoot = Split-Path -Parent ([IO.Path]::GetFullPath($commonGitDirectory))
$upstreamRoot = Join-Path $totalProjectRoot 'upstream/edit-mind'
$pin = Get-Content -LiteralPath $pinPath -Raw -Encoding UTF8 | ConvertFrom-Json

Assert-True ($pin.repository -eq 'https://github.com/IliasHad/edit-mind.git') 'Unexpected Edit Mind repository pin.'
Assert-True ($pin.commit -eq '4cfed9470e77f3552afdbc464f36caf1386dc990') 'Unexpected Edit Mind commit pin.'
Assert-True (Test-Path -LiteralPath $upstreamRoot -PathType Container) 'Ignored upstream/edit-mind checkout is required.'

$actualCommit = (& git -C $upstreamRoot rev-parse HEAD).Trim()
Assert-True ($LASTEXITCODE -eq 0 -and $actualCommit -eq $pin.commit) 'Edit Mind checkout is not at the pinned commit.'
$actualRemote = (& git -C $upstreamRoot remote get-url origin).Trim().TrimEnd('/')
Assert-True ($LASTEXITCODE -eq 0 -and $actualRemote -eq $pin.repository) 'Edit Mind checkout remote does not match the pin.'
$dirty = @(& git -C $upstreamRoot status --porcelain --untracked-files=all)
Assert-True ($LASTEXITCODE -eq 0 -and $dirty.Count -eq 0) 'Edit Mind tracked worktree is dirty.'
$ignored = @(& git -C $root check-ignore 'upstream/edit-mind')
Assert-True ($LASTEXITCODE -eq 0 -and $ignored.Count -eq 1) 'upstream/edit-mind is not ignored by OpenVideo Git.'

$admissionExample = Get-Content -LiteralPath (Join-Path $root 'config/edit-mind-license-admission.example.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Assert-True ($admissionExample.decision -eq 'pending') 'Public license example must default to pending.'
Assert-True ($admissionExample.organization_size_eligible -eq $false) 'Public license example must not pre-confirm organization eligibility.'
Assert-True ($admissionExample.direct_competition_reviewed -eq $false) 'Public license example must not pre-confirm non-competition.'
Assert-True ($admissionExample.written_authorization_confirmed -eq $false) 'Public license example must not pre-confirm written authorization.'
$providerExample = Get-Content -LiteralPath (Join-Path $root 'config/edit-mind-provider.example.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Assert-True ($providerExample.material_container_ids.Count -eq 3) 'Provider config must identify all three material-consuming containers.'
Assert-True ($providerExample.authorization_id -and $providerExample.material_root) 'Provider config must explicitly bind authorization and material root.'

$tracked = @(& git -C $root ls-files)
Assert-True (-not ($tracked -contains 'upstream/edit-mind')) 'Third-party upstream source must not be tracked.'
Assert-True (-not ($tracked -contains 'license-admission.json')) 'Private license admission must not be tracked.'
Assert-True (-not ($tracked -contains 'provider.json')) 'Private provider configuration must not be tracked.'
Assert-True (-not ($tracked | Where-Object { $_ -match '(?i)(^|/)Scene-[^/]*\.mp4$' })) 'Permanent Scene clips must not be tracked.'

Invoke-Checked 'Real-material snapshot tests' {
    & (Join-Path $root 'scripts/Test-EM004RealMaterialSnapshot.ps1') -RepositoryRoot $root
}

Invoke-Checked 'Gateway EM-004 tests' {
    & node --test `
        (Join-Path $root 'apps/gateway/test/edit-mind.test.mjs') `
        (Join-Path $root 'apps/gateway/test/ollama-bridge.test.mjs')
}

Invoke-Checked 'Gateway Workbench tests' {
    & node --test `
        (Join-Path $root 'apps/gateway/test/local-runtime.test.mjs') `
        (Join-Path $root 'apps/gateway/test/workbench.test.mjs')
}

Invoke-Checked 'Web material analysis tests' {
    $previousNodeEnv = $env:NODE_ENV
    try {
        $env:NODE_ENV = 'test'
        & corepack pnpm --dir $root --filter '@openvideo/web' test 'src/pages/ProjectMaterialsPage.test.tsx'
    } finally {
        if ($null -eq $previousNodeEnv) {
            Remove-Item Env:NODE_ENV -ErrorAction SilentlyContinue
        } else {
            $env:NODE_ENV = $previousNodeEnv
        }
    }
}

Invoke-Checked 'Gateway typecheck' {
    & corepack pnpm --dir $root --filter '@openvideo/gateway' typecheck
}

Write-Host 'EM-004 adapter, license, integrity, privacy, read-only and Top 3 checks passed.' -ForegroundColor Green
