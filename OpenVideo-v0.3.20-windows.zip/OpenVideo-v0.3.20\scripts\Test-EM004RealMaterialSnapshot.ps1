[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
$testRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) ("Temp\openvideo-em004-snapshot-$([Guid]::NewGuid().ToString('N'))")
$materialRoot = Join-Path $testRoot 'materials'
$runtimeRoot = Join-Path $testRoot 'runtime'
$scriptPath = Join-Path $RepositoryRoot 'scripts/Protect-EM004RealMaterials.ps1'

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

try {
    New-Item -ItemType Directory -Path $materialRoot -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $materialRoot 'nested') -Force | Out-Null
    [IO.File]::WriteAllText((Join-Path $materialRoot 'sample-a.mp4'), 'sample-a', $utf8)
    [IO.File]::WriteAllText((Join-Path $materialRoot 'nested/sample-b.mov'), 'sample-b', $utf8)
    [IO.File]::WriteAllText((Join-Path $materialRoot 'notes.txt'), 'metadata', $utf8)

    & $scriptPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before -SampleCount 2
    $preflightPath = Join-Path $runtimeRoot 'evidence/em-004/source-preflight.json'
    $preflightText = Get-Content -LiteralPath $preflightPath -Raw -Encoding UTF8
    $preflight = $preflightText | ConvertFrom-Json
    Assert-True ($preflight.file_count -eq 3 -and $preflight.sample_count -eq 2) 'Before snapshot counts are invalid.'
    Assert-True (-not $preflightText.Contains($materialRoot)) 'Public preflight leaked the material root.'
    Assert-True (-not $preflightText.Contains('sample-a.mp4')) 'Public preflight leaked a material name.'

    & $scriptPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase After -SampleCount 2
    $verification = Get-Content -LiteralPath (Join-Path $runtimeRoot 'evidence/em-004/source-verification.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    Assert-True ($verification.unchanged -eq $true) 'Unchanged fixture did not pass verification.'

    [IO.File]::AppendAllText((Join-Path $materialRoot 'sample-a.mp4'), '-changed', $utf8)
    $changeRejected = $false
    try {
        & $scriptPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase After -SampleCount 2
    } catch {
        $changeRejected = $_.Exception.Message -match 'count, names, sizes, mtimes, or sample SHA256 changed'
    }
    Assert-True $changeRejected 'Changed material was accepted by the after snapshot.'
    Write-Host 'EM-004 real-material snapshot tests passed.' -ForegroundColor Green
} finally {
    if (Test-Path -LiteralPath $testRoot) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force
    }
}
