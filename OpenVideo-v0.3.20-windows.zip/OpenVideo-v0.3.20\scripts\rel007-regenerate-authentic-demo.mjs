#!/usr/bin/env node
/**
 * REL-007: regenerate authentic template demo for an existing library template.
 * Writes only into the private runtime template-library-media store.
 */
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { createTemplateDemoRenderer } from '../apps/gateway/src/template-demo-renderer.mjs'
import { createTemplateMediaStore } from '../apps/gateway/src/template-media-store.mjs'
import { createTemplateStyleAnalyzer } from '../apps/gateway/src/template-style-analyzer.mjs'

const dataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
  || path.join(process.env.LOCALAPPDATA || '', 'OpenVideo', 'data')
const requestedId = process.argv[2] || ''

const ffmpegPath = path.join(dataRoot, 'material-analysis', 'dependencies', 'ffmpeg', 'bin', 'ffmpeg.exe')
const ffprobePath = path.join(dataRoot, 'material-analysis', 'dependencies', 'ffmpeg', 'bin', 'ffprobe.exe')
if (!fs.existsSync(ffmpegPath)) {
  console.error(JSON.stringify({ ok: false, error: 'FFMPEG_MISSING' }))
  process.exit(2)
}

const templatesPath = path.join(dataRoot, 'reusable-templates.json')
const storeDoc = JSON.parse(fs.readFileSync(templatesPath, 'utf8'))
const records = Array.isArray(storeDoc.records) ? storeDoc.records : []

/** @type {Map<string, any>} */
const latestById = new Map()
for (const record of records) {
  const id = record.libraryTemplateId
  if (!id) continue
  const prev = latestById.get(id)
  if (!prev || Number(record.revision || 0) >= Number(prev.revision || 0)) {
    latestById.set(id, record)
  }
}

const candidates = [...latestById.values()].filter((record) => {
  const dir = path.join(dataRoot, 'template-library-media', record.libraryTemplateId)
  return fs.existsSync(path.join(dir, 'reference.mp4')) || fs.existsSync(path.join(dir, 'reference.mov'))
})

const selected = requestedId
  ? candidates.find((item) => item.libraryTemplateId === requestedId)
  : candidates.find((item) => item.libraryTemplateId.includes('2a8b312c'))
    || candidates.find((item) => item.status === 'approved')
    || candidates[0]

if (!selected) {
  console.error(JSON.stringify({ ok: false, error: 'NO_TEMPLATE_WITH_REFERENCE', count: candidates.length }))
  process.exit(3)
}

const tempRoot = path.join(dataRoot, 'tmp', 'rel007-template-regen')
fs.mkdirSync(tempRoot, { recursive: true })

const styleAnalyzer = createTemplateStyleAnalyzer({
  ffmpegPath,
  ffprobePath: fs.existsSync(ffprobePath) ? ffprobePath : null,
  tempRoot,
})
const demoRenderer = createTemplateDemoRenderer({ ffmpegPath })
const mediaStore = createTemplateMediaStore({
  dataRoot,
  ffmpegPath,
  demoRenderer,
  styleAnalyzer,
})

const before = await mediaStore.previewAvailability(selected.libraryTemplateId)
const result = await mediaStore.generateDemo(selected.libraryTemplateId, {
  durationSeconds: Math.min(15, Math.max(8, Number(selected.targetDurationSeconds) || 12)),
  label: selected.label,
  storedTemplate: {
    libraryTemplateId: selected.libraryTemplateId,
    revision: selected.revision,
    fingerprint: selected.fingerprint,
    label: selected.label,
    orientation: selected.orientation,
    targetDurationSeconds: selected.targetDurationSeconds,
    pacing: selected.pacing,
    status: selected.status,
    artifact: selected.artifact,
  },
  styleSummary: selected.styleSummary || null,
})
const after = await mediaStore.previewAvailability(selected.libraryTemplateId)
const meta = await mediaStore.readMeta(selected.libraryTemplateId)

const summary = {
  ok: after.demoAuthentic === true
    && after.demoRenderer === 'template_demo_renderer'
    && after.demoPlayable === true,
  libraryTemplateId: selected.libraryTemplateId,
  label: selected.label,
  status: selected.status,
  revision: selected.revision,
  fingerprint: selected.fingerprint,
  before,
  after,
  demo: {
    status: meta?.demo?.status || null,
    sha256: meta?.demo?.sha256 || null,
    durationSeconds: meta?.demo?.durationSeconds || null,
    renderer: meta?.demo?.renderer || null,
    authentic: meta?.demo?.authentic === true,
    bindingFingerprint: meta?.demo?.bindingFingerprint || null,
    demoFingerprint: meta?.demo?.demoFingerprint || null,
    errorCode: meta?.demo?.errorCode || null,
  },
  styleAnalysisComplete: after.styleAnalysisComplete === true,
  approveReady: after.approveReady === true,
}
console.log(JSON.stringify(summary, null, 2))
process.exit(summary.ok ? 0 : 1)
