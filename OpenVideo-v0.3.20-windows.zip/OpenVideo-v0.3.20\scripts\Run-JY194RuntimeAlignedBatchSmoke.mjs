import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

import {
  loadLauncherRuntimeConfig,
  summarizeLauncherRuntimeConfig,
} from '../apps/gateway/src/launcher-runtime-config.mjs'

const allowedFamilies = new Set(['video_effect', 'sticker', 'video_animation', 'mask', 'blend'])
const smokeScript = fileURLToPath(new URL('./New-JY138PrivateBatchEvidenceDraft.mjs', import.meta.url))
export const MAX_WRITER_OUTPUT_BYTES = 64 * 1024
export const WRITER_TIMEOUT_MS = 90_000
const MAX_WRITER_PLACEMENTS = 24
const safeProfilePattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/u
const safeVersionPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/u

/** @param {unknown} value @param {RegExp} pattern */
const isSafeBoundedString = (value, pattern) => typeof value === 'string' && pattern.test(value)

/** @param {unknown} value */
const isSafePlacementCount = (value) => Number.isSafeInteger(value) && value >= 1 && value <= MAX_WRITER_PLACEMENTS

/** @param {unknown} value */
export const parseWriterSmokeOutput = (value, { exitCode = 0, signal = null } = {}) => {
  const lines = typeof value === 'string' ? value.split(/\r?\n/u).map((line) => line.trim()).filter(Boolean) : []
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    try {
      const parsed = JSON.parse(lines[index])
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) continue
      if (
        parsed.ok === true &&
        exitCode === 0 &&
        signal === null &&
        parsed.manual_open_required === true &&
        isSafePlacementCount(parsed.placements) &&
        isSafeBoundedString(parsed.profile, safeProfilePattern) &&
        isSafeBoundedString(parsed.version, safeVersionPattern)
      ) {
        return Object.freeze({
          status: 'draft_created',
          manual_open_required: true,
          placements: parsed.placements,
          profile: parsed.profile,
          version: parsed.version,
        })
      }
      if (parsed.ok === false && typeof parsed.code === 'string' && /^JY[0-9A-Z_]+$/u.test(parsed.code)) {
        return Object.freeze({ status: 'blocked', code: parsed.code })
      }
    } catch { /* ignore child diagnostics and inspect the next JSON line */ }
  }
  return Object.freeze({ status: 'blocked', code: 'JY194_WRITER_SMOKE_FAILED' })
}

/** @param {number} port */
const probeGateway = async (port) => {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 5_000)
  try {
    const response = await fetch(`http://127.0.0.1:${port}/api/live`, { signal: controller.signal })
    return Object.freeze({ reachable: response.ok, status: response.status })
  } catch {
    return Object.freeze({ reachable: false, status: null })
  } finally {
    clearTimeout(timer)
  }
}

/** @param {{config: {source: string, gatewayPort: number}, gateway: {reachable: boolean, status: number|null}, writer: Record<string, any>}} input */
export const buildSafeSmokeSummary = ({ config, gateway, writer }) => {
  const validSuccess = writer?.status === 'draft_created' &&
    writer.manual_open_required === true &&
    isSafePlacementCount(writer.placements) &&
    isSafeBoundedString(writer.profile, safeProfilePattern) &&
    isSafeBoundedString(writer.version, safeVersionPattern)
  const safeStatus = validSuccess ? 'draft_created' : 'blocked'
  const safeCode = safeStatus === 'blocked'
    ? (typeof writer?.code === 'string' && /^JY[0-9A-Z_]+$/u.test(writer.code) ? writer.code : 'JY194_WRITER_SMOKE_FAILED')
    : null
  return Object.freeze({
    schema_version: 1,
    runtime: summarizeLauncherRuntimeConfig(config),
    gateway: Object.freeze({ reachable: gateway.reachable === true, status: gateway.status }),
    writer: Object.freeze({
      status: safeStatus,
      ...(safeCode ? { code: safeCode } : {}),
      ...(safeStatus === 'draft_created'
        ? {
            manual_open_required: true,
            placements: writer.placements,
            profile: writer.profile,
            version: writer.version,
          }
        : {}),
    }),
    evidence_boundary: Object.freeze({
      discovery_only_never_promoted: true,
      desktop_open_edit_save_reopen_verified: false,
    }),
  })
}

/** @param {string[]} args */
export const parseFamilyArgs = (args) => {
  if (args.length === 0) return []
  if (args.length === 2 && args[0] === '--family' && allowedFamilies.has(args[1])) return args
  throw new Error('JY194_FAMILY_INVALID')
}

/** @param {import('node:child_process').ChildProcess} child */
const killWriterProcessTree = (child) => new Promise((resolve) => {
  if (!child.pid) {
    resolve()
    return
  }
  if (process.platform === 'win32') {
    const killer = spawn('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], {
      stdio: 'ignore',
      windowsHide: true,
    })
    killer.once('error', () => resolve())
    killer.once('close', () => resolve())
    return
  }
  try { process.kill(-child.pid, 'SIGKILL') } catch { try { child.kill('SIGKILL') } catch { /* already closed */ } }
  resolve()
})

const runWriter = (args, config) => new Promise((resolve) => {
  const childEnvironment = { ...process.env }
  // The child must resolve both runtime and Python roots from launcher config;
  // stale shell values are removed rather than allowed to influence a smoke.
  delete childEnvironment.OPENVIDEO_RUNTIME_DATA_ROOT
  delete childEnvironment.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  childEnvironment.OPENVIDEO_CONFIG_PATH = config.configPath
  const child = spawn(process.execPath, [smokeScript, ...args], {
    env: childEnvironment,
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: process.platform !== 'win32',
    windowsHide: true,
  })
  let stdout = ''
  let stdoutBytes = 0
  let settled = false
  let timedOut = false
  let outputExceeded = false
  let timer
  let cleanupPromise = null
  const finish = (result) => {
    if (settled) return
    settled = true
    clearTimeout(timer)
    resolve(result)
  }
  const terminate = () => {
    cleanupPromise ??= killWriterProcessTree(child)
    return cleanupPromise
  }
  child.stdout.on('data', (chunk) => {
    if (settled) return
    const bytes = Buffer.isBuffer(chunk) ? chunk.byteLength : Buffer.byteLength(String(chunk))
    stdoutBytes += bytes
    if (stdoutBytes > MAX_WRITER_OUTPUT_BYTES) {
      outputExceeded = true
      void terminate()
      return
    }
    stdout += Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk)
  })
  // Drain diagnostics so a noisy child cannot block on stderr. Diagnostics
  // are intentionally discarded because they may contain private paths.
  child.stderr.on('data', () => {})
  child.on('error', () => finish(Object.freeze({ status: 'blocked', code: 'JY194_WRITER_SMOKE_FAILED' })))
  child.on('close', async (exitCode, signal) => {
    if (timedOut || outputExceeded) {
      await terminate()
      finish(Object.freeze({ status: 'blocked', code: timedOut ? 'JY194_WRITER_SMOKE_TIMEOUT' : 'JY194_WRITER_SMOKE_OUTPUT_LIMIT' }))
      return
    }
    finish(parseWriterSmokeOutput(stdout, { exitCode, signal }))
  })
  timer = setTimeout(() => {
    timedOut = true
    void terminate()
  }, WRITER_TIMEOUT_MS)
})

const main = async () => {
  const config = await loadLauncherRuntimeConfig()
  const args = parseFamilyArgs(process.argv.slice(2))
  const gateway = await probeGateway(config.gatewayPort)
  const writer = await runWriter(args, config)
  process.stdout.write(`${JSON.stringify(buildSafeSmokeSummary({ config, gateway, writer }))}\n`)
  if (writer.status !== 'draft_created' && writer.code !== 'JY138_PENDING_EVIDENCE_EXISTS') process.exitCode = 1
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main().catch((error) => {
    const code = error?.code && /^JY[0-9A-Z_]+$/u.test(error.code) ? error.code : 'JY194_RUNTIME_CONFIG_FAILED'
    process.stdout.write(`${JSON.stringify({ schema_version: 1, status: 'blocked', code })}\n`)
    process.exitCode = 1
  })
}
