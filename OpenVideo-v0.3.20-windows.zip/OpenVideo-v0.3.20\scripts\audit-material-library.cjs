#!/usr/bin/env node
/**
 * MATERIAL-LIBRARY-001 / phase audit
 *
 * Walks the codebase and confirms the artifacts claimed by the
 * `MATERIAL-LIBRARY-001` phases still exist on the current checkout.
 * Prints a per-phase PASS / PARTIAL / MISS table.
 *
 * This is a discovery-only audit; it never modifies files. Exits 0 if
 * every phase is at least PASS or PARTIAL, 1 if any phase is MISS.
 *
 * Re-run anytime:
 *   node scripts/audit-material-library.cjs
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');

function exists(rel) {
  return fs.existsSync(path.join(ROOT, rel));
}

function readFileSafe(rel) {
  try { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
  catch { return ''; }
}

function grepCount(rel, needle) {
  if (!exists(rel)) return 0;
  const hay = readFileSafe(rel);
  if (!hay) return 0;
  if (needle instanceof RegExp) {
    const m = hay.match(new RegExp(needle.source, needle.flags + 'g'));
    return m ? m.length : 0;
  }
  let n = 0, i = 0;
  while ((i = hay.indexOf(needle, i)) !== -1) { n++; i += needle.length; }
  return n;
}

function grepAny(rel, needles) {
  return needles.some((n) => grepCount(rel, n) > 0);
}

function statusFor(checks) {
  // checks is array of {label, ok}
  const total = checks.length;
  const okCount = checks.filter((c) => c.ok).length;
  if (okCount === total) return 'PASS';
  if (okCount >= Math.ceil(total / 2)) return 'PARTIAL';
  return 'MISS';
}

function row(phase, status, checks) {
  console.log(`${phase.padEnd(8)} ${status.padEnd(8)} ${checks.map((c) => (c.ok ? '✓' : '✗')).join(' ')}`);
}

const phases = [];

phases.push({
  name: 'Phase 1',
  title: 'Foundation and safe identity',
  checks: [
    { label: 'gateway material-library service exists', ok: exists('apps/gateway/src/material-library.mjs') },
    { label: 'MaterialAsset analyzerVersion field', ok: grepAny('apps/gateway/src/material-library.mjs', ['analyzerVersion']) },
    { label: 'manifest fingerprint in analyzer', ok: grepAny('apps/gateway/src/permissive-material-analyzer.mjs', ['manifest_fingerprint']) },
    { label: 'fail-closed error type', ok: grepAny('apps/gateway/src/material-library.mjs', ['MaterialLibraryError']) },
  ],
});

phases.push({
  name: 'Phase 2',
  title: 'Reuse and incremental analysis',
  checks: [
    { label: 'libraryState stale flag', ok: grepAny('apps/gateway/src/material-library.mjs', ["'stale'"]) },
    { label: 'libraryState unavailable flag', ok: grepAny('apps/gateway/src/material-library.mjs', ["'unavailable'"]) },
    { label: 'binding-mediated reuse', ok: grepAny('apps/gateway/src/material-library.mjs', ['LibraryBinding', 'projectReferences']) },
    { label: 'artifact/binding storage split', ok: grepAny('apps/gateway/src/permissive-material-analyzer.mjs', ['artifacts']) && grepAny('apps/gateway/src/permissive-material-analyzer.mjs', ['bindings']) },
  ],
});

phases.push({
  name: 'Phase 3',
  title: 'Global material-library experience',
  checks: [
    { label: '/library route', ok: exists('apps/web/src/pages/MaterialLibraryPage.tsx') },
    { label: '/library test', ok: exists('apps/web/src/pages/MaterialLibraryPage.test.tsx') },
    { label: 'library API client', ok: exists('apps/web/src/api/library.ts') },
    { label: 'virtual collections', ok: grepAny('apps/gateway/src/material-library.mjs', ['LibraryCollection']) },
    { label: 'favorite scene refs', ok: grepAny('apps/gateway/src/material-library.mjs', ['favoriteSceneRefs']) },
    { label: 'add-to-project reference', ok: grepAny('apps/gateway/src/material-library.mjs', ['addReference', 'addReferences']) },
  ],
});

phases.push({
  name: 'Phase 4',
  title: 'Project integration and migration',
  checks: [
    { label: 'project reference state', ok: grepAny('apps/gateway/src/material-library.mjs', ['getProjectReferenceState', 'removeProjectReferences']) },
    { label: 'project material page', ok: exists('apps/web/src/pages/ProjectMaterialsPage.tsx') },
    { label: 'needsReview flag', ok: grepAny('apps/gateway/src/material-library.mjs', ['needsReview']) },
  ],
});

phases.push({
  name: 'Phase 5',
  title: 'Evidence and rollout',
  checks: [
    { label: 'gateway material tests', ok: (function () { try { return fs.readdirSync(path.join(ROOT, 'apps/gateway/test')).some((f) => /material/i.test(f)); } catch { return false; } })() },
    { label: 'web material tests', ok: exists('apps/web/src/pages/MaterialLibraryPage.test.tsx') && exists('apps/web/src/api/library.test.ts') },
    { label: 'CSS contract test', ok: exists('apps/web/src/pages/materials/MaterialLibraryBrowser.styles.test.ts') },
    { label: 'visual gate screenshot dir', ok: exists('docs/tasks/MATERIAL-LIBRARY-001-visual-gate/screens') },
  ],
});

let anyMiss = false;
console.log('=== MATERIAL-LIBRARY-001 phase audit ===');
console.log(`cwd: ${ROOT}`);
console.log('');
for (const p of phases) {
  const s = statusFor(p.checks);
  if (s === 'MISS') anyMiss = true;
  row(p.name + ' (' + p.title + ')', s, p.checks);
}
console.log('');
const total = phases.length;
const pass = phases.filter((p) => statusFor(p.checks) === 'PASS').length;
const partial = phases.filter((p) => statusFor(p.checks) === 'PARTIAL').length;
const miss = phases.filter((p) => statusFor(p.checks) === 'MISS').length;
console.log(`Summary: ${total} phases, ${pass} PASS, ${partial} PARTIAL, ${miss} MISS.`);
console.log('');
if (anyMiss) {
  console.error('Audit FAILED: at least one phase is MISS.');
  process.exit(1);
}
console.log('Audit OK: every phase is at least PARTIAL.');
