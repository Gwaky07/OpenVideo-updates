import { execFile } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import {
  detectJianyingDesktop,
  inspectPyJianyingUpstream,
} from '../apps/gateway/src/jianying-local-environment.mjs'
import { securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const execFileAsync = promisify(execFile)
const repositoryRoot = fileURLToPath(new URL('..', import.meta.url))
const runtimeDataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
const pythonModuleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
const pythonExecutable = process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE || 'python'
const ffmpegExecutable = process.env.OPENVIDEO_FFMPEG_EXECUTABLE || 'ffmpeg'
const durationUs = 4_000_000
let acceptanceStage = 'configuration'

const requirePrivateConfiguration = () => {
  if (
    typeof runtimeDataRoot !== 'string' ||
    !path.isAbsolute(runtimeDataRoot) ||
    typeof pythonModuleRoot !== 'string' ||
    !path.isAbsolute(pythonModuleRoot)
  ) {
    throw Object.assign(new Error('JY008_ACCEPTANCE_CONFIG_INVALID'), {
      code: 'JY008_ACCEPTANCE_CONFIG_INVALID',
    })
  }
}

/** @param {string} mediaRoot */
const createPrivateSyntheticMedia = async (mediaRoot) => {
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const voiceoverPath = path.join(mediaRoot, 'voiceover.wav')
  const bgmPath = path.join(mediaRoot, 'bgm.wav')
  const sfxPath = path.join(mediaRoot, 'sfx.wav')
  await execFileAsync(ffmpegExecutable, [
    '-hide_banner', '-loglevel', 'error', '-y',
    '-f', 'lavfi', '-i', 'color=c=0x1f6feb:s=540x960:r=30',
    '-t', '4', '-pix_fmt', 'yuv420p', videoPath,
  ])
  for (const [filePath, frequency, seconds] of [
    [voiceoverPath, 440, 4],
    [bgmPath, 220, 5],
    [sfxPath, 880, 1],
  ]) {
    await execFileAsync(ffmpegExecutable, [
      '-hide_banner', '-loglevel', 'error', '-y',
      '-f', 'lavfi', '-i', `sine=frequency=${frequency}:sample_rate=48000`,
      '-t', String(seconds), '-ac', '1', filePath,
    ])
  }
  return { videoPath, voiceoverPath, bgmPath, sfxPath }
}

/** @param {Record<string, any>} content */
const assertPersistedStructures = (content) => {
  const videoTrack = content.tracks.find((track) => track.name === 'video-primary')
  const rotation = videoTrack?.segments?.[0]?.common_keyframes?.find(
    (entry) => entry.property_type === 'KFTypeRotation',
  )
  const rotationPoint = rotation?.keyframe_list?.[0]
  if (rotationPoint?.time_offset !== 1_500_000 || rotationPoint?.values?.[0] !== 7) {
    throw Object.assign(new Error('JY008_ROTATION_STRUCTURE_MISSING'), {
      code: 'JY008_ROTATION_STRUCTURE_MISSING',
    })
  }
  const fades = new Map(content.materials.audio_fades.map((entry) => [entry.id, entry]))
  const expected = new Map([
    ['voiceover-primary', [120_000, 180_000]],
    ['sfx-primary', [100_000, 150_000]],
    ['bgm-primary', [300_000, 400_000]],
  ])
  for (const [trackName, durations] of expected) {
    const track = content.tracks.find((entry) => entry.name === trackName)
    const fadeId = track?.segments?.[0]?.extra_material_refs?.find((id) => fades.has(id))
    const fade = fades.get(fadeId)
    if (
      fade?.fade_in_duration !== durations[0] ||
      fade?.fade_out_duration !== durations[1]
    ) {
      throw Object.assign(new Error('JY008_AUDIO_FADE_STRUCTURE_MISSING'), {
        code: 'JY008_AUDIO_FADE_STRUCTURE_MISSING',
      })
    }
  }
}

const main = async () => {
  requirePrivateConfiguration()
  acceptanceStage = 'manifest'
  const compatibilityManifest = JSON.parse(
    await readFile(path.join(repositoryRoot, 'config', 'jianying-compatibility.json'), 'utf8'),
  )
  const upstreamManifest = JSON.parse(
    await readFile(path.join(repositoryRoot, 'config', 'pyjianyingdraft-upstream.json'), 'utf8'),
  )
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  acceptanceStage = 'upstream'
  await inspectPyJianyingUpstream({ upstreamRoot: pythonModuleRoot, manifest: upstreamManifest })
  if (
    desktop.capabilities.draft_generation !== true ||
    desktop.capabilities.manual_open !== true ||
    desktop.capabilities.background_render !== false
  ) {
    throw Object.assign(new Error('JY008_DESKTOP_PROFILE_INVALID'), {
      code: 'JY008_DESKTOP_PROFILE_INVALID',
    })
  }

  const runToken = `${new Date().toISOString().replace(/\D/gu, '').slice(0, 14)}-${randomBytes(3).toString('hex')}`
  const draftId = `OpenVideo-JY008-capability-${runToken}`
  const runRoot = path.join(runtimeDataRoot, 'jy008-acceptance', runToken)
  const mediaRoot = path.join(runRoot, 'media')
  const evidenceRoot = path.join(runtimeDataRoot, 'jy008-acceptance-evidence')
  acceptanceStage = 'private_root'
  await Promise.all([mkdir(runRoot, { recursive: true }), mkdir(evidenceRoot, { recursive: true })])
  await Promise.all([securePrivateRuntimeRoot(runRoot), securePrivateRuntimeRoot(evidenceRoot)])
  await mkdir(mediaRoot, { recursive: true })
  const media = await createPrivateSyntheticMedia(mediaRoot)
  acceptanceStage = 'draft_write'
  let renderOptions = {
    captions: false,
    bgmPath: media.bgmPath,
    bgmVolume: 0.12,
    timelinePackaging: {
      video: [{
        transition_out: null,
        keyframes: [{
          capability_id: 'transform.rotation',
          offset_us: 1_500_000,
          value: 7,
          interpolation: 'linear',
        }],
      }],
      voiceover_segments: [{
        segment_id: 'voiceover-acceptance',
        fade_in_us: 120_000,
        fade_out_us: 180_000,
      }],
      sfx_segments: [{
        path: media.sfxPath,
        volume: 0.5,
        target_start_us: 500_000,
        target_duration_us: 1_000_000,
        fade_in_us: 100_000,
        fade_out_us: 150_000,
      }],
      bgm: { fade_in_us: 300_000, fade_out_us: 400_000 },
      effect_segments: [],
      sticker_segments: [],
    },
  }
  const writer = createPyJianyingDraftWriter({
    draftRoot: desktop.draftRoot,
    pythonExecutable,
    pythonModuleRoot,
    getRenderOptions: () => renderOptions,
  })
  const exportRequest = {
    preparation: {
      timeline: {
        duration: durationUs,
        tracks: [
          { segments: [{ source_range: { start: 0, duration: durationUs }, target_range: { start: 0, duration: durationUs } }] },
          { segments: [{ segment_id: 'voiceover-acceptance', text: 'OpenVideo JY-008 editable draft acceptance', target_range: { start: 0, duration: durationUs } }] },
        ],
      },
    },
  }
  const writeInput = {
    job_id: `job-${runToken}`,
    request_id: `request-${runToken}`,
    output_policy: { draft_id: draftId },
    export_request: exportRequest,
    orientation: 'portrait',
    materials: [{ path: media.videoPath }],
    voiceovers: [{ path: media.voiceoverPath }],
  }
  const writeResult = await writer.writeDraft(writeInput)
  acceptanceStage = 'draft_verify'
  const verified = await writer.verifyDraft({
    job_id: writeInput.job_id,
    request: { export_request: exportRequest },
    write_result: writeResult,
  })
  if (verified !== true) throw Object.assign(new Error('JY008_DRAFT_VERIFY_FAILED'), { code: 'JY008_DRAFT_VERIFY_FAILED' })
  const content = JSON.parse(
    await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'), 'utf8'),
  )
  assertPersistedStructures(content)
  const isolation = writer.getIsolationEvidence({ job_id: writeInput.job_id })
  if (!isolation || isolation.before_fingerprint !== isolation.after_existing_fingerprint) {
    throw Object.assign(new Error('JY008_DRAFT_ISOLATION_FAILED'), { code: 'JY008_DRAFT_ISOLATION_FAILED' })
  }
  if (await writer.releaseDraft({ job_id: writeInput.job_id }) !== true) {
    throw Object.assign(new Error('JY008_DRAFT_RELEASE_FAILED'), { code: 'JY008_DRAFT_RELEASE_FAILED' })
  }
  renderOptions = null
  const evidence = {
    schema_version: 1,
    kind: 'jy008_capability_acceptance_evidence',
    generated_at: new Date().toISOString(),
    draft_label: draftId,
    desktop_version: desktop.version,
    profile_id: desktop.profileId,
    handoff_mode: 'manual_open_and_edit_required',
    desktop_opened: false,
    edit_confirmed: false,
    output_fingerprint: writeResult.output_fingerprint,
    structures: {
      rotation_keyframe: { offset_us: 1_500_000, value: 7 },
      voiceover_fade: [120_000, 180_000],
      sfx_fade: [100_000, 150_000],
      bgm_fade: [300_000, 400_000],
    },
    isolation,
    media_policy: 'private_synthetic_acceptance_assets_preserved_for_manual_edit_confirmation',
  }
  const evidencePath = path.join(evidenceRoot, `${runToken}.json`)
  acceptanceStage = 'evidence'
  await writeFile(evidencePath, `${JSON.stringify(evidence, null, 2)}\n`, { flag: 'wx' })
  process.stdout.write(`${JSON.stringify({ ok: true, evidence })}\n`)
}

main().catch((error) => {
  const code = error && typeof error === 'object' && 'code' in error
    ? String(error.code)
    : 'JY008_CAPABILITY_ACCEPTANCE_FAILED'
  process.stderr.write(`${JSON.stringify({ ok: false, code, stage: acceptanceStage })}\n`)
  process.exitCode = 1
})
