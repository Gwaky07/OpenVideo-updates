import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { parseJianyingAudioEffectCatalog, resolveJianyingAudioEffectToken } from '../apps/gateway/src/jianying-audio-effect-catalog.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { createJianyingPackagingResolver } from '../apps/gateway/src/jianying-packaging-resolver.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'

const run = promisify(execFile)
const manifest = JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8'))
const durationUs = 4_000_000
const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true || !['jianying-11-1-provisional', 'jianying-11-2-provisional'].includes(desktop.profileId)) throw new Error('JY067_PROFILE_UNSUPPORTED')
  const catalogPath = path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs', 'jy064-audio-effect-catalog.json')
  const catalog = parseJianyingAudioEffectCatalog(JSON.parse(await readFile(catalogPath, 'utf8')))
  const effectToken = catalog.entries.keys().next().value
  if (typeof effectToken !== 'string') throw new Error('JY067_CATALOG_MISSING')
  const tracks = [
    { trackId: 'video-primary', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary', segments: [{ segmentId: 'jy067-video', kind: 'video', asset: { authorizationId: 'jy067-auth', assetId: 'jy067-video', sceneId: 'jy067-scene' }, sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs }, fit: 'cover', volume: 1, speed: { numerator: 1, denominator: 1 }, keyframes: [], effects: [], audit: { origin: 'editor', candidateId: 'jy067-candidate', instructionFingerprint: null }, transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} } }] },
    { trackId: 'voiceover-empty', order: 1, enabled: true, locked: false, kind: 'audio', role: 'voiceover', segments: [] },
    { trackId: 'sfx-primary', order: 2, enabled: true, locked: false, kind: 'audio', role: 'sfx', segments: [{ segmentId: 'jy067-sfx', kind: 'sfx', capabilityId: 'audio.sfx.local', source: { kind: 'generated', generatedAudioId: 'jy067-audio' }, sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs }, volume: 1, fadeInUs: 0, fadeOutUs: 0, keyframes: [], ducking: 'none' }] },
    { trackId: 'audio-effect-primary', order: 3, enabled: true, locked: false, kind: 'effect', segments: [{ segmentId: 'jy067-audio-effect', kind: 'effect', targetRange: { startUs: 0, durationUs }, capabilityId: 'audio.effect.named', intensity: 1, parameters: { effectToken } }] },
  ]
  const draft = { schemaVersion: 1, timelineId: 'jy067-audio-effect', projectId: 'jy067', revision: 1, parentRevision: null, parentRevisionFingerprint: null, status: 'draft', createdAt: '2026-08-11T00:00:00.000Z', durationUs, orientation: 'portrait', fps: { numerator: 30, denominator: 1 }, source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null }, tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks) }
  const timeline = finalizeRichTimeline(sealRichTimeline(draft))
  const projected = projectRichTimelineToJianyingExport(timeline, { capabilityRegistry: { assertWriterCapability: () => ({}) } })
  const resolver = createJianyingPackagingResolver({ resolveAudioEffectToken: ({ effectToken: token }) => resolveJianyingAudioEffectToken(catalog, token) })
  const audioEffectBinding = await resolver.resolveAudioEffectToken(projected.packaging.audio_effect_segments[0]?.effect_token)
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy067-audio-'))
  const mediaOwner = randomUUID()
  await writeFile(path.join(mediaRoot, '.openvideo-jy067-owner'), mediaOwner, { encoding: 'utf8', mode: 0o600 })
  const videoPath = path.join(mediaRoot, 'video.mp4'); const audioPath = path.join(mediaRoot, 'audio.wav')
  await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath])
  await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=16000', '-t', '4', '-ac', '1', audioPath])
  const draftId = `OpenVideo-JY067-audio-effect-${Date.now()}`
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', captionSegments: [], titleSegments: [], timelinePackaging: { ...projected.packaging, sfx_segments: [{ path: audioPath, target_start_us: 0, target_duration_us: durationUs, volume: 1, fade_in_us: 0, fade_out_us: 0, effect_resource_id: audioEffectBinding.resourceId }], effect_segments: [], sticker_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
  const request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: videoPath }], voiceovers: [] }
  let stage = 'write'
  try {
    const result = await writer.writeDraft(request)
    stage = 'verify'
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY067_DRAFT_VERIFY_FAILED')
    stage = 'release'
    if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY067_DRAFT_RELEASE_FAILED')
    stage = 'evidence'
    const contentBytes = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
    const evidenceRoot = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy067-audio-effect')
    await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
    await securePrivateRuntimeRoot(evidenceRoot)
    await writeFile(path.join(evidenceRoot, 'pending.json'), `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, media_owner: mediaOwner, profile_id: desktop.profileId, app_version: desktop.version, catalog_fingerprint: catalog.fingerprint, effect_token: effectToken, pre_open_fingerprint: createHash('sha256').update(contentBytes).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
    process.stdout.write(JSON.stringify({ ok: true, draft_id: draftId, manual_open_required: true, profile: desktop.profileId }) + '\n')
  } catch (error) { await rm(mediaRoot, { recursive: true, force: true }); throw Object.assign(error, { evidenceStage: stage }) }
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY067_DRAFT_FAILED', stage: error?.evidenceStage ?? 'bootstrap' }) + '\n'); process.exitCode = 1 })
