import { execFile } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { access, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createJianyingDraftRuntime } from '../apps/gateway/src/jianying-draft-runtime.mjs'
import { createJianyingWorkbenchBridge } from '../apps/gateway/src/jianying-workbench-bridge.mjs'
import {
  detectJianyingDesktop,
  inspectPyJianyingUpstream,
} from '../apps/gateway/src/jianying-local-environment.mjs'
import {
  createReferenceTemplateAdapterRequest,
  createReferenceTemplateDraft,
  createReferenceTemplateReviewDecision,
  preflightReferenceTemplateDraft,
} from '../apps/gateway/src/reference-template-contracts.mjs'
import { createTemplateDraftRequest, selectFixedTemplate } from '../apps/gateway/src/template-library.mjs'
import { securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const execFileAsync = promisify(execFile)
const repositoryRoot = path.resolve(new URL('..', import.meta.url).pathname.slice(process.platform === 'win32' ? 1 : 0))
const runtimeDataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
const pythonModuleRoot =
  process.env.OPENVIDEO_PYJIANYINGDRAFT_ROOT ||
  process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
const pythonExecutable = process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE || 'python'
const ffmpegExecutable = process.env.OPENVIDEO_FFMPEG_EXECUTABLE ||
  (runtimeDataRoot
    ? path.join(runtimeDataRoot, 'material-analysis', 'dependencies', 'ffmpeg', 'bin', 'ffmpeg.exe')
    : '')

const segmentCount = 4
const segmentDurationSeconds = 4

/** @param {string} parent @param {string} candidate */
const isInsideAuthorizedRoot = (parent, candidate) => {
  const root = path.resolve(parent)
  const target = path.resolve(candidate)
  const relative = path.relative(root, target)
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

/**
 * 尝试从仓库外 authorizations.json + EM-005 索引取只读真材场景；失败则返回 null。
 * @param {{runtimeDataRoot: string, ffmpegExecutable: string, mediaRoot: string}} input
 */
const tryResolveAuthorizedVideoClips = async ({ runtimeDataRoot, ffmpegExecutable, mediaRoot }) => {
  try {
    const authorizationsPath = path.join(runtimeDataRoot, 'authorizations.json')
    const indexPath = path.join(runtimeDataRoot, 'material-analysis', 'analysis-index.json')
    await access(authorizationsPath)
    await access(indexPath)
    const authorizationsDocument = JSON.parse(await readFile(authorizationsPath, 'utf8'))
    const indexDocument = JSON.parse(await readFile(indexPath, 'utf8'))
    const records = Array.isArray(authorizationsDocument?.records)
      ? authorizationsDocument.records
      : Array.isArray(authorizationsDocument)
        ? authorizationsDocument
        : []
    const indexRecords = Array.isArray(indexDocument?.records) ? indexDocument.records : []
    /** @type {{authorizationId: string, absolutePath: string, scenes: {relativePath: string, start: number, end: number}[]} | null} */
    let selected = null
    for (const authorization of records) {
      if (
        !authorization ||
        authorization.status !== 'authorized' ||
        authorization.readOnly === false ||
        typeof authorization.id !== 'string' ||
        typeof authorization.absolutePath !== 'string' ||
        !path.isAbsolute(authorization.absolutePath)
      ) continue
      const analysis = indexRecords.find((record) =>
        record?.authorization_id === authorization.id &&
        Array.isArray(record?.assets) &&
        record.assets.length > 0)
      if (!analysis) continue
      /** @type {{relativePath: string, start: number, end: number}[]} */
      const scenes = []
      for (const asset of analysis.assets) {
        if (
          typeof asset?.relative_path !== 'string' ||
          !Array.isArray(asset?.scenes)
        ) continue
        for (const scene of asset.scenes) {
          if (
            typeof scene?.start !== 'number' ||
            typeof scene?.end !== 'number' ||
            !(scene.end > scene.start)
          ) continue
          scenes.push({
            relativePath: asset.relative_path,
            start: scene.start,
            end: scene.end,
          })
          if (scenes.length >= segmentCount) break
        }
        if (scenes.length >= segmentCount) break
      }
      if (scenes.length >= segmentCount) {
        selected = {
          authorizationId: authorization.id,
          absolutePath: path.resolve(authorization.absolutePath),
          scenes: scenes.slice(0, segmentCount),
        }
        break
      }
    }
    if (!selected) return null
    const videoPaths = []
    /** @type {{role: string, index: number, provenance: 'real' | 'synthetic', generator: string}[]} */
    const mediaTracks = []
    for (let index = 0; index < selected.scenes.length; index += 1) {
      const scene = selected.scenes[index]
      const sourcePath = path.resolve(selected.absolutePath, scene.relativePath)
      if (!isInsideAuthorizedRoot(selected.absolutePath, sourcePath)) {
        throw new Error('JY003_AUTHORIZED_PATH_ESCAPE')
      }
      await access(sourcePath)
      const clipDuration = Math.min(segmentDurationSeconds, Math.max(0.5, scene.end - scene.start))
      const videoPath = path.join(mediaRoot, `video-${index + 1}.mp4`)
      await execFileAsync(ffmpegExecutable, [
        '-hide_banner', '-loglevel', 'error', '-y',
        '-ss', String(scene.start),
        '-i', sourcePath,
        '-t', String(clipDuration),
        '-an',
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',
        videoPath,
      ])
      videoPaths.push(videoPath)
      mediaTracks.push({
        role: 'video',
        index: index + 1,
        provenance: 'real',
        generator: 'authorized_scene_readonly_clip',
      })
    }
    return {
      authorizationId: selected.authorizationId,
      videoPaths,
      mediaTracks,
      realAuthorizedVideo: true,
    }
  } catch {
    return null
  }
}

/**
 * @param {{ffmpegExecutable: string, mediaRoot: string}} input
 */
const createSyntheticVideoClips = async ({ ffmpegExecutable, mediaRoot }) => {
  const colors = ['0x1f6feb', '0x2da44e', '0xbf8700', '0xcf222e']
  const videoPaths = []
  /** @type {{role: string, index: number, provenance: 'real' | 'synthetic', generator: string}[]} */
  const mediaTracks = []
  for (let index = 0; index < colors.length; index += 1) {
    const videoPath = path.join(mediaRoot, `video-${index + 1}.mp4`)
    await execFileAsync(ffmpegExecutable, [
      '-hide_banner', '-loglevel', 'error', '-y',
      '-f', 'lavfi', '-i', `color=c=${colors[index]}:s=540x960:r=30`,
      '-t', String(segmentDurationSeconds), '-pix_fmt', 'yuv420p', videoPath,
    ])
    videoPaths.push(videoPath)
    mediaTracks.push({
      role: 'video',
      index: index + 1,
      provenance: 'synthetic',
      generator: 'ffmpeg_lavfi_color',
    })
  }
  return {
    authorizationId: null,
    videoPaths,
    mediaTracks,
    realAuthorizedVideo: false,
  }
}

/**
 * @param {{ffmpegExecutable: string, mediaRoot: string, count: number}} input
 */
const createSyntheticAudioTracks = async ({ ffmpegExecutable, mediaRoot, count }) => {
  const voiceoverPaths = []
  /** @type {{role: string, index: number, provenance: 'real' | 'synthetic', generator: string}[]} */
  const mediaTracks = []
  for (let index = 0; index < count; index += 1) {
    const voiceoverPath = path.join(mediaRoot, `voiceover-${index + 1}.wav`)
    await execFileAsync(ffmpegExecutable, [
      '-hide_banner', '-loglevel', 'error', '-y',
      '-f', 'lavfi', '-i', `sine=frequency=${440 + index * 110}:sample_rate=48000`,
      '-t', String(segmentDurationSeconds), '-ac', '1', voiceoverPath,
    ])
    voiceoverPaths.push(voiceoverPath)
    mediaTracks.push({
      role: 'voiceover',
      index: index + 1,
      provenance: 'synthetic',
      generator: 'ffmpeg_lavfi_sine',
    })
  }
  const bgmPath = path.join(mediaRoot, 'bgm.wav')
  await execFileAsync(ffmpegExecutable, [
    '-hide_banner', '-loglevel', 'error', '-y',
    '-f', 'lavfi', '-i', 'sine=frequency=220:sample_rate=48000',
    '-t', String(count * segmentDurationSeconds + 1), '-ac', '1', bgmPath,
  ])
  mediaTracks.push({
    role: 'bgm',
    index: 1,
    provenance: 'synthetic',
    generator: 'ffmpeg_lavfi_sine',
  })
  return { voiceoverPaths, bgmPath, mediaTracks }
}

const main = async () => {
if (!runtimeDataRoot || !path.isAbsolute(runtimeDataRoot) ||
    !pythonModuleRoot || !path.isAbsolute(pythonModuleRoot) ||
    !path.isAbsolute(ffmpegExecutable)) {
  throw Object.assign(new Error('JY003_REAL_ACCEPTANCE_CONFIG_INVALID'), {
    code: 'JY003_REAL_ACCEPTANCE_CONFIG_INVALID',
  })
}

const compatibilityManifest = JSON.parse(
  await readFile(path.join(repositoryRoot, 'config', 'jianying-compatibility.json'), 'utf8'),
)
const upstreamManifest = JSON.parse(
  await readFile(path.join(repositoryRoot, 'config', 'pyjianyingdraft-upstream.json'), 'utf8'),
)

const desktop = await detectJianyingDesktop({ compatibilityManifest })
await inspectPyJianyingUpstream({ upstreamRoot: pythonModuleRoot, manifest: upstreamManifest })
const manualOnlyProfiles = new Set([
  'jianying-10-9-provisional',
  'jianying-11-1-provisional',
])
if (
  !manualOnlyProfiles.has(desktop.profileId) ||
  desktop.capabilities.draft_generation !== true ||
  desktop.capabilities.manual_open !== true ||
  desktop.capabilities.desktop_ui_automation !== false ||
  desktop.capabilities.template_read !== false
) {
  throw Object.assign(new Error('JY003_REAL_ACCEPTANCE_PROFILE_INVALID'), {
    code: 'JY003_REAL_ACCEPTANCE_PROFILE_INVALID',
  })
}

const runToken = `${new Date().toISOString().replace(/\D/gu, '').slice(0, 14)}-${randomBytes(3).toString('hex')}`
const projectId = `project-jy003-accept-${runToken}`
const jobId = `jy003-accept-${runToken}`
const draftId = `openvideo-${jobId}`
const runRoot = path.join(runtimeDataRoot, 'jy003-acceptance', runToken)
const mediaRoot = path.join(runRoot, 'media')
const evidenceRoot = path.join(runtimeDataRoot, 'jy003-acceptance-evidence')
await Promise.all([
  mkdir(mediaRoot, { recursive: true }),
  mkdir(evidenceRoot, { recursive: true }),
])
await Promise.all([
  securePrivateRuntimeRoot(runRoot),
  securePrivateRuntimeRoot(evidenceRoot),
])

const segmentDurationUs = segmentDurationSeconds * 1_000_000
const realVideos = await tryResolveAuthorizedVideoClips({
  runtimeDataRoot,
  ffmpegExecutable,
  mediaRoot,
})
const videoBundle = realVideos || await createSyntheticVideoClips({
  ffmpegExecutable,
  mediaRoot,
})
const audioBundle = await createSyntheticAudioTracks({
  ffmpegExecutable,
  mediaRoot,
  count: videoBundle.videoPaths.length,
})
const videoPaths = videoBundle.videoPaths
const voiceoverPaths = audioBundle.voiceoverPaths
const bgmPath = audioBundle.bgmPath
const mediaTracks = [...videoBundle.mediaTracks, ...audioBundle.mediaTracks]
const authorizationId = videoBundle.authorizationId || `synthetic-authorization-${runToken}`
const claims = {
  writer_isolation: true,
  real_authorized_video: videoBundle.realAuthorizedVideo === true,
  synthetic_voiceover: true,
  synthetic_bgm: true,
}

const writer = createPyJianyingDraftWriter({
  draftRoot: desktop.draftRoot,
  pythonExecutable,
  pythonModuleRoot,
  captions: true,
  bgmPath,
})
const runtime = createJianyingDraftRuntime({ writer })
let privateJobId = null
const bridgeRuntime = {
  ...runtime,
  service: {
    ...runtime.service,
    start(request) {
      const started = runtime.service.start(request)
      privateJobId = String(started.job_id)
      return started
    },
  },
}
const createBridge = () => createJianyingWorkbenchBridge({
  runtime: bridgeRuntime,
  desktopProfile: {
    version: desktop.version,
    profileId: desktop.profileId,
    provisional: desktop.provisional,
    capabilities: desktop.capabilities,
  },
  materialAnalysisProvider: {
    async resolvePreviewSources({ selections }) {
      return selections.map((selection, index) => ({
        ...selection,
        sourcePath: videoPaths[index],
      }))
    },
  },
  voiceoverProvider: {
    async resolveVoiceovers({ segments }) {
      return segments.map((segment, index) => ({
        sentenceId: segment.sentence_id,
        audioId: `audio-${index + 1}`,
        path: voiceoverPaths[index],
      }))
    },
    async cleanup() {},
  },
})
const editPlan = {
  schema_version: 1,
  plan_id: `plan-${runToken}`,
  project_id: projectId,
  created_at: new Date().toISOString(),
  items: videoPaths.map((_, index) => ({
    sentence_id: `sentence-${index + 1}`,
    order: index + 1,
    voiceover_text: `OpenVideo JY-003 验收字幕 ${index + 1}`,
    status: 'selected',
    selected_candidate_id: `candidate-${index + 1}`,
    candidates: [{
      candidate_id: `candidate-${index + 1}`,
      asset_id: `asset-${index + 1}`,
      scene_id: `scene-${index + 1}`,
      source: 'material_analysis',
      start: 0,
      end: segmentDurationUs / 1_000_000,
      summary: `验收镜头 ${index + 1}`,
      tags: [],
      search_score: 1,
      director_score: 1,
      reason: claims.real_authorized_video
        ? 'JY-003 授权真材片段验收'
        : 'JY-003 隔离验收（合成视频）',
    }],
  })),
}
const selectionRequest = {
  schema_version: 1,
  kind: 'template_selection_request',
  project_id: projectId,
  content_goal: 'product_showcase',
  orientation: 'portrait',
  pacing: 'balanced',
  target_duration_seconds: videoPaths.length * segmentDurationUs / 1_000_000,
  voiceover_required: true,
  captions_required: true,
}
const fixedDraftRequest = createTemplateDraftRequest(
  selectionRequest,
  selectFixedTemplate(selectionRequest),
)
const adapterRequest = createReferenceTemplateAdapterRequest(
  selectionRequest,
  fixedDraftRequest,
  {
    schema_version: 1,
    kind: 'reference_video_descriptor',
    reference_id: `reference-${runToken}`,
    duration_ms: videoPaths.length * segmentDurationUs / 1_000,
    orientation: 'portrait',
    source_kind: 'external_reference',
    access_mode: 'external_read_only',
    privacy: 'sanitized_metadata_only',
  },
)
const analysis = {
  schema_version: 1,
  kind: 'reference_template_analysis',
  request_id: adapterRequest.request_id,
  reference_id: adapterRequest.reference.reference_id,
  duration_ms: videoPaths.length * segmentDurationUs / 1_000,
  orientation: 'portrait',
  shots: videoPaths.map((_, index) => ({
    shot_id: `shot-${index + 1}`,
    order: index + 1,
    start_ms: index * segmentDurationUs / 1_000,
    end_ms: (index + 1) * segmentDurationUs / 1_000,
    role: ['hook', 'detail', 'proof', 'cta'][index],
    transition_out: index === videoPaths.length - 1 ? 'none' : 'cut',
  })),
  caption_cadence: { mode: 'steady', max_chars_per_card: 30, cards_per_minute: 20 },
  audio_emphasis: [],
  evidence_codes: ['shot_timing', 'visual_role', 'transition_pattern', 'caption_cadence', 'audio_emphasis'],
}
const templateDraft = createReferenceTemplateDraft(selectionRequest, adapterRequest, analysis)
const templatePreflight = preflightReferenceTemplateDraft(
  selectionRequest,
  adapterRequest,
  analysis,
  templateDraft,
)
const decision = createReferenceTemplateReviewDecision(
  selectionRequest,
  adapterRequest,
  analysis,
  templateDraft,
  templatePreflight,
  {
    schema_version: 1,
    kind: 'reference_template_review_command',
    decision: 'approve',
    reason_codes: ['structure_verified'],
    revision: null,
  },
)
const approvedTemplate = {
  referenceTemplateId: `template-${runToken}`,
  projectId,
  publication: 'committed',
  revision: 1,
  status: 'approved',
  analysis,
  draft: templateDraft,
  decision,
}

let bridge = null
let bridgeResult = null
const evidencePath = path.join(evidenceRoot, `${runToken}.json`)
try {
  bridge = createBridge()
  bridgeResult = await bridge.exportDraft({
    projectId,
    jobId,
    authorizationId,
    editPlan,
    approvedTemplate,
    signal: new AbortController().signal,
    checkpoint: async () => {},
  })
  const isolationEvidence = writer.getIsolationEvidence({ job_id: privateJobId })
  if (
    !isolationEvidence ||
    isolationEvidence.before_fingerprint !== isolationEvidence.after_existing_fingerprint
  ) {
    throw Object.assign(new Error('JY003_REAL_ACCEPTANCE_ISOLATION_FAILED'), {
      code: 'JY003_REAL_ACCEPTANCE_ISOLATION_FAILED',
    })
  }
  const evidence = {
    schema_version: 1,
    kind: 'jy003_acceptance_evidence',
    generated_at: new Date().toISOString(),
    draft_label: draftId,
    desktop_version: desktop.version,
    profile_id: desktop.profileId,
    provisional: desktop.provisional,
    handoff_mode: 'manual_open_required',
    desktop_opened: false,
    output_fingerprint: bridgeResult.outputFingerprint,
    isolation: isolationEvidence,
    claims,
    media_tracks: mediaTracks,
    authorization_mode: claims.real_authorized_video ? 'authorized_record' : 'synthetic_placeholder',
    media_policy: 'private_acceptance_assets_preserved_until_manual_reopen_confirmation',
  }
  await writeFile(
    evidencePath,
    `${JSON.stringify(evidence, null, 2)}\n`,
    { flag: 'wx' },
  )
  if (await bridge.commitDraft({ jobId }) !== true) {
    throw Object.assign(new Error('JY003_REAL_ACCEPTANCE_COMMIT_FAILED'), {
      code: 'JY003_REAL_ACCEPTANCE_COMMIT_FAILED',
    })
  }
  process.stdout.write(`${JSON.stringify({ ok: true, ...evidence })}\n`)
} catch (error) {
  await bridge?.cleanupDraft({ projectId, jobId }).catch(() => {})
  await rm(evidencePath, { force: true }).catch(() => {})
  await rm(runRoot, { recursive: true, force: true }).catch(() => {})
  throw error
}
}

main().catch((error) => {
  const code = error && typeof error === 'object' && 'code' in error
    ? String(error.code)
    : 'JY003_REAL_ACCEPTANCE_FAILED'
  process.stderr.write(`${JSON.stringify({ ok: false, code })}\n`)
  process.exitCode = 1
})
