#!/usr/bin/env node
/**
 * GOV-005 / STATUS.json structural sanity check.
 *
 * Reads docs/tasks/STATUS.json and asserts:
 *   - file is valid JSON
 *   - file is a JSON object at the top level
 *   - file has a non-empty `tasks` array
 *   - all expected metadata fields are present
 *   - the file ends with `}` (i.e. is not truncated mid-structure)
 *
 * Exits 0 on success, 1 on failure with a clear diagnostic.
 *
 * This is a small reusable check that downstream maintainers can run after
 * editing STATUS.json to avoid silently re-introducing the bug fixed in
 * GOV-005 (the file was an object that ended with `]` since commit
 * 1f830f07, which made it invalid JSON).
 */
'use strict';

// STATUS.json is always at <repo-root>/docs/tasks/STATUS.json. Resolve it
// relative to this script's location using path.relative so the script works
// whether it lives at <root>/scripts or at <root>/.worktrees/<name>/scripts.
const fs = require('fs');
const path = require('path');

function resolveStatusJson() {
  // Walk up from this script until we find a sibling docs/tasks/STATUS.json.
  let dir = __dirname;
  for (let i = 0; i < 8; i++) {
    const candidate = path.join(dir, 'docs', 'tasks', 'STATUS.json');
    if (fs.existsSync(candidate)) return candidate;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  throw new Error(`could not locate docs/tasks/STATUS.json from ${__dirname}`);
}

const FILE = resolveStatusJson();
const EXPECTED_METADATA = [
  'schema_version',
  'project',
  'current_task',
  'current_status',
  'last_pushed_commit',
  'execution_mode',
  'remote_repository',
  'default_branch',
  'tasks',
];

function fail(msg) {
  console.error('STATUS.json check FAILED:', msg);
  process.exit(1);
}

function main() {
  if (!fs.existsSync(FILE)) fail(`file not found: ${FILE}`);

  const buf = fs.readFileSync(FILE);
  let enc = 'utf8';
  if (buf[0] === 0xff && buf[1] === 0xfe) enc = 'utf16le';
  const raw = buf.toString(enc).replace(/^\uFEFF/, '');

  // 1. Must be valid JSON.
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    fail(`JSON parse error: ${e.message}`);
  }

  // 2. Top-level must be an object, not an array.
  if (Array.isArray(parsed) || typeof parsed !== 'object' || parsed === null) {
    fail(`top level must be an object, got ${Array.isArray(parsed) ? 'array' : typeof parsed}`);
  }

  // 3. Must end with `}`.
  const trimmed = raw.replace(/\s+$/, '');
  if (!trimmed.endsWith('}')) {
    fail(`file must end with "}", got final chars: ${JSON.stringify(trimmed.slice(-5))}`);
  }

  // 4. Must have non-empty tasks array.
  if (!Array.isArray(parsed.tasks) || parsed.tasks.length === 0) {
    fail(`"tasks" must be a non-empty array, got ${typeof parsed.tasks}`);
  }

  // 5. Metadata fields present.
  const missing = EXPECTED_METADATA.filter((k) => !(k in parsed));
  if (missing.length > 0) {
    fail(`missing metadata fields: ${missing.join(', ')}`);
  }

  // 6. Every task entry should have at least an id field.
  const tasksMissingId = parsed.tasks
    .map((t, i) => ({ t, i }))
    .filter(({ t }) => !t || typeof t !== 'object' || !t.id)
    .map(({ i }) => i);
  if (tasksMissingId.length > 0) {
    fail(`${tasksMissingId.length} task entries are missing an "id" (indices: ${tasksMissingId.slice(0, 5).join(',')}${tasksMissingId.length > 5 ? '...' : ''})`);
  }

  // 7. Sanity: task count and top-level key count.
  const topKeys = Object.keys(parsed);
  console.log(
    `STATUS.json OK: top-level keys=${topKeys.length}, tasks=${parsed.tasks.length}, encoding=${enc}`,
  );
}

main();
