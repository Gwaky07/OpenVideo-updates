import { spawn } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { mkdir, readFile, readdir, rm, rmdir, stat } from 'node:fs/promises'
import { isAbsolute, resolve } from 'node:path'

import { runShortVideoFactoryElectronBridge } from '../apps/gateway/src/short-video-factory-electron-bridge.mjs'

const dataRoot = process.argv[2]
const upstreamRoot = process.argv[3]
const timeoutMs = Number(process.argv[4] ?? 90_000)
const ttsEnabled = process.argv[5] === 'tts'
const voice = process.argv[6] ?? 'zh-CN-XiaoxiaoNeural'
if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('DIAGNOSTIC_DATA_ROOT_INVALID')
if (!upstreamRoot || !isAbsolute(upstreamRoot)) throw new Error('DIAGNOSTIC_UPSTREAM_ROOT_INVALID')
if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1_000 || timeoutMs > 120_000) {
  throw new Error('DIAGNOSTIC_TIMEOUT_INVALID')
}

const startedAt = Date.now()
const emit = (event, details = {}) => {
  process.stdout.write(`${JSON.stringify({
    event,
    elapsed_ms: Date.now() - startedAt,
    ...details,
  })}\n`)
}
const classifyOutput = (value) => {
  const message = String(value)
  const known = [
    ['App threw an error during load', 'electron_app_load_error'],
    ["Failed to get 'userData' path", 'electron_user_data_unavailable'],
    ['Connected to the database.', 'database_connected'],
    ['Database initialized.', 'database_initialized'],
    ['Input contains (near) NaN/+-Inf', 'ffmpeg_audio_nan'],
    ['Error submitting audio frame to the encoder', 'ffmpeg_audio_encode_failed'],
    ["Error occurred in handler for 'render-video'", 'render_ipc_failed'],
  ].filter(([needle]) => message.includes(needle)).map(([, classification]) => classification)
  return {
    classifications: known,
    output_bytes: Buffer.byteLength(message),
    output_sha256: createHash('sha256').update(message).digest('hex'),
  }
}
const authorizations = JSON.parse(
  await readFile(resolve(dataRoot, 'authorizations.json'), 'utf8'),
)
const authorization = authorizations.records
  .filter((record) => record.status === 'authorized' && record.readOnly === true)
  .sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))[0]
if (!authorization) throw new Error('DIAGNOSTIC_AUTHORIZATION_NOT_FOUND')
const index = JSON.parse(
  await readFile(resolve(dataRoot, 'material-analysis/analysis-index.json'), 'utf8'),
)
const record = index.records.find((candidate) =>
  candidate.authorization_id === authorization.id &&
  candidate.project_id === authorization.projectId)
const asset = record?.assets?.find((candidate) =>
  typeof candidate.source_path === 'string' &&
  candidate.duration_seconds >= 1)
if (!asset) throw new Error('DIAGNOSTIC_ASSET_NOT_FOUND')

const diagnosticRoot = resolve(dataRoot, 'qa003-diagnostics')
const runRoot = resolve(diagnosticRoot, randomUUID())
const outputPath = resolve(runRoot, 'preview.mp4')
const voicePath = resolve(runRoot, ttsEnabled ? 'voice.mp3' : 'silence.wav')
const subtitlePath = resolve(runRoot, ttsEnabled ? 'voice.srt' : 'captions.srt')
await mkdir(runRoot, { recursive: true, mode: 0o700 })
let lastProgress = null
const sampler = setInterval(async () => {
  const output = await stat(outputPath).catch(() => null)
  const voiceOutput = await stat(voicePath).catch(() => null)
  const subtitleOutput = await stat(subtitlePath).catch(() => null)
  const entries = await readdir(runRoot).catch(() => [])
  emit('sample', {
    output_exists: Boolean(output?.isFile()),
    output_bytes: output?.isFile() ? output.size : 0,
    work_entry_count: entries.length,
    last_progress: lastProgress,
    voice_exists: Boolean(voiceOutput?.isFile()),
    voice_bytes: voiceOutput?.isFile() ? voiceOutput.size : 0,
    subtitle_exists: Boolean(subtitleOutput?.isFile()),
    subtitle_bytes: subtitleOutput?.isFile() ? subtitleOutput.size : 0,
  })
}, 5_000)
sampler.unref()

try {
  emit('bridge_invoked', {
    tts_enabled: ttsEnabled,
    clip_count: 1,
    output_duration_seconds: ttsEnabled ? 3 : 1,
    output_width: 320,
    output_height: 568,
    timeout_ms: timeoutMs,
  })
  await runShortVideoFactoryElectronBridge({
    request: {
      projectId: 'qa003-diagnostic-project',
      jobId: 'qa003-diagnostic-job',
      outputDurationSeconds: ttsEnabled ? 3 : 1,
      outputSize: { width: 320, height: 568 },
      script: '诊断。',
      voiceover: { enabled: ttsEnabled, voice: ttsEnabled ? voice : null, rate: 0 },
      captions: { enabled: true },
      bgmPath: null,
      clips: [{
        candidateId: 'qa003-diagnostic-scene',
        sourcePath: asset.source_path,
        start: 0,
        end: 1,
      }],
    },
    upstreamRoot,
    workRoot: runRoot,
    outputPath,
    timeoutMs,
    onStarted: () => emit('electron_spawned'),
    onProgress: (progress) => {
      lastProgress = progress
      emit('render_progress', { progress })
    },
    spawnProcess: (executable, args, options) => {
      const child = spawn(executable, args, {
        ...options,
        stdio: ['ignore', 'pipe', 'pipe'],
      })
      for (const [stream, output] of [
        ['stdout', child.stdout],
        ['stderr', child.stderr],
      ]) {
        output?.on('data', (value) => {
          const diagnostic = classifyOutput(value)
          if (diagnostic.output_bytes > 0) {
            emit('electron_output', {
              stream,
              ...diagnostic,
            })
          }
        })
      }
      return child
    },
  })
  const output = await stat(outputPath)
  emit('bridge_succeeded', { output_bytes: output.size })
} catch (error) {
  const output = await stat(outputPath).catch(() => null)
  emit('bridge_failed', {
    code: error && typeof error === 'object' && 'code' in error
      ? String(error.code)
      : 'DIAGNOSTIC_UNKNOWN_FAILURE',
    output_exists: Boolean(output?.isFile()),
    output_bytes: output?.isFile() ? output.size : 0,
  })
  process.exitCode = 1
} finally {
  clearInterval(sampler)
  await rm(runRoot, { recursive: true, force: true })
  await rmdir(diagnosticRoot).catch(() => {})
  emit('cleanup_completed')
}
