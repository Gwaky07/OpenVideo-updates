import { createHash, randomUUID } from 'node:crypto'
import { execFile } from 'node:child_process'
import {
  createReadStream,
  lstatSync,
} from 'node:fs'
import {
  mkdir,
  mkdtemp,
  opendir,
  readFile,
  readdir,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { tmpdir } from 'node:os'
import {
  basename,
  isAbsolute,
  join,
  relative,
  resolve,
} from 'node:path'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { loadGatewayConfig } from '../apps/gateway/src/config.mjs'
import { createGateway } from '../apps/gateway/src/gateway.mjs'
import { createPermissiveMaterialAnalyzer } from '../apps/gateway/src/permissive-material-analyzer.mjs'
import { createReferenceTemplateAdapter } from '../apps/gateway/src/reference-template-adapter.mjs'
import { createReferenceTemplateRepository } from '../apps/gateway/src/reference-template-repository.mjs'
import { listFixedTemplates } from '../apps/gateway/src/template-library.mjs'

const execFileAsync = promisify(execFile)
const sampleLimit = 3
const stableCodePattern = /^[A-Z][A-Z0-9_]{2,159}$/u
const snapshotPrivateNames = new WeakMap()

class AcceptanceError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'AcceptanceError'
    this.code = code
  }
}

/** @param {unknown} value */
const sha256 = (value) =>
  createHash('sha256').update(
    typeof value === 'string' ? value : JSON.stringify(value),
  ).digest('hex')

/** @param {string} filePath */
const hashFile = async (filePath) => {
  const hash = createHash('sha256')
  await new Promise((resolveHash, rejectHash) => {
    const stream = createReadStream(filePath)
    stream.on('data', (chunk) => hash.update(chunk))
    stream.once('error', rejectHash)
    stream.once('end', resolveHash)
  })
  return hash.digest('hex')
}

/** @param {string} root */
const assertNoWindowsReparsePoints = async (root) => {
  if (process.platform !== 'win32') return
  try {
    const command = [
      '$ErrorActionPreference = "Stop"',
      '$root = $env:OPENVIDEO_TPL003_SOURCE_ROOT',
      '$items = @((Get-Item -LiteralPath $root -Force)) + @(Get-ChildItem -LiteralPath $root -Force -Recurse)',
      '$count = @($items | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count',
      '[Console]::Out.Write($count)',
    ].join('; ')
    const { stdout } = await execFileAsync(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', command],
      {
        encoding: 'utf8',
        windowsHide: true,
        maxBuffer: 1_024,
        env: {
          ...process.env,
          OPENVIDEO_TPL003_SOURCE_ROOT: root,
        },
      },
    )
    if (stdout.trim() !== '0') throw new AcceptanceError('TPL003_SOURCE_REPARSE_RISK')
  } catch (error) {
    if (error instanceof AcceptanceError) throw error
    throw new AcceptanceError('TPL003_SOURCE_REPARSE_CHECK_FAILED')
  }
}

/**
 * @param {string} sourceRoot
 * @returns {Promise<{
 *   fileCount: number,
 *   totalBytes: number,
 *   permanentSceneFileCount: number,
 *   fingerprint: string,
 *   records: {nameHash: string, size: string, mtimeNs: string}[],
 *   sampleHashes: {nameHash: string, sha256: string}[],
 * }>}
 */
export const snapshotSourceDirectory = async (sourceRoot) => {
  if (!isAbsolute(sourceRoot)) throw new AcceptanceError('TPL003_SOURCE_ROOT_INVALID')
  const rootStats = lstatSync(sourceRoot, { bigint: true })
  if (!rootStats.isDirectory() || rootStats.isSymbolicLink()) {
    throw new AcceptanceError('TPL003_SOURCE_ROOT_UNSAFE')
  }
  await assertNoWindowsReparsePoints(sourceRoot)
  const records = []
  const privateNames = []
  let totalBytes = 0
  let permanentSceneFileCount = 0

  /** @param {string} directory */
  const visit = async (directory) => {
    const iterator = await opendir(directory)
    for await (const entry of iterator) {
      const absolutePath = join(directory, entry.name)
      if (entry.isSymbolicLink()) {
        throw new AcceptanceError('TPL003_SOURCE_LINK_RISK')
      }
      if (entry.isDirectory()) {
        await visit(absolutePath)
        continue
      }
      if (!entry.isFile()) throw new AcceptanceError('TPL003_SOURCE_SPECIAL_FILE_RISK')
      const fileStats = await stat(absolutePath, { bigint: true })
      if (!fileStats.isFile() || fileStats.nlink !== 1n) {
        throw new AcceptanceError('TPL003_SOURCE_HARDLINK_RISK')
      }
      const relativePath = relative(sourceRoot, absolutePath).replaceAll('\\', '/')
      if (
        relativePath.length === 0 ||
        relativePath.startsWith('../') ||
        isAbsolute(relativePath)
      ) throw new AcceptanceError('TPL003_SOURCE_BOUNDARY_VIOLATION')
      const numericSize = Number(fileStats.size)
      if (!Number.isSafeInteger(numericSize)) {
        throw new AcceptanceError('TPL003_SOURCE_SIZE_UNSUPPORTED')
      }
      totalBytes += numericSize
      if (!Number.isSafeInteger(totalBytes)) {
        throw new AcceptanceError('TPL003_SOURCE_SIZE_UNSUPPORTED')
      }
      if (/^Scene-.*\.mp4$/iu.test(basename(absolutePath))) permanentSceneFileCount += 1
      privateNames.push(relativePath, basename(absolutePath))
      records.push({
        nameHash: sha256(relativePath),
        size: fileStats.size.toString(),
        mtimeNs: fileStats.mtimeNs.toString(),
        sourcePath: absolutePath,
      })
    }
  }
  await visit(sourceRoot)
  records.sort((left, right) => left.nameHash.localeCompare(right.nameHash))
  const samples = [...records]
    .sort((left, right) =>
      Number(BigInt(left.size) - BigInt(right.size)) ||
      left.nameHash.localeCompare(right.nameHash))
    .slice(0, sampleLimit)
  const sampleHashes = []
  for (const sample of samples) {
    const digest = await hashFile(sample.sourcePath)
    const afterHash = await stat(sample.sourcePath, { bigint: true })
    if (
      afterHash.size.toString() !== sample.size ||
      afterHash.mtimeNs.toString() !== sample.mtimeNs
    ) throw new AcceptanceError('TPL003_SOURCE_CHANGED_DURING_SNAPSHOT')
    sampleHashes.push({ nameHash: sample.nameHash, sha256: digest })
  }
  const safeRecords = records.map(({ nameHash, size, mtimeNs }) => ({
    nameHash,
    size,
    mtimeNs,
  }))
  const snapshot = {
    fileCount: records.length,
    totalBytes,
    permanentSceneFileCount,
    fingerprint: sha256({ records: safeRecords, sampleHashes }),
    records: safeRecords,
    sampleHashes,
  }
  snapshotPrivateNames.set(snapshot, privateNames)
  return snapshot
}

/** @param {Awaited<ReturnType<typeof snapshotSourceDirectory>>} left @param {Awaited<ReturnType<typeof snapshotSourceDirectory>>} right */
export const sourceSnapshotsEqual = (left, right) =>
  left.fileCount === right.fileCount &&
  left.totalBytes === right.totalBytes &&
  left.permanentSceneFileCount === right.permanentSceneFileCount &&
  left.fingerprint === right.fingerprint

/** @param {unknown} payload @param {{sourceRoot: string, authorizationId: string, transcript: string, providerKey?: string, fileNames?: string[]}} privateValues */
export const assertPublicPayloadSafe = (payload, privateValues) => {
  const serialized = JSON.stringify(payload)
  const lower = serialized.toLowerCase()
  for (const forbidden of [
    'source_path',
    'sourcepath',
    'absolutepath',
    'authorizationid',
    'transcript',
    'provider',
    'api_key',
    'apikey',
    '"token"',
    'file://',
  ]) {
    if (lower.includes(forbidden)) throw new AcceptanceError('TPL003_PUBLIC_PAYLOAD_LEAK')
  }
  const privateStrings = [
    privateValues.sourceRoot,
    privateValues.sourceRoot.replaceAll('\\', '/'),
    privateValues.authorizationId,
    privateValues.transcript,
    privateValues.providerKey ?? '',
    ...(privateValues.fileNames ?? []),
  ].filter((value) => value.length > 0)
  const visit = (value) => {
    if (typeof value === 'string') {
      if (
        privateStrings.some((entry) => value.includes(entry)) ||
        /^[A-Za-z]:[\\/]/u.test(value) ||
        /^\\\\/u.test(value) ||
        /^\//u.test(value)
      ) throw new AcceptanceError('TPL003_PUBLIC_PAYLOAD_LEAK')
      return
    }
    if (Array.isArray(value)) {
      value.forEach(visit)
      return
    }
    if (value && typeof value === 'object') {
      Object.values(value).forEach(visit)
    }
  }
  visit(payload)
}

/** @param {Record<string, any>} inspected */
const createSelectionRequest = (projectId, inspected) => {
  const template = listFixedTemplates().find((entry) =>
    entry.template_id === 'step-by-step' &&
    entry.supported_orientations.includes(inspected.orientation) &&
    inspected.scenes.length >= entry.slot_count.min)
  if (!template) throw new AcceptanceError('TPL003_TEMPLATE_COMPATIBILITY_MISSING')
  const durationSeconds = Math.max(
    template.duration_seconds.min,
    Math.min(template.duration_seconds.max, Math.round(inspected.durationMs / 1_000)),
  )
  return {
    schema_version: 1,
    kind: 'template_selection_request',
    project_id: projectId,
    content_goal: 'tutorial',
    orientation: inspected.orientation,
    pacing: 'calm',
    target_duration_seconds: durationSeconds,
    voiceover_required: false,
    captions_required: true,
  }
}

/** @param {string} dataRoot */
const createPrivateGateway = async (dataRoot) => {
  let privateProvider
  try {
    privateProvider = JSON.parse(
      await readFile(resolve(dataRoot, 'gateway/provider.json'), 'utf8'),
    )
  } catch {
    throw new AcceptanceError('TPL003_GATEWAY_CONFIG_MISSING')
  }
  if (
    privateProvider?.schema_version !== 1 ||
    privateProvider?.provider !== 'openai-compatible' ||
    typeof privateProvider.base_url !== 'string' ||
    typeof privateProvider.api_key !== 'string' ||
    typeof privateProvider.text_model !== 'string' ||
    typeof privateProvider.vision_model !== 'string' ||
    typeof privateProvider.json_model !== 'string'
  ) throw new AcceptanceError('TPL003_GATEWAY_CONFIG_INVALID')
  process.env.OPENVIDEO_LLM_PROVIDER = privateProvider.provider
  process.env.OPENVIDEO_LLM_BASE_URL = privateProvider.base_url
  process.env.OPENVIDEO_LLM_API_KEY = privateProvider.api_key
  process.env.OPENVIDEO_LLM_TEXT_MODEL = privateProvider.text_model
  process.env.OPENVIDEO_LLM_VISION_MODEL = privateProvider.vision_model
  process.env.OPENVIDEO_LLM_JSON_MODEL = privateProvider.json_model
  try {
    return {
      gateway: createGateway({
        config: loadGatewayConfig(),
        logger: () => {},
      }),
      providerKey: privateProvider.api_key,
    }
  } catch {
    throw new AcceptanceError('TPL003_GATEWAY_CONFIG_INVALID')
  }
}

/** @param {string} referenceRoot */
export const createExplicitAuthorization = (referenceRoot) => {
  if (!isAbsolute(referenceRoot)) {
    throw new AcceptanceError('TPL003_REFERENCE_ROOT_INVALID')
  }
  const absolutePath = resolve(referenceRoot)
  const authorizationSuffix = randomUUID()
  const projectSuffix = randomUUID()
  return {
    id: `tpl003-authorization-${authorizationSuffix}`,
    projectId: `tpl003-project-${projectSuffix}`,
    status: 'authorized',
    readOnly: true,
    absolutePath,
    label: `reference-${authorizationSuffix.slice(0, 8)}`,
    total: 0,
    createdAt: '2026-01-01T00:00:00.000Z',
  }
}

/** @param {string} dataRoot @param {string} referenceRoot */
const runAcceptance = async (dataRoot, referenceRoot) => {
  if (!isAbsolute(dataRoot)) throw new AcceptanceError('TPL003_RUNTIME_ROOT_INVALID')
  if (typeof referenceRoot !== 'string' || referenceRoot.trim().length === 0) {
    throw new AcceptanceError('TPL003_REFERENCE_ROOT_REQUIRED')
  }
  const authorization = createExplicitAuthorization(referenceRoot)
  const authorizationRepository = {
    get(id) {
      return id === authorization.id ? structuredClone(authorization) : null
    },
  }
  const privateGateway = await createPrivateGateway(dataRoot)
  const gateway = privateGateway.gateway
  const providerKey = privateGateway.providerKey
  const sourceRoot = resolve(authorization.absolutePath)
  const before = await snapshotSourceDirectory(sourceRoot)
  if (before.fileCount === 0) throw new AcceptanceError('TPL003_SOURCE_EMPTY')
  if (before.permanentSceneFileCount !== 0) {
    throw new AcceptanceError('TPL003_PERMANENT_SCENE_FILES_PRESENT')
  }
  const temporaryRoot = resolve(dataRoot, 'material-analysis/tmp')
  const temporaryBefore = new Set(await readdir(temporaryRoot).catch((error) => {
    if (error?.code === 'ENOENT') return []
    throw error
  }))
  const acceptanceRepositoryRoot = await mkdtemp(join(tmpdir(), 'openvideo-tpl003-acceptance-'))
  let result
  let pipelineError
  let persistIndexCallCount = 0
  try {
    const analyzer = await createPermissiveMaterialAnalyzer({
      dataRoot,
      authorizationRepository,
      gateway,
      adapters: {
        async persistIndex() {
          persistIndexCallCount += 1
        },
      },
    })
    const status = analyzer.getStatus()
    if (!status.available) throw new AcceptanceError('TPL003_ANALYZER_UNAVAILABLE')
    let materials
    try {
      materials = await analyzer.analyzeMaterials({
        projectId: authorization.projectId,
        authorizationId: authorization.id,
      })
    } catch (error) {
      if (error?.code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') {
        throw new AcceptanceError('TPL003_ANALYSIS_RESCAN_REQUIRED')
      }
      throw new AcceptanceError('TPL003_FRESH_ANALYSIS_FAILED')
    }
    if (persistIndexCallCount !== 1) {
      throw new AcceptanceError('TPL003_PERSIST_INDEX_CALL_COUNT_INVALID')
    }
    const candidates = materials.assets
      .filter((asset) => asset.status === 'ready' && asset.sceneCount >= 4)
      .sort((left, right) => left.id.localeCompare(right.id))
    if (candidates.length === 0) throw new AcceptanceError('TPL003_ASSET_NOT_SUITABLE')

    let selected = null
    for (const asset of candidates) {
      try {
        const inspected = await analyzer.inspectReferenceAsset({
          projectId: authorization.projectId,
          authorizationId: authorization.id,
          assetId: asset.id,
        })
        const selectionRequest = createSelectionRequest(authorization.projectId, inspected)
        selected = { asset, inspected, selectionRequest }
        break
      } catch (error) {
        if (error?.code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') {
          throw new AcceptanceError('TPL003_ANALYSIS_RESCAN_REQUIRED')
        }
        // Continue only across already indexed opaque candidates; overall selection still fails closed.
      }
    }
    if (!selected) throw new AcceptanceError('TPL003_ASSET_NOT_SUITABLE')

    const adapter = createReferenceTemplateAdapter({ materialAnalysisProvider: analyzer })
    const generated = await adapter.generate({
      projectId: authorization.projectId,
      authorizationId: authorization.id,
      assetId: selected.asset.id,
      templateSelectionRequest: selected.selectionRequest,
    })
    const repository = await createReferenceTemplateRepository({
      dataRoot: acceptanceRepositoryRoot,
      securePrivateRoot: async () => {},
    })
    const owner = {
      projectId: authorization.projectId,
      jobId: `tpl003-acceptance-job-${randomUUID()}`,
      attemptId: `tpl003-acceptance-attempt-${randomUUID()}`,
      generation: 1,
      inputFingerprint: sha256({
        assetId: selected.asset.id,
        selectionRequest: selected.selectionRequest,
      }),
    }
    const staged = await repository.stageGenerated({ ...owner, generated })
    if (staged.publication !== 'staged' || (await repository.list(owner.projectId)).length !== 0) {
      throw new AcceptanceError('TPL003_STAGED_FENCE_INVALID')
    }
    const prepared = await repository.commit({
      ...owner,
      referenceTemplateId: staged.referenceTemplateId,
    })
    if (prepared.publication !== 'prepared' || (await repository.list(owner.projectId)).length !== 0) {
      throw new AcceptanceError('TPL003_PREPARED_FENCE_INVALID')
    }
    const committed = await repository.publish({
      ...owner,
      referenceTemplateId: staged.referenceTemplateId,
    })
    const reviewed = await repository.review({
      projectId: owner.projectId,
      referenceTemplateId: staged.referenceTemplateId,
      expectedRevision: committed.revision,
      command: {
        schema_version: 1,
        kind: 'reference_template_review_command',
        decision: 'approve',
        reason_codes: ['structure_verified'],
        revision: null,
      },
    })
    const publicDetail = await repository.get(owner.projectId, staged.referenceTemplateId)
    const approved = await repository.getApproved(owner.projectId)
    if (
      reviewed.status !== 'approved' ||
      reviewed.decision?.decision !== 'approved' ||
      reviewed.decision?.confirmed_template?.confirmation !== 'approved' ||
      publicDetail?.referenceTemplateId !== staged.referenceTemplateId ||
      approved?.referenceTemplateId !== staged.referenceTemplateId
    ) throw new AcceptanceError('TPL003_APPROVAL_INVALID')
    assertPublicPayloadSafe(
      { generated, committed, reviewed, publicDetail, approved },
      {
        sourceRoot,
        authorizationId: authorization.id,
        transcript: selected.inspected.transcript,
        providerKey,
        fileNames: snapshotPrivateNames.get(before) ?? [],
      },
    )
    result = {
      asset: selected.asset,
      reviewed,
      publicDetail,
    }
  } catch (error) {
    pipelineError = error
  } finally {
    await rm(acceptanceRepositoryRoot, { recursive: true, force: true }).catch(() => {})
  }

  const after = await snapshotSourceDirectory(sourceRoot)
  const temporaryAfter = await readdir(temporaryRoot).catch((error) => {
    if (error?.code === 'ENOENT') return []
    throw error
  })
  const newTemporaryEntries = temporaryAfter.filter((entry) => !temporaryBefore.has(entry))
  if (!sourceSnapshotsEqual(before, after)) {
    throw new AcceptanceError('TPL003_SOURCE_MODIFIED')
  }
  if (after.permanentSceneFileCount !== 0) {
    throw new AcceptanceError('TPL003_PERMANENT_SCENE_FILES_CREATED')
  }
  if (newTemporaryEntries.length !== 0) {
    throw new AcceptanceError('TPL003_TEMPORARY_FILES_REMAIN')
  }
  if (pipelineError) throw pipelineError
  if (!result) throw new AcceptanceError('TPL003_REAL_ACCEPTANCE_FAILED')

  const summary = {
    schema_version: 1,
    completed_at: new Date().toISOString(),
    asset_opaque_hash: sha256(result.asset.id).slice(0, 12),
    source_file_count: before.fileCount,
    source_total_bytes: before.totalBytes,
    source_fingerprint_equal: true,
    sample_hash_count: before.sampleHashes.length,
    permanent_scene_file_count: after.permanentSceneFileCount,
    new_temporary_entry_count: newTemporaryEntries.length,
    reference_template_id: result.publicDetail.referenceTemplateId,
    confirmed_template_id: result.reviewed.decision.confirmed_template.confirmed_template_id,
    slot_count: result.reviewed.decision.confirmed_template.slots.length,
    status: result.reviewed.status,
    analysis_mode: 'explicit_fresh_analysis',
    persist_index_call_count: persistIndexCallCount,
  }
  const evidenceRoot = resolve(dataRoot, 'evidence/tpl-003')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await writeFile(
    resolve(evidenceRoot, 'acceptance.json'),
    `${JSON.stringify({
      ...summary,
      source_snapshot: {
        file_count: before.fileCount,
        total_bytes: before.totalBytes,
        fingerprint: before.fingerprint,
        records: before.records,
        sample_hashes: before.sampleHashes,
      },
    }, null, 2)}\n`,
    { encoding: 'utf8', mode: 0o600 },
  )
  return summary
}

/**
 * @param {string[]} argv
 * @param {NodeJS.ProcessEnv} environment
 */
export const parseAcceptanceArguments = (argv, environment) => {
  let index = 0
  let dataRoot = environment.OPENVIDEO_RUNTIME_DATA_ROOT
  let referenceRoot = environment.OPENVIDEO_TPL003_REFERENCE_ROOT
  if (argv[0] && !argv[0].startsWith('--')) {
    dataRoot = argv[0]
    index = 1
  }
  while (index < argv.length) {
    const name = argv[index]
    const value = argv[index + 1]
    if (
      name !== '--reference-root' ||
      typeof value !== 'string' ||
      value.length === 0 ||
      value.startsWith('--')
    ) throw new AcceptanceError('TPL003_ARGUMENTS_INVALID')
    referenceRoot = value
    index += 2
  }
  if (typeof dataRoot !== 'string' || dataRoot.length === 0) {
    throw new AcceptanceError('TPL003_RUNTIME_ROOT_INVALID')
  }
  if (typeof referenceRoot !== 'string' || referenceRoot.trim().length === 0) {
    throw new AcceptanceError('TPL003_REFERENCE_ROOT_REQUIRED')
  }
  return { dataRoot, referenceRoot }
}

const main = async () => {
  const parsed = parseAcceptanceArguments(
    process.argv.slice(2),
    process.env,
  )
  const originalStdoutWrite = process.stdout.write
  const originalStderrWrite = process.stderr.write
  let summary
  try {
    process.stdout.write = /** @type {any} */ (() => true)
    process.stderr.write = /** @type {any} */ (() => true)
    summary = await runAcceptance(
      parsed.dataRoot,
      parsed.referenceRoot,
    )
  } finally {
    process.stdout.write = originalStdoutWrite
    process.stderr.write = originalStderrWrite
  }
  process.stdout.write(`${JSON.stringify(summary)}\n`)
}

const isDirectExecution = process.argv[1] &&
  pathToFileURL(resolve(process.argv[1])).href === import.meta.url
if (isDirectExecution) {
  main().catch((error) => {
    const code = error &&
      typeof error === 'object' &&
      'code' in error &&
      typeof error.code === 'string' &&
      stableCodePattern.test(error.code)
      ? error.code
      : 'TPL003_REAL_ACCEPTANCE_FAILED'
    process.stderr.write(`${JSON.stringify({ ok: false, code })}\n`)
    process.exitCode = 1
  })
}
