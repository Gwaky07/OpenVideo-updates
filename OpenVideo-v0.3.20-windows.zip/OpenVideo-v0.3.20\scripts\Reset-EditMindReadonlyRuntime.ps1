[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)][string]$MaterialRoot,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [string]$RepositoryRoot,
    [string]$UpstreamRoot,
    [switch]$Recreate,
    [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $RepositoryRoot) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
if (-not $UpstreamRoot) { $UpstreamRoot = Join-Path $RepositoryRoot 'upstream/edit-mind' }

$runtime = & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $MaterialRoot -RuntimeDataRoot $RuntimeDataRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -PassThru
$metadata = Get-Content -LiteralPath $runtime.MetadataPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($metadata.material_root -ne $runtime.MaterialRoot -or $metadata.runtime_data_root -ne $runtime.RuntimeDataRoot) {
    throw 'Runtime metadata does not match the validated material and runtime roots.'
}

$shouldReset = $Force -or $PSCmdlet.ShouldProcess($runtime.RuntimeDataRoot, 'Delete and reset the Edit Mind runtime data root')
if (-not $shouldReset) { return }

$requiresContainerCleanup = $false
try {
    Get-ChildItem -LiteralPath $runtime.RuntimeDataRoot -Force | Remove-Item -Recurse -Force -ErrorAction Stop
} catch [System.UnauthorizedAccessException] {
    $requiresContainerCleanup = $true
}
if ($requiresContainerCleanup) {
    & docker image inspect alpine:3.20 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw 'Runtime cleanup requires the already-cached alpine:3.20 helper; automatic image download is forbidden.'
    }
    & docker run --pull=never --rm --mount "type=bind,src=$($runtime.RuntimeDataRoot),dst=/runtime" alpine:3.20 sh -ceu 'find /runtime -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +'
    if ($LASTEXITCODE -ne 0) { throw 'Container-assisted runtime cleanup failed.' }
}
$remainingEntries = @(Get-ChildItem -LiteralPath $runtime.RuntimeDataRoot -Force -ErrorAction Stop)
if ($remainingEntries.Count -ne 0) {
    throw "Container-assisted runtime cleanup left $($remainingEntries.Count) entries in the runtime data root."
}

Remove-Item -LiteralPath $runtime.RuntimeDataRoot -Recurse -Force
if ($Recreate) {
    & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $runtime.MaterialRoot -RuntimeDataRoot $runtime.RuntimeDataRoot -RepositoryRoot $runtime.RepositoryRoot -UpstreamRoot $runtime.UpstreamRoot -PassThru
} else {
    [pscustomobject]@{ RuntimeDataRoot = $runtime.RuntimeDataRoot; Deleted = $true; Recreated = $false }
}
