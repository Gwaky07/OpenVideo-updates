import { mkdir, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute } from 'node:path'

import { createJsonRepositories } from '../apps/gateway/src/local-runtime.mjs'

const [dataRoot, outputPath] = process.argv.slice(2)
if (!isAbsolute(dataRoot) || !isAbsolute(outputPath)) throw new Error('EM005_PRIVATE_PATH_INVALID')

const repositories = await createJsonRepositories({ dataRoot })
const authorization = repositories.authorizationRepository.list()
  .filter((record) => record.status === 'authorized' && record.readOnly === true && record.total >= 20)
  .sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))[0]
if (!authorization) throw new Error('EM005_AUTHORIZATION_NOT_FOUND')

await mkdir(dirname(outputPath), { recursive: true, mode: 0o700 })
await writeFile(outputPath, `${JSON.stringify(authorization, null, 2)}\n`, {
  encoding: 'utf8',
  mode: 0o600,
})
