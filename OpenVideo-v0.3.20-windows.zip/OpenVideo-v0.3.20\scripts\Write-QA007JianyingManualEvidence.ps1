# Write-QA007JianyingManualEvidence.ps1
# 在用户确认已于剪映中打开并继续编辑后，写入私有 manual evidence。
# 严禁在未人工确认时传入 -EditConfirmed。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$RuntimeDataRoot = "$env:LOCALAPPDATA\OpenVideo-QA007\data",

    [Parameter(Mandatory = $false)]
    [string]$GeneratedEvidencePath = "$env:LOCALAPPDATA\OpenVideo-QA007\data\evidence\qa-007\editor-e2e-1785161861239.json",

    [Parameter(Mandatory = $false)]
    [string]$ManualEvidencePath = "$env:LOCALAPPDATA\OpenVideo-QA007\data\evidence\qa-007\jianying-manual-open.json",

    [Parameter(Mandatory = $true)]
    [switch]$EditConfirmed
)

$ErrorActionPreference = 'Stop'

if (-not $EditConfirmed.IsPresent) {
    throw 'Refusing to write manual evidence without -EditConfirmed. Open the draft in Jianying first.'
}

if (-not (Test-Path -LiteralPath $GeneratedEvidencePath)) {
    throw "Generated evidence missing: $GeneratedEvidencePath"
}

$generated = Get-Content -LiteralPath $GeneratedEvidencePath -Raw -Encoding UTF8 | ConvertFrom-Json
$manual = [ordered]@{
    schema_version = 1
    kind = 'qa007_jianying_manual_open_evidence'
    timeline_revision_fingerprint = [string]$generated.timeline_revision_fingerprint
    jianying_output_fingerprint = [string]$generated.jianying_output_fingerprint
    opened_at = (Get-Date).ToUniversalTime().ToString('o')
    edit_confirmed = $true
}

$manualDir = Split-Path -Parent $ManualEvidencePath
New-Item -ItemType Directory -Force -Path $manualDir | Out-Null
$json = ($manual | ConvertTo-Json -Depth 5)
[IO.File]::WriteAllText($ManualEvidencePath, $json + "`n", [Text.UTF8Encoding]::new($false))

Write-Host "Wrote manual evidence: $ManualEvidencePath"
Write-Host 'Validate with:'
Write-Host ("powershell -NoProfile -ExecutionPolicy Bypass -File scripts\Test-QA007JianyingEvidence.ps1 -RuntimeDataRoot '{0}' -GeneratedEvidencePath '{1}' -ManualEvidencePath '{2}'" -f $RuntimeDataRoot, $GeneratedEvidencePath, $ManualEvidencePath)
