[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ManifestPath,
    [Parameter(Mandatory)][string]$RuntimeDataRoot
)

$ErrorActionPreference = 'Stop'
$pathComparison = [StringComparison]::OrdinalIgnoreCase
$utf8 = New-Object Text.UTF8Encoding($false)

function Get-FullPath {
    param([string]$Path, [string]$Name, [bool]$MustExist)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "$Name is required." }
    if ([IO.Path]::GetInvalidPathChars() | Where-Object { $Path.Contains($_) }) { throw "$Name contains invalid path characters." }
    if (-not [IO.Path]::IsPathRooted($Path) -or $Path -match '^[A-Za-z]:[^\\/]') { throw "$Name must be an absolute path." }
    $full = [IO.Path]::GetFullPath($Path)
    if ($MustExist -and -not (Test-Path -LiteralPath $full)) { throw "$Name does not exist: $full" }
    $root = [IO.Path]::GetPathRoot($full)
    if ($full.Equals($root, $pathComparison)) { return $root }
    return $full.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
}

function Test-Within {
    param([string]$Root, [string]$Candidate)
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($Root, $pathComparison) -or $Candidate.StartsWith($prefix, $pathComparison)
}

function Assert-NoReparseBoundary {
    param([string]$Root, [string]$Candidate)
    $cursor = $Candidate
    while ($true) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "Path crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        if ($cursor.Equals($Root, $pathComparison)) { break }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor -or -not (Test-Within -Root $Root -Candidate $parent)) {
            throw 'Private search evidence must be inside RuntimeDataRoot.'
        }
        $cursor = $parent
    }
}

function Assert-NoReparseAncestors {
    param([string]$Path, [string]$Name)
    $cursor = $Path
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "$Name crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-NotReparsePath {
    param([string]$Path, [string]$Name)
    $item = Get-Item -LiteralPath $Path -Force
    $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw "$Name must not be a symbolic link or reparse point: $Path"
    }
}

function Assert-RuntimeBoundary {
    param([string]$RuntimeRoot, [string]$RepositoryRoot)
    if (-not (Test-Path -LiteralPath $RuntimeRoot -PathType Container)) {
        throw 'RuntimeDataRoot must be an existing directory.'
    }
    $runtimeItem = Get-Item -LiteralPath $RuntimeRoot -Force
    $hasLinkType = $null -ne $runtimeItem.PSObject.Properties['LinkType'] -and [bool]$runtimeItem.LinkType
    if (($runtimeItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw 'RuntimeDataRoot must not be a symbolic link or reparse point.'
    }
    if ((Test-Within -Root $RepositoryRoot -Candidate $RuntimeRoot) -or (Test-Within -Root $RuntimeRoot -Candidate $RepositoryRoot)) {
        throw 'RuntimeDataRoot and the repository must be separate and must not contain one another.'
    }
}

$repositoryPath = Get-FullPath -Path (Split-Path -Parent $PSScriptRoot) -Name 'RepositoryRoot' -MustExist $true
$runtimePath = Get-FullPath -Path $RuntimeDataRoot -Name 'RuntimeDataRoot' -MustExist $true
Assert-NotReparsePath -Path $repositoryPath -Name 'RepositoryRoot'
Assert-RuntimeBoundary -RuntimeRoot $runtimePath -RepositoryRoot $repositoryPath
Assert-NoReparseAncestors -Path $runtimePath -Name 'RuntimeDataRoot'

$manifestPathFull = Get-FullPath -Path $ManifestPath -Name 'ManifestPath' -MustExist $true
if (-not (Test-Path -LiteralPath $manifestPathFull -PathType Leaf)) { throw 'ManifestPath must be an existing file.' }
if (-not (Test-Within -Root $runtimePath -Candidate $manifestPathFull)) { throw 'ManifestPath must be inside RuntimeDataRoot.' }
Assert-NoReparseBoundary -Root $runtimePath -Candidate $manifestPathFull

$manifest = Get-Content -LiteralPath $manifestPathFull -Raw -Encoding utf8 | ConvertFrom-Json
if ($manifest.schema_version -ne 1) { throw 'Search manifest schema_version must be 1.' }
if ($manifest.authorization -ne 'read_only_search') { throw 'Search manifest authorization must be read_only_search.' }
$rawSentences = @($manifest.sentences)
if ($rawSentences.Count -ne 8) { throw 'Search manifest must contain exactly eight sentences.' }

$normalizedSentences = @()
$seen = @{}
foreach ($rawSentence in $rawSentences) {
    if ($rawSentence -isnot [string] -or [string]::IsNullOrWhiteSpace($rawSentence)) {
        throw 'Each search sentence must be a non-empty string.'
    }
    $sentence = $rawSentence.Trim()
    if ($sentence -match '[\r\n]') { throw 'Each search sentence must be a single line.' }
    $key = $sentence.ToLowerInvariant()
    if ($seen.ContainsKey($key)) { throw 'Search sentences must be unique.' }
    $seen[$key] = $true
    $normalizedSentences += $sentence
}

$evidenceDir = Join-Path $runtimePath 'evidence/em-003'
$privateEvidenceDir = Join-Path $evidenceDir 'private'
New-Item -ItemType Directory -Path $privateEvidenceDir -Force | Out-Null

$snapshotPath = Join-Path $privateEvidenceDir 'search-query-snapshot.json'
$snapshot = [ordered]@{
    schema_version = 1
    authorization = 'read_only_search'
    sentence_count = 8
    sentences = $normalizedSentences
}
[IO.File]::WriteAllText($snapshotPath, ($snapshot | ConvertTo-Json -Depth 8), $utf8)

$verificationPath = Join-Path $evidenceDir 'search-query-verification.json'
$verification = [ordered]@{
    schema_version = 1
    sentence_count = 8
    query_text_private = $true
    snapshot_path = 'evidence/em-003/private/search-query-snapshot.json'
}
[IO.File]::WriteAllText($verificationPath, ($verification | ConvertTo-Json -Depth 6), $utf8)

[pscustomobject]@{ sentence_count = 8; verification_path = $verificationPath }
