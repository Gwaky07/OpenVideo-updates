import { execFile } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { copyFile, mkdir, mkdtemp, readdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import {
  loadLocalRuntimeConfig,
  securePrivateRuntimeRoot,
} from '../apps/gateway/src/local-runtime.mjs'

const execFileAsync = promisify(execFile)
const require = createRequire(import.meta.url)
const compatibilityManifest = require('../config/jianying-compatibility.json')
const segmentDurationUs = 4_000_000
const segmentCount = 4
const initialDissolveDurationUs = 500_000
const mediaRootPrefix = 'openvideo-jy026-dissolve-'
const inspectionStagingTtlMs = 10 * 60 * 1000

const safeFailure = (error) => ({
  ok: false,
  code: typeof error?.code === 'string' ? error.code : 'JY002_DRAFT_WRITE_FAILED',
  stage: typeof error?.stage === 'string' ? error.stage : 'generate',
})

const privateModuleRoot = () => {
  const value = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (typeof value !== 'string' || !path.isAbsolute(value)) {
    throw Object.assign(new Error('missing governed pyJianYingDraft root'), {
      code: 'JY002_PATH_PERMISSION_DENIED',
      stage: 'runtime',
    })
  }
  return value
}

export const getPendingCleanupLeasePath = () => path.join(
  loadLocalRuntimeConfig().dataRoot,
  'evidence',
  'jy026-dissolve',
  'pending-media.json',
)

export const getPendingInspectionCleanupLeasePath = () => path.join(
  loadLocalRuntimeConfig().dataRoot,
  'evidence',
  'jy026-dissolve',
  'pending-inspection',
)

/** @param {string} mediaRoot */
const assertOwnedMediaRoot = (mediaRoot) => {
  if (
    !path.isAbsolute(mediaRoot) ||
    path.dirname(mediaRoot) !== tmpdir() ||
    !path.basename(mediaRoot).startsWith(mediaRootPrefix)
  ) {
    throw Object.assign(new Error('unsafe JY-026 media cleanup target'), {
      code: 'JY026_MEDIA_CLEANUP_TARGET_INVALID',
      stage: 'cleanup',
    })
  }
}

/** @param {string} mediaRoot */
export const cleanupOwnedMediaRoot = async (mediaRoot) => {
  assertOwnedMediaRoot(mediaRoot)
  await rm(mediaRoot, { recursive: true, force: true, maxRetries: 3 })
}

/** @param {string} inspectRoot */
const assertOwnedInspectionRoot = (inspectRoot) => {
  if (
    !path.isAbsolute(inspectRoot) ||
    path.dirname(inspectRoot) !== tmpdir() ||
    !path.basename(inspectRoot).startsWith('openvideo-jy026-inspect-')
  ) {
    throw Object.assign(new Error('unsafe JY-026 inspection cleanup target'), {
      code: 'JY026_INSPECTION_CLEANUP_TARGET_INVALID',
      stage: 'cleanup',
    })
  }
}

/**
 * @param {{inspectRoot: string}} lease
 * @param {{secureRuntimeRoot?: typeof securePrivateRuntimeRoot}} [deps]
 */
export const persistPendingInspectionCleanup = async (lease, deps = {}) => {
  assertOwnedInspectionRoot(lease.inspectRoot)
  const leaseRoot = getPendingInspectionCleanupLeasePath()
  await mkdir(leaseRoot, { recursive: true, mode: 0o700 })
  const stagingDir = await mkdtemp(path.join(leaseRoot, 'staging-'))
  try {
    await (deps.secureRuntimeRoot ?? securePrivateRuntimeRoot)(stagingDir)
    await writeFile(path.join(stagingDir, 'lease.json'), `${JSON.stringify({
      inspectRoot: lease.inspectRoot,
      createdAt: new Date().toISOString(),
    })}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await rename(stagingDir, path.join(leaseRoot, `lease-${path.basename(stagingDir).slice('staging-'.length)}`))
  } catch (error) {
    await rm(stagingDir, { recursive: true, force: true }).catch(() => {})
    throw error
  }
}

export const cleanupPendingInspection = async (removeInspectionRoot = rm) => {
  const leaseRoot = getPendingInspectionCleanupLeasePath()
  let leaseNames
  try {
    leaseNames = await readdir(leaseRoot)
  } catch (error) {
    if (error?.code === 'ENOENT') return false
    throw Object.assign(error, { stage: 'cleanup' })
  }
  let cleaned = false
  for (const leaseName of leaseNames) {
    const leaseDir = path.join(leaseRoot, leaseName)
    if (leaseName.startsWith('staging-')) {
      try {
        const ageMs = Date.now() - (await stat(leaseDir)).mtimeMs
        if (ageMs >= inspectionStagingTtlMs) {
          await rm(leaseDir, { recursive: true, force: true })
        }
      } catch (error) {
        if (error?.code !== 'ENOENT') throw Object.assign(error, { stage: 'cleanup' })
      }
      continue
    }
    const leasePath = path.join(leaseDir, 'lease.json')
    let lease
    try {
      lease = JSON.parse(await readFile(leasePath, 'utf8'))
    } catch (error) {
      if (error?.code === 'ENOENT') {
        await rm(leaseDir, { recursive: true, force: true })
        continue
      }
      throw Object.assign(error, { stage: 'cleanup' })
    }
    if (typeof lease?.inspectRoot !== 'string') {
      throw Object.assign(new Error('invalid JY-026 inspection cleanup lease'), {
        code: 'JY026_INSPECTION_CLEANUP_LEASE_INVALID',
        stage: 'cleanup',
      })
    }
    assertOwnedInspectionRoot(lease.inspectRoot)
    await removeInspectionRoot(lease.inspectRoot, { recursive: true, force: true, maxRetries: 3 })
    await rm(leaseDir, { recursive: true, force: true })
    cleaned = true
  }
  return cleaned
}

/** @param {{mediaRoot: string, draftId: string}} lease */
const persistPendingCleanup = async (lease) => {
  assertOwnedMediaRoot(lease.mediaRoot)
  const leasePath = getPendingCleanupLeasePath()
  const evidenceRoot = path.dirname(leasePath)
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(evidenceRoot)
  try {
    const existing = JSON.parse(await readFile(leasePath, 'utf8'))
    if (typeof existing?.mediaRoot === 'string') {
      throw Object.assign(new Error('pending JY-026 media cleanup required'), {
        code: 'JY026_PENDING_MEDIA_CLEANUP_REQUIRED',
        stage: 'cleanup',
      })
    }
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  await writeFile(leasePath, `${JSON.stringify({
    mediaRoot: lease.mediaRoot,
    draftId: lease.draftId,
    createdAt: new Date().toISOString(),
  })}\n`, { encoding: 'utf8', mode: 0o600 })
}

const cleanupPendingMedia = async () => {
  const leasePath = getPendingCleanupLeasePath()
  let lease
  try {
    lease = JSON.parse(await readFile(leasePath, 'utf8'))
  } catch (error) {
    if (error?.code === 'ENOENT') return false
    throw error
  }
  if (typeof lease?.mediaRoot !== 'string' || typeof lease?.draftId !== 'string') {
    throw Object.assign(new Error('invalid JY-026 cleanup lease'), {
      code: 'JY026_MEDIA_CLEANUP_LEASE_INVALID',
      stage: 'cleanup',
    })
  }
  await cleanupOwnedMediaRoot(lease.mediaRoot)
  await rm(leasePath, { force: true })
  return true
}

const createSyntheticMedia = async (mediaRoot) => {
  const videoPaths = []
  const voiceoverPaths = []
  const colors = ['red', 'green', 'blue', 'yellow']
  for (let index = 0; index < segmentCount; index += 1) {
    const videoPath = path.join(mediaRoot, `clip-${index + 1}.mp4`)
    const audioPath = path.join(mediaRoot, `silent-${index + 1}.wav`)
    await execFileAsync('ffmpeg', [
      '-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi',
      '-i', `color=c=${colors[index]}:s=360x640:r=30`, '-t', '4',
      '-pix_fmt', 'yuv420p', videoPath,
    ])
    await execFileAsync('ffmpeg', [
      '-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi',
      '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audioPath,
    ])
    videoPaths.push(videoPath)
    voiceoverPaths.push(audioPath)
  }
  return { videoPaths, voiceoverPaths }
}

const draftId = () => `OpenVideo-JY026-dissolve-${Date.now()}`

const createInput = (id, videoPaths, voiceoverPaths) => {
  const videoSegments = videoPaths.map((_, index) => ({
    source_range: { start: 0, duration: segmentDurationUs },
    target_range: { start: index * segmentDurationUs, duration: segmentDurationUs },
  }))
  const voiceoverSegments = voiceoverPaths.map((_, index) => ({
    segment_id: `voiceover-${index + 1}`,
    text: `JY-026 segment ${index + 1}`,
    target_range: { start: index * segmentDurationUs, duration: segmentDurationUs },
  }))
  const exportRequest = {
    preparation: {
      timeline: {
        duration: segmentCount * segmentDurationUs,
        tracks: [{ segments: videoSegments }, { segments: voiceoverSegments }],
      },
    },
  }
  return {
    request: { export_request: exportRequest },
    writeInput: {
      job_id: `job-${id}`,
      request_id: `request-${id}`,
      output_policy: { draft_id: id },
      export_request: exportRequest,
      orientation: 'portrait',
      materials: videoPaths.map((filePath) => ({ path: filePath })),
      voiceovers: voiceoverPaths.map((filePath) => ({ path: filePath })),
    },
  }
}

export const hasInitialDissolve = (content) =>
  Array.isArray(content?.materials?.transitions) &&
  content.materials.transitions.length === 1 &&
  content.materials.transitions.every((transition) =>
    transition?.type === 'transition' &&
    transition?.duration === initialDissolveDurationUs,
  )

/**
 * Inspect released draft content through the governed decryptor so encrypted
 * current-version drafts never fall back to direct parsing or in-place writes.
 * @param {{sourcePath: string, desktop: {installRoot: string, version: string}}} input
 * @param {{
 *   createDecryptor?: typeof createJianyingDraftDecryptor,
 *   cleanupPendingInspection?: typeof cleanupPendingInspection,
 *   removeInspectionRoot?: typeof rm,
 *   persistInspectionCleanup?: typeof persistPendingInspectionCleanup,
 * }} [deps]
 */
export const readDissolveDraftContent = async ({ sourcePath, desktop }, deps = {}) => {
  if (
    typeof sourcePath !== 'string' || !path.isAbsolute(sourcePath) ||
    typeof desktop?.installRoot !== 'string' || !path.isAbsolute(desktop.installRoot) ||
    typeof desktop?.version !== 'string' || !desktop.version.trim()
  ) {
    throw Object.assign(new Error('invalid dissolve inspection input'), {
      code: 'JY002_DRAFT_STRUCTURE_INVALID',
      stage: 'verify-content',
    })
  }
  await (deps.cleanupPendingInspection ?? cleanupPendingInspection)(deps.removeInspectionRoot)
  const inspectRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy026-inspect-'))
  try {
    const plaintextPath = path.join(inspectRoot, 'draft_content.json')
    const decryptor = (deps.createDecryptor ?? createJianyingDraftDecryptor)({
      installRoot: desktop.installRoot,
      appVersion: desktop.version,
    })
    let metadata
    try {
      metadata = await decryptor.ensurePlaintextFile(sourcePath, plaintextPath)
    } catch (error) {
      throw Object.assign(error, { stage: 'verify-content' })
    }
    try {
      // Without an installed decrypt helper, plaintext input is identified but
      // not materialized at the requested output path.
      if (metadata?.scheme === 'plaintext') await copyFile(sourcePath, plaintextPath)
      return JSON.parse(await readFile(plaintextPath, 'utf8'))
    } catch (error) {
      throw Object.assign(new Error('invalid dissolve draft content', { cause: error }), {
        code: 'JY002_DRAFT_STRUCTURE_INVALID',
        stage: 'verify-content',
      })
    }
  } finally {
    try {
      await (deps.removeInspectionRoot ?? rm)(inspectRoot, { recursive: true, force: true, maxRetries: 3 })
    } catch (error) {
      let leaseError = null
      try {
        await (deps.persistInspectionCleanup ?? persistPendingInspectionCleanup)({ inspectRoot })
      } catch (persistError) {
        leaseError = persistError
      }
      throw Object.assign(new Error('JY-026 inspection cleanup required', { cause: error }), {
        code: 'JY026_INSPECTION_CLEANUP_REQUIRED',
        stage: 'cleanup',
        lease_error: leaseError?.code ?? null,
      })
    }
  }
}

const main = async () => {
  if (process.argv.includes('--cleanup')) {
    const cleaned = await cleanupPendingMedia()
    process.stdout.write(`${JSON.stringify({ ok: true, cleanup_completed: cleaned })}\n`)
    return
  }
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  if (desktop?.available !== true || typeof desktop.draftRoot !== 'string') {
    throw Object.assign(new Error('Jianying desktop unavailable'), {
      code: 'JY002_DRAFT_WRITE_FAILED',
      stage: 'desktop',
    })
  }
  let mediaRoot = null
  let retainMediaForManualEvidence = false
  try {
    mediaRoot = await mkdtemp(path.join(tmpdir(), mediaRootPrefix))
    await mkdir(mediaRoot, { recursive: true })
    const { videoPaths, voiceoverPaths } = await createSyntheticMedia(mediaRoot)
    const id = draftId()
    const input = createInput(id, videoPaths, voiceoverPaths)
    const writer = createPyJianyingDraftWriter({
    draftRoot: desktop.draftRoot,
    pythonExecutable: process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE ?? 'python',
    pythonModuleRoot: privateModuleRoot(),
    timeoutMs: 90_000,
    getRenderOptions: () => ({
      captions: false,
      bgmPath: null,
      subtitleStyle: 'default',
      keywordHighlights: [],
      captionSegments: [],
      titleSegments: [],
      timelinePackaging: {
        video: [
          {
            transition_out: {
              capability_id: 'transition.dissolve',
              duration_us: initialDissolveDurationUs,
              transition_name: '\u53e0\u5316',
            },
            keyframes: [],
          },
          ...Array.from({ length: segmentCount - 1 }, () => ({ transition_out: null, keyframes: [] })),
        ],
        sfx_segments: [],
        effect_segments: [],
        sticker_segments: [],
        voiceover_segments: [],
        bgm: { fade_in_us: 0, fade_out_us: 0 },
      },
    }),
    })
    const writeResult = await writer.writeDraft(input.writeInput)
    const verified = await writer.verifyDraft({
    job_id: input.writeInput.job_id,
    request: input.request,
    write_result: writeResult,
    })
    if (verified !== true) {
    throw Object.assign(new Error('draft verification failed'), {
      code: 'JY002_DRAFT_STRUCTURE_INVALID',
      stage: 'verify',
    })
    }
    const released = await writer.releaseDraft({
    job_id: input.writeInput.job_id,
    write_result: writeResult,
    })
    if (released !== true) {
    throw Object.assign(new Error('draft release failed'), {
      code: 'JY002_DRAFT_WRITE_FAILED',
      stage: 'release',
    })
    }
    const content = await readDissolveDraftContent({
      sourcePath: path.join(desktop.draftRoot, id, 'draft_content.json'),
      desktop,
    })
    if (!hasInitialDissolve(content)) {
    throw Object.assign(new Error('initial transition evidence absent'), {
      code: 'JY002_DRAFT_STRUCTURE_INVALID',
      stage: 'verify-content',
    })
    }
    await persistPendingCleanup({ mediaRoot, draftId: id })
    retainMediaForManualEvidence = true
    process.stdout.write(`${JSON.stringify({
      ok: true,
      manual_open_required: true,
      desktop_version: desktop.version ?? null,
      profile_id: desktop.profileId ?? null,
      initial_dissolve_duration_us: initialDissolveDurationUs,
      video_segment_count: segmentCount,
    })}\n`)
  } finally {
    if (mediaRoot && !retainMediaForManualEvidence) await cleanupOwnedMediaRoot(mediaRoot)
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    process.stdout.write(`${JSON.stringify(safeFailure(error))}\n`)
    process.exitCode = 1
  })
}
