import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { writeFile } from 'node:fs/promises'
import path from 'node:path'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'

const execFileAsync = promisify(execFile)
const main = async () => {
  const moduleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (!moduleRoot || !path.isAbsolute(moduleRoot)) throw new Error('JY044_UPSTREAM_ROOT_REQUIRED')
  const { stdout } = await execFileAsync('python', ['-c', "import pyJianYingDraft as d, json; x=next(iter(d.IntroType)); print(json.dumps({'resource_id': x.value.resource_id, 'display_name': x.value.title}, ensure_ascii=False))"], { env: { ...process.env, PYTHONPATH: moduleRoot }, windowsHide: true })
  const raw = JSON.parse(stdout)
  if (typeof raw.resource_id !== 'string') throw new Error('JY044_ANIMATION_UNAVAILABLE')
  const entry = { capability_id: 'animation.video.named', animation_token: `ovjanim_v1_${createHash('sha256').update(raw.resource_id).digest('hex')}`, display_name: raw.display_name, resource_id: raw.resource_id, duration_us: 500_000 }
  const catalog = { schema_version: 1, kind: 'jy044_animation_catalog', catalog_version: '1.0.0', entries: [entry] }
  catalog.catalog_fingerprint = createHash('sha256').update(JSON.stringify(catalog)).digest('hex')
  await writeFile(path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs', 'jy044-animation-catalog.json'), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(JSON.stringify({ ok: true, capability: entry.capability_id, binding_count: 1, animation_name: entry.display_name }) + '\n')
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY044_CATALOG_FAILED' }) + '\n'); process.exitCode = 1 })
