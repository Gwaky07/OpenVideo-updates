import { execFile } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import {
  projectRichTimelineToJianyingExport,
  RichTimelineJianyingProjectionError,
} from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import {
  computeCapabilityRequirements,
  finalizeRichTimeline,
  sealRichTimeline,
} from '../apps/gateway/src/rich-timeline-contracts.mjs'

const execFileAsync = promisify(execFile)
const require = createRequire(import.meta.url)
const compatibilityManifest = require('../config/jianying-compatibility.json')
const mediaRootPrefix = 'openvideo-jy027-scale-'
const durationUs = 4_000_000
const scaleOffsetUs = 1_000_000
const initialScale = 1.08
const persistedScale = 1.2
const evidenceProfileId = 'jianying-11-1-provisional'

const privateModuleRoot = () => {
  const root = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (typeof root !== 'string' || !path.isAbsolute(root)) {
    throw Object.assign(new Error('missing governed pyJianYingDraft root'), {
      code: 'JY002_PATH_PERMISSION_DENIED', stage: 'runtime',
    })
  }
  return root
}

export const getPendingScaleCleanupLeasePath = () => path.join(
  loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy027-scale', 'pending-media.json',
)

const privateAuditPath = () => path.join(
  loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy027-scale', 'post-save.json',
)

/** @param {number} scale @param {string} interpolation */
const scaleKeyframe = (scale, interpolation = 'linear') => ({
  capabilityId: 'transform.scale', offsetUs: scaleOffsetUs, value: scale, interpolation,
})

export const createScaleEvidenceTimeline = (keyframe = scaleKeyframe(initialScale)) => {
  const tracks = [
    {
      trackId: 'video-primary', order: 0, enabled: true, locked: false,
      kind: 'video', role: 'primary',
      segments: [{
        segmentId: 'jy027-video', kind: 'video',
        asset: { authorizationId: 'jy027-evidence-auth', assetId: 'jy027-evidence-video', sceneId: 'jy027-evidence-scene' },
        sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs },
        fit: 'cover', volume: 1, speed: { numerator: 1, denominator: 1 },
        keyframes: [keyframe], effects: [],
        audit: { origin: 'editor', candidateId: 'jy027-evidence-candidate', instructionFingerprint: null },
        transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
      }],
    },
    {
      trackId: 'voiceover-guide', order: 1, enabled: true, locked: false,
      kind: 'audio', role: 'voiceover',
      segments: [{
        segmentId: 'jy027-voiceover', kind: 'voiceover', capabilityId: 'audio.voiceover.edge_tts',
        source: { kind: 'generated', generatedAudioId: 'jy027-evidence-voiceover' },
        sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs },
        volume: 1, fadeInUs: 0, fadeOutUs: 0, keyframes: [], ducking: 'none',
      }],
    },
  ]
  const draft = {
    schemaVersion: 1, timelineId: 'jy027-scale-evidence', projectId: 'jy027-evidence',
    revision: 1, parentRevision: null, parentRevisionFingerprint: null, status: 'draft',
    createdAt: '2026-08-08T00:00:00.000Z', durationUs, orientation: 'portrait',
    fps: { numerator: 30, denominator: 1 },
    source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null },
    tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks),
  }
  return finalizeRichTimeline(sealRichTimeline(draft))
}

/** @param {string | null | undefined} profileId @param {Record<string, any>} [timeline] */
export const projectScaleEvidenceTimeline = (profileId, timeline = createScaleEvidenceTimeline()) => {
  if (profileId !== evidenceProfileId) {
    throw new RichTimelineJianyingProjectionError(
      'JY004_CAPABILITY_UNSUPPORTED',
      409,
      'transform.scale',
    )
  }
  return projectRichTimelineToJianyingExport(timeline, {
    jianyingProfileId: profileId,
    allowAppendTrackFallback: true,
  })
}

/** @param {string} mediaRoot */
const assertOwnedMediaRoot = (mediaRoot) => {
  if (!path.isAbsolute(mediaRoot) || path.dirname(mediaRoot) !== tmpdir() ||
    !path.basename(mediaRoot).startsWith(mediaRootPrefix)) {
    throw Object.assign(new Error('unsafe JY-027 media cleanup target'), {
      code: 'JY027_MEDIA_CLEANUP_TARGET_INVALID', stage: 'cleanup',
    })
  }
}

/** @param {string} mediaRoot */
export const cleanupOwnedScaleMediaRoot = async (mediaRoot) => {
  assertOwnedMediaRoot(mediaRoot)
  await rm(mediaRoot, { recursive: true, force: true, maxRetries: 3 })
}

/** @param {{mediaRoot: string, draftId: string, profileId: string, draftRoot: string}} lease */
const persistPendingCleanup = async (lease) => {
  assertOwnedMediaRoot(lease.mediaRoot)
  const leasePath = getPendingScaleCleanupLeasePath()
  const evidenceRoot = path.dirname(leasePath)
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(evidenceRoot)
  try {
    const existing = JSON.parse(await readFile(leasePath, 'utf8'))
    if (typeof existing?.mediaRoot === 'string') throw Object.assign(
      new Error('pending JY-027 media cleanup required'),
      { code: 'JY027_PENDING_MEDIA_CLEANUP_REQUIRED', stage: 'cleanup' },
    )
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  await writeFile(leasePath, `${JSON.stringify({
    mediaRoot: lease.mediaRoot, draftId: lease.draftId, profileId: lease.profileId,
    draftRoot: path.resolve(lease.draftRoot),
    createdAt: new Date().toISOString(),
  })}\n`, { encoding: 'utf8', mode: 0o600 })
}

const cleanupPendingMedia = async () => {
  const leasePath = getPendingScaleCleanupLeasePath()
  let lease
  try { lease = JSON.parse(await readFile(leasePath, 'utf8')) } catch (error) {
    if (error?.code === 'ENOENT') return false
    throw error
  }
  if (typeof lease?.mediaRoot !== 'string' || typeof lease?.draftId !== 'string' ||
    typeof lease?.draftRoot !== 'string' || lease?.profileId !== evidenceProfileId) {
    throw Object.assign(new Error('invalid JY-027 cleanup lease'), {
      code: 'JY027_MEDIA_CLEANUP_LEASE_INVALID', stage: 'cleanup',
    })
  }
  await cleanupOwnedScaleMediaRoot(lease.mediaRoot)
  await rm(leasePath, { force: true })
  return true
}

/** @param {string} mediaRoot */
const createSyntheticMedia = async (mediaRoot) => {
  const videoPath = path.join(mediaRoot, 'scale-evidence.mp4')
  const audioPath = path.join(mediaRoot, 'silent.wav')
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi',
    '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath])
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi',
    '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audioPath])
  return { videoPath, audioPath }
}

/** @param {string} mediaRoot @param {Record<string, string>} catalog @param {string} token */
export const resolveOwnedEvidenceMedia = (mediaRoot, catalog, token) => {
  assertOwnedMediaRoot(mediaRoot)
  const candidate = catalog[token]
  if (typeof candidate !== 'string' || !path.isAbsolute(candidate) ||
    path.dirname(candidate) !== mediaRoot) {
    throw Object.assign(new Error('JY-027 evidence media token is unavailable'), {
      code: 'JY027_EVIDENCE_MEDIA_MISSING', stage: 'private-catalog',
    })
  }
  return candidate
}

/** @param {Record<string, any>} content */
export const hasInitialScale = (content) => {
  const videoTrack = content?.tracks?.find((track) => track?.name === 'video-primary')
  const scaleLists = videoTrack?.segments?.flatMap((segment) =>
    (segment?.common_keyframes ?? []).filter((entry) => entry?.property_type === 'KFTypeScaleX')) ?? []
  return scaleLists.length === 1 &&
    Array.isArray(scaleLists[0]?.keyframe_list) &&
    scaleLists[0].keyframe_list.length === 1 &&
    scaleLists[0].keyframe_list[0]?.time_offset === scaleOffsetUs &&
    Array.isArray(scaleLists[0].keyframe_list[0]?.values) &&
    scaleLists[0].keyframe_list[0].values.length === 1 &&
    Math.abs(scaleLists[0].keyframe_list[0].values[0] - initialScale) <= 1e-9
}

/** @param {Record<string, any>} content */
export const hasPersistedManualScale = (content) => {
  const videoTrack = content?.tracks?.find((track) => track?.name === 'video-primary')
  const scaleLists = videoTrack?.segments?.flatMap((segment) =>
    (segment?.common_keyframes ?? []).filter((entry) => entry?.property_type === 'KFTypeScaleX')) ?? []
  return scaleLists.length === 1 && Array.isArray(scaleLists[0]?.keyframe_list) &&
    scaleLists[0].keyframe_list.length === 1 &&
    scaleLists[0].keyframe_list[0]?.time_offset === scaleOffsetUs &&
    Array.isArray(scaleLists[0].keyframe_list[0]?.values) &&
    scaleLists[0].keyframe_list[0].values.length === 1 &&
    Math.abs(scaleLists[0].keyframe_list[0].values[0] - persistedScale) <= 1e-9
}

/** @param {unknown} lease @param {Record<string, any>} desktop */
export const assertBoundManualLease = (lease, desktop) => {
  if (typeof lease?.draftId !== 'string' || !/^OpenVideo-JY027-scale-[0-9]+$/u.test(lease.draftId) ||
    typeof lease?.draftRoot !== 'string' || lease?.profileId !== evidenceProfileId ||
    desktop?.profileId !== evidenceProfileId || typeof desktop?.draftRoot !== 'string' ||
    path.resolve(lease.draftRoot) !== path.resolve(desktop.draftRoot)) {
    throw Object.assign(new Error('bound JY-027 evidence lease required'), {
      code: 'JY027_MANUAL_EVIDENCE_BINDING_REQUIRED', stage: 'manual-evidence',
    })
  }
  return lease.draftId
}

const readBoundManualLease = async (desktop) => {
  let lease
  try { lease = JSON.parse(await readFile(getPendingScaleCleanupLeasePath(), 'utf8')) } catch (error) {
    if (error?.code === 'ENOENT') throw Object.assign(new Error('bound JY-027 evidence lease missing'), {
      code: 'JY027_MANUAL_EVIDENCE_BINDING_REQUIRED', stage: 'manual-evidence',
    })
    throw error
  }
  return assertBoundManualLease(lease, desktop)
}

const verifyPostSaveEvidence = async (desktop) => {
  if (desktop?.profileId !== evidenceProfileId || typeof desktop?.draftRoot !== 'string') {
    throw Object.assign(new Error('JY-027 manual evidence profile is unsupported'), {
      code: 'JY027_MANUAL_PROFILE_UNSUPPORTED', stage: 'manual-evidence',
    })
  }
  const draftId = await readBoundManualLease(desktop)
  const encryptedPath = path.join(desktop.draftRoot, draftId, 'draft_content.json')
  const plaintextRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy027-scale-verify-'))
  const plaintextPath = path.join(plaintextRoot, 'draft_content.json')
  try {
    const decryptor = createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
    const decryptMeta = await decryptor.ensurePlaintextFile(encryptedPath, plaintextPath)
    if (decryptMeta.scheme !== 'encrypt_v2' && decryptMeta.decryptedFrom !== 'encrypt_v2') {
      throw Object.assign(new Error('controlled encrypt_v2 decrypt required'), {
        code: 'JY027_MANUAL_DECRYPT_REQUIRED', stage: 'manual-evidence',
      })
    }
    const content = JSON.parse(await readFile(plaintextPath, 'utf8'))
    if (!hasPersistedManualScale(content)) {
      throw Object.assign(new Error('post-save scale evidence absent'), {
        code: 'JY027_MANUAL_SCALE_MISMATCH', stage: 'manual-evidence',
      })
    }
    const auditPath = privateAuditPath()
    const auditRoot = path.dirname(auditPath)
    await mkdir(auditRoot, { recursive: true, mode: 0o700 })
    await securePrivateRuntimeRoot(auditRoot)
    await writeFile(auditPath, `${JSON.stringify({
      profileId: desktop.profileId, desktopVersion: desktop.version ?? null,
      scheme: decryptMeta.scheme ?? decryptMeta.decryptedFrom ?? 'plaintext',
      scaleOffsetUs, persistedScale, opened: true, edited: true, saved: true,
      reopened: true, keyframeCount: 1, verifiedAt: new Date().toISOString(),
    })}\n`, { encoding: 'utf8', mode: 0o600 })
    return { scheme: decryptMeta.scheme ?? decryptMeta.decryptedFrom ?? 'plaintext' }
  } finally {
    await rm(plaintextRoot, { recursive: true, force: true, maxRetries: 3 })
  }
}

const main = async () => {
  if (process.argv.includes('--cleanup')) {
    process.stdout.write(`${JSON.stringify({ ok: true, cleanup_completed: await cleanupPendingMedia() })}\n`)
    return
  }
  if (process.argv.includes('--verify-manual')) {
    if (!['--opened', '--edited', '--saved', '--reopened'].every((flag) => process.argv.includes(flag))) {
      throw Object.assign(new Error('manual evidence flags are required'), {
        code: 'JY027_MANUAL_EVIDENCE_REQUIRED', stage: 'manual-evidence',
      })
    }
    const desktop = await detectJianyingDesktop({ compatibilityManifest })
    const result = await verifyPostSaveEvidence(desktop)
    process.stdout.write(`${JSON.stringify({ ok: true, manual_evidence_verified: true, scheme: result.scheme })}\n`)
    return
  }
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  if (desktop?.available !== true || typeof desktop.draftRoot !== 'string' ||
    desktop.profileId !== evidenceProfileId) {
    throw Object.assign(new Error('Jianying desktop unavailable'), {
      code: 'JY002_DRAFT_WRITE_FAILED', stage: 'desktop',
    })
  }
  let mediaRoot = null
  let retainMediaForManualEvidence = false
  try {
    const projected = projectScaleEvidenceTimeline(desktop.profileId)
    mediaRoot = await mkdtemp(path.join(tmpdir(), mediaRootPrefix))
    const media = await createSyntheticMedia(mediaRoot)
    const draftId = `OpenVideo-JY027-scale-${Date.now()}`
    const exportRequest = { preparation: projected.preparation }
    const privateCatalog = { jy027_video: media.videoPath, jy027_voiceover: media.audioPath }
    const writer = createPyJianyingDraftWriter({
      draftRoot: desktop.draftRoot,
      pythonExecutable: process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE ?? 'python',
      pythonModuleRoot: privateModuleRoot(),
      timeoutMs: 90_000,
      getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default',
        keywordHighlights: [], captionSegments: [], titleSegments: [],
        timelinePackaging: { ...projected.packaging, sfx_segments: [], effect_segments: [], sticker_segments: [],
          voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } },
      }),
    })
    const writeInput = { job_id: `job-${draftId}`, request_id: `request-${draftId}`,
      output_policy: { draft_id: draftId }, export_request: exportRequest, orientation: 'portrait',
      materials: [{ path: resolveOwnedEvidenceMedia(mediaRoot, privateCatalog, 'jy027_video') }],
      voiceovers: [{ path: resolveOwnedEvidenceMedia(mediaRoot, privateCatalog, 'jy027_voiceover') }] }
    const writeResult = await writer.writeDraft(writeInput)
    if (await writer.verifyDraft({ job_id: writeInput.job_id, request: { export_request: exportRequest }, write_result: writeResult }) !== true) {
      throw Object.assign(new Error('draft verification failed'), { code: 'JY002_DRAFT_STRUCTURE_INVALID', stage: 'verify' })
    }
    if (await writer.releaseDraft({ job_id: writeInput.job_id, write_result: writeResult }) !== true) {
      throw Object.assign(new Error('draft release failed'), { code: 'JY002_DRAFT_WRITE_FAILED', stage: 'release' })
    }
    const content = JSON.parse(await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'), 'utf8'))
    if (!hasInitialScale(content)) throw Object.assign(new Error('initial scale evidence absent'), {
      code: 'JY002_DRAFT_STRUCTURE_INVALID', stage: 'verify-content',
    })
    await persistPendingCleanup({ mediaRoot, draftId, profileId: desktop.profileId, draftRoot: desktop.draftRoot })
    retainMediaForManualEvidence = true
    process.stdout.write(`${JSON.stringify({ ok: true, manual_open_required: true,
      desktop_version: desktop.version ?? null, profile_id: desktop.profileId ?? null,
      initial_scale: initialScale, scale_offset_us: scaleOffsetUs })}\n`)
  } finally {
    if (mediaRoot && !retainMediaForManualEvidence) await cleanupOwnedScaleMediaRoot(mediaRoot)
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? 'JY002_DRAFT_WRITE_FAILED', stage: error?.stage ?? 'generate' })}\n`)
    process.exitCode = 1
  })
}
