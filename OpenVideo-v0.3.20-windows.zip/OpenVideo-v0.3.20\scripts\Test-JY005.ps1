param(
  [string]$RepositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path,
  [string]$RuntimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($RuntimeRoot)) {
  $RuntimeRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo\jy005-probe'
}
$resolvedRepositoryRoot = [IO.Path]::GetFullPath($RepositoryRoot).TrimEnd('\')
$resolvedRuntimeRoot = [IO.Path]::GetFullPath($RuntimeRoot).TrimEnd('\')
if ($resolvedRuntimeRoot.Equals($resolvedRepositoryRoot, [StringComparison]::OrdinalIgnoreCase) -or
    $resolvedRuntimeRoot.StartsWith($resolvedRepositoryRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'JY005_RUNTIME_ROOT_MUST_BE_OUTSIDE_REPOSITORY'
}
$cursor = $resolvedRuntimeRoot
while (-not [string]::IsNullOrWhiteSpace($cursor)) {
  if (Test-Path -LiteralPath $cursor) {
    $item = Get-Item -LiteralPath $cursor -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
      throw 'JY005_RUNTIME_ROOT_REPARSE_POINT_DENIED'
    }
  }
  $parent = Split-Path -Parent $cursor
  if ($parent -eq $cursor) { break }
  $cursor = $parent
}
$RuntimeRoot = $resolvedRuntimeRoot
$EvidenceRoot = Join-Path $RuntimeRoot 'evidence'
New-Item -ItemType Directory -Force -Path $EvidenceRoot | Out-Null

function Get-JianyingInstall {
  $roots = @(
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
  )
  $app = Get-ItemProperty $roots -ErrorAction SilentlyContinue |
    Where-Object { [string]$_.DisplayIcon -like '*JianyingPro*' -or [string]$_.InstallLocation -like '*JianyingPro*' -or [string]$_.DisplayName -like '*Jianying*' } |
    Sort-Object { [version]$_.DisplayVersion } -Descending |
    Select-Object -First 1
  if ($null -eq $app) { throw 'JY005_DESKTOP_NOT_FOUND' }
  $iconPath = ([string]$app.DisplayIcon -replace '^"|"$','' -replace ',\d+$','')
  $install = if (-not [string]::IsNullOrWhiteSpace([string]$app.InstallLocation)) {
    [string]$app.InstallLocation
  } elseif ([IO.Path]::IsPathRooted($iconPath)) {
    Split-Path -Parent $iconPath
  } else { throw 'JY005_INSTALL_ROOT_NOT_FOUND' }
  $versionDir = Join-Path $install ([string]$app.DisplayVersion)
  $exe = Join-Path $versionDir 'JianyingPro.exe'
  if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
    $exe = Get-ChildItem -LiteralPath $install -Filter JianyingPro.exe -File -Recurse -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1 -ExpandProperty FullName
  }
  if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'JY005_EXE_NOT_FOUND' }
  $sig = Get-AuthenticodeSignature -LiteralPath $exe
  [pscustomobject]@{
    Version = [string]$app.DisplayVersion
    InstallRoot = [IO.Path]::GetFullPath($install)
    VersionRoot = [IO.Path]::GetFullPath((Split-Path -Parent $exe))
    Executable = [IO.Path]::GetFullPath($exe)
    SignatureStatus = [string]$sig.Status
    Publisher = if ($sig.SignerCertificate) { [string]$sig.SignerCertificate.Subject } else { '' }
  }
}

function Find-AsciiPattern([string]$Path, [string[]]$Patterns) {
  $matches = @()
  foreach ($pattern in $Patterns) {
    $escaped = $pattern.Replace('"','\"')
    $output = & findstr.exe /m /i /c:"$escaped" "$Path" 2>$null
    if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace([string]$output)) {
      $matches += $pattern
    }
  }
  $matches
}

$install = Get-JianyingInstall
$patterns = @(
  'enable_silent_export',
  'SilentExportTaskManager',
  'backend_export_exit_jianying',
  'silent export start',
  'real_export_path',
  '--export',
  '--render',
  '--draft',
  '--project',
  '--help'
)
$scanFiles = @('JianyingPro.exe','taskcontainer.exe','VEHelper.exe','VEDetector.exe','VECreator.dll','cccreator.dll','lyra_cli_client.dll') |
  ForEach-Object { Join-Path $install.VersionRoot $_ } |
  Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }
$stringEvidence = @()
foreach ($file in $scanFiles) {
  $found = Find-AsciiPattern -Path $file -Patterns $patterns
  $stringEvidence += [pscustomobject]@{
    File = Split-Path -Leaf $file
    Sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash.ToLowerInvariant()
    Matches = $found
  }
}

$public = [pscustomobject]@{
  SchemaVersion = 1
  Kind = 'jy005_probe_summary'
  Verdict = 'FAIL'
  ReasonCode = 'JY005_SAFE_BACKGROUND_TRANSPORT_UNPROVEN'
  BackgroundRender = $false
  Version = $install.Version
  SignatureStatus = $install.SignatureStatus
  PublisherTrusted = ($install.SignatureStatus -eq 'Valid' -and $install.Publisher -like 'CN=*')
  TransportCandidates = $stringEvidence | ForEach-Object {
    [pscustomobject]@{ File = $_.File; MatchCount = @($_.Matches).Count }
  }
  Notes = @(
    'Read-only probe found internal strings only; no public stable CLI/service/IPC was invoked.',
    'DLL injection, memory patching, credential access, and membership bypass remain prohibited.',
    'Visible UI automation is not classified as background_render PASS.'
  )
}

$private = [pscustomobject]@{
  Summary = $public
  Install = $install
  StringEvidence = $stringEvidence
  RecordedAt = (Get-Date).ToUniversalTime().ToString('o')
}
$evidencePath = Join-Path $EvidenceRoot ('jy005-probe-{0}.json' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$private | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $evidencePath -Encoding UTF8
$public | ConvertTo-Json -Depth 6
