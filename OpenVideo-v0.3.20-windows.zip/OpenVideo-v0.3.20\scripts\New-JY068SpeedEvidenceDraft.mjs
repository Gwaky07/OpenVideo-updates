import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'

const run = promisify(execFile)
const profileId = 'jianying-11-1-provisional'
const durationUs = 4_000_000
const targetDurationUs = 3_200_000
const initialSpeed = { numerator: 5, denominator: 4 }
const mediaPrefix = 'openvideo-jy068-speed-'

const registry = {
  assertWriterCapability(capabilityId, target) {
    if (target !== 'jianying' || !['speed.constant', 'transition.none'].includes(capabilityId)) {
      throw new Error(`JY068_UNEXPECTED_CAPABILITY:${capabilityId}`)
    }
    return {}
  },
}

const timeline = () => {
  const tracks = [
    { trackId: 'video-primary', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary', segments: [{
      segmentId: 'jy068-video', kind: 'video',
      asset: { authorizationId: 'jy068-auth', assetId: 'jy068-video', sceneId: 'jy068-scene' },
      sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs: targetDurationUs }, fit: 'cover', volume: 1,
      speed: initialSpeed, keyframes: [], effects: [],
      audit: { origin: 'editor', candidateId: 'jy068-candidate', instructionFingerprint: null },
      transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
    }] },
    { trackId: 'voiceover-guide', order: 1, enabled: true, locked: false, kind: 'audio', role: 'voiceover', segments: [] },
  ]
  const draft = { schemaVersion: 1, timelineId: 'jy068-speed', projectId: 'jy068', revision: 1, parentRevision: null,
    parentRevisionFingerprint: null, status: 'draft', createdAt: '2026-08-12T00:00:00.000Z', durationUs: targetDurationUs,
    orientation: 'portrait', fps: { numerator: 30, denominator: 1 }, source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null },
    tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks) }
  return finalizeRichTimeline(sealRichTimeline(draft))
}

const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  if (desktop?.available !== true || desktop.profileId !== profileId) throw new Error('JY068_PROFILE_UNSUPPORTED')
  const projected = projectRichTimelineToJianyingExport(timeline(), { capabilityRegistry: registry })
  const draftId = `OpenVideo-JY068-speed-${Date.now()}`
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT,
    getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', captionSegments: [], titleSegments: [], keywordHighlights: [],
      timelinePackaging: { ...projected.packaging, sfx_segments: [], effect_segments: [], sticker_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
  const mediaRoot = await mkdtemp(path.join(tmpdir(), mediaPrefix))
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: videoPath }], voiceovers: [] }
  let result = null
  let pendingPath = null
  let released = false
  try {
    await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath])
    result = await writer.writeDraft(request)
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY068_DRAFT_VERIFY_FAILED')
    const encrypted = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
    const root = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy068-speed')
    await mkdir(root, { recursive: true, mode: 0o700 }); await securePrivateRuntimeRoot(root)
    pendingPath = path.join(root, 'pending.json')
    await writeFile(pendingPath, `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, profile_id: desktop.profileId, app_version: desktop.version, initial_speed: initialSpeed, pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
    if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY068_DRAFT_RELEASE_FAILED')
    released = true
    process.stdout.write(`${JSON.stringify({ ok: true, draft_id: draftId, manual_open_required: true, profile: desktop.profileId, initial_speed: '1.25x', change_to: '1.50x' })}\n`)
  } catch (error) {
    if (!released && result) {
      try { await writer.cleanupDraft({ job_id: request.job_id }) } catch {
        try { await writer.cleanupOwnedDraft({ requestId: request.request_id, draftId }) } catch { /* Preserve the original failure. */ }
      }
    }
    if (!released && pendingPath) await rm(pendingPath, { force: true })
    await rm(mediaRoot, { recursive: true, force: true })
    throw error
  }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.message ?? 'JY068_DRAFT_FAILED' })}\n`); process.exitCode = 1 })
