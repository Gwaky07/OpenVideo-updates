[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,
    [Parameter(Mandatory = $true)]
    [string]$GeneratedEvidencePath,
    [Parameter(Mandatory = $true)]
    [string]$ManualEvidencePath
)

$ErrorActionPreference = 'Stop'
$runtimeRoot = [IO.Path]::GetFullPath($RuntimeDataRoot).TrimEnd('\') + '\'
$generatedRoot = [IO.Path]::GetFullPath(
    (Join-Path $runtimeRoot 'jy003-acceptance-evidence')
)
$generatedPath = [IO.Path]::GetFullPath($GeneratedEvidencePath)
$manualPath = [IO.Path]::GetFullPath($ManualEvidencePath)

function Assert-NoReparseBoundary {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CandidatePath,
        [Parameter(Mandatory = $true)]
        [string]$BoundaryPath
    )
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if (
        $candidate -ne $boundary `
        -and -not $candidate.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)
    ) {
        throw 'QA-003 Jianying evidence escaped its private boundary.'
    }
    $currentPath = $candidate
    while ($true) {
        $current = Get-Item -LiteralPath $currentPath -Force
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'QA-003 Jianying evidence cannot traverse a reparse point.'
        }
        if ([IO.Path]::GetFullPath($currentPath).TrimEnd('\') -eq $boundary) { break }
        $currentPath = [IO.Path]::GetDirectoryName($currentPath.TrimEnd('\'))
        if ([string]::IsNullOrWhiteSpace($currentPath)) {
            throw 'QA-003 Jianying evidence boundary could not be verified.'
        }
    }
}

function Test-JsonInteger([object]$Value) {
    return $Value -is [byte] `
        -or $Value -is [int16] `
        -or $Value -is [int32] `
        -or $Value -is [int64]
}

if (
    $generatedPath -eq $manualPath `
    -or [IO.Path]::GetDirectoryName($generatedPath) -ne $generatedRoot `
    -or -not $manualPath.StartsWith($runtimeRoot, [StringComparison]::OrdinalIgnoreCase)
) {
    throw 'QA-003 Jianying evidence paths are outside their private fixed boundaries.'
}
Assert-NoReparseBoundary -CandidatePath $generatedRoot -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $generatedPath -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $manualPath -BoundaryPath $runtimeRoot

$generated = Get-Content -LiteralPath $generatedPath -Raw | ConvertFrom-Json
$manual = Get-Content -LiteralPath $manualPath -Raw | ConvertFrom-Json
$generatedKeys = @(
    'schema_version',
    'kind',
    'generated_at',
    'draft_label',
    'desktop_version',
    'profile_id',
    'provisional',
    'handoff_mode',
    'desktop_opened',
    'output_fingerprint',
    'isolation',
    'claims',
    'media_tracks',
    'authorization_mode',
    'media_policy'
)
$manualKeys = @(
    'schema_version',
    'kind',
    'draft_label',
    'output_fingerprint',
    'desktop_version',
    'opened_at',
    'edit_confirmed'
)
$isolationKeys = @(
    'schema_version',
    'existing_entry_count',
    'before_fingerprint',
    'after_existing_fingerprint',
    'created_draft_id'
)
if (
    @(Compare-Object ($generatedKeys | Sort-Object) @($generated.PSObject.Properties.Name | Sort-Object)).Count -ne 0 `
    -or @(Compare-Object ($manualKeys | Sort-Object) @($manual.PSObject.Properties.Name | Sort-Object)).Count -ne 0 `
    -or @(Compare-Object ($isolationKeys | Sort-Object) @($generated.isolation.PSObject.Properties.Name | Sort-Object)).Count -ne 0
) {
    throw 'QA-003 Jianying evidence schema is not exact.'
}

if (
    $generated.generated_at -isnot [string] `
    -or $manual.opened_at -isnot [string]
) {
    throw 'QA-003 Jianying evidence timestamps must be strings.'
}
$generatedAt = [DateTimeOffset]::Parse($generated.generated_at)
$openedAt = [DateTimeOffset]::Parse($manual.opened_at)
$now = [DateTimeOffset]::UtcNow
$profileMatchesVersion = (
    $generated.profile_id -eq 'jianying-10-9-provisional' `
    -and $generated.desktop_version -match '^10\.9\.'
) -or (
    $generated.profile_id -eq 'jianying-11-1-provisional' `
    -and $generated.desktop_version -match '^11\.1\.'
)
if (
    -not (Test-JsonInteger $generated.schema_version) `
    -or -not (Test-JsonInteger $generated.isolation.schema_version) `
    -or -not (Test-JsonInteger $generated.isolation.existing_entry_count) `
    -or -not (Test-JsonInteger $manual.schema_version) `
    -or $generated.provisional -isnot [bool] `
    -or $generated.desktop_opened -isnot [bool] `
    -or $manual.edit_confirmed -isnot [bool] `
    -or $generated.kind -isnot [string] `
    -or $generated.generated_at -isnot [string] `
    -or $generated.draft_label -isnot [string] `
    -or $generated.desktop_version -isnot [string] `
    -or $generated.profile_id -isnot [string] `
    -or $generated.handoff_mode -isnot [string] `
    -or $generated.output_fingerprint -isnot [string] `
    -or $generated.media_policy -isnot [string] `
    -or $generated.isolation.before_fingerprint -isnot [string] `
    -or $generated.isolation.after_existing_fingerprint -isnot [string] `
    -or $generated.isolation.created_draft_id -isnot [string] `
    -or $manual.kind -isnot [string] `
    -or $manual.draft_label -isnot [string] `
    -or $manual.output_fingerprint -isnot [string] `
    -or $manual.desktop_version -isnot [string] `
    -or $manual.opened_at -isnot [string] `
    -or $generated.schema_version -ne 1 `
    -or $generated.kind -ne 'jy003_acceptance_evidence' `
    -or $null -eq $generated.claims `
    -or $generated.claims.writer_isolation -ne $true `
    -or (
      $generated.claims.real_authorized_video -ne $true -and
      $generated.claims.real_authorized_video -ne $false
    ) `
    -or $generated.media_tracks -isnot [System.Array] `
    -or $generated.media_tracks.Count -lt 1 `
    -or (@($generated.media_tracks) | Where-Object {
      $_.provenance -notin @('real', 'synthetic') -or
      $_.role -isnot [string] -or
      $_.role.Length -lt 1
    }).Count -gt 0 `
    -or -not $profileMatchesVersion `
    -or $generated.provisional -ne $true `
    -or $generated.handoff_mode -ne 'manual_open_required' `
    -or $generated.desktop_opened -ne $false `
    -or $generated.media_policy -ne 'private_acceptance_assets_preserved_until_manual_reopen_confirmation' `
    -or $generated.draft_label -notmatch '^openvideo-jy003-accept-[a-z0-9-]{8,80}$' `
    -or $generated.desktop_version -notmatch '^[0-9]+(?:\.[0-9]+){1,3}$' `
    -or $generated.output_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $generated.isolation.schema_version -ne 1 `
    -or $generated.isolation.existing_entry_count -lt 0 `
    -or $generated.isolation.before_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $generated.isolation.after_existing_fingerprint -ne $generated.isolation.before_fingerprint `
    -or $generated.isolation.created_draft_id -ne $generated.draft_label `
    -or $generatedAt -gt $now.AddMinutes(5) `
    -or $generatedAt -lt $now.AddDays(-30) `
    -or $manual.schema_version -ne 1 `
    -or $manual.kind -ne 'qa003_jianying_manual_open_evidence' `
    -or $manual.draft_label -ne $generated.draft_label `
    -or $manual.output_fingerprint -ne $generated.output_fingerprint `
    -or $manual.desktop_version -ne $generated.desktop_version `
    -or $manual.edit_confirmed -ne $true `
    -or $openedAt -lt $generatedAt `
    -or $openedAt -gt $now.AddMinutes(5)
) {
    throw 'QA-003 Jianying evidence does not prove the generated draft was manually opened and edited.'
}

Write-Output 'QA-003 Jianying evidence verified.'
