[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [int]$ApplyPort = 8803,
    [int]$RollbackPort = 8804,
    [switch]$SkipApply
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
$root = [IO.Path]::GetFullPath($RepositoryRoot)
$exe = Join-Path $root 'dist\OpenVideo.exe'
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'OPENVIDEO_FULL_UPDATE_EXE_MISSING' }
foreach ($port in @($ApplyPort, $RollbackPort)) {
    if ($port -eq 8787) { throw 'OPENVIDEO_ISOLATED_QA_MUST_NOT_USE_PRODUCT_PORT' }
}

function New-IsolatedTree {
    param([int]$Port)
    $iso = Join-Path $env:LOCALAPPDATA ('OpenVideo-iso-' + [guid]::NewGuid().ToString('N'))
    $dataRoot = Join-Path $iso 'data'
    $program = Join-Path $iso 'program'
    $configPath = Join-Path $iso 'config.json'
    New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $program -Force | Out-Null
    $utf8 = [Text.UTF8Encoding]::new($false)
    [IO.File]::WriteAllText((Join-Path $dataRoot '.openvideo-runtime-owner.json'), (@{ schema_version = 1; owner = 'openvideo-local-runtime' } | ConvertTo-Json), $utf8)
    [IO.File]::WriteAllText($configPath, (@{
        schema_version = 1
        runtime_data_root = $dataRoot
        short_video_factory_root = (Join-Path $root 'upstream\short-video-factory')
        pyjianyingdraft_root = (Join-Path $root 'upstream\pyJianYingDraft')
        gateway_port = $Port
    } | ConvertTo-Json), $utf8)
    $officialAnalysis = Join-Path $env:LOCALAPPDATA 'OpenVideo\data\material-analysis'
    $isolatedAnalysis = Join-Path $dataRoot 'material-analysis'
    if (Test-Path -LiteralPath $officialAnalysis -PathType Container) {
        New-Item -ItemType Directory -Path $isolatedAnalysis -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $officialAnalysis 'dependency-installation.json') -Destination $isolatedAnalysis -Force -ErrorAction SilentlyContinue
        foreach ($name in @('dependencies', 'models')) {
            $source = Join-Path $officialAnalysis $name
            $destination = Join-Path $isolatedAnalysis $name
            if ((Test-Path -LiteralPath $source) -and -not (Test-Path -LiteralPath $destination)) {
                cmd /c "mklink /J `"$destination`" `"$source`"" | Out-Null
            }
        }
    }
    [IO.File]::WriteAllText((Join-Path $program 'OLD_MARKER.txt'), 'old', $utf8)
    [IO.File]::WriteAllText((Join-Path $program 'OpenVideo.cmd'), "@echo off`r`nexit /b 0`r`n", $utf8)
    return [pscustomobject]@{ Iso = $iso; Program = $program; ConfigPath = $configPath; Port = $Port }
}

function Invoke-PortableExe {
    param($Tree, [int]$HealthSeconds)
    $previousProgram = $env:OPENVIDEO_PROGRAM_ROOT
    $previousConfig = $env:OPENVIDEO_CONFIG_PATH
    $previousPort = $env:OPENVIDEO_GATEWAY_PORT
    $previousHealth = $env:OPENVIDEO_PORTABLE_HEALTH_SECONDS
    $env:OPENVIDEO_PROGRAM_ROOT = $Tree.Program
    $env:OPENVIDEO_CONFIG_PATH = $Tree.ConfigPath
    $env:OPENVIDEO_GATEWAY_PORT = [string]$Tree.Port
    $env:OPENVIDEO_PORTABLE_HEALTH_SECONDS = [string]$HealthSeconds
    try {
        $process = Start-Process -FilePath $exe -PassThru -WindowStyle Hidden
        $null = $process.WaitForExit(($HealthSeconds + 30) * 1000)
        return $process
    } finally {
        if ($null -eq $previousProgram) { Remove-Item Env:OPENVIDEO_PROGRAM_ROOT -ErrorAction SilentlyContinue } else { $env:OPENVIDEO_PROGRAM_ROOT = $previousProgram }
        if ($null -eq $previousConfig) { Remove-Item Env:OPENVIDEO_CONFIG_PATH -ErrorAction SilentlyContinue } else { $env:OPENVIDEO_CONFIG_PATH = $previousConfig }
        if ($null -eq $previousPort) { Remove-Item Env:OPENVIDEO_GATEWAY_PORT -ErrorAction SilentlyContinue } else { $env:OPENVIDEO_GATEWAY_PORT = $previousPort }
        if ($null -eq $previousHealth) { Remove-Item Env:OPENVIDEO_PORTABLE_HEALTH_SECONDS -ErrorAction SilentlyContinue } else { $env:OPENVIDEO_PORTABLE_HEALTH_SECONDS = $previousHealth }
    }
}

if (-not $SkipApply) {
    $apply = New-IsolatedTree -Port $ApplyPort
    Write-Host "OPENVIDEO_ISOLATED_APPLY_ROOT: $($apply.Iso)"
    $applyProcess = Invoke-PortableExe -Tree $apply -HealthSeconds 300
    $live = $false
    try {
        $probe = Invoke-RestMethod -Uri "http://127.0.0.1:$ApplyPort/api/live" -TimeoutSec 3
        $live = ($probe.live -eq $true)
    } catch {}
    if (-not $live -or -not (Test-Path -LiteralPath (Join-Path $apply.Program 'OpenVideo.exe'))) {
        Write-Host "OPENVIDEO_ISOLATED_APPLY_FAILED: live=$live exit=$($applyProcess.ExitCode)"
        throw 'OPENVIDEO_FULL_UPDATE_APPLY_FAILED'
    }
    if (Test-Path -LiteralPath (Join-Path $apply.Program 'OLD_MARKER.txt')) {
        throw 'OPENVIDEO_FULL_UPDATE_OLD_TREE_NOT_REPLACED'
    }
    Write-Host "OPENVIDEO_ISOLATED_APPLY_OK: http://127.0.0.1:$ApplyPort/api/live"
}

$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $RollbackPort)
$listener.Start()
try {
    $rollback = New-IsolatedTree -Port $RollbackPort
    Write-Host "OPENVIDEO_ISOLATED_ROLLBACK_ROOT: $($rollback.Iso)"
    $rollbackProcess = Invoke-PortableExe -Tree $rollback -HealthSeconds 20
    Start-Sleep -Seconds 2
    if (-not (Test-Path -LiteralPath (Join-Path $rollback.Program 'OLD_MARKER.txt'))) {
        throw 'OPENVIDEO_FULL_UPDATE_ROLLBACK_LOST_OLD_TREE'
    }
    if (Test-Path -LiteralPath (Join-Path $rollback.Program 'OpenVideo.exe')) {
        throw 'OPENVIDEO_FULL_UPDATE_ROLLBACK_LEFT_PARTIAL_NEW_TREE'
    }
    Write-Host "OPENVIDEO_ISOLATED_ROLLBACK_OK: old tree restored exit=$($rollbackProcess.ExitCode)"
} finally {
    $listener.Stop()
}

try { (Invoke-RestMethod -TimeoutSec 2 http://127.0.0.1:8787/api/live) | Out-Null; Write-Host 'OPENVIDEO_OFFICIAL_8787_STILL_LIVE' } catch { throw 'OPENVIDEO_OFFICIAL_PORT_REGRESSED' }
