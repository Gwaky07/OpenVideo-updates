[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot),
    [string]$RuntimeDataRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT,
    [string]$ShortVideoFactoryRoot,
    [switch]$RealAcceptance,
    [string]$JianyingGeneratedEvidencePath,
    [string]$JianyingManualOpenEvidencePath,
    [Nullable[long]]$MinimumFreeDiskBytes,
    [Nullable[long]]$MaximumProcessRssBytes,
    [Nullable[long]]$MaximumElapsedMs
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = [IO.Path]::GetFullPath($RepositoryRoot)

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [scriptblock]$Action
    )
    Write-Host "==> $Name" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Action
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

Push-Location $root
try {
    Invoke-Checked 'QA-003 focused fault and recovery tests' {
        & corepack pnpm --filter '@openvideo/gateway' exec node --test `
            test/local-runtime.test.mjs `
            test/permissive-material-analyzer.test.mjs `
            test/workbench-job-repository.test.mjs `
            test/workbench-job-coordinator.test.mjs `
            test/short-video-factory-electron-bridge.test.mjs `
            test/short-video-factory-provider.test.mjs `
            test/jianying-draft-writer.integration.mjs `
            test/workbench.test.mjs
    }
    Invoke-Checked 'QA-003 final video UI tests' {
        & corepack pnpm --filter '@openvideo/web' exec vitest run `
            src/pages/ProjectDeliveryPage.test.tsx
    }

    if (-not $RealAcceptance) {
        Write-Output 'QA-003 focused verification passed.'
        exit 0
    }

    if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
        $RuntimeDataRoot = [Environment]::GetEnvironmentVariable(
            'OPENVIDEO_RUNTIME_DATA_ROOT',
            'User'
        )
    }
    if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
        throw 'RuntimeDataRoot is required for real acceptance.'
    }
    if ([string]::IsNullOrWhiteSpace($ShortVideoFactoryRoot)) {
        $commonGitDirectory = (& git -C $root rev-parse --git-common-dir).Trim()
        if ($LASTEXITCODE -ne 0) { throw 'Unable to resolve the common Git directory.' }
        $projectRoot = Split-Path -Parent ([IO.Path]::GetFullPath($commonGitDirectory))
        $ShortVideoFactoryRoot = Join-Path $projectRoot 'upstream/short-video-factory'
    }

    $previousRuntimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
    $previousMinimumFreeDiskBytes = $env:OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES
    $previousMaximumProcessRssBytes = $env:OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES
    $previousMaximumElapsedMs = $env:OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS
    $env:OPENVIDEO_RUNTIME_DATA_ROOT = [IO.Path]::GetFullPath($RuntimeDataRoot)
    $env:OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES = if ($null -eq $MinimumFreeDiskBytes) {
        $null
    } else {
        [string]$MinimumFreeDiskBytes
    }
    $env:OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES = if ($null -eq $MaximumProcessRssBytes) {
        $null
    } else {
        [string]$MaximumProcessRssBytes
    }
    $env:OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS = if ($null -eq $MaximumElapsedMs) {
        $null
    } else {
        [string]$MaximumElapsedMs
    }
    & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') `
        -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
        -Stage before
    if ($LASTEXITCODE -ne 0) { throw 'QA-003 before snapshot failed.' }
    try {
        Invoke-Checked 'QA-003 real material analysis and search' {
            & node (Join-Path $PSScriptRoot 'run-em005-real-acceptance.mjs') `
                $env:OPENVIDEO_RUNTIME_DATA_ROOT
        }
        Invoke-Checked 'QA-003 real Director and restart recovery' {
            & node (Join-Path $PSScriptRoot 'run-prod002-real-acceptance.mjs') `
                $env:OPENVIDEO_RUNTIME_DATA_ROOT
        }
        Invoke-Checked 'QA-003 real preview and final MP4' {
            & node (Join-Path $PSScriptRoot 'run-vid002-real-acceptance.mjs') `
                $env:OPENVIDEO_RUNTIME_DATA_ROOT `
                ([IO.Path]::GetFullPath($ShortVideoFactoryRoot)) `
                'zh-CN-XiaoxiaoNeural'
        }
        if ([string]::IsNullOrWhiteSpace($JianyingGeneratedEvidencePath)) {
            $jianyingEvidenceStartedAt = [DateTimeOffset]::UtcNow
            Invoke-Checked 'QA-003 governed Jianying bridge and draft generation' {
                & (Join-Path $PSScriptRoot 'Test-JY003.ps1') `
                    -RepositoryRoot $root `
                    -RequireDesktop `
                    -GenerateRealDraft
            }
            $generatedEvidenceRoot = Join-Path $env:OPENVIDEO_RUNTIME_DATA_ROOT 'jy003-acceptance-evidence'
            $generatedEvidenceFiles = @(
                Get-ChildItem -LiteralPath $generatedEvidenceRoot -File -Filter '*.json' |
                    Where-Object { $_.LastWriteTimeUtc -ge $jianyingEvidenceStartedAt.UtcDateTime }
            )
            if ($generatedEvidenceFiles.Count -ne 1) {
                throw 'QA-003 could not bind exactly one generated Jianying draft evidence file to this run.'
            }
            throw 'QA-003 generated a private Jianying draft; manually open and edit it, then rerun with the generated and manual evidence files.'
        }
        Invoke-Checked 'QA-003 governed Jianying desktop compatibility' {
            & (Join-Path $PSScriptRoot 'Test-JY003.ps1') `
                -RepositoryRoot $root `
                -RequireDesktop
        }
        if ([string]::IsNullOrWhiteSpace($JianyingManualOpenEvidencePath)) {
            throw 'QA-003 requires a private manual-open evidence file for the generated Jianying draft.'
        }
        Invoke-Checked 'QA-003 Jianying manual-open evidence' {
            & (Join-Path $PSScriptRoot 'Test-QA003JianyingEvidence.ps1') `
                -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
                -GeneratedEvidencePath $JianyingGeneratedEvidencePath `
                -ManualEvidencePath $JianyingManualOpenEvidencePath
        }
        Invoke-Checked 'QA-003 sanitized real scale evidence' {
            & node (Join-Path $PSScriptRoot 'measure-qa003-real-baseline.mjs') `
                $env:OPENVIDEO_RUNTIME_DATA_ROOT
        }
    }
    finally {
        & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') `
            -RuntimeDataRoot $env:OPENVIDEO_RUNTIME_DATA_ROOT `
            -Stage after
        $env:OPENVIDEO_RUNTIME_DATA_ROOT = $previousRuntimeRoot
        $env:OPENVIDEO_QA003_MINIMUM_FREE_DISK_BYTES = $previousMinimumFreeDiskBytes
        $env:OPENVIDEO_QA003_MAXIMUM_PROCESS_RSS_BYTES = $previousMaximumProcessRssBytes
        $env:OPENVIDEO_QA003_MAXIMUM_ELAPSED_MS = $previousMaximumElapsedMs
    }

    Write-Output 'QA-003 real acceptance completed; scale evidence records the current baseline without a fixed capacity gate.'
}
finally {
    Pop-Location
}
