# REL-HOTFIX-021b / Push-OpenVideoSafe wrapper.
#
# Goal: survive intermittent failures from the user-global
# `http.proxy=http://127.0.0.1:20081` (or any future SSL-inspecting
# proxy) without rewriting `~/.gitconfig`. Operates strictly at the
# process level (`git -c http.proxy= ...`). On any push that hits a
# known network failure token, retries once with proxy disabled.
#
# Hard constraints (AGENTS.md + this task doc):
#   * Never invoke `git config --global`.
#   * Never modify env vars, shell aliases, or any file outside this
#     repository and `OPENVIDEO_RUNTIME_DATA_ROOT/logs/push-helper/`.
#   * Refuse `git push ... main` unless the caller explicitly supplied
#     `-ForceWithLease` *and* the `OPENVIDEO_FORCE_WITH_LEASE_TOKEN`
#     env var.
#
# Parameters:
#   -Remote                name of the remote (default 'origin').
#   -Refspec               refspec (default 'main').
#   -Branch                optional branch convenience that maps to
#                          `-Refspec task/<id>-<slug>`.
#   -DryRun                if set, run `git push --dry-run` instead.
#   -SkipRetry             if set, do not perform the proxy-offline
#                          fallback (useful in tests).
#   -ForceWithLease        DANGEROUS: allow non-fast-forward push on
#                          `main`. Must be paired with the env var
#                          `OPENVIDEO_FORCE_WITH_LEASE_TOKEN` (any
#                          non-empty value).
#
# Exit codes:
#   0   push completed (either first attempt or successful retry).
#   100 push blocked after retry exhausted; consult the regression log.
#   2   usage error.
#
# Logs:
#   %LOCALAPPDATA%\OpenVideo\logs\push-helper\<yyyyMMddTHHmmssZ>.log
#   (or `$env:OPENVIDEO_RUNTIME_DATA_ROOT/logs/push-helper/<...>.log`
#   when the runtime root override is set).

[CmdletBinding()]
param(
    [string]$Remote = 'origin',
    [string]$Refspec = 'main',
    [string]$Branch = '',
    [switch]$DryRun,
    [switch]$SkipRetry,
    [switch]$ForceWithLease
)

$ErrorActionPreference = 'Stop'

function Get-OpenVideoPushLogRoot {
    param()
    $runtimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
    if ([string]::IsNullOrWhiteSpace($runtimeRoot)) {
        $runtimeRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo'
    }
    $logRoot = Join-Path $runtimeRoot 'logs/push-helper'
    if (-not (Test-Path -LiteralPath $logRoot)) {
        New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
    }
    return $logRoot
}

function Write-OpenVideoPushLogEntry {
    param(
        [Parameter(Mandatory = $true)][string]$LogRoot,
        [Parameter(Mandatory = $true)][string]$Event,
        [Parameter(Mandatory = $true)][string]$Remote,
        [Parameter(Mandatory = $true)][string]$Refspec,
        [int]$DurationMs = 0,
        [int]$Attempt = 0,
        [string]$ProxyMode = 'inherit',
        [string]$Outcome = '',
        [string]$LastStderr = '',
        [int]$LastExitCode = 0
    )
    $timestamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
    $redact = {
        param($text)
        if ([string]::IsNullOrEmpty($text)) { return '' }
        $out = $text -replace '[?&](?:gh_[a-z0-9_]+|access_token|token|password)=[^&\r\n\s]+', '$1=<redacted>'
        $out = $out -replace 'ssh://[^@\s]+@', 'ssh://<redacted>@'
        $out
    }
    $safeStderr = & $redact $LastStderr
    $entry = [pscustomobject]@{
        timestamp    = $timestamp
        pid          = $PID
        event        = $Event
        remote       = $Remote
        refspec      = $Refspec
        attempt      = $Attempt
        proxy_mode   = $ProxyMode
        outcome      = $Outcome
        duration_ms  = $DurationMs
        exit_code    = $LastExitCode
        last_stderr  = $safeStderr
    } | ConvertTo-Json -Compress -Depth 4
    $path = Join-Path $LogRoot ("{0}-pid{1}.jsonl" -f $timestamp, $PID)
    Add-Content -LiteralPath $path -Value $entry -Encoding UTF8
}

function Invoke-GitPushOnce {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$RepoRoot,
        [Parameter(Mandatory = $true)][string]$Remote,
        [Parameter(Mandatory = $true)][string]$Refspec,
        [bool]$UseProxyOff,
        [bool]$DryRun,
        [bool]$AllowForce
    )
    $args = @('-C', $RepoRoot, 'push')
    if ($DryRun) { $args += '--dry-run' }
    if ($AllowForce) { $args += '--force-with-lease' }
    $args += @($Remote, $Refspec)
    if ($UseProxyOff) {
        # Process-local overrides only; never written to .gitconfig.
        $envPrefix = @(
            'GIT_CONFIG_COUNT=2',
            'GIT_CONFIG_KEY_0=http.proxy',
            'GIT_CONFIG_VALUE_0=',
            'GIT_CONFIG_KEY_1=https.proxy',
            'GIT_CONFIG_VALUE_1=',
            'GIT_CONFIG_KEY_2=http.sslverify',
            'GIT_CONFIG_VALUE_2=true'
        )
        $originalPrefix = @{
            'GIT_CONFIG_COUNT'    = $env:GIT_CONFIG_COUNT
            'GIT_CONFIG_KEY_0'    = $env:GIT_CONFIG_KEY_0
            'GIT_CONFIG_VALUE_0'  = $env:GIT_CONFIG_VALUE_0
            'GIT_CONFIG_KEY_1'    = $env:GIT_CONFIG_KEY_1
            'GIT_CONFIG_VALUE_1'  = $env:GIT_CONFIG_VALUE_1
            'GIT_CONFIG_KEY_2'    = $env:GIT_CONFIG_KEY_2
            'GIT_CONFIG_VALUE_2'  = $env:GIT_CONFIG_VALUE_2
            'GIT_HTTP_LOW_TIME_LIMIT' = $env:GIT_HTTP_LOW_TIME_LIMIT
        }
        try {
            $env:GIT_CONFIG_COUNT = '3'
            $env:GIT_CONFIG_KEY_0 = 'http.proxy'
            $env:GIT_CONFIG_VALUE_0 = ''
            $env:GIT_CONFIG_KEY_1 = 'https.proxy'
            $env:GIT_CONFIG_VALUE_1 = ''
            $env:GIT_CONFIG_KEY_2 = 'http.sslverify'
            $env:GIT_CONFIG_VALUE_2 = 'true'
            $env:GIT_HTTP_LOW_TIME_LIMIT = '20'
            $output = & git @args 2>&1
            $code = $LASTEXITCODE
        } finally {
            foreach ($key in @('GIT_CONFIG_COUNT','GIT_CONFIG_KEY_0','GIT_CONFIG_VALUE_0','GIT_CONFIG_KEY_1','GIT_CONFIG_VALUE_1','GIT_CONFIG_KEY_2','GIT_CONFIG_VALUE_2','GIT_HTTP_LOW_TIME_LIMIT')) {
                $orig = $originalPrefix[$key]
                if ($null -eq $orig) {
                    Remove-Item "Env:$key" -ErrorAction SilentlyContinue
                } else {
                    Set-Item "Env:$key" -Value $orig
                }
            }
        }
    } else {
        $output = & git @args 2>&1
        $code = $LASTEXITCODE
    }
    $stderr = ($output | Where-Object { $_ -is [System.Management.Automation.ErrorRecord] }) -join "`n"
    if ([string]::IsNullOrEmpty($stderr)) {
        $stderr = ($output | Out-String).Trim()
    }
    return [pscustomobject]@{
        ExitCode = $code
        StdOut = $output
        StdErr = $stderr
    }
}

function Test-PushOutputNeedsRetry {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$StdErr)
    if ([string]::IsNullOrWhiteSpace($StdErr)) { return $false }
    foreach ($token in @(
        'Connection was reset',
        'OpenSSL SSL_read',
        'SSL_read: Connection',
        'Failed to connect',
        'Timed out',
        'Could not resolve host',
        'proxyconnect',
        'Port 443',
        'Connection aborted',
        'unexpected EOF',
        'gnutls_handshake'
    )) {
        if ($StdErr.Contains($token)) { return $true }
    }
    return $false
}

if ($Branch) {
    if ($Refspec -ne 'main') {
        Write-Error "OPENVIDEO_PUSH_USAGE: -Branch and -Refspec are mutually exclusive." -ErrorAction Stop
        exit 2
    }
    $Refspec = "task/$Branch"
}

# Locate repo root.
$repoRoot = & git rev-parse --show-toplevel 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Error "OPENVIDEO_PUSH_NOT_A_REPO: $repoRoot" -ErrorAction Stop
    exit 2
}

# Guard against accidental force-push of main.
if ($Refspec -eq 'main' -and $ForceWithLease) {
    $token = $env:OPENVIDEO_FORCE_WITH_LEASE_TOKEN
    if ([string]::IsNullOrEmpty($token)) {
        Write-Error "OPENVIDEO_PUSH_FORCE_TOKEN_MISSING: refusing -ForceWithLease on main." -ErrorAction Stop
        exit 2
    }
}

$logRoot = Get-OpenVideoPushLogRoot

# Attempt 1: inherit user config (including proxy).
$sw = [System.Diagnostics.Stopwatch]::StartNew()
$first = Invoke-GitPushOnce -RepoRoot $repoRoot -Remote $Remote -Refspec $Refspec -UseProxyOff:$false -DryRun:$DryRun -AllowForce:$ForceWithLease
$sw.Stop()

if ($first.ExitCode -eq 0) {
    Write-Output $first.StdOut
    exit 0
}

$needsRetry = Test-PushOutputNeedsRetry -StdErr $first.StdErr
if ((-not $needsRetry) -or $SkipRetry) {
    Write-Output $first.StdOut
    Write-Error "OPENVIDEO_PUSH_FAILED attempt=1 mode=inherit exit=$($first.ExitCode) - no proxy-offline retry invoked." -ErrorAction Stop
    exit $first.ExitCode
}

# Log so we have evidence of the fallback invocation.
Write-OpenVideoPushLogEntry -LogRoot $logRoot -Event 'retry_invoked_proxy_offline' -Remote $Remote -Refspec $Refspec -Attempt 1 -ProxyMode 'inherit' -Outcome 'failed' -LastStderr $first.StdErr -LastExitCode $first.ExitCode

# Attempt 2: per-process override (never persisted).
$sw = [System.Diagnostics.Stopwatch]::StartNew()
$second = Invoke-GitPushOnce -RepoRoot $repoRoot -Remote $Remote -Refspec $Refspec -UseProxyOff:$true -DryRun:$DryRun -AllowForce:$ForceWithLease
$sw.Stop()

$outcome = if ($second.ExitCode -eq 0) { 'succeeded' } else { 'failed' }
Write-OpenVideoPushLogEntry -LogRoot $logRoot -Event ('retry_{0}_proxy_offline' -f $outcome) -Remote $Remote -Refspec $Refspec -Attempt 2 -ProxyMode 'override_off' -Outcome $outcome -LastStderr $second.StdErr -LastExitCode $second.ExitCode

if ($second.ExitCode -eq 0) {
    Write-Output $second.StdOut
    exit 0
}

Write-Output $second.StdOut
Write-Error "OPENVIDEO_PUSH_BLOCKED attempt=2 mode=override_off exit=$($second.ExitCode) - both proxy and direct paths failed." -ErrorAction Stop
exit 100
