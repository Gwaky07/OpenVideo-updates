[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot),
    [switch]$RequireDesktop,
    [switch]$GenerateRealDraft
)

$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($RepositoryRoot)
$manifestPath = Join-Path $root 'config/pyjianyingdraft-upstream.json'
$compatibilityPath = Join-Path $root 'config/jianying-compatibility.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.repository -ne 'https://github.com/GuanYixuan/pyJianYingDraft.git' `
    -or $manifest.commit -ne 'c3318066d964744e2bfc66f75c71745fe8cea52a' `
    -or $manifest.license -ne 'Apache-2.0') {
    throw 'The governed pyJianYingDraft manifest is invalid.'
}
if (-not (Test-Path -LiteralPath $compatibilityPath -PathType Leaf)) {
    throw 'The governed Jianying compatibility matrix is unavailable.'
}

$git = (Get-Command git.exe -ErrorAction Stop).Source
$node = (Get-Command node.exe -ErrorAction Stop).Source
$python = (Get-Command python.exe -ErrorAction Stop).Source
$corepack = (Get-Command corepack.cmd -ErrorAction Stop).Source
$commonGitDirectory = (& $git -C $root rev-parse --git-common-dir).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Unable to resolve the OpenVideo common Git directory.' }
$totalProjectRoot = Split-Path -Parent ([IO.Path]::GetFullPath($commonGitDirectory))
$upstreamRoot = Join-Path $totalProjectRoot 'upstream/pyJianYingDraft'
if (-not (Test-Path -LiteralPath $upstreamRoot -PathType Container)) {
    throw 'The governed pyJianYingDraft checkout is unavailable.'
}
$repository = (& $git -C $upstreamRoot remote get-url origin).Trim()
$commit = (& $git -C $upstreamRoot rev-parse HEAD).Trim()
$status = (& $git -C $upstreamRoot status --porcelain --untracked-files=all) -join "`n"
$license = Get-Content -LiteralPath (Join-Path $upstreamRoot 'LICENSE') -Raw
$normalizedRepository = ($repository.TrimEnd('/') -replace '\.git$', '').ToLowerInvariant()
$normalizedManifestRepository = ($manifest.repository.TrimEnd('/') -replace '\.git$', '').ToLowerInvariant()
if ($normalizedRepository -ne $normalizedManifestRepository `
    -or $commit -ne $manifest.commit `
    -or -not [string]::IsNullOrWhiteSpace($status) `
    -or $license -notmatch 'Apache License\s+Version 2\.0') {
    throw 'The governed pyJianYingDraft checkout failed URL, commit, license, or clean-tree validation.'
}

$previousModuleRoot = $env:OPENVIDEO_JY002_PYTHON_MODULE_ROOT
$previousPython = $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE
try {
    $env:OPENVIDEO_JY002_PYTHON_MODULE_ROOT = $upstreamRoot
    $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE = $python
    & $corepack pnpm --filter '@openvideo/gateway' exec node --test `
        test/jianying-local-environment.test.mjs `
        test/jy003-real-acceptance-script.test.mjs `
        test/jianying-voiceover-provider.test.mjs `
        test/jianying-workbench-bridge.test.mjs `
        test/jianying-draft-writer.integration.mjs `
        test/workbench-job-coordinator.test.mjs `
        test/workbench.test.mjs
    if ($LASTEXITCODE -ne 0) { throw 'JY-003 focused tests failed.' }
    & $corepack pnpm --filter '@openvideo/gateway' typecheck
    if ($LASTEXITCODE -ne 0) { throw 'JY-003 Gateway typecheck failed.' }
}
finally {
    $env:OPENVIDEO_JY002_PYTHON_MODULE_ROOT = $previousModuleRoot
    $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE = $previousPython
}

$desktopProbe = & $node --input-type=module -e "Promise.all([import('node:fs/promises'),import('./apps/gateway/src/jianying-local-environment.mjs')]).then(async ([fs,m])=>{try{const compatibilityManifest=JSON.parse(await fs.readFile('./config/jianying-compatibility.json','utf8'));const d=await m.detectJianyingDesktop({compatibilityManifest});console.log(JSON.stringify({available:true,version:d.version,profileId:d.profileId,provisional:d.provisional,capabilities:d.capabilities}))}catch(e){console.log(JSON.stringify({available:false,code:e.code||'JY002_DESKTOP_VERSION_UNSUPPORTED'}));process.exitCode=2}})"
$desktopExit = $LASTEXITCODE
if ($desktopExit -ne 0) {
    if ($RequireDesktop) { throw 'No compatible local Jianying installation is available.' }
    Write-Warning 'Compatible local Jianying desktop acceptance remains blocked; no synthetic result is counted as desktop-open evidence.'
    Write-Host 'JY-003 automated bridge checks passed; real desktop-open acceptance remains blocked.' -ForegroundColor Yellow
}
else {
    Write-Host $desktopProbe
    Write-Host 'JY-003 automated bridge checks passed; generation requires a manual-open acceptance and never counts as desktop automation.' -ForegroundColor Yellow
}

if ($GenerateRealDraft) {
    if ([string]::IsNullOrWhiteSpace($env:OPENVIDEO_RUNTIME_DATA_ROOT)) {
        throw 'OPENVIDEO_RUNTIME_DATA_ROOT is required for real draft generation.'
    }
    $previousUpstreamRoot = $env:OPENVIDEO_PYJIANYINGDRAFT_ROOT
    try {
        $env:OPENVIDEO_PYJIANYINGDRAFT_ROOT = $upstreamRoot
        & $node (Join-Path $root 'scripts/jy003-real-acceptance.mjs')
        if ($LASTEXITCODE -ne 0) { throw 'JY-003 isolated real draft generation failed.' }
    }
    finally {
        $env:OPENVIDEO_PYJIANYINGDRAFT_ROOT = $previousUpstreamRoot
    }
}

$global:LASTEXITCODE = 0
exit 0
