[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [int]$GatewayPort = 8798,
    [switch]$SkipLive
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$root = [IO.Path]::GetFullPath($RepositoryRoot)
if ($GatewayPort -eq 8787) { throw 'OPENVIDEO_ISOLATED_QA_MUST_NOT_USE_PRODUCT_PORT' }
if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'OPENVIDEO_ISOLATED_QA_LOCALAPPDATA_REQUIRED' }

# Keep the real LOCALAPPDATA so Node/Python stay visible. Isolate only the
# OpenVideo config/data/program tree under a sibling folder.
$iso = Join-Path $env:LOCALAPPDATA ('OpenVideo-iso-' + [guid]::NewGuid().ToString('N'))
$configPath = Join-Path $iso 'config.json'
$dataRoot = Join-Path $iso 'data'
New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
$utf8 = [Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText(
    (Join-Path $dataRoot '.openvideo-runtime-owner.json'),
    (@{ schema_version = 1; owner = 'openvideo-local-runtime' } | ConvertTo-Json),
    $utf8
)
[IO.File]::WriteAllText(
    $configPath,
    (@{
        schema_version = 1
        runtime_data_root = $dataRoot
        short_video_factory_root = (Join-Path $root 'upstream\short-video-factory')
        pyjianyingdraft_root = (Join-Path $root 'upstream\pyJianYingDraft')
        gateway_port = $GatewayPort
    } | ConvertTo-Json),
    $utf8
)
$officialAnalysis = Join-Path $env:LOCALAPPDATA 'OpenVideo\data\material-analysis'
$isolatedAnalysis = Join-Path $dataRoot 'material-analysis'
if (Test-Path -LiteralPath $officialAnalysis -PathType Container) {
    New-Item -ItemType Directory -Path $isolatedAnalysis -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $officialAnalysis 'dependency-installation.json') -Destination $isolatedAnalysis -Force -ErrorAction SilentlyContinue
    foreach ($name in @('dependencies', 'models')) {
        $source = Join-Path $officialAnalysis $name
        $destination = Join-Path $isolatedAnalysis $name
        if ((Test-Path -LiteralPath $source) -and -not (Test-Path -LiteralPath $destination)) {
            cmd /c "mklink /J `"$destination`" `"$source`"" | Out-Null
        }
    }
}

$env:OPENVIDEO_CONFIG_PATH = $configPath
$env:OPENVIDEO_GATEWAY_PORT = [string]$GatewayPort
$env:OPENVIDEO_PROGRAM_ROOT = Join-Path $iso 'program'
Remove-Item Env:OPENVIDEO_LAUNCHER_INTERACTIVE -ErrorAction SilentlyContinue

Write-Host "OPENVIDEO_ISOLATED_QA_ROOT: $iso"
Write-Host "OPENVIDEO_ISOLATED_QA_PORT: $GatewayPort"
Write-Host "OPENVIDEO_ISOLATED_QA_OFFICIAL_PORT_UNTOUCHED: 8787"

$liveUrl = "http://127.0.0.1:$GatewayPort/api/live"
if ($SkipLive) {
    Write-Host 'OPENVIDEO_ISOLATED_QA_LIVE_SKIPPED'
    return [pscustomobject]@{ IsoRoot = $iso; ConfigPath = $configPath; Port = $GatewayPort }
}

$startLog = Join-Path $iso 'start.log'
$launcher = Start-Process -FilePath 'powershell.exe' -ArgumentList @(
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $root 'scripts\Start-OpenVideo.ps1'),
    '-RepositoryRoot', $root,
    '-ConfigPath', $configPath,
    '-NoBrowser'
) -PassThru -WindowStyle Hidden -RedirectStandardOutput $startLog -RedirectStandardError (Join-Path $iso 'start.err.log')

$healthy = $false
$deadline = [DateTime]::UtcNow.AddSeconds(180)
while ([DateTime]::UtcNow -lt $deadline) {
    if ($launcher.HasExited -and $launcher.ExitCode -ne 0) { break }
    try {
        $probe = Invoke-RestMethod -Uri $liveUrl -TimeoutSec 2
        if ($probe.live -eq $true) { $healthy = $true; break }
    } catch {}
    Start-Sleep -Seconds 2
}

if (-not $healthy) {
    Write-Host 'OPENVIDEO_ISOLATED_QA_LIVE_FAILED'
    $logRoot = Join-Path $dataRoot 'launcher-logs'
    if (Test-Path -LiteralPath $logRoot) {
        Get-ChildItem -LiteralPath $logRoot -File -ErrorAction SilentlyContinue |
            ForEach-Object { Write-Host ("OPENVIDEO_ISOLATED_QA_LOG: " + $_.Name) }
    }
    throw 'OPENVIDEO_READY_TIMEOUT'
}
Write-Host "OPENVIDEO_ISOLATED_QA_LIVE_OK: $liveUrl"
return [pscustomobject]@{
    IsoRoot = $iso
    ConfigPath = $configPath
    Port = $GatewayPort
    Live = $true
    LauncherPid = $launcher.Id
}
