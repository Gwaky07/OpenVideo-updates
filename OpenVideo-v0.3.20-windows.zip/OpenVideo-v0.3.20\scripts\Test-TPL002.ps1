[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$pnpmCommand = Get-Command pnpm.cmd -ErrorAction SilentlyContinue
$pnpm = if ($pnpmCommand) { $pnpmCommand.Source } else { (Get-Command corepack.cmd -ErrorAction Stop).Source }

Push-Location $RepositoryRoot
try {
    if ($pnpmCommand) {
        & $pnpm --filter '@openvideo/gateway' exec node --test test/reference-template-contracts.test.mjs
    } else {
        & $pnpm pnpm --filter '@openvideo/gateway' exec node --test test/reference-template-contracts.test.mjs
    }
    if ($LASTEXITCODE -ne 0) { throw 'TPL-002 reference template contract tests failed.' }
}
finally {
    Pop-Location
}

Write-Host 'OpenVideo TPL-002 reference template contract checks passed.' -ForegroundColor Green
