[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,
    [Parameter(Mandatory = $true)]
    [string]$GeneratedEvidencePath,
    [Parameter(Mandatory = $true)]
    [string]$ManualEvidencePath
)

$ErrorActionPreference = 'Stop'
$runtimeRoot = [IO.Path]::GetFullPath($RuntimeDataRoot).TrimEnd('\') + '\'
$generatedRoot = [IO.Path]::GetFullPath(
    (Join-Path $runtimeRoot 'evidence/qa-007')
)
$generatedPath = [IO.Path]::GetFullPath($GeneratedEvidencePath)
$manualPath = [IO.Path]::GetFullPath($ManualEvidencePath)

function Assert-NoReparseBoundary {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CandidatePath,
        [Parameter(Mandatory = $true)]
        [string]$BoundaryPath
    )
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if (
        $candidate -ne $boundary `
        -and -not $candidate.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)
    ) {
        throw 'QA-007 Jianying evidence escaped its private boundary.'
    }
    $currentPath = $candidate
    while ($true) {
        $current = Get-Item -LiteralPath $currentPath -Force
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'QA-007 Jianying evidence cannot traverse a reparse point.'
        }
        if ([IO.Path]::GetFullPath($currentPath).TrimEnd('\') -eq $boundary) { break }
        $currentPath = [IO.Path]::GetDirectoryName($currentPath.TrimEnd('\'))
        if ([string]::IsNullOrWhiteSpace($currentPath)) {
            throw 'QA-007 Jianying evidence boundary could not be verified.'
        }
    }
}

function Test-JsonInteger([object]$Value) {
    return $Value -is [byte] `
        -or $Value -is [int16] `
        -or $Value -is [int32] `
        -or $Value -is [int64]
}

if (
    $generatedPath -eq $manualPath `
    -or [IO.Path]::GetDirectoryName($generatedPath) -ne $generatedRoot `
    -or -not $manualPath.StartsWith($runtimeRoot, [StringComparison]::OrdinalIgnoreCase)
) {
    throw 'QA-007 Jianying evidence paths are outside their private fixed boundaries.'
}
Assert-NoReparseBoundary -CandidatePath $generatedRoot -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $generatedPath -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $manualPath -BoundaryPath $runtimeRoot

$generated = Get-Content -LiteralPath $generatedPath -Raw | ConvertFrom-Json
$manual = Get-Content -LiteralPath $manualPath -Raw | ConvertFrom-Json
$generatedKeys = @(
    'schema_version',
    'completed_at',
    'project_id_hash',
    'initial_revision',
    'timeline_id_hash',
    'timeline_revision',
    'timeline_revision_fingerprint',
    'editor_job_status',
    'preview_job_status',
    'preview_output_fingerprint',
    'jianying_job_status',
    'jianying_output_fingerprint',
    'same_revision',
    'public_response_leak_count'
)
$manualKeys = @(
    'schema_version',
    'kind',
    'timeline_revision_fingerprint',
    'jianying_output_fingerprint',
    'opened_at',
    'edit_confirmed'
)
if (
    @(Compare-Object ($generatedKeys | Sort-Object) @($generated.PSObject.Properties.Name | Sort-Object)).Count -ne 0 `
    -or @(Compare-Object ($manualKeys | Sort-Object) @($manual.PSObject.Properties.Name | Sort-Object)).Count -ne 0
) {
    throw 'QA-007 Jianying evidence schema is not exact.'
}

$completedAt = [DateTimeOffset]::Parse($generated.completed_at)
$openedAt = [DateTimeOffset]::Parse($manual.opened_at)
$now = [DateTimeOffset]::UtcNow
if (
    -not (Test-JsonInteger $generated.schema_version) `
    -or -not (Test-JsonInteger $generated.initial_revision) `
    -or -not (Test-JsonInteger $generated.timeline_revision) `
    -or -not (Test-JsonInteger $generated.public_response_leak_count) `
    -or -not (Test-JsonInteger $manual.schema_version) `
    -or $generated.same_revision -isnot [bool] `
    -or $manual.edit_confirmed -isnot [bool] `
    -or $generated.schema_version -ne 1 `
    -or $manual.schema_version -ne 1 `
    -or $generated.initial_revision -lt 1 `
    -or $generated.timeline_revision -le $generated.initial_revision `
    -or $generated.project_id_hash -notmatch '^[a-f0-9]{64}$' `
    -or $generated.timeline_id_hash -notmatch '^[a-f0-9]{64}$' `
    -or $generated.timeline_revision_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $generated.preview_output_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $generated.jianying_output_fingerprint -notmatch '^[a-f0-9]{64}$' `
    -or $generated.editor_job_status -ne 'succeeded' `
    -or $generated.preview_job_status -ne 'succeeded' `
    -or $generated.jianying_job_status -ne 'succeeded' `
    -or $generated.same_revision -ne $true `
    -or $generated.public_response_leak_count -ne 0 `
    -or $manual.kind -ne 'qa007_jianying_manual_open_evidence' `
    -or $manual.timeline_revision_fingerprint -ne $generated.timeline_revision_fingerprint `
    -or $manual.jianying_output_fingerprint -ne $generated.jianying_output_fingerprint `
    -or $manual.edit_confirmed -ne $true `
    -or $completedAt -gt $now.AddMinutes(5) `
    -or $completedAt -lt $now.AddDays(-30) `
    -or $openedAt -lt $completedAt `
    -or $openedAt -gt $now.AddMinutes(5)
) {
    throw 'QA-007 evidence does not prove the Editor-bound draft was manually opened and edited.'
}

Write-Output 'QA-007 Jianying evidence verified.'
