[CmdletBinding()]
param(
    [string]$RuntimeDataRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT,
    [switch]$RealAcceptance
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repositoryRoot = Split-Path $PSScriptRoot -Parent
Push-Location $repositoryRoot
try {
    & corepack pnpm --filter '@openvideo/gateway' exec node --test `
        test/material-analysis-contracts.test.mjs `
        test/material-analysis-dependencies.test.mjs `
        test/permissive-material-analyzer.test.mjs `
        test/workbench.test.mjs
    if ($LASTEXITCODE -ne 0) { throw 'EM-005 focused tests failed.' }

    & corepack pnpm --filter '@openvideo/gateway' typecheck
    if ($LASTEXITCODE -ne 0) { throw 'EM-005 Gateway typecheck failed.' }

    $serverSource = Get-Content -LiteralPath 'apps/gateway/src/server.mjs' -Raw
    if (-not $serverSource.Contains('createPermissiveMaterialAnalyzer')) {
        throw 'Production server is not wired to the independent analyzer.'
    }
    if ($serverSource.Contains('createEditMindCapability')) {
        throw 'Production server still wires Edit Mind.'
    }

    if ($RealAcceptance) {
        if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) { throw 'RuntimeDataRoot is required for real acceptance.' }
        & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') -RuntimeDataRoot $RuntimeDataRoot -Stage before
        if ($LASTEXITCODE -ne 0) { throw 'EM-005 before snapshot failed.' }

        $runningEditMind = @()
        if (Get-Command docker -ErrorAction SilentlyContinue) {
            & cmd.exe /d /c 'docker info >nul 2>nul'
            if ($LASTEXITCODE -eq 0) {
                $runningEditMind = @(& docker ps --format '{{.Names}}' | Where-Object { $_ -match 'edit.?mind' })
            }
        }
        if ($runningEditMind.Count -gt 0) { throw 'Edit Mind containers must be stopped for independent acceptance.' }

        & node (Join-Path $PSScriptRoot 'run-em005-real-acceptance.mjs') $RuntimeDataRoot
        if ($LASTEXITCODE -ne 0) { throw 'EM-005 real acceptance failed.' }

        & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') -RuntimeDataRoot $RuntimeDataRoot -Stage after
        if ($LASTEXITCODE -ne 0) { throw 'EM-005 after snapshot failed.' }
    }

    Write-Output 'EM-005 verification passed.'
} finally {
    Pop-Location
}
