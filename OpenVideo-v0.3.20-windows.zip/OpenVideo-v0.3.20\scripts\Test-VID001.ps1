[CmdletBinding()]
param([string]$RepositoryRoot = (Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference = 'Stop'
$root = Join-Path ([IO.Path]::GetTempPath()) ('openvideo-vid001-test-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root | Out-Null
try {
  $script = Join-Path $RepositoryRoot 'scripts/Generate-SyntheticPreview.ps1'
  $plan = Join-Path $root 'edit_plan.json'
  $output = Join-Path $root 'preview.mp4'
  @{ schema_version=1; kind='edit_plan'; items=@(@{ item_id='item-1'; status='selected'; start=0; end=1.2 },@{ item_id='item-2'; status='selected'; start=2; end=3.5 }) } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $plan -Encoding utf8
  $result = & $script -EditPlanPath $plan -OutputPath $output -OutputRoot $root | ConvertFrom-Json
  if (-not (Test-Path -LiteralPath $output -PathType Leaf) -or $result.selected_items -ne 2 -or (Get-Item $output).Length -le 0) { throw 'valid preview failed' }
  @{ schema_version=1; kind='edit_plan'; items=@(@{ item_id='long'; status='selected'; start=0; end=999999 }) } | ConvertTo-Json -Depth 5 | Set-Content $plan -Encoding utf8
  try { & $script -EditPlanPath $plan -OutputPath (Join-Path $root 'bad.mp4') -OutputRoot $root | Out-Null; throw 'oversized duration was accepted' } catch { if ($_.Exception.Message -notmatch 'safety limit') { throw } }
  try { & $script -EditPlanPath $plan -OutputPath (Join-Path ([IO.Path]::GetTempPath()) 'escape.mp4') -OutputRoot $root | Out-Null; throw 'path escape was accepted' } catch { if ($_.Exception.Message -notmatch 'inside OutputRoot') { throw } }
  @{ schema_version=1; kind='edit_plan'; items=@(@{ item_id='missing-time'; status='selected'; end=1 }) } | ConvertTo-Json -Depth 5 | Set-Content $plan -Encoding utf8
  try { & $script -EditPlanPath $plan -OutputPath (Join-Path $root 'missing.mp4') -OutputRoot $root | Out-Null; throw 'missing timing was accepted' } catch { if ($_.Exception.Message -notmatch 'start and end are required') { throw } }
  'VID-001 synthetic preview acceptance passed.'
} finally {
  Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path ([IO.Path]::GetTempPath()) 'escape.mp4') -Force -ErrorAction SilentlyContinue
}