param([Parameter(Mandatory=$true)][string]$LiteralPath, [Parameter(Mandatory=$true)][string]$RootPath, [long]$MaxBytes = 268435456)
$ErrorActionPreference = 'Stop'
$type = @"
using System;
using System.IO;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
public static class OpenVideoNativeRead {
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern uint GetFinalPathNameByHandle(SafeFileHandle handle, System.Text.StringBuilder path, uint length, uint flags);
  static string FinalPath(SafeFileHandle handle) { var b=new System.Text.StringBuilder(32768); var n=GetFinalPathNameByHandle(handle,b,(uint)b.Capacity,0); if(n==0 || n>=b.Capacity) throw new IOException("path failed"); return b.ToString(); }
  public static byte[] Read(string name, string rootName, long maxBytes) {
    const uint GENERIC_READ=0x80000000, FILE_SHARE_READ=1, FILE_SHARE_WRITE=2, OPEN_EXISTING=3, OPEN_REPARSE_POINT=0x00200000, BACKUP_SEMANTICS=0x02000000;
    using (var root=CreateFile(rootName, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, OPEN_REPARSE_POINT|BACKUP_SEMANTICS, IntPtr.Zero))
    using (var handle=CreateFile(name, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, OPEN_REPARSE_POINT|BACKUP_SEMANTICS, IntPtr.Zero)) {
      if (root.IsInvalid) throw new IOException("root open failed");
      if (handle.IsInvalid) throw new IOException("open failed");
      var rootPrefix=FinalPath(root).TrimEnd('\\')+"\\";
      if (!FinalPath(handle).StartsWith(rootPrefix, StringComparison.OrdinalIgnoreCase)) throw new IOException("outside root");
      using (var stream=new FileStream(handle, FileAccess.Read)) using (var memory=new MemoryStream()) {
        var buffer = new byte[81920];
        long total = 0;
        while (true) {
          var remaining = maxBytes - total;
          if (remaining <= 0) {
            if (stream.ReadByte() >= 0) throw new IOException("JY018_NATIVE_FILE_TOO_LARGE");
            break;
          }
          var requested = (int)Math.Min((long)buffer.Length, remaining);
          var read = stream.Read(buffer, 0, requested);
          if (read <= 0) break;
          total += read;
          memory.Write(buffer, 0, read);
        }
        return memory.ToArray();
      }
    }
  }
}
"@
if (-not ('OpenVideoNativeRead' -as [type])) { Add-Type -TypeDefinition $type }
if ($MaxBytes -le 0) { throw 'invalid size limit' }
[Convert]::ToBase64String([OpenVideoNativeRead]::Read($LiteralPath, $RootPath, $MaxBytes))

