import { parseDraftMinerRequest, projectDraftMinerCandidate } from './jianying-draft-resource-contracts.mjs'

/** @param {string} code @returns {never} */
const fail = (code) => { const error = /** @type {Error & {code: string, cleanupFailed?: boolean}} */ (new Error(code)); error.code = code; throw error }
/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} before @param {unknown} after */
const equalSafeFingerprint = (before, after) => typeof before === 'string' && before.length > 0 && before === after
/** @param {unknown} authorization @param {string} expectedId @returns {Record<string, unknown> & {authorizationId: string, readOnly: true, expired: false, revoked?: boolean}} */
const assertAuthorization = (authorization, expectedId) => {
  if (!isRecord(authorization) || authorization.authorizationId !== expectedId ||
      authorization.readOnly !== true || authorization.expired !== false || authorization.revoked === true) {
    fail('NATIVE003_AUTHORIZATION_INVALID')
  }
  return /** @type {Record<string, unknown> & {authorizationId: string, readOnly: true, expired: false, revoked?: boolean}} */ (authorization)
}
/** @param {Record<string, unknown>} left @param {Record<string, unknown>} right */
const sameCandidate = (left, right) => left.packagingToken === right.packagingToken &&
  left.family === right.family && left.label === right.label && left.state === right.state &&
  left.writerEligible === right.writerEligible && JSON.stringify(left.tags) === JSON.stringify(right.tags)

/**
 * Create a discovery-only miner. All filesystem, decoder and persistence work
 * is injected so the orchestration layer cannot accidentally accept a browser
 * path or become a second writer implementation.
 *
 * @param {{resolveAuthorization: (id: string) => Promise<Record<string, unknown>|null>, detectDesktop: () => Promise<Record<string, unknown>|null>, readManifest: (authorization: Record<string, unknown>) => Promise<string>, decodeSnapshot: (input: {authorization: Record<string, unknown>, desktop: Record<string, unknown>}) => Promise<unknown>, extractCandidates: (snapshot: unknown) => Promise<unknown[]>, persistDiscovery: (input: {authorization: Record<string, unknown>, desktop: Record<string, unknown>, candidates: readonly Record<string, unknown>[], manifestFingerprint: string}) => Promise<unknown>, cleanup: () => Promise<void>}} deps
 */
export const createDraftResourceMiner = (deps) => {
  if (!isRecord(deps) || typeof deps.resolveAuthorization !== 'function' || typeof deps.detectDesktop !== 'function' ||
      typeof deps.readManifest !== 'function' || typeof deps.decodeSnapshot !== 'function' ||
      typeof deps.extractCandidates !== 'function' || typeof deps.persistDiscovery !== 'function' ||
      typeof deps.cleanup !== 'function') {
    fail('NATIVE003_DEPENDENCIES_INVALID')
  }
  const cleanup = deps.cleanup
  return Object.freeze({
    /** @param {unknown} input */
    mine: async (input) => {
      const request = parseDraftMinerRequest(input)
      /** @type {Record<string, unknown> | null} */
      let authorization = null
      /** @type {string | null} */
      let beforeManifest = null
      /** @type {Record<string, unknown> | null} */
      let result = null
      /** @type {(Error & {code?: string, cleanupFailed?: boolean}) | null} */
      let primaryError = null
      let cleaned = false
      try {
        authorization = assertAuthorization(await deps.resolveAuthorization(request.draft_authorization_id), request.draft_authorization_id)
        beforeManifest = await deps.readManifest(authorization)
        if (typeof beforeManifest !== 'string' || beforeManifest.length < 8) fail('NATIVE003_MANIFEST_INVALID')
        const desktop = await deps.detectDesktop()
        if (!isRecord(desktop) || desktop.available !== true || typeof desktop.profileId !== 'string' || typeof desktop.version !== 'string') fail('NATIVE003_DESKTOP_UNAVAILABLE')
        authorization = assertAuthorization(await deps.resolveAuthorization(request.draft_authorization_id), request.draft_authorization_id)
        const verifiedDesktop = /** @type {Record<string, unknown> & {available: true, profileId: string, version: string}} */ (desktop)
        const snapshot = await deps.decodeSnapshot({ authorization, desktop: verifiedDesktop })
        const extracted = await deps.extractCandidates(snapshot)
        if (!Array.isArray(extracted) || extracted.length > 20_000) fail('NATIVE003_EXTRACTION_INVALID')
        /** @type {Map<string, Record<string, unknown>>} */
        const candidateMap = new Map()
        for (const entry of extracted.map((/** @type {unknown} */ candidate) => projectDraftMinerCandidate(candidate))) {
          const previous = candidateMap.get(entry.packagingToken)
          if (previous && !sameCandidate(previous, entry)) fail('NATIVE003_EXTRACTION_CONFLICT')
          if (!previous) candidateMap.set(entry.packagingToken, entry)
        }
        const candidates = Object.freeze([...candidateMap.values()])
        authorization = assertAuthorization(await deps.resolveAuthorization(request.draft_authorization_id), request.draft_authorization_id)
        const afterManifest = await deps.readManifest(authorization)
        if (!equalSafeFingerprint(beforeManifest, afterManifest)) fail('NATIVE003_SOURCE_CHANGED')
        authorization = assertAuthorization(await deps.resolveAuthorization(request.draft_authorization_id), request.draft_authorization_id)
        try {
          await cleanup()
          cleaned = true
        } catch {
          fail('NATIVE003_CLEANUP_FAILED')
        }
        await deps.persistDiscovery({ authorization, desktop, candidates, manifestFingerprint: afterManifest })
        result = Object.freeze({ schemaVersion: 1, requestId: request.request_id, status: 'succeeded', candidateCount: candidates.length, candidates })
      } catch (error) {
        const typedError = /** @type {Error & {code?: string}} */ (error)
        const code = error instanceof Error && /^NATIVE00[123]_/u.test(typedError.code ?? error.message)
          ? (typedError.code ?? error.message) : 'NATIVE003_MINER_FAILED'
        primaryError = /** @type {Error & {code: string, cleanupFailed?: boolean}} */ (new Error(code))
        primaryError.code = code
      } finally {
        if (!cleaned) {
          try {
            await cleanup()
          } catch {
            if (primaryError) /** @type {Error & {code: string, cleanupFailed?: boolean}} */ (primaryError).cleanupFailed = true
            else fail('NATIVE003_CLEANUP_FAILED')
          }
        }
      }
      if (primaryError) throw primaryError
      return result
    },
  })
}
