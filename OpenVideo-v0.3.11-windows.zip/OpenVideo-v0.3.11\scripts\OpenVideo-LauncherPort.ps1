# Shared port / instance helpers for Start-OpenVideo.ps1 (worktree isolation).
# Dot-source only; do not execute as a standalone entrypoint.

function Get-OpenVideoFileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    $stream = [IO.File]::OpenRead([IO.Path]::GetFullPath($Path))
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
        $stream.Dispose()
    }
}

function Get-OpenVideoReleaseRevision {
    param([Parameter(Mandatory = $true)][string]$Root)
    $normalizedRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $releaseFiles = @(
        Get-ChildItem -LiteralPath (Join-Path $normalizedRoot 'apps\gateway\src') -File -Recurse
        Get-ChildItem -LiteralPath (Join-Path $normalizedRoot 'apps\gateway\scripts') -File -Recurse
        Get-ChildItem -LiteralPath (Join-Path $normalizedRoot 'apps\web\src') -File -Recurse
        Get-ChildItem -LiteralPath (Join-Path $normalizedRoot 'config') -File -Filter '*.json'
        Get-ChildItem -LiteralPath $normalizedRoot -File -Filter 'tsconfig*.json'
        Get-ChildItem -LiteralPath (Join-Path $normalizedRoot 'apps\gateway') -File -Filter 'tsconfig*.json'
        Get-ChildItem -LiteralPath (Join-Path $normalizedRoot 'apps\web') -File -Filter 'tsconfig*.json'
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'package.json')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'pnpm-lock.yaml')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'pnpm-workspace.yaml')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'apps\gateway\package.json')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'apps\web\package.json')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'apps\web\index.html')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'apps\web\vite.config.ts')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'scripts\Start-OpenVideo.ps1')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'scripts\Build-OpenVideoArtifacts.ps1')
        Get-Item -LiteralPath (Join-Path $normalizedRoot 'scripts\OpenVideo-LauncherPort.ps1')
    ) | Sort-Object -Property FullName -Unique
    $releaseHashText = ($releaseFiles | ForEach-Object {
        $relativePath = $_.FullName.Substring($normalizedRoot.Length).TrimStart('\').Replace('\', '/')
        "$relativePath|$(Get-OpenVideoReleaseFileSha256 -Path $_.FullName)"
    }) -join "`n"
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString(
            $hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($releaseHashText))
        )).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
    }
}

function Get-LocalApiBrowserUrl {
    param(
        [Parameter(Mandatory = $true)][string]$BaseUrl,
        [Parameter(Mandatory = $true)][string]$TokenPath
    )
    if (-not (Test-Path -LiteralPath $TokenPath -PathType Leaf)) {
        throw 'OPENVIDEO_LOCAL_API_TOKEN_MISSING'
    }
    $document = Get-Content -LiteralPath $TokenPath -Raw | ConvertFrom-Json
    $token = [string]$document.token
    if ($token -notmatch '^[a-f0-9]{64}$') {
        throw 'OPENVIDEO_LOCAL_API_TOKEN_INVALID'
    }
    return "$BaseUrl#openvideo_token=$token"
}

function Get-OpenVideoReadiness {
    param(
        [Parameter(Mandatory = $true)][string]$ReadinessUrl,
        [Parameter(Mandatory = $true)][string]$TokenPath
    )
    try {
        if (-not (Test-Path -LiteralPath $TokenPath -PathType Leaf)) { return $null }
        $document = Get-Content -LiteralPath $TokenPath -Raw | ConvertFrom-Json
        $token = [string]$document.token
        if ($token -notmatch '^[a-f0-9]{64}$') { return $null }
        $response = Invoke-WebRequest `
            -Uri $ReadinessUrl `
            -Headers @{ 'X-OpenVideo-Local-Token' = $token } `
            -UseBasicParsing `
            -TimeoutSec 3
        return [pscustomobject]@{
            StatusCode = [int]$response.StatusCode
            Body = ($response.Content | ConvertFrom-Json)
        }
    } catch {
        return $null
    }
}

function Test-OpenVideoPrimaryWorktree {
    param([Parameter(Mandatory = $true)][string]$Root)
    $gitPath = Join-Path $Root '.git'
    return (Test-Path -LiteralPath $gitPath -PathType Container)
}

function Get-OpenVideoInstancesRoot {
    return (Join-Path $env:LOCALAPPDATA 'OpenVideo\instances')
}

function Get-OpenVideoInstancePath {
    param([Parameter(Mandatory = $true)][int]$Port)
    return (Join-Path (Get-OpenVideoInstancesRoot) "$Port.json")
}

function Get-OpenVideoInstanceRecord {
    param([Parameter(Mandatory = $true)][int]$Port)
    $path = Get-OpenVideoInstancePath -Port $Port
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return $null
    }
    try {
        return (Get-Content -LiteralPath $path -Raw | ConvertFrom-Json)
    } catch {
        return $null
    }
}

function Write-OpenVideoInstanceRecord {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][string]$RepositoryRoot,
        [Parameter(Mandatory = $true)][string]$ReleaseRevision,
        [Parameter(Mandatory = $true)][int]$ProcessId,
        [int]$SupervisorProcessId = 0,
        [string]$Url = ("http://127.0.0.1:$Port/")
    )
    $normalizedRoot = [IO.Path]::GetFullPath($RepositoryRoot).TrimEnd('\')
    $record = [ordered]@{
        schema_version = 1
        port = $Port
        url = $Url
        repositoryRoot = $normalizedRoot
        releaseRevision = $ReleaseRevision
        pid = $ProcessId
        supervisorPid = $SupervisorProcessId
        startedAt = ([DateTime]::UtcNow.ToString('o'))
    }
    $path = Get-OpenVideoInstancePath -Port $Port
    $dir = Split-Path -Parent $path
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $tmp = "$path.tmp"
    $utf8 = [Text.UTF8Encoding]::new($false)
    [IO.File]::WriteAllText($tmp, (($record | ConvertTo-Json -Depth 6) + "`n"), $utf8)
    Move-Item -LiteralPath $tmp -Destination $path -Force
}

function Get-OpenVideoReleaseFileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    # Normalize text line endings so Windows checkout settings cannot trigger a fake release.
    $text = [IO.File]::ReadAllText([IO.Path]::GetFullPath($Path))
    $normalized = $text.Replace("`r`n", "`n").Replace("`r", "`n")
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString(
            $hasher.ComputeHash([Text.UTF8Encoding]::new($false).GetBytes($normalized))
        )).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
    }
}

function Get-OpenVideoGitState {
    param([Parameter(Mandatory = $true)][string]$Root)
    try {
        $commit = (& git -C $Root rev-parse --verify HEAD 2>$null).Trim()
        if ($LASTEXITCODE -ne 0 -or $commit -notmatch '^[a-f0-9]{40}$') { return $null }
        $status = (& git -C $Root status --porcelain=v1 --untracked-files=all 2>$null) -join "`n"
        if ($LASTEXITCODE -ne 0) { return $null }
        return [pscustomobject]@{
            Commit = $commit
            Clean = [string]::IsNullOrWhiteSpace($status)
        }
    } catch {
        return $null
    }
}

function Get-OpenVideoReleaseRevisionCachePath {
    param([Parameter(Mandatory = $true)][int]$Port)
    return (Join-Path (Get-OpenVideoInstancesRoot) "release-revision.$Port.json")
}

function Read-OpenVideoCachedReleaseRevision {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][int]$Port
    )
    $gitState = Get-OpenVideoGitState -Root $Root
    if ($null -eq $gitState -or -not $gitState.Clean) { return $null }
    $cachePath = Get-OpenVideoReleaseRevisionCachePath -Port $Port
    if (-not (Test-Path -LiteralPath $cachePath -PathType Leaf)) { return $null }
    try {
        $cache = Get-Content -LiteralPath $cachePath -Raw | ConvertFrom-Json
        if (
            $cache.schema_version -ne 1 -or
            [string]$cache.repository_root -ne [IO.Path]::GetFullPath($Root).TrimEnd('\') -or
            [string]$cache.git_commit -ne [string]$gitState.Commit -or
            [string]$cache.release_revision -notmatch '^[a-f0-9]{64}$'
        ) { return $null }
        return [string]$cache.release_revision
    } catch {
        return $null
    }
}

function Write-OpenVideoCachedReleaseRevision {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][string]$ReleaseRevision
    )
    $gitState = Get-OpenVideoGitState -Root $Root
    if ($null -eq $gitState -or -not $gitState.Clean) { return }
    $cachePath = Get-OpenVideoReleaseRevisionCachePath -Port $Port
    $temporaryPath = "$cachePath.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        New-Item -ItemType Directory -Path (Split-Path $cachePath -Parent) -Force | Out-Null
        $document = [ordered]@{
            schema_version = 1
            repository_root = [IO.Path]::GetFullPath($Root).TrimEnd('\')
            git_commit = $gitState.Commit
            release_revision = $ReleaseRevision
            written_at = [DateTimeOffset]::UtcNow.ToString('O')
        }
        [IO.File]::WriteAllText(
            $temporaryPath,
            (($document | ConvertTo-Json -Depth 4) + "`n"),
            [Text.UTF8Encoding]::new($false)
        )
        Move-Item -LiteralPath $temporaryPath -Destination $cachePath -Force
    } catch {
        # A cache is an optimization only; a failed write must never block launch.
    } finally {
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
    }
}

# Bind the recorded owner to the live Gateway parent before stopping a supervisor.
function Stop-OpenVideoSupervisorOwner {
    param(
        [Parameter(Mandatory = $true)]$Ownership,
        [Parameter(Mandatory = $true)][int]$ExpectedListenerPid
    )
    $record = $Ownership.Record
    if (
        $null -eq $record -or
        -not ($record.PSObject.Properties.Name -contains 'pid') -or
        -not ($record.PSObject.Properties.Name -contains 'supervisorPid')
    ) {
        return $false
    }
    $recordPid = 0
    $supervisorPid = 0
    if (
        -not [int]::TryParse([string]$record.pid, [ref]$recordPid) -or
        $recordPid -ne $ExpectedListenerPid -or
        -not [int]::TryParse([string]$record.supervisorPid, [ref]$supervisorPid) -or
        $supervisorPid -lt 1 -or
        $supervisorPid -eq $PID
    ) {
        return $false
    }
    try {
        $gatewayProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $ExpectedListenerPid"
        if ($null -eq $gatewayProcess -or [int]$gatewayProcess.ParentProcessId -ne $supervisorPid) {
            return $false
        }
        $supervisorProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $supervisorPid"
        if ($null -eq $supervisorProcess) { return $false }
        $supervisorName = [string]$supervisorProcess.Name
        $supervisorCommand = [string]$supervisorProcess.CommandLine
        if (
            $supervisorName -notin @('powershell.exe', 'pwsh.exe') -or
            $supervisorCommand -notmatch '(?i)(Start-OpenVideo\.ps1|-EncodedCommand)'
        ) {
            return $false
        }
        Stop-Process -Id $supervisorPid -Force -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

function Remove-OpenVideoInstanceRecord {
    param([Parameter(Mandatory = $true)][int]$Port)
    $path = Get-OpenVideoInstancePath -Port $Port
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
    }
}

function Write-OpenVideoInstanceSummary {
    $root = Get-OpenVideoInstancesRoot
    if (-not (Test-Path -LiteralPath $root -PathType Container)) {
        Write-Host 'OPENVIDEO_INSTANCES: (none registered)' -ForegroundColor DarkGray
        return
    }
    $files = @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File -ErrorAction SilentlyContinue)
    if ($files.Count -eq 0) {
        Write-Host 'OPENVIDEO_INSTANCES: (none registered)' -ForegroundColor DarkGray
        return
    }
    Write-Host 'OPENVIDEO_INSTANCES:' -ForegroundColor Cyan
    foreach ($file in ($files | Sort-Object Name)) {
        try {
            $record = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
            $alive = $false
            if ($record.pid -gt 0) {
                $alive = $null -ne (Get-Process -Id ([int]$record.pid) -ErrorAction SilentlyContinue)
            }
            $slug = Split-Path -Leaf ([string]$record.repositoryRoot)
            Write-Host (
                "  port=$($record.port) alive=$alive revision=$($record.releaseRevision) root=$slug url=$($record.url)"
            ) -ForegroundColor DarkGray
        } catch {
            Write-Host "  (unreadable $($file.Name))" -ForegroundColor DarkGray
        }
    }
}

function Get-StableWorktreeGatewayPort {
    param([Parameter(Mandatory = $true)][string]$Root)
    $normalized = [IO.Path]::GetFullPath($Root).TrimEnd('\').ToLowerInvariant()
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($normalized))
        $value = [BitConverter]::ToUInt32($bytes, 0)
        return [int](8790 + ($value % 100))
    } finally {
        $hasher.Dispose()
    }
}

function Get-ProcessRepositoryRootHint {
    param([Parameter(Mandatory = $true)][int]$ProcessId)
    $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction SilentlyContinue
    if ($null -eq $proc -or [string]::IsNullOrWhiteSpace([string]$proc.CommandLine)) {
        return $null
    }
    $cmd = [string]$proc.CommandLine
    # Node quotes the entry point when its worktree path contains spaces.  Parse that
    # form before the legacy compact-path expression so this root is never treated as
    # an unowned OpenVideo instance merely because its directory contains a space.
    if ($cmd -match '(?i)"((?:[A-Za-z]:\\|\\\\)[^"]+?)(?:[/\\](?:apps[/\\]gateway|tmp-boot\.mjs))') {
        try {
            return [IO.Path]::GetFullPath($Matches[1]).TrimEnd('\\')
        } catch {
            return $null
        }
    }
    # Typical: ...\open-video-vid006\apps\gateway\src\server.mjs or ...\tmp-boot.mjs under worktree
    if ($cmd -match '(?i)((?:[A-Za-z]:\\|\\\\)[^"\s]+?)(?:[/\\](?:apps[/\\]gateway|/tmp-boot\.mjs|\\tmp-boot\.mjs))') {
        try {
            return [IO.Path]::GetFullPath($Matches[1]).TrimEnd('\')
        } catch {
            return $null
        }
    }
    if ($cmd -match '(?i)WorkingDirectory[=:]?\s*"?((?:[A-Za-z]:\\|\\\\)[^"]+)"?') {
        try {
            return [IO.Path]::GetFullPath($Matches[1]).TrimEnd('\')
        } catch {
            return $null
        }
    }
    return $null
}

function Test-LoopbackPortInUse {
    param([Parameter(Mandatory = $true)][int]$Port)
    $client = [Net.Sockets.TcpClient]::new()
    try {
        $client.Connect('127.0.0.1', $Port)
        return $true
    } catch {
        return $false
    } finally {
        $client.Dispose()
    }
}

function Get-LoopbackListenerPid {
    param([Parameter(Mandatory = $true)][int]$Port)
    # Get-NetTCPConnection initializes the CIM networking provider and commonly costs 1-2s
    # even for a single local port. netstat is available on every supported Windows release
    # and returns the same kernel listener PID without that initialization penalty.
    try {
        $pattern = "127\.0\.0\.1:$Port\s+\S+\s+LISTENING\s+(\d+)"
        foreach ($line in @(netstat -ano -p tcp)) {
            if ($line -match $pattern) {
                return [int]$Matches[1]
            }
        }
    } catch {
        # Fall through to the PowerShell networking provider when netstat is unavailable.
    }
    try {
        $listeners = @(Get-NetTCPConnection `
            -LocalAddress '127.0.0.1' `
            -LocalPort $Port `
            -State Listen `
            -ErrorAction SilentlyContinue)
        foreach ($listener in $listeners) {
            if ($listener.OwningProcess -gt 0) {
                return [int]$listener.OwningProcess
            }
        }
    } catch {
        # Fall through to netstat when Get-NetTCPConnection is unavailable.
    }
    return $null
}

function Get-OpenVideoPortOwnership {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][string]$ExpectedRoot
    )
    $expected = [IO.Path]::GetFullPath($ExpectedRoot).TrimEnd('\')
    $pidOnPort = Get-LoopbackListenerPid -Port $Port
    if ($null -eq $pidOnPort) {
        return [pscustomobject]@{
            State = 'free'
            Pid = $null
            RepositoryRoot = $null
            ReleaseRevision = $null
            Record = $null
        }
    }

    $record = Get-OpenVideoInstanceRecord -Port $Port
    $recordPid = 0
    $recordMatchesListener = (
        $null -ne $record -and
        $record.PSObject.Properties.Name -contains 'pid' -and
        [int]::TryParse([string]$record.pid, [ref]$recordPid) -and
        $recordPid -eq $pidOnPort
    )
    $recordRoot = $null
    if (
        $recordMatchesListener -and
        $record.PSObject.Properties.Name -contains 'repositoryRoot' -and
        -not [string]::IsNullOrWhiteSpace([string]$record.repositoryRoot)
    ) {
        $recordRoot = [IO.Path]::GetFullPath([string]$record.repositoryRoot).TrimEnd('\')
    }

    $release = $null
    if ($recordMatchesListener -and $record.PSObject.Properties.Name -contains 'releaseRevision') {
        $release = [string]$record.releaseRevision
    }
    try {
        $live = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/live" -TimeoutSec 2
        if ($live.live -eq $true -and $live.PSObject.Properties.Name -contains 'releaseRevision') {
            $release = [string]$live.releaseRevision
        }
        $isOpenVideo = ($live.live -eq $true)
    } catch {
        $isOpenVideo = $false
    }

    # Bind the liveness result to the PID sampled before the probe. A listener can be
    # replaced while the HTTP request is in flight; a record for A must not authenticate B.
    $confirmedPid = Get-LoopbackListenerPid -Port $Port
    $listenerStable = ($null -ne $confirmedPid -and $confirmedPid -eq $pidOnPort)
    if (-not $listenerStable) {
        $pidOnPort = $confirmedPid
    }
    $ownerRoot = $null
    if ($listenerStable -and $isOpenVideo -and $null -ne $recordRoot) {
        $ownerRoot = $recordRoot
    } elseif ($null -ne $pidOnPort) {
        # A record alone is not proof: Windows can reuse a stale PID for an unrelated service.
        # On a failed/non-OpenVideo liveness probe, retain the command-line identity fallback.
        $hint = Get-ProcessRepositoryRootHint -ProcessId $pidOnPort
        if ($null -ne $hint) {
            $ownerRoot = $hint
        }
    }

    if ($null -ne $ownerRoot -and $ownerRoot.Equals($expected, [StringComparison]::OrdinalIgnoreCase)) {
        return [pscustomobject]@{
            State = 'same_root'
            Pid = $pidOnPort
            RepositoryRoot = $ownerRoot
            ReleaseRevision = $release
            Record = $record
        }
    }
    if ($null -ne $ownerRoot) {
        return [pscustomobject]@{
            State = 'other_root'
            Pid = $pidOnPort
            RepositoryRoot = $ownerRoot
            ReleaseRevision = $release
            Record = $record
        }
    }
    if ($isOpenVideo) {
        return [pscustomobject]@{
            State = 'openvideo_unknown_root'
            Pid = $pidOnPort
            RepositoryRoot = $null
            ReleaseRevision = $release
            Record = $record
        }
    }
    return [pscustomobject]@{
        State = 'unknown'
        Pid = $pidOnPort
        RepositoryRoot = $null
        ReleaseRevision = $null
        Record = $record
    }
}

function Resolve-OpenVideoGatewayPort {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][int]$PrimaryPort
    )
    $envPortText = $env:OPENVIDEO_GATEWAY_PORT
    if (-not [string]::IsNullOrWhiteSpace($envPortText)) {
        $parsed = 0
        if ([int]::TryParse($envPortText, [ref]$parsed) -and $parsed -ge 1 -and $parsed -le 65535) {
            return $parsed
        }
        throw "OPENVIDEO_GATEWAY_PORT_INVALID: OPENVIDEO_GATEWAY_PORT='$envPortText' is not a valid TCP port."
    }

    $normalizedRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    if (Test-OpenVideoPrimaryWorktree -Root $normalizedRoot) {
        return $PrimaryPort
    }

    $preferred = Get-StableWorktreeGatewayPort -Root $normalizedRoot
    for ($offset = 0; $offset -lt 20; $offset += 1) {
        $candidate = 8790 + ((($preferred - 8790) + $offset) % 100)
        if (-not (Test-LoopbackPortInUse -Port $candidate)) {
            return $candidate
        }
        $ownership = Get-OpenVideoPortOwnership -Port $candidate -ExpectedRoot $normalizedRoot
        if ($ownership.State -eq 'same_root') {
            return $candidate
        }
    }
    throw "OPENVIDEO_WORKTREE_PORT_EXHAUSTED: Unable to find a free port in 8790-8889 for worktree '$normalizedRoot'."
}

function Assert-OpenVideoPortOccupiable {
    param(
        [Parameter(Mandatory = $true)][int]$Port,
        [Parameter(Mandatory = $true)][string]$RepositoryRoot,
        [switch]$Replace,
        [switch]$IsPrimaryWorktree
    )
    $ownership = Get-OpenVideoPortOwnership -Port $Port -ExpectedRoot $RepositoryRoot
    switch ($ownership.State) {
        'free' { return $ownership }
        'same_root' { return $ownership }
        'other_root' {
            $slug = if ($ownership.RepositoryRoot) { Split-Path -Leaf $ownership.RepositoryRoot } else { '(unknown)' }
            if ($Replace -and $IsPrimaryWorktree) {
                Write-Host (
                    "OPENVIDEO_REPLACE_REQUESTED: Will replace other worktree on 127.0.0.1:$Port (root=$slug revision=$($ownership.ReleaseRevision))."
                ) -ForegroundColor Yellow
                return $ownership
            }
            throw (
                "OPENVIDEO_PORT_OWNED_BY_OTHER_WORKTREE: 127.0.0.1:$Port is owned by '$slug' " +
                "(revision=$($ownership.ReleaseRevision), pid=$($ownership.Pid)). " +
                "Use that URL, or pass -Replace from the primary worktree to take over port $Port."
            )
        }
        'openvideo_unknown_root' {
            if ($Replace -and $IsPrimaryWorktree) {
                Write-Host (
                    "OPENVIDEO_REPLACE_REQUESTED: Will replace OpenVideo instance on 127.0.0.1:$Port (revision=$($ownership.ReleaseRevision))."
                ) -ForegroundColor Yellow
                return $ownership
            }
            throw (
                "OPENVIDEO_PORT_OWNED_BY_OTHER_INSTANCE: 127.0.0.1:$Port already serves OpenVideo " +
                "(revision=$($ownership.ReleaseRevision), pid=$($ownership.Pid)). " +
                "Do not steal silently. Pass -Replace from the primary worktree only when intentional."
            )
        }
        default {
            throw "OPENVIDEO_PORT_IN_USE: The configured port $Port is occupied by an unknown local service (pid=$($ownership.Pid))."
        }
    }
}
