import {
  isPackagingWriterReadyEntry,
  PACKAGING_RESOURCE_WRITER_FAMILIES,
} from './jianying-packaging-resource-index.mjs'

const automaticPackagingFamilies = PACKAGING_RESOURCE_WRITER_FAMILIES

/**
 * Select automatic recommendation families from the current private index.
 * The index is already profile/version-bound by its loader; this helper only
 * admits exact writer-eligible entries and never promotes discovery records.
 * @param {unknown} index
 * @returns {string[]}
 */
export const selectWriterEligiblePackagingFamilies = (index) => {
  if (!index || typeof index !== 'object' || Array.isArray(index)) return []
  const candidate = /** @type {Record<string, unknown>} */ (index)
  if (!Array.isArray(candidate.entries)) return []
  const ready = new Set(candidate.entries
    .filter((entry) => isPackagingWriterReadyEntry(entry))
    .map((entry) => entry.family))
  return automaticPackagingFamilies.filter((family) => ready.has(family))
}

export const AUTOMATIC_PACKAGING_FAMILIES = automaticPackagingFamilies
