import { scanJianyingPrivateResourceCatalog } from './jianying-private-resource-scanner.mjs'

const MAX_KEYS = 2048
const MAX_NODES = 200_000
const MAX_DEPTH = 48
const SAFE_KEY = /^[A-Za-z0-9_.-]{1,96}$/u
const knownSchemaKeys = new Set([
  'id', 'resource_id', 'resourceId', 'effect_id', 'effectId', 'duration',
  'duration_us', 'durationUs', 'type', 'category', 'family', 'name', 'title',
  'label', 'data', 'items', 'list', 'records', 'resources', 'effects',
  'common_mask_template', 'commonMaskTemplate',
])

/** @param {string} key */
const keyCategory = (key) => {
  if (!SAFE_KEY.test(key)) return 'unsafe_key'
  return knownSchemaKeys.has(key) ? key : 'other_key'
}

/** @param {number} length */
const bucketForLength = (length) => length === 0 ? 'empty' : length === 1 ? 'one' : length <= 8 ? 'small' : length <= 64 ? 'medium' : 'large'
/** @param {unknown} value */
const valueClass = (value) => {
  if (typeof value !== 'string') return value === null ? 'null' : typeof value
  if (value.length === 0) return 'empty_string'
  if (/^[A-Za-z0-9_-]{4,160}$/u.test(value)) return 'safe_identifier'
  if (/[A-Za-z]:[\\/]|[\\/]\.?[\\/]/u.test(value)) return 'path_like'
  return `string_${bucketForLength(value.length)}`
}

const createAccumulator = () => {
  /** @type {Map<string, number>} */
  const keys = new Map()
  /** @type {Map<string, number>} */
  const shapes = new Map()
  /** @type {Map<string, number>} */
  const arrays = new Map()
  /** @type {Map<string, number>} */
  const scalarTypes = new Map()
  /** @type {Map<string, number>} */
  const fieldValueClasses = new Map()
  /** @type {Map<string, number>} */
  const fieldCooccurrence = new Map()
  let documents = 0
  let nodes = 0
  let objects = 0
  let arraysSeen = 0
  let maxDepth = 0
  let truncated = false

  /** @param {Map<string, number>} map @param {string} value @param {number} [amount] */
  const count = (map, value, amount = 1) => map.set(value, (map.get(value) ?? 0) + amount)
  /** @param {unknown} value @param {number} [depth] */
  const observe = (value, depth = 0) => {
    if (nodes >= MAX_NODES || depth > MAX_DEPTH) {
      truncated = true
      return
    }
    nodes += 1
    maxDepth = Math.max(maxDepth, depth)
    if (Array.isArray(value)) {
      arraysSeen += 1
      count(arrays, bucketForLength(value.length))
      value.forEach((item) => observe(item, depth + 1))
      return
    }
    if (value && typeof value === 'object') {
      const record = /** @type {Record<string, unknown>} */ (value)
      objects += 1
      const objectKeys = Object.keys(record)
      const shapeKeys = []
      const recognizedKeys = new Set()
      for (const key of objectKeys) {
        const category = keyCategory(key)
        if (keys.size >= MAX_KEYS && !keys.has(category)) {
          truncated = true
          continue
        }
        count(keys, category)
        shapeKeys.push(category)
        if (knownSchemaKeys.has(key)) recognizedKeys.add(key)
        if (['resource_id', 'resourceId', 'id', 'name', 'title', 'label', 'type', 'category', 'family', 'effectId', 'duration_us', 'durationUs'].includes(key)) {
          count(fieldValueClasses, `${key}:${valueClass(record[key])}`)
        }
        observe(record[key], depth + 1)
      }
      if (recognizedKeys.size > 0) {
        const cooccurrence = [...recognizedKeys].sort().join('|')
        count(fieldCooccurrence, cooccurrence.length <= 240 ? cooccurrence : 'large_signature')
      }
      if (shapeKeys.length > 0) {
        const shape = shapeKeys.sort().join('|')
        count(shapes, shape.length <= 512 ? shape : 'large_shape')
      }
      return
    }
    const type = value === null ? 'null' : typeof value
    count(scalarTypes, ['string', 'number', 'boolean', 'null'].includes(type) ? type : 'other')
  }

  return {
    document() { documents += 1 },
    observe,
    finish() {
      /** @param {Map<string, number>} map */
      const sortCounts = (map) => Object.freeze(Object.fromEntries([...map.entries()].sort(([a], [b]) => a.localeCompare(b))))
      return Object.freeze({
        schema_version: 1,
        documents,
        nodes,
        objects,
        arrays: arraysSeen,
        max_depth: maxDepth,
        truncated,
        key_counts: sortCounts(keys),
        object_shapes: sortCounts(shapes),
        array_length_buckets: sortCounts(arrays),
        scalar_types: sortCounts(scalarTypes),
        field_value_classes: sortCounts(fieldValueClasses),
        field_cooccurrence: sortCounts(fieldCooccurrence),
      })
    },
  }
}

/** Aggregate JSON shape without retaining any metadata value. */
export const summarizePrivateMetadataSchema = (/** @type {unknown} */ values) => {
  if (!Array.isArray(values)) throw new Error('JY177_SCHEMA_INPUT_INVALID')
  const accumulator = createAccumulator()
  for (const value of values) {
    accumulator.document()
    accumulator.observe(value)
  }
  return accumulator.finish()
}

/** Probe trusted Jianying roots through the existing bounded scanner.
 * @param {Parameters<typeof scanJianyingPrivateResourceCatalog>[0]} input
 */
export const probeJianyingPrivateMetadataSchema = async (input) => {
  const accumulator = createAccumulator()
  await scanJianyingPrivateResourceCatalog({
    ...input,
    classifyFamily: () => null,
    observeMetadata: (value) => {
      accumulator.document()
      accumulator.observe(value)
    },
  })
  return accumulator.finish()
}
