import { createHash, randomUUID } from 'node:crypto'
import { execFile } from 'node:child_process'
import { createWriteStream } from 'node:fs'
import { copyFile, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, resolve } from 'node:path'
import { Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

const schemaVersion = 1
const maxEntries = 512
const soundFamilies = new Set([
  'camera', 'foley', 'impact', 'riser', 'sparkle', 'text', 'transition', 'whoosh',
])
const importanceLevels = new Set(['low', 'medium', 'high'])
const shaPattern = /^[a-f0-9]{64}$/u
const opaquePattern = /^[A-Za-z0-9._:-]{1,200}$/u
const tagPattern = /^[a-z0-9][a-z0-9._-]{0,39}$/u
const forbiddenPrivateText = /(?:[A-Za-z]:[\\/]|\\\\|\bfile:|\bhttps?:|api[_ -]?key|authorization|bearer|access[_ -]?token)/iu
const rightsFingerprintPrefix = 'openvideo-user-authorized-sfx-v1'
/** @type {ReadonlyArray<readonly [string, RegExp]>} */
const familyMatchers = Object.freeze([
  ['camera', /(?:camera|shutter|snapshot|photo|拍照|快门|相机)/iu],
  ['impact', /(?:impact|hit|boom|punch|slam|重击|冲击|爆炸)/iu],
  ['riser', /(?:riser|rise|build|swell|上升|渐强|累积)/iu],
  ['sparkle', /(?:sparkle|magic|twinkle|chime|ding|闪光|魔法|叮)/iu],
  ['text', /(?:text|subtitle|caption|notification|pop|文字|字幕|弹出|提示)/iu],
  ['whoosh', /(?:whoosh|swoosh|swish|whip|划过|嗖)/iu],
  ['transition', /(?:transition|switch|wipe|转场|切换)/iu],
  ['foley', /(?:foley|click|tap|type|keyboard|footstep|knock|按键|点击|敲击|脚步)/iu],
])
const familyDefaultVolumes = new Map([
  ['camera', 0.55],
  ['foley', 0.5],
  ['impact', 0.7],
  ['riser', 0.6],
  ['sparkle', 0.5],
  ['text', 0.45],
  ['transition', 0.55],
  ['whoosh', 0.55],
])

export class SfxCatalogError extends Error {
  /** @param {string} code @param {number} status */
  constructor(code, status = 503) {
    super(code)
    this.name = 'SfxCatalogError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const opaqueId = (value) => typeof value === 'string' && opaquePattern.test(value) && !forbiddenPrivateText.test(value)
/** @param {unknown} value */
const validTags = (value) => Array.isArray(value) && value.length <= 12 &&
  new Set(value).size === value.length && value.every((tag) => typeof tag === 'string' && tagPattern.test(tag))
/** @param {unknown} value */
const validEntry = (value) => isRecord(value) &&
  Object.keys(value).length === 12 &&
  ['audioToken', 'projectId', 'semanticFamily', 'tags', 'durationUs', 'loudnessDb',
    'defaultVolume', 'sourceFingerprint', 'licenseFingerprint', 'state', 'createdAt', 'updatedAt']
    .every((key) => Object.hasOwn(value, key)) &&
  opaqueId(value.audioToken) && opaqueId(value.projectId) &&
  soundFamilies.has(value.semanticFamily) && validTags(value.tags) &&
  Number.isSafeInteger(value.durationUs) && value.durationUs > 0 && value.durationUs <= 60_000_000 &&
  Number.isFinite(value.loudnessDb) && value.loudnessDb >= -96 && value.loudnessDb <= 6 &&
  Number.isFinite(value.defaultVolume) && value.defaultVolume >= 0 && value.defaultVolume <= 1 &&
  typeof value.sourceFingerprint === 'string' && shaPattern.test(value.sourceFingerprint) &&
  typeof value.licenseFingerprint === 'string' && shaPattern.test(value.licenseFingerprint) &&
  ['active', 'stale'].includes(value.state) &&
  typeof value.createdAt === 'string' && Number.isFinite(Date.parse(value.createdAt)) &&
  typeof value.updatedAt === 'string' && Number.isFinite(Date.parse(value.updatedAt))

/** @param {Record<string, any>[]} entries */
const fingerprintEntries = (entries) => createHash('sha256')
  .update(JSON.stringify(entries.map((entry) => ({
    audioToken: entry.audioToken,
    projectId: entry.projectId,
    semanticFamily: entry.semanticFamily,
    tags: entry.tags,
    durationUs: entry.durationUs,
    loudnessDb: entry.loudnessDb,
    defaultVolume: entry.defaultVolume,
    sourceFingerprint: entry.sourceFingerprint,
    licenseFingerprint: entry.licenseFingerprint,
    state: entry.state,
    updatedAt: entry.updatedAt,
  })).sort((left, right) => `${left.projectId}\u0000${left.audioToken}`.localeCompare(`${right.projectId}\u0000${right.audioToken}`))))
  .digest('hex')

/** @param {string} label */
const classifyLabel = (label) => {
  for (const [family, pattern] of familyMatchers) {
    if (pattern.test(label)) return { family, tags: ['auto', family] }
  }
  return { family: 'foley', tags: ['auto', 'generic'] }
}

/** @param {{ffprobePath: string, runner?: typeof execFileAsync}} input */
export const createFfprobeSfxInspector = ({ ffprobePath, runner = execFileAsync }) => {
  if (typeof ffprobePath !== 'string' || !isAbsolute(ffprobePath) || typeof runner !== 'function') {
    throw new SfxCatalogError('SFX_CATALOG_DEPENDENCY_INVALID', 500)
  }
  return async (/** @type {{path: string}} */ input) => {
    try {
      /** @type {Record<string, string>} */
      const environment = { PATH: dirname(ffprobePath) }
      for (const key of ['SystemRoot', 'WINDIR', 'TEMP', 'TMP']) {
        if (typeof process.env[key] === 'string') environment[key] = process.env[key]
      }
      const { stdout } = await runner(ffprobePath, [
        '-v', 'error',
        '-protocol_whitelist', 'file,pipe',
        '-max_alloc', '67108864',
        '-probesize', '1048576',
        '-analyzeduration', '5000000',
        '-show_entries', 'format=duration:stream=codec_type',
        '-of', 'json',
        input.path,
      ], {
        cwd: dirname(ffprobePath),
        encoding: 'utf8',
        env: environment,
        windowsHide: true,
        timeout: 10_000,
        maxBuffer: 64 * 1024,
      })
      const parsed = JSON.parse(stdout)
      const durationSeconds = Number(parsed?.format?.duration)
      const streams = Array.isArray(parsed?.streams) ? parsed.streams : []
      if (
        !Number.isFinite(durationSeconds) || durationSeconds <= 0 || durationSeconds > 60 ||
        streams.length === 0 || streams.some((/** @type {Record<string, any>} */ stream) => stream?.codec_type !== 'audio')
      ) return null
      return Object.freeze({ durationUs: Math.max(1, Math.round(durationSeconds * 1_000_000)) })
    } catch {
      return null
    }
  }
}

/**
 * Private, path-free semantic index over already-authorized audio leases. Media,
 * filenames and license text remain in their owning private stores.
 * @param {{
 *   dataRoot: string,
 *   audioLibrary: {isAuthorizedTrack: Function, acquireTrackLease: Function, describeTrack?: Function},
 *   inspectAudio?: (input: {path: string}) => Promise<{durationUs: number} | null>,
 *   globalProjectId?: string | null,
 *   securePrivateRoot?: (path: string) => Promise<void>,
 *   now?: () => string,
 * }} input
 */
export const createSfxCatalog = async ({
  dataRoot,
  audioLibrary,
  inspectAudio = async () => null,
  globalProjectId = null,
  securePrivateRoot = async () => {},
  now = () => new Date().toISOString(),
}) => {
  if (
    typeof dataRoot !== 'string' || !isAbsolute(dataRoot) ||
    !isRecord(audioLibrary) ||
    typeof audioLibrary.isAuthorizedTrack !== 'function' ||
    typeof audioLibrary.acquireTrackLease !== 'function' ||
    (audioLibrary.describeTrack !== undefined && typeof audioLibrary.describeTrack !== 'function') ||
    typeof inspectAudio !== 'function' ||
    (globalProjectId !== null && !opaqueId(globalProjectId)) ||
    typeof securePrivateRoot !== 'function' || typeof now !== 'function'
  ) throw new SfxCatalogError('SFX_CATALOG_DEPENDENCY_INVALID', 500)

  const root = resolve(dataRoot, 'creative-sfx')
  const workRoot = resolve(root, 'work')
  const catalogPath = resolve(root, 'catalog-v1.json')
  const backupPath = `${catalogPath}.bak`
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRoot(root)
  await rm(workRoot, { recursive: true, force: true })
  await mkdir(workRoot, { recursive: true, mode: 0o700 })
  /** @type {Record<string, any>[]} */
  let entries = []
  try {
    const parsed = JSON.parse(await readFile(catalogPath, 'utf8'))
    if (
      !isRecord(parsed) || parsed.schemaVersion !== schemaVersion ||
      !Array.isArray(parsed.entries) || parsed.entries.length > maxEntries ||
      !parsed.entries.every(validEntry) ||
      parsed.fingerprint !== fingerprintEntries(parsed.entries)
    ) throw new Error('invalid_catalog')
    entries = parsed.entries.map((entry) => structuredClone(entry))
  } catch (error) {
    if (/** @type {NodeJS.ErrnoException} */ (error)?.code !== 'ENOENT') {
      throw new SfxCatalogError('SFX_CATALOG_INTEGRITY_INVALID')
    }
  }

  const persist = async () => {
    const ordered = entries
      .map((entry) => structuredClone(entry))
      .sort((left, right) => `${left.projectId}\u0000${left.audioToken}`.localeCompare(`${right.projectId}\u0000${right.audioToken}`))
    const content = `${JSON.stringify({
      schemaVersion,
      fingerprint: fingerprintEntries(ordered),
      entries: ordered,
    }, null, 2)}\n`
    const temporaryPath = resolve(root, `.catalog-v1.${randomUUID()}.tmp`)
    try {
      await writeFile(temporaryPath, content, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
      await copyFile(catalogPath, backupPath).catch((error) => {
        if (/** @type {NodeJS.ErrnoException} */ (error)?.code !== 'ENOENT') throw error
      })
      await rename(temporaryPath, catalogPath)
    } finally {
      await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }
  let mutationQueue = Promise.resolve()
  /** @template T @param {() => Promise<T>} operation @returns {Promise<T>} */
  const mutate = (operation) => {
    const result = mutationQueue.then(operation, operation)
    mutationQueue = result.then(() => undefined, () => undefined)
    return result
  }

  /** @param {{projectId: string, audioToken: string}} input */
  const acquireCatalogAudio = async (input) => {
    if (!opaqueId(input?.projectId) || !opaqueId(input?.audioToken)) return null
    const entry = entries.find((candidate) => candidate.state === 'active' &&
      (candidate.projectId === input.projectId || candidate.projectId === globalProjectId) &&
      candidate.audioToken === input.audioToken)
    if (!entry || await audioLibrary.isAuthorizedTrack({
      projectId: entry.projectId,
      trackId: input.audioToken,
    }) !== true) return null
    return audioLibrary.acquireTrackLease({ projectId: entry.projectId, trackId: input.audioToken })
  }

  return Object.freeze({
    /**
     * Register an already-authorized local audio track without exposing its path or
     * requiring per-video sound selection. Classification is deterministic and can
     * be replaced by a future schema-validated classifier without changing tokens.
     * @param {{projectId: string, audioToken: string, rightsConfirmed: true}} input
     */
    async registerAuthorizedTrack(input) {
      if (
        !opaqueId(input?.projectId) || !opaqueId(input?.audioToken) ||
        input?.rightsConfirmed !== true || typeof audioLibrary.describeTrack !== 'function'
      ) throw new SfxCatalogError('SFX_CATALOG_INPUT_INVALID', 400)
      const description = await audioLibrary.describeTrack({
        projectId: input.projectId,
        trackId: input.audioToken,
      })
      if (
        !isRecord(description) || description.trackId !== input.audioToken ||
        typeof description.label !== 'string' || !description.label.trim() ||
        typeof description.sha256 !== 'string' || !shaPattern.test(description.sha256)
      ) throw new SfxCatalogError('SFX_CATALOG_AUTHORIZATION_REQUIRED', 409)
      const lease = await audioLibrary.acquireTrackLease({
        projectId: input.projectId,
        trackId: input.audioToken,
      })
      if (
        !lease || typeof lease.extension !== 'string' ||
        !/^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(lease.extension) ||
        typeof lease.sha256 !== 'string' || lease.sha256 !== description.sha256 ||
        !Number.isSafeInteger(lease.size) || lease.size <= 0 ||
        typeof lease.createStream !== 'function' || typeof lease.release !== 'function'
      ) {
        await lease?.release?.().catch(() => {})
        throw new SfxCatalogError('SFX_CATALOG_AUDIO_UNAVAILABLE')
      }
      const inspectRoot = resolve(workRoot, `inspect-${randomUUID()}`)
      const inspectPath = resolve(inspectRoot, `audio${lease.extension}`)
      try {
        await mkdir(inspectRoot, { recursive: false, mode: 0o700 })
        const digest = createHash('sha256')
        let size = 0
        const verifier = new Transform({
          transform(chunk, _encoding, callback) {
            size += chunk.length
            digest.update(chunk)
            callback(null, chunk)
          },
        })
        await pipeline(
          lease.createStream(),
          verifier,
          createWriteStream(inspectPath, { flags: 'wx', mode: 0o600 }),
        )
        if (size !== lease.size || digest.digest('hex') !== lease.sha256) {
          throw new SfxCatalogError('SFX_CATALOG_AUDIO_UNAVAILABLE')
        }
        const inspection = await inspectAudio({ path: inspectPath })
        if (
          !isRecord(inspection) || !Number.isSafeInteger(inspection.durationUs) ||
          inspection.durationUs <= 0 || inspection.durationUs > 60_000_000
        ) throw new SfxCatalogError('SFX_CATALOG_AUDIO_UNAVAILABLE')
        const classified = classifyLabel(description.label)
        return this.register({
          projectId: input.projectId,
          audioToken: input.audioToken,
          semanticFamily: classified.family,
          tags: classified.tags,
          durationUs: inspection.durationUs,
          loudnessDb: -18,
          defaultVolume: familyDefaultVolumes.get(classified.family),
          sourceFingerprint: description.sha256,
          licenseFingerprint: createHash('sha256')
            .update(`${rightsFingerprintPrefix}\u0000${description.sha256}`)
            .digest('hex'),
        })
      } finally {
        await lease.release().catch(() => {})
        await rm(inspectRoot, { recursive: true, force: true }).catch(() => {})
      }
    },

    /** @param {{projectId: string, audioToken: string}} input */
    async unregister(input) {
      if (!opaqueId(input?.projectId) || !opaqueId(input?.audioToken)) {
        throw new SfxCatalogError('SFX_CATALOG_INPUT_INVALID', 400)
      }
      return mutate(async () => {
        const previousEntries = entries.map((entry) => structuredClone(entry))
        entries = entries.filter((entry) =>
          entry.projectId !== input.projectId || entry.audioToken !== input.audioToken)
        if (entries.length === previousEntries.length) return false
        try {
          await persist()
          return true
        } catch (error) {
          entries = previousEntries
          throw error
        }
      })
    },

    /** @param {Record<string, any>} input */
    async register(input) {
      return mutate(async () => {
        const timestamp = now()
        const candidate = {
          audioToken: input?.audioToken,
          projectId: input?.projectId,
          semanticFamily: input?.semanticFamily,
          tags: Array.isArray(input?.tags) ? [...new Set(input.tags)].sort() : [],
          durationUs: input?.durationUs,
          loudnessDb: input?.loudnessDb,
          defaultVolume: input?.defaultVolume,
          sourceFingerprint: input?.sourceFingerprint,
          licenseFingerprint: input?.licenseFingerprint,
          state: 'active',
          createdAt: timestamp,
          updatedAt: timestamp,
        }
        if (!validEntry(candidate)) throw new SfxCatalogError('SFX_CATALOG_INPUT_INVALID', 400)
        if (await audioLibrary.isAuthorizedTrack({
          projectId: candidate.projectId,
          trackId: candidate.audioToken,
        }) !== true) throw new SfxCatalogError('SFX_CATALOG_AUTHORIZATION_REQUIRED', 409)
        const index = entries.findIndex((entry) =>
          entry.projectId === candidate.projectId && entry.audioToken === candidate.audioToken)
        if (index >= 0) {
          const existing = entries[index]
          candidate.createdAt = existing.createdAt
          const unchanged = existing.audioToken === candidate.audioToken &&
            existing.projectId === candidate.projectId &&
            existing.semanticFamily === candidate.semanticFamily &&
            existing.durationUs === candidate.durationUs &&
            existing.loudnessDb === candidate.loudnessDb &&
            existing.defaultVolume === candidate.defaultVolume &&
            existing.sourceFingerprint === candidate.sourceFingerprint &&
            existing.licenseFingerprint === candidate.licenseFingerprint &&
            existing.state === candidate.state &&
            JSON.stringify(existing.tags) === JSON.stringify(candidate.tags)
          if (unchanged) {
            return Object.freeze({
              audioToken: existing.audioToken,
              semanticFamily: existing.semanticFamily,
              tags: Object.freeze([...existing.tags]),
              durationUs: existing.durationUs,
              loudnessDb: existing.loudnessDb,
              defaultVolume: existing.defaultVolume,
            })
          }
        }
        else if (entries.length >= maxEntries) throw new SfxCatalogError('SFX_CATALOG_LIMIT_REACHED', 409)
        const previousEntries = entries.map((entry) => structuredClone(entry))
        if (index >= 0) entries[index] = candidate
        else entries.push(candidate)
        try {
          await persist()
        } catch (error) {
          entries = previousEntries
          throw error
        }
        return Object.freeze({
          audioToken: candidate.audioToken,
          semanticFamily: candidate.semanticFamily,
          tags: Object.freeze([...candidate.tags]),
          durationUs: candidate.durationUs,
          loudnessDb: candidate.loudnessDb,
          defaultVolume: candidate.defaultVolume,
        })
      })
    },

    /** @param {{projectId: string, semanticFamily: string, importance: string, desiredDurationUs: number, tags?: string[]}} input */
    async resolveCue(input) {
      if (
        !opaqueId(input?.projectId) || !soundFamilies.has(input?.semanticFamily) ||
        !importanceLevels.has(input?.importance) ||
        !Number.isSafeInteger(input?.desiredDurationUs) || input.desiredDurationUs <= 0 ||
        input.desiredDurationUs > 10_000_000 || !validTags(input?.tags ?? [])
      ) throw new SfxCatalogError('SFX_CATALOG_INPUT_INVALID', 400)
      const requestedTags = new Set(input.tags ?? [])
      const candidates = entries
        .filter((entry) => entry.state === 'active' &&
          (entry.projectId === input.projectId || entry.projectId === globalProjectId) &&
          entry.semanticFamily === input.semanticFamily)
        .map((entry) => ({
          entry,
          tagMatches: entry.tags.filter((/** @type {string} */ tag) => requestedTags.has(tag)).length,
          durationDelta: Math.abs(entry.durationUs - input.desiredDurationUs),
        }))
        .sort((left, right) => right.tagMatches - left.tagMatches ||
          left.durationDelta - right.durationDelta || left.entry.audioToken.localeCompare(right.entry.audioToken))
      for (const candidate of candidates) {
        if (await audioLibrary.isAuthorizedTrack({
          projectId: candidate.entry.projectId,
          trackId: candidate.entry.audioToken,
        }) !== true) continue
        const importanceScale = input.importance === 'high' ? 1 : input.importance === 'low' ? 0.7 : 0.85
        return Object.freeze({
          audioToken: candidate.entry.audioToken,
          semanticFamily: candidate.entry.semanticFamily,
          durationUs: Math.min(candidate.entry.durationUs, input.desiredDurationUs),
          volume: Math.min(1, Math.max(0, candidate.entry.defaultVolume * importanceScale)),
          catalogFingerprint: fingerprintEntries(entries),
        })
      }
      return null
    },

    /** @param {{projectId: string, audioToken: string}} input */
    async acquireAudio(input) {
      return acquireCatalogAudio(input)
    },

    /** @param {{projectId: string, audioToken: string, workId: string, signal?: AbortSignal}} input */
    async materializeAudio(input) {
      if (!opaqueId(input?.workId) || (input.signal !== undefined && !(input.signal instanceof AbortSignal))) {
        throw new SfxCatalogError('SFX_CATALOG_INPUT_INVALID', 400)
      }
      const lease = await acquireCatalogAudio({
        projectId: input.projectId,
        audioToken: input.audioToken,
      })
      if (
        !lease || typeof lease.extension !== 'string' ||
        !/^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(lease.extension) ||
        typeof lease.sha256 !== 'string' || !shaPattern.test(lease.sha256) ||
        !Number.isSafeInteger(lease.size) || lease.size <= 0 ||
        typeof lease.createStream !== 'function' || typeof lease.release !== 'function'
      ) {
        await lease?.release?.().catch(() => {})
        return null
      }
      const workFingerprint = createHash('sha256').update(input.workId).digest('hex').slice(0, 16)
      const ownedRoot = resolve(workRoot, `${workFingerprint}-${randomUUID()}`)
      const path = resolve(ownedRoot, `sfx${lease.extension}`)
      let released = false
      const release = async () => {
        if (released) return
        released = true
        await lease.release().catch(() => {})
        await rm(ownedRoot, { recursive: true, force: true }).catch(() => {})
      }
      try {
        input.signal?.throwIfAborted()
        await mkdir(ownedRoot, { recursive: false, mode: 0o700 })
        const digest = createHash('sha256')
        let size = 0
        const verifier = new Transform({
          transform(chunk, _encoding, callback) {
            size += chunk.length
            digest.update(chunk)
            callback(null, chunk)
          },
        })
        await pipeline(
          lease.createStream(),
          verifier,
          createWriteStream(path, { flags: 'wx', mode: 0o600 }),
          { signal: input.signal },
        )
        if (size !== lease.size || digest.digest('hex') !== lease.sha256) {
          throw new SfxCatalogError('SFX_CATALOG_AUDIO_UNAVAILABLE')
        }
        return Object.freeze({ path, release })
      } catch (error) {
        await release()
        if (input.signal?.aborted || /** @type {any} */ (error)?.name === 'AbortError') throw error
        if (error instanceof SfxCatalogError) throw error
        throw new SfxCatalogError('SFX_CATALOG_AUDIO_UNAVAILABLE')
      }
    },

    /** @param {string} projectId */
    snapshot(projectId) {
      if (!opaqueId(projectId)) throw new SfxCatalogError('SFX_CATALOG_INPUT_INVALID', 400)
      const projectEntries = entries.filter((entry) =>
        (entry.projectId === projectId || entry.projectId === globalProjectId) && entry.state === 'active')
      /** @type {Record<string, number>} */
      const families = {}
      for (const family of [...soundFamilies].sort()) {
        const count = projectEntries.filter((entry) => entry.semanticFamily === family).length
        if (count > 0) families[family] = count
      }
      return Object.freeze({
        schemaVersion,
        ready: projectEntries.length > 0,
        count: projectEntries.length,
        families: Object.freeze(families),
        audioTokens: Object.freeze(projectEntries.map((entry) => entry.audioToken).sort()),
        fingerprint: fingerprintEntries(projectEntries),
      })
    },
  })
}

export const sfxCatalogContract = Object.freeze({
  schemaVersion,
  maxEntries,
  soundFamilies: Object.freeze([...soundFamilies].sort()),
})

/** @param {{catalog: Awaited<ReturnType<typeof createSfxCatalog>>}} input */
export const createSfxCatalogHandler = ({ catalog }) => async (/** @type {Request} */ request) => {
  const pathname = new URL(request.url).pathname
  const match = pathname.match(/^\/api\/sfx-catalog\/projects\/([^/]+)$/u)
  if (!match || request.method !== 'GET') {
    return new Response(JSON.stringify({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }), {
      status: 405,
      headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8' },
    })
  }
  try {
    const snapshot = catalog.snapshot(decodeURIComponent(match[1]))
    return new Response(JSON.stringify({
      schema_version: 1,
      ready: snapshot.ready,
      count: snapshot.count,
      families: snapshot.families,
      audio_tokens: snapshot.audioTokens,
      fingerprint: snapshot.fingerprint,
    }), {
      headers: {
        'cache-control': 'no-store',
        'content-type': 'application/json; charset=utf-8',
        'x-content-type-options': 'nosniff',
      },
    })
  } catch (error) {
    const status = error instanceof SfxCatalogError ? error.status : 500
    const code = error instanceof SfxCatalogError ? error.code : 'SFX_CATALOG_UNAVAILABLE'
    return new Response(JSON.stringify({ error: { code, message: 'SFX catalog operation failed safely.' } }), {
      status,
      headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8' },
    })
  }
}
