import { createHash, randomUUID } from 'node:crypto'
import { copyFile, mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

import { isCreativeBeatIntent } from './creative-retrieval.mjs'
import {
  isCreativeAudioCueDecision,
  isCreativeTechniqueDecision,
} from './creative-technique-policy.mjs'
import { isSafeCreativeText } from './creative-text-safety.mjs'

const defaultRepositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const schemaVersion = 1
const maxRecords = 2_000
const idPattern = /^[A-Za-z0-9._:-]{1,180}$/u
const sha256Pattern = /^[a-f0-9]{64}$/u
const timestampPattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/u
const topKeys = ['schema_version', 'records']
const recordKeys = [
  'schema_version', 'trace_id', 'project_id', 'storyboard_job_id', 'attempt_id',
  'generation', 'lease_token_fingerprint', 'input_fingerprint',
  'knowledge_snapshot_fingerprint', 'created_at', 'beats',
  'timeline_revision_fingerprint',
]
const beatKeys = [
  'sentence_id', 'beat_intent', 'intent_source', 'retrieved_recipe_ids',
  'selected_recipe_id', 'preferred_realization', 'realized_as',
  'degradation_reason', 'candidate_evidence_ids', 'selection_reason', 'technique_policy', 'audio_cues',
]
const techniqueBeatKeys = beatKeys.filter((key) => key !== 'audio_cues')
const legacyBeatKeys = techniqueBeatKeys.filter((key) => key !== 'technique_policy')

export class CreativeDecisionTraceRepositoryError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'CreativeDecisionTraceRepositoryError'
    this.code = code
  }
}

/** @param {string} code @returns {never} */
const fail = (code) => { throw new CreativeDecisionTraceRepositoryError(code) }
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys @returns {value is Record<string, any>} */
const exactKeys = (value, keys) => isRecord(value) && Object.keys(value).length === keys.length &&
  keys.every((key) => Object.hasOwn(value, key))
/** @param {unknown} value @param {number} [max] */
const safeText = (value, max = 180) => isSafeCreativeText(value, max)
/** @param {unknown} value */
const safeId = (value) => typeof value === 'string' && idPattern.test(value)
/** @param {unknown} value @param {number} max */
const safeIdList = (value, max) => Array.isArray(value) && value.length <= max &&
  new Set(value).size === value.length && value.every(safeId)
/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {string} value */
const hash = (value) => createHash('sha256').update(value).digest('hex')
/** @param {string} parent @param {string} child */
const isInside = (parent, child) => {
  const base = resolve(parent).toLowerCase()
  const target = resolve(child).toLowerCase()
  return target === base || target.startsWith(`${base}${sep}`)
}

/** @param {unknown} value */
const validBeat = (value) => (exactKeys(value, beatKeys) || exactKeys(value, techniqueBeatKeys) ||
  exactKeys(value, legacyBeatKeys)) && safeId(value.sentence_id) &&
  isCreativeBeatIntent(value.beat_intent) &&
  (value.intent_source === 'llm_gateway' || value.intent_source === 'deterministic_fallback') &&
  safeIdList(value.retrieved_recipe_ids, 8) && value.retrieved_recipe_ids.length >= 3 &&
  (value.selected_recipe_id === null || (safeId(value.selected_recipe_id) && value.retrieved_recipe_ids.includes(value.selected_recipe_id))) &&
  safeText(value.preferred_realization, 80) &&
  (value.realized_as === 'shadow_only' || value.realized_as === 'active_context') &&
  (value.degradation_reason === null || safeText(value.degradation_reason, 120)) &&
  safeIdList(value.candidate_evidence_ids, 10) && safeText(value.selection_reason, 120) &&
  (!Object.hasOwn(value, 'technique_policy') || value.technique_policy === null ||
    isCreativeTechniqueDecision(value.technique_policy)) &&
  (!Object.hasOwn(value, 'audio_cues') ||
    (Array.isArray(value.audio_cues) && value.audio_cues.length <= 3 &&
      value.audio_cues.every(isCreativeAudioCueDecision) &&
      value.audio_cues.every((cue) => cue.beat_id === value.sentence_id)))

/** @param {unknown} value */
const validTrace = (value) => exactKeys(value, recordKeys) && value.schema_version === schemaVersion &&
  safeId(value.trace_id) && safeId(value.project_id) && safeId(value.storyboard_job_id) &&
  safeId(value.attempt_id) && Number.isSafeInteger(value.generation) && value.generation >= 1 &&
  sha256Pattern.test(value.lease_token_fingerprint) && sha256Pattern.test(value.input_fingerprint) &&
  sha256Pattern.test(value.knowledge_snapshot_fingerprint) && timestampPattern.test(value.created_at) &&
  Array.isArray(value.beats) && value.beats.length > 0 && value.beats.length <= 30 &&
  value.beats.every(validBeat) && new Set(value.beats.map((beat) => beat.sentence_id)).size === value.beats.length &&
  (value.timeline_revision_fingerprint === null || sha256Pattern.test(value.timeline_revision_fingerprint))

/** @param {unknown} value */
const validDocument = (value) => exactKeys(value, topKeys) && value.schema_version === schemaVersion &&
  Array.isArray(value.records) && value.records.length <= maxRecords && value.records.every(validTrace)

const emptyDocument = () => ({ schema_version: schemaVersion, records: [] })

/** @param {string} filePath @returns {Promise<Record<string, any>>} */
const readDocument = async (filePath) => {
  /** @param {string} path @returns {Promise<Record<string, any>>} */
  const parse = async (path) => {
    const text = await readFile(path, 'utf8')
    if (Buffer.byteLength(text, 'utf8') > 8 * 1024 * 1024) fail('CREATIVE_TRACE_STORE_INVALID')
    const parsed = JSON.parse(text)
    if (!validDocument(parsed)) fail('CREATIVE_TRACE_STORE_INVALID')
    return parsed
  }
  try {
    return await parse(filePath)
  } catch (error) {
    if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') return emptyDocument()
    try {
      const backup = await parse(`${filePath}.bak`)
      await writeAtomic(filePath, backup, false)
      return backup
    } catch {
      fail('CREATIVE_TRACE_STORE_CORRUPT')
    }
  }
}

/** @param {string} filePath @param {Record<string, any>} document @param {boolean} [preservePrimary] */
const writeAtomic = async (filePath, document, preservePrimary = true) => {
  if (!validDocument(document)) fail('CREATIVE_TRACE_STORE_INVALID')
  const temporaryPath = `${filePath}.${randomUUID()}.tmp`
  try {
    await writeFile(temporaryPath, `${JSON.stringify(document)}\n`, { encoding: 'utf8', mode: 0o600 })
    if (preservePrimary) await copyFile(filePath, `${filePath}.bak`).catch((error) => {
      if (!(error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT')) throw error
    })
    await rename(temporaryPath, filePath)
  } catch {
    await unlink(temporaryPath).catch(() => {})
    fail('CREATIVE_TRACE_STORE_WRITE_FAILED')
  }
}

/** @param {Record<string, any>} value */
const traceKey = (value) => `${value.project_id}\u0000${value.storyboard_job_id}\u0000${value.knowledge_snapshot_fingerprint}`
/** @param {string} projectId @param {string} storyboardJobId @param {string} fingerprint */
const publicTraceId = (projectId, storyboardJobId, fingerprint) =>
  `creative-trace-${hash(`${projectId}\u0000${storyboardJobId}\u0000${fingerprint}`).slice(0, 32)}`

/** @param {Record<string, any>} input */
const toTrace = (input) => {
  if (!safeId(input?.projectId) || !safeId(input?.storyboardJobId) || !safeId(input?.attemptId) ||
      !Number.isSafeInteger(input?.generation) || input.generation < 1 ||
      typeof input?.leaseToken !== 'string' || input.leaseToken.length < 16 ||
      !sha256Pattern.test(input?.inputFingerprint) || !sha256Pattern.test(input?.knowledgeSnapshotFingerprint) ||
      !timestampPattern.test(input?.createdAt) || !Array.isArray(input?.beats)) {
    fail('CREATIVE_TRACE_INPUT_INVALID')
  }
  const trace = {
    schema_version: schemaVersion,
    trace_id: publicTraceId(input.projectId, input.storyboardJobId, input.knowledgeSnapshotFingerprint),
    project_id: input.projectId,
    storyboard_job_id: input.storyboardJobId,
    attempt_id: input.attemptId,
    generation: input.generation,
    lease_token_fingerprint: hash(input.leaseToken),
    input_fingerprint: input.inputFingerprint,
    knowledge_snapshot_fingerprint: input.knowledgeSnapshotFingerprint,
    created_at: input.createdAt,
    beats: clone(input.beats).map((beat) => ({
      ...beat,
      technique_policy: beat.technique_policy ?? null,
      audio_cues: beat.audio_cues ?? [],
    })),
    timeline_revision_fingerprint: null,
  }
  if (!validTrace(trace)) fail('CREATIVE_TRACE_INPUT_INVALID')
  return trace
}

/** @param {Record<string, any>} existing @param {Record<string, any>} input */
const assertFence = (existing, input) => {
  const leaseFingerprint = hash(input.leaseToken)
  if (existing.generation > input.generation ||
      (existing.generation === input.generation &&
        (existing.attempt_id !== input.attemptId || existing.lease_token_fingerprint !== leaseFingerprint))) {
    fail('CREATIVE_TRACE_WRITE_FENCED')
  }
}

/**
 * @param {{dataRoot: string, repositoryRoot?: string, securePrivateRoot?: (path: string) => Promise<void>}} options
 */
export const createCreativeDecisionTraceRepository = async ({
  dataRoot,
  repositoryRoot = defaultRepositoryRoot,
  securePrivateRoot = async () => {},
}) => {
  if (!isAbsolute(dataRoot) || isInside(repositoryRoot, dataRoot)) fail('CREATIVE_TRACE_DATA_ROOT_UNSAFE')
  const traceRoot = resolve(dataRoot, 'creative-planning')
  await mkdir(traceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(traceRoot)
  const filePath = resolve(traceRoot, 'decision-traces.json')
  let queue = Promise.resolve()
  /** @param {(document: Record<string, any>) => Promise<{document: Record<string, any>, result: any}>} operation */
  const mutate = (operation) => {
    const run = async () => {
      const document = await readDocument(filePath)
      const output = await operation(clone(document))
      await writeAtomic(filePath, output.document)
      return clone(output.result)
    }
    const result = queue.then(run, run)
    queue = result.then(() => undefined, () => undefined)
    return result
  }
  const initial = await readDocument(filePath)
  await writeAtomic(filePath, initial)
  return Object.freeze({
    async save(/** @type {Record<string, any>} */ input) {
      const candidate = toTrace(input)
      return mutate(async (document) => {
        const records = /** @type {Record<string, any>[]} */ (document.records)
        const index = records.findIndex((entry) => traceKey(entry) === traceKey(candidate))
        if (index >= 0) {
          assertFence(records[index], input)
          records[index] = candidate
        } else {
          records.push(candidate)
        }
        document.records = records
          .sort((left, right) => left.created_at.localeCompare(right.created_at))
          .slice(-maxRecords)
        return { document, result: candidate }
      })
    },
    async bindTimeline(/** @type {Record<string, any>} */ input) {
      if (!sha256Pattern.test(input?.timelineRevisionFingerprint) ||
          !safeId(input?.projectId) || !safeId(input?.storyboardJobId) ||
          !sha256Pattern.test(input?.knowledgeSnapshotFingerprint) ||
          !safeId(input?.attemptId) || !Number.isSafeInteger(input?.generation) ||
          typeof input?.leaseToken !== 'string' ||
          (input.techniquePolicies !== undefined &&
            (!Array.isArray(input.techniquePolicies) || !input.techniquePolicies.every(isCreativeTechniqueDecision)))) {
        fail('CREATIVE_TRACE_INPUT_INVALID')
      }
      return mutate(async (document) => {
        const records = /** @type {Record<string, any>[]} */ (document.records)
        const key = `${input.projectId}\u0000${input.storyboardJobId}\u0000${input.knowledgeSnapshotFingerprint}`
        const index = records.findIndex((entry) => traceKey(entry) === key)
        if (index < 0) fail('CREATIVE_TRACE_NOT_FOUND')
        assertFence(records[index], input)
        if (input.techniquePolicies !== undefined) {
          const policies = new Map(input.techniquePolicies.map((/** @type {Record<string, any>} */ policy) => [policy.beat_id, policy]))
          if (policies.size !== records[index].beats.length ||
              records[index].beats.some((/** @type {Record<string, any>} */ beat) => !policies.has(beat.sentence_id))) {
            fail('CREATIVE_TRACE_INPUT_INVALID')
          }
          records[index].beats = records[index].beats.map((/** @type {Record<string, any>} */ beat) => ({
            ...beat,
            technique_policy: clone(policies.get(beat.sentence_id)),
          }))
        }
        records[index].timeline_revision_fingerprint = input.timelineRevisionFingerprint
        return { document, result: records[index] }
      })
    },
    async get(/** @type {{projectId: string, storyboardJobId: string, knowledgeSnapshotFingerprint: string}} */ { projectId, storyboardJobId, knowledgeSnapshotFingerprint }) {
      const document = await readDocument(filePath)
      const key = `${projectId}\u0000${storyboardJobId}\u0000${knowledgeSnapshotFingerprint}`
      return clone(/** @type {Record<string, any>[]} */ (document.records)
        .find((entry) => traceKey(entry) === key) ?? null)
    },
  })
}
