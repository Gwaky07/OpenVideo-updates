[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidatePattern('^v\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$')][string]$Version,
    [string]$RepositoryRoot,
    [string]$FeedRoot = 'S:\Codex\releases\openvideo-updates',
    [string]$Summary = 'OpenVideo whole-product update',
    [string]$NotesPath
)
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest

# Windows PowerShell 5.1's `Set-Content -Encoding utf8` writes a BOM.  Keep the
# public manifest BOM-free so clients in every runtime can parse it directly.
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
function Write-Utf8NoBom([string]$Path, [string]$Content) {
    [IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

if([string]::IsNullOrWhiteSpace($RepositoryRoot)){ $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
$root = [IO.Path]::GetFullPath($RepositoryRoot)
$feed = [IO.Path]::GetFullPath($FeedRoot)
if(-not(Test-Path (Join-Path $feed '.git'))){ throw 'OPENVIDEO_FULL_FEED_REQUIRES_GIT' }

$build = Join-Path $root 'scripts\Build-OpenVideoFullUpdate.ps1'
$logFile = Join-Path $env:TEMP ('ov-build-' + [guid]::NewGuid().ToString('N') + '.log')
$buildProc = Start-Process -FilePath 'powershell.exe' -ArgumentList @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', ('"' + $build + '"'),
    '-Version', $Version,
    '-RepositoryRoot', ('"' + $root + '"'),
    '-OutputDirectory', ('"' + (Join-Path $root 'release') + '"')
) -NoNewWindow -PassThru -RedirectStandardOutput $logFile -Wait
if($buildProc.ExitCode -ne 0){ Get-Content $logFile; throw 'OPENVIDEO_FULL_UPDATE_BUILD_FAILED' }

$zip = Join-Path $root ("release\OpenVideo-$Version-windows.zip")
$validator = Join-Path $root 'scripts\Validate-OpenVideoUpdatePackage.ps1'
$valLog = Join-Path $env:TEMP ('ov-validate-' + [guid]::NewGuid().ToString('N') + '.log')
$valProc = Start-Process -FilePath 'powershell.exe' -ArgumentList @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', ('"' + $validator + '"'),
    '-PackagePath', ('"' + $zip + '"'),
    '-Scope', 'full'
) -NoNewWindow -PassThru -RedirectStandardOutput $valLog -Wait
if($valProc.ExitCode -ne 0){ Get-Content $valLog; throw 'OPENVIDEO_FULL_UPDATE_PACKAGE_REJECTED' }

$metaPath = Join-Path $root 'release\latest-full.json'
$meta = Get-Content $metaPath -Raw | ConvertFrom-Json
$meta.summary = $Summary
if([string]::IsNullOrWhiteSpace($NotesPath) -or -not (Test-Path $NotesPath)){
    $meta.notes = @('Page, Gateway and launcher upgrade together', 'Failed apply rolls back to the previous release')
} else {
    $meta.notes = (Get-Content $NotesPath -Raw) -split "`r?`n" | Where-Object { $_ -and $_.Trim().Length -gt 0 }
}
Copy-Item -LiteralPath $zip -Destination (Join-Path $feed (Split-Path $zip -Leaf)) -Force
$meta.package.url = ('https://raw.githubusercontent.com/Gwaky07/OpenVideo-updates/main/' + (Split-Path $zip -Leaf))
$manifestPath = Join-Path $feed 'latest.json'
Write-Utf8NoBom -Path $manifestPath -Content (($meta | ConvertTo-Json -Depth 8) + [Environment]::NewLine)
if(Test-Path -LiteralPath (Join-Path $root 'START-HERE.md')){
    Copy-Item -LiteralPath (Join-Path $root 'START-HERE.md') -Destination (Join-Path $feed 'README.md') -Force
}
$stageItems = @('latest.json', (Split-Path $zip -Leaf))
if(Test-Path -LiteralPath (Join-Path $feed 'README.md')){ $stageItems += 'README.md' }
git -C $feed add @stageItems
if($LASTEXITCODE -ne 0){ throw 'OPENVIDEO_FULL_FEED_STAGE_FAILED' }
if(-not (git -C $feed diff --cached --quiet)){
    git -C $feed commit -m ("Publish OpenVideo " + $Version) --quiet
    if($LASTEXITCODE -ne 0){ throw 'OPENVIDEO_FULL_FEED_COMMIT_FAILED' }
    git -C $feed push origin HEAD:main
    if($LASTEXITCODE -ne 0){ throw 'OPENVIDEO_FULL_FEED_PUSH_FAILED' }
}
Remove-Item -LiteralPath (Join-Path $feed 'frontend.zip') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $feed 'frontend-update.json') -Force -ErrorAction SilentlyContinue
try {
    git -C $feed add -A 2>&1 | Out-Null
    git -C $feed diff --cached --quiet
    $diffQuiet = $LASTEXITCODE -eq 0
} catch { $diffQuiet = $true }
if(-not $diffQuiet){
    git -C $feed commit -m ("Remove obsolete frontend artefacts for " + $Version) --quiet
    if($LASTEXITCODE -ne 0){ throw 'OPENVIDEO_FULL_FEED_COMMIT_FAILED' }
    git -C $feed push origin HEAD:main
    if($LASTEXITCODE -ne 0){ throw 'OPENVIDEO_FULL_FEED_PUSH_FAILED' }
}
Write-Host ("OPENVIDEO_FULL_FEED_READY: " + $Version)
