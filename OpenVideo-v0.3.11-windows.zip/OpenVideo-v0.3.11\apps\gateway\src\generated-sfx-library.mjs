import { createHash, randomUUID } from 'node:crypto'
import { lstat, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { Readable } from 'node:stream'

export const generatedSfxProjectId = 'openvideo_builtin_sfx'
const sampleRate = 48_000
const twoPi = Math.PI * 2

/** @typedef {{id: string, family: string, durationMs: number, volume: number}} GeneratedSfxDefinition */
/** @type {ReadonlyArray<GeneratedSfxDefinition>} */
const definitions = Object.freeze([
  { id: 'sfx_builtin_camera_v1', family: 'camera', durationMs: 240, volume: 0.5 },
  { id: 'sfx_builtin_foley_v1', family: 'foley', durationMs: 320, volume: 0.45 },
  { id: 'sfx_builtin_impact_v1', family: 'impact', durationMs: 650, volume: 0.65 },
  { id: 'sfx_builtin_riser_v1', family: 'riser', durationMs: 900, volume: 0.55 },
  { id: 'sfx_builtin_sparkle_v1', family: 'sparkle', durationMs: 780, volume: 0.45 },
  { id: 'sfx_builtin_text_v1', family: 'text', durationMs: 280, volume: 0.4 },
  { id: 'sfx_builtin_transition_v1', family: 'transition', durationMs: 620, volume: 0.5 },
  { id: 'sfx_builtin_whoosh_v1', family: 'whoosh', durationMs: 520, volume: 0.5 },
])

/** @param {string | Buffer} value */
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
/** @param {number} value */
const clamp = (value) => Math.max(-1, Math.min(1, value))

/** @param {number} index */
const deterministicNoise = (index) => {
  const value = Math.sin((index + 1) * 12.9898) * 43_758.5453
  return (value - Math.floor(value)) * 2 - 1
}

/** @param {string} family @param {number} time @param {number} progress @param {number} index */
const sampleFor = (family, time, progress, index) => {
  const decay = Math.exp(-5 * progress)
  if (family === 'camera') {
    const click = progress < 0.08 ? deterministicNoise(index) * (1 - progress / 0.08) : 0
    return click * 0.7 + Math.sin(twoPi * 1_800 * time) * decay * 0.25
  }
  if (family === 'foley') {
    const first = Math.exp(-70 * Math.abs(progress - 0.18))
    const second = Math.exp(-80 * Math.abs(progress - 0.55))
    return Math.sin(twoPi * 520 * time) * (first + second * 0.75) * 0.5
  }
  if (family === 'impact') {
    return Math.sin(twoPi * (75 - 35 * progress) * time) * Math.exp(-4 * progress) * 0.85 +
      deterministicNoise(index) * Math.exp(-12 * progress) * 0.25
  }
  if (family === 'riser') {
    const frequency = 180 + 1_800 * progress * progress
    return Math.sin(twoPi * frequency * time) * Math.sin(Math.PI * progress) * 0.45
  }
  if (family === 'sparkle') {
    return (
      Math.sin(twoPi * 1_150 * time) +
      Math.sin(twoPi * 1_725 * time) * 0.65 +
      Math.sin(twoPi * 2_300 * time) * 0.35
    ) * decay * 0.28
  }
  if (family === 'text') {
    return Math.sin(twoPi * (720 + 240 * progress) * time) * decay * 0.55
  }
  if (family === 'transition') {
    const frequency = 1_400 - 1_050 * progress
    return (
      Math.sin(twoPi * frequency * time) * 0.25 + deterministicNoise(index) * 0.16
    ) * Math.sin(Math.PI * progress)
  }
  return deterministicNoise(index) * Math.sin(Math.PI * progress) * 0.32 +
    Math.sin(twoPi * (220 + 900 * progress) * time) * Math.sin(Math.PI * progress) * 0.18
}

/** @param {GeneratedSfxDefinition} definition */
const wavFor = (definition) => {
  const sampleCount = Math.round(sampleRate * definition.durationMs / 1_000)
  const pcmBytes = sampleCount * 2
  const buffer = Buffer.allocUnsafe(44 + pcmBytes)
  buffer.write('RIFF', 0, 'ascii')
  buffer.writeUInt32LE(36 + pcmBytes, 4)
  buffer.write('WAVE', 8, 'ascii')
  buffer.write('fmt ', 12, 'ascii')
  buffer.writeUInt32LE(16, 16)
  buffer.writeUInt16LE(1, 20)
  buffer.writeUInt16LE(1, 22)
  buffer.writeUInt32LE(sampleRate, 24)
  buffer.writeUInt32LE(sampleRate * 2, 28)
  buffer.writeUInt16LE(2, 32)
  buffer.writeUInt16LE(16, 34)
  buffer.write('data', 36, 'ascii')
  buffer.writeUInt32LE(pcmBytes, 40)
  for (let index = 0; index < sampleCount; index += 1) {
    const time = index / sampleRate
    const progress = index / Math.max(1, sampleCount - 1)
    const envelope = Math.min(1, progress * 80) * Math.min(1, (1 - progress) * 80)
    const sample = clamp(sampleFor(definition.family, time, progress, index) * envelope)
    buffer.writeInt16LE(Math.round(sample * 32_000), 44 + index * 2)
  }
  return buffer
}

/**
 * OpenVideo-owned deterministic starter sounds. They are generated into the
 * private runtime and never committed as media or exposed by path.
 * @param {{dataRoot: string, securePrivateRoot?: (path: string) => Promise<void>}} input
 */
export const createGeneratedSfxLibrary = async ({
  dataRoot,
  securePrivateRoot = async () => {},
}) => {
  const root = resolve(dataRoot, 'creative-sfx', 'builtin-v1')
  await mkdir(root, { recursive: true, mode: 0o700 })
  const metadata = await lstat(root)
  if (!metadata.isDirectory() || metadata.isSymbolicLink()) throw new Error('GENERATED_SFX_STORAGE_INVALID')
  await securePrivateRoot(root)
  const records = new Map()
  for (const definition of definitions) {
    const bytes = wavFor(definition)
    const fingerprint = sha256(bytes)
    const path = resolve(root, `${definition.id}.wav`)
    let current = null
    try { current = await readFile(path) } catch (error) {
      if (/** @type {NodeJS.ErrnoException} */ (error)?.code !== 'ENOENT') throw error
    }
    if (!current || sha256(current) !== fingerprint) {
      const temporaryPath = resolve(root, `.${definition.id}.${randomUUID()}.tmp`)
      try {
        await writeFile(temporaryPath, bytes, { flag: 'wx', mode: 0o600 })
        await rm(path, { force: true })
        await rename(temporaryPath, path)
      } finally {
        await rm(temporaryPath, { force: true }).catch(() => {})
      }
    }
    records.set(definition.id, Object.freeze({
      ...definition,
      path,
      size: bytes.length,
      sha256: fingerprint,
      durationUs: definition.durationMs * 1_000,
    }))
  }

  /** @param {{projectId?: string, trackId?: string}} input */
  const find = (input) => input?.projectId === generatedSfxProjectId &&
    typeof input?.trackId === 'string' ? records.get(input.trackId) ?? null : null
  /** @param {{projectId?: string, trackId?: string}} input */
  const authorized = async (input) => {
    const record = find(input)
    if (!record) return false
    try { return sha256(await readFile(record.path)) === record.sha256 } catch { return false }
  }
  return Object.freeze({
    listCatalogEntries: () => [...records.values()].map((record) => ({
      projectId: generatedSfxProjectId,
      audioToken: record.id,
      semanticFamily: record.family,
      tags: ['builtin', record.family],
      durationUs: record.durationUs,
      loudnessDb: -18,
      defaultVolume: record.volume,
      sourceFingerprint: record.sha256,
      licenseFingerprint: sha256(`openvideo-generated-sfx-v1\u0000${record.sha256}`),
    })),
    isAuthorizedTrack: authorized,
    async describeTrack(/** @type {{projectId?: string, trackId?: string}} */ input) {
      const record = find(input)
      if (!record || !(await authorized(input))) return null
      return Object.freeze({
        trackId: record.id,
        label: `${record.family}.wav`,
        extension: '.wav',
        size: record.size,
        sha256: record.sha256,
      })
    },
    async acquireTrackLease(/** @type {{projectId?: string, trackId?: string}} */ input) {
      const record = find(input)
      if (!record) return null
      let bytes
      try { bytes = await readFile(record.path) } catch { return null }
      if (sha256(bytes) !== record.sha256) return null
      let consumed = false
      let released = false
      return Object.freeze({
        extension: '.wav',
        sha256: record.sha256,
        size: bytes.length,
        createStream: () => {
          if (consumed || released) throw new Error('GENERATED_SFX_LEASE_CONSUMED')
          consumed = true
          return Readable.from(bytes)
        },
        release: async () => { released = true },
      })
    },
  })
}

export const generatedSfxContract = Object.freeze({
  projectId: generatedSfxProjectId,
  entries: definitions.map(({ id, family, durationMs }) => ({ id, family, durationMs })),
})
