import { createHash } from 'node:crypto'
import { lstat, mkdtemp, opendir, readFile, realpath, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createJianyingDraftDecryptor, isEncryptedDraftContent } from './jianying-draft-decrypt.mjs'
import { readFileNoReparseBuffer, readFilesNoReparse } from './jianying-native-safe-file.mjs'
import {
  computePackagingCatalogFingerprint,
  computePackagingResourceToken,
  createJianyingDesktopBinding,
  assertSafePackagingText,
} from './jianying-packaging-resource-index.mjs'

const authorizationPattern = /^ovauth_[A-Za-z0-9_-]{8,160}$/u
const versionPattern = /^[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const privateEffectIdPattern = /^[A-Za-z0-9_-]{4,80}$/u
const maxFiles = 4096
const maxTraversalNodes = 16_384
const maxDepth = 64
const maxFileBytes = 256 * 1024 * 1024
const maxTotalBytes = 512 * 1024 * 1024
const maxMaterials = 20_000
const legacyBucketFamilies = Object.freeze({ audios: 'bgm', flowers: 'flower', stickers: 'sticker' })
const effectFamilies = Object.freeze({
  text_shape: 'bubble',
  text_effect: 'flower',
  mix_mode: 'blend',
  filter: 'filter',
  video_effect: 'video_effect',
  effect: 'video_effect',
})

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} code @param {number} [status] @param {unknown} [diagnostic] @returns {never} */
const fail = (code, status = 503, diagnostic = undefined) => {
  const error = /** @type {Error & {code?: string, status?: number, diagnostic?: unknown}} */ (new Error(code))
  error.code = code
  error.status = status
  error.diagnostic = diagnostic
  throw error
}
/** @param {string} parent @param {string} candidate */
const inside = (parent, candidate) => {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}
/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {unknown} value */
const safeLabel = (value) => {
  if (typeof value !== 'string' || value.trim().length === 0 || value.trim().length > 160) return false
  try {
    assertSafePackagingText(value.trim(), 'label', 160)
    return true
  } catch {
    return false
  }
}

/** @param {unknown} error @returns {never} */
const failNativeRead = (error) => {
  const message = error instanceof Error ? error.message : ''
  if (message === 'JY018_NATIVE_FILE_TOO_LARGE' || message === 'JY018_NATIVE_TOTAL_TOO_LARGE') fail('NATIVE018_SOURCE_TOO_LARGE', 413)
  if (message === 'JY018_NATIVE_REPARSE_REJECTED') fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
  fail('NATIVE018_DRAFT_SOURCE_UNAVAILABLE', 503)
}

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * Windows realpath may expand an 8.3 alias. Different spellings are accepted
 * only when both names still identify the same non-reparse object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats} requestedMetadata
 * @param {typeof lstat} inspect
 */
const sameResolvedObject = async (requested, actual, requestedMetadata, inspect = lstat) => {
  if (requestedMetadata.isSymbolicLink()) return false
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await inspect(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && !actualMetadata.isSymbolicLink() &&
    objectIdentity(requestedMetadata) === objectIdentity(actualMetadata)
}

/**
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata
 * @param {'ctime'|'mtime'} field
 */
const statTimeIdentity = (metadata, field) => {
  const candidate = /** @type {{ctimeNs?: bigint, mtimeNs?: bigint}} */ (/** @type {unknown} */ (metadata))
  const value = field === 'ctime' ? candidate.ctimeNs : candidate.mtimeNs
  if (typeof value === 'bigint') return value.toString()
  return String(field === 'ctime' ? metadata.ctimeMs : metadata.mtimeMs)
}

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const directoryGeneration = (metadata) => `${objectIdentity(metadata)}:${statTimeIdentity(metadata, 'ctime')}:${statTimeIdentity(metadata, 'mtime')}`

/** @param {unknown} folder @param {typeof lstat} inspect @param {typeof realpath} resolveReal */
const verifyDirectory = async (folder, inspect = lstat, resolveReal = realpath) => {
  if (typeof folder !== 'string' || !path.isAbsolute(folder)) fail('NATIVE018_DRAFT_SOURCE_INVALID', 400)
  const resolved = path.resolve(folder)
  if (path.dirname(resolved) === resolved) fail('NATIVE018_DRAFT_SOURCE_INVALID', 400)
  try {
    const parent = path.dirname(resolved)
    const [metadata, parentMetadata, actual, actualParent] = await Promise.all([
      inspect(resolved, { bigint: true }), inspect(parent, { bigint: true }), resolveReal(resolved), resolveReal(parent),
    ])
    if (!metadata.isDirectory() || !await sameResolvedObject(resolved, actual, metadata, inspect)) {
      fail('NATIVE018_DRAFT_SOURCE_INVALID', 400)
    }
    if (!parentMetadata.isDirectory() || !await sameResolvedObject(parent, actualParent, parentMetadata, inspect)) {
      fail('NATIVE018_DRAFT_SOURCE_INVALID', 400)
    }
    return Object.freeze({
      path: resolved,
      realPath: path.resolve(actual),
      identity: objectIdentity(metadata),
      parent,
      parentGeneration: directoryGeneration(parentMetadata),
    })
  } catch (error) {
    const candidate = /** @type {{code?: unknown}} */ (error)
    if (typeof candidate?.code === 'string' && candidate.code.startsWith('NATIVE018_')) throw error
    fail('NATIVE018_DRAFT_SOURCE_UNAVAILABLE', 503)
  }
}

/** @param {{path: string, realPath: string, identity: string, parent: string, parentGeneration: string}} binding @param {typeof lstat} inspect @param {typeof realpath} resolveReal */
const assertDirectoryBindingCurrent = async (binding, inspect = lstat, resolveReal = realpath) => {
  try {
    const [metadata, parentMetadata, actual, actualParent] = await Promise.all([
      inspect(binding.path, { bigint: true }), inspect(binding.parent, { bigint: true }), resolveReal(binding.path), resolveReal(binding.parent),
    ])
    if (!metadata.isDirectory() || objectIdentity(metadata) !== binding.identity ||
        !await sameResolvedObject(binding.path, actual, metadata, inspect) || !parentMetadata.isDirectory() ||
        directoryGeneration(parentMetadata) !== binding.parentGeneration ||
        !await sameResolvedObject(binding.parent, actualParent, parentMetadata, inspect)) {
      fail('NATIVE018_SOURCE_CHANGED', 409)
    }
  } catch (error) {
    const candidate = /** @type {{code?: unknown}} */ (error)
    if (candidate?.code === 'NATIVE018_SOURCE_CHANGED') throw error
    fail('NATIVE018_SOURCE_CHANGED', 409)
  }
}

/** @param {string} draftFolder */
const readManifest = async (draftFolder) => {
  const actualDraftFolder = await realpath(draftFolder)
  /** @type {{name: string, size: number, sha256: string}[]} */
  const entries = []
  /** @type {{path: string, relativeName: string}[]} */
  const files = []
  let fileCount = 0
  let traversalNodes = 0
  /** @param {string} current @param {string} relativeName */
  const visit = async (current, relativeName, depth = 0) => {
    if (depth > maxDepth) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    traversalNodes += 1
    if (traversalNodes > maxTraversalNodes) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    const metadata = await lstat(current, { bigint: true })
    if (metadata.isSymbolicLink()) fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
    const actual = await realpath(current)
    if (!inside(actualDraftFolder, actual) || !await sameResolvedObject(current, actual, metadata)) {
      fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
    }
    if (metadata.isDirectory()) {
      const directory = await opendir(current)
      try {
        for await (const child of directory) {
          if (child.isSymbolicLink()) fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
          await visit(path.join(current, child.name), relativeName ? `${relativeName}/${child.name}` : child.name, depth + 1)
        }
      } finally {
        await directory.close().catch(() => {})
      }
      return
    }
    if (!metadata.isFile()) return
    fileCount += 1
    if (fileCount > maxFiles || metadata.size > maxFileBytes) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    files.push({ path: current, relativeName: relativeName.replaceAll('\\', '/') })
  }
  try { await visit(draftFolder, '') } catch (error) {
    const candidate = /** @type {{code?: unknown}} */ (error)
    if (typeof candidate?.code === 'string' && candidate.code.startsWith('NATIVE018_')) throw error
    if (error instanceof Error && /^JY018_NATIVE_/u.test(error.message)) failNativeRead(error)
    fail('NATIVE018_DRAFT_SOURCE_UNAVAILABLE', 503)
  }
  let contents
  try {
    contents = await readFilesNoReparse(files.map(({ path: filePath }) => ({ path: filePath, rootPath: draftFolder })), {
      maxFileBytes,
      maxTotalBytes,
      maxStdoutBytes: 768 * 1024 * 1024,
      asBuffer: true,
    })
  } catch (error) { failNativeRead(error) }
  let totalBytes = 0
  for (let index = 0; index < files.length; index += 1) {
    const content = contents[index]
    const bytes = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8')
    const actualSize = bytes.byteLength
    if (actualSize > maxFileBytes) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    totalBytes += actualSize
    if (totalBytes > maxTotalBytes) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    entries.push({ name: files[index].relativeName, size: actualSize, sha256: createHash('sha256').update(bytes).digest('hex') })
  }
  entries.sort((/** @type {{name: string}} */ left, /** @type {{name: string}} */ right) => left.name.localeCompare(right.name))
  const sourceFingerprint = createHash('sha256').update(JSON.stringify({ schema_version: 1, files: entries })).digest('hex')
  return { sourceFingerprint, files: entries }
}

/**
 * Observe every object in the authorized draft without reading file bytes.
 * The generation includes object identity and ctime, so a same-size/mtime
 * replacement cannot reuse a completed full-byte verification.
 * @param {string} draftFolder
 */
const observeManifestGeneration = async (draftFolder) => {
  const verifiedFolder = await verifyDirectory(draftFolder)
  /** @type {{kind: 'directory'|'file', name: string, identity: string, ctime: string, mtime: string, size?: string}[]} */
  const entries = []
  let fileCount = 0
  let traversalNodes = 0
  /** @param {string} current @param {string} relativeName @param {number} depth */
  const visit = async (current, relativeName, depth = 0) => {
    if (depth > maxDepth) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    traversalNodes += 1
    if (traversalNodes > maxTraversalNodes) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    const metadata = await lstat(current, { bigint: true })
    if (metadata.isSymbolicLink()) fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
    const actual = await realpath(current)
    if (!inside(verifiedFolder.realPath, actual) || !await sameResolvedObject(current, actual, metadata)) {
      fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
    }
    const name = relativeName.replaceAll('\\', '/')
    if (metadata.isDirectory()) {
      entries.push({
        kind: 'directory',
        name,
        identity: objectIdentity(metadata),
        ctime: statTimeIdentity(metadata, 'ctime'),
        mtime: statTimeIdentity(metadata, 'mtime'),
      })
      const directory = await opendir(current)
      try {
        for await (const child of directory) {
          if (child.isSymbolicLink()) fail('NATIVE018_REPARSE_POINT_REJECTED', 409)
          await visit(path.join(current, child.name), relativeName ? `${relativeName}/${child.name}` : child.name, depth + 1)
        }
      } finally {
        await directory.close().catch(() => {})
      }
      return
    }
    if (!metadata.isFile()) return
    fileCount += 1
    if (fileCount > maxFiles || metadata.size > BigInt(maxFileBytes)) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
    entries.push({
      kind: 'file',
      name,
      identity: objectIdentity(metadata),
      ctime: statTimeIdentity(metadata, 'ctime'),
      mtime: statTimeIdentity(metadata, 'mtime'),
      size: metadata.size.toString(),
    })
  }
  try {
    await assertDirectoryBindingCurrent(verifiedFolder)
    await visit(verifiedFolder.path, '', 0)
    await assertDirectoryBindingCurrent(verifiedFolder)
  } catch (error) {
    const candidate = /** @type {{code?: unknown}} */ (error)
    if (typeof candidate?.code === 'string' && candidate.code.startsWith('NATIVE018_')) throw error
    fail('NATIVE018_DRAFT_SOURCE_UNAVAILABLE', 503)
  }
  entries.sort((left, right) => `${left.kind}:${left.name}`.localeCompare(`${right.kind}:${right.name}`))
  return Object.freeze({
    path: verifiedFolder.path,
    generation: createHash('sha256').update(JSON.stringify({
      schema_version: 1,
      root_identity: verifiedFolder.identity,
      parent_generation: verifiedFolder.parentGeneration,
      entries,
    })).digest('hex'),
  })
}

/** Compute the current authorized draft manifest without exposing its path. */
/** @param {string} draftFolder @returns {Promise<string>} */
export const computeJianyingPrivateDraftSourceFingerprint = async (draftFolder) => {
  const verifiedFolder = await verifyDirectory(draftFolder)
  await assertDirectoryBindingCurrent(verifiedFolder)
  const fingerprint = (await readManifest(verifiedFolder.path)).sourceFingerprint
  await assertDirectoryBindingCurrent(verifiedFolder)
  return fingerprint
}

/**
 * Keep a bounded server-local cache of completed full-byte verifications.
 * Cache reuse is keyed by authorization and a freshly observed full-tree
 * object generation, never by age. Pending and failed computations are not
 * cached. Callers that need an operation-wide guard perform another compute
 * after their protected work; repeating the same traversal inside one compute
 * adds latency without making its point-in-time result atomic.
 * @param {{observeGeneration?: typeof observeManifestGeneration, readFullFingerprint?: typeof computeJianyingPrivateDraftSourceFingerprint, maxEntries?: number}} [options]
 */
export const createJianyingPrivateDraftSourceFingerprintValidator = ({
  observeGeneration = observeManifestGeneration,
  readFullFingerprint = computeJianyingPrivateDraftSourceFingerprint,
  maxEntries = 8,
} = {}) => {
  if (!Number.isSafeInteger(maxEntries) || maxEntries < 1 || maxEntries > 64) {
    throw new TypeError('NATIVE018_SOURCE_CACHE_LIMIT_INVALID')
  }
  /** @type {Map<string, string>} */
  const completed = new Map()
  /** @type {Map<string, Promise<string>>} */
  const inFlight = new Map()
  /** @param {string} authorizationId @param {{path: string, generation: string}} observation */
  const cacheKey = (authorizationId, observation) => createHash('sha256').update(JSON.stringify({
    schema_version: 1,
    authorization_id: authorizationId,
    source_path: observation.path,
    source_generation: observation.generation,
  })).digest('hex')
  /** @param {string} expected @param {{path: string, generation: string}} observation @param {string} authorizationId */
  const assertObservationCurrent = (expected, observation, authorizationId) => {
    if (cacheKey(authorizationId, observation) !== expected) fail('NATIVE018_SOURCE_CHANGED', 409)
  }
  return Object.freeze({
    /** @param {{authorizationId: string, draftFolder: string}} input */
    async compute({ authorizationId, draftFolder }) {
      if (typeof authorizationId !== 'string' || !authorizationPattern.test(authorizationId)) {
        fail('NATIVE018_DRAFT_AUTHORIZATION_INVALID', 400)
      }
      const before = await observeGeneration(draftFolder)
      const key = cacheKey(authorizationId, before)
      const cached = completed.get(key)
      if (cached) return cached
      let pending = inFlight.get(key)
      if (!pending) {
        pending = (async () => {
          const fingerprint = await readFullFingerprint(draftFolder)
          assertObservationCurrent(key, await observeGeneration(draftFolder), authorizationId)
          completed.set(key, fingerprint)
          while (completed.size > maxEntries) completed.delete(/** @type {string} */ (completed.keys().next().value))
          return fingerprint
        })()
        inFlight.set(key, pending)
        void pending.finally(() => {
          if (inFlight.get(key) === pending) inFlight.delete(key)
        }).catch(() => {})
      }
      return pending
    },
  })
}

/** @param {Record<string, any>} desktop @returns {Promise<Record<string, any> & {profileId: string, version: string, executablePath: string, installRoot: string, installDir: string, dllFingerprint: string}>} */
const validateDesktop = async (desktop) => {
  if (!record(desktop) || desktop.available !== true || typeof desktop.profileId !== 'string' ||
      !/^jianying-[a-z0-9-]{1,80}$/u.test(desktop.profileId) || typeof desktop.version !== 'string' ||
      !versionPattern.test(desktop.version) || typeof desktop.executablePath !== 'string' ||
      !path.isAbsolute(desktop.executablePath) || typeof desktop.installRoot !== 'string' ||
      !path.isAbsolute(desktop.installRoot) || typeof desktop.dllFingerprint !== 'string' ||
      !fingerprintPattern.test(desktop.dllFingerprint)) fail('NATIVE018_DESKTOP_BINDING_INVALID', 409)
  const executablePath = path.resolve(desktop.executablePath)
  const installRoot = path.resolve(desktop.installRoot)
  const installDir = path.dirname(executablePath)
  if (!inside(installRoot, executablePath) || path.basename(executablePath).toLowerCase() !== 'jianyingpro.exe' ||
      path.basename(installDir).toLowerCase() !== desktop.version.toLowerCase()) {
    fail('NATIVE018_DESKTOP_BINDING_INVALID', 409)
  }
  const dllPath = path.join(installDir, 'videoeditor.dll')
  try {
    const [exeStat, dllStat, actualDllFingerprint, actualExe, actualDll] = await Promise.all([
      lstat(executablePath), lstat(dllPath), readFileNoReparseBuffer(dllPath, installRoot, maxFileBytes).then((value) => createHash('sha256').update(value).digest('hex')),
      realpath(executablePath), realpath(dllPath),
    ])
    if (!exeStat.isFile() || !dllStat.isFile() ||
        !await sameResolvedObject(executablePath, actualExe, exeStat) ||
        !await sameResolvedObject(dllPath, actualDll, dllStat) ||
        actualDllFingerprint !== desktop.dllFingerprint.toLowerCase()) fail('NATIVE018_DESKTOP_BINDING_INVALID', 409)
  } catch (error) {
    const candidate = /** @type {{code?: unknown}} */ (error)
    if (typeof candidate?.code === 'string' && candidate.code.startsWith('NATIVE018_')) throw error
    fail('NATIVE018_DESKTOP_BINDING_UNAVAILABLE', 503)
  }
  return {
    ...desktop,
    profileId: /** @type {string} */ (desktop.profileId),
    version: /** @type {string} */ (desktop.version),
    executablePath,
    installRoot,
    installDir,
    dllFingerprint: desktop.dllFingerprint.toLowerCase(),
  }
}

/** @param {Record<string, any>} authorization @param {string} authorizationId */
const authorizationPath = (authorization, authorizationId) => {
  if (!record(authorization) ||
      (authorization.authorizationId !== authorizationId && authorization.id !== authorizationId) ||
      authorization.readOnly !== true || authorization.revoked === true || authorization.expired === true ||
      authorization.status !== 'authorized' || typeof authorization.absolutePath !== 'string') {
    fail('NATIVE018_DRAFT_AUTHORIZATION_UNAVAILABLE', 503)
  }
  return authorization.absolutePath
}

/** @param {unknown} content @param {string} profileId @param {string} appVersion @param {((entry: Record<string, any>, material: Record<string, any>) => void)|undefined} [observePrivateEntry] */
const extractEntries = (content, profileId, appVersion, observePrivateEntry = undefined) => {
  if (!record(content) || !record(content.materials)) fail('NATIVE018_DRAFT_STRUCTURE_INVALID', 409)
  /** @type {Record<string, any>[]} */
  const entries = []
  /** @param {string} family @param {Record<string, any>} material @param {boolean} [allowLegacyFlowerEffectId] @param {boolean} [skipUnboundMedia] */
  const addEntry = (family, material, allowLegacyFlowerEffectId = false, skipUnboundMedia = false) => {
    const resourceId = material.resource_id
    if (typeof resourceId !== 'string' || resourceId.length < 4 || resourceId.length > 160) {
      // Jianying stores ordinary source media and captions in the same legacy
      // buckets as packaging resources. Those records often have no native
      // packaging binding and must not make otherwise valid effect/sticker
      // evidence fail closed; advanced buckets remain strict below.
      if (skipUnboundMedia) return
      fail('NATIVE018_DRAFT_STRUCTURE_INVALID', 409)
    }
    /** @type {Record<string, any>} */
    const privateBinding = { resourceId }
    if (family === 'video_effect' && Object.hasOwn(material, 'effect_id')) {
      const effectId = material.effect_id
      if (typeof effectId !== 'string' || !privateEffectIdPattern.test(effectId)) {
        fail('NATIVE018_DRAFT_STRUCTURE_INVALID', 409)
      }
      // Current Jianying-managed effects can be newer than the pinned Writer's
      // enum catalog. Preserve only the exact private identity pair required by
      // the controlled dynamic Writer path.
      privateBinding.effectId = effectId
    } else if (family === 'bubble' || (family === 'flower' && !allowLegacyFlowerEffectId && material.type !== 'text_effect')) {
      const effectId = material.effect_id
      if (typeof effectId !== 'string' || effectId.length < 4 || effectId.length > 160) {
        fail('NATIVE018_DRAFT_STRUCTURE_INVALID', 409)
      }
      privateBinding.effectId = effectId
    } else if (family === 'flower' && typeof material.effect_id === 'string' && material.effect_id.length >= 4 && material.effect_id.length <= 160 && (allowLegacyFlowerEffectId || material.type === 'text_effect')) {
      // Native text_effect entries are identified by resource_id; preserve an
      // available effect id so a later writer admission can bind both fields.
      privateBinding.effectId = material.effect_id
    }
    const label = material.name ?? material.title ?? material.label ?? `草稿${family}资源`
    if (!safeLabel(label)) return
    const entry = {
      packaging_token: computePackagingResourceToken({ family, profileId, appVersion, privateBinding }),
      family,
      label: label.trim(),
      tags: ['draft', 'user-owned'],
      state: 'discoverable',
      writer_eligible: false,
      parameter_schema: {},
      private_binding: privateBinding,
    }
    entries.push(entry)
    observePrivateEntry?.(entry, material)
    if (entries.length > maxMaterials) fail('NATIVE018_CATALOG_TOO_LARGE', 413)
  }
  for (const [bucket, legacyFamily] of Object.entries(legacyBucketFamilies)) {
    const materials = content.materials[bucket]
    if (!Array.isArray(materials)) continue
    for (const material of materials) {
      if (!record(material)) continue
      addEntry(legacyFamily, material, true, true)
    }
  }
  const effects = content.materials.effects
  if (Array.isArray(effects)) {
    for (const material of effects) {
      if (!record(material)) continue
      const type = typeof material.type === 'string' ? material.type.trim().toLocaleLowerCase() : ''
      const family = Object.hasOwn(effectFamilies, type)
        ? effectFamilies[/** @type {keyof typeof effectFamilies} */ (type)]
        : 'video_effect'
      addEntry(family, material)
    }
  }
  // Newer Jianying drafts split packaging materials into dedicated buckets.
  // Keep these mappings provider-neutral and require the same native binding
  // shape as the legacy effect bucket; ordinary source media is never inferred.
  const packagingBuckets = [
    ['video_effects', 'video_effect'],
    ['text_templates', 'flower'],
    ['common_mask', 'mask'],
    ['material_animations', 'video_animation'],
  ]
  for (const [bucket, family] of packagingBuckets) {
    const materials = content.materials[bucket]
    if (!Array.isArray(materials)) continue
    for (const material of materials) {
      if (!record(material)) continue
      addEntry(family, material, false, bucket === 'material_animations')
    }
  }
  const seen = new Set()
  return entries.filter((entry) => {
    if (seen.has(entry.packaging_token)) return false
    seen.add(entry.packaging_token)
    return true
  })
}

/**
 * Create a read-only, provider-neutral decoder for an authorized Jianying
 * draft. Private paths and resource bindings remain in the returned closure
 * and never appear in the public extraction result.
 *
 * @param {{decryptor?: ReturnType<typeof createJianyingDraftDecryptor>, readFile?: typeof readFile, lstat?: typeof lstat, realpath?: typeof realpath}} [options]
 */
export const createJianyingPrivateDraftDecoder = ({ decryptor = undefined, readFile: read = readFile, lstat: inspect = lstat, realpath: resolveReal = realpath } = {}) => {
  /** @param {{authorization: Record<string, any>, desktop: Record<string, any>}} input @param {string|undefined} packagingToken */
  const extract = async ({ authorization, desktop }, packagingToken = undefined) => {
    const boundDesktop = await validateDesktop(desktop)
    const authorizationId = authorization?.authorizationId ?? authorization?.id
    if (typeof authorizationId !== 'string' || !authorizationPattern.test(authorizationId)) fail('NATIVE018_DRAFT_AUTHORIZATION_INVALID', 400)
    const sourceBinding = await verifyDirectory(authorizationPath(authorization, authorizationId), inspect, resolveReal)
    const draftFolder = sourceBinding.path
    const contentPath = path.join(draftFolder, 'draft_content.json')
    await assertDirectoryBindingCurrent(sourceBinding, inspect, resolveReal)
    const before = await readManifest(draftFolder)
    await assertDirectoryBindingCurrent(sourceBinding, inspect, resolveReal)
    let temporaryRoot = null
    let plaintextPath = contentPath
    try {
      let raw
      try {
        raw = read === readFile
          ? await readFileNoReparseBuffer(contentPath, draftFolder, maxFileBytes)
          : await read(contentPath)
      } catch (error) {
        const candidate = /** @type {{code?: unknown}} */ (error)
        if (typeof candidate?.code === 'string' && candidate.code.startsWith('NATIVE018_')) throw error
        if (error instanceof Error && /^JY018_NATIVE_/u.test(error.message)) failNativeRead(error)
        fail('NATIVE018_DRAFT_SOURCE_UNAVAILABLE', 503)
      }
      await assertDirectoryBindingCurrent(sourceBinding, inspect, resolveReal)
      if (isEncryptedDraftContent(raw)) {
        const activeDecryptor = decryptor ?? createJianyingDraftDecryptor({
          installRoot: boundDesktop.installRoot,
          appVersion: boundDesktop.version,
          expectedDllFingerprint: boundDesktop.dllFingerprint,
        })
        temporaryRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy018-'))
        const encryptedPath = path.join(temporaryRoot, 'draft_content.encrypted')
        plaintextPath = path.join(temporaryRoot, 'draft_content.json')
        await writeFile(encryptedPath, raw, { mode: 0o600 })
        try {
          await activeDecryptor.ensurePlaintextFile(encryptedPath, plaintextPath)
        } catch (error) {
          const candidate = /** @type {{code?: unknown, status?: unknown}} */ (error)
          if (candidate?.code === 'JY_TEMPLATE_DECRYPT_OUTPUT_TOO_LARGE') {
            fail('NATIVE018_SOURCE_TOO_LARGE', 413)
          }
          const code = candidate?.code === 'JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION'
            ? 'NATIVE018_DECODER_UNSUPPORTED_VERSION'
            : candidate?.code === 'JY_TEMPLATE_DECRYPT_DLL_MISMATCH'
              ? 'NATIVE018_DESKTOP_BINDING_INVALID'
              : 'NATIVE018_DECODER_UNAVAILABLE'
          fail(code, candidate?.status === 409 ? 409 : 503)
        }
      }
      let content
      try {
        const plaintext = plaintextPath === contentPath && read === readFile
          ? raw
          : plaintextPath !== contentPath
            ? await readFileNoReparseBuffer(plaintextPath, /** @type {string} */ (temporaryRoot), maxFileBytes)
            : await read(plaintextPath, 'utf8')
        const plaintextBytes = Buffer.isBuffer(plaintext) ? plaintext : Buffer.from(String(plaintext), 'utf8')
        if (plaintextBytes.byteLength > maxFileBytes) fail('NATIVE018_SOURCE_TOO_LARGE', 413)
        content = JSON.parse(plaintextBytes.toString('utf8'))
      } catch (error) {
        const candidate = /** @type {{code?: unknown}} */ (error)
        if (typeof candidate?.code === 'string' && candidate.code.startsWith('NATIVE018_')) throw error
        if (error instanceof Error && /^JY018_NATIVE_/u.test(error.message)) failNativeRead(error)
        fail('NATIVE018_DRAFT_STRUCTURE_INVALID', 409)
      }
      const privateMaterials = new Map()
      const entries = extractEntries(content, boundDesktop.profileId, boundDesktop.version, (entry, material) => {
        if (!privateMaterials.has(entry.packaging_token)) privateMaterials.set(entry.packaging_token, structuredClone(material))
      })
      await assertDirectoryBindingCurrent(sourceBinding, inspect, resolveReal)
      const after = await readManifest(draftFolder)
      await assertDirectoryBindingCurrent(sourceBinding, inspect, resolveReal)
      if (before.sourceFingerprint !== after.sourceFingerprint) fail('NATIVE018_SOURCE_CHANGED', 409)
      const desktopBinding = createJianyingDesktopBinding(boundDesktop)
      const result = Object.freeze({
        entries: Object.freeze(entries),
        sourceFingerprint: before.sourceFingerprint,
        catalogFingerprint: computePackagingCatalogFingerprint({ profileId: boundDesktop.profileId, appVersion: boundDesktop.version, entries, desktopBinding }),
        profileId: boundDesktop.profileId,
        appVersion: boundDesktop.version,
        desktopBinding,
      })
      if (packagingToken === undefined) return result
      const catalogEntry = entries.find((entry) => entry.packaging_token === packagingToken)
      const sourceMaterial = privateMaterials.get(packagingToken)
      if (!catalogEntry || !['sticker', 'flower', 'video_effect'].includes(catalogEntry.family) || !sourceMaterial) {
        fail('NATIVE018_DUO_PROBE_BINDING_UNAVAILABLE', 409)
      }
      return Object.freeze({
        ...result,
        catalogEntry,
        sourceMaterial: Object.freeze(sourceMaterial),
      })
    } finally {
      if (temporaryRoot) await rm(temporaryRoot, { recursive: true, force: true })
    }
  }
  return Object.freeze({
    /** @param {{authorization: Record<string, any>, desktop: Record<string, any>}} input */
    extract: (input) => extract(input),
    /**
     * Private Gate-A seam. Raw resource identity never crosses the Gateway or
     * Catalog DTO; it is returned only to the task-owned Duo probe runner.
     * @param {{authorization: Record<string, any>, desktop: Record<string, any>, packagingToken: string}} input
     */
    async extractDuoProbeMaterial({ authorization, desktop, packagingToken }) {
      if (!/^ovj(?:sticker|flower|video_effect)_v1_[a-f0-9]{24}$/u.test(packagingToken ?? '')) {
        fail('NATIVE018_DUO_PROBE_TOKEN_INVALID', 400)
      }
      return await extract({ authorization, desktop }, packagingToken)
    },
  })
}
