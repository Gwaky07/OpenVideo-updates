import { createHash, generateKeyPairSync, sign, verify } from 'node:crypto'
import { chmod, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  CAPCUT_MATE_PINNED_SOURCE_CHECKSUMS,
  createCapCutCatalogService,
} from '../apps/gateway/src/jianying-capcut-catalog-service.mjs'
import { CAPCUT_MATE_PINNED_COMMIT } from '../apps/gateway/src/jianying-capcut-catalog-importer.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const repositoryRoot = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const fingerprintPattern = /^[a-f0-9]{64}$/u
const sha256 = (value) => createHash('sha256').update(value).digest('hex')

const inside = (parent, candidate) => {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate))
  return relative === '' || (!!relative && !relative.startsWith('..') && !path.isAbsolute(relative))
}

const writePrivateAtomic = async (filePath, contents) => {
  await mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 })
  const temporary = `${filePath}.${process.pid}.tmp`
  try {
    await writeFile(temporary, contents, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
    await rename(temporary, filePath)
    await chmod(filePath, 0o600).catch(() => {})
  } catch (error) {
    await rm(temporary, { force: true }).catch(() => {})
    throw error
  }
}

const loadOrCreateSigningKey = async (dataRoot, securePrivateRoot) => {
  const keyRoot = path.join(dataRoot, 'catalog-signing', 'capcut-mate')
  await mkdir(keyRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(keyRoot)
  const privateKeyPath = path.join(keyRoot, 'private-key.pem')
  const publicKeyPath = path.join(keyRoot, 'public-key.pem')
  try {
    const [privateKey, publicKey] = await Promise.all([
      readFile(privateKeyPath, 'utf8'),
      readFile(publicKeyPath, 'utf8'),
    ])
    return { privateKey, publicKey }
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  const pair = generateKeyPairSync('ed25519')
  const privateKey = pair.privateKey.export({ type: 'pkcs8', format: 'pem' }).toString()
  const publicKey = pair.publicKey.export({ type: 'spki', format: 'pem' }).toString()
  await writePrivateAtomic(privateKeyPath, privateKey)
  await writePrivateAtomic(publicKeyPath, publicKey)
  return { privateKey, publicKey }
}

export const installCapCutMatePackagingCatalog = async ({
  dataRoot,
  sourceRoot,
  backupRoot,
  expectedSourceChecksums = CAPCUT_MATE_PINNED_SOURCE_CHECKSUMS,
  securePrivateRoot = securePrivateRuntimeRoot,
}) => {
  if (![dataRoot, sourceRoot, backupRoot].every((value) => typeof value === 'string' && path.isAbsolute(value)) ||
      inside(repositoryRoot, dataRoot) || inside(repositoryRoot, backupRoot) || inside(dataRoot, backupRoot)) {
    throw new Error('PACKAGING_CATALOG_INSTALLER_INPUT_INVALID')
  }
  await mkdir(backupRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(backupRoot)
  const keys = await loadOrCreateSigningKey(dataRoot, securePrivateRoot)
  const service = createCapCutCatalogService({
    dataRoot,
    sourceRoot,
    expectedSourceChecksums,
    signBackup: (payload) => sign(null, payload, keys.privateKey).toString('base64'),
    verifyBackup: (payload, signature) => verify(null, payload, keys.publicKey, Buffer.from(signature, 'base64')),
  })
  const installed = await service.install()
  if (installed.status !== 'ready' || installed.writer_eligible !== 0) {
    throw new Error('PACKAGING_CATALOG_INSTALLER_ADMISSION_VIOLATION')
  }
  const backup = await service.createBackup()
  const manifestFingerprint = backup.publicSummary?.manifestFingerprint
  if (!fingerprintPattern.test(manifestFingerprint ?? '') || !fingerprintPattern.test(backup.payloadFingerprint ?? '')) {
    throw new Error('PACKAGING_CATALOG_INSTALLER_BACKUP_INVALID')
  }
  const publicKeyFingerprint = sha256(Buffer.from(keys.publicKey))
  const backupPath = path.join(backupRoot, `capcut-mate-${manifestFingerprint}-${backup.payloadFingerprint}.signed.json`)
  const publicKeyPath = path.join(backupRoot, `capcut-mate-public-key-${publicKeyFingerprint}.pem`)
  await writePrivateAtomic(backupPath, `${JSON.stringify(backup)}\n`)
  await writePrivateAtomic(publicKeyPath, keys.publicKey)

  const offlineService = createCapCutCatalogService({ dataRoot, sourceRoot: null })
  const offlineSearch = await offlineService.search({ query: '', limit: 1 })
  if (offlineSearch.candidates.length !== 1 || offlineSearch.candidates[0].writerEligible !== false) {
    throw new Error('PACKAGING_CATALOG_INSTALLER_OFFLINE_SEARCH_INVALID')
  }

  const restoreRoot = path.join(dataRoot, 'tmp', `capcut-mate-restore-${process.pid}`)
  try {
    await service.restoreBackup(JSON.parse(await readFile(backupPath, 'utf8')), restoreRoot)
    const restoredService = createCapCutCatalogService({ dataRoot: restoreRoot, sourceRoot: null })
    const restored = await restoredService.summary()
    const restoredSearch = await restoredService.search({ query: '', limit: 1 })
    if (restored.status !== 'ready' || restored.writer_eligible !== 0 || restoredSearch.candidates.length !== 1 ||
        restoredSearch.candidates[0].writerEligible !== false) {
      throw new Error('PACKAGING_CATALOG_INSTALLER_RESTORE_INVALID')
    }
  } finally {
    await rm(restoreRoot, { recursive: true, force: true }).catch(() => {})
  }

  const shardEntries = backup.publicSummary.shards.map((entry) => entry.entries)
  const receipt = Object.freeze({
    schema_version: 1,
    kind: 'capcut_mate_installer_import_receipt',
    status: 'ready',
    rights_mode: 'import_only',
    source_commit: CAPCUT_MATE_PINNED_COMMIT,
    catalog_revision_token: installed.catalog_revision_token,
    manifest_fingerprint: manifestFingerprint,
    entries: installed.entries,
    families: installed.families,
    shards: Object.freeze({ count: shardEntries.length, maximum_entries: Math.max(...shardEntries) }),
    writer_eligible: 0,
    offline_search: Object.freeze({ status: 'ready', returned: offlineSearch.candidates.length }),
    signed_backup: Object.freeze({
      status: 'ready',
      algorithm: 'Ed25519',
      public_key_fingerprint: publicKeyFingerprint,
      payload_fingerprint: backup.payloadFingerprint,
      restore_status: 'ready',
    }),
  })
  const receiptRoot = path.join(dataRoot, 'evidence', 'packaging-catalog-001')
  await mkdir(receiptRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(receiptRoot)
  await writePrivateAtomic(path.join(receiptRoot, 'installer-receipt.json'), `${JSON.stringify(receipt, null, 2)}\n`)
  return receipt
}

const argument = (args, name) => {
  const index = args.indexOf(name)
  return index >= 0 ? args[index + 1] : null
}

const main = async () => {
  try {
    const args = process.argv.slice(2)
    const sourceRoot = argument(args, '--source-root')
    const backupRoot = argument(args, '--backup-root')
    const dataRoot = loadLocalRuntimeConfig(process.env, { repositoryRoot }).dataRoot
    const receipt = await installCapCutMatePackagingCatalog({
      dataRoot,
      sourceRoot: sourceRoot ? path.resolve(sourceRoot) : '',
      backupRoot: backupRoot ? path.resolve(backupRoot) : '',
    })
    process.stdout.write(`${JSON.stringify(receipt)}\n`)
  } catch (error) {
    const reason = error instanceof Error && /^[A-Z][A-Z0-9_]{2,159}$/u.test(error.message)
      ? error.message
      : 'PACKAGING_CATALOG_INSTALLER_FAILED'
    process.stdout.write(`${JSON.stringify({ status: 'failed', reason })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
