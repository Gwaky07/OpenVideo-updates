import { createHash } from 'node:crypto'
import { lstat, readdir, readFile, stat } from 'node:fs/promises'
import { DatabaseSync } from 'node:sqlite'
import { isAbsolute, join, relative, resolve } from 'node:path'

const maxListedDraftFiles = 800
const maxFileBytes = 48 * 1024 * 1024
const maxFavoriteFiles = 120
const maxFavoriteFileBytes = 8 * 1024 * 1024
const maxResourceCacheFiles = 3
const maxResourceCacheRows = 256
const maxResourceCacheRowBytes = 8 * 1024 * 1024
const maxMaterialRefs = 4_096
const voiceRefPattern = /^jyv_[a-f0-9]{24}$/u
const cacheTtlMs = 120_000
const skippedDirectoryNames = new Set([
  '.openvideo-locks',
  'timelines',
  'resources',
  'materials',
  'common_attachment',
  'recyclebin',
  'adjust_cache',
])
const draftContainerName = 'com.lveditor.draft'
const friendlyLabels = Object.freeze({
  xiaoluoli: '小萝莉',
  xinwennansheng: '新闻男声',
  BV411_streaming: '解说小帅',
})
/** @typedef {{speakerId: string, label: string}} VoiceEntry */
/** @typedef {{label: string}} NamedEntry */
/** @typedef {{resourceId: string, speakerId: string}} ResourceVoiceMapping */
/** @typedef {{file: string, modifiedAt: number, size: number}} CatalogFile */
/** @typedef {{file: string, modifiedAt: number, size: number}} ResourceCacheFile */
/** @typedef {{signature: string, mappings: ResourceVoiceMapping[], degraded: boolean}} ResourceMappingsCache */
/** @typedef {{modifiedAt: number, size: number, voices: VoiceEntry[], favorites: NamedEntry[], materialRefs: Array<[string, NamedEntry]>}} ParsedCatalogFile */
/** @param {string} name */
const skipDirectory = (name) => name.startsWith('.') || skippedDirectoryNames.has(name.toLowerCase())
/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} speakerId @param {string} label */
const voiceRef = (speakerId, label) => `jyv_${createHash('sha256').update(`${speakerId}\u0000${label}`).digest('hex').slice(0, 24)}`

/** @param {unknown} value @param {Map<string, VoiceEntry>} entries */
const collectVoiceEntries = (value, entries) => {
  if (Array.isArray(value)) { for (const item of value) collectVoiceEntries(item, entries); return }
  if (!isRecord(value)) return
  if (value.type === 'text_to_audio' && typeof value.tone_speaker === 'string' && typeof value.tone_type === 'string' && /^[A-Za-z][A-Za-z0-9_]{2,79}$/u.test(value.tone_speaker.trim()) && value.tone_type.trim()) {
    const speakerId = value.tone_speaker.trim()
    const rawLabel = value.tone_type.trim()
    const labels = /** @type {Record<string, string>} */ (friendlyLabels)
    const label = labels[speakerId] ?? labels[rawLabel] ?? rawLabel.slice(0, 80)
    entries.set(`${speakerId}\u0000${label}`, { speakerId, label })
  }
  for (const child of Object.values(value)) collectVoiceEntries(child, entries)
}

/** @param {unknown} value @param {Map<string, NamedEntry>} entries */
const collectFavoriteVoiceEntries = (value, entries) => {
  if (!isRecord(value)) return
  if (value.materialCategory === 'tone' && value.materialThirdcategory === 'tone_fav' && typeof value.materialName === 'string' && value.materialName.trim()) {
    const label = value.materialName.trim().slice(0, 80)
    entries.set(label, { label })
  }
}

/** @param {unknown} value @param {Map<string, NamedEntry>} entries */
const collectToneMaterialRefs = (value, entries) => {
  if (entries.size >= maxMaterialRefs) return
  if (Array.isArray(value)) { for (const item of value) collectToneMaterialRefs(item, entries); return }
  if (!isRecord(value)) return
  if (value.materialCategory === 'tone' && typeof value.materialName === 'string' && typeof value.materialId === 'string' && value.materialName.trim() && value.materialId.trim()) {
    entries.set(value.materialId.trim(), { label: value.materialName.trim().slice(0, 80) })
  }
  for (const child of Object.values(value)) collectToneMaterialRefs(child, entries)
}

/** @param {unknown} value @returns {Record<string, unknown> | null} */
const parseJsonObject = (value) => {
  if (typeof value !== 'string' || !value.trim()) return null
  try {
    const parsed = JSON.parse(value)
    return isRecord(parsed) ? parsed : null
  } catch { return null }
}

/** @param {unknown} value @returns {string | null} */
const readVoiceType = (value) => {
  if (!isRecord(value)) return null
  const direct = typeof value.voice_type === 'string' ? value.voice_type.trim() : ''
  if (direct && /^[A-Za-z][A-Za-z0-9_]{2,79}$/u.test(direct)) return direct
  for (const field of ['extra', 'biz_extra']) {
    const parent = typeof value[field] === 'string' ? parseJsonObject(value[field]) : isRecord(value[field]) ? value[field] : null
    const tone = typeof parent?.tonetype === 'string' ? parseJsonObject(parent.tonetype) : isRecord(parent?.tonetype) ? parent.tonetype : null
    const speaker = typeof tone?.voice_type === 'string' ? tone.voice_type.trim() : ''
    if (speaker && /^[A-Za-z][A-Za-z0-9_]{2,79}$/u.test(speaker)) return speaker
  }
  return null
}

/** @param {unknown} value @param {Set<string>} requestedIds @param {Map<string, ResourceVoiceMapping>} entries @param {number} depth */
const collectResourceVoiceMappings = (value, requestedIds, entries, depth = 0) => {
  if (depth > 24 || entries.size >= requestedIds.size) return
  if (Array.isArray(value)) { for (const item of value) collectResourceVoiceMappings(item, requestedIds, entries, depth + 1); return }
  if (!isRecord(value)) return
  const common = isRecord(value.common_attr) ? value.common_attr : null
  const resourceId = typeof value.id === 'string'
    ? value.id
    : typeof value.effect_id === 'string'
      ? value.effect_id
      : typeof common?.id === 'string'
        ? common.id
        : typeof common?.effect_id === 'string'
          ? common.effect_id
          : null
  if (resourceId && requestedIds.has(resourceId)) {
    const speakerId = readVoiceType(value)
    if (speakerId && !entries.has(resourceId)) entries.set(resourceId, { resourceId, speakerId })
  }
  for (const child of Object.values(value)) collectResourceVoiceMappings(child, requestedIds, entries, depth + 1)
}

/** @param {string[]} files @param {string[]} requestedMaterialIds @returns {{mappings: ResourceVoiceMapping[], degraded: boolean}} */
const readResourceVoiceMappings = (files, requestedMaterialIds) => {
  /** @type {Map<string, ResourceVoiceMapping>} */
  const mappings = new Map()
  const requestedIds = new Set(requestedMaterialIds.slice(0, maxMaterialRefs))
  let failedFiles = 0
  let truncated = false
  for (const file of files) {
    if (mappings.size >= requestedIds.size) break
    try {
      const db = new DatabaseSync(file, { readOnly: true })
      try {
        db.exec('PRAGMA busy_timeout = 250')
        const rows = db.prepare("SELECT response_body FROM http_cache WHERE length(response_body) <= ? AND instr(CAST(response_body AS TEXT), 'voice_type') > 0 ORDER BY rowid DESC LIMIT ?").iterate(maxResourceCacheRowBytes, maxResourceCacheRows + 1)
        let scannedRows = 0
        for (const row of rows) {
          scannedRows += 1
          if (scannedRows > maxResourceCacheRows) { truncated = true; break }
          const raw = row?.response_body
          const text = typeof raw === 'string' ? raw : Buffer.isBuffer(raw) ? raw.toString('utf8') : ''
          try { collectResourceVoiceMappings(JSON.parse(text), requestedIds, mappings) } catch { /* cache body may be partial */ }
          if (mappings.size >= requestedIds.size) break
        }
      } finally { db.close() }
    } catch { failedFiles += 1 }
  }
  return { mappings: [...mappings.values()], degraded: failedFiles > 0 || truncated }
}

/** @param {string[]} files @param {string[]} requestedMaterialIds @returns {Promise<{mappings: ResourceVoiceMapping[], degraded: boolean}>} */
const scanResourceVoiceMappings = (files, requestedMaterialIds) =>
  Promise.resolve(files.length === 0 || requestedMaterialIds.length === 0
    ? { mappings: [], degraded: false }
    : readResourceVoiceMappings(files, requestedMaterialIds))

/** @param {string} root @param {string} candidate */
const insideRoot = (root, candidate) => {
  const rel = relative(root, resolve(candidate))
  return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel))
}

/** @template T, R @param {T[]} items @param {number} limit @param {(item: T) => Promise<R>} mapper */
const mapLimit = async (items, limit, mapper) => {
  /** @type {R[]} */
  const results = []
  let index = 0
  await Promise.all(Array.from({ length: Math.min(Math.max(limit, 1), items.length || 1) }, async () => {
    while (index < items.length) {
      const current = index
      index += 1
      results[current] = await mapper(items[current])
    }
  }))
  return results
}

/** @param {string} directory @param {string} fileName @param {number} maxBytes @param {string} canonicalRoot */
const probeKnownFile = async (directory, fileName, maxBytes, canonicalRoot) => {
  const candidate = join(directory, fileName)
  try {
    const info = await lstat(candidate)
    if (insideRoot(canonicalRoot, candidate) && info.isFile() && info.size <= maxBytes) {
      return { file: candidate, modifiedAt: info.mtimeMs, size: info.size }
    }
  } catch { /* known file is optional */ }
  return null
}

/** @param {string | null} projectsRoot @returns {Promise<CatalogFile[]>} */
const listDraftContentFiles = async (projectsRoot) => {
  if (!projectsRoot) return []
  const canonicalRoot = resolve(projectsRoot)
  /** @type {import('node:fs').Dirent[]} */
  let projects
  try { projects = await readdir(projectsRoot, { withFileTypes: true }) } catch { return [] }
  /** @type {string[]} */
  const directories = []
  for (const project of projects) {
    if (!project.isDirectory() || skipDirectory(project.name)) continue
    const projectPath = join(projectsRoot, project.name)
    if (project.name === draftContainerName) {
      let drafts
      try { drafts = await readdir(projectPath, { withFileTypes: true }) } catch { continue }
      for (const draft of drafts) {
        if (!draft.isDirectory() || skipDirectory(draft.name)) continue
        directories.push(join(projectPath, draft.name))
      }
      continue
    }
    directories.push(projectPath)
  }
  const found = await mapLimit(directories.slice(0, maxListedDraftFiles), 16, (directory) =>
    probeKnownFile(directory, 'draft_content.json', maxFileBytes, canonicalRoot))
  return found.filter((item) => item !== null).sort((left, right) => right.modifiedAt - left.modifiedAt).slice(0, maxListedDraftFiles)
}

/** @param {string | null} userDataRoot @returns {Promise<CatalogFile[]>} */
const listFavoriteFiles = async (userDataRoot) => {
  if (!userDataRoot) return []
  const canonicalRoot = resolve(userDataRoot)
  const projectsRoot = join(userDataRoot, 'Projects')
  /** @type {import('node:fs').Dirent[]} */
  let projects
  try { projects = await readdir(projectsRoot, { withFileTypes: true }) } catch { projects = [] }
  /** @type {string[]} */
  const directories = []
  for (const project of projects) {
    if (!project.isDirectory() || skipDirectory(project.name)) continue
    const projectPath = join(projectsRoot, project.name)
    if (project.name === draftContainerName) {
      let drafts
      try { drafts = await readdir(projectPath, { withFileTypes: true }) } catch { continue }
      for (const draft of drafts) {
        if (!draft.isDirectory() || skipDirectory(draft.name)) continue
        directories.push(join(projectPath, draft.name))
      }
      continue
    }
    directories.push(projectPath)
  }
  const configRoot = join(userDataRoot, 'Config')
  directories.push(configRoot)
  /** @type {import('node:fs').Dirent[]} */
  let configEntries
  try { configEntries = await readdir(configRoot, { withFileTypes: true }) } catch { configEntries = [] }
  for (const entry of configEntries) {
    if (!entry.isDirectory() || skipDirectory(entry.name)) continue
    directories.push(join(configRoot, entry.name))
  }
  const found = await mapLimit(directories.slice(0, maxFavoriteFiles * 8), 16, (directory) =>
    probeKnownFile(directory, 'key_value.json', maxFavoriteFileBytes, canonicalRoot))
  return found.filter((item) => item !== null).slice(0, maxFavoriteFiles)
}

/** @param {CatalogFile} item @param {Map<string, ParsedCatalogFile>} cache @param {'draft' | 'favorite'} kind */
const readParsedCatalogFile = async (item, cache, kind) => {
  const cached = cache.get(item.file)
  if (cached && cached.modifiedAt === item.modifiedAt && cached.size === item.size) return cached
  /** @type {ParsedCatalogFile} */
  const parsed = { modifiedAt: item.modifiedAt, size: item.size, voices: [], favorites: [], materialRefs: [] }
  try {
    const text = await readFile(item.file, 'utf8')
    const useful = kind === 'draft'
      ? text.includes('text_to_audio') || text.includes('tone_speaker')
      : text.includes('materialCategory') || text.includes('tone_fav')
    if (useful) {
      const json = JSON.parse(text)
      if (kind === 'draft') {
        /** @type {Map<string, VoiceEntry>} */
        const voices = new Map()
        collectVoiceEntries(json, voices)
        parsed.voices = [...voices.values()]
      } else {
        /** @type {Map<string, NamedEntry>} */
        const favorites = new Map()
        /** @type {Map<string, NamedEntry>} */
        const refs = new Map()
        collectToneMaterialRefs(json, refs)
        for (const value of Object.values(json)) collectFavoriteVoiceEntries(value, favorites)
        parsed.favorites = [...favorites.values()]
        parsed.materialRefs = [...refs.entries()]
      }
    }
  } catch { /* ignore incomplete local files */ }
  cache.set(item.file, parsed)
  return parsed
}

/** @param {string | null} cacheRoot @returns {Promise<ResourceCacheFile[]>} */
const listResourceCacheFiles = async (cacheRoot) => {
  if (!cacheRoot) return []
  const canonicalRoot = resolve(cacheRoot)
  /** @param {string} candidate */
  const insideRoot = (candidate) => {
    const rel = relative(canonicalRoot, resolve(candidate))
    return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel))
  }
  try {
    const children = await readdir(cacheRoot, { withFileTypes: true })
    const candidates = await Promise.all(children.filter((entry) => entry.isDirectory()).map(async (entry) => {
      const file = join(cacheRoot, entry.name, 'rp.db')
      try {
        const raw = await lstat(file)
        const info = await stat(file)
        let modifiedAt = info.mtimeMs
        let footprint = info.size
        for (const suffix of ['-wal', '-shm']) {
          try {
            const sidecar = await lstat(`${file}${suffix}`)
            if (sidecar.isFile()) {
              modifiedAt = Math.max(modifiedAt, sidecar.mtimeMs)
              footprint += sidecar.size
            }
          } catch { /* sidecar is optional */ }
        }
        return insideRoot(file) && raw.isFile() ? { file, modifiedAt, size: footprint } : null
      } catch { return null }
    }))
    return candidates.filter((candidate) => candidate !== null).sort((left, right) => right.modifiedAt - left.modifiedAt).slice(0, maxResourceCacheFiles)
  } catch { return [] }
}

/** @param {{localAppData?: string, resourceScanner?: typeof scanResourceVoiceMappings} | undefined} options */
export const createJianyingVoiceCatalogService = (options = {}) => {
  const { localAppData = process.env.LOCALAPPDATA, resourceScanner = scanResourceVoiceMappings } = options
  const projectsRoot = typeof localAppData === 'string' && localAppData ? join(localAppData, 'JianyingPro', 'User Data', 'Projects') : null
  const userDataRoot = typeof localAppData === 'string' && localAppData ? join(localAppData, 'JianyingPro', 'User Data') : null
  const resourceCacheRoot = userDataRoot ? join(userDataRoot, 'Cache', 'ressdk_db') : null
  /** @type {{createdAt: number, entries: Map<string, VoiceEntry>, favoriteEntries: Map<string, NamedEntry>, degraded: boolean} | null} */
  let cache = null
  /** @type {Map<string, ParsedCatalogFile>} */
  const parsedFileCache = new Map()
  /** @type {ResourceMappingsCache | null} */
  let resourceMappingsCache = null
  /** @type {{signature: string, promise: Promise<{mappings: ResourceVoiceMapping[], degraded: boolean}>} | null} */
  let resourceMappingsPending = null
  /** @param {{force?: boolean}} options */
  const scan = async ({ force = false } = {}) => {
    if (!force && cache && Date.now() - cache.createdAt < cacheTtlMs) return cache
    /** @type {Map<string, VoiceEntry>} */
    const entries = new Map()
    /** @type {Map<string, NamedEntry>} */
    const favoriteEntries = new Map()
    /** @type {Map<string, NamedEntry>} */
    const materialRefs = new Map()
    const [draftFiles, favoriteFiles] = await Promise.all([
      listDraftContentFiles(projectsRoot),
      listFavoriteFiles(userDataRoot),
    ])
    const seenFiles = new Set([...draftFiles, ...favoriteFiles].map((item) => item.file))
    const draftParsed = await mapLimit(draftFiles, 8, (item) => readParsedCatalogFile(item, parsedFileCache, 'draft'))
    for (const parsed of draftParsed) {
      for (const voice of parsed.voices) entries.set(`${voice.speakerId}\u0000${voice.label}`, voice)
    }
    const favoriteParsed = await mapLimit(favoriteFiles, 8, (item) => readParsedCatalogFile(item, parsedFileCache, 'favorite'))
    for (const parsed of favoriteParsed) {
      for (const [resourceId, material] of parsed.materialRefs) materialRefs.set(resourceId, material)
      for (const favorite of parsed.favorites) favoriteEntries.set(favorite.label, favorite)
    }
    for (const file of parsedFileCache.keys()) if (!seenFiles.has(file)) parsedFileCache.delete(file)
    const resourceFiles = await listResourceCacheFiles(resourceCacheRoot)
    const requestedMaterialIds = [...materialRefs.keys()].sort()
    const materialSignature = createHash('sha256').update(requestedMaterialIds.join('\u0000')).digest('hex')
    const resourceSignature = `${resourceFiles.map(({ file, modifiedAt, size }) => `${file}\u0000${modifiedAt}\u0000${size}`).join('\u0001')}\u0002${materialSignature}`
    if (!resourceMappingsCache || resourceMappingsCache.signature !== resourceSignature) {
      if (!resourceMappingsPending || resourceMappingsPending.signature !== resourceSignature) {
        resourceMappingsPending = {
          signature: resourceSignature,
          promise: resourceScanner(resourceFiles.map(({ file }) => file), requestedMaterialIds),
        }
      }
      const pending = resourceMappingsPending
      try {
        resourceMappingsCache = { signature: resourceSignature, ...(await pending.promise) }
      } finally {
        if (resourceMappingsPending === pending) resourceMappingsPending = null
      }
    }
    for (const { resourceId, speakerId } of resourceMappingsCache.mappings) {
      const material = materialRefs.get(resourceId)
      if (material) entries.set(`${speakerId}\u0000${material.label}`, { speakerId, label: material.label })
    }
    for (const label of entries.values()) favoriteEntries.delete(label.label)
    cache = { createdAt: Date.now(), entries, favoriteEntries, degraded: resourceMappingsCache.degraded }
    return cache
  }
  return {
    /** @param {{force?: boolean}} [options] */
    async list(options) {
      const { entries, favoriteEntries, degraded } = await scan(options)
      return {
        available: Boolean(userDataRoot),
        degradedReason: degraded ? 'resource-cache-unavailable' : null,
        voices: [...entries.values()].sort((a, b) => a.label.localeCompare(b.label, 'zh-CN')).map(({ label, speakerId }) => ({ id: voiceRef(speakerId, label), label, locale: 'zh-CN', source: 'jianying-local-draft' })),
        unavailableVoices: [...favoriteEntries.values()].sort((a, b) => a.label.localeCompare(b.label, 'zh-CN')).map(({ label }) => ({ label, source: 'jianying-local-favorite', reason: 'requires-generated-draft' })),
      }
    },
    /** @param {string} id */
    async resolve(id) {
      if (typeof id !== 'string' || !voiceRefPattern.test(id)) return null
      const { entries } = await scan()
      for (const { label, speakerId } of entries.values()) if (voiceRef(speakerId, label) === id) return { label, speakerId }
      return null
    },
    /** @param {string} label */
    async resolveLabel(label) {
      if (typeof label !== 'string' || !label.trim()) return null
      const { entries } = await scan()
      const wanted = label.trim()
      for (const entry of entries.values()) if (entry.label === wanted) return { ...entry }
      return null
    },
    /** @param {string} label */
    async resolveUnavailableLabel(label) {
      if (typeof label !== 'string' || !label.trim()) return null
      const { favoriteEntries } = await scan()
      return favoriteEntries.get(label.trim()) ?? null
    },
  }
}

/** @param {unknown} body @param {number} status */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8', 'x-content-type-options': 'nosniff' } })

/** @param {{catalog: ReturnType<typeof createJianyingVoiceCatalogService>, presetsService: {add: (entry: VoiceEntry) => Promise<unknown>}}} dependencies @returns {(request: Request) => Promise<Response>} */
export const createJianyingVoiceCatalogHandler = ({ catalog, presetsService }) => async (request) => {
  const pathname = new URL(request.url).pathname
  try {
    if (pathname === '/api/settings/jianying-tts-voices' && request.method === 'GET') return jsonResponse(await catalog.list({ force: new URL(request.url).searchParams.get('refresh') === '1' }))
    if (pathname === '/api/settings/jianying-tts-voices' && request.method === 'POST') {
      if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') return jsonResponse({ error: { code: 'JIANYING_TTS_VOICE_INVALID' } }, 415)
      const body = await request.json()
      const resolved = body?.id
        ? await catalog.resolve(body.id)
        : await catalog.resolveLabel?.(body?.name)
      if (!resolved) {
        const unavailable = await catalog.resolveUnavailableLabel?.(body?.name)
        if (unavailable) return jsonResponse({ error: { code: 'JIANYING_TTS_VOICE_REQUIRES_GENERATED_DRAFT' } }, 409)
        return jsonResponse({ error: { code: 'JIANYING_TTS_VOICE_NOT_FOUND' } }, 404)
      }
      if (typeof body?.label === 'string' && body.label.trim()) resolved.label = body.label.trim().slice(0, 80)
      return jsonResponse(await presetsService.add(resolved), 201)
    }
    return jsonResponse({ error: { code: 'JIANYING_TTS_VOICE_NOT_FOUND' } }, 404)
  } catch { return jsonResponse({ error: { code: 'JIANYING_TTS_VOICE_CATALOG_UNAVAILABLE' } }, 503) }
}
