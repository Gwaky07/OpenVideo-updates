import { createHash, randomUUID } from 'node:crypto'
import { createReadStream, createWriteStream } from 'node:fs'
import { lstat, mkdir, mkdtemp, readFile, realpath, rm, stat, writeFile } from 'node:fs/promises'
import { pipeline } from 'node:stream/promises'
import os from 'node:os'
import path from 'node:path'

export const CAPCUT_MATE_PINNED_COMMIT = 'e886ba6cd1ba275fc68e4176ea448ba5b470cd28'
export const CAPCUT_MATE_RIGHTS_MODE = 'import_only'
export const CAPCUT_MATE_SOURCE = 'capcut-mate'
export const CAPCUT_CATALOG_SCHEMA_VERSION = 2
export const CAPCUT_CATALOG_MAX_SHARD_ENTRIES = 10_000

const capcutFamilies = Object.freeze(['flower', 'sticker', 'video_effect'])
const jsonFamilyByFilePattern = Object.freeze([
  { family: 'flower', pattern: /(?:huazi|flower|text[_-]?(?:effect|template|style))/iu },
  { family: 'sticker', pattern: /sticker/iu },
  { family: 'video_effect', pattern: /(?:^|[_-])effects?|video[_-]?effects?|filter/iu },
])
const pythonEffectEntityBySymbol = Object.freeze([
  { entity: 'scene', pattern: /scene[_-]?effects?|SceneEffect/iu },
  { entity: 'character', pattern: /character[_-]?effects?|face[_-]?effects?|CharacterEffect|FaceEffect/iu },
])
const rawIdKeys = new Set(['id', 'resourceid', 'resource_id', 'effectid', 'effect_id', 'materialid', 'material_id', 'stickerid', 'sticker_id'])
const canonicalRawIdKey = Object.freeze({
  id: 'id',
  resourceid: 'resource_id',
  resource_id: 'resource_id',
  effectid: 'effect_id',
  effect_id: 'effect_id',
  materialid: 'material_id',
  material_id: 'material_id',
  stickerid: 'sticker_id',
  sticker_id: 'sticker_id',
})
const labelKeys = ['name', 'title', 'label', 'displayName', 'display_name']
const vipPattern = /(?:^|_)(?:vip|premium|paid|member)(?:$|_)/iu
const urlPattern = /(?:url|uri|download|cdn|web_url|file_url)/iu
const identityPattern = /(?:identity|account|device|iid|did|user|cookie|passport|session)/iu
const checksumPattern = /(?:checksum|sha256|sha1|md5|hash|digest)/iu
const unsafeLabelPattern = /(?:[A-Za-z]:[\\/]|\\\\|(?:https?|file):\/\/|\b[a-f0-9]{32,64}\b|(?:resource|effect|material|sticker)[_-]?id\s*[:=])/iu
const hex64Pattern = /^[a-f0-9]{64}$/u
const commitPattern = /^[a-f0-9]{40}$/u
const maximumJsonFallbackBytes = 1024 * 1024

/**
 * @typedef {Record<string, any>} NormalizedCapCutEntry
 * @typedef {{shardId: string, entries: number, fingerprint: string}} CapCutShardManifest
 * @typedef {{schemaVersion: number, shardId: string, entries: Record<string, any>[]}} CapCutShardDocument
 */

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string | Buffer} value @returns {string} */
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
/** @param {string} filePath @returns {Promise<string>} */
const sha256File = async (filePath) => {
  const hasher = createHash('sha256')
  for await (const chunk of createReadStream(filePath)) hasher.update(chunk)
  return hasher.digest('hex')
}
/** Git pins text blobs with LF bytes; Windows checkouts may materialize CRLF. */
/** @param {string} filePath @returns {Promise<string>} */
const sha256NormalizedTextFile = async (filePath) => {
  const hasher = createHash('sha256')
  let trailingCr = false
  for await (const chunk of createReadStream(filePath)) {
    /** @type {Buffer} */
    let bytes = trailingCr ? Buffer.concat([Buffer.from([13]), Buffer.from(chunk)]) : Buffer.from(chunk)
    trailingCr = bytes.length > 0 && bytes[bytes.length - 1] === 13
    if (trailingCr) bytes = bytes.subarray(0, bytes.length - 1)
    let offset = 0
    for (let index = 0; index + 1 < bytes.length; index += 1) {
      if (bytes[index] !== 13 || bytes[index + 1] !== 10) continue
      if (index > offset) hasher.update(bytes.subarray(offset, index))
      hasher.update('\n')
      offset = index + 2
      index += 1
    }
    if (offset < bytes.length) hasher.update(bytes.subarray(offset))
  }
  if (trailingCr) hasher.update(Buffer.from([13]))
  return hasher.digest('hex')
}
/** @param {string} sourcePath @param {string} snapshotPath @returns {Promise<void>} */
const snapshotFile = async (sourcePath, snapshotPath) => {
  await pipeline(createReadStream(sourcePath), createWriteStream(snapshotPath, { flags: 'wx' }))
}
/** @param {unknown} value @returns {unknown} */
const sortJson = (value) => {
  if (Array.isArray(value)) return value.map(sortJson)
  if (!isRecord(value)) return value
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, sortJson(value[key])]))
}
/** @param {unknown} value @returns {string} */
const stableJson = (value) => JSON.stringify(sortJson(value))
/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  const error = new Error(code)
  Object.assign(error, { code, status })
  throw error
}
/** @param {unknown} value @param {string} field @returns {string} */
const assertSha256 = (value, field) => {
  if (typeof value !== 'string' || !hex64Pattern.test(value)) fail(`CAPCUT_CATALOG_${field}_INVALID`)
  return value
}
/** @param {unknown} value @param {string} field @returns {string} */
const assertCommit = (value, field) => {
  if (typeof value !== 'string' || !commitPattern.test(value)) fail(`CAPCUT_MATE_${field}_INVALID`)
  return value
}
/** @param {string} key */
const normalizeKey = (key) => key.replace(/([a-z0-9])([A-Z])/gu, '$1_$2').replaceAll('-', '_').toLowerCase()
/** @param {unknown} value @returns {string | null} */
const publicLabelFrom = (value) => {
  if (!isRecord(value)) return null
  for (const key of labelKeys) {
    const label = value[key]
    if (typeof label === 'string' && label.trim() && !/[\u0000-\u001f]/u.test(label) &&
        label.length <= 160 && !unsafeLabelPattern.test(label)) return label.trim()
  }
  return null
}
/** @param {Record<string, any>} value @returns {string} */
const rawIdentityFrom = (value) => {
  for (const [key, child] of Object.entries(value)) {
    const normalized = normalizeKey(key)
    if (rawIdKeys.has(normalized) && (typeof child === 'string' || typeof child === 'number')) return String(child)
  }
  return sha256(stableJson(value))
}
/** @param {Record<string, any>} value @returns {Readonly<Record<string, string>>} */
const rawIdentityComponentsFrom = (value) => {
  /** @type {Record<string, string>} */
  const components = {}
  for (const [key, child] of Object.entries(value)) {
    const normalized = normalizeKey(key)
    const canonical = canonicalRawIdKey[/** @type {keyof typeof canonicalRawIdKey} */ (normalized)]
    if (!canonical || (typeof child !== 'string' && typeof child !== 'number')) continue
    const component = String(child)
    if (!component || component.length > 512) continue
    if (components[canonical] !== undefined && components[canonical] !== component) {
      fail('CAPCUT_MATE_SOURCE_IDENTITY_AMBIGUOUS')
    }
    components[canonical] = component
  }
  return Object.freeze(sortJson(components))
}
/** @param {unknown} value @param {(key: string, child: unknown) => boolean} predicate @returns {boolean} */
const hasDeepKey = (value, predicate) => {
  if (Array.isArray(value)) return value.some((entry) => hasDeepKey(entry, predicate))
  if (!isRecord(value)) return false
  return Object.entries(value).some(([key, child]) => predicate(normalizeKey(key), child) || hasDeepKey(child, predicate))
}
/** @param {unknown} parsed @returns {Record<string, any>[]} */
const candidateRecords = (parsed) => {
  if (Array.isArray(parsed)) return parsed.filter(isRecord)
  if (!isRecord(parsed)) return []
  const arrays = Object.values(parsed).filter(Array.isArray)
  if (arrays.length === 1) return arrays[0].filter(isRecord)
  return arrays.flatMap((value) => value.filter(isRecord))
}
/** @param {string} relativePath @returns {string | null} */
const inferJsonFamily = (relativePath) => jsonFamilyByFilePattern.find((entry) => entry.pattern.test(relativePath))?.family ?? null
/** @param {string} relativePath @param {string} symbol @returns {string | null} */
const inferPythonEntity = (relativePath, symbol) => pythonEffectEntityBySymbol.find((entry) => entry.pattern.test(`${relativePath}\n${symbol}`))?.entity ?? null

/** @param {string} left @param {string} right @returns {boolean} */
const sameFilesystemPath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLocaleLowerCase() === path.resolve(right).toLocaleLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {unknown} metadata */
const objectIdentity = (metadata) => {
  if (!metadata || typeof metadata !== 'object' ||
      (typeof /** @type {any} */ (metadata).dev !== 'number' && typeof /** @type {any} */ (metadata).dev !== 'bigint') ||
      (typeof /** @type {any} */ (metadata).ino !== 'number' && typeof /** @type {any} */ (metadata).ino !== 'bigint')) return null
  return `${/** @type {any} */ (metadata).dev}:${/** @type {any} */ (metadata).ino}`
}

/**
 * Windows realpath may return an 8.3 alias. A different spelling is safe only
 * when both names still identify the same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats|Record<string, any>} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (sameFilesystemPath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  const expectedIdentity = objectIdentity(requestedMetadata)
  return expectedIdentity !== null && expectedIdentity === objectIdentity(actualMetadata)
}

/** @param {string} root @param {string} child @returns {boolean} */
const within = (root, child) => {
  const relative = path.relative(path.resolve(root), path.resolve(child))
  return relative === '' || (!!relative && !relative.startsWith('..') && !path.isAbsolute(relative))
}

/** @param {string} sourceRoot @param {string} relativePath */
const resolvePinnedSourceFile = async (sourceRoot, relativePath, { allowedExtensions = ['.json', '.py'] } = {}) => {
  const normalized = relativePath.replaceAll('\\', '/')
  if (!normalized || path.posix.normalize(normalized) !== normalized ||
      normalized.split('/').some((segment) => segment === '' || segment === '.' || segment === '..' || segment.includes(':')) ||
      path.posix.isAbsolute(normalized) || path.isAbsolute(normalized) || !allowedExtensions.includes(path.posix.extname(normalized).toLowerCase())) {
    fail('CAPCUT_MATE_SOURCE_CHECKSUM_PATH_INVALID')
  }
  const root = path.resolve(sourceRoot)
  const rootStats = await lstat(root, { bigint: true }).catch(() => null)
  if (!rootStats?.isDirectory() || rootStats.isSymbolicLink()) fail('CAPCUT_MATE_SOURCE_REPARSE_REJECTED')
  const canonicalRoot = await realpath(root).catch(() => null)
  if (typeof canonicalRoot !== 'string' || !await sameResolvedObject(root, canonicalRoot, rootStats)) {
    fail('CAPCUT_MATE_SOURCE_REPARSE_REJECTED')
  }
  let current = root
  let currentStats = rootStats
  for (const segment of normalized.split('/')) {
    current = path.join(current, segment)
    if (!within(root, current)) fail('CAPCUT_MATE_SOURCE_CHECKSUM_PATH_INVALID')
    const segmentStats = await lstat(current, { bigint: true }).catch(() => null)
    if (!segmentStats || segmentStats.isSymbolicLink()) fail('CAPCUT_MATE_SOURCE_REPARSE_REJECTED')
    currentStats = segmentStats
  }
  const canonicalFile = await realpath(current).catch(() => null)
  if (typeof canonicalFile !== 'string' || !within(canonicalRoot, canonicalFile) ||
      !await sameResolvedObject(current, canonicalFile, currentStats)) {
    fail('CAPCUT_MATE_SOURCE_REPARSE_REJECTED')
  }
  const stats = await stat(current).catch(() => null)
  if (!stats?.isFile()) fail('CAPCUT_MATE_SOURCE_CHECKSUM_PATH_INVALID')
  return { normalized, absolutePath: current }
}

/** @param {{sourceRoot: string}} input */
const verifyRightsFiles = async ({ sourceRoot }) => {
  const licensePath = await resolvePinnedSourceFile(sourceRoot, 'LICENSE', { allowedExtensions: [''] }).catch(() => null)
  const license = licensePath ? await readFile(licensePath.absolutePath, 'utf8').catch(() => null) : null
  if (typeof license !== 'string' || !/Apache License/iu.test(license) || !/Version\s+2(?:\.0)?/iu.test(license)) fail('CAPCUT_MATE_LICENSE_UNVERIFIED')
  const noticePath = await resolvePinnedSourceFile(sourceRoot, 'NOTICE', { allowedExtensions: [''] }).catch(() => null)
  const notice = noticePath ? await readFile(noticePath.absolutePath, 'utf8').catch(() => null) : null
  if (typeof notice !== 'string' || notice.trim().length === 0) fail('CAPCUT_MATE_NOTICE_UNVERIFIED')
  return Object.freeze({
    license: 'Apache-2.0-root-code-only',
    noticePresent: true,
    rightsMode: CAPCUT_MATE_RIGHTS_MODE,
    redistribution: 'raw_snapshot_not_redistributed',
  })
}

/** @param {{sourceRoot: string, expectedSourceChecksums?: Record<string, string>}} input */
const verifySourceChecksums = async ({ sourceRoot, expectedSourceChecksums = {} }) => {
  if (!isRecord(expectedSourceChecksums) || Object.keys(expectedSourceChecksums).length === 0) {
    fail('CAPCUT_MATE_SOURCE_CHECKSUMS_REQUIRED')
  }
  const verified = []
  for (const [relativePath, expected] of Object.entries(expectedSourceChecksums)) {
    assertSha256(expected, 'SOURCE_CHECKSUM')
    const { normalized, absolutePath } = await resolvePinnedSourceFile(sourceRoot, relativePath)
    const actual = await sha256NormalizedTextFile(absolutePath)
    if (actual !== expected) fail('CAPCUT_MATE_SOURCE_CHECKSUM_MISMATCH')
    verified.push({ path: normalized, sha256: actual })
  }
  return verified.sort((a, b) => a.path.localeCompare(b.path))
}

/** @param {Record<string, any>} record @param {{family: string, sourceFile: string, sourceIndex: number, entity?: string | null, sourceFingerprint: string}} input */
const normalizeRecord = (record, { family, sourceFile, sourceIndex, entity = null, sourceFingerprint }) => {
  const rawIdentity = rawIdentityFrom(record)
  const rawIdentityComponents = rawIdentityComponentsFrom(record)
  const schemaKeys = Object.keys(record).map(normalizeKey).sort()
  return Object.freeze({
    family,
    entity,
    sourceFile,
    sourceIndex,
    rawIdentity,
    rawIdentityComponents,
    label: publicLabelFrom(record),
    schemaKeys,
    vipTagged: hasDeepKey(record, (key, child) => vipPattern.test(key) && child !== false && child !== null && child !== undefined),
    urlTagged: hasDeepKey(record, (key, child) => urlPattern.test(key) && typeof child === 'string' && child.length > 0),
    identityTagged: hasDeepKey(record, (key, child) => identityPattern.test(key) && child !== null && child !== undefined),
    checksumTagged: hasDeepKey(record, (key, child) => checksumPattern.test(key) && child !== null && child !== undefined),
    sourceFingerprint,
  })
}

/** @param {readonly Record<string, any>[]} entries */
const familySummaries = (entries) => capcutFamilies.map((family) => {
  const familyEntries = entries.filter((entry) => entry.family === family)
  const identities = new Set()
  const schemaKeys = new Set()
  let duplicates = 0
  for (const entry of familyEntries) {
    const identityKey = `${entry.family}\u0000${entry.entity ?? ''}\u0000${entry.rawIdentity}`
    if (identities.has(identityKey)) duplicates += 1
    identities.add(identityKey)
    for (const key of entry.schemaKeys) schemaKeys.add(key)
  }
  return Object.freeze({
    family,
    total: familyEntries.length,
    duplicates,
    vipTagged: familyEntries.filter((entry) => entry.vipTagged).length,
    urlTagged: familyEntries.filter((entry) => entry.urlTagged).length,
    identityTagged: familyEntries.filter((entry) => entry.identityTagged).length,
    checksumTagged: familyEntries.filter((entry) => entry.checksumTagged).length,
    entities: [...new Set(familyEntries.map((entry) => entry.entity).filter(Boolean))].sort(),
    schemaKeys: [...schemaKeys].sort(),
  })
}).filter((entry) => entry.total > 0)

const createFamilyAccumulator = () => new Map(capcutFamilies.map((family) => [family, {
  family,
  total: 0,
  duplicates: 0,
  vipTagged: 0,
  urlTagged: 0,
  identityTagged: 0,
  checksumTagged: 0,
  identities: new Set(),
  entities: new Set(),
  schemaKeys: new Set(),
}]))

/** @param {Map<string, Record<string, any>>} accumulator @param {Record<string, any>} entry */
const accumulateFamily = (accumulator, entry) => {
  const family = accumulator.get(entry.family)
  if (!family) return
  family.total += 1
  const identityKey = `${entry.family}\u0000${entry.entity ?? ''}\u0000${entry.rawIdentity}`
  if (family.identities.has(identityKey)) family.duplicates += 1
  family.identities.add(identityKey)
  if (entry.vipTagged) family.vipTagged += 1
  if (entry.urlTagged) family.urlTagged += 1
  if (entry.identityTagged) family.identityTagged += 1
  if (entry.checksumTagged) family.checksumTagged += 1
  if (entry.entity) family.entities.add(entry.entity)
  for (const key of entry.schemaKeys) family.schemaKeys.add(key)
}

/** @param {Map<string, Record<string, any>>} accumulator */
const familySummariesFromAccumulator = (accumulator) => [...accumulator.values()]
  .filter((family) => family.total > 0)
  .map((family) => Object.freeze({
    family: family.family,
    total: family.total,
    duplicates: family.duplicates,
    vipTagged: family.vipTagged,
    urlTagged: family.urlTagged,
    identityTagged: family.identityTagged,
    checksumTagged: family.checksumTagged,
    entities: [...family.entities].sort(),
    schemaKeys: [...family.schemaKeys].sort(),
  }))

/** @param {{sourceRoot: string, sourceCommit: string, expectedCommit?: string, expectedSourceChecksums?: Record<string, string>}} input */
const prepareSource = async ({ sourceRoot, sourceCommit, expectedCommit = CAPCUT_MATE_PINNED_COMMIT, expectedSourceChecksums = {} }) => {
  assertCommit(sourceCommit, 'COMMIT')
  assertCommit(expectedCommit, 'EXPECTED_COMMIT')
  if (sourceCommit !== expectedCommit || sourceCommit !== CAPCUT_MATE_PINNED_COMMIT) fail('CAPCUT_MATE_COMMIT_MISMATCH')
  const sourceStats = await stat(sourceRoot).catch(() => null)
  if (!sourceStats?.isDirectory()) fail('CAPCUT_MATE_SOURCE_ROOT_INVALID')
  const rights = await verifyRightsFiles({ sourceRoot })
  const verifiedSourceChecksums = await verifySourceChecksums({ sourceRoot, expectedSourceChecksums })
  const files = verifiedSourceChecksums.map((entry) => entry.path)
  return { rights, verifiedSourceChecksums, files }
}

/** @param {string} text */
const parsePythonDictSubset = (text) => {
  const json = text
    .replace(/#.*$/gmu, '')
    .replace(/'/gu, '"')
    .replace(/\bTrue\b/gu, 'true')
    .replace(/\bFalse\b/gu, 'false')
    .replace(/\bNone\b/gu, 'null')
    .replace(/,\s*([}\]])/gu, '$1')
  return JSON.parse(json)
}

/**
 * Split one Python call without evaluating source code.
 * @param {string} text
 * @returns {string[]}
 */
const splitPythonCallArguments = (text) => {
  const argumentsList = []
  let start = 0
  let depth = 0
  let inString = false
  let quote = ''
  let escaped = false
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index]
    if (inString) {
      if (escaped) escaped = false
      else if (char === '\\') escaped = true
      else if (char === quote) inString = false
      continue
    }
    if (char === '"' || char === "'") { inString = true; quote = char; continue }
    if (char === '(' || char === '[' || char === '{') depth += 1
    else if (char === ')' || char === ']' || char === '}') depth -= 1
    else if (char === ',' && depth === 0) {
      argumentsList.push(text.slice(start, index).trim())
      start = index + 1
    }
    if (depth < 0) fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
  }
  if (inString || depth !== 0) fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
  argumentsList.push(text.slice(start).trim())
  return argumentsList
}

/** @param {string} value */
const parsePythonString = (value) => {
  if (typeof value !== 'string' || value.length < 2 || value[0] !== '"' || value.at(-1) !== '"') {
    fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
  }
  try {
    const parsed = JSON.parse(value)
    if (typeof parsed !== 'string') fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
    return parsed
  } catch { fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID') }
}

/** @param {string} text */
const parseEffectParameters = (text) => {
  const trimmed = text.trim()
  if (!trimmed.startsWith('[') || !trimmed.endsWith(']')) fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
  const parameters = []
  const pattern = /EffectParam\(\s*("(?:[^"\\]|\\.)*")\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)/gu
  let match
  while ((match = pattern.exec(trimmed)) !== null) {
    parameters.push({
      name: parsePythonString(match[1]),
      default: Number(match[2]),
      minimum: Number(match[3]),
      maximum: Number(match[4]),
    })
  }
  const residue = trimmed.replace(pattern, '').replace(/[\s,\[\]]/gu, '')
  if (residue.length > 0) fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
  return parameters
}

/** @param {string} text @param {string} relativePath @param {(record: Record<string, any>, entity: string, sourceIndex: number) => Promise<void>|void} onRecord */
const streamPythonEffectMetaRecords = async (text, relativePath, onRecord) => {
  const assignmentPattern = /^[ \t]+([^\s=]+)\s*=\s*EffectMeta\s*\(/gmu
  const entity = inferPythonEntity(relativePath, '')
  if (!entity) return 0
  let count = 0
  for (const match of text.matchAll(assignmentPattern)) {
    let depth = 1
    let inString = false
    let quote = ''
    let escaped = false
    let end = -1
    for (let index = match.index + match[0].length; index < text.length; index += 1) {
      const char = text[index]
      if (inString) {
        if (escaped) escaped = false
        else if (char === '\\') escaped = true
        else if (char === quote) inString = false
        continue
      }
      if (char === '"' || char === "'") { inString = true; quote = char; continue }
      if (char === '(') depth += 1
      else if (char === ')' && --depth === 0) { end = index; break }
    }
    if (end < 0) fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
    const args = splitPythonCallArguments(text.slice(match.index + match[0].length, end))
    if (args.length !== 6 || !['True', 'False'].includes(args[1])) fail('CAPCUT_MATE_SOURCE_PYTHON_INVALID')
    await onRecord({
      name: parsePythonString(args[0]),
      vip: args[1] === 'True',
      resource_id: parsePythonString(args[2]),
      effect_id: parsePythonString(args[3]),
      checksum: parsePythonString(args[4]),
      parameters: parseEffectParameters(args[5]),
    }, entity, count++)
  }
  return count
}

/** @param {string} text @param {string} relativePath @param {(record: Record<string, any>, entity: string, sourceIndex: number) => Promise<void>|void} onRecord */
const streamPythonEffectRecords = async (text, relativePath, onRecord) => {
  const effectMetaCount = await streamPythonEffectMetaRecords(text, relativePath, onRecord)
  if (effectMetaCount > 0) return
  const assignmentPattern = /([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\[/gu
  let sourceIndex = 0
  for (const match of text.matchAll(assignmentPattern)) {
    const symbol = match[1]
    const entity = inferPythonEntity(relativePath, symbol)
    if (!entity) continue
    let depth = 0
    let inString = false
    let quote = ''
    let escaped = false
    let start = -1
    for (let index = match.index + match[0].length; index < text.length; index += 1) {
      const char = text[index]
      if (inString) {
        if (escaped) escaped = false
        else if (char === '\\') escaped = true
        else if (char === quote) inString = false
        continue
      }
      if (char === '"' || char === "'") { inString = true; quote = char; continue }
      if (char === '{') { if (depth === 0) start = index; depth += 1 }
      else if (char === '}') {
        depth -= 1
        if (depth === 0 && start >= 0) {
          const record = parsePythonDictSubset(text.slice(start, index + 1))
          if (isRecord(record)) await onRecord(record, entity, sourceIndex++)
          start = -1
        }
      } else if (char === ']' && depth === 0) break
    }
  }
}

/** @param {string} filePath @param {(record: Record<string, any>, index: number) => Promise<void>|void} onRecord @param {Record<string, Function>} instrumentation */
const streamJsonArrayRecords = async (filePath, onRecord, instrumentation = {}) => {
  let recordBuffer = ''
  let depth = 0
  let inString = false
  let escaped = false
  let startedArray = false
  let endedArray = false
  let expectingValue = true
  let afterComma = false
  let sourceIndex = 0
  for await (const chunk of createReadStream(filePath, { encoding: 'utf8' })) {
    const text = String(chunk)
    let cursor = 0
    while (cursor < text.length) {
      const char = text[cursor]
      if (!startedArray) {
        if (/\s/u.test(char)) { cursor += 1; continue }
        if (char !== '[') return false
        startedArray = true
        cursor += 1
        continue
      }
      if (endedArray) {
        if (!/\s/u.test(char)) fail('CAPCUT_MATE_SOURCE_JSON_INVALID')
        cursor += 1
        continue
      }
      if (depth === 0) {
        if (/\s/u.test(char)) { cursor += 1; continue }
        if (expectingValue) {
          if (char === ']' && !afterComma) endedArray = true
          else if (char === '{') {
            depth = 1
            recordBuffer = '{'
            expectingValue = false
            afterComma = false
            instrumentation.onRawBufferedRecords?.(1)
          } else fail('CAPCUT_MATE_SOURCE_JSON_INVALID')
        } else if (char === ',') {
          expectingValue = true
          afterComma = true
        } else if (char === ']') endedArray = true
        else fail('CAPCUT_MATE_SOURCE_JSON_INVALID')
        cursor += 1
        continue
      }
      recordBuffer += char
      instrumentation.onRawRecordBytes?.(recordBuffer.length)
      if (inString) {
        if (escaped) escaped = false
        else if (char === '\\') escaped = true
        else if (char === '"') inString = false
      } else if (char === '"') inString = true
      else if (char === '{') depth += 1
      else if (char === '}') {
        depth -= 1
        if (depth === 0) {
          const parsed = JSON.parse(recordBuffer)
          if (isRecord(parsed)) await onRecord(parsed, sourceIndex++)
          recordBuffer = ''
        }
      }
      cursor += 1
    }
  }
  if (depth !== 0 || !endedArray || afterComma) fail('CAPCUT_MATE_SOURCE_JSON_INVALID')
  return startedArray
}

/** @param {string} filePath @param {(record: Record<string, any>, index: number) => Promise<void>|void} onRecord */
const parseSmallJsonRecords = async (filePath, onRecord) => {
  const stats = await stat(filePath)
  if (stats.size > maximumJsonFallbackBytes) fail('CAPCUT_MATE_SOURCE_JSON_TOO_LARGE_FOR_FALLBACK')
  const parsed = JSON.parse(await readFile(filePath, 'utf8'))
  for (const [index, record] of candidateRecords(parsed).entries()) await onRecord(record, index)
}

/** @param {{sourceRoot: string, files: readonly string[], expectedSourceChecksums?: ReadonlyMap<string, string>, instrumentation?: Record<string, Function>, onEntry: (entry: Record<string, any>) => Promise<void>|void}} input */
const streamNormalizedEntries = async ({ sourceRoot, files, expectedSourceChecksums = new Map(), instrumentation = {}, onEntry }) => {
  const snapshotRoot = await mkdtemp(path.join(os.tmpdir(), 'openvideo-capcut-source-snapshot-'))
  try {
    for (const relativePath of files) {
      const absolutePath = path.join(sourceRoot, relativePath)
      const expectedFingerprint = expectedSourceChecksums.get(relativePath)
      if (!expectedFingerprint) fail('CAPCUT_MATE_SOURCE_CHECKSUM_MISMATCH')
      const snapshotPath = path.join(snapshotRoot, relativePath)
      await mkdir(path.dirname(snapshotPath), { recursive: true })
      const sourceByteFingerprint = await sha256File(absolutePath)
      await snapshotFile(absolutePath, snapshotPath)
      const snapshotByteFingerprint = await sha256File(snapshotPath)
      if (snapshotByteFingerprint !== sourceByteFingerprint ||
          await sha256NormalizedTextFile(snapshotPath) !== expectedFingerprint) {
        fail('CAPCUT_MATE_SOURCE_CHECKSUM_MISMATCH')
      }
      const sourceFingerprint = expectedFingerprint
      await instrumentation.afterPinnedChecksumVerified?.(relativePath, absolutePath)
      if (relativePath.toLowerCase().endsWith('.json')) {
        const family = inferJsonFamily(relativePath)
        if (!family) continue
        const streamed = await streamJsonArrayRecords(snapshotPath, async (record, sourceIndex) => {
          await onEntry(normalizeRecord(record, { family, sourceFile: relativePath, sourceIndex, sourceFingerprint }))
        }, instrumentation)
        if (!streamed) {
          await parseSmallJsonRecords(snapshotPath, async (record, sourceIndex) => {
            await onEntry(normalizeRecord(record, { family, sourceFile: relativePath, sourceIndex, sourceFingerprint }))
          })
        }
      } else if (relativePath.toLowerCase().endsWith('.py')) {
        const text = await readFile(snapshotPath, 'utf8')
        await streamPythonEffectRecords(text, relativePath, async (record, entity, sourceIndex) => {
          await onEntry(normalizeRecord(record, { family: 'video_effect', entity, sourceFile: relativePath, sourceIndex, sourceFingerprint }))
        })
      }
      if (await sha256File(absolutePath) !== sourceByteFingerprint ||
          await sha256NormalizedTextFile(absolutePath) !== expectedFingerprint) {
        fail('CAPCUT_MATE_SOURCE_CHECKSUM_MISMATCH')
      }
    }
  } finally {
    await rm(snapshotRoot, { recursive: true, force: true })
  }
}

/** @param {{sourceCommit: string, sourceFingerprint: string, families: readonly Record<string, any>[], shards: readonly Record<string, any>[], verifiedSourceChecksums?: readonly Record<string, any>[], rights?: Record<string, any>}} input */
export const createCapCutCatalogManifest = ({ sourceCommit, sourceFingerprint, families, shards, verifiedSourceChecksums = [], rights = {} }) => {
  assertCommit(sourceCommit, 'COMMIT')
  assertSha256(sourceFingerprint, 'SOURCE_FINGERPRINT')
  const normalizedFamilies = [...families].map((family) => Object.freeze({
    family: family.family,
    total: Number(family.total) || 0,
    duplicates: Number(family.duplicates) || 0,
    vipTagged: Number(family.vipTagged) || 0,
    urlTagged: Number(family.urlTagged) || 0,
    identityTagged: Number(family.identityTagged) || 0,
    checksumTagged: Number(family.checksumTagged) || 0,
    ...(Array.isArray(family.entities) && family.entities.length ? { entities: [...new Set(family.entities.map(String))].sort() } : {}),
    schemaKeys: Array.isArray(family.schemaKeys) ? [...new Set(family.schemaKeys.map(String))].sort() : [],
  })).sort((a, b) => a.family.localeCompare(b.family))
  const normalizedShards = [...shards].map((shard) => Object.freeze({
    shardId: String(shard.shardId),
    entries: Number(shard.entries) || 0,
    fingerprint: assertSha256(shard.fingerprint, 'SHARD_FINGERPRINT'),
  })).sort((a, b) => a.shardId.localeCompare(b.shardId))
  if (normalizedShards.some((shard) => shard.entries > CAPCUT_CATALOG_MAX_SHARD_ENTRIES)) fail('CAPCUT_CATALOG_SHARD_LIMIT_EXCEEDED')
  const unsigned = {
    schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION,
    source: CAPCUT_MATE_SOURCE,
    sourceCommit,
    sourceFingerprint,
    rightsMode: CAPCUT_MATE_RIGHTS_MODE,
    redistribution: 'importer_plus_user_signed_backup_only',
    rights: sortJson({ rightsMode: CAPCUT_MATE_RIGHTS_MODE, ...rights }),
    families: normalizedFamilies,
    shards: normalizedShards,
    verifiedSourceChecksums: [...verifiedSourceChecksums].map((entry) => ({ path: String(entry.path), sha256: assertSha256(entry.sha256, 'SOURCE_CHECKSUM') })).sort((a, b) => a.path.localeCompare(b.path)),
  }
  return Object.freeze({ ...unsigned, manifestFingerprint: sha256(stableJson(unsigned)) })
}

/** @param {Record<string, any>} entry @param {number} ordinal */
const toShardRecord = (entry, ordinal) => ({
  schema_version: CAPCUT_CATALOG_SCHEMA_VERSION,
  source: CAPCUT_MATE_SOURCE,
  rights_mode: CAPCUT_MATE_RIGHTS_MODE,
  family: entry.family,
  ...(entry.entity ? { entity: entry.entity } : {}),
  ordinal,
  label: entry.label,
  state: 'discoverable',
  private_binding: {
    source: CAPCUT_MATE_SOURCE,
    family: entry.family,
    ...(entry.entity ? { entity: entry.entity } : {}),
    source_file: entry.sourceFile,
    source_index: entry.sourceIndex,
    raw_identity: entry.rawIdentity,
    ...(Object.keys(entry.rawIdentityComponents).length > 0
      ? { raw_identity_components: entry.rawIdentityComponents }
      : {}),
    source_fingerprint: entry.sourceFingerprint,
  },
  tags: [],
  parameters_schema: {},
})

/** @param {{sourceRoot: string, sourceCommit?: string, expectedCommit?: string, expectedSourceChecksums?: Record<string, string>, profileId?: string, appVersion?: string, shardSize?: number, workRoot?: string | null, instrumentation?: Record<string, Function>}} input */
export const importCapCutMateCatalog = async ({
  sourceRoot,
  sourceCommit = CAPCUT_MATE_PINNED_COMMIT,
  expectedCommit = CAPCUT_MATE_PINNED_COMMIT,
  expectedSourceChecksums = {},
  profileId = 'jianying-capcut-mate-import',
  appVersion = '0.0.0',
  shardSize = CAPCUT_CATALOG_MAX_SHARD_ENTRIES,
  workRoot = null,
  instrumentation = {},
}) => {
  if (!Number.isSafeInteger(shardSize) || shardSize < 1 || shardSize > CAPCUT_CATALOG_MAX_SHARD_ENTRIES) fail('CAPCUT_CATALOG_SHARD_SIZE_INVALID')
  const { rights, verifiedSourceChecksums, files } = await prepareSource({ sourceRoot, sourceCommit, expectedCommit, expectedSourceChecksums })
  const expectedSourceChecksumMap = new Map(verifiedSourceChecksums.map((entry) => [entry.path, entry.sha256]))
  const outputRoot = workRoot ? path.resolve(workRoot) : await mkdtemp(path.join(os.tmpdir(), 'openvideo-capcut-catalog-'))
  const ownsOutputRoot = !workRoot
  const shardRoot = path.join(outputRoot, `shards-${randomUUID()}`)
  /** @type {Record<string, any>[]} */
  const buffered = []
  const familyAccumulator = createFamilyAccumulator()
  /** @type {CapCutShardManifest[]} */
  const shardManifests = []
  /** @type {Map<string, string>} */
  const shardPaths = new Map()
  const sourceFingerprintHasher = createHash('sha256')
  let ordinal = 0
  const flushShard = async () => {
    if (buffered.length === 0) return
    const shardId = `shard-${String(shardManifests.length + 1).padStart(5, '0')}`
    const entries = buffered.splice(0, buffered.length)
    instrumentation.onBufferedNormalizedRecords?.(buffered.length)
    const fingerprint = sha256(stableJson(entries))
    const filePath = path.join(shardRoot, `${shardId}.json`)
    await writeFile(filePath, `${stableJson({ schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION, shardId, entries })}\n`, 'utf8')
    shardPaths.set(shardId, filePath)
    shardManifests.push(Object.freeze({ shardId, entries: entries.length, fingerprint }))
  }
  await mkdir(shardRoot, { recursive: true })
  await streamNormalizedEntries({
    sourceRoot,
    files,
    expectedSourceChecksums: expectedSourceChecksumMap,
    instrumentation,
    onEntry: async (entry) => {
      accumulateFamily(familyAccumulator, entry)
      sourceFingerprintHasher.update(stableJson({
        family: entry.family,
        entity: entry.entity,
        rawIdentityFingerprint: sha256(`${entry.family}\u0000${entry.entity ?? ''}\u0000${entry.rawIdentity}`),
        identityComponentsFingerprint: sha256(stableJson(entry.rawIdentityComponents)),
        sourceFile: entry.sourceFile,
        sourceIndex: entry.sourceIndex,
        sourceFingerprint: entry.sourceFingerprint,
      }))
      buffered.push(toShardRecord(entry, ordinal++))
      instrumentation.onBufferedNormalizedRecords?.(buffered.length)
      if (buffered.length >= shardSize) await flushShard()
    },
  })
  await flushShard()
  const families = familySummariesFromAccumulator(familyAccumulator)
  const manifest = createCapCutCatalogManifest({ sourceCommit, sourceFingerprint: sourceFingerprintHasher.digest('hex'), families, shards: shardManifests, verifiedSourceChecksums, rights })
  const publicSummary = Object.freeze({
    schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION,
    source: CAPCUT_MATE_SOURCE,
    rightsMode: CAPCUT_MATE_RIGHTS_MODE,
    sourceCommit,
    families,
    totals: Object.freeze({
      entries: families.reduce((sum, family) => sum + family.total, 0),
      duplicates: families.reduce((sum, family) => sum + family.duplicates, 0),
      vipTagged: families.reduce((sum, family) => sum + family.vipTagged, 0),
      urlTagged: families.reduce((sum, family) => sum + family.urlTagged, 0),
      identityTagged: families.reduce((sum, family) => sum + family.identityTagged, 0),
      checksumTagged: families.reduce((sum, family) => sum + family.checksumTagged, 0),
    }),
    verifiedSourceChecksums,
    rights,
  })
  /** @param {string} shardId @returns {Promise<CapCutShardDocument | null>} */
  const loadShard = async (shardId) => {
    const filePath = shardPaths.get(shardId)
    if (!filePath) return null
    const document = JSON.parse(await readFile(filePath, 'utf8'))
    const shard = manifest.shards.find((entry) => entry.shardId === shardId)
    if (!shard || sha256(stableJson(document.entries ?? [])) !== shard.fingerprint) fail('CAPCUT_CATALOG_SHARD_FINGERPRINT_MISMATCH')
    return /** @type {CapCutShardDocument} */ (Object.freeze(document))
  }
  return Object.freeze({
    manifest,
    publicSummary,
    privateIndex: Object.freeze({
      schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION,
      profileId,
      appVersion,
      source: CAPCUT_MATE_SOURCE,
      rightsMode: CAPCUT_MATE_RIGHTS_MODE,
      catalogFingerprint: manifest.manifestFingerprint,
      catalogRevisionToken: `ovcapcut_v1_${manifest.manifestFingerprint.slice(0, 24)}`,
      shards: manifest.shards,
    }),
    async *shards() {
      for (const shard of manifest.shards) yield await loadShard(shard.shardId)
    },
    loadShard,
    /** @param {(entry: Record<string, any>) => boolean | Promise<boolean>} predicate @param {{limit?: number}} [options] */
    async search(predicate, { limit = 20 } = {}) {
      /** @type {Record<string, any>[]} */
      const results = []
      for (const shard of manifest.shards) {
        const document = await loadShard(shard.shardId)
        if (!document) continue
        for (const entry of document.entries) {
          if (await predicate(entry)) results.push(entry)
          if (results.length >= limit) return results
        }
      }
      return results
    },
    async dispose() {
      await rm(ownsOutputRoot ? outputRoot : shardRoot, { recursive: true, force: true })
    },
  })
}

/** @param {{sourceRoot: string, sourceCommit?: string, expectedCommit?: string, expectedSourceChecksums?: Record<string, string>}} input */
export const summarizeCapCutMateSource = async ({ sourceRoot, sourceCommit = CAPCUT_MATE_PINNED_COMMIT, expectedCommit = CAPCUT_MATE_PINNED_COMMIT, expectedSourceChecksums = {} }) => {
  const { rights, verifiedSourceChecksums, files } = await prepareSource({ sourceRoot, sourceCommit, expectedCommit, expectedSourceChecksums })
  const expectedSourceChecksumMap = new Map(verifiedSourceChecksums.map((entry) => [entry.path, entry.sha256]))
  const familyAccumulator = createFamilyAccumulator()
  await streamNormalizedEntries({ sourceRoot, files, expectedSourceChecksums: expectedSourceChecksumMap, onEntry: (entry) => accumulateFamily(familyAccumulator, entry) })
  const families = familySummariesFromAccumulator(familyAccumulator)
  return Object.freeze({
    schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION,
    source: CAPCUT_MATE_SOURCE,
    rightsMode: CAPCUT_MATE_RIGHTS_MODE,
    sourceCommit,
    families,
    totals: Object.freeze({
      entries: families.reduce((sum, family) => sum + family.total, 0),
      duplicates: families.reduce((sum, family) => sum + family.duplicates, 0),
      vipTagged: families.reduce((sum, family) => sum + family.vipTagged, 0),
      urlTagged: families.reduce((sum, family) => sum + family.urlTagged, 0),
      identityTagged: families.reduce((sum, family) => sum + family.identityTagged, 0),
      checksumTagged: families.reduce((sum, family) => sum + family.checksumTagged, 0),
    }),
    verifiedSourceChecksums,
    rights,
  })
}
