import { access, realpath, stat } from 'node:fs/promises'
import { constants as fsConstants, realpathSync, statSync } from 'node:fs'
import path from 'node:path'

import {
  JianyingDraftAdapterError,
  createJianyingDraftAdapterRequest,
  createJianyingDraftJobService,
  createJianyingDraftRequestRegistry,
} from './jianying-draft-adapter.mjs'
import { createPyJianyingDraftWriter } from './jianying-draft-writer.mjs'

const maxIdentifierLength = 180
const maxRegistrations = 100

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {Record<string, any>} value @param {string[]} keys */
const hasExactKeys = (value, keys) =>
  Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key))

/** @param {string} value */
const hasIdentifierDelimiter = (value) =>
  Array.from(value).some((character) => {
    const codePoint = character.codePointAt(0) ?? 0
    return codePoint <= 31 || codePoint === 47 || codePoint === 58 || codePoint === 92
  })

/** @param {unknown} value */
const isSafeIdentifier = (value) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= maxIdentifierLength &&
  value === value.trim() &&
  !hasIdentifierDelimiter(value)

/** @param {unknown} value */
const isPrivateAuthorization = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['authorization_id', 'path']) &&
  isSafeIdentifier(value.authorization_id) &&
  typeof value.path === 'string' &&
  path.isAbsolute(value.path)

/** @param {unknown} value */
const isBgmLease = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['extension', 'sha256', 'size', 'createStream', 'release']) &&
  typeof value.extension === 'string' && /^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(value.extension) &&
  typeof value.sha256 === 'string' && /^[a-f0-9]{64}$/u.test(value.sha256) &&
  Number.isSafeInteger(value.size) && value.size > 0 &&
  typeof value.createStream === 'function' &&
  typeof value.release === 'function'

/** @param {unknown} value */
const isPrivateRegistration = (value) =>
  isRecord(value) &&
  (
    hasExactKeys(value, ['request', 'material_authorizations', 'voiceover_authorizations']) ||
    hasExactKeys(value, ['request', 'material_authorizations', 'voiceover_authorizations', 'bgm_lease'])
  ) &&
  Array.isArray(value.material_authorizations) &&
  value.material_authorizations.every(isPrivateAuthorization) &&
  Array.isArray(value.voiceover_authorizations) &&
  value.voiceover_authorizations.every(isPrivateAuthorization) &&
  (value.bgm_lease === undefined || value.bgm_lease === null || isBgmLease(value.bgm_lease))

/** @param {Record<string, any>[]} entries */
const createAuthorizationMap = (entries) => {
  const authorizationMap = new Map()
  for (const entry of entries) {
    if (authorizationMap.has(entry.authorization_id)) {
      throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
    }
    try {
      const canonicalPath = realpathSync(entry.path)
      const metadata = statSync(canonicalPath)
      if (!metadata.isFile()) throw new Error('not-file')
      authorizationMap.set(
        entry.authorization_id,
        Object.freeze({
          path: entry.path,
          canonical_path: canonicalPath,
          size: metadata.size,
          mtime_ms: metadata.mtimeMs,
          dev: metadata.dev,
          ino: metadata.ino,
        }),
      )
    } catch {
      throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
    }
  }
  return authorizationMap
}

/**
 * @param {{draftRoot?: string, pythonExecutable?: string, pythonModuleRoot?: string, bridgePath?: string, timeoutMs?: number, captions?: boolean, bgmPath?: string | null, getRenderOptions?: Function | null, resolvePrivatePackagingToken?: Function | null, resolveTemplateBlueprint?: Function | null, writer?: {writeDraft: (input: Record<string, any>) => Promise<unknown>, verifyDraft: (input: Record<string, any>) => Promise<boolean>, cleanupDraft: (input: Record<string, any>) => Promise<void>, releaseDraft?: (input: Record<string, any>) => Promise<boolean>, cleanupOwnedDraft?: (input: {requestId: string, draftId: string}) => Promise<boolean>, releaseOwnedDraft?: (input: {requestId: string, draftId: string}) => Promise<boolean>}}} options
 */
export const createJianyingDraftRuntime = (options) => {
  const requestRegistry = createJianyingDraftRequestRegistry()
  /** @type {Map<string, {materials: Map<string, {path: string, canonical_path: string, size: number, mtime_ms: number, dev: number, ino: number}>, voiceovers: Map<string, {path: string, canonical_path: string, size: number, mtime_ms: number, dev: number, ino: number}>}>} */
  const authorizations = new Map()
  /** @type {Map<string, {extension: string, sha256: string, size: number, createStream: Function, release: Function}>} */
  const bgmLeases = new Map()
  const writer = options.writer ?? createPyJianyingDraftWriter(/** @type {any} */ ({
    ...options,
    getBgmLease: (/** @type {string} */ requestId) => bgmLeases.get(String(requestId)) ?? null,
  }))

  /** @param {Record<string, any>} binding @param {'materials' | 'voiceovers'} kind */
  const resolveAuthorization = async (binding, kind) => {
    const requestId = binding.request_id
    const requestAuthorizations = authorizations.get(String(requestId))
    const resolved = requestAuthorizations?.[kind].get(String(binding.authorization_id))
    if (!resolved) {
      throw new JianyingDraftAdapterError(
        kind === 'voiceovers' ? 'JY002_VOICEOVER_AUDIO_MISSING' : 'JY002_MATERIAL_AUTHORIZATION_EXPIRED',
      )
    }
    let stage = 'authorization_unavailable'
    try {
      const canonicalPath = await realpath(resolved.path)
      stage = 'authorization_path_changed'
      // Windows may return short and long aliases for the same file. The
      // metadata identity below remains authoritative for that platform.
      if (process.platform !== 'win32' && path.resolve(canonicalPath) !== path.resolve(resolved.canonical_path)) {
        throw new Error('path-changed')
      }
      const metadata = await stat(canonicalPath)
      stage = 'authorization_not_file'
      if (!metadata.isFile()) throw new Error('not-file')
      stage = 'authorization_identity_changed'
      if (
        metadata.size !== resolved.size ||
        metadata.mtimeMs !== resolved.mtime_ms ||
        metadata.dev !== resolved.dev ||
        metadata.ino !== resolved.ino
      ) {
        throw new Error('file-changed')
      }
      stage = 'authorization_unreadable'
      await access(canonicalPath, fsConstants.R_OK)
    } catch {
      const error = new JianyingDraftAdapterError(
        kind === 'voiceovers' ? 'JY002_VOICEOVER_AUDIO_MISSING' : 'JY002_MATERIAL_AUTHORIZATION_EXPIRED',
      )
      Object.defineProperty(error, 'stage', { value: stage, enumerable: true })
      throw error
    }
    return { path: resolved.canonical_path }
  }

  const service = createJianyingDraftJobService({
    resolveMaterial: (binding) => resolveAuthorization(binding, 'materials'),
    resolveVoiceover: (binding) => resolveAuthorization(binding, 'voiceovers'),
    writeDraft: writer.writeDraft,
    verifyDraft: writer.verifyDraft,
    cleanupDraft: writer.cleanupDraft,
    releaseDraft: writer.releaseDraft,
    cleanupOwnedDraft: writer.cleanupOwnedDraft,
    releaseOwnedDraft: writer.releaseOwnedDraft,
  })

  return {
    registry: requestRegistry,
    service,
    /** @param {unknown} registration */
    register(registration) {
      if (!isPrivateRegistration(registration)) {
        throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
      }
      const source = /** @type {Record<string, any>} */ (registration)
      const request = createJianyingDraftAdapterRequest(source.request)
      const requestId = String(request.request_id)
      if (authorizations.has(requestId)) {
        throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
      }
      if (authorizations.size >= maxRegistrations) {
        throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
      }
      const materialBindings = /** @type {Record<string, any>[]} */ (request.material_bindings)
      const voiceoverBindings = /** @type {Record<string, any>[]} */ (request.voiceover_bindings)
      const materials = createAuthorizationMap(source.material_authorizations)
      const voiceovers = createAuthorizationMap(source.voiceover_authorizations)
      if (
        materials.size !== materialBindings.length ||
        voiceovers.size !== voiceoverBindings.length ||
        materialBindings.some((binding) => !materials.has(String(binding.authorization_id))) ||
        voiceoverBindings.some((binding) => !voiceovers.has(String(binding.authorization_id)))
      ) {
        throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
      }
      authorizations.set(requestId, { materials, voiceovers })
      if (source.bgm_lease) bgmLeases.set(requestId, source.bgm_lease)
      requestRegistry.register(request)
      return requestId
    },
    /** @param {string} requestId */
    remove(requestId) {
      authorizations.delete(requestId)
      bgmLeases.delete(requestId)
      return requestRegistry.remove(requestId)
    },
  }
}
