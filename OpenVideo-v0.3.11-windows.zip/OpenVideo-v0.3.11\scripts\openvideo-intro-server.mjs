import { createServer } from 'node:http'
import { readFile, rename, writeFile, rm } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const assets = new Map([
  ['/openvideo-intro/launch.html', ['openvideo-intro/launch.html', 'text/html; charset=utf-8']],
  ['/openvideo-intro/style.css', ['openvideo-intro/style.css', 'text/css; charset=utf-8']],
  ['/openvideo-intro/launch.css', ['openvideo-intro/launch.css', 'text/css; charset=utf-8']],
  ['/openvideo-intro/app.bundle.js', ['openvideo-intro/app.bundle.js', 'text/javascript; charset=utf-8']],
  ['/openvideo-intro/launch-bridge.js', ['openvideo-intro/launch-bridge.js', 'text/javascript; charset=utf-8']],
  ['/openvideo-logo.svg', ['openvideo-logo.svg', 'image/svg+xml']],
])

const phases = new Set([
  'gateway-starting', 'repositories', 'local-api-token', 'static-web', 'startup-listen',
  'creative-knowledge', 'material-analysis', 'material-review-overlay', 'tts-studio',
  'narration-provider', 'preview-provider', 'template-capabilities', 'jianying-capability',
  'workbench-runtime', 'startup-recovery', 'factories', 'native-evidence-preflight',
  'runtime-root-acl-finalize', 'workbench-ready', 'startup-failed',
])

export async function startIntroServer({ publicRoot, statePath, launchId, target, parentPid, lifetimeMs = 360_000 }) {
  const parsedTarget = new URL(target)
  if (parsedTarget.protocol !== 'http:' || parsedTarget.hostname !== '127.0.0.1' ||
      parsedTarget.pathname !== '/' || parsedTarget.search || parsedTarget.hash ||
      parsedTarget.username || parsedTarget.password || !/^[a-f0-9]{32}$/u.test(launchId)) {
    throw new Error('invalid_intro_configuration')
  }
  let origin
  let deadline
  const close = () => {
    clearTimeout(deadline)
    server.close()
    server.closeAllConnections()
  }
  const server = createServer(async (request, response) => {
    response.setHeader('Cache-Control', 'no-store')
    response.setHeader('X-Content-Type-Options', 'nosniff')
    response.setHeader('Referrer-Policy', 'no-referrer')
    response.setHeader('Cross-Origin-Resource-Policy', 'same-origin')
    response.setHeader('X-Frame-Options', 'DENY')
    const reply = (status, value, type = 'application/json') => {
      response.writeHead(status, { 'Content-Type': type })
      response.end(type === 'application/json' ? JSON.stringify(value) : value)
    }
    if (request.headers.host !== new URL(origin).host ||
        (request.headers.origin && request.headers.origin !== origin) ||
        request.headers['sec-fetch-site'] === 'cross-site') {
      reply(403, { error: 'intro_request_denied' })
      return
    }
    let url
    try { url = new URL(request.url, origin) } catch {
      reply(400, { error: 'invalid_request' })
      return
    }
    if (url.pathname === '/complete' && request.method === 'POST' && request.headers.origin === origin) {
      response.end()
      setImmediate(close)
      return
    }
    if (request.method !== 'GET') { reply(405, { error: 'method_not_allowed' }); return }
    try {
      if (url.pathname === '/launch-config.json') {
        reply(200, { launchId, target: parsedTarget.href })
        return
      }
      if (url.pathname === '/api/live') {
        const fallback = { live: true, ready: false, startup: { phase: 'gateway-starting', progress: 0 } }
        let snapshot
        try {
          // Read only the launcher's fixed assignment as JSON, never execute private state.
          const raw = (await readFile(statePath, 'utf8')).trim()
          const prefix = 'window.__OPENVIDEO_LAUNCH_STATE__ = '
          if (!raw.startsWith(prefix) || !raw.endsWith(';')) throw new Error('invalid_state')
          snapshot = JSON.parse(raw.slice(prefix.length, -1))
          if (snapshot.launchId !== launchId || snapshot.target !== parsedTarget.href) throw new Error('stale_state')
        } catch { snapshot = fallback }
        if (parentPid && !snapshot.ready) {
          try { process.kill(parentPid, 0) } catch {
            snapshot = { ...fallback, startup: { phase: 'startup-failed', progress: 0 } }
          }
        }
        const phase = snapshot.startup?.phase
        const progress = snapshot.startup?.progress
        reply(200, {
          live: true,
          ready: snapshot.ready === true,
          startup: {
            phase: phases.has(phase) ? phase : 'gateway-starting',
            progress: Number.isFinite(progress) ? Math.max(0, Math.min(100, progress)) : 0,
          },
        })
        return
      }
      const asset = assets.get(url.pathname)
      if (!asset) { reply(404, { error: 'not_found' }); return }
      reply(200, await readFile(join(publicRoot, asset[0])), asset[1])
    } catch { reply(503, { error: 'intro_unavailable' }) }
  })
  await new Promise((done, reject) => {
    server.once('error', reject)
    server.listen(0, '127.0.0.1', done)
  })
  origin = `http://127.0.0.1:${server.address().port}`
  deadline = setTimeout(close, lifetimeMs)
  return { origin, close }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const endpointPath = process.env.OPENVIDEO_INTRO_ENDPOINT_PATH
  try {
    const intro = await startIntroServer({
      publicRoot: fileURLToPath(new URL('../apps/web/public/', import.meta.url)),
      statePath: process.env.OPENVIDEO_INTRO_STATE_PATH,
      launchId: process.env.OPENVIDEO_INTRO_LAUNCH_ID,
      target: process.env.OPENVIDEO_INTRO_TARGET,
      parentPid: Number(process.env.OPENVIDEO_INTRO_PARENT_PID),
    })
    const temporaryPath = `${endpointPath}.tmp`
    await writeFile(temporaryPath, JSON.stringify({ url: `${intro.origin}/openvideo-intro/launch.html?bootstrap=1` }))
    await rename(temporaryPath, endpointPath)
  } catch {
    await rm(endpointPath, { force: true }).catch(() => {})
    process.exit(1)
  }
}
