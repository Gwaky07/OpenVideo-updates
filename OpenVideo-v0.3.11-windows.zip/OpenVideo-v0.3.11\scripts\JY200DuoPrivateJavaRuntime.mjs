import { createHash } from 'node:crypto'
import { execFile as execFileCallback } from 'node:child_process'
import { lstat, readdir, readFile, realpath } from 'node:fs/promises'
import path from 'node:path'
import { promisify } from 'node:util'

const execFile = promisify(execFileCallback)
const fingerprintPattern = /^[a-f0-9]{64}$/u
const requiredFiles = Object.freeze([
  'bin/jar.exe',
  'bin/java.exe',
  'bin/javac.exe',
  'legal/java.base/ADDITIONAL_LICENSE_INFO',
  'legal/java.base/ASSEMBLY_EXCEPTION',
  'legal/java.base/LICENSE',
  'release',
])

const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}

const fail = (code) => {
  throw new Error(code)
}

const parseRelease = (bytes) => {
  const values = {}
  for (const line of bytes.toString('utf8').split(/\r?\n/u)) {
    if (!line) continue
    const match = /^([A-Z0-9_]+)="([^"]*)"$/u.exec(line)
    if (!match || Object.hasOwn(values, match[1])) fail('JY200_DUO_PRIVATE_JAVA_RELEASE_INVALID')
    values[match[1]] = match[2]
  }
  return Object.freeze(values)
}

const assertOwnedRoot = async (runtimeRoot) => {
  if (typeof runtimeRoot !== 'string' || !path.isAbsolute(runtimeRoot)) {
    fail('JY200_DUO_PRIVATE_JAVA_ROOT_INVALID')
  }
  const [metadata, actual] = await Promise.all([
    lstat(runtimeRoot, { bigint: true }),
    realpath(runtimeRoot),
  ])
  if (!metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameResolvedObject(runtimeRoot, actual, metadata)) {
    fail('JY200_DUO_PRIVATE_JAVA_ROOT_INVALID')
  }
}

const inspectDirectory = async ({ runtimeRoot, current, entries }) => {
  const children = await readdir(current, { withFileTypes: true })
  children.sort((left, right) => left.name.localeCompare(right.name))
  for (const child of children) {
    const candidate = path.join(current, child.name)
    const metadata = await lstat(candidate, { bigint: true })
    if (metadata.isSymbolicLink()) fail('JY200_DUO_PRIVATE_JAVA_REPARSE_DENIED')
    if (metadata.isDirectory()) {
      if (!await sameResolvedObject(candidate, await realpath(candidate), metadata)) {
        fail('JY200_DUO_PRIVATE_JAVA_REPARSE_DENIED')
      }
      await inspectDirectory({ runtimeRoot, current: candidate, entries })
      continue
    }
    if (!metadata.isFile() || metadata.nlink !== 1n) fail('JY200_DUO_PRIVATE_JAVA_FILE_INVALID')
    const bytes = await readFile(candidate)
    const relativePath = path.relative(runtimeRoot, candidate).split(path.sep).join('/')
    if (!relativePath || relativePath.startsWith('../') || path.isAbsolute(relativePath)) {
      fail('JY200_DUO_PRIVATE_JAVA_FILE_INVALID')
    }
    entries.push(Object.freeze({ path: relativePath, size: bytes.byteLength, sha256: sha256(bytes) }))
  }
}

export const inspectJY200DuoPrivateJavaRuntime = async ({ runtimeRoot }) => {
  await assertOwnedRoot(runtimeRoot)
  const entries = []
  await inspectDirectory({ runtimeRoot, current: runtimeRoot, entries })
  entries.sort((left, right) => left.path.localeCompare(right.path))
  if (!requiredFiles.every((file) => entries.some((entry) => entry.path === file))) {
    fail('JY200_DUO_PRIVATE_JAVA_REQUIRED_FILE_MISSING')
  }
  const release = parseRelease(await readFile(path.join(runtimeRoot, 'release')))
  return Object.freeze({
    fileCount: entries.length,
    inventoryFingerprint: sha256(Buffer.from(JSON.stringify(entries))),
    release,
    entries: Object.freeze(entries),
  })
}

export const validateJY200DuoPrivateJavaRuntime = async ({ runtimeRoot, distribution, execute = true }) => {
  if (!distribution || typeof distribution !== 'object' || Array.isArray(distribution) ||
      !Number.isSafeInteger(distribution.file_count) || distribution.file_count <= 0 ||
      !fingerprintPattern.test(distribution.inventory_fingerprint ?? '') ||
      typeof distribution.java_version !== 'string' || typeof distribution.java_runtime_version !== 'string' ||
      typeof distribution.implementor !== 'string' || distribution.os_name !== 'Windows' ||
      distribution.os_arch !== 'x86_64') {
    fail('JY200_DUO_PRIVATE_JAVA_DISTRIBUTION_INVALID')
  }
  const inspected = await inspectJY200DuoPrivateJavaRuntime({ runtimeRoot })
  if (inspected.fileCount !== distribution.file_count ||
      inspected.inventoryFingerprint !== distribution.inventory_fingerprint ||
      inspected.release.JAVA_VERSION !== distribution.java_version ||
      inspected.release.JAVA_RUNTIME_VERSION !== distribution.java_runtime_version ||
      inspected.release.IMPLEMENTOR !== distribution.implementor ||
      inspected.release.OS_NAME !== distribution.os_name ||
      inspected.release.OS_ARCH !== distribution.os_arch) {
    fail('JY200_DUO_PRIVATE_JAVA_IDENTITY_INVALID')
  }
  if (execute) {
    const environment = Object.fromEntries(['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP']
      .filter((key) => typeof process.env[key] === 'string')
      .map((key) => [key, process.env[key]]))
    const options = { env: environment, timeout: 15_000, windowsHide: true }
    const [java, javac] = await Promise.all([
      execFile(path.join(runtimeRoot, 'bin', 'java.exe'), ['-version'], options),
      execFile(path.join(runtimeRoot, 'bin', 'javac.exe'), ['-version'], options),
    ])
    const output = `${java.stdout}\n${java.stderr}\n${javac.stdout}\n${javac.stderr}`
    if (!output.includes(distribution.java_version) || !output.includes(distribution.implementor)) {
      fail('JY200_DUO_PRIVATE_JAVA_EXECUTION_INVALID')
    }
  }
  return Object.freeze({
    runtimeRoot: path.resolve(runtimeRoot),
    javaExecutable: path.join(path.resolve(runtimeRoot), 'bin', 'java.exe'),
    javacExecutable: path.join(path.resolve(runtimeRoot), 'bin', 'javac.exe'),
    jarExecutable: path.join(path.resolve(runtimeRoot), 'bin', 'jar.exe'),
    inventoryFingerprint: inspected.inventoryFingerprint,
  })
}
