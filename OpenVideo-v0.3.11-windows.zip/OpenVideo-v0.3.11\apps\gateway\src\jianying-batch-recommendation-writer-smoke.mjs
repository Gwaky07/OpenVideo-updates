import { projectRecommendationToRichTimeline } from './jianying-packaging-recommender.mjs'
import {
  planPrivatePackagingBatch,
  projectPrivatePackagingBatchForWriter,
  summarizePrivatePackagingBatch,
  validatePrivateBatchPlanForWriter,
  verifyPrivateBatchDraftContent,
  verifyPrivateBatchDraftReadback,
} from './jianying-private-batch-packaging.mjs'
import {
  isPackagingCatalogBoundToDesktop,
  resolvePrivatePackagingResourceToken,
} from './jianying-packaging-resource-index.mjs'

const genericFamilies = new Set(['sticker', 'video_effect', 'video_animation', 'mask', 'blend'])
const native000BDesktop = Object.freeze({
  profileId: 'jianying-11-3-codec-candidate',
  version: '11.3.0.14362',
})

/**
 * @typedef {{
 *   family: 'sticker' | 'video_effect' | 'video_animation' | 'mask' | 'blend',
 *   parameters?: Record<string, unknown> | null,
 *   targetRange: { startUs: number, durationUs: number },
 *   targetSegmentId?: string,
 * }} PrivateBatchPatch
 * @typedef {{
 *   entries: ReadonlyArray<Record<string, unknown>>,
 *   profileId?: string,
 *   version?: string,
 *   appVersion?: string,
 *   evidenceId?: string,
 * }} PrivateBatchIndex
 * @typedef {{
 *   effect_segments?: unknown,
 *   sticker_segments?: unknown,
 *   animation_segments?: unknown,
 *   mask_segments?: unknown,
 *   blend_segments?: unknown,
 * }} TimelinePackagingShape
 */

/** @param {{family: string, parameters?: Record<string, unknown> | null}} patch */
const tokenForPatch = (patch) => {
  if (patch.family === 'video_animation') return patch.parameters?.animationToken
  if (patch.family === 'mask') return patch.parameters?.maskToken
  if (patch.family === 'blend') return patch.parameters?.blendToken
  return patch.parameters?.packagingToken
}

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const asRecords = (value) => Array.isArray(value) ? value.filter(isRecord) : []

/**
 * Apply the exact NATIVE-000B admission gate before a batch smoke can be
 * interpreted as 11.3 evidence. The generic helpers remain reusable for older
 * provisional profiles, while this entry point refuses to inherit them.
 * @param {{index: PrivateBatchIndex, desktop: {profileId: string, version: string}}} input
 */
export const assertNative000BBatchWriterSmokeAdmission = ({ index, desktop }) => {
  if (!isRecord(index) || !isRecord(desktop) ||
      desktop.profileId !== native000BDesktop.profileId ||
      desktop.version !== native000BDesktop.version ||
      index.profileId !== native000BDesktop.profileId ||
      index.appVersion !== native000BDesktop.version ||
      typeof index.evidenceId !== 'string' ||
      !/^ovjevidence_v1_[a-z0-9_-]{8,160}$/iu.test(index.evidenceId) ||
      !isPackagingCatalogBoundToDesktop(index, desktop)) {
    throw new Error('NATIVE_000B_BATCH_ADMISSION_REQUIRED')
  }
  if (!index.entries.some((/** @type {Record<string, unknown>} */ entry) => entry?.state === 'writer_eligible' && entry?.writer_eligible === true)) {
    throw new Error('NATIVE_000B_BATCH_EVIDENCE_REQUIRED')
  }
  return index
}

/**
 * A known catalog token may use a legacy writer shape (for example, a
 * keyframed sticker), but it cannot fall back to a legacy resolver unless the
 * current catalog has admitted it to the writer plan.
 * @param {{index: PrivateBatchIndex, packagingToken: unknown, admittedTokens: ReadonlySet<string>}} input
 */
export const assertCurrentPrivateCatalogTokenAdmitted = ({ index, packagingToken, admittedTokens }) => {
  if (!index || !Array.isArray(index.entries) || !(admittedTokens instanceof Set)) {
    throw new Error('JY176_BATCH_INPUT_INVALID')
  }
  const known = index.entries.some((/** @type {Record<string, unknown>} */ entry) => entry?.packaging_token === packagingToken)
  if (known && !admittedTokens.has(packagingToken)) throw new Error('JY176_BATCH_ADMISSION_REQUIRED')
}

/**
 * Convert the final RichTimeline Jianying projection into one private generic
 * writer plan. Unknown tokens remain available to their existing dedicated
 * resolvers. A token known to this catalog but not admitted is reported as a
 * skipped batch candidate; it never falls through to a legacy resolver. This
 * lets one automatic draft continue with the admitted subset while preserving
 * an auditable reason for every omitted placement.
 * @param {{index: PrivateBatchIndex, timelinePackaging: TimelinePackagingShape}} input
 */
export const preparePrivateBatchWriterSmokeFromTimelinePackaging = ({ index, timelinePackaging }) => {
  if (!index || !Array.isArray(index.entries) || !isRecord(timelinePackaging)) {
    throw new Error('JY176_BATCH_INPUT_INVALID')
  }
  const timeline = /** @type {Record<string, unknown>} */ (timelinePackaging)
  /** @type {Map<string, Record<string, unknown>>} */
  const catalogEntries = new Map(index.entries
    .filter((/** @type {Record<string, unknown>} */ entry) => typeof entry?.packaging_token === 'string')
    .map((/** @type {Record<string, unknown>} */ entry) => [/** @type {string} */ (entry.packaging_token), entry]))
  const catalogTokens = new Set(catalogEntries.keys())
  /** @type {Array<readonly [Record<string, unknown>[], 'packaging_token' | 'animation_token' | 'mask_token' | 'blend_token', 'video_effect' | 'sticker' | 'video_animation' | 'mask' | 'blend']>} */
  const groups = [
    [asRecords(timeline.effect_segments), 'packaging_token', 'video_effect'],
    [asRecords(timeline.sticker_segments)
      .filter((/** @type {Record<string, unknown>} */ segment) => !Array.isArray(segment.keyframes) || segment.keyframes.length === 0), 'packaging_token', 'sticker'],
    [asRecords(timeline.animation_segments), 'animation_token', 'video_animation'],
    [asRecords(timeline.mask_segments), 'mask_token', 'mask'],
    [asRecords(timeline.blend_segments), 'blend_token', 'blend'],
  ]
  const requests = groups.flatMap(([segments, tokenKey, expectedFamily]) => segments.flatMap((segment) => {
    const item = /** @type {Record<string, unknown>} */ (segment)
    const token = item[tokenKey]
    if (typeof token !== 'string' || !catalogTokens.has(token)) return []
    if (catalogEntries.get(token)?.family !== expectedFamily) {
      throw new Error('JY176_BATCH_FAMILY_MISMATCH')
    }
    const startUs = item.target_start_us
    const durationUs = item.target_duration_us
    if (typeof startUs !== 'number' || typeof durationUs !== 'number' ||
        !Number.isSafeInteger(startUs) || startUs < 0 ||
        !Number.isSafeInteger(durationUs) || durationUs <= 0) {
      throw new Error('JY176_BATCH_RANGE_INVALID')
    }
    return [{
      packagingToken: token,
      targetStartUs: startUs,
      targetDurationUs: durationUs,
    }]
  }))
  const batch = planPrivatePackagingBatch(index, requests)
  return Object.freeze({
    writerPlan: batch.writerPlan,
    projected: projectPrivatePackagingBatchForWriter(batch.writerPlan),
    summary: summarizePrivatePackagingBatch(batch),
    privateCatalogTokens: Object.freeze([...catalogTokens]),
  })
}

/**
 * Prepare one server-only recommendation -> RichTimeline -> private writer
 * smoke plan. Raw bindings are deliberately returned only to the caller that
 * immediately invokes the controlled writer; this object must never cross an
 * HTTP, LLM or browser boundary.
 *
 * @param {{index: PrivateBatchIndex, recommendation: Record<string, unknown>, allowedTargetSegmentIds: Set<string>}} input
 */
export const preparePrivateBatchWriterSmoke = ({ index, recommendation, allowedTargetSegmentIds }) => {
  if (!(allowedTargetSegmentIds instanceof Set) || allowedTargetSegmentIds.size === 0) {
    throw new Error('JY176_BATCH_TARGETS_REQUIRED')
  }
  const patches = projectRecommendationToRichTimeline(recommendation, {
    index,
    allowedTargetSegmentIds,
  })
  if (patches.length === 0 || patches.some((patch) => !genericFamilies.has(/** @type {string} */ (patch.family)))) {
    throw new Error('JY176_BATCH_FAMILY_UNSUPPORTED')
  }
  const requests = patches.map((patch) => {
    const packagingToken = tokenForPatch(patch)
    if (typeof packagingToken !== 'string') throw new Error('JY176_BATCH_TOKEN_MISSING')
    return {
      packagingToken,
      targetStartUs: patch.targetRange.startUs,
      targetDurationUs: patch.targetRange.durationUs,
    }
  })
  const batch = planPrivatePackagingBatch(index, requests)
  if (batch.writerPlan.length !== patches.length) throw new Error('JY176_BATCH_ADMISSION_REQUIRED')
  return Object.freeze({
    recommendationId: recommendation.recommendationId,
    catalogRevisionToken: recommendation.catalogRevisionToken,
    patches: Object.freeze(structuredClone(patches)),
    writerPlan: batch.writerPlan,
    projected: projectPrivatePackagingBatchForWriter(batch.writerPlan),
    summary: summarizePrivatePackagingBatch(batch),
  })
}

/**
 * Prepare one exact-11.3, evidence-admitted canonical RichTimeline packaging
 * object for a single controlled writer request.
 * @param {{index: PrivateBatchIndex, desktop: {profileId: string, version: string}, timelinePackaging: TimelinePackagingShape}} input
 */
export const prepareNative000BBatchWriterSmokeFromTimelinePackaging = ({ index, desktop, timelinePackaging }) => {
  assertNative000BBatchWriterSmokeAdmission({ index, desktop })
  // The exact-version entry point is an atomic writer gate. A mixed batch is
  // never allowed to silently persist its admitted subset while dropping a
  // catalog-known placement that lacks current evidence.
  const catalogTokens = new Set(index.entries
    .filter((/** @type {Record<string, unknown>} */ entry) => typeof entry?.packaging_token === 'string')
    .map((/** @type {Record<string, unknown>} */ entry) => /** @type {string} */ (entry.packaging_token)))
  const batchSegments = [
    ...asRecords(timelinePackaging.effect_segments).map((/** @type {Record<string, unknown>} */ segment) => ({ segment, token: segment.packaging_token })),
    ...asRecords(timelinePackaging.sticker_segments)
      .filter((/** @type {Record<string, unknown>} */ segment) => !Array.isArray(segment.keyframes) || segment.keyframes.length === 0)
      .map((/** @type {Record<string, unknown>} */ segment) => ({ segment, token: segment.packaging_token })),
    ...asRecords(timelinePackaging.animation_segments).map((/** @type {Record<string, unknown>} */ segment) => ({ segment, token: segment.animation_token })),
    ...asRecords(timelinePackaging.mask_segments).map((/** @type {Record<string, unknown>} */ segment) => ({ segment, token: segment.mask_token })),
    ...asRecords(timelinePackaging.blend_segments).map((/** @type {Record<string, unknown>} */ segment) => ({ segment, token: segment.blend_token })),
  ]
  if (batchSegments.some(({ token }) => typeof token !== 'string' || !catalogTokens.has(token))) {
    throw new Error('NATIVE_000B_BATCH_CATALOG_REQUIRED')
  }
  const prepared = preparePrivateBatchWriterSmokeFromTimelinePackaging({ index, timelinePackaging })
  // A normal export may intentionally contain no private packaging. Keep the
  // exact profile metadata on the empty batch, while still enforcing atomic
  // admission whenever placements are present.
  if (batchSegments.length === 0) {
    return Object.freeze({
      ...prepared,
      profileId: native000BDesktop.profileId,
      appVersion: native000BDesktop.version,
      evidenceId: index.evidenceId,
    })
  }
  if (prepared.writerPlan.length !== batchSegments.length || prepared.summary.skipped.length > 0) {
    throw new Error('NATIVE_000B_BATCH_ATOMIC_ADMISSION_REQUIRED')
  }
  return Object.freeze({
    ...prepared,
    profileId: native000BDesktop.profileId,
    appVersion: native000BDesktop.version,
    evidenceId: index.evidenceId,
  })
}

/**
 * Verify the controlled writer's private readback and, when available, the
 * decrypted draft_content structure against the exact prepared projection.
 * @param {{index: any, prepared: any, readback: unknown, draftContent?: unknown}} input
 */
export const verifyPrivateBatchWriterSmoke = ({ index, prepared, readback, draftContent = undefined }) => {
  if (!index || !prepared || !Array.isArray(prepared.writerPlan) || !prepared.projected) return false
  try {
    validatePrivateBatchPlanForWriter(
      prepared.writerPlan,
      (packagingToken) => resolvePrivatePackagingResourceToken(index, packagingToken),
    )
    const expectedProjection = projectPrivatePackagingBatchForWriter(prepared.writerPlan)
    if (JSON.stringify(expectedProjection) !== JSON.stringify(prepared.projected)) return false
  } catch {
    return false
  }
  if (!verifyPrivateBatchDraftReadback(readback, prepared.writerPlan)) return false
  return draftContent === undefined || verifyPrivateBatchDraftContent(draftContent, prepared.projected)
}

const batchReceiptProfilePattern = /^jianying-[a-z0-9-]{1,80}$/u
const batchReceiptEvidencePattern = /^ovjevidence_v1_[a-z0-9_-]{8,160}$/iu

/**
 * Publish a path-free aggregate for a controlled writer readback. This is a
 * writer/readback receipt only; it deliberately does not assert that the
 * Jianying desktop opened, edited, saved or reopened the draft.
 * @param {{index: any, desktop: {profileId: string, version: string}, prepared: any, readback: unknown, draftContent?: unknown}} input
 */
export const createPrivateBatchWriterReadbackReceipt = ({ index, desktop, prepared, readback, draftContent = undefined }) => {
  if (!index || !desktop || index.profileId !== desktop.profileId || index.appVersion !== desktop.version ||
      !batchReceiptProfilePattern.test(desktop.profileId ?? '') ||
      typeof index.evidenceId !== 'string' || !batchReceiptEvidencePattern.test(index.evidenceId) ||
      !prepared || !Array.isArray(prepared.writerPlan) || prepared.writerPlan.length === 0 ||
      prepared.writerPlan.length > 24 || !verifyPrivateBatchWriterSmoke({ index, prepared, readback, draftContent })) return null
  const families = [...new Set(prepared.writerPlan.map((/** @type {Record<string, unknown>} */ entry) => entry?.family))]
    .filter((family) => typeof family === 'string' && /^[a-z][a-z0-9_]{1,40}$/u.test(family))
    .sort()
  if (families.length === 0) return null
  return Object.freeze({
    schema_version: 1,
    kind: 'jy_private_batch_writer_readback_receipt',
    status: 'writer_readback_verified',
    profile_id: desktop.profileId,
    app_version: desktop.version,
    evidence_id: index.evidenceId,
    accepted_count: prepared.writerPlan.length,
    families: Object.freeze(families),
    readback_verified: true,
    draft_content_verified: draftContent !== undefined,
    desktop_lifecycle_verified: false,
  })
}
