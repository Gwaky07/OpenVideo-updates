import { createHash } from 'node:crypto'

import { isJianyingDraftExportRequest } from './jianying-draft-contracts.mjs'
import {
  isHistoricalTemplateDraftRequest,
  isTemplateDraftRequest,
  isTemplateSelectionRequest,
  listFixedTemplates,
} from './template-library.mjs'

const orientations = ['portrait', 'landscape', 'square']
const requestedSignals = [
  'shot_timing',
  'visual_role',
  'transition_pattern',
  'caption_cadence',
  'audio_emphasis',
]
const evidenceCodes = ['synthetic_fixture', ...requestedSignals]
const shotRoles = ['hook', 'context', 'detail', 'process', 'proof', 'cta']
const transitions = ['none', 'cut', 'dissolve', 'match_cut', 'wipe']
const captionModes = ['none', 'steady', 'burst']
const audioEmphasisKinds = ['beat', 'accent', 'drop']
const pacingValues = ['calm', 'balanced', 'dynamic']
const reviewReasonCodes = [
  'structure_verified',
  'reference_approved',
  'reference_structure_unsuitable',
  'policy_mismatch',
  'adjust_slot_timing',
  'adjust_transition',
  'adjust_caption_cadence',
  'adjust_pacing',
]
const approvalReasonCodes = ['structure_verified', 'reference_approved']
const rejectionReasonCodes = ['reference_structure_unsuitable', 'policy_mismatch']
const revisionReasonCodes = [
  'adjust_slot_timing',
  'adjust_transition',
  'adjust_caption_cadence',
  'adjust_pacing',
]
const maxIdentifierLength = 180
const ratioScale = 1_000_000

const descriptorKeys = [
  'schema_version',
  'kind',
  'reference_id',
  'duration_ms',
  'orientation',
  'source_kind',
  'access_mode',
  'privacy',
]
const adapterRequestKeys = [
  'schema_version',
  'kind',
  'request_id',
  'project_id',
  'template_selection_request',
  'fixed_template_draft_request',
  'reference',
  'requested_signals',
  'output_contract',
]
const analysisKeys = [
  'schema_version',
  'kind',
  'request_id',
  'reference_id',
  'duration_ms',
  'orientation',
  'shots',
  'caption_cadence',
  'audio_emphasis',
  'evidence_codes',
]
const shotKeys = ['shot_id', 'order', 'start_ms', 'end_ms', 'role', 'transition_out']
const captionCadenceKeys = ['mode', 'max_chars_per_card', 'cards_per_minute']
const audioEmphasisKeys = ['at_ms', 'kind']

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {value is any[]} */
const isDenseArray = (value) =>
  Array.isArray(value) &&
  Object.keys(value).length === value.length &&
  Object.keys(value).every((key, index) => key === String(index))

/** @param {Record<string, unknown>} value @param {string[]} expected */
const hasExactKeys = (value, expected) =>
  Object.keys(value).length === expected.length &&
  expected.every((key) => Object.hasOwn(value, key)) &&
  Object.keys(value).every((key) => expected.includes(key))

/** @param {unknown} left @param {unknown} right @returns {boolean} */
const valuesEqual = (left, right) => {
  if (left === right) return true
  if (Array.isArray(left) || Array.isArray(right)) {
    return (
      isDenseArray(left) &&
      isDenseArray(right) &&
      left.length === right.length &&
      left.every((entry, index) => valuesEqual(entry, right[index]))
    )
  }
  if (!isRecord(left) || !isRecord(right)) return false
  const leftKeys = Object.keys(left)
  const rightKeys = Object.keys(right)
  return (
    leftKeys.length === rightKeys.length &&
    leftKeys.every((key) => Object.hasOwn(right, key) && valuesEqual(left[key], right[key]))
  )
}

/** @param {unknown} value @returns {value is string} */
const isSafeIdentifier = (value) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= maxIdentifierLength &&
  value === value.trim() &&
  /^[A-Za-z0-9][A-Za-z0-9_-]*$/u.test(value)

/** @param {unknown} value @param {string[]} allowed @returns {value is string} */
const isEnum = (value, allowed) => typeof value === 'string' && allowed.includes(value)

/** @param {unknown} value @param {string[]} allowed @returns {value is string[]} */
const isUniqueEnumArray = (value, allowed) =>
  isDenseArray(value) &&
  value.length > 0 &&
  new Set(value).size === value.length &&
  value.every((entry) => isEnum(entry, allowed))

/** @param {unknown} value @param {string[]} allowed @returns {value is string[]} */
const isEnumArray = (value, allowed) =>
  isDenseArray(value) && value.length > 0 && value.every((entry) => isEnum(entry, allowed))

/** @param {unknown} value @returns {value is number} */
const isInteger = (value) => typeof value === 'number' && Number.isSafeInteger(value)

/** @param {unknown} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value)
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new ReferenceTemplateContractError('non_json_canonical_value')
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) {
    if (!isDenseArray(value)) throw new ReferenceTemplateContractError('non_json_canonical_value')
    return `[${value.map(stableStringify).join(',')}]`
  }
  if (isRecord(value)) {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`
  }
  throw new ReferenceTemplateContractError('non_json_canonical_value')
}

/** @param {unknown} value */
const sha256 = (value) => createHash('sha256').update(stableStringify(value)).digest('hex')

/** @param {number} total @param {number[]} weights */
const allocateIntegerTotal = (total, weights) => {
  const weightTotal = weights.reduce((sum, weight) => sum + weight, 0)
  if (
    !Number.isSafeInteger(total) ||
    total < weights.length ||
    weights.length === 0 ||
    !weights.every((weight) => Number.isSafeInteger(weight) && weight > 0) ||
    !Number.isSafeInteger(weightTotal) ||
    weightTotal <= 0
  ) {
    throw new ReferenceTemplateContractError('invalid_allocation_weights')
  }
  const distributable = total - weights.length
  let allocated = 0
  return weights.map((weight, index) => {
    const value =
      index === weights.length - 1
        ? total - allocated
        : Math.floor((distributable * weight) / weightTotal) + 1
    allocated += value
    return value
  })
}

/** @param {unknown} value */
const isCaptionCadence = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, captionCadenceKeys)) return false
  if (
    !isEnum(value.mode, captionModes) ||
    !isInteger(value.max_chars_per_card) ||
    !isInteger(value.cards_per_minute)
  ) {
    return false
  }
  if (value.mode === 'none') return value.max_chars_per_card === 0 && value.cards_per_minute === 0
  return (
    value.max_chars_per_card >= 6 &&
    value.max_chars_per_card <= 40 &&
    value.cards_per_minute >= 1 &&
    value.cards_per_minute <= 120
  )
}

/** @param {unknown} value @param {number} durationMs */
const isAudioEmphasis = (value, durationMs) =>
  isDenseArray(value) &&
  value.length <= 64 &&
  value.every(
    (entry, index) =>
      isRecord(entry) &&
      hasExactKeys(entry, audioEmphasisKeys) &&
      isInteger(entry.at_ms) &&
      entry.at_ms >= 0 &&
      entry.at_ms < durationMs &&
      isEnum(entry.kind, audioEmphasisKinds) &&
      (index === 0 || (isRecord(value[index - 1]) && entry.at_ms > value[index - 1].at_ms)),
  )

export class ReferenceTemplateContractError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'ReferenceTemplateContractError'
    this.code = code
  }
}

/** @param {unknown} value */
export const isReferenceVideoDescriptor = (value) =>
  isRecord(value) &&
  hasExactKeys(value, descriptorKeys) &&
  value.schema_version === 1 &&
  value.kind === 'reference_video_descriptor' &&
  isSafeIdentifier(value.reference_id) &&
  isInteger(value.duration_ms) &&
  value.duration_ms >= 1_000 &&
  value.duration_ms <= 600_000 &&
  isEnum(value.orientation, orientations) &&
  value.source_kind === 'external_reference' &&
  value.access_mode === 'external_read_only' &&
  value.privacy === 'sanitized_metadata_only'

/** @param {unknown} selectionRequest @param {unknown} fixedDraftRequest @param {unknown} reference */
const buildAdapterRequest = (selectionRequest, fixedDraftRequest, reference) => {
  if (!isTemplateSelectionRequest(selectionRequest)) {
    throw new ReferenceTemplateContractError('invalid_template_selection_request')
  }
  if (!isSafeIdentifier(selectionRequest.project_id)) {
    throw new ReferenceTemplateContractError('invalid_project_identifier')
  }
  if (!isTemplateDraftRequest(selectionRequest, fixedDraftRequest)) {
    throw new ReferenceTemplateContractError('invalid_fixed_template_draft_request')
  }
  if (!isReferenceVideoDescriptor(reference)) {
    throw new ReferenceTemplateContractError('invalid_reference_video_descriptor')
  }
  const referenceDescriptor = /** @type {Record<string, unknown>} */ (reference)
  if (referenceDescriptor.orientation !== selectionRequest.orientation) {
    throw new ReferenceTemplateContractError('reference_orientation_mismatch')
  }
  const draft = /** @type {Record<string, unknown>} */ (fixedDraftRequest)
  const templateRef = /** @type {Record<string, unknown>} */ (draft.template_ref)
  const requestPayload = {
    schema_version: 1,
    kind: 'reference_template_adapter_request',
    project_id: selectionRequest.project_id,
    template_selection_request: clone(selectionRequest),
    fixed_template_draft_request: clone(fixedDraftRequest),
    reference: clone(reference),
    requested_signals: [...requestedSignals],
    output_contract: 'reference_template_analysis_v1',
  }
  return {
    ...requestPayload,
    request_id: `reference-analysis-${sha256(requestPayload).slice(0, 24)}`,
  }
}

/** @param {unknown} selectionRequest @param {unknown} fixedDraftRequest @param {unknown} reference */
const buildHistoricalAdapterRequest = (selectionRequest, fixedDraftRequest, reference) => {
  if (
    !isTemplateSelectionRequest(selectionRequest) ||
    !isHistoricalTemplateDraftRequest(selectionRequest, fixedDraftRequest) ||
    !isReferenceVideoDescriptor(reference)
  ) {
    throw new ReferenceTemplateContractError('invalid_historical_adapter_request')
  }
  const referenceDescriptor = /** @type {Record<string, unknown>} */ (reference)
  if (referenceDescriptor.orientation !== selectionRequest.orientation) {
    throw new ReferenceTemplateContractError('reference_orientation_mismatch')
  }
  const requestPayload = {
    schema_version: 1,
    kind: 'reference_template_adapter_request',
    project_id: selectionRequest.project_id,
    template_selection_request: clone(selectionRequest),
    fixed_template_draft_request: clone(fixedDraftRequest),
    reference: clone(reference),
    requested_signals: [...requestedSignals],
    output_contract: 'reference_template_analysis_v1',
  }
  return {
    ...requestPayload,
    request_id: `reference-analysis-${sha256(requestPayload).slice(0, 24)}`,
  }
}

/** @param {unknown} value */
const findFixedTemplate = (value) => {
  if (!isTemplateReference(value)) return null
  const reference = /** @type {Record<string, unknown>} */ (value)
  return (
    listFixedTemplates().find(
      (template) =>
        template.template_id === reference.template_id && template.version === reference.version,
    ) ?? null
  )
}

/** @param {unknown} templateRef @param {unknown} slots @param {unknown} rules @param {unknown} targetDurationMs */
const matchesBaseTemplateCapabilities = (templateRef, slots, rules, targetDurationMs) => {
  const template = findFixedTemplate(templateRef)
  if (!template || !isDenseArray(slots) || !isRecord(rules) || !isInteger(targetDurationMs)) return false
  return (
    slots.length >= template.slot_count.min &&
    slots.length <= template.slot_count.max &&
    template.pacing.includes(String(rules.pacing)) &&
    targetDurationMs >= template.duration_seconds.min * 1_000 &&
    targetDurationMs <= template.duration_seconds.max * 1_000
  )
}

/** @param {unknown} value */
const isAdapterRequestEnvelope = (value) =>
  isRecord(value) &&
  hasExactKeys(value, adapterRequestKeys) &&
  value.schema_version === 1 &&
  value.kind === 'reference_template_adapter_request' &&
  isSafeIdentifier(value.request_id) &&
  isSafeIdentifier(value.project_id) &&
  isTemplateSelectionRequest(value.template_selection_request) &&
  isRecord(value.fixed_template_draft_request) &&
  isReferenceVideoDescriptor(value.reference) &&
  valuesEqual(value.requested_signals, requestedSignals) &&
  value.output_contract === 'reference_template_analysis_v1'

/** @param {unknown} selectionRequest @param {unknown} value */
export const isReferenceTemplateAdapterRequest = (selectionRequest, value) => {
  if (!isAdapterRequestEnvelope(value)) return false
  const request = /** @type {Record<string, unknown>} */ (value)
  try {
    return valuesEqual(
      request,
      buildAdapterRequest(selectionRequest, request.fixed_template_draft_request, request.reference),
    )
  } catch {
    return false
  }
}

/** @param {unknown} selectionRequest @param {unknown} value */
export const isHistoricalReferenceTemplateAdapterRequest = (selectionRequest, value) => {
  if (!isAdapterRequestEnvelope(value)) return false
  const request = /** @type {Record<string, unknown>} */ (value)
  try {
    return valuesEqual(
      request,
      buildHistoricalAdapterRequest(
        selectionRequest,
        request.fixed_template_draft_request,
        request.reference,
      ),
    )
  } catch {
    return false
  }
}

/** @param {unknown} selectionRequest @param {unknown} fixedDraftRequest @param {unknown} reference */
export const createReferenceTemplateAdapterRequest = (selectionRequest, fixedDraftRequest, reference) =>
  buildAdapterRequest(selectionRequest, fixedDraftRequest, reference)

/** @param {unknown} value @param {number} durationMs */
const isShotList = (value, durationMs) => {
  if (!isDenseArray(value) || value.length < 2 || value.length > 24) return false
  const identifiers = new Set()
  return value.every((shot, index) => {
    if (!isRecord(shot) || !hasExactKeys(shot, shotKeys)) return false
    const valid =
      isSafeIdentifier(shot.shot_id) &&
      !identifiers.has(shot.shot_id) &&
      shot.order === index + 1 &&
      isInteger(shot.start_ms) &&
      isInteger(shot.end_ms) &&
      shot.start_ms === (index === 0 ? 0 : isRecord(value[index - 1]) ? value[index - 1].end_ms : -1) &&
      shot.end_ms > shot.start_ms &&
      shot.end_ms <= durationMs &&
      isEnum(shot.role, shotRoles) &&
      isEnum(shot.transition_out, transitions) &&
      (index === value.length - 1 ? shot.end_ms === durationMs && shot.transition_out === 'none' : shot.transition_out !== 'none')
    identifiers.add(shot.shot_id)
    return valid
  })
}

/**
 * @param {unknown} adapterRequest
 * @param {unknown} value
 * @param {(selectionRequest: unknown, request: unknown) => boolean} validateAdapter
 */
const isReferenceTemplateAnalysisWith = (adapterRequest, value, validateAdapter) => {
  if (!isAdapterRequestEnvelope(adapterRequest) || !isRecord(value) || !hasExactKeys(value, analysisKeys)) {
    return false
  }
  const request = /** @type {Record<string, unknown>} */ (adapterRequest)
  if (!validateAdapter(request.template_selection_request, adapterRequest)) return false
  const reference = request.reference
  if (!isRecord(reference)) return false
  const fixedDraft = request.fixed_template_draft_request
  const selectionRequest = request.template_selection_request
  const templateRef = isRecord(fixedDraft) ? fixedDraft.template_ref : null
  const template = findFixedTemplate(templateRef)
  if (!template || !isRecord(selectionRequest)) return false
  return (
    value.schema_version === 1 &&
    value.kind === 'reference_template_analysis' &&
    value.request_id === request.request_id &&
    value.reference_id === reference.reference_id &&
    value.duration_ms === reference.duration_ms &&
    value.orientation === reference.orientation &&
    isInteger(value.duration_ms) &&
    isShotList(value.shots, value.duration_ms) &&
    /** @type {unknown[]} */ (value.shots).length >= template.slot_count.min &&
    /** @type {unknown[]} */ (value.shots).length <= template.slot_count.max &&
    isCaptionCadence(value.caption_cadence) &&
    (selectionRequest.captions_required !== true ||
      (isRecord(value.caption_cadence) && value.caption_cadence.mode !== 'none')) &&
    isAudioEmphasis(value.audio_emphasis, value.duration_ms) &&
    isUniqueEnumArray(value.evidence_codes, evidenceCodes) &&
    requestedSignals.every((signal) => /** @type {unknown[]} */ (value.evidence_codes).includes(signal))
  )
}

/** @param {unknown} adapterRequest @param {unknown} value */
export const isReferenceTemplateAnalysis = (adapterRequest, value) =>
  isReferenceTemplateAnalysisWith(
    adapterRequest,
    value,
    isReferenceTemplateAdapterRequest,
  )

/** @param {unknown} adapterRequest @param {unknown} value */
export const isHistoricalReferenceTemplateAnalysis = (adapterRequest, value) =>
  isReferenceTemplateAnalysisWith(
    adapterRequest,
    value,
    isHistoricalReferenceTemplateAdapterRequest,
  )

const draftKeys = [
  'schema_version',
  'kind',
  'draft_id',
  'project_id',
  'base_template_ref',
  'reference_evidence',
  'revision',
  'target_duration_ms',
  'slots',
  'rules',
  'confirmation',
  'integrity_sha256',
]
const templateRefKeys = ['template_id', 'version']
const referenceEvidenceKeys = [
  'request_id',
  'reference_id',
  'duration_ms',
  'orientation',
  'source_kind',
  'access_mode',
  'privacy',
  'evidence_codes',
]
const revisionKeys = ['number', 'parent_draft_id', 'reason_codes', 'changes']
const slotKeys = [
  'slot_id',
  'order',
  'role',
  'duration_ratio_ppm',
  'recommended_duration_ms',
  'transition_out',
  'evidence_shot_ids',
]
const rulesKeys = ['pacing', 'caption_cadence', 'audio_emphasis']
const normalizedEmphasisKeys = ['position_ratio_ppm', 'kind']
const revisionRequestKeys = [
  'pacing',
  'caption_cadence',
  'slot_duration_weights',
  'transition_overrides',
]
const slotWeightKeys = ['slot_id', 'weight_ppm']
const transitionOverrideKeys = ['slot_id', 'transition_out']

/** @param {unknown} value */
const isTemplateReference = (value) =>
  isRecord(value) &&
  hasExactKeys(value, templateRefKeys) &&
  isSafeIdentifier(value.template_id) &&
  value.version === 1

/** @param {unknown} value */
const isReferenceEvidence = (value) =>
  isRecord(value) &&
  hasExactKeys(value, referenceEvidenceKeys) &&
  isSafeIdentifier(value.request_id) &&
  isSafeIdentifier(value.reference_id) &&
  isInteger(value.duration_ms) &&
  value.duration_ms >= 1_000 &&
  value.duration_ms <= 600_000 &&
  isEnum(value.orientation, orientations) &&
  value.source_kind === 'external_reference' &&
  value.access_mode === 'external_read_only' &&
  value.privacy === 'sanitized_metadata_only' &&
  isUniqueEnumArray(value.evidence_codes, evidenceCodes) &&
  requestedSignals.every((signal) => /** @type {unknown[]} */ (value.evidence_codes).includes(signal))

/** @param {unknown} value */
const isNormalizedEmphasis = (value) =>
  isDenseArray(value) &&
  value.length <= 64 &&
  value.every(
    (entry, index) =>
      isRecord(entry) &&
      hasExactKeys(entry, normalizedEmphasisKeys) &&
      isInteger(entry.position_ratio_ppm) &&
      entry.position_ratio_ppm >= 0 &&
      entry.position_ratio_ppm < ratioScale &&
      isEnum(entry.kind, audioEmphasisKinds) &&
      (index === 0 ||
        (isRecord(value[index - 1]) && entry.position_ratio_ppm > value[index - 1].position_ratio_ppm)),
  )

/** @param {unknown} value @param {string[]} slotIds */
const isRevisionRequest = (value, slotIds) => {
  if (!isRecord(value) || !hasExactKeys(value, revisionRequestKeys)) return false
  if (!isEnum(value.pacing, pacingValues) || !isCaptionCadence(value.caption_cadence)) return false
  if (
    !isDenseArray(value.slot_duration_weights) ||
    value.slot_duration_weights.length !== slotIds.length ||
    !value.slot_duration_weights.every(
      (entry, index) =>
        isRecord(entry) &&
        hasExactKeys(entry, slotWeightKeys) &&
        entry.slot_id === slotIds[index] &&
        isInteger(entry.weight_ppm) &&
        entry.weight_ppm >= 1,
    ) ||
    value.slot_duration_weights.reduce(
      (total, entry) => total + (isRecord(entry) && isInteger(entry.weight_ppm) ? entry.weight_ppm : 0),
      0,
    ) !== ratioScale
  ) {
    return false
  }
  if (!isDenseArray(value.transition_overrides) || value.transition_overrides.length > slotIds.length) return false
  const seen = new Set()
  return value.transition_overrides.every(
    (entry) =>
      isRecord(entry) &&
      hasExactKeys(entry, transitionOverrideKeys) &&
      typeof entry.slot_id === 'string' &&
      slotIds.includes(entry.slot_id) &&
      !seen.has(entry.slot_id) &&
      seen.add(entry.slot_id) &&
      isEnum(entry.transition_out, transitions) &&
      (entry.slot_id === slotIds.at(-1) ? entry.transition_out === 'none' : entry.transition_out !== 'none'),
  )
}

/** @param {unknown} value @param {string[]} slotIds */
const isRevision = (value, slotIds) => {
  if (!isRecord(value) || !hasExactKeys(value, revisionKeys)) return false
  if (!isInteger(value.number) || value.number < 0 || value.number > 1) return false
  if (!isDenseArray(value.reason_codes) || !value.reason_codes.every((entry) => isEnum(entry, reviewReasonCodes))) {
    return false
  }
  if (value.number === 0) {
    return value.parent_draft_id === null && value.reason_codes.length === 0 && value.changes === null
  }
  return (
    isSafeIdentifier(value.parent_draft_id) &&
    value.reason_codes.length > 0 &&
    isRevisionRequest(value.changes, slotIds)
  )
}

/** @param {unknown} value @param {number} targetDurationMs */
const isSlots = (value, targetDurationMs) => {
  if (!isDenseArray(value) || value.length < 2 || value.length > 24) return false
  const identifiers = new Set()
  const valid = value.every(
    (slot, index) =>
      isRecord(slot) &&
      hasExactKeys(slot, slotKeys) &&
      isSafeIdentifier(slot.slot_id) &&
      !identifiers.has(slot.slot_id) &&
      identifiers.add(slot.slot_id) &&
      slot.order === index + 1 &&
      isEnum(slot.role, shotRoles) &&
      isInteger(slot.duration_ratio_ppm) &&
      slot.duration_ratio_ppm >= 1 &&
      isInteger(slot.recommended_duration_ms) &&
      slot.recommended_duration_ms >= 1 &&
      isEnum(slot.transition_out, transitions) &&
      (index === value.length - 1 ? slot.transition_out === 'none' : slot.transition_out !== 'none') &&
      isDenseArray(slot.evidence_shot_ids) &&
      slot.evidence_shot_ids.length > 0 &&
      slot.evidence_shot_ids.every(isSafeIdentifier),
  )
  return (
    valid &&
    value.reduce(
      (total, slot) => total + (isRecord(slot) && isInteger(slot.duration_ratio_ppm) ? slot.duration_ratio_ppm : 0),
      0,
    ) === ratioScale &&
    value.reduce(
      (total, slot) =>
        total + (isRecord(slot) && isInteger(slot.recommended_duration_ms) ? slot.recommended_duration_ms : 0),
      0,
    ) === targetDurationMs
  )
}

/** @param {unknown} value */
const isRules = (value) =>
  isRecord(value) &&
  hasExactKeys(value, rulesKeys) &&
  isEnum(value.pacing, pacingValues) &&
  isCaptionCadence(value.caption_cadence) &&
  isNormalizedEmphasis(value.audio_emphasis)

/** @param {Record<string, unknown>} draft */
const draftWithoutIntegrity = (draft) => {
  const { integrity_sha256: _integrity, ...payload } = draft
  return payload
}

/** @param {unknown} value @param {boolean} verifyIntegrity */
const isReferenceTemplateDraftShape = (value, verifyIntegrity) => {
  if (!isRecord(value) || !hasExactKeys(value, draftKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'reference_template_draft' ||
    !isSafeIdentifier(value.draft_id) ||
    !isSafeIdentifier(value.project_id) ||
    !isTemplateReference(value.base_template_ref) ||
    !isReferenceEvidence(value.reference_evidence) ||
    !isInteger(value.target_duration_ms) ||
    value.target_duration_ms < 1_000 ||
    value.target_duration_ms > 600_000 ||
    !isSlots(value.slots, value.target_duration_ms) ||
    !isRules(value.rules) ||
    !matchesBaseTemplateCapabilities(value.base_template_ref, value.slots, value.rules, value.target_duration_ms) ||
    value.confirmation !== 'required' ||
    typeof value.integrity_sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.integrity_sha256)
  ) {
    return false
  }
  const slotIds = /** @type {Record<string, unknown>[]} */ (value.slots).map((slot) => String(slot.slot_id))
  return (
    isRevision(value.revision, slotIds) &&
    (!verifyIntegrity || value.integrity_sha256 === sha256(draftWithoutIntegrity(value)))
  )
}

/** @param {unknown} value */
export const isReferenceTemplateDraft = (value) => isReferenceTemplateDraftShape(value, true)

/** @param {Record<string, unknown>} payload */
const finalizeDraft = (payload) => {
  const draftId = `reference-template-${sha256(payload).slice(0, 24)}`
  const withoutIntegrity = { ...payload, draft_id: draftId }
  return { ...withoutIntegrity, integrity_sha256: sha256(withoutIntegrity) }
}

/**
 * @param {unknown} selectionRequest
 * @param {unknown} adapterRequest
 * @param {unknown} analysis
 * @param {(selectionRequest: unknown, request: unknown) => boolean} validateAdapter
 * @param {(request: unknown, analysis: unknown) => boolean} validateAnalysis
 */
const buildInitialDraftWith = (
  selectionRequest,
  adapterRequest,
  analysis,
  validateAdapter,
  validateAnalysis,
) => {
  if (!isTemplateSelectionRequest(selectionRequest)) {
    throw new ReferenceTemplateContractError('invalid_template_selection_request')
  }
  if (!validateAdapter(selectionRequest, adapterRequest)) {
    throw new ReferenceTemplateContractError('invalid_reference_template_adapter_request')
  }
  if (!validateAnalysis(adapterRequest, analysis)) {
    throw new ReferenceTemplateContractError('invalid_reference_template_analysis')
  }
  const request = /** @type {Record<string, unknown>} */ (adapterRequest)
  const fixedDraft = /** @type {Record<string, unknown>} */ (request.fixed_template_draft_request)
  const reference = /** @type {Record<string, unknown>} */ (request.reference)
  const templateRef = /** @type {Record<string, unknown>} */ (fixedDraft.template_ref)
  const observation = /** @type {Record<string, unknown>} */ (analysis)
  const shots = /** @type {Record<string, unknown>[]} */ (observation.shots)
  const sourceDurations = shots.map((shot) => Number(shot.end_ms) - Number(shot.start_ms))
  const ratios = allocateIntegerTotal(ratioScale, sourceDurations)
  const targetDurationMs = selectionRequest.target_duration_seconds * 1_000
  const recommendedDurations = allocateIntegerTotal(targetDurationMs, ratios)
  const slots = shots.map((shot, index) => ({
    slot_id: `slot-${String(index + 1).padStart(3, '0')}`,
    order: index + 1,
    role: shot.role,
    duration_ratio_ppm: ratios[index],
    recommended_duration_ms: recommendedDurations[index],
    transition_out: shot.transition_out,
    evidence_shot_ids: [shot.shot_id],
  }))
  const audioEmphasis = /** @type {Record<string, unknown>[]} */ (observation.audio_emphasis).map(
    (entry) => ({
      position_ratio_ppm: Math.floor((Number(entry.at_ms) * ratioScale) / Number(observation.duration_ms)),
      kind: entry.kind,
    }),
  )
  return finalizeDraft({
    schema_version: 1,
    kind: 'reference_template_draft',
    project_id: selectionRequest.project_id,
    base_template_ref: clone(templateRef),
    reference_evidence: {
      request_id: request.request_id,
      reference_id: observation.reference_id,
      duration_ms: observation.duration_ms,
      orientation: observation.orientation,
      source_kind: reference.source_kind,
      access_mode: reference.access_mode,
      privacy: reference.privacy,
      evidence_codes: clone(observation.evidence_codes),
    },
    revision: {
      number: 0,
      parent_draft_id: null,
      reason_codes: [],
      changes: null,
    },
    target_duration_ms: targetDurationMs,
    slots,
    rules: {
      pacing: selectionRequest.pacing,
      caption_cadence: clone(observation.caption_cadence),
      audio_emphasis: audioEmphasis,
    },
    confirmation: 'required',
  })
}

/** @param {unknown} selectionRequest @param {unknown} adapterRequest @param {unknown} analysis */
const buildInitialDraft = (selectionRequest, adapterRequest, analysis) =>
  buildInitialDraftWith(
    selectionRequest,
    adapterRequest,
    analysis,
    isReferenceTemplateAdapterRequest,
    isReferenceTemplateAnalysis,
  )

/** @param {unknown} selectionRequest @param {unknown} adapterRequest @param {unknown} analysis */
export const createReferenceTemplateDraft = (selectionRequest, adapterRequest, analysis) =>
  buildInitialDraft(selectionRequest, adapterRequest, analysis)

const preflightCheckCodes = [
  'adapter_request_valid',
  'analysis_valid',
  'draft_shape_valid',
  'draft_integrity_valid',
  'draft_links_valid',
  'draft_canonical',
]
const preflightErrorCodes = [
  'invalid_adapter_request',
  'invalid_analysis',
  'invalid_draft_shape',
  'draft_integrity_mismatch',
  'draft_link_mismatch',
  'draft_canonical_mismatch',
]
const preflightKeys = [
  'schema_version',
  'kind',
  'draft_id',
  'ready',
  'checks',
  'errors',
  'summary',
  'integrity_sha256',
]
const preflightCheckKeys = ['code', 'passed']
const preflightErrorKeys = ['code']
const preflightSummaryKeys = ['slot_count', 'target_duration_ms', 'revision_number']

/** @param {unknown} value */
const isPreflightCheck = (value) =>
  isRecord(value) &&
  hasExactKeys(value, preflightCheckKeys) &&
  isEnum(value.code, preflightCheckCodes) &&
  typeof value.passed === 'boolean'

/** @param {unknown} value */
const isPreflightError = (value) =>
  isRecord(value) &&
  hasExactKeys(value, preflightErrorKeys) &&
  isEnum(value.code, preflightErrorCodes)

/** @param {unknown} value */
export const isReferenceTemplatePreflightReport = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, preflightKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'reference_template_preflight_report' ||
    !isSafeIdentifier(value.draft_id) ||
    typeof value.ready !== 'boolean' ||
    !isDenseArray(value.checks) ||
    value.checks.length !== preflightCheckCodes.length ||
    !value.checks.every(isPreflightCheck) ||
    !value.checks.every((check, index) => isRecord(check) && check.code === preflightCheckCodes[index]) ||
    !isDenseArray(value.errors) ||
    !value.errors.every(isPreflightError) ||
    !isRecord(value.summary) ||
    !hasExactKeys(value.summary, preflightSummaryKeys) ||
    !isInteger(value.summary.slot_count) ||
    value.summary.slot_count < 0 ||
    !isInteger(value.summary.target_duration_ms) ||
    value.summary.target_duration_ms < 0 ||
    !isInteger(value.summary.revision_number) ||
    value.summary.revision_number < 0 ||
    typeof value.integrity_sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.integrity_sha256)
  ) {
    return false
  }
  const passed = /** @type {Record<string, unknown>[]} */ (value.checks).every((check) => check.passed === true)
  const readyMatches = value.ready === passed && value.ready === (value.errors.length === 0)
  const { integrity_sha256: _integrity, ...payload } = value
  return readyMatches && value.integrity_sha256 === sha256(payload)
}

/** @param {Record<string, unknown>} initialDraft @param {Record<string, unknown>} revision @param {string[]} reasonCodes */
const buildRevisedDraft = (initialDraft, revision, reasonCodes) => {
  const slots = /** @type {Record<string, unknown>[]} */ (initialDraft.slots)
  const slotIds = slots.map((slot) => String(slot.slot_id))
  if (!isRevisionRequest(revision, slotIds)) {
    throw new ReferenceTemplateContractError('invalid_template_revision_request')
  }
  const template = findFixedTemplate(initialDraft.base_template_ref)
  if (!template || !template.pacing.includes(String(revision.pacing))) {
    throw new ReferenceTemplateContractError('revision_pacing_incompatible')
  }
  if (
    !isDenseArray(reasonCodes) ||
    reasonCodes.length === 0 ||
    new Set(reasonCodes).size !== reasonCodes.length ||
    !reasonCodes.every((reason) => isEnum(reason, reviewReasonCodes))
  ) {
    throw new ReferenceTemplateContractError('invalid_review_reason_codes')
  }
  const weights = /** @type {Record<string, unknown>[]} */ (revision.slot_duration_weights).map((entry) =>
    Number(entry.weight_ppm),
  )
  const durations = allocateIntegerTotal(Number(initialDraft.target_duration_ms), weights)
  const overrides = new Map(
    /** @type {Record<string, unknown>[]} */ (revision.transition_overrides).map((entry) => [
      String(entry.slot_id),
      entry.transition_out,
    ]),
  )
  const revisedSlots = slots.map((slot, index) => ({
    ...clone(slot),
    duration_ratio_ppm: weights[index],
    recommended_duration_ms: durations[index],
    transition_out: overrides.has(String(slot.slot_id))
      ? overrides.get(String(slot.slot_id))
      : slot.transition_out,
  }))
  return finalizeDraft({
    schema_version: 1,
    kind: 'reference_template_draft',
    project_id: initialDraft.project_id,
    base_template_ref: clone(initialDraft.base_template_ref),
    reference_evidence: clone(initialDraft.reference_evidence),
    revision: {
      number: 1,
      parent_draft_id: initialDraft.draft_id,
      reason_codes: clone(reasonCodes),
      changes: clone(revision),
    },
    target_duration_ms: initialDraft.target_duration_ms,
    slots: revisedSlots,
    rules: {
      pacing: revision.pacing,
      caption_cadence: clone(revision.caption_cadence),
      audio_emphasis: clone(/** @type {Record<string, unknown>} */ (initialDraft.rules).audio_emphasis),
    },
    confirmation: 'required',
  })
}

/**
 * @param {unknown} selectionRequest
 * @param {unknown} adapterRequest
 * @param {unknown} analysis
 * @param {unknown} draft
 * @param {(selectionRequest: unknown, request: unknown) => boolean} validateAdapter
 * @param {(request: unknown, analysis: unknown) => boolean} validateAnalysis
 */
const buildCanonicalDraftForPreflight = (
  selectionRequest,
  adapterRequest,
  analysis,
  draft,
  validateAdapter,
  validateAnalysis,
) => {
  const initial = buildInitialDraftWith(
    selectionRequest,
    adapterRequest,
    analysis,
    validateAdapter,
    validateAnalysis,
  )
  if (!isRecord(draft) || !isRecord(draft.revision) || draft.revision.number === 0) return initial
  if (draft.revision.number !== 1 || draft.revision.parent_draft_id !== initial.draft_id) return null
  if (!isDenseArray(draft.revision.reason_codes) || !isRecord(draft.revision.changes)) return null
  try {
    return buildRevisedDraft(initial, draft.revision.changes, draft.revision.reason_codes)
  } catch {
    return null
  }
}

/**
 * @param {unknown} selectionRequest
 * @param {unknown} adapterRequest
 * @param {unknown} analysis
 * @param {unknown} draft
 * @param {(selectionRequest: unknown, request: unknown) => boolean} validateAdapter
 * @param {(request: unknown, analysis: unknown) => boolean} validateAnalysis
 */
const preflightReferenceTemplateDraftWith = (
  selectionRequest,
  adapterRequest,
  analysis,
  draft,
  validateAdapter,
  validateAnalysis,
) => {
  const adapterValid = validateAdapter(selectionRequest, adapterRequest)
  const analysisValid = adapterValid && validateAnalysis(adapterRequest, analysis)
  const shapeValid = isReferenceTemplateDraftShape(draft, false)
  const integrityValid =
    isRecord(draft) &&
    typeof draft.integrity_sha256 === 'string' &&
    draft.integrity_sha256 === sha256(draftWithoutIntegrity(draft))
  let linksValid = false
  if (
    adapterValid &&
    analysisValid &&
    isRecord(selectionRequest) &&
    isRecord(draft) &&
    isRecord(adapterRequest) &&
    isRecord(analysis)
  ) {
    const fixedDraft = adapterRequest.fixed_template_draft_request
    const templateRef = isRecord(fixedDraft) ? fixedDraft.template_ref : null
    const evidence = draft.reference_evidence
    linksValid =
      draft.project_id === selectionRequest.project_id &&
      valuesEqual(draft.base_template_ref, templateRef) &&
      isRecord(evidence) &&
      evidence.request_id === adapterRequest.request_id &&
      evidence.reference_id === analysis.reference_id &&
      evidence.duration_ms === analysis.duration_ms &&
      isRecord(adapterRequest.reference) &&
      evidence.orientation === analysis.orientation &&
      evidence.source_kind === adapterRequest.reference.source_kind &&
      evidence.access_mode === adapterRequest.reference.access_mode &&
      evidence.privacy === adapterRequest.reference.privacy &&
      valuesEqual(evidence.evidence_codes, analysis.evidence_codes) &&
      draft.target_duration_ms === Number(selectionRequest.target_duration_seconds) * 1_000
  }
  let canonical = null
  if (adapterValid && analysisValid) {
    try {
      canonical = buildCanonicalDraftForPreflight(
        selectionRequest,
        adapterRequest,
        analysis,
        draft,
        validateAdapter,
        validateAnalysis,
      )
    } catch {
      canonical = null
    }
  }
  const canonicalValid = canonical !== null && valuesEqual(draft, canonical)
  const checks = [
    { code: 'adapter_request_valid', passed: adapterValid },
    { code: 'analysis_valid', passed: analysisValid },
    { code: 'draft_shape_valid', passed: shapeValid },
    { code: 'draft_integrity_valid', passed: integrityValid },
    { code: 'draft_links_valid', passed: linksValid },
    { code: 'draft_canonical', passed: canonicalValid },
  ]
  const errors = []
  if (!adapterValid) errors.push({ code: 'invalid_adapter_request' })
  if (!analysisValid) errors.push({ code: 'invalid_analysis' })
  if (!shapeValid) errors.push({ code: 'invalid_draft_shape' })
  if (!integrityValid) errors.push({ code: 'draft_integrity_mismatch' })
  if (!linksValid) errors.push({ code: 'draft_link_mismatch' })
  if (!canonicalValid) errors.push({ code: 'draft_canonical_mismatch' })
  const draftRecord = isRecord(draft) ? draft : {}
  const slots = isDenseArray(draftRecord.slots) ? draftRecord.slots : []
  const revision = isRecord(draftRecord.revision) ? draftRecord.revision : {}
  const payload = {
    schema_version: 1,
    kind: 'reference_template_preflight_report',
    draft_id: isSafeIdentifier(draftRecord.draft_id) ? draftRecord.draft_id : 'invalid-reference-template-draft',
    ready: errors.length === 0,
    checks,
    errors,
    summary: {
      slot_count: slots.length,
      target_duration_ms: isInteger(draftRecord.target_duration_ms) ? draftRecord.target_duration_ms : 0,
      revision_number: isInteger(revision.number) && revision.number >= 0 ? revision.number : 0,
    },
  }
  const report = { ...payload, integrity_sha256: sha256(payload) }
  if (!isReferenceTemplatePreflightReport(report)) {
    throw new ReferenceTemplateContractError('invalid_template_preflight_report')
  }
  return report
}

/** @param {unknown} selectionRequest @param {unknown} adapterRequest @param {unknown} analysis @param {unknown} draft */
export const preflightReferenceTemplateDraft = (selectionRequest, adapterRequest, analysis, draft) =>
  preflightReferenceTemplateDraftWith(
    selectionRequest,
    adapterRequest,
    analysis,
    draft,
    isReferenceTemplateAdapterRequest,
    isReferenceTemplateAnalysis,
  )

/** @param {unknown} selectionRequest @param {unknown} adapterRequest @param {unknown} analysis @param {unknown} draft */
export const preflightHistoricalReferenceTemplateDraft = (
  selectionRequest,
  adapterRequest,
  analysis,
  draft,
) => preflightReferenceTemplateDraftWith(
  selectionRequest,
  adapterRequest,
  analysis,
  draft,
  isHistoricalReferenceTemplateAdapterRequest,
  isHistoricalReferenceTemplateAnalysis,
)

const reviewCommandKeys = ['schema_version', 'kind', 'decision', 'reason_codes', 'revision']
const reviewDecisionKeys = [
  'schema_version',
  'kind',
  'draft_id',
  'decision',
  'reason_codes',
  'confirmed_template',
  'revision_request',
  'integrity_sha256',
]
const confirmedTemplateKeys = [
  'schema_version',
  'kind',
  'confirmed_template_id',
  'source_draft_id',
  'project_id',
  'base_template_ref',
  'orientation',
  'reference_provenance',
  'target_duration_ms',
  'slots',
  'rules',
  'confirmation',
  'integrity_sha256',
]
const compatibilityErrorCodes = [
  'TPL002_TEMPLATE_NOT_APPROVED',
  'TPL002_TEMPLATE_INTEGRITY_MISMATCH',
  'TPL002_EXPORT_REQUEST_INVALID',
  'TPL002_PROJECT_MISMATCH',
  'TPL002_UNSUPPORTED_ORIENTATION',
  'TPL002_UNSUPPORTED_TRANSITION',
  'TPL002_UNSUPPORTED_CAPTION_CADENCE',
  'TPL002_UNSUPPORTED_AUDIO_EMPHASIS',
  'TPL002_DURATION_MISMATCH',
  'TPL002_SLOT_COUNT_MISMATCH',
]
const capabilityEntryKeys = ['field', 'status', 'reason_code']
const capabilityMatrix = [
  { field: 'orientation', status: 'observation_only', reason_code: 'TPL002_UNSUPPORTED_ORIENTATION' },
  { field: 'slot_timing', status: 'actionable', reason_code: null },
  { field: 'transitions', status: 'observation_only', reason_code: 'TPL002_UNSUPPORTED_TRANSITION' },
  {
    field: 'caption_cadence',
    status: 'observation_only',
    reason_code: 'TPL002_UNSUPPORTED_CAPTION_CADENCE',
  },
  {
    field: 'audio_emphasis',
    status: 'observation_only',
    reason_code: 'TPL002_UNSUPPORTED_AUDIO_EMPHASIS',
  },
]
const compatibilityReportKeys = [
  'schema_version',
  'kind',
  'ready',
  'errors',
  'summary',
  'integrity_sha256',
]
const compatibilityErrorKeys = ['code']
const compatibilitySummaryKeys = [
  'template_duration_ms',
  'export_duration_us',
  'template_slot_count',
  'export_slot_count',
]
const exportRequestRefKeys = [
  'schema_version',
  'kind',
  'request_schema_version',
  'preparation_id',
  'source_plan_id',
  'export_request_digest',
]
const approvalRefKeys = [
  'schema_version',
  'kind',
  'decision_schema_version',
  'draft_id',
  'decision',
  'decision_integrity_sha256',
]
const confirmedTemplateRefKeys = [
  'schema_version',
  'kind',
  'template_schema_version',
  'source_draft_id',
  'confirmed_template_id',
  'template_integrity_sha256',
]
const envelopeKeys = [
  'schema_version',
  'kind',
  'envelope_id',
  'project_id',
  'template_ref',
  'export_request_ref',
  'approval_ref',
  'reference_provenance',
  'capability_matrix',
  'executable',
  'observation_only',
  'compatibility',
  'integrity_sha256',
]
/** @param {unknown} value @param {string[]} slotIds */
const isReviewCommand = (value, slotIds) => {
  if (!isRecord(value) || !hasExactKeys(value, reviewCommandKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'reference_template_review_command' ||
    !isEnum(value.decision, ['approve', 'reject', 'revise']) ||
    !isDenseArray(value.reason_codes) ||
    value.reason_codes.length === 0 ||
    new Set(value.reason_codes).size !== value.reason_codes.length ||
    !value.reason_codes.every((reason) => isEnum(reason, reviewReasonCodes))
  ) {
    return false
  }
  const reasons = /** @type {string[]} */ (value.reason_codes)
  if (value.decision === 'approve') {
    return reasons.every((reason) => approvalReasonCodes.includes(reason)) && value.revision === null
  }
  if (value.decision === 'reject') {
    return reasons.every((reason) => rejectionReasonCodes.includes(reason)) && value.revision === null
  }
  return reasons.every((reason) => revisionReasonCodes.includes(reason)) && isRevisionRequest(value.revision, slotIds)
}

/** @param {unknown} value */
const isConfirmedReferenceTemplateShape = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, confirmedTemplateKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'confirmed_reference_template' ||
    !isSafeIdentifier(value.confirmed_template_id) ||
    !isSafeIdentifier(value.source_draft_id) ||
    !isSafeIdentifier(value.project_id) ||
    !isTemplateReference(value.base_template_ref) ||
    !isEnum(value.orientation, orientations) ||
    !isRecord(value.reference_provenance) ||
    !hasExactKeys(value.reference_provenance, [
      'reference_id',
      'source_kind',
      'access_mode',
      'privacy',
    ]) ||
    !isSafeIdentifier(value.reference_provenance.reference_id) ||
    value.reference_provenance.source_kind !== 'external_reference' ||
    value.reference_provenance.access_mode !== 'external_read_only' ||
    value.reference_provenance.privacy !== 'sanitized_metadata_only' ||
    !isInteger(value.target_duration_ms) ||
    value.target_duration_ms < 1_000 ||
    value.target_duration_ms > 600_000 ||
    !isSlots(value.slots, value.target_duration_ms) ||
    !isRules(value.rules) ||
    !matchesBaseTemplateCapabilities(value.base_template_ref, value.slots, value.rules, value.target_duration_ms) ||
    value.confirmation !== 'approved' ||
    typeof value.integrity_sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.integrity_sha256)
  ) {
    return false
  }
  const { integrity_sha256: _integrity, ...payload } = value
  return value.integrity_sha256 === sha256(payload)
}

/** @param {Record<string, unknown>} draft */
const buildConfirmedTemplate = (draft) => {
  const evidence = /** @type {Record<string, unknown>} */ (draft.reference_evidence)
  const payload = {
    schema_version: 1,
    kind: 'confirmed_reference_template',
    confirmed_template_id: `confirmed-${sha256({ draft_id: draft.draft_id }).slice(0, 24)}`,
    source_draft_id: draft.draft_id,
    project_id: draft.project_id,
    base_template_ref: clone(draft.base_template_ref),
    orientation: evidence.orientation,
    reference_provenance: {
      reference_id: evidence.reference_id,
      source_kind: evidence.source_kind,
      access_mode: evidence.access_mode,
      privacy: evidence.privacy,
    },
    target_duration_ms: draft.target_duration_ms,
    slots: clone(draft.slots),
    rules: clone(draft.rules),
    confirmation: 'approved',
  }
  return { ...payload, integrity_sha256: sha256(payload) }
}

/** @param {unknown} draft @param {unknown} value */
export const isConfirmedReferenceTemplate = (draft, value) => {
  if (!isReferenceTemplateDraft(draft) || !isConfirmedReferenceTemplateShape(value)) return false
  return valuesEqual(value, buildConfirmedTemplate(/** @type {Record<string, unknown>} */ (draft)))
}

/** @param {unknown} draft @param {unknown} value */
export const isReferenceTemplateReviewDecision = (draft, value) => {
  if (!isReferenceTemplateDraft(draft)) return false
  if (!isRecord(value) || !hasExactKeys(value, reviewDecisionKeys)) return false
  const draftRecord = /** @type {Record<string, unknown>} */ (draft)
  const slots = /** @type {Record<string, unknown>[]} */ (draftRecord.slots)
  const slotIds = slots.map((slot) => String(slot.slot_id))
  if (
    value.schema_version !== 1 ||
    value.kind !== 'reference_template_review_decision' ||
    value.draft_id !== draftRecord.draft_id ||
    !isEnum(value.decision, ['approved', 'rejected', 'revision_required']) ||
    !isDenseArray(value.reason_codes) ||
    value.reason_codes.length === 0 ||
    new Set(value.reason_codes).size !== value.reason_codes.length ||
    !value.reason_codes.every((reason) => isEnum(reason, reviewReasonCodes)) ||
    typeof value.integrity_sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.integrity_sha256)
  ) {
    return false
  }
  const reasons = /** @type {string[]} */ (value.reason_codes)
  const reasonsMatchDecision =
    value.decision === 'approved'
      ? reasons.every((reason) => approvalReasonCodes.includes(reason))
      : value.decision === 'rejected'
        ? reasons.every((reason) => rejectionReasonCodes.includes(reason))
        : reasons.every((reason) => revisionReasonCodes.includes(reason))
  if (!reasonsMatchDecision) return false
  const payloadMatches =
    value.decision === 'approved'
      ? isConfirmedReferenceTemplate(draft, value.confirmed_template) &&
        value.revision_request === null
      : value.decision === 'rejected'
        ? value.confirmed_template === null && value.revision_request === null
        : value.confirmed_template === null &&
          isRecord(value.revision_request) &&
          isDenseArray(value.revision_request.slot_duration_weights) &&
          isRevisionRequest(value.revision_request, slotIds)
  if (!payloadMatches) return false
  if (value.decision === 'revision_required') {
    try {
      buildRevisedDraft(
        draftRecord,
        /** @type {Record<string, unknown>} */ (value.revision_request),
        reasons,
      )
    } catch {
      return false
    }
  }
  const { integrity_sha256: _integrity, ...payload } = value
  return value.integrity_sha256 === sha256(payload)
}

/** @param {unknown} value */
const isCapabilityMatrix = (value) =>
  isDenseArray(value) &&
  value.length === capabilityMatrix.length &&
  value.every(
    (entry, index) =>
      isRecord(entry) &&
      hasExactKeys(entry, capabilityEntryKeys) &&
      entry.field === capabilityMatrix[index].field &&
      entry.status === capabilityMatrix[index].status &&
      entry.reason_code === capabilityMatrix[index].reason_code,
  )

/** @param {unknown} value */
const isReferenceProvenance = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['reference_id', 'source_kind', 'access_mode', 'privacy']) &&
  isSafeIdentifier(value.reference_id) &&
  value.source_kind === 'external_reference' &&
  value.access_mode === 'external_read_only' &&
  value.privacy === 'sanitized_metadata_only'

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isCompatibilityReport = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, compatibilityReportKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'jianying_template_compatibility_report' ||
    typeof value.ready !== 'boolean' ||
    !isDenseArray(value.errors) ||
    !value.errors.every(
      (error) =>
        isRecord(error) &&
        hasExactKeys(error, compatibilityErrorKeys) &&
        isEnum(error.code, compatibilityErrorCodes),
    ) ||
    !isRecord(value.summary) ||
    !hasExactKeys(value.summary, compatibilitySummaryKeys) ||
    !isInteger(value.summary.template_duration_ms) ||
    value.summary.template_duration_ms < 0 ||
    !isInteger(value.summary.export_duration_us) ||
    value.summary.export_duration_us < 0 ||
    !isInteger(value.summary.template_slot_count) ||
    value.summary.template_slot_count < 0 ||
    !isInteger(value.summary.export_slot_count) ||
    value.summary.export_slot_count < 0 ||
    typeof value.integrity_sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.integrity_sha256)
  ) {
    return false
  }
  const { integrity_sha256: _integrity, ...payload } = value
  return value.ready === (value.errors.length === 0) && value.integrity_sha256 === sha256(payload)
}

/** @param {unknown} value */
const isExportRequestRef = (value) =>
  isRecord(value) &&
  hasExactKeys(value, exportRequestRefKeys) &&
  value.schema_version === 1 &&
  value.kind === 'jianying_draft_export_request_ref' &&
  value.request_schema_version === 1 &&
  isSafeIdentifier(value.preparation_id) &&
  isSafeIdentifier(value.source_plan_id) &&
  typeof value.export_request_digest === 'string' &&
  /^[a-f0-9]{64}$/u.test(value.export_request_digest)

/** @param {unknown} value */
const isApprovalRef = (value) =>
  isRecord(value) &&
  hasExactKeys(value, approvalRefKeys) &&
  value.schema_version === 1 &&
  value.kind === 'reference_template_review_decision_ref' &&
  value.decision_schema_version === 1 &&
  isSafeIdentifier(value.draft_id) &&
  value.decision === 'approved' &&
  typeof value.decision_integrity_sha256 === 'string' &&
  /^[a-f0-9]{64}$/u.test(value.decision_integrity_sha256)

/** @param {unknown} value */
const isTemplateRef = (value) =>
  isRecord(value) &&
  hasExactKeys(value, confirmedTemplateRefKeys) &&
  value.schema_version === 1 &&
  value.kind === 'confirmed_reference_template_ref' &&
  value.template_schema_version === 1 &&
  isSafeIdentifier(value.source_draft_id) &&
  isSafeIdentifier(value.confirmed_template_id) &&
  typeof value.template_integrity_sha256 === 'string' &&
  /^[a-f0-9]{64}$/u.test(value.template_integrity_sha256)

/** @param {{ code: string }[]} errors @param {{ template_duration_ms: number, export_duration_us: number, template_slot_count: number, export_slot_count: number }} summary */
const createCompatibilityReport = (errors, summary) => {
  const payload = {
    schema_version: 1,
    kind: 'jianying_template_compatibility_report',
    ready: errors.length === 0,
    errors,
    summary,
  }
  return { ...payload, integrity_sha256: sha256(payload) }
}

/**
 * @param {unknown} orientation
 * @param {unknown[]} observedTransitions
 * @param {Record<string, unknown>} captionCadence
 * @param {unknown[]} audioEmphasis
 * @param {{ template_duration_ms: number, export_duration_us: number, template_slot_count: number, export_slot_count: number }} summary
 */
const deriveCompatibilityErrors = (
  orientation,
  observedTransitions,
  captionCadence,
  audioEmphasis,
  summary,
) => {
  const errors = [{ code: 'TPL002_UNSUPPORTED_ORIENTATION' }]
  if (observedTransitions.some((transition) => transition !== 'none')) {
    errors.push({ code: 'TPL002_UNSUPPORTED_TRANSITION' })
  }
  if (captionCadence.mode !== 'none') {
    errors.push({ code: 'TPL002_UNSUPPORTED_CAPTION_CADENCE' })
  }
  if (audioEmphasis.length > 0) {
    errors.push({ code: 'TPL002_UNSUPPORTED_AUDIO_EMPHASIS' })
  }
  if (summary.template_duration_ms * 1_000 !== summary.export_duration_us) {
    errors.push({ code: 'TPL002_DURATION_MISMATCH' })
  }
  if (summary.template_slot_count !== summary.export_slot_count) {
    errors.push({ code: 'TPL002_SLOT_COUNT_MISMATCH' })
  }
  return errors
}

/** @param {Record<string, unknown>} template @param {Record<string, unknown>} exportRequest */
const buildCompatibilityReport = (template, exportRequest) => {
  const preparation = /** @type {Record<string, unknown>} */ (exportRequest.preparation)
  const timeline = /** @type {Record<string, unknown>} */ (preparation.timeline)
  const tracks = /** @type {Record<string, unknown>[]} */ (timeline.tracks)
  const videoSegments = /** @type {unknown[]} */ (tracks[0].segments)
  const slots = /** @type {Record<string, unknown>[]} */ (template.slots)
  const rules = /** @type {Record<string, unknown>} */ (template.rules)
  const captionCadence = /** @type {Record<string, unknown>} */ (rules.caption_cadence)
  const audioEmphasis = /** @type {unknown[]} */ (rules.audio_emphasis)
  const summary = {
    template_duration_ms: Number(template.target_duration_ms),
    export_duration_us: Number(timeline.duration),
    template_slot_count: slots.length,
    export_slot_count: videoSegments.length,
  }
  return createCompatibilityReport(
    deriveCompatibilityErrors(
      template.orientation,
      slots.map((slot) => slot.transition_out),
      captionCadence,
      audioEmphasis,
      summary,
    ),
    summary,
  )
}

/** @param {unknown} editPlan @param {unknown} exportRequest @param {unknown} templateDraft @param {unknown} confirmedTemplate */
export const preflightJianyingTemplateCompatibility = (
  editPlan,
  exportRequest,
  templateDraft,
  confirmedTemplate,
) => {
  if (!isJianyingDraftExportRequest(editPlan, exportRequest)) {
    return createCompatibilityReport(
      [{ code: 'TPL002_EXPORT_REQUEST_INVALID' }],
      {
        template_duration_ms: 0,
        export_duration_us: 0,
        template_slot_count: 0,
        export_slot_count: 0,
      },
    )
  }
  if (!isReferenceTemplateDraft(templateDraft) || !isRecord(confirmedTemplate)) {
    return createCompatibilityReport(
      [{ code: 'TPL002_TEMPLATE_NOT_APPROVED' }],
      {
        template_duration_ms: 0,
        export_duration_us: 0,
        template_slot_count: 0,
        export_slot_count: 0,
      },
    )
  }
  if (!isConfirmedReferenceTemplate(templateDraft, confirmedTemplate)) {
    return createCompatibilityReport(
      [{ code: 'TPL002_TEMPLATE_INTEGRITY_MISMATCH' }],
      {
        template_duration_ms: 0,
        export_duration_us: 0,
        template_slot_count: 0,
        export_slot_count: 0,
      },
    )
  }
  const exportRecord = /** @type {Record<string, unknown>} */ (exportRequest)
  const preparation = /** @type {Record<string, unknown>} */ (exportRecord.preparation)
  const timeline = /** @type {Record<string, unknown>} */ (preparation.timeline)
  const tracks = /** @type {Record<string, unknown>[]} */ (timeline.tracks)
  const videoSegments = /** @type {unknown[]} */ (tracks[0].segments)
  const template = /** @type {Record<string, unknown>} */ (confirmedTemplate)
  const slots = /** @type {unknown[]} */ (template.slots)
  if (template.project_id !== preparation.project_id) {
    return createCompatibilityReport(
      [{ code: 'TPL002_PROJECT_MISMATCH' }],
      {
        template_duration_ms: Number(template.target_duration_ms),
        export_duration_us: Number(timeline.duration),
        template_slot_count: slots.length,
        export_slot_count: videoSegments.length,
      },
    )
  }
  return buildCompatibilityReport(template, exportRecord)
}

/** @param {unknown} report */
const assertValidCompatibilityReport = (report) => {
  if (!isCompatibilityReport(report)) {
    throw new ReferenceTemplateContractError('invalid_jianying_template_compatibility_report')
  }
}

/** @param {unknown} editPlan @param {unknown} exportRequest @param {unknown} templateDraft @param {unknown} confirmedTemplate @param {unknown} reviewDecision */
export const createJianyingTemplateAdapterEnvelope = (
  editPlan,
  exportRequest,
  templateDraft,
  confirmedTemplate,
  reviewDecision,
) => {
  if (!isJianyingDraftExportRequest(editPlan, exportRequest)) {
    throw new ReferenceTemplateContractError('TPL002_EXPORT_REQUEST_INVALID')
  }
  if (!isReferenceTemplateDraft(templateDraft) || !isRecord(confirmedTemplate)) {
    throw new ReferenceTemplateContractError('TPL002_TEMPLATE_NOT_APPROVED')
  }
  if (!isConfirmedReferenceTemplate(templateDraft, confirmedTemplate)) {
    throw new ReferenceTemplateContractError('TPL002_TEMPLATE_INTEGRITY_MISMATCH')
  }
  if (!isReferenceTemplateReviewDecision(templateDraft, reviewDecision)) {
    throw new ReferenceTemplateContractError('TPL002_TEMPLATE_NOT_APPROVED')
  }
  const review = /** @type {Record<string, unknown>} */ (reviewDecision)
  if (
    review.decision !== 'approved' ||
    !isConfirmedReferenceTemplate(templateDraft, review.confirmed_template) ||
    !valuesEqual(review.confirmed_template, confirmedTemplate)
  ) {
    throw new ReferenceTemplateContractError('TPL002_TEMPLATE_NOT_APPROVED')
  }
  const template = /** @type {Record<string, unknown>} */ (confirmedTemplate)
  const request = /** @type {Record<string, unknown>} */ (exportRequest)
  const preparation = /** @type {Record<string, unknown>} */ (request.preparation)
  const slots = /** @type {Record<string, unknown>[]} */ (template.slots)
  const rules = /** @type {Record<string, unknown>} */ (template.rules)
  if (template.project_id !== preparation.project_id) {
    throw new ReferenceTemplateContractError('TPL002_PROJECT_MISMATCH')
  }
  const templateRef = {
    schema_version: 1,
    kind: 'confirmed_reference_template_ref',
    template_schema_version: template.schema_version,
    source_draft_id: template.source_draft_id,
    confirmed_template_id: template.confirmed_template_id,
    template_integrity_sha256: template.integrity_sha256,
  }
  const exportRequestRef = {
    schema_version: 1,
    kind: 'jianying_draft_export_request_ref',
    request_schema_version: request.schema_version,
    preparation_id: preparation.preparation_id,
    source_plan_id: preparation.source_plan_id,
    export_request_digest: sha256(request),
  }
  const approvalRef = {
    schema_version: 1,
    kind: 'reference_template_review_decision_ref',
    decision_schema_version: review.schema_version,
    draft_id: review.draft_id,
    decision: review.decision,
    decision_integrity_sha256: review.integrity_sha256,
  }
  const compatibility = preflightJianyingTemplateCompatibility(
    editPlan,
    request,
    templateDraft,
    template,
  )
  assertValidCompatibilityReport(compatibility)
  const envelopePayload = {
    schema_version: 1,
    kind: 'jianying_template_adapter_envelope',
     envelope_id: `jy002-envelope-${sha256({ project_id: template.project_id, template_ref: templateRef, export_request_ref: exportRequestRef, approval_ref: approvalRef }).slice(0, 24)}`,
     project_id: template.project_id,
     template_ref: templateRef,
     export_request_ref: exportRequestRef,
     approval_ref: approvalRef,
    reference_provenance: clone(template.reference_provenance),
    capability_matrix: clone(capabilityMatrix),
    executable: {
      slot_timing: {
        target_duration_ms: template.target_duration_ms,
        slots: clone(slots),
      },
    },
    observation_only: {
      orientation: template.orientation,
      transitions: slots.map((slot) => slot.transition_out),
      caption_cadence: clone(rules.caption_cadence),
      audio_emphasis: clone(rules.audio_emphasis),
    },
    compatibility,
  }
  const envelope = { ...envelopePayload, integrity_sha256: sha256(envelopePayload) }
  if (!isJianyingTemplateAdapterEnvelope(envelope)) {
    throw new ReferenceTemplateContractError('invalid_jianying_template_adapter_envelope')
  }
  return envelope
}

/**
 * Validates the envelope's exact shape and self-contained hashes only.
 * Cross-boundary consumers must use isJianyingTemplateAdapterEnvelopeAuthentic
 * with the original approved decision, confirmed template, and JY-001 request.
 * @param {unknown} value
 * @returns {value is Record<string, unknown>}
 */
export const isJianyingTemplateAdapterEnvelope = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, envelopeKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'jianying_template_adapter_envelope' ||
    !isSafeIdentifier(value.envelope_id) ||
    !isSafeIdentifier(value.project_id) ||
    !isTemplateRef(value.template_ref) ||
    !isExportRequestRef(value.export_request_ref) ||
    !isApprovalRef(value.approval_ref) ||
    !isReferenceProvenance(value.reference_provenance) ||
    !isCapabilityMatrix(value.capability_matrix) ||
    !isRecord(value.executable) ||
    !hasExactKeys(value.executable, ['slot_timing']) ||
    !isRecord(value.executable.slot_timing) ||
    !hasExactKeys(value.executable.slot_timing, ['target_duration_ms', 'slots']) ||
    !isInteger(value.executable.slot_timing.target_duration_ms) ||
    !isSlots(value.executable.slot_timing.slots, value.executable.slot_timing.target_duration_ms) ||
    !isRecord(value.observation_only) ||
    !hasExactKeys(value.observation_only, ['orientation', 'transitions', 'caption_cadence', 'audio_emphasis']) ||
    !isEnum(value.observation_only.orientation, orientations) ||
    !isEnumArray(value.observation_only.transitions, transitions) ||
    !isCaptionCadence(value.observation_only.caption_cadence) ||
    !isNormalizedEmphasis(value.observation_only.audio_emphasis) ||
    !isCompatibilityReport(value.compatibility) ||
    typeof value.integrity_sha256 !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.integrity_sha256)
  ) {
    return false
  }
  const templateRef = /** @type {Record<string, unknown>} */ (value.template_ref)
  const exportRef = /** @type {Record<string, unknown>} */ (value.export_request_ref)
  const approvalRef = /** @type {Record<string, unknown>} */ (value.approval_ref)
  const executable = /** @type {Record<string, unknown>} */ (value.executable)
  const slotTiming = /** @type {Record<string, unknown>} */ (executable.slot_timing)
  const executableSlots = /** @type {Record<string, unknown>[]} */ (slotTiming.slots)
  const observationOnly = /** @type {Record<string, unknown>} */ (value.observation_only)
  const observedTransitions = /** @type {unknown[]} */ (observationOnly.transitions)
  const compatibility = /** @type {Record<string, unknown>} */ (value.compatibility)
  const compatibilitySummary = /** @type {Record<string, unknown>} */ (compatibility.summary)
  const compatibilityErrors = /** @type {Record<string, unknown>[]} */ (compatibility.errors)
  const expectedErrors = deriveCompatibilityErrors(
    observationOnly.orientation,
    observedTransitions,
    /** @type {Record<string, unknown>} */ (observationOnly.caption_cadence),
    /** @type {unknown[]} */ (observationOnly.audio_emphasis),
    {
      template_duration_ms: Number(compatibilitySummary.template_duration_ms),
      export_duration_us: Number(compatibilitySummary.export_duration_us),
      template_slot_count: Number(compatibilitySummary.template_slot_count),
      export_slot_count: Number(compatibilitySummary.export_slot_count),
    },
  )
  const expectedEnvelopeId = `jy002-envelope-${sha256({ project_id: value.project_id, template_ref: value.template_ref, export_request_ref: value.export_request_ref, approval_ref: value.approval_ref }).slice(0, 24)}`
  const { integrity_sha256: _integrity, ...payload } = value
  return (
    value.envelope_id === expectedEnvelopeId &&
    templateRef.template_schema_version === 1 &&
    exportRef.request_schema_version === 1 &&
    approvalRef.decision_schema_version === 1 &&
    approvalRef.decision === 'approved' &&
    approvalRef.draft_id === templateRef.source_draft_id &&
    compatibilitySummary.template_duration_ms === slotTiming.target_duration_ms &&
    compatibilitySummary.template_slot_count === executableSlots.length &&
    compatibilityErrors.length === expectedErrors.length &&
    compatibilityErrors.every((error, index) => error.code === expectedErrors[index].code) &&
    observedTransitions.length === executableSlots.length &&
    observedTransitions.every(
      (transition, index) => transition === executableSlots[index].transition_out,
    ) &&
    value.integrity_sha256 === sha256(payload)
  )
}

/**
 * @param {unknown} value
 * @param {unknown} editPlan
 * @param {unknown} exportRequest
 * @param {unknown} templateDraft
 * @param {unknown} confirmedTemplate
 * @param {unknown} reviewDecision
 */
export const isJianyingTemplateAdapterEnvelopeAuthentic = (
  value,
  editPlan,
  exportRequest,
  templateDraft,
  confirmedTemplate,
  reviewDecision,
) => {
  if (!isJianyingTemplateAdapterEnvelope(value)) return false
  if (!isJianyingDraftExportRequest(editPlan, exportRequest)) return false
  if (!isReferenceTemplateDraft(templateDraft)) return false
  if (!isConfirmedReferenceTemplate(templateDraft, confirmedTemplate)) return false
  if (!isReferenceTemplateReviewDecision(templateDraft, reviewDecision)) return false
  try {
    return valuesEqual(
      value,
      createJianyingTemplateAdapterEnvelope(
        editPlan,
        exportRequest,
        templateDraft,
        confirmedTemplate,
        reviewDecision,
      ),
    )
  } catch {
    return false
  }
}

/**
 * @param {unknown} value
 * @param {unknown} editPlan
 * @param {unknown} exportRequest
 * @param {unknown} templateDraft
 * @param {unknown} confirmedTemplate
 * @param {unknown} reviewDecision
 */
export const isJianyingTemplateAdapterEnvelopeReady = (
  value,
  editPlan,
  exportRequest,
  templateDraft,
  confirmedTemplate,
  reviewDecision,
) =>
  isJianyingTemplateAdapterEnvelopeAuthentic(
    value,
    editPlan,
    exportRequest,
    templateDraft,
    confirmedTemplate,
    reviewDecision,
  ) &&
  /** @type {Record<string, unknown>} */ (
    /** @type {Record<string, unknown>} */ (value).compatibility
  ).ready === true

/**
 * @param {unknown} value
 * @param {unknown} editPlan
 * @param {unknown} exportRequest
 * @param {unknown} templateDraft
 * @param {unknown} confirmedTemplate
 * @param {unknown} reviewDecision
 */
export const assertJianyingTemplateAdapterEnvelopeReady = (
  value,
  editPlan,
  exportRequest,
  templateDraft,
  confirmedTemplate,
  reviewDecision,
) => {
  if (
    !isJianyingTemplateAdapterEnvelopeAuthentic(
      value,
      editPlan,
      exportRequest,
      templateDraft,
      confirmedTemplate,
      reviewDecision,
    )
  ) {
    throw new ReferenceTemplateContractError('invalid_jianying_template_adapter_envelope')
  }
  const compatibility = /** @type {Record<string, unknown>} */ (
    /** @type {Record<string, unknown>} */ (value).compatibility
  )
  if (compatibility.ready !== true) {
    throw new ReferenceTemplateContractError('TPL002_COMPATIBILITY_NOT_READY')
  }
}

/**
 * @param {unknown} selectionRequest
 * @param {unknown} adapterRequest
 * @param {unknown} analysis
 * @param {unknown} draft
 * @param {unknown} preflight
 * @param {unknown} command
 */
export const createReferenceTemplateReviewDecision = (
  selectionRequest,
  adapterRequest,
  analysis,
  draft,
  preflight,
  command,
) => {
  if (!isReferenceTemplateDraft(draft)) {
    throw new ReferenceTemplateContractError('invalid_reference_template_draft')
  }
  const canonicalPreflight = preflightReferenceTemplateDraft(
    selectionRequest,
    adapterRequest,
    analysis,
    draft,
  )
  if (!valuesEqual(preflight, canonicalPreflight)) {
    throw new ReferenceTemplateContractError('template_preflight_mismatch')
  }
  if (canonicalPreflight.ready !== true) {
    throw new ReferenceTemplateContractError('template_preflight_not_ready')
  }
  const draftRecord = /** @type {Record<string, unknown>} */ (draft)
  const slots = /** @type {Record<string, unknown>[]} */ (draftRecord.slots)
  const slotIds = slots.map((slot) => String(slot.slot_id))
  if (!isReviewCommand(command, slotIds)) {
    throw new ReferenceTemplateContractError('invalid_template_review_command')
  }
  const reviewCommand = /** @type {Record<string, unknown>} */ (command)
  if (reviewCommand.decision === 'revise') {
    buildRevisedDraft(
      draftRecord,
      /** @type {Record<string, unknown>} */ (reviewCommand.revision),
      /** @type {string[]} */ (reviewCommand.reason_codes),
    )
  }
  const decision =
    reviewCommand.decision === 'approve'
      ? 'approved'
      : reviewCommand.decision === 'reject'
        ? 'rejected'
        : 'revision_required'
  const payload = {
    schema_version: 1,
    kind: 'reference_template_review_decision',
    draft_id: draftRecord.draft_id,
    decision,
    reason_codes: clone(reviewCommand.reason_codes),
    confirmed_template: decision === 'approved' ? buildConfirmedTemplate(draftRecord) : null,
    revision_request: decision === 'revision_required' ? clone(reviewCommand.revision) : null,
  }
  const reviewDecision = { ...payload, integrity_sha256: sha256(payload) }
  if (!isReferenceTemplateReviewDecision(draft, reviewDecision)) {
    throw new ReferenceTemplateContractError('invalid_template_review_decision')
  }
  return reviewDecision
}

/** @param {unknown} draft @param {unknown} reviewDecision */
export const createRevisedReferenceTemplateDraft = (draft, reviewDecision) => {
  if (!isReferenceTemplateDraft(draft)) {
    throw new ReferenceTemplateContractError('invalid_reference_template_draft')
  }
  if (!isReferenceTemplateReviewDecision(draft, reviewDecision)) {
    throw new ReferenceTemplateContractError('invalid_template_review_decision')
  }
  const draftRecord = /** @type {Record<string, unknown>} */ (draft)
  const decision = /** @type {Record<string, unknown>} */ (reviewDecision)
  const currentRevision = /** @type {Record<string, unknown>} */ (draftRecord.revision)
  if (currentRevision.number !== 0) {
    throw new ReferenceTemplateContractError('template_revision_limit_reached')
  }
  if (
    decision.decision !== 'revision_required' ||
    decision.draft_id !== draftRecord.draft_id ||
    !isRecord(decision.revision_request) ||
    !isDenseArray(decision.reason_codes)
  ) {
    throw new ReferenceTemplateContractError('revision_decision_mismatch')
  }
  const revision = buildRevisedDraft(
    draftRecord,
    decision.revision_request,
    /** @type {string[]} */ (decision.reason_codes),
  )
  if (!isReferenceTemplateDraft(revision)) {
    throw new ReferenceTemplateContractError('invalid_revised_template_draft')
  }
  return revision
}
