import { createHash } from 'node:crypto'

import { buildPackagingResourceIntent } from './brief-packaging.mjs'
import { createPackagingBindingQualificationAuthority } from './jianying-packaging-binding-resolver.mjs'
import { createPackagingRecommendationProvider } from './jianying-packaging-recommendation-provider.mjs'
import {
  assertPackagingWriterBinding,
  computePackagingResourceToken,
  isAdmittedPackagingEntry,
} from './jianying-packaging-resource-index.mjs'
import {
  projectCapCutDirectIdBinding,
} from './jianying-capcut-direct-id.mjs'

const supportedFamilies = new Set(['flower', 'sticker', 'video_effect'])
const identityKeysByFamily = Object.freeze({
  flower: new Set(['effectid', 'resourceid', 'templateid']),
  sticker: new Set(['resourceid', 'stickerid']),
  video_effect: new Set(['effectid', 'resourceid']),
})

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @returns {unknown} */
const sortJson = (value) => {
  if (Array.isArray(value)) return value.map(sortJson)
  if (!isRecord(value)) return value
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, sortJson(value[key])]))
}
/** @param {unknown} value @returns {string} */
const fingerprint = (value) => createHash('sha256').update(JSON.stringify(sortJson(value))).digest('hex')
/** @param {string} value @returns {string} */
const normalizeKey = (value) => value.replaceAll('_', '').replaceAll('-', '').toLowerCase()
const hex64 = /^[a-f0-9]{64}$/u

/**
 * The ordinary Direct-ID path only needs a Gateway-owned structural readback.
 * Jianying may resolve the referenced resource later when the user opens the
 * draft, but export must not depend on that desktop lifecycle. Keep this
 * probe deliberately narrow: it validates the writer binding shape and
 * fingerprints the exact projected payload without contacting any remote API.
 * @param {Record<string, any>} input
 * @returns {Promise<{passed: true, readbackKind: 'static_json', readbackFingerprint: string}>}
 */
export const defaultDirectIdProbe = async (input) => {
  const family = typeof input?.family === 'string' ? input.family : null
  const privateBinding = isRecord(input?.privateBinding) ? input.privateBinding : null
  if (!family || !privateBinding) throw new Error('DIRECT_ID_BINDING_INVALID')
  const binding = assertPackagingWriterBinding(family, privateBinding)
  return {
    passed: true,
    readbackKind: 'static_json',
    readbackFingerprint: fingerprint({ schema_version: 1, family, private_binding: binding }),
  }
}

/** Convert importer-private identity components to the narrow Writer binding. */
/** @param {Record<string, any>} sourceEntry */
export const projectDirectIdBinding = projectCapCutDirectIdBinding

/** @param {unknown} value @param {Set<string>} keys @param {Set<string>} output */
const collectIdentityValues = (value, keys, output) => {
  if (Array.isArray(value)) {
    for (const child of value) collectIdentityValues(child, keys, output)
    return
  }
  if (!isRecord(value)) return
  for (const [key, child] of Object.entries(value)) {
    if (keys.has(normalizeKey(key)) && (typeof child === 'string' || typeof child === 'number')) {
      output.add(String(child))
    }
    collectIdentityValues(child, keys, output)
  }
}

/** @param {Record<string, any>} sourceEntry @param {Record<string, any>} snapshot */
export const exactNativeEntry = (sourceEntry, snapshot) => {
  const rawIdentity = sourceEntry.private_binding?.raw_identity
  const keys = identityKeysByFamily[/** @type {keyof typeof identityKeysByFamily} */ (sourceEntry.family)]
  if ((typeof rawIdentity !== 'string' && typeof rawIdentity !== 'number') || !keys ||
      !Array.isArray(snapshot.packagingIndex?.entries)) return null
  const sourceComponents = sourceEntry.private_binding?.raw_identity_components
  const isVideoEffect = sourceEntry.family === 'video_effect'
  const sourceEntity = sourceEntry.private_binding?.entity
  const sourceResourceId = isRecord(sourceComponents) ? sourceComponents.resource_id : null
  const sourceEffectId = isRecord(sourceComponents) ? sourceComponents.effect_id : null
  if (isVideoEffect && (!['scene', 'character'].includes(sourceEntity) ||
      typeof sourceResourceId !== 'string' || typeof sourceEffectId !== 'string')) return null
  const matches = snapshot.packagingIndex.entries.filter((/** @type {unknown} */ entry) => {
    if (!isRecord(entry) || entry.family !== sourceEntry.family || entry.state !== 'writer_eligible' ||
        entry.writer_eligible !== true || !isRecord(entry.private_binding)) return false
    if (isVideoEffect) {
      return entry.private_binding.resourceId === sourceResourceId &&
        entry.private_binding.effectId === sourceEffectId &&
        entry.private_binding.entity === sourceEntity
    }
    const values = new Set()
    collectIdentityValues(entry.private_binding, keys, values)
    return values.has(String(rawIdentity))
  })
  return matches.length === 1 ? matches[0] : null
}

/** @param {unknown} snapshot @returns {snapshot is Record<string, any>} */
const validNativeSnapshot = (snapshot) => {
  if (!isRecord(snapshot)) return false
  return snapshot.ready === true &&
    typeof snapshot.profileId === 'string' && typeof snapshot.appVersion === 'string' &&
    typeof snapshot.catalogFingerprint === 'string' && /^[a-f0-9]{64}$/u.test(snapshot.catalogFingerprint) &&
    isRecord(snapshot.packagingIndex) && snapshot.packagingIndex.profileId === snapshot.profileId &&
    snapshot.packagingIndex.appVersion === snapshot.appVersion &&
    snapshot.packagingIndex.catalogFingerprint === snapshot.catalogFingerprint &&
    snapshot.packagingIndex.catalogRevisionToken === `ovjcatalog_v1_${snapshot.catalogFingerprint.slice(0, 24)}`
}

/** Discovery-only CapCut catalogs can qualify Direct-ID per request without
 * durable Native writer rows.
 * @param {unknown} snapshot
 * @returns {snapshot is Record<string, any>}
 */
const validCatalogSnapshot = (snapshot) => {
  if (!isRecord(snapshot) || (snapshot.catalogAvailable !== true && snapshot.ready !== true)) return false
  return typeof snapshot.profileId === 'string' && typeof snapshot.appVersion === 'string' &&
    typeof snapshot.catalogFingerprint === 'string' && hex64.test(snapshot.catalogFingerprint) &&
    isRecord(snapshot.packagingIndex) && snapshot.packagingIndex.profileId === snapshot.profileId &&
    snapshot.packagingIndex.appVersion === snapshot.appVersion &&
    snapshot.packagingIndex.catalogFingerprint === snapshot.catalogFingerprint &&
    snapshot.packagingIndex.catalogRevisionToken === `ovjcatalog_v1_${snapshot.catalogFingerprint.slice(0, 24)}`
}

/**
 * Rebuild the exact request-scoped Writer index from opaque RichTimeline
 * selections. Native entries are reused; Direct-ID entries are re-read from
 * the current private CapCut release and structurally probed again.
 * @param {{
 *   capCutCatalogService: {resolvePrivateWriterCandidates: Function},
 *   nativeSnapshotResolver: () => Promise<Record<string, any> | null>,
 *   detectDesktop: () => Promise<Record<string, any>>,
 *   directIdProbe?: ((input: Record<string, any>) => Promise<Record<string, any> | null> | Record<string, any> | null) | null,
 * }} input
 */
export const createCapCutCatalogPackagingExportSnapshotResolver = ({
  capCutCatalogService,
  nativeSnapshotResolver,
  detectDesktop,
  directIdProbe = defaultDirectIdProbe,
}) => async (/** @type {{packagingTokens?: unknown}} */ input = {}) => {
  const { packagingTokens = [] } = input
  const snapshot = await nativeSnapshotResolver().catch(() => null)
  if (!validCatalogSnapshot(snapshot)) return null
  if (!Array.isArray(packagingTokens) || packagingTokens.length > 24 ||
      packagingTokens.some((token) => typeof token !== 'string') ||
      new Set(packagingTokens).size !== packagingTokens.length) return null
  if (packagingTokens.length === 0) return snapshot

  const nativeTokens = new Set(snapshot.packagingIndex.entries
    .filter(isAdmittedPackagingEntry)
    .map((/** @type {Record<string, any>} */ entry) => entry.packaging_token))
  const missingTokens = packagingTokens.filter((token) => !nativeTokens.has(token))
  if (missingTokens.length === 0) return snapshot
  if (typeof capCutCatalogService?.resolvePrivateWriterCandidates !== 'function' || typeof directIdProbe !== 'function') return null

  const desktop = await detectDesktop().catch(() => null)
  if (!isRecord(desktop) || desktop.available !== true || desktop.profileId !== snapshot.profileId ||
      desktop.version !== snapshot.appVersion) return null
  const directEntries = await capCutCatalogService.resolvePrivateWriterCandidates({
    packagingTokens: missingTokens,
    profileId: snapshot.profileId,
    appVersion: snapshot.appVersion,
  }).catch(() => null)
  if (!Array.isArray(directEntries) || directEntries.length !== missingTokens.length) return null
  const directByToken = new Map(directEntries.map((entry) => [entry?.packaging_token, entry]))
  if (directByToken.size !== missingTokens.length || missingTokens.some((token) => !directByToken.has(token))) return null

  for (const token of missingTokens) {
    const entry = directByToken.get(token)
    if (!isRecord(entry)) return null
    let privateBinding = null
    try { privateBinding = assertPackagingWriterBinding(entry.family, entry.private_binding) } catch { return null }
    const result = await Promise.resolve(directIdProbe({
      family: entry.family,
      privateBinding: structuredClone(privateBinding),
      catalog: {
        profileId: snapshot.profileId,
        appVersion: snapshot.appVersion,
        catalogFingerprint: snapshot.catalogFingerprint,
      },
      desktop: structuredClone(desktop),
      signal: null,
    })).catch(() => null)
    if (!isRecord(result) || result.passed !== true || !hex64.test(result.readbackFingerprint ?? '') ||
        (result.readbackKind !== undefined && result.readbackKind !== 'static_json' && result.readbackKind !== 'jianying_resolved')) return null
  }

  return Object.freeze({
    ...snapshot,
    packagingIndex: Object.freeze({
      ...snapshot.packagingIndex,
      entries: Object.freeze([
        ...snapshot.packagingIndex.entries,
        ...missingTokens.map((token) => directByToken.get(token)),
      ]),
    }),
  })
}

/**
 * CapCut Mate remains a sharded discovery source. Only a bounded Top-N view is
 * materialized, and every selected row must map uniquely to an already-current
 * Native admitted binding before its existing opaque token can reach RichTimeline.
 * @param {{
 *   capCutCatalogService: {search: Function, resolvePrivateCandidate: Function, resolvePrivateCandidates?: Function},
 *   nativeSnapshotResolver: () => Promise<Record<string, any> | null>,
 *   detectDesktop: () => Promise<Record<string, any>>,
 *   ranker?: ((input: Record<string, any>) => unknown) | null,
 *   directIdProbe?: ((input: Record<string, any>) => Promise<Record<string, any> | null> | Record<string, any> | null) | null,
 * }} input
 */
export const createCapCutCatalogPackagingProviderResolver = ({
  capCutCatalogService,
  nativeSnapshotResolver,
  detectDesktop,
  ranker = null,
  directIdProbe = defaultDirectIdProbe,
}) => {
  if (!isRecord(capCutCatalogService) || typeof capCutCatalogService.search !== 'function' ||
      typeof capCutCatalogService.resolvePrivateCandidate !== 'function' ||
      typeof nativeSnapshotResolver !== 'function' || typeof detectDesktop !== 'function') {
    return async () => null
  }
  const authority = createPackagingBindingQualificationAuthority()

  return async () => {
    const initialSnapshot = await nativeSnapshotResolver().catch(() => null)
    if (!validCatalogSnapshot(initialSnapshot)) return null
    const nativeProvider = createPackagingRecommendationProvider({
      index: initialSnapshot.packagingIndex,
      ranker,
      profileId: initialSnapshot.profileId,
      appVersion: initialSnapshot.appVersion,
    })
    if (!nativeProvider) return null

    /**
     * Recommend only while the Native snapshot identity remains current.
     * @param {{brief: unknown, editPlan: Record<string, any>, templateConstraints?: unknown, narrationSegments?: unknown, sceneCards?: unknown, excludedPackagingTokens?: unknown, signal?: AbortSignal | null}} recommendationInput
     */
    const recommendFromCurrentNative = async (recommendationInput) => {
      const before = await nativeSnapshotResolver().catch(() => null)
      if (!validCatalogSnapshot(before)) return null
      const provider = createPackagingRecommendationProvider({
        index: before.packagingIndex,
        ranker,
        profileId: before.profileId,
        appVersion: before.appVersion,
      })
      const recommendation = await provider?.recommend(recommendationInput)
      if (!recommendation) return null
      const after = await nativeSnapshotResolver().catch(() => null)
      if (!validCatalogSnapshot(after) || before.profileId !== after.profileId ||
          before.appVersion !== after.appVersion ||
          before.catalogFingerprint !== after.catalogFingerprint) return null
      return recommendation
    }

    /** @param {Record<string, any>} entry @param {Record<string, any>} catalog @param {AbortSignal | null} signal */
    const observeExactCurrentBinding = async (entry, catalog, signal) => {
      signal?.throwIfAborted()
      const sourceToken = entry.source_packaging_token
      const currentSource = typeof sourceToken === 'string'
        ? await capCutCatalogService.resolvePrivateCandidate(sourceToken).catch(() => null)
        : null
      if (!isRecord(currentSource) || currentSource.family !== entry.family ||
          fingerprint(currentSource.private_binding) !== fingerprint(entry.private_binding)) return null
      const [snapshot, desktop] = await Promise.all([
        nativeSnapshotResolver().catch(() => null),
        detectDesktop().catch(() => null),
      ])
      if (!validCatalogSnapshot(snapshot) || !isRecord(desktop) || desktop.available !== true ||
          snapshot.profileId !== catalog.profileId || snapshot.appVersion !== catalog.appVersion ||
          snapshot.catalogFingerprint !== catalog.catalogFingerprint ||
          desktop.profileId !== snapshot.profileId || desktop.version !== snapshot.appVersion) return null
      const nativeEntry = exactNativeEntry(entry, snapshot)
      if (!nativeEntry) return null
      return { currentSource, desktop, nativeEntry, snapshot }
    }

    /** @param {{entry: Record<string, any>, catalog: Record<string, any>, signal: AbortSignal | null}} input */
    const qualifyCandidate = async ({ entry, catalog, signal }) => {
      const directBinding = entry.resource_mode === 'direct_id'
        ? (() => {
            try { return assertPackagingWriterBinding(entry.family, entry.private_binding) } catch { return null }
          })()
        : null
      const observeDirect = async () => {
        signal?.throwIfAborted()
        const currentSource = typeof entry.source_packaging_token === 'string'
          ? await capCutCatalogService.resolvePrivateCandidate(entry.source_packaging_token).catch(() => null)
          : null
        if (!isRecord(currentSource) || currentSource.family !== entry.family ||
            fingerprint(currentSource.private_binding) !== entry.source_private_binding_fingerprint) return null
        const [snapshot, desktop] = await Promise.all([
          nativeSnapshotResolver().catch(() => null),
          detectDesktop().catch(() => null),
        ])
        if (!validCatalogSnapshot(snapshot) || !isRecord(desktop) || desktop.available !== true ||
            snapshot.profileId !== catalog.profileId || snapshot.appVersion !== catalog.appVersion ||
            snapshot.catalogFingerprint !== catalog.catalogFingerprint ||
            desktop.profileId !== snapshot.profileId || desktop.version !== snapshot.appVersion) return null
        return { currentSource, snapshot, desktop }
      }
      const observed = directBinding ? await observeDirect() : await observeExactCurrentBinding(entry, catalog, signal)
      if (!observed) throw new Error('PACKAGING_BINDING_ENTITY_UNAVAILABLE')
      /** @type {Record<string, any> | null} */
      let phaseObservation = observed
      const observe = async () => {
        const current = phaseObservation ?? (directBinding
          ? await observeDirect()
          : await observeExactCurrentBinding(entry, catalog, signal))
        if (!current) throw new Error('PACKAGING_BINDING_ENTITY_UNAVAILABLE')
        return current
      }
      return authority.qualify({
        catalogFingerprint: catalog.catalogFingerprint,
        entry,
        desktop: {
          profileId: observed.snapshot.profileId,
          appVersion: observed.snapshot.appVersion,
          bindingFingerprint: fingerprint({
            profileId: observed.desktop.profileId,
            version: observed.desktop.version,
            dllFingerprint: observed.desktop.dllFingerprint ?? null,
            executablePath: observed.desktop.executablePath ?? null,
            installRoot: observed.desktop.installRoot ?? null,
          }),
        },
        adapter: {
          revision: directBinding ? 'capcut-mate-direct-id-v2' : 'capcut-mate-native-exact-v1',
          qualifiedFamilies: [...supportedFamilies],
          validateEntity: async () => Boolean(await observe()),
          projectBinding: async () => {
            const current = await observe()
            const projected = structuredClone(directBinding ?? /** @type {any} */ (current).nativeEntry?.private_binding ?? {})
            // projectBinding is the final qualification step. Force the
            // one-shot authority's consume pass to observe the environment,
            // entitlement, cache and probe again instead of reusing this pass.
            phaseObservation = null
            return projected
          },
        },
        inspectEntitlement: async () => {
          const current = await observe()
          return {
            available: true,
            observationFingerprint: fingerprint({
              kind: directBinding ? 'direct_id_entitlement' : 'current_admission',
              token: directBinding ? entry.packaging_token : /** @type {any} */ (current).nativeEntry?.packaging_token ?? null,
              evidence: current.snapshot.packagingEvidence ?? null,
            }),
          }
        },
        inspectCache: async () => {
          const current = await observe()
          return {
            available: true,
            observationFingerprint: fingerprint({
              kind: 'current_cache_binding',
              source: current.currentSource.private_binding,
              native: directBinding ?? /** @type {any} */ (current).nativeEntry?.private_binding ?? null,
            }),
          }
        },
        probe: async () => {
          const current = await observe()
          if (directBinding) {
            const probeFn = directIdProbe
            if (typeof probeFn !== 'function') throw new Error('PACKAGING_BINDING_PROBE_FAILED')
            const result = await /** @type {Function} */ (probeFn)({
              family: entry.family,
              privateBinding: structuredClone(directBinding),
              catalog: { profileId: catalog.profileId, appVersion: catalog.appVersion, catalogFingerprint: catalog.catalogFingerprint },
              desktop: structuredClone(/** @type {any} */ (current).desktop),
              signal,
            }).catch(() => null)
            if (!isRecord(result) || result.passed !== true || !hex64.test(result.readbackFingerprint ?? '') ||
                (result.readbackKind !== undefined && result.readbackKind !== 'static_json' && result.readbackKind !== 'jianying_resolved')) {
              throw new Error('PACKAGING_BINDING_PROBE_FAILED')
            }
            return { passed: true, receiptFingerprint: fingerprint({
              kind: 'direct_id_readback',
              readbackKind: result.readbackKind ?? 'static_json',
              readbackFingerprint: result.readbackFingerprint,
            }) }
          }
          return {
            passed: true,
            receiptFingerprint: fingerprint({
              kind: 'bounded_current_evidence_probe',
              catalogFingerprint: current.snapshot.catalogFingerprint,
              token: /** @type {any} */ (current).nativeEntry?.packaging_token ?? null,
              evidence: current.snapshot.packagingEvidence ?? null,
            }),
          }
        },
      })
    }

    return Object.freeze({
      index: nativeProvider.index,
      readiness: nativeProvider.readiness,
      qualificationMode: 'request_scoped_direct_id',
      /** @param {{brief: unknown, editPlan: Record<string, any>, templateConstraints?: unknown, narrationSegments?: unknown, sceneCards?: unknown, excludedPackagingTokens?: unknown, signal?: AbortSignal | null}} recommendationInput */
      async recommend(recommendationInput) {
        const intent = buildPackagingResourceIntent(
          isRecord(recommendationInput?.brief) ? recommendationInput.brief.packaging : null,
        )
        const families = [...new Set(intent.families.filter((family) => supportedFamilies.has(family)))]
        if (families.length === 0) return recommendFromCurrentNative(recommendationInput)
        // Search each bounded intent term independently. The catalog service
        // matches a term against a label/tag; joining terms with spaces made
        // otherwise relevant Chinese labels miss and silently fall back to
        // the first shard entries.
        const queryTerms = [...new Set(intent.queryTerms
          .filter((term) => typeof term === 'string' && term.trim())
          .map((term) => term.trim().slice(0, 120)))]
        const entriesByToken = new Map()
        const publicCandidates = []
        for (const family of families) {
          const familyCandidates = new Map()
          for (const query of queryTerms) {
            const result = await capCutCatalogService.search({ query, family, limit: 6 }).catch(() => null)
            for (const candidate of Array.isArray(result?.candidates) ? result.candidates : []) {
              if (candidate?.packagingToken && !familyCandidates.has(candidate.packagingToken)) {
                familyCandidates.set(candidate.packagingToken, candidate)
              }
              if (familyCandidates.size >= 12) break
            }
            if (familyCandidates.size >= 12) break
          }
          if (familyCandidates.size === 0) {
            const result = await capCutCatalogService.search({ query: '', family, limit: 6 }).catch(() => null)
            for (const candidate of Array.isArray(result?.candidates) ? result.candidates : []) {
              if (candidate?.packagingToken && !familyCandidates.has(candidate.packagingToken)) {
                familyCandidates.set(candidate.packagingToken, candidate)
              }
            }
          }
          publicCandidates.push(...familyCandidates.values())
        }
        const candidateTokens = publicCandidates.map((candidate) => candidate.packagingToken)
        const resolvedCandidates = candidateTokens.length > 0 && typeof capCutCatalogService.resolvePrivateCandidates === 'function'
          ? await capCutCatalogService.resolvePrivateCandidates(candidateTokens).catch(() => null)
          : null
        for (let candidateIndex = 0; candidateIndex < publicCandidates.length; candidateIndex += 1) {
            const candidate = publicCandidates[candidateIndex]
            const sourceEntry = Array.isArray(resolvedCandidates)
              ? resolvedCandidates[candidateIndex]
              : await capCutCatalogService.resolvePrivateCandidate(candidate.packagingToken).catch(() => null)
            if (!isRecord(sourceEntry) || !isRecord(sourceEntry.private_binding)) continue
            const nativeEntry = exactNativeEntry(sourceEntry, initialSnapshot)
            const directBinding = !nativeEntry && typeof directIdProbe === 'function' ? projectDirectIdBinding(sourceEntry) : null
            if (!nativeEntry && !directBinding) continue
            const packagingToken = nativeEntry?.packaging_token ?? computePackagingResourceToken({
              family: sourceEntry.family,
              profileId: initialSnapshot.profileId,
              appVersion: initialSnapshot.appVersion,
              privateBinding: /** @type {Record<string, any>} */ (directBinding),
            })
            entriesByToken.set(packagingToken, Object.freeze({
              family: sourceEntry.family,
              label: candidate.label,
              tags: Object.freeze(Array.isArray(candidate.tags) ? candidate.tags : []),
              state: 'discoverable',
              writer_eligible: false,
              packaging_token: packagingToken,
              parameter_schema: Object.freeze(isRecord(nativeEntry?.parameter_schema) ? nativeEntry.parameter_schema : {}),
              private_binding: Object.freeze(structuredClone(directBinding ?? sourceEntry.private_binding)),
              source_packaging_token: candidate.packagingToken,
              resource_mode: directBinding ? 'direct_id' : 'native_exact',
              source_private_binding_fingerprint: fingerprint(sourceEntry.private_binding),
            }))
        }
        if (entriesByToken.size > 0) {
          const discoveryIndex = Object.freeze({
            ...initialSnapshot.packagingIndex,
            entries: Object.freeze([...entriesByToken.values()]),
          })
          const provider = createPackagingRecommendationProvider({
            index: discoveryIndex,
            ranker,
            profileId: initialSnapshot.profileId,
            appVersion: initialSnapshot.appVersion,
            qualifyCandidate,
            qualificationRegistry: authority.registry,
          })
          const capCutRecommendation = await provider?.recommend(recommendationInput)
          if (capCutRecommendation) return capCutRecommendation
        }
        return recommendFromCurrentNative(recommendationInput)
      },
    })
  }
}
