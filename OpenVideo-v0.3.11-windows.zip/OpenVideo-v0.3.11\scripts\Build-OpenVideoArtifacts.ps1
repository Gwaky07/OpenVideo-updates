[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$RepositoryRoot,
    [Parameter(Mandatory = $true)][string]$RuntimeRoot,
    [Parameter(Mandatory = $true)][string]$DependencyRevision,
    [Parameter(Mandatory = $true)][string]$GatewayBuildRevision,
    [Parameter(Mandatory = $true)][string]$WebBuildRevision,
    [Parameter(Mandatory = $true)][string]$ReleaseRevision,
    [Parameter(Mandatory = $true)][string]$DependencyReceiptPath,
    [Parameter(Mandatory = $true)][string]$GatewayBuildReceiptPath,
    [Parameter(Mandatory = $true)][string]$WebBuildReceiptPath,
    [Parameter(Mandatory = $true)][string]$BuildReceiptPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = [IO.Path]::GetFullPath($RepositoryRoot).TrimEnd('\')

function Write-Receipt {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][hashtable]$Value
    )
    $directory = Split-Path -Parent $Path
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    $temporaryPath = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        $utf8 = [Text.UTF8Encoding]::new($false)
        [IO.File]::WriteAllText($temporaryPath, (($Value | ConvertTo-Json -Depth 8) + "`n"), $utf8)
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    } finally {
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
    }
}

try {
    & corepack pnpm --dir $root --filter '@openvideo/gateway' build
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_GATEWAY_BUILD_FAILED' }
    & corepack pnpm --dir $root --filter '@openvideo/gateway' build:workbench-preview
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_PREVIEW_BUILD_FAILED' }
    & corepack pnpm --dir $root --filter '@openvideo/gateway' build:tpl002
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_TEMPLATE_BUILD_FAILED' }
    & corepack pnpm --dir $root --filter '@openvideo/gateway' build:jy002
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_JIANYING_BUILD_FAILED' }
    Write-Receipt -Path $GatewayBuildReceiptPath -Value @{
        schema_version = 1
        component = 'gateway'
        component_revision = $GatewayBuildRevision
        repository_root = $root
        verified_at = [DateTimeOffset]::UtcNow.ToString('O')
    }

    $env:VITE_OPENVIDEO_HEALTH_PATH = '/api/live'
    $env:VITE_MATERIAL_ANALYSIS_HEALTH_PATH = '/api/workbench/material-analysis/status'
    $env:VITE_OPENVIDEO_WORKBENCH_PATH = '/api/workbench'
    & corepack pnpm --dir $root --filter '@openvideo/web' build
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_WEB_BUILD_FAILED' }
    Write-Receipt -Path $WebBuildReceiptPath -Value @{
        schema_version = 1
        component = 'web'
        component_revision = $WebBuildRevision
        repository_root = $root
        required_paths = @((Join-Path $root 'apps\web\dist\index.html'))
        verified_at = [DateTimeOffset]::UtcNow.ToString('O')
    }
    Write-Receipt -Path $DependencyReceiptPath -Value @{
        schema_version = 1
        dependency_revision = $DependencyRevision
        repository_root = $root
        verified_at = [DateTimeOffset]::UtcNow.ToString('O')
    }
    Write-Receipt -Path $BuildReceiptPath -Value @{
        schema_version = 1
        release_revision = $ReleaseRevision
        repository_root = $root
        verified_at = [DateTimeOffset]::UtcNow.ToString('O')
    }
    exit 0
} catch {
    Write-Error $_
    exit 1
}
