import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { copyFile, lstat, mkdir, readFile, realpath, rename, rm, writeFile } from 'node:fs/promises'
import { basename, dirname, isAbsolute, parse, relative, resolve } from 'node:path'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)
const schemaVersion = 1
const sha256Pattern = /^[a-f0-9]{64}$/u
const thumbprintPattern = /^[A-F0-9]{40,128}$/u
const versionPattern = /^6\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u
const opaqueIdPattern = /^[a-z0-9][a-z0-9._:-]{0,159}$/iu
const expectedPublisher = '深圳市脸萌科技有限公司'

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} error */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error ? String(error.code) : null
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? resolve(left).toLowerCase() === resolve(right).toLowerCase()
  : resolve(left) === resolve(right)

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * Windows realpath can return an 8.3 alias. Accept a different spelling only
 * when both names still identify the exact same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}

export class Jianying6RendererSettingsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'Jianying6RendererSettingsError'
    this.code = code
    this.status = status
  }
}

const emptyDocument = () => ({
  schema_version: schemaVersion,
  revision: null,
  enabled: false,
  selected_root: null,
  executable_path: null,
  version: null,
  executable_sha256: null,
  signer_thumbprint: null,
  confirmed_at: null,
  last_validated_at: null,
})

/** @param {unknown} value */
const validDocument = (value) => isRecord(value) &&
  value.schema_version === schemaVersion &&
  (value.revision === null || (typeof value.revision === 'string' && opaqueIdPattern.test(value.revision))) &&
  typeof value.enabled === 'boolean' &&
  (value.selected_root === null || (typeof value.selected_root === 'string' && isAbsolute(value.selected_root))) &&
  (value.executable_path === null || (typeof value.executable_path === 'string' && isAbsolute(value.executable_path))) &&
  (value.version === null || (typeof value.version === 'string' && versionPattern.test(value.version))) &&
  (value.executable_sha256 === null || (typeof value.executable_sha256 === 'string' && sha256Pattern.test(value.executable_sha256))) &&
  (value.signer_thumbprint === null || (typeof value.signer_thumbprint === 'string' && thumbprintPattern.test(value.signer_thumbprint))) &&
  (value.confirmed_at === null || (typeof value.confirmed_at === 'string' && Number.isFinite(Date.parse(value.confirmed_at)))) &&
  (value.last_validated_at === null || (typeof value.last_validated_at === 'string' && Number.isFinite(Date.parse(value.last_validated_at)))) &&
  (value.selected_root === null
    ? [value.executable_path, value.version, value.executable_sha256, value.signer_thumbprint, value.confirmed_at]
        .every((entry) => entry === null)
    : value.revision !== null && value.executable_path !== null && value.version !== null &&
      value.executable_sha256 !== null && value.signer_thumbprint !== null && value.confirmed_at !== null)

/** @param {string} path */
const readDocumentFile = async (path) => {
  const value = JSON.parse(await readFile(path, 'utf8'))
  if (!validDocument(value)) throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
  return value
}

/** @param {string} path @param {Record<string, unknown>} value @param {{backup?: boolean, assertSafe?: () => Promise<void>}} [options] */
const writeDocument = async (path, value, { backup = true, assertSafe } = {}) => {
  const temporary = `${path}.${randomUUID()}.tmp`
  await assertSafe?.()
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  await assertSafe?.()
  await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
  try {
    await assertSafe?.()
    if (backup) {
      await copyFile(path, `${path}.bak`).catch((error) => {
        if (errorCode(error) !== 'ENOENT') throw error
      })
    }
    await assertSafe?.()
    await rename(temporary, path)
    await copyFile(path, `${path}.bak`).catch(() => {})
  } finally {
    await rm(temporary, { force: true })
  }
}

/** @param {string} path @param {() => Promise<void>} [assertSafe] */
const readDocument = async (path, assertSafe) => {
  await assertSafe?.()
  try {
    return await readDocumentFile(path)
  } catch (primaryError) {
    try {
      const backup = await readDocumentFile(`${path}.bak`)
      await writeDocument(path, backup, { backup: false, assertSafe })
      return backup
    } catch (backupError) {
      if (errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') return emptyDocument()
      throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
    }
  }
}

/** @param {string} path */
const assertSafeCandidateRoot = async (path) => {
  if (!isAbsolute(path) || /^\\\\/u.test(path) || resolve(path) === parse(resolve(path)).root) {
    throw new Jianying6RendererSettingsError('JY006_PATH_INVALID')
  }
  const resolved = resolve(path)
  const [actual, resolvedMetadata] = await Promise.all([
    realpath(resolved).catch(() => null),
    lstat(resolved, { bigint: true }).catch(() => null),
  ])
  if (!actual || !resolvedMetadata || resolvedMetadata.isSymbolicLink() ||
      !await sameResolvedObject(resolved, actual, resolvedMetadata)) {
    throw new Jianying6RendererSettingsError('JY006_PATH_UNSAFE')
  }
  let cursor = resolved
  while (cursor && cursor !== parse(cursor).root) {
    const stats = await lstat(cursor).catch(() => null)
    if (!stats || stats.isSymbolicLink()) throw new Jianying6RendererSettingsError('JY006_PATH_UNSAFE')
    const parent = dirname(cursor)
    if (parent === cursor) break
    cursor = parent
  }
  return resolved
}

/** @param {string} root @param {string} child */
export const assertSafeJianying6CandidateDescendant = async (root, child) => {
  const resolvedRoot = resolve(root)
  const resolvedChild = resolve(child)
  if (!inside(resolvedRoot, resolvedChild)) throw new Jianying6RendererSettingsError('JY006_PATH_UNSAFE')
  const actualRoot = await realpath(resolvedRoot).catch(() => null)
  const actualChild = await realpath(resolvedChild).catch(() => null)
  if (!actualRoot || !actualChild || !inside(actualRoot, actualChild)) {
    throw new Jianying6RendererSettingsError('JY006_PATH_UNSAFE')
  }
  let cursor = resolvedChild
  while (inside(resolvedRoot, cursor)) {
    const stats = await lstat(cursor).catch(() => null)
    if (!stats || stats.isSymbolicLink()) throw new Jianying6RendererSettingsError('JY006_PATH_UNSAFE')
    if (cursor.toLowerCase() === resolvedRoot.toLowerCase()) break
    cursor = dirname(cursor)
  }
}

const inspectPowerShell = [
  "$ErrorActionPreference='Stop'",
  '$root=[IO.Path]::GetFullPath($env:OPENVIDEO_JY6_CANDIDATE)',
  '$dirs=@($root)',
  '$level1=@(Get-ChildItem -LiteralPath $root -Directory -Force -ErrorAction Stop | Where-Object { -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) })',
  '$dirs += $level1.FullName',
  'foreach($one in $level1){$dirs += @(Get-ChildItem -LiteralPath $one.FullName -Directory -Force -ErrorAction SilentlyContinue | Where-Object { -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) }).FullName}',
  '$valid=@()',
  'foreach($dir in @($dirs | Select-Object -Unique)){',
  "  $exe=Join-Path $dir 'JianyingPro.exe'",
  '  if(-not (Test-Path -LiteralPath $exe -PathType Leaf)){continue}',
  '  $item=Get-Item -LiteralPath $exe -Force',
  '  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){continue}',
  '  $version=[string]$item.VersionInfo.FileVersion',
  "  if($version -notmatch '^6\\.[0-9]+\\.[0-9]+(?:\\.[0-9]+)?$'){continue}",
  '  $sig=Get-AuthenticodeSignature -LiteralPath $exe',
  "  if([string]$sig.Status -ne 'Valid' -or -not $sig.SignerCertificate.Subject.Contains('深圳市脸萌科技有限公司')){continue}",
  "  $required=@('VECreator.dll','videoeditor.dll','ttvideoeditor.dll','Qt6Core.dll','Resources','plugins.xml')",
  '  if(@($required | Where-Object {$requiredItem=Get-Item -LiteralPath (Join-Path $dir $_) -Force -ErrorAction SilentlyContinue; $null -eq $requiredItem -or ($requiredItem.Attributes -band [IO.FileAttributes]::ReparsePoint)}).Count -gt 0){continue}',
  '  $valid += [pscustomobject]@{version=$version;executable=[IO.Path]::GetFullPath($exe);versionRoot=[IO.Path]::GetFullPath($dir);sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $exe).Hash.ToLowerInvariant();thumbprint=[string]$sig.SignerCertificate.Thumbprint;subject=[string]$sig.SignerCertificate.Subject}',
  '}',
  "if($valid.Count -eq 0){throw 'JY006_CANDIDATE_NOT_FOUND'}",
  '$selected=$valid | Sort-Object {[version]$_.version} -Descending | Select-Object -First 1',
  '$json=$selected | ConvertTo-Json -Compress',
  '[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($json))',
].join(';')

/** @param {string} candidateRoot */
export const inspectJianying6Candidate = async (candidateRoot) => {
  const selectedRoot = await assertSafeCandidateRoot(candidateRoot)
  let stdout
  try {
    ;({ stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-Command', inspectPowerShell], {
      encoding: 'utf8',
      env: { ...process.env, OPENVIDEO_JY6_CANDIDATE: selectedRoot },
      timeout: 20_000,
      windowsHide: true,
      maxBuffer: 1024 * 1024,
    }))
  } catch {
    throw new Jianying6RendererSettingsError('JY006_CANDIDATE_INVALID', 409)
  }
  let value
  try {
    const encoded = stdout.trim().split(/\r?\n/u).at(-1)
    if (!encoded) throw new Error('missing-inspection-output')
    value = JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'))
  } catch {
    throw new Jianying6RendererSettingsError('JY006_CANDIDATE_INVALID', 409)
  }
  if (
    !isRecord(value) || typeof value.version !== 'string' || !versionPattern.test(value.version) ||
    typeof value.executable !== 'string' || !isAbsolute(value.executable) ||
    typeof value.versionRoot !== 'string' || !isAbsolute(value.versionRoot) ||
    !inside(selectedRoot, resolve(value.executable)) || !inside(selectedRoot, resolve(value.versionRoot)) ||
    typeof value.sha256 !== 'string' || !sha256Pattern.test(value.sha256) ||
    typeof value.thumbprint !== 'string' || !thumbprintPattern.test(value.thumbprint) ||
    typeof value.subject !== 'string' || !value.subject.includes(expectedPublisher)
  ) throw new Jianying6RendererSettingsError('JY006_CANDIDATE_INVALID', 409)
  await assertSafeJianying6CandidateDescendant(selectedRoot, value.versionRoot)
  await assertSafeJianying6CandidateDescendant(selectedRoot, value.executable)
  return {
    selectedRoot,
    executablePath: resolve(value.executable),
    versionRoot: resolve(value.versionRoot),
    version: value.version,
    executableSha256: value.sha256,
    signerThumbprint: value.thumbprint,
  }
}

/** @returns {Promise<string[]>} */
export const discoverJianying6CandidateRoots = async () => {
  const script = [
    "$roots=@('HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*')",
    "$apps=Get-ItemProperty $roots -ErrorAction SilentlyContinue | Where-Object {[string]$_.DisplayVersion -match '^6\\.' -and ([string]$_.DisplayName -match '剪映|Jianying' -or [string]$_.DisplayIcon -match 'JianyingPro')}",
    '$values=@($apps | ForEach-Object {if(-not [string]::IsNullOrWhiteSpace([string]$_.InstallLocation)){[string]$_.InstallLocation}else{$icon=([string]$_.DisplayIcon -replace \'^"|"$\',\'\' -replace \',\\d+$\',\'\');if([IO.Path]::IsPathRooted($icon)){Split-Path -Parent $icon}}} | Where-Object {$_} | Select-Object -Unique)',
    '$json=$values | ConvertTo-Json -Compress',
    '[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($json))',
  ].join(';')
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-Command', script], {
      encoding: 'utf8', timeout: 10_000, windowsHide: true, maxBuffer: 1024 * 1024,
    })
    const encoded = stdout.trim().split(/\r?\n/u).at(-1)
    if (!encoded) return []
    const decoded = JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'))
    return (Array.isArray(decoded) ? decoded : typeof decoded === 'string' ? [decoded] : [])
      .filter((entry) => typeof entry === 'string' && isAbsolute(entry) && !/^\\\\/u.test(entry))
  } catch {
    return []
  }
}

/** @param {Record<string, any>} document @param {'unconfigured'|'ready'|'disabled'|'invalid'} status */
const publicDocument = (document, status) => ({
  schema_version: schemaVersion,
  revision: document.revision,
  configured: document.selected_root !== null,
  enabled: status === 'ready',
  status,
  version: document.version,
  locationLabel: document.selected_root ? `${parse(document.selected_root).root.slice(0, 2)} 盘 · 剪映 6.x` : null,
  requiresVisibleUi: true,
  capabilities: {
    effectPreview: status === 'ready',
    desktopUiAutomation: status === 'ready',
    backgroundRender: false,
  },
})

/**
 * @param {{
 *   settingsPath: string,
 *   privateConfigRoot: string,
 *   inspectCandidate?: typeof inspectJianying6Candidate,
 *   discoverCandidateRoots?: typeof discoverJianying6CandidateRoots,
 *   now?: () => string,
 *   repositoryRoot?: string | null,
 * }} input
 */
export const createJianying6RendererSettingsService = ({
  settingsPath,
  privateConfigRoot,
  inspectCandidate = inspectJianying6Candidate,
  discoverCandidateRoots = discoverJianying6CandidateRoots,
  now = () => new Date().toISOString(),
  repositoryRoot = null,
}) => {
  if (!isAbsolute(settingsPath) || !isAbsolute(privateConfigRoot)) {
    throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
  }
  const root = resolve(privateConfigRoot)
  const path = resolve(settingsPath)
  const backupPath = `${path}.bak`
  const repository = repositoryRoot && isAbsolute(repositoryRoot) ? resolve(repositoryRoot) : null
  if (
    root === path || !inside(root, path) || root === parse(root).root ||
    // The installed runtime lives below the private settings directory
    // (`%LOCALAPPDATA%\\OpenVideo\\program`). Only reject a settings file
    // that would actually be inside the repository; a private parent that
    // contains the program directory is the supported installed layout.
    (repository && inside(repository, path))
  ) throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
  const assertSafeStorage = async () => {
    for (const target of [root, path, backupPath]) {
      let cursor = target
      while (cursor && cursor !== parse(cursor).root) {
        const stats = await lstat(cursor).catch((error) => {
          if (errorCode(error) === 'ENOENT') return null
          throw error
        })
        if (stats?.isSymbolicLink()) throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
        if (cursor === target && target !== root && stats?.isFile() && stats.nlink > 1) {
          throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
        }
        if (stats) {
          const actual = await realpath(cursor).catch(() => null)
          if (!actual || !await sameResolvedObject(cursor, actual, stats)) {
            throw new Jianying6RendererSettingsError('JY006_STORAGE_INVALID', 500)
          }
        }
        const parent = dirname(cursor)
        if (parent === cursor) break
        cursor = parent
      }
    }
  }
  let serialization = Promise.resolve()
  /** @template T @param {() => Promise<T>} operation */
  const serialize = (operation) => {
    const result = serialization.then(operation, operation)
    serialization = result.then(() => undefined, () => undefined)
    return result
  }
  /** @param {Record<string, any>} document */
  const revalidate = async (document) => {
    if (!document.selected_root) return { document, status: 'unconfigured' }
    try {
      const candidate = await inspectCandidate(document.selected_root)
      const matches = candidate.version === document.version &&
        candidate.executablePath === document.executable_path &&
        candidate.executableSha256 === document.executable_sha256 &&
        candidate.signerThumbprint === document.signer_thumbprint
      if (!matches) return { document: { ...document, enabled: false }, status: 'invalid' }
      return {
        document,
        status: document.enabled ? 'ready' : 'disabled',
      }
    } catch {
      return { document: { ...document, enabled: false }, status: 'invalid' }
    }
  }
  /** @param {string} selectedRoot */
  const saveCandidate = async (selectedRoot, enabled = true) => {
    const resolvedSelection = resolve(selectedRoot)
    if (inside(root, resolvedSelection) || (repository && inside(repository, resolvedSelection))) {
      throw new Jianying6RendererSettingsError('JY006_PATH_INVALID')
    }
    const candidate = await inspectCandidate(selectedRoot)
    const stamp = now()
    const document = {
      schema_version: schemaVersion,
      revision: `jy6_${randomUUID().replace(/-/gu, '')}`,
      enabled,
      selected_root: candidate.selectedRoot,
      executable_path: candidate.executablePath,
      version: candidate.version,
      executable_sha256: candidate.executableSha256,
      signer_thumbprint: candidate.signerThumbprint,
      confirmed_at: stamp,
      last_validated_at: stamp,
    }
    await writeDocument(path, document, { assertSafe: assertSafeStorage })
    return publicDocument(document, enabled ? 'ready' : 'disabled')
  }
  return {
    readPublic: () => serialize(async () => {
      const current = await readDocument(path, assertSafeStorage)
      const result = await revalidate(current)
      if (JSON.stringify(result.document) !== JSON.stringify(current)) {
        await writeDocument(path, result.document, { assertSafe: assertSafeStorage })
      }
      return publicDocument(
        result.document,
        /** @type {'unconfigured'|'ready'|'disabled'|'invalid'} */ (result.status),
      )
    }),
    readPrivate: () => serialize(async () => {
      const current = await readDocument(path, assertSafeStorage)
      const result = await revalidate(current)
      if (result.status !== 'ready') throw new Jianying6RendererSettingsError('JY006_RENDERER_UNAVAILABLE', 409)
      return structuredClone(result.document)
    }),
    /** @param {string} selectedRoot */
    select: (selectedRoot) => serialize(() => saveCandidate(selectedRoot)),
    discover: () => serialize(async () => {
      const current = await readDocument(path, assertSafeStorage)
      const currentResult = await revalidate(current)
      if (current.selected_root) {
        if (JSON.stringify(currentResult.document) !== JSON.stringify(current)) {
          await writeDocument(path, currentResult.document, { assertSafe: assertSafeStorage })
        }
        return publicDocument(
          currentResult.document,
          /** @type {'ready'|'disabled'|'invalid'} */ (currentResult.status),
        )
      }
      for (const candidateRoot of await discoverCandidateRoots()) {
        try {
          return await saveCandidate(candidateRoot, false)
        } catch {
          // Continue across bounded trusted installation candidates.
        }
      }
      return publicDocument(currentResult.document, 'unconfigured')
    }),
    /** @param {boolean} enabled */
    setEnabled: (enabled) => serialize(async () => {
      if (typeof enabled !== 'boolean') throw new Jianying6RendererSettingsError('JY006_INPUT_INVALID')
      const current = await readDocument(path, assertSafeStorage)
      if (!current.selected_root) throw new Jianying6RendererSettingsError('JY006_RENDERER_UNAVAILABLE', 409)
      const result = await revalidate({ ...current, enabled })
      if (enabled && result.status === 'invalid') throw new Jianying6RendererSettingsError('JY006_CANDIDATE_INVALID', 409)
      await writeDocument(path, result.document, { assertSafe: assertSafeStorage })
      return publicDocument(
        result.document,
        /** @type {'ready'|'disabled'|'invalid'} */ (result.status),
      )
    }),
    forget: () => serialize(async () => {
      const empty = emptyDocument()
      await writeDocument(path, empty, { assertSafe: assertSafeStorage })
      return publicDocument(empty, 'unconfigured')
    }),
  }
}

/** @param {unknown} body @param {number} [status] */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  },
})

/** @param {Request} request */
const readStrictJsonObject = async (request) => {
  if ((request.headers.get('content-type') ?? '').split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new Jianying6RendererSettingsError('UNSUPPORTED_MEDIA_TYPE', 415)
  }
  try {
    const value = await request.json()
    if (!isRecord(value)) throw new Error('not-an-object')
    return value
  } catch {
    throw new Jianying6RendererSettingsError('JY006_INPUT_INVALID')
  }
}

/**
 * @param {{
 *   service: ReturnType<typeof createJianying6RendererSettingsService>,
 *   resolveSelection: (input: {sessionId: string, nodeId: string}) => string,
 *   resolveNativeSelection?: () => string | Promise<string>,
 * }} input
 */
export const createJianying6RendererSettingsHandler = ({ service, resolveSelection, resolveNativeSelection }) => async (/** @type {Request} */ request) => {
  const pathname = new URL(request.url).pathname
  try {
    if (pathname === '/api/settings/jianying6' && request.method === 'GET') {
      return jsonResponse(await service.readPublic())
    }
    if (pathname === '/api/settings/jianying6/discover' && request.method === 'POST') {
      const input = await readStrictJsonObject(request)
      if (Object.keys(input).length !== 0) throw new Jianying6RendererSettingsError('JY006_INPUT_INVALID')
      return jsonResponse(await service.discover())
    }
    if (pathname === '/api/settings/jianying6/select' && request.method === 'POST') {
      const input = await readStrictJsonObject(request)
      const pickerSelection = Object.keys(input).sort().join('\u0000') === 'nodeId\u0000sessionId' &&
        typeof input.sessionId === 'string' && opaqueIdPattern.test(input.sessionId) &&
        typeof input.nodeId === 'string' && opaqueIdPattern.test(input.nodeId)
      const nativeSelection = Object.keys(input).length === 0 && typeof resolveNativeSelection === 'function'
      if (!pickerSelection && !nativeSelection) {
        throw new Jianying6RendererSettingsError('JY006_INPUT_INVALID')
      }
      const selectedRoot = pickerSelection
        ? resolveSelection({
          sessionId: /** @type {string} */ (input.sessionId),
          nodeId: /** @type {string} */ (input.nodeId),
        })
        : await /** @type {() => string | Promise<string>} */ (resolveNativeSelection)()
      return jsonResponse(await service.select(selectedRoot))
    }
    if (pathname === '/api/settings/jianying6/enabled' && request.method === 'PUT') {
      const input = await readStrictJsonObject(request)
      if (!isRecord(input) || Object.keys(input).join('') !== 'enabled' || typeof input.enabled !== 'boolean') {
        throw new Jianying6RendererSettingsError('JY006_INPUT_INVALID')
      }
      return jsonResponse(await service.setEnabled(input.enabled))
    }
    if (pathname === '/api/settings/jianying6' && request.method === 'DELETE') {
      const input = await readStrictJsonObject(request)
      if (Object.keys(input).length !== 0) throw new Jianying6RendererSettingsError('JY006_INPUT_INVALID')
      return jsonResponse(await service.forget())
    }
    return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  } catch (error) {
    const status = error instanceof Jianying6RendererSettingsError ? error.status : 500
    const code = error instanceof Jianying6RendererSettingsError ? error.code : 'JY006_SETTINGS_UNAVAILABLE'
    return jsonResponse({ error: { code, message: 'Jianying 6.x renderer settings failed safely.' } }, status)
  }
}
