const providerIdPattern = /^[a-z][a-z0-9_-]{2,63}$/
const revisionPattern = /^[a-z0-9][a-z0-9._-]{0,127}$/
const forbiddenFieldPattern = /(?:resource|material|draft|device|account|identity|cookie|token|secret|credential|cache|path|url|uri|download|endpoint|file)/i
const approvalFields = new Set(['licenseReviewed', 'termsReviewed', 'identityReviewed', 'securityReviewed', 'userEnabled'])

/** @param {string} code @returns {never} */
/** @param {string} code @returns {never} */
const fail = (code) => {
  const error = /** @type {Error & {code: string, status: number}} */ (new Error(code))
  error.code = code
  error.status = 409
  throw error
}

/**
 * This is a governance-only boundary. It deliberately never returns a
 * provider client, resource ID, or provisioned asset. A future adapter must
 * be separately approved and wired behind this policy.
 */
export const EXTERNAL_PACKAGING_PROVIDER_POLICY = Object.freeze({
  defaultMode: 'disabled',
  provisionAdapter: 'not_implemented',
  publicFields: Object.freeze(['mode', 'provider', 'policyRevision']),
})

/** @param {unknown} input */
export const validateExternalPackagingProviderConfiguration = (input = {}) => {
  if (!input || typeof input !== 'object' || Array.isArray(input)) fail('JY153_PROVIDER_CONFIG_INVALID')
  const record = /** @type {Record<string, unknown>} */ (input)
  const keys = Object.keys(record)
  if (keys.some((key) => !approvalFields.has(key) && forbiddenFieldPattern.test(key))) fail('JY153_PRIVATE_PROVIDER_FIELD_DENIED')
  if (record.mode === undefined || record.mode === 'disabled') {
    if (keys.some((key) => key !== 'mode')) fail('JY153_PROVIDER_CONFIG_INVALID')
    return Object.freeze({ mode: 'disabled', provider: null, policyRevision: null })
  }
  if (record.mode !== 'provision') fail('JY153_PROVIDER_CONFIG_INVALID')
  if (keys.some((key) => !['mode', 'provider', 'policyRevision', ...approvalFields].includes(key))) {
    fail('JY153_PROVIDER_CONFIG_INVALID')
  }
  if (typeof record.provider !== 'string' || !providerIdPattern.test(record.provider)) fail('JY153_PROVIDER_CONFIG_INVALID')
  if (typeof record.policyRevision !== 'string' || !revisionPattern.test(record.policyRevision)) fail('JY153_PROVIDER_CONFIG_INVALID')
  if (record.licenseReviewed !== true || record.termsReviewed !== true || record.identityReviewed !== true || record.securityReviewed !== true || record.userEnabled !== true) {
    fail('JY153_PROVIDER_APPROVAL_REQUIRED')
  }
  // Approval is necessary but not sufficient: no downloader is shipped.
  fail('JY153_PROVISION_ADAPTER_NOT_IMPLEMENTED')
}
