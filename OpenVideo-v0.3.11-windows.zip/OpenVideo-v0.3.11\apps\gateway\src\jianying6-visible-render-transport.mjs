import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { lstat, mkdir, realpath, rm, stat } from 'node:fs/promises'
import { dirname, isAbsolute, parse, relative, resolve } from 'node:path'
import { promisify } from 'node:util'

import {
  assertJianyingRenderJob,
  assertJianyingRenderArtifact,
  assertRenderBundleIdentity,
  assertSameRenderBundleDelivery,
  fingerprintRenderBundleIdentity,
} from './jianying-render-contracts.mjs'

const sha256 = /^[a-f0-9]{64}$/u
const opaqueId = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$/u
const execFileAsync = promisify(execFile)
const visibleFailureCodes = new Set([
  'JY007_CONFLICTING_JIANYING_INSTANCE',
  'JY007_DRAFT_CONTROL_UNAVAILABLE',
  'JY007_DRAFT_ARTIFACT_INVALID',
  'JY007_DRIVER_HASH_INVALID',
  'JY007_DRIVER_JSON_INVALID',
  'JY007_DRIVER_KEYS_INVALID',
  'JY007_DRIVER_PATH_INVALID',
  'JY007_DRIVER_SCHEMA_INVALID',
  'JY007_DRIVER_TIMEOUT_INVALID',
  'JY007_EXPORT_CONFIRM_UNAVAILABLE',
  'JY007_EXPORT_CONTROL_REJECTED',
  'JY007_EXPORT_CONTROL_UNAVAILABLE',
  'JY007_EXPORT_DIALOG_UNAVAILABLE',
  'JY007_EXPORT_NAME_CONTROL_UNAVAILABLE',
  'JY007_OUTPUT_MISSING',
  'JY007_OUTPUT_PATH_CONTROL_UNAVAILABLE',
  'JY007_OUTPUT_TARGET_INVALID',
  'JY007_PROCESS_INSPECTION_FAILED',
  'JY007_PROCESS_OWNERSHIP_FAILED',
  'JY007_RENDERER_ALREADY_RUNNING',
  'JY007_RENDERER_EXECUTABLE_INVALID',
  'JY007_RENDERER_WINDOW_UNAVAILABLE',
])
/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  record(value) && Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} value */
const opaque = (value) => typeof value === 'string' && opaqueId.test(value)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? resolve(left).toLowerCase() === resolve(right).toLowerCase()
  : resolve(left) === resolve(right)

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * Windows realpath can return an 8.3 alias. Accept a different spelling only
 * when both names still identify the exact same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}

/**
 * @param {string} path
 * @param {string} code
 * @param {{directory?: boolean, allowMissing?: boolean}} [options]
 */
const assertSafePath = async (path, code, { directory = false, allowMissing = false } = {}) => {
  if (!isAbsolute(path)) throw new Jianying6VisibleRenderTransportError(code)
  const resolved = resolve(path)
  let cursor = resolved
  while (cursor && cursor !== parse(cursor).root) {
    const metadata = await lstat(cursor).catch((error) => {
      if (allowMissing && error?.code === 'ENOENT') return null
      throw new Jianying6VisibleRenderTransportError(code)
    })
    if (metadata) {
      if (metadata.isSymbolicLink() || (cursor === resolved && metadata.isFile() && metadata.nlink > 1)) {
        throw new Jianying6VisibleRenderTransportError(code)
      }
      const actual = await realpath(cursor).catch(() => null)
      if (!actual || !await sameResolvedObject(cursor, actual, metadata)) {
        throw new Jianying6VisibleRenderTransportError(code)
      }
      if (cursor === resolved && directory && !metadata.isDirectory()) {
        throw new Jianying6VisibleRenderTransportError(code)
      }
    }
    const parent = dirname(cursor)
    if (parent === cursor) break
    cursor = parent
  }
  if (!allowMissing && !(await lstat(resolved).catch(() => null))) {
    throw new Jianying6VisibleRenderTransportError(code)
  }
  return resolved
}

export class Jianying6VisibleRenderTransportError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'Jianying6VisibleRenderTransportError'
    this.code = code
    this.status = status
  }
}

/** @param {Record<string, any>} renderer */
export const fingerprintJianying6RendererIdentity = (renderer) => {
  if (
    !record(renderer) ||
    !opaque(renderer.revision) ||
    typeof renderer.version !== 'string' ||
    !/^6\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u.test(renderer.version) ||
    typeof renderer.executable_sha256 !== 'string' ||
    !sha256.test(renderer.executable_sha256) ||
    typeof renderer.signer_thumbprint !== 'string' ||
    !/^[A-F0-9]{40,128}$/u.test(renderer.signer_thumbprint)
  ) throw new Jianying6VisibleRenderTransportError('JY007_RENDERER_IDENTITY_INVALID')
  return createHash('sha256').update(JSON.stringify({
    executableSha256: renderer.executable_sha256,
    revision: renderer.revision,
    signerThumbprint: renderer.signer_thumbprint,
    version: renderer.version,
  })).digest('hex')
}

/** @param {string} path */
const sha256File = (path) => new Promise((resolveHash, rejectHash) => {
  const hash = createHash('sha256')
  const stream = createReadStream(path)
  stream.on('data', (chunk) => hash.update(chunk))
  stream.once('error', rejectHash)
  stream.once('end', () => resolveHash(hash.digest('hex')))
})

/**
 * @param {{
 *   ffprobePath: string,
 *   runner?: typeof execFileAsync,
 * }} input
 */
export const createJianying6Mp4Verifier = ({
  ffprobePath,
  runner = execFileAsync,
}) => {
  if (!isAbsolute(ffprobePath)) {
    throw new Jianying6VisibleRenderTransportError('JY007_FFPROBE_UNAVAILABLE', 500)
  }
  return async (/** @type {string} */ outputPath) => {
    if (!isAbsolute(outputPath)) {
      throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
    }
    const info = await lstat(outputPath).catch(() => null)
    if (!info?.isFile() || info.isSymbolicLink() || info.nlink !== 1 || info.size <= 0) {
      throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
    }
    const actual = await realpath(outputPath).catch(() => null)
    if (!actual || !await sameResolvedObject(resolve(outputPath), actual, info)) {
      throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
    }
    let parsed
    try {
      const { stdout } = await runner(ffprobePath, [
        '-v', 'error',
        '-show_entries', 'format=duration,format_name:stream=codec_type,codec_name',
        '-of', 'json',
        outputPath,
      ], {
        cwd: dirname(ffprobePath),
        encoding: 'utf8',
        env: { PATH: dirname(ffprobePath) },
        maxBuffer: 1024 * 1024,
        timeout: 15_000,
        windowsHide: true,
      })
      parsed = JSON.parse(stdout)
    } catch {
      throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
    }
    const streams = Array.isArray(parsed?.streams) ? parsed.streams : []
    const video = streams.find((/** @type {any} */ stream) =>
      record(stream) && stream.codec_type === 'video' && opaque(stream.codec_name))
    const durationSeconds = Number(parsed?.format?.duration)
    if (
      !video ||
      !Number.isFinite(durationSeconds) ||
      durationSeconds <= 0 ||
      typeof parsed?.format?.format_name !== 'string' ||
      !parsed.format.format_name.split(',').some((/** @type {string} */ name) => name === 'mov' || name === 'mp4')
    ) throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
    const finalInfo = await stat(outputPath)
    if (finalInfo.size !== info.size) {
      throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
    }
    return {
      byteLength: finalInfo.size,
      durationMs: Math.round(durationSeconds * 1000),
      sha256: await sha256File(outputPath),
      videoCodec: video.codec_name,
    }
  }
}

/** @param {unknown} value */
const assertRequest = (value) => {
  const keys = [
    'bundleIdentity',
    'draftArtifactFingerprint',
    'draftArtifactId',
    'projectId',
    'rendererRevision',
    'timeoutMs',
  ]
  if (!exactKeys(value, keys)) {
    throw new Jianying6VisibleRenderTransportError('JY007_RENDER_REQUEST_INVALID')
  }
  const request = /** @type {Record<string, any>} */ (value)
  const bundleIdentity = assertRenderBundleIdentity(request.bundleIdentity)
  if (
    !opaque(request.projectId) ||
    !opaque(request.draftArtifactId) ||
    typeof request.draftArtifactFingerprint !== 'string' ||
    !sha256.test(request.draftArtifactFingerprint) ||
    !opaque(request.rendererRevision) ||
    !Number.isInteger(request.timeoutMs) ||
    request.timeoutMs < 1 ||
    request.timeoutMs > 30 * 60 * 1000
  ) throw new Jianying6VisibleRenderTransportError('JY007_RENDER_REQUEST_INVALID')
  return /** @type {Record<string, any>} */ ({ ...structuredClone(request), bundleIdentity })
}

/** @param {unknown} value */
const assertDraft = (value) => {
  const candidate = /** @type {Record<string, any>} */ (value)
  if (
    !exactKeys(value, ['artifactId', 'bundleFingerprint', 'fingerprint', 'path']) ||
    !opaque(candidate.artifactId) ||
    typeof candidate.bundleFingerprint !== 'string' || !sha256.test(candidate.bundleFingerprint) ||
    typeof candidate.fingerprint !== 'string' ||
    !sha256.test(candidate.fingerprint) ||
    typeof candidate.path !== 'string' ||
    !isAbsolute(candidate.path)
  ) throw new Jianying6VisibleRenderTransportError('JY007_DRAFT_IDENTITY_INVALID')
  return /** @type {{artifactId: string, bundleFingerprint: string, fingerprint: string, path: string}} */ (candidate)
}

/** @param {unknown} value */
const assertVerification = (value) => {
  const candidate = /** @type {Record<string, any>} */ (value)
  if (
    !exactKeys(value, ['byteLength', 'durationMs', 'sha256', 'videoCodec']) ||
    !Number.isSafeInteger(candidate.byteLength) ||
    candidate.byteLength <= 0 ||
    !Number.isFinite(candidate.durationMs) ||
    candidate.durationMs <= 0 ||
    typeof candidate.sha256 !== 'string' ||
    !sha256.test(candidate.sha256) ||
    !opaque(candidate.videoCodec)
  ) throw new Jianying6VisibleRenderTransportError('JY007_OUTPUT_UNVERIFIED')
  return /** @type {{byteLength: number, durationMs: number, sha256: string, videoCodec: string}} */ (candidate)
}

/**
 * @param {Record<string, any>} request
 * @param {string} jobId
 * @param {string} state
 * @param {number} progress
 * @param {string} createdAt
 * @param {string} updatedAt
 * @param {null | {code: string, recoverable: boolean}} [error]
 */
const createJob = (request, jobId, state, progress, createdAt, updatedAt, error = null) =>
  assertJianyingRenderJob({
    bundleFingerprint: fingerprintRenderBundleIdentity(request.bundleIdentity),
    bundleIdentity: request.bundleIdentity,
    createdAt,
    error,
    jobId,
    progress,
    projectId: request.projectId,
    state,
    updatedAt,
  })

/**
 * @param {{
 *   repositoryRoot: string,
 *   runtimeRoot: string,
 *   settingsService: {readPrivate: () => Promise<Record<string, any>>},
 *   resolveDraftArtifact: (input: {artifactId: string}) => Promise<unknown>,
 *   driver: {render: (input: {draftPath: string, executablePath: string, executableSha256: string, outputPath: string, signal: AbortSignal, timeoutMs: number}) => Promise<void>},
 *   verifyOutput: (path: string) => Promise<unknown>,
 *   now?: () => string,
 * }} input
 */
export const createJianying6VisibleRenderTransport = ({
  repositoryRoot,
  runtimeRoot,
  settingsService,
  resolveDraftArtifact,
  driver,
  verifyOutput,
  now = () => new Date().toISOString(),
}) => {
  if (
    !isAbsolute(repositoryRoot) ||
    !isAbsolute(runtimeRoot) ||
    resolve(runtimeRoot) === parse(resolve(runtimeRoot)).root ||
    inside(resolve(repositoryRoot), resolve(runtimeRoot)) ||
    inside(resolve(runtimeRoot), resolve(repositoryRoot)) ||
    typeof settingsService?.readPrivate !== 'function' ||
    typeof resolveDraftArtifact !== 'function' ||
    typeof driver?.render !== 'function' ||
    typeof verifyOutput !== 'function'
  ) throw new Jianying6VisibleRenderTransportError('JY007_STORAGE_INVALID', 500)

  const root = resolve(runtimeRoot)
  /** @type {Map<string, any>} */
  const jobs = new Map()
  /** @param {any} entry */
  const publicJob = (entry) => structuredClone(entry.job)
  /** @param {any} entry @param {string} state @param {number} progress @param {null | {code: string, recoverable: boolean}} [error] */
  const update = (entry, state, progress, error = null) => {
    entry.job = createJob(
      entry.request,
      entry.job.jobId,
      state,
      progress,
      entry.job.createdAt,
      now(),
      error,
    )
  }
  /** @param {string} jobId */
  const get = (jobId) => {
    if (!opaque(jobId)) throw new Jianying6VisibleRenderTransportError('JY007_RENDER_JOB_ID_INVALID')
    const entry = jobs.get(jobId)
    if (!entry) throw new Jianying6VisibleRenderTransportError('JY007_RENDER_JOB_NOT_FOUND', 404)
    return entry
  }

  return Object.freeze({
    /** @param {unknown} rawRequest */
    async start(rawRequest) {
      const request = assertRequest(rawRequest)
      const renderer = await settingsService.readPrivate()
      if (
        renderer.revision !== request.rendererRevision ||
        renderer.version !== request.bundleIdentity.jianyingVersion ||
        fingerprintJianying6RendererIdentity(renderer) !==
          request.bundleIdentity.jianyingSignatureFingerprint ||
        typeof renderer.executable_path !== 'string' ||
        !isAbsolute(renderer.executable_path)
      ) throw new Jianying6VisibleRenderTransportError('JY007_RENDERER_IDENTITY_MISMATCH')

      const draft = assertDraft(await resolveDraftArtifact({ artifactId: request.draftArtifactId }))
      if (
        draft.artifactId !== request.draftArtifactId ||
        draft.fingerprint !== request.draftArtifactFingerprint
      ) throw new Jianying6VisibleRenderTransportError('JY007_DRAFT_IDENTITY_MISMATCH')
      if (draft.bundleFingerprint !== fingerprintRenderBundleIdentity(request.bundleIdentity)) {
        throw new Jianying6VisibleRenderTransportError('JY007_DRAFT_BUNDLE_MISMATCH')
      }
      const safeDraftPath = await assertSafePath(
        draft.path,
        'JY007_DRAFT_ARTIFACT_INVALID',
        { directory: true },
      )
      await assertSafePath(root, 'JY007_STORAGE_INVALID', { directory: true, allowMissing: true })

      const jobId = 'jy7_' + randomUUID().replace(/-/gu, '')
      const outputDir = resolve(root, 'renders', jobId)
      const outputPath = resolve(outputDir, 'preview.mp4')
      const controller = new AbortController()
      const createdAt = now()
      const entry = /** @type {any} */ ({
        artifact: null,
        controller,
        job: createJob(request, jobId, 'draft_staged', 20, createdAt, createdAt),
        outputDir,
        outputPath,
        draftArtifact: {
          artifactId: draft.artifactId,
          bundleFingerprint: draft.bundleFingerprint,
          fingerprint: draft.fingerprint,
        },
        request,
        running: true,
      })
      try {
        await mkdir(outputDir, { recursive: true })
        await assertSafePath(root, 'JY007_STORAGE_INVALID', { directory: true })
        await assertSafePath(outputDir, 'JY007_OUTPUT_TARGET_INVALID', { directory: true })
      } catch (error) {
        await rm(outputDir, { recursive: true, force: true }).catch(() => {})
        if (error instanceof Jianying6VisibleRenderTransportError) throw error
        throw new Jianying6VisibleRenderTransportError('JY007_STORAGE_INVALID', 500)
      }
      jobs.set(jobId, entry)
      update(entry, 'render_started', 45)

      const timer = setTimeout(() => {
        controller.abort(new Jianying6VisibleRenderTransportError('JY007_RENDER_TIMEOUT'))
      }, request.timeoutMs)
      entry.promise = (async () => {
        try {
          const aborted = new Promise((resolveAbort, rejectAbort) => {
            controller.signal.addEventListener('abort', () => {
              rejectAbort(controller.signal.reason ?? new Jianying6VisibleRenderTransportError('JY007_RENDER_CANCELLED'))
            }, { once: true })
          })
          await Promise.race([driver.render({
            draftPath: safeDraftPath,
            executablePath: renderer.executable_path,
            executableSha256: renderer.executable_sha256,
            outputPath,
            signal: controller.signal,
            timeoutMs: request.timeoutMs,
          }), aborted])
          const verified = assertVerification(await verifyOutput(outputPath))
          entry.artifact = assertJianyingRenderArtifact({
            artifactId: 'render_' + jobId,
            bundleFingerprint: fingerprintRenderBundleIdentity(entry.request.bundleIdentity),
            byteLength: verified.byteLength,
            durationMs: verified.durationMs,
            sha256: verified.sha256,
            videoCodec: verified.videoCodec,
          })
          update(entry, 'bundle_ready', 90)
        } catch (error) {
          const timedOut = controller.signal.reason?.code === 'JY007_RENDER_TIMEOUT'
          const cancelled = controller.signal.aborted && !timedOut
          if (cancelled) {
            update(entry, 'cancelled', Math.min(entry.job.progress, 89))
          } else {
            const errorCode = /** @type {any} */ (error)?.code
            const code = timedOut
              ? 'JY007_RENDER_TIMEOUT'
              : errorCode === 'JY007_OUTPUT_UNVERIFIED'
                ? 'JY007_OUTPUT_UNVERIFIED'
                : visibleFailureCodes.has(errorCode)
                  ? errorCode
                : 'JY007_VISIBLE_RENDER_FAILED'
            update(entry, 'failed', Math.min(entry.job.progress, 89), {
              code,
              recoverable: true,
            })
          }
          await rm(outputDir, { recursive: true, force: true })
        } finally {
          clearTimeout(timer)
          entry.running = false
        }
      })()
      return publicJob(entry)
    },

    /** @param {string} jobId */
    async status(jobId) {
      return publicJob(get(jobId))
    },

    /** @param {string} jobId */
    async cancel(jobId) {
      const entry = get(jobId)
      if (entry.running) {
        entry.controller.abort()
        await entry.promise.catch(() => {})
      }
      if (!['cancelled', 'failed', 'promoted', 'bundle_ready'].includes(entry.job.state)) {
        update(entry, 'cancelled', Math.min(entry.job.progress, 89))
      }
      await rm(entry.outputDir, { recursive: true, force: true })
      return publicJob(entry)
    },

    /** @param {string} jobId */
    async collect(jobId) {
      const entry = get(jobId)
      if (entry.running) await entry.promise.catch(() => {})
      if (entry.job.state !== 'bundle_ready' || !entry.artifact) {
        throw new Jianying6VisibleRenderTransportError('JY007_RENDER_NOT_COLLECTABLE')
      }
      const currentDraft = assertDraft(await resolveDraftArtifact({ artifactId: entry.draftArtifact.artifactId }))
      if (
        currentDraft.artifactId !== entry.draftArtifact.artifactId ||
        currentDraft.fingerprint !== entry.draftArtifact.fingerprint ||
        currentDraft.bundleFingerprint !== entry.draftArtifact.bundleFingerprint
      ) throw new Jianying6VisibleRenderTransportError('JY007_DRAFT_DELIVERY_MISMATCH')
      await assertSafePath(currentDraft.path, 'JY007_DRAFT_ARTIFACT_INVALID', { directory: true })
      const delivery = assertSameRenderBundleDelivery({
        bundleIdentity: entry.request.bundleIdentity,
        draftArtifact: entry.draftArtifact,
        renderArtifact: entry.artifact,
      })
      update(entry, 'promoted', 100)
      return {
        artifact: delivery.renderArtifact,
        draftArtifact: delivery.draftArtifact,
        job: publicJob(entry),
      }
    },

    /** @param {string} jobId */
    async cleanup(jobId) {
      const entry = get(jobId)
      if (entry.running) entry.controller.abort()
      await entry.promise?.catch(() => {})
      await rm(entry.outputDir, { recursive: true, force: true })
      return { cleaned: true }
    },
  })
}
