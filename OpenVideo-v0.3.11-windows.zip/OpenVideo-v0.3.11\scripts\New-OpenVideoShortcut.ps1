[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [string]$ShortcutPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$root = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $RepositoryRoot).Path)
$launcherPath = Join-Path $root 'OpenVideo.cmd'
if (-not (Test-Path -LiteralPath $launcherPath -PathType Leaf)) {
    throw 'OpenVideo.cmd is missing from the selected repository root.'
}
$icon = Join-Path $root 'apps\web\public\openvideo.ico'
if (-not (Test-Path -LiteralPath $icon -PathType Leaf)) {
    throw 'OpenVideo icon is missing.'
}

# Shortcuts contain machine-specific absolute paths; regenerate on each target computer.
if ([string]::IsNullOrWhiteSpace($ShortcutPath)) {
    $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    if ([string]::IsNullOrWhiteSpace($desktop)) {
        throw 'Windows desktop directory is unavailable.'
    }
    $shortcutPath = Join-Path $desktop 'OpenVideo.lnk'
} else {
    $shortcutPath = [IO.Path]::GetFullPath($ShortcutPath)
}
$shortcutParent = Split-Path -Parent $shortcutPath
if (-not [string]::IsNullOrWhiteSpace($shortcutParent)) {
    New-Item -ItemType Directory -Path $shortcutParent -Force | Out-Null
}
$shell = New-Object -ComObject WScript.Shell
$shortcut = $null
try {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $launcherPath
    $shortcut.WorkingDirectory = $root
    $shortcut.IconLocation = "$icon,0"
    $shortcut.Description = 'Launch OpenVideo'
    $shortcut.WindowStyle = 1
    $shortcut.Save()
} finally {
    if ($null -ne $shortcut) {
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut)
    }
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)
}
Write-Output $shortcutPath
