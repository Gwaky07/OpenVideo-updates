import { randomBytes } from 'node:crypto'
import { lstat, mkdir, open, readFile, realpath, rename, rm } from 'node:fs/promises'
import path from 'node:path'

import {
  canonicalJY200DuoJson,
  fingerprintJY200DuoValue,
  parseJY200DuoLocalCatalogLifecycleReceipt,
  parseJY200DuoProbeExecutionReceipt,
} from './jianying-duo-direct-probe-evidence.mjs'
import {
  signArtistEffectStickerReceipt,
  verifyArtistEffectStickerReceiptSignature,
} from './jianying-artist-effect-probe.mjs'

const FINGERPRINT = /^[a-f0-9]{64}$/u
const COMMIT = /^[a-f0-9]{40}$/u
const IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}$/u
const BINDING_CAPABILITIES = Object.freeze(['effect.video.named', 'sticker.named', 'text.flower.private'])
const PRODUCT_CAPABILITIES = Object.freeze([
  'audio.bgm.local',
  'audio.sfx.local',
  'audio.voiceover.edge_tts',
  'caption.basic',
  'effect.video.named',
  'sticker.named',
  'text.flower.private',
  'track.insert_many',
  'transition.cut',
  'transition.none',
])
const RECEIPT_KEYS = Object.freeze([
  'schema_version', 'kind', 'status', 'admission', 'writer_eligible', 'catalog_bound',
  'provider', 'provider_commit', 'build_digest', 'profile_id', 'app_version',
  'desktop_binding_fingerprint', 'current_catalog_fingerprint', 'evidence_fingerprint',
  'binding_set_fingerprint', 'capability_snapshot', 'adapter_revision',
  'lifecycle_receipt_fingerprint', 'execution_receipt_fingerprint',
  'publication_record_fingerprint', 'publication_id', 'publication_job_id',
  'timeline_fingerprint', 'remote_resource_policy', 'execution_receipt',
  'audio_evidence_fingerprint',
  'admitted_at', 'integrity_revision', 'integrity_signature',
])

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {readonly string[]} keys */
const exactKeys = (value, keys) => isRecord(value) &&
  Object.keys(/** @type {Record<string, unknown>} */ (value)).sort().join('\0') === [...keys].sort().join('\0')
/** @param {string} parent @param {string} candidate */
const inside = (parent, candidate) => {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}
/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {unknown} value */
const validRemotePolicy = (value) => exactKeys(value, [
  'remote_resources', 'cloud_upload', 'account_device_identity', 'inherited_cache',
]) && Object.values(/** @type {Record<string, unknown>} */ (value)).every((entry) => entry === 'denied')

/** @param {unknown} value @param {string} timelineFingerprint */
const validFinalizedTimeline = (value, timelineFingerprint) => {
  const timeline = /** @type {any} */ (value)
  if (!isRecord(timeline) || timeline.status !== 'finalized' ||
      timeline.revisionFingerprint !== timelineFingerprint || !Array.isArray(timeline.capabilityRequirements)) return false
  const capabilities = timeline.capabilityRequirements
    .filter((/** @type {Record<string, any>} */ entry) => entry?.acceptance === 'implemented')
    .map((/** @type {Record<string, any>} */ entry) => entry.capabilityId)
    .sort()
  return canonicalJY200DuoJson(capabilities) === canonicalJY200DuoJson(PRODUCT_CAPABILITIES)
}

/** @param {unknown} value @param {string} integrityKey */
export const parseJY200DuoProductAdmissionReceipt = (value, integrityKey) => {
  const receipt = /** @type {any} */ (value)
  const execution = parseJY200DuoProbeExecutionReceipt(receipt?.execution_receipt, integrityKey)
  if (!exactKeys(receipt, RECEIPT_KEYS) || !execution ||
      receipt.schema_version !== 1 || receipt.kind !== 'jy200_duo_product_admission' ||
      receipt.status !== 'admitted' || receipt.admission !== 'admitted' ||
      receipt.writer_eligible !== true || receipt.catalog_bound !== true ||
      receipt.provider !== 'duo-video' || !COMMIT.test(receipt.provider_commit ?? '') ||
      !['build_digest', 'desktop_binding_fingerprint', 'current_catalog_fingerprint',
        'evidence_fingerprint', 'binding_set_fingerprint', 'lifecycle_receipt_fingerprint',
        'execution_receipt_fingerprint', 'audio_evidence_fingerprint', 'publication_record_fingerprint', 'timeline_fingerprint']
        .every((key) => FINGERPRINT.test(receipt[key] ?? '')) ||
      !IDENTIFIER.test(receipt.adapter_revision ?? '') ||
      !IDENTIFIER.test(receipt.publication_id ?? '') || !IDENTIFIER.test(receipt.publication_job_id ?? '') ||
      canonicalJY200DuoJson(receipt.capability_snapshot) !== canonicalJY200DuoJson(PRODUCT_CAPABILITIES) ||
      receipt.execution_receipt_fingerprint !== fingerprintJY200DuoValue(canonicalJY200DuoJson(execution)) ||
      receipt.audio_evidence_fingerprint !== execution.audio_evidence_fingerprint ||
      execution.provider_commit !== receipt.provider_commit || execution.build_digest !== receipt.build_digest ||
      execution.profile_id !== receipt.profile_id || execution.app_version !== receipt.app_version ||
      execution.desktop_binding_fingerprint !== receipt.desktop_binding_fingerprint ||
      execution.current_catalog_fingerprint !== receipt.current_catalog_fingerprint ||
      execution.binding_set_fingerprint !== receipt.binding_set_fingerprint ||
      canonicalJY200DuoJson(execution.capability_snapshot) !== canonicalJY200DuoJson(BINDING_CAPABILITIES) ||
      !validRemotePolicy(receipt.remote_resource_policy) ||
      Number.isNaN(Date.parse(receipt.admitted_at)) || receipt.integrity_revision !== 1 ||
      !verifyArtistEffectStickerReceiptSignature(receipt, integrityKey)) return null
  return Object.freeze(structuredClone(receipt))
}

/** @param {unknown} value */
const publicationProjection = (value) => {
  const record = /** @type {any} */ (value)
  if (!isRecord(record) || record.state !== 'committed' || record.ownerId !== 'duo-video' ||
      !IDENTIFIER.test(record.jobId ?? '') || record.requestId !== record.jobId ||
      !COMMIT.test(record.providerCommit ?? '') || !FINGERPRINT.test(record.buildDigest ?? '') ||
      !IDENTIFIER.test(record.adapterRevision ?? '') || !FINGERPRINT.test(record.evidenceFingerprint ?? '') ||
      !FINGERPRINT.test(record.timelineFingerprint ?? '') || !isRecord(record.publication) ||
      record.publication.providerId !== 'duo-video' || !IDENTIFIER.test(record.publication.publicationId ?? '') ||
      Number.isNaN(Date.parse(record.settledAt)) || Number.isNaN(Date.parse(record.ownerCompletedAt)) ||
      record.lastFailure !== null) return null
  return Object.freeze({
    jobId: record.jobId,
    requestId: record.requestId,
    ownerId: record.ownerId,
    providerCommit: record.providerCommit,
    buildDigest: record.buildDigest,
    adapterRevision: record.adapterRevision,
    evidenceFingerprint: record.evidenceFingerprint,
    timelineFingerprint: record.timelineFingerprint,
    state: record.state,
    publicationId: record.publication.publicationId,
    publicationProviderId: record.publication.providerId,
    settledAt: record.settledAt,
    ownerCompletedAt: record.ownerCompletedAt,
  })
}

/**
 * Mint a formal admission only from the complete current Gate-A evidence chain.
 * This is an explicit product decision; startup never promotes technical evidence.
 * @param {{lifecycleReceipt: unknown, executionReceipt: unknown, publicationRecord: unknown, richTimeline: unknown, manifest: unknown, admittedAt?: string}} input
 * @param {string} integrityKey
 */
export const createJY200DuoProductAdmissionReceipt = (input, integrityKey) => {
  const lifecycle = parseJY200DuoLocalCatalogLifecycleReceipt(input?.lifecycleReceipt, integrityKey)
  const execution = parseJY200DuoProbeExecutionReceipt(input?.executionReceipt, integrityKey)
  const publication = publicationProjection(input?.publicationRecord)
  const manifest = /** @type {any} */ (input?.manifest)
  const audioRoles = new Set(execution?.audio_evidence?.map((/** @type {{role?: unknown}} */ entry) => entry?.role))
  if (!lifecycle || !execution || !publication || !isRecord(manifest) ||
      audioRoles.size !== 3 || !['voiceover', 'bgm', 'sfx'].every((role) => audioRoles.has(role)) ||
      lifecycle.schema_version !== 5 || lifecycle.readback?.edit_kind !== 'audio_volume' ||
      lifecycle.readback?.videos !== 3 || lifecycle.readback?.audios !== 5 || lifecycle.readback?.texts !== 4 ||
      lifecycle.readback?.tracks !== 8 || lifecycle.readback?.segments !== 14 ||
      !validFinalizedTimeline(input?.richTimeline, publication.timelineFingerprint) ||
      manifest.provider !== 'duo-video' || manifest.commit !== lifecycle.provider_commit ||
      manifest.root_license !== 'MIT' || manifest.direct_probe?.gate_a_decision !== 'GO' ||
      manifest.direct_probe?.status !== 'go' ||
      canonicalJY200DuoJson(manifest.direct_probe?.advanced_families?.verified) !==
        canonicalJY200DuoJson(['sticker', 'flower', 'video_effect']) ||
      manifest.direct_probe?.latest_receipt?.evidence_fingerprint !== lifecycle.current_evidence_fingerprint ||
      manifest.direct_probe?.latest_receipt?.timeline_fingerprint !== publication.timelineFingerprint ||
      canonicalJY200DuoJson(manifest.direct_probe?.latest_receipt?.required_capabilities) !==
        canonicalJY200DuoJson(PRODUCT_CAPABILITIES) ||
      manifest.resource_rights_audit?.current_product_decision !== 'remote_fail_closed_local_writer_gate_a_go' ||
      !validRemotePolicy(manifest.network_identity_boundary) ||
      publication.providerCommit !== lifecycle.provider_commit || publication.buildDigest !== lifecycle.build_digest ||
      execution.provider_commit !== lifecycle.provider_commit || execution.build_digest !== lifecycle.build_digest ||
      execution.profile_id !== lifecycle.profile_id || execution.app_version !== lifecycle.app_version ||
      execution.desktop_binding_fingerprint !== lifecycle.desktop_binding_fingerprint ||
      execution.current_catalog_fingerprint !== lifecycle.current_catalog_fingerprint ||
      execution.binding_set_fingerprint !== lifecycle.binding_set_fingerprint ||
      lifecycle.execution_receipt_fingerprint !== fingerprintJY200DuoValue(canonicalJY200DuoJson(execution)) ||
      lifecycle.execution_binding_evidence_fingerprint !== execution.binding_evidence_fingerprint ||
      canonicalJY200DuoJson(lifecycle.capability_snapshot) !== canonicalJY200DuoJson(BINDING_CAPABILITIES)) {
    throw new Error('JY200_DUO_PRODUCT_ADMISSION_EVIDENCE_INVALID')
  }
  const admittedAt = input.admittedAt ?? new Date().toISOString()
  if (Number.isNaN(Date.parse(admittedAt))) throw new Error('JY200_DUO_PRODUCT_ADMISSION_TIME_INVALID')
  const unsigned = {
    schema_version: 1,
    kind: 'jy200_duo_product_admission',
    status: 'admitted',
    admission: 'admitted',
    writer_eligible: true,
    catalog_bound: true,
    provider: 'duo-video',
    provider_commit: lifecycle.provider_commit,
    build_digest: lifecycle.build_digest,
    profile_id: lifecycle.profile_id,
    app_version: lifecycle.app_version,
    desktop_binding_fingerprint: lifecycle.desktop_binding_fingerprint,
    current_catalog_fingerprint: lifecycle.current_catalog_fingerprint,
    evidence_fingerprint: lifecycle.current_evidence_fingerprint,
    binding_set_fingerprint: lifecycle.binding_set_fingerprint,
    capability_snapshot: [...PRODUCT_CAPABILITIES],
    adapter_revision: publication.adapterRevision,
    lifecycle_receipt_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(lifecycle)),
    execution_receipt_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(execution)),
    audio_evidence_fingerprint: execution.audio_evidence_fingerprint,
    publication_record_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(publication)),
    publication_id: publication.publicationId,
    publication_job_id: publication.jobId,
    timeline_fingerprint: publication.timelineFingerprint,
    remote_resource_policy: {
      remote_resources: 'denied',
      cloud_upload: 'denied',
      account_device_identity: 'denied',
      inherited_cache: 'denied',
    },
    execution_receipt: structuredClone(execution),
    admitted_at: admittedAt,
    integrity_revision: 1,
  }
  const receipt = { ...unsigned, integrity_signature: signArtistEffectStickerReceipt(unsigned, integrityKey) }
  const parsed = parseJY200DuoProductAdmissionReceipt(receipt, integrityKey)
  if (!parsed) throw new Error('JY200_DUO_PRODUCT_ADMISSION_RECEIPT_INVALID')
  return parsed
}

/** @param {string} directory */
const assertOrdinaryDirectory = async (directory) => {
  const [metadata, actual] = await Promise.all([lstat(directory), realpath(directory)])
  if (!metadata.isDirectory() || metadata.isSymbolicLink()) {
    throw new Error('JY200_DUO_PRODUCT_ADMISSION_ROOT_UNSAFE')
  }
  if (!samePath(directory, actual)) {
    if (process.platform !== 'win32') throw new Error('JY200_DUO_PRODUCT_ADMISSION_ROOT_UNSAFE')
    const actualMetadata = await lstat(actual)
    if (!actualMetadata.isDirectory() || actualMetadata.isSymbolicLink() ||
      actualMetadata.dev !== metadata.dev || actualMetadata.ino !== metadata.ino) {
      throw new Error('JY200_DUO_PRODUCT_ADMISSION_ROOT_UNSAFE')
    }
  }
  return Object.freeze({ path: path.resolve(directory), identity: `${metadata.dev}:${metadata.ino}` })
}

/**
 * Atomically publish the private receipt outside Git. The runtime resolver
 * still revalidates its current desktop, catalog and installed build on read.
 * @param {{dataRoot: string, receipt: unknown, integrityKey: string}} input
 */
export const publishJY200DuoProductAdmissionReceipt = async ({ dataRoot, receipt, integrityKey }) => {
  const parsed = parseJY200DuoProductAdmissionReceipt(receipt, integrityKey)
  if (!parsed || typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot)) {
    throw new Error('JY200_DUO_PRODUCT_ADMISSION_PUBLICATION_INVALID')
  }
  const evidenceRoot = path.join(path.resolve(dataRoot), 'evidence')
  if (!inside(dataRoot, evidenceRoot)) throw new Error('JY200_DUO_PRODUCT_ADMISSION_ROOT_UNSAFE')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const before = await assertOrdinaryDirectory(evidenceRoot)
  const outputPath = path.join(evidenceRoot, 'jy200-duo-admission.json')
  try {
    const existing = await lstat(outputPath)
    if (!existing.isFile() || existing.isSymbolicLink() || existing.nlink !== 1) {
      throw new Error('JY200_DUO_PRODUCT_ADMISSION_FILE_UNSAFE')
    }
  } catch (error) {
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw error
  }
  const temporary = `${outputPath}.${process.pid}.${randomBytes(8).toString('hex')}.tmp`
  let handle
  try {
    handle = await open(temporary, 'wx', 0o600)
    await handle.writeFile(`${JSON.stringify(parsed)}\n`, 'utf8')
    await handle.sync()
    await handle.close()
    handle = undefined
    const current = await assertOrdinaryDirectory(evidenceRoot)
    if (current.identity !== before.identity) throw new Error('JY200_DUO_PRODUCT_ADMISSION_ROOT_REPLACED')
    await rename(temporary, outputPath)
    const metadata = await lstat(outputPath)
    if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.nlink !== 1) {
      throw new Error('JY200_DUO_PRODUCT_ADMISSION_FILE_UNSAFE')
    }
    const persisted = JSON.parse(await readFile(outputPath, 'utf8'))
    if (!parseJY200DuoProductAdmissionReceipt(persisted, integrityKey)) {
      throw new Error('JY200_DUO_PRODUCT_ADMISSION_PERSISTENCE_INVALID')
    }
    return Object.freeze({
      provider: 'duo-video',
      admission: 'admitted',
      writer_eligible: true,
      receipt_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(persisted)),
    })
  } finally {
    await handle?.close().catch(() => {})
    await rm(temporary, { force: true }).catch(() => {})
  }
}
