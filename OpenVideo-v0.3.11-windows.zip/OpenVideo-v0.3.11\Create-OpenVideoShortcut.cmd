@echo off
setlocal
chcp 65001 >NUL
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\New-OpenVideoShortcut.ps1" -RepositoryRoot "%~dp0"
if errorlevel 1 (
  echo Failed to create the OpenVideo desktop shortcut.
  pause
  exit /b 1
)
echo OpenVideo desktop shortcut created.
timeout /t 3 /nobreak >NUL
endlocal
