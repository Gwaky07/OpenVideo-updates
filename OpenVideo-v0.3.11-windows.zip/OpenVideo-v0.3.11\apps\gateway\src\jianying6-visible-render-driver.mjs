import { spawn } from 'node:child_process'
import { isAbsolute } from 'node:path'

const maxOutputBytes = 64 * 1024
const sha256Pattern = /^[a-f0-9]{64}$/u
/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  record(value) && Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')

export class Jianying6VisibleRenderDriverError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'Jianying6VisibleRenderDriverError'
    this.code = code
  }
}

/**
 * Runs the repository-owned UI Automation worker over a bounded stdin/stdout JSON protocol.
 * Private paths stay inside the local helper process and are never copied into thrown errors.
 * @param {{
 *   pythonExecutable: string,
 *   workerPath: string,
 *   spawnProcess?: typeof spawn,
 * }} input
 */
export const createJianying6VisibleDesktopDriver = ({
  pythonExecutable,
  workerPath,
  spawnProcess = spawn,
}) => {
  if (!isAbsolute(pythonExecutable) || !isAbsolute(workerPath)) {
    throw new Jianying6VisibleRenderDriverError('JY007_DRIVER_CONFIGURATION_INVALID')
  }
  return Object.freeze({
    /**
     * @param {{
     *   draftPath: string,
     *   executablePath: string,
     *   outputPath: string,
     *   executableSha256: string,
     *   signal: AbortSignal,
     *   timeoutMs: number,
     * }} input
     */
    render(input) {
      if (
        !isAbsolute(input?.draftPath) ||
        !isAbsolute(input?.executablePath) ||
        !isAbsolute(input?.outputPath) ||
        typeof input?.executableSha256 !== 'string' ||
        !sha256Pattern.test(input.executableSha256) ||
        !(input?.signal instanceof AbortSignal) ||
        !Number.isInteger(input?.timeoutMs) ||
        input.timeoutMs < 1
      ) return Promise.reject(new Jianying6VisibleRenderDriverError('JY007_DRIVER_INPUT_INVALID'))
      if (input.signal.aborted) {
        return Promise.reject(new Jianying6VisibleRenderDriverError('JY007_RENDER_CANCELLED'))
      }

      return new Promise((resolveRender, rejectRender) => {
        let settled = false
        let stdout = ''
        let stdoutBytes = 0
        let safeStderr = ''
        let stderrBytes = 0
        /** @type {Jianying6VisibleRenderDriverError | null} */
        let terminationError = null
        /** @type {NodeJS.Timeout | null} */
        let forceKillTimer = null
        const inheritedEnvironment = Object.fromEntries(
          ['APPDATA', 'LOCALAPPDATA', 'SystemRoot', 'TEMP', 'TMP', 'USERPROFILE', 'WINDIR']
            .map((key) => [key, process.env[key]])
            .filter((entry) => typeof entry[1] === 'string' && entry[1].length > 0),
        )
        const child = spawnProcess(pythonExecutable, [workerPath], {
          cwd: undefined,
          env: {
            ...inheritedEnvironment,
            JY007_DRIVER_PROTOCOL: '1',
            PATH: '',
            PYTHONIOENCODING: 'utf-8',
          },
          shell: false,
          stdio: ['pipe', 'pipe', 'pipe'],
          windowsHide: true,
        })
        const timeout = setTimeout(() => {
          requestTermination(new Jianying6VisibleRenderDriverError('JY007_VISIBLE_RENDER_TIMEOUT'))
        }, input.timeoutMs)
        /** @param {Error | null} error @param {unknown} [value] */
        const finish = (error, value) => {
          if (settled) return
          settled = true
          clearTimeout(timeout)
          if (forceKillTimer) clearTimeout(forceKillTimer)
          input.signal.removeEventListener('abort', abort)
          if (error) rejectRender(error)
          else resolveRender(value)
        }
        /** @param {Jianying6VisibleRenderDriverError} error */
        function requestTermination(error) {
          if (settled || terminationError) return
          terminationError = error
          const terminateOwnedChild = () => {
            if (settled) return
            if (process.platform === 'win32' && child.pid) {
              const killer = spawn('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], {
                shell: false,
                stdio: 'ignore',
                windowsHide: true,
              })
              killer.once('error', () => child.kill('SIGKILL'))
              killer.once('close', () => {
                if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL')
              })
            } else {
              child.kill()
            }
            forceKillTimer = setTimeout(() => {
              if (!settled) child.kill('SIGKILL')
            }, 1_000)
            forceKillTimer.unref?.()
          }
          if (child.pid) terminateOwnedChild()
          else child.once('spawn', terminateOwnedChild)
        }
        const abort = () => {
          requestTermination(new Jianying6VisibleRenderDriverError('JY007_RENDER_CANCELLED'))
        }
        input.signal.addEventListener('abort', abort, { once: true })
        child.once('error', () => {
          finish(terminationError ?? new Jianying6VisibleRenderDriverError('JY007_DRIVER_START_FAILED'))
        })
        child.stdout?.on('data', (chunk) => {
          stdoutBytes += chunk.byteLength
          if (stdoutBytes > maxOutputBytes) {
            requestTermination(new Jianying6VisibleRenderDriverError('JY007_DRIVER_PROTOCOL_INVALID'))
            return
          }
          stdout += chunk.toString('utf8')
        })
        child.stderr?.on('data', (chunk) => {
          stderrBytes += chunk.byteLength
          if (stderrBytes <= maxOutputBytes) safeStderr += chunk.toString('utf8')
        })
        child.once('close', (code) => {
          if (settled) return
          if (terminationError) {
            finish(terminationError)
            return
          }
          if (code !== 0) {
            const reason = safeStderr.trim()
            finish(new Jianying6VisibleRenderDriverError(
              /^JY007_[A-Z0-9_]{1,100}$/u.test(reason)
                ? reason
                : 'JY007_VISIBLE_RENDER_FAILED',
            ))
            return
          }
          let result
          try {
            result = JSON.parse(stdout)
          } catch {
            finish(new Jianying6VisibleRenderDriverError('JY007_DRIVER_PROTOCOL_INVALID'))
            return
          }
          if (
            !exactKeys(result, ['focusStealObserved', 'schema_version', 'status']) ||
            result.schema_version !== 1 ||
            result.status !== 'completed' ||
            typeof result.focusStealObserved !== 'boolean'
          ) {
            finish(new Jianying6VisibleRenderDriverError('JY007_DRIVER_PROTOCOL_INVALID'))
            return
          }
          finish(null, structuredClone(result))
        })
        child.stdin?.end(JSON.stringify({
          draft_path: input.draftPath,
          executable_path: input.executablePath,
          executable_sha256: input.executableSha256,
          output_path: input.outputPath,
          schema_version: 1,
          timeout_ms: input.timeoutMs,
        }))
      })
    },
  })
}
