/** @param {string} code */
const safeError = (code) => {
  const error = /** @type {Error & {code: string}} */ (new Error(code))
  error.code = code
  return error
}
/** @param {unknown} input */
const assertCanonicalInput = (input) => {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw safeError('JY200_WRITER_INPUT_INVALID')
  const value = /** @type {Record<string, any>} */ (input)
  const timelineFingerprint = value.richTimeline?.revisionFingerprint ?? value.timeline_fingerprint
  if (typeof timelineFingerprint !== 'string' || !/^[a-f0-9]{32,128}$/iu.test(timelineFingerprint)) {
    throw safeError('JY200_TIMELINE_IDENTITY_INVALID')
  }
  if (value.admission_handle !== undefined) throw safeError('JY200_CALLER_ADMISSION_HANDLE_DENIED')
  if (value.staging_lease !== undefined) throw safeError('JY200_CALLER_LEASE_DENIED')
  if (value.staging_root !== undefined || value.draft_root !== undefined) throw safeError('JY200_CALLER_PATH_DENIED')
  return { value, timelineFingerprint }
}

/** @param {unknown} richTimeline @param {unknown} admittedCapabilities */
const deriveRequiredCapabilities = (richTimeline, admittedCapabilities) => {
  const requirements = /** @type {Record<string, any>} */ (richTimeline)?.capabilityRequirements
  if (!Array.isArray(requirements) || !Array.isArray(admittedCapabilities)) {
    throw safeError('JY200_WRITER_CAPABILITY_SET_INVALID')
  }
  const required = requirements
    .filter((entry) => entry?.acceptance === 'implemented')
    .map((entry) => entry?.capabilityId)
  if (required.length === 0 || required.some((capabilityId) => typeof capabilityId !== 'string') ||
      new Set(required).size !== required.length) {
    throw safeError('JY200_WRITER_CAPABILITY_SET_INVALID')
  }
  const admitted = new Set(admittedCapabilities)
  if (required.some((capabilityId) => !admitted.has(capabilityId))) {
    throw safeError('JY200_PROVIDER_CAPABILITY_UNSUPPORTED')
  }
  return Object.freeze([...required].sort())
}

/**
 * Create a Provider only from a server-owned current admission handle and a
 * Gateway-owned lease manager. The runner receives an opaque lease, never a
 * caller-selected path.
 * The trusted runner resolves only after its Provider process tree is fully
 * quiesced. The lease is then atomically sealed behind a Gateway-private name.
 * Publication recovery is delegated to a Gateway-owned durable authority keyed
 * by jobId. Provider process memory is never the only cleanup fact.
 * @param {{manifest: Record<string, unknown>, admissionHandle: unknown, admissionRegistry: {isCurrent: Function, describe: Function}, leaseManager: {create: Function, resolve: Function, seal: Function, owns: Function, release: Function}, run: (input: Record<string, unknown>, lease: unknown) => Promise<unknown>, readback: (input: Record<string, unknown>) => Promise<unknown>, publish: (input: Record<string, unknown>) => Promise<unknown>, rollbackPublish: (input: Record<string, unknown>) => Promise<boolean>, commitPublish: (input: Record<string, unknown>) => Promise<boolean>, canExportPackagingSelections?: ((richTimeline: Record<string, any>) => Promise<boolean> | boolean) | null, priority?: number}} options
 */
export const createExternalWriterProvider = ({ manifest, admissionHandle, admissionRegistry, leaseManager, run, readback, publish, rollbackPublish, commitPublish, canExportPackagingSelections = null, priority = 0 }) => {
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest) ||
      typeof manifest.provider !== 'string') throw safeError('JY200_MANIFEST_INVALID')
  if (!admissionRegistry || typeof admissionRegistry.isCurrent !== 'function' ||
      typeof admissionRegistry.describe !== 'function') throw safeError('JY200_ADMISSION_REGISTRY_REQUIRED')
  if (!leaseManager || typeof leaseManager.create !== 'function' || typeof leaseManager.resolve !== 'function' || typeof leaseManager.seal !== 'function' || typeof leaseManager.owns !== 'function' ||
      typeof leaseManager.release !== 'function') throw safeError('JY200_STAGING_LEASE_MANAGER_REQUIRED')
  if (typeof run !== 'function') throw safeError('JY200_PROVIDER_RUNNER_INVALID')
  if (typeof readback !== 'function') throw safeError('JY200_GATEWAY_READBACK_REQUIRED')
  if (typeof publish !== 'function') throw safeError('JY200_GATEWAY_PUBLISHER_REQUIRED')
  if (typeof rollbackPublish !== 'function') throw safeError('JY200_GATEWAY_PUBLISH_ROLLBACK_REQUIRED')
  if (typeof commitPublish !== 'function') throw safeError('JY200_GATEWAY_PUBLISH_COMMIT_REQUIRED')
  if (canExportPackagingSelections !== null && typeof canExportPackagingSelections !== 'function') {
    throw safeError('JY200_PROVIDER_PACKAGING_PREFLIGHT_INVALID')
  }
  if (!Number.isSafeInteger(priority)) throw safeError('JY200_PROVIDER_PRIORITY_INVALID')

  const providerId = manifest.provider
  const readCurrent = async () => {
    const description = await admissionRegistry.describe(admissionHandle)
    if (!description || description.provider !== providerId) throw safeError('JY200_PROVIDER_ADMISSION_STALE')
    return description
  }

  const provider = Object.freeze({
    id: providerId,
    priority,
    admissionHandle,
    async routingCandidate() {
      const description = await readCurrent()
      return { id: providerId, priority, admissionHandle, ownerIdentity: description.identity, writer: provider }
    },
    async canExportPackagingSelections(/** @type {Record<string, any>} */ richTimeline) {
      if (typeof canExportPackagingSelections !== 'function') return false
      await readCurrent()
      return await canExportPackagingSelections(richTimeline) === true
    },
    /** @param {Record<string, unknown>} input */
    async exportDraft(input) {
      const { value, timelineFingerprint } = assertCanonicalInput(input)
      const jobId = typeof value.jobId === 'string' ? value.jobId : null
      if (!jobId) throw safeError('JY200_WRITER_JOB_INVALID')
      await readCurrent()
      const lease = await leaseManager.create({ providerId })
      let publishReceipt = null
      try {
        const description = await readCurrent()
        if (!leaseManager.owns(lease)) throw safeError('JY200_STAGING_LEASE_NOT_OWNED')
        const requiredCapabilities = deriveRequiredCapabilities(value.richTimeline, description.capabilities)
        const trustedInput = Object.freeze({
          ...value,
          provider_id: description.provider,
          provider_commit: description.commit,
          timeline_fingerprint: timelineFingerprint,
          required_capabilities: requiredCapabilities,
        })
        const providerResult = await run(trustedInput, lease)
        if (!providerResult || typeof providerResult !== 'object' || Array.isArray(providerResult)) {
          throw safeError('JY200_PROVIDER_STAGING_RECEIPT_INVALID')
        }
        const stagingRoot = await leaseManager.seal(lease)
        const readbackReceipt = await readback(Object.freeze({
          stagingRoot,
          providerResult,
          timelineFingerprint,
          providerId: description.provider,
          providerCommit: description.commit,
          requiredCapabilities,
        }))
        if (!readbackReceipt || typeof readbackReceipt !== 'object' || Array.isArray(readbackReceipt) ||
            /** @type {Record<string, unknown>} */ (readbackReceipt).verified !== true ||
            /** @type {Record<string, unknown>} */ (readbackReceipt).timeline_fingerprint !== timelineFingerprint) {
          throw safeError('JY200_GATEWAY_READBACK_INVALID')
        }
        await readCurrent()
        const publishRoot = await leaseManager.resolve(lease)
        publishReceipt = await publish(Object.freeze({
          jobId,
          stagingRoot: publishRoot,
          providerResult,
          readbackReceipt,
          timelineFingerprint,
          providerId: description.provider,
          providerCommit: description.commit,
        }))
        if (!publishReceipt || typeof publishReceipt !== 'object' || Array.isArray(publishReceipt) ||
            /** @type {Record<string, unknown>} */ (publishReceipt).published !== true ||
            /** @type {Record<string, unknown>} */ (publishReceipt).atomic !== true) {
          throw safeError('JY200_GATEWAY_PUBLISH_INVALID')
        }
        await readCurrent()
        if (await leaseManager.release(lease) !== true) throw safeError('JY200_STAGING_RELEASE_FAILED')
        return Object.freeze({
          .../** @type {Record<string, unknown>} */ (publishReceipt),
          readback_receipt: readbackReceipt,
        })
      } catch (error) {
        if (publishReceipt && await rollbackPublish(Object.freeze({
          jobId,
          providerId,
          timelineFingerprint,
          publishReceipt,
        })).catch(() => false) !== true) {
          await leaseManager.release(lease).catch(() => {})
          throw safeError('JY200_GATEWAY_PUBLISH_ROLLBACK_FAILED')
        }
        await leaseManager.release(lease).catch(() => {})
        throw error
      }
    },
    /** @param {{jobId?: unknown}} input */
    async cleanupDraft(input) {
      const jobId = typeof input?.jobId === 'string' ? input.jobId : null
      if (!jobId) return false
      return rollbackPublish(Object.freeze({ jobId, providerId }))
    },
    /** @param {{jobId?: unknown}} input */
    async commitDraft(input) {
      const jobId = typeof input?.jobId === 'string' ? input.jobId : null
      if (!jobId) return false
      return commitPublish(Object.freeze({ jobId, providerId }))
    },
  })
  return provider
}
