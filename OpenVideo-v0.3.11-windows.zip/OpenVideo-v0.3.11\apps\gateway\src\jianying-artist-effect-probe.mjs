import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { lstat, readdir, realpath } from 'node:fs/promises'
import path from 'node:path'

import { readFileNoReparseBuffer, readFilesNoReparse } from './jianying-native-safe-file.mjs'
import { signPackagingResourceEvidenceRegistry, verifyPackagingResourceEvidenceSignature } from './jianying-packaging-resource-evidence.mjs'
import {
  computePackagingEntryBindingFingerprint,
  computePackagingResourceToken,
} from './jianying-packaging-resource-index.mjs'

const PAYLOAD_PROFILES = Object.freeze({
  sticker: Object.freeze({
    bucket: 'artistEffect',
    contracts: Object.freeze([
      Object.freeze(['config.json', 'ani_info.json', 'infoSticker.lua', 'SequenceMap.png']),
    ]),
  }),
  flower: Object.freeze({
    bucket: 'artistEffect',
    contracts: Object.freeze([
      Object.freeze(['config.json', 'effectStyle.json']),
      Object.freeze(['config.json', 'content.json', 'extra.json']),
    ]),
  }),
  video_effect: Object.freeze({
    bucket: 'effect',
    contracts: Object.freeze([
      Object.freeze(['config.json', 'extra.json']),
    ]),
  }),
})
const REQUIRED_PAYLOAD_FILES = PAYLOAD_PROFILES.sticker.contracts[0]
const MAX_PAYLOAD_ENTRIES = 256
const MAX_PAYLOAD_FILE_BYTES = 8 * 1024 * 1024
const MAX_PAYLOAD_TOTAL_BYTES = 16 * 1024 * 1024
const RESOURCE_ID = /^[A-Za-z0-9_-]{4,160}$/u
const RUN_ID = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u
const DRAFT_ID = /^OpenVideo-JY200-sticker-[0-9]{10,20}$/u
const FINGERPRINT = /^[a-f0-9]{64}$/u
const SIGNATURE = /^[A-Za-z0-9_-]{43}$/u
const PACKAGING_TOKEN = /^ovjsticker_v1_[a-f0-9]{24}$/u
const NUMERIC_RESOURCE_ID = /^[1-9][0-9]{3,18}$/u
const DRAFT_SUFFIX = path.join('Projects', 'com.lveditor.draft')
const JAVA_LONG_MAX = 9_223_372_036_854_775_807n

/** @param {string} root @param {string} candidate */
const inside = (root, candidate) => {
  const relative = path.relative(path.resolve(root), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

/** @param {Buffer|string} bytes */
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')

/** @param {unknown} value @returns {string} */
const canonicalJson = (value) => Array.isArray(value)
  ? `[${value.map(canonicalJson).join(',')}]`
  : !value || typeof value !== 'object'
    ? JSON.stringify(value)
    : `{${Object.keys(/** @type {Record<string, unknown>} */ (value)).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(/** @type {Record<string, unknown>} */ (value)[key])}`).join(',')}}`

/** Bind evidence to semantic JSON independent of whitespace/key-order rewrites. */
/** @param {unknown} draft */
export const fingerprintCanonicalJY200Draft = (draft) => sha256(canonicalJson(draft))

/** Sign JY-200 private evidence with the existing DPAPI-backed evidence key. */
/** @param {Record<string, any>} receipt @param {string} integrityKey */
export const signArtistEffectStickerReceipt = (receipt, integrityKey) => {
  if (!FINGERPRINT.test(integrityKey ?? '')) throw new Error('JY200_EVIDENCE_INTEGRITY_KEY_INVALID')
  return signPackagingResourceEvidenceRegistry(receipt, integrityKey)
}

/** @param {Record<string, any>} receipt @param {string} integrityKey */
export const verifyArtistEffectStickerReceiptSignature = (receipt, integrityKey) => {
  if (!FINGERPRINT.test(integrityKey ?? '') || !SIGNATURE.test(receipt?.integrity_signature ?? '')) return false
  return verifyPackagingResourceEvidenceSignature(receipt, integrityKey)
}

/** Never allow filesystem, process or private identifier text into probe output. */
/** @param {unknown} error */
export const sanitizeJY200ProbeError = (error) => {
  const message = error instanceof Error ? error.message : ''
  return /^JY200_[A-Z0-9_]+$/u.test(message) ? message : 'JY200_STICKER_PROBE_FAILED'
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats|Record<string, any>} metadata */
const objectIdentity = (metadata) => {
  if ((typeof metadata?.dev !== 'number' && typeof metadata?.dev !== 'bigint') ||
      (typeof metadata?.ino !== 'number' && typeof metadata?.ino !== 'bigint')) return null
  return `${metadata.dev}:${metadata.ino}`
}

/**
 * Windows realpath may return an 8.3 alias. A different spelling is safe only
 * when both names still identify the same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {typeof lstat} inspect
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats|Record<string, any>} [requestedMetadata]
 */
const sameResolvedObject = async (requested, actual, inspect, requestedMetadata = undefined) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const [expected, observed] = await Promise.all([
    requestedMetadata ?? inspect(requested, { bigint: true }),
    inspect(actual, { bigint: true }),
  ])
  const expectedIdentity = objectIdentity(expected)
  return expectedIdentity !== null && expectedIdentity === objectIdentity(observed)
}

/**
 * Validate a Gateway-owned private staging root. Every existing component must
 * be an ordinary directory and the canonical tree must stay below runtime data
 * while remaining disjoint from the live Jianying draft root.
 * @param {{runtimeRoot: string, stagingRoot: string, liveDraftRoot: string, inspect?: typeof lstat, resolveReal?: typeof realpath}} input
 */
export const validateJY200ProbeStagingRoot = async ({ runtimeRoot, stagingRoot, liveDraftRoot, inspect = lstat, resolveReal = realpath }) => {
  if (![runtimeRoot, stagingRoot, liveDraftRoot].every((value) => typeof value === 'string' && path.isAbsolute(value))) {
    throw new Error('JY200_STAGING_ROOT_UNSAFE')
  }
  const runtime = path.resolve(runtimeRoot)
  const staging = path.resolve(stagingRoot)
  const live = path.resolve(liveDraftRoot)
  if (!inside(runtime, staging) || inside(live, staging) || inside(staging, live)) throw new Error('JY200_STAGING_ROOT_UNSAFE')
  try {
    const [runtimeMetadata, stagingMetadata, liveMetadata, runtimeReal, stagingReal, liveReal] = await Promise.all([
      inspect(runtime, { bigint: true }), inspect(staging, { bigint: true }), inspect(live, { bigint: true }),
      resolveReal(runtime), resolveReal(staging), resolveReal(live),
    ])
    if (![runtimeMetadata, stagingMetadata, liveMetadata].every((metadata) => metadata.isDirectory() && !metadata.isSymbolicLink?.()) ||
        !await sameResolvedObject(runtime, runtimeReal, inspect, runtimeMetadata) ||
        !await sameResolvedObject(staging, stagingReal, inspect, stagingMetadata) ||
        !await sameResolvedObject(live, liveReal, inspect, liveMetadata) ||
        !inside(runtimeReal, stagingReal) || inside(liveReal, stagingReal) || inside(stagingReal, liveReal)) {
      throw new Error('JY200_STAGING_ROOT_UNSAFE')
    }
    const relative = path.relative(runtime, staging)
    let cursor = runtime
    for (const fragment of ['', ...relative.split(path.sep).filter(Boolean)]) {
      if (fragment) cursor = path.join(cursor, fragment)
      const metadata = await inspect(cursor)
      if (!metadata.isDirectory() || metadata.isSymbolicLink?.()) throw new Error('JY200_STAGING_ROOT_UNSAFE')
    }
    return Object.freeze({ runtimeRoot: runtimeReal, stagingRoot: stagingReal, liveDraftRoot: liveReal })
  } catch (error) {
    if (error instanceof Error && error.message === 'JY200_STAGING_ROOT_UNSAFE') throw error
    throw new Error('JY200_STAGING_ROOT_UNSAFE')
  }
}

/**
 * Validate every Writer-created artifact before readback, publish or recursive
 * cleanup. A Writer cannot turn a previously safe staging directory into a
 * junction-based escape after the root check has completed.
 * @param {{stagingRoot: string, artifactRoot: string, inspect?: typeof lstat, list?: typeof readdir, resolveReal?: typeof realpath, maxEntries?: number}} input
 */
export const validateJY200ProbeArtifactTree = async ({ stagingRoot, artifactRoot, inspect = lstat, list = readdir, resolveReal = realpath, maxEntries = 256 }) => {
  if (![stagingRoot, artifactRoot].every((value) => typeof value === 'string' && path.isAbsolute(value)) ||
      !Number.isInteger(maxEntries) || maxEntries < 1 || maxEntries > 4096) throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
  const staging = path.resolve(stagingRoot)
  const artifact = path.resolve(artifactRoot)
  if (!inside(staging, artifact) || samePath(staging, artifact)) throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
  try {
    const [stagingMetadata, artifactMetadata, stagingReal, artifactReal] = await Promise.all([
      inspect(staging, { bigint: true }), inspect(artifact, { bigint: true }), resolveReal(staging), resolveReal(artifact),
    ])
    if (!stagingMetadata.isDirectory() || stagingMetadata.isSymbolicLink?.() ||
        !artifactMetadata.isDirectory() || artifactMetadata.isSymbolicLink?.() ||
        !await sameResolvedObject(staging, stagingReal, inspect, stagingMetadata) ||
        !await sameResolvedObject(artifact, artifactReal, inspect, artifactMetadata) || !inside(stagingReal, artifactReal)) {
      throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
    }
    const pending = [artifact]
    let visited = 0
    while (pending.length > 0) {
      const current = /** @type {string} */ (pending.pop())
      if (++visited > maxEntries) throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
      const [metadata, currentReal] = await Promise.all([inspect(current, { bigint: true }), resolveReal(current)])
      if (metadata.isSymbolicLink?.() || (!metadata.isDirectory() && !metadata.isFile()) ||
          (metadata.isFile() && Number(metadata.nlink ?? 1) !== 1) ||
          !await sameResolvedObject(current, currentReal, inspect, metadata) ||
          !inside(artifactReal, currentReal)) throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
      if (!metadata.isDirectory()) continue
      const entries = await list(current, { withFileTypes: true })
      for (const entry of entries) {
        if (!entry || typeof entry.name !== 'string' || entry.name === '' || entry.name === '.' || entry.name === '..' ||
            entry.isSymbolicLink?.() || (!entry.isDirectory?.() && !entry.isFile?.())) throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
        pending.push(path.join(current, entry.name))
      }
    }
    return Object.freeze({ stagingRoot: stagingReal, artifactRoot: artifactReal, entries: visited })
  } catch (error) {
    if (error instanceof Error && error.message === 'JY200_ARTIFACT_TREE_UNSAFE') throw error
    throw new Error('JY200_ARTIFACT_TREE_UNSAFE')
  }
}

/**
 * Resolve only the launcher-selected Python executable. PATH lookup and
 * reparse-backed executables are not valid for the third-party Writer probe.
 * @param {{executable: unknown, inspect?: typeof lstat, resolveReal?: typeof realpath}} input
 */
export const validateJY200PythonExecutable = async ({ executable, inspect = lstat, resolveReal = realpath }) => {
  if (typeof executable !== 'string' || executable.trim() !== executable || !path.isAbsolute(executable)) {
    throw new Error('JY200_PYTHON_EXECUTABLE_UNTRUSTED')
  }
  const resolved = path.resolve(executable)
  try {
    const [metadata, canonical] = await Promise.all([inspect(resolved), resolveReal(resolved)])
    if (!metadata.isFile() || metadata.isSymbolicLink?.() ||
        !await sameResolvedObject(resolved, canonical, inspect, metadata)) {
      throw new Error('JY200_PYTHON_EXECUTABLE_UNTRUSTED')
    }
    return canonical
  } catch (error) {
    if (error instanceof Error && error.message === 'JY200_PYTHON_EXECUTABLE_UNTRUSTED') throw error
    throw new Error('JY200_PYTHON_EXECUTABLE_UNTRUSTED')
  }
}

const WRITER_ENVIRONMENT_KEYS = Object.freeze(['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP'])

/** @param {NodeJS.ProcessEnv} source @param {string} pythonPath */
export const createJY200WriterEnvironment = (source, pythonPath) => {
  if (typeof pythonPath !== 'string' || !path.isAbsolute(pythonPath)) throw new Error('JY200_WRITER_ENVIRONMENT_INVALID')
  /** @type {NodeJS.ProcessEnv} */
  const environment = {}
  for (const expected of WRITER_ENVIRONMENT_KEYS) {
    const actual = Object.keys(source).find((key) => key.toLowerCase() === expected.toLowerCase())
    if (actual && typeof source[actual] === 'string') environment[expected] = source[actual]
  }
  environment.PYTHONPATH = pythonPath
  environment.PYTHONNOUSERSITE = '1'
  environment.PYTHONDONTWRITEBYTECODE = '1'
  return Object.freeze(environment)
}

/** @param {import('node:child_process').ChildProcess} child @param {typeof spawn} [spawnImpl] @param {number} [timeoutMs] @returns {Promise<void>} */
export const terminateJY200ProbeProcessTree = (child, spawnImpl = spawn, timeoutMs = 2_000) => new Promise((resolve) => {
  if (!child.pid) { resolve(); return }
  if (process.platform === 'win32') {
    const killer = spawnImpl('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
    let settled = false
    const finish = () => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      try { if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL') } catch {}
      try { if (killer.exitCode === null && killer.signalCode === null) killer.kill('SIGKILL') } catch {}
      resolve()
    }
    const timer = setTimeout(finish, Math.max(1, Math.min(timeoutMs, 10_000)))
    killer.once('error', finish)
    killer.once('close', finish)
    return
  }
  try { process.kill(-child.pid, 'SIGKILL') } catch { try { child.kill('SIGKILL') } catch {} }
  resolve()
})

/**
 * Run the dev-only Writer with a bounded lifetime and bounded output. Both
 * streams are drained, but their private contents are never returned/logged.
 * @param {{command: string, args: string[], cwd: string, env: NodeJS.ProcessEnv, input: unknown, timeoutMs?: number, maxOutputBytes?: number, spawnImpl?: typeof spawn, terminateImpl?: (child: import('node:child_process').ChildProcess) => Promise<void>}} input
 * @returns {Promise<void>}
 */
export const runBoundedJY200ProbeProcess = ({ command, args, cwd, env, input, timeoutMs = 30_000, maxOutputBytes = 64 * 1024, spawnImpl = spawn, terminateImpl = terminateJY200ProbeProcessTree }) => new Promise((resolve, reject) => {
  const child = spawnImpl(command, args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, detached: process.platform !== 'win32' })
  let settled = false
  let outputBytes = 0
  /** @type {Error|null} */
  let forcedError = null
  /** @type {Promise<void>|null} */
  let termination = null
  const terminate = () => (termination ??= terminateImpl(child))
  /** @param {Error|null} error */
  const finish = (error) => {
    if (settled) return
    settled = true
    clearTimeout(timer)
    if (error) reject(error)
    else resolve(undefined)
  }
  /** @param {Buffer|string} chunk */
  const consume = (chunk) => {
    outputBytes += Buffer.isBuffer(chunk) ? chunk.byteLength : Buffer.byteLength(String(chunk))
    if (outputBytes > maxOutputBytes && !settled && !forcedError) {
      forcedError = new Error('JY200_STICKER_WRITER_OUTPUT_LIMIT')
      void terminate().finally(() => finish(forcedError))
    }
  }
  child.stdout?.on('data', consume)
  child.stderr?.on('data', consume)
  child.once('error', () => finish(new Error('JY200_STICKER_WRITER_UNAVAILABLE')))
  child.once('close', (code, signal) => {
    if (settled) return
    if (forcedError) { void terminate().finally(() => finish(forcedError)); return }
    if (code !== 0 || signal !== null) finish(new Error('JY200_STICKER_WRITER_FAILED'))
    else finish(null)
  })
  const timer = setTimeout(() => {
    if (!settled && !forcedError) {
      forcedError = new Error('JY200_STICKER_WRITER_TIMEOUT')
      void terminate().finally(() => finish(forcedError))
    }
  }, Math.max(1, Math.min(timeoutMs, 120_000)))
  child.stdin?.once('error', () => {})
  child.stdin?.end(JSON.stringify(input))
})

/**
 * Locate a downloaded Jianying-managed packaging payload without exposing its
 * path or raw identifiers. This is a Gate-A dev-only probe; callers must not
 * promote its result to catalog admission.
 * @param {{desktop: {available?: boolean, draftRoot: string}, resourceId: string, family?: 'sticker'|'flower'|'video_effect', read?: typeof readFileNoReparseBuffer, readBatch?: typeof readFilesNoReparse, list?: typeof readdir, inspect?: typeof lstat, resolveReal?: typeof realpath}} input
 * @returns {Promise<{evidence: {mode: 'jianying_managed', family: 'sticker'|'flower'|'video_effect', resourceIdFingerprint: string, payloadFingerprint: string, files: readonly string[], probeCandidate: true}, resourceId: string, payloadRoot: string, values: Readonly<Record<string, Buffer>>}|null>}
 */
const inspectArtistEffectPayload = async ({ desktop, resourceId, family = 'sticker', read = undefined, readBatch = readFilesNoReparse, list = readdir, inspect = lstat, resolveReal = realpath }) => {
  const profile = PAYLOAD_PROFILES[family]
  if (desktop?.available !== true || typeof desktop.draftRoot !== 'string' ||
      !path.isAbsolute(desktop.draftRoot) || !desktop.draftRoot.toLowerCase().endsWith(DRAFT_SUFFIX.toLowerCase()) ||
      !profile || typeof resourceId !== 'string' || !RESOURCE_ID.test(resourceId)) return null
  const userDataRoot = path.resolve(desktop.draftRoot, '..', '..')
  const cacheRoot = path.join(userDataRoot, 'Cache', profile.bucket)
  const resourceRoot = path.join(cacheRoot, resourceId)
  try {
    const [rootStat, rootReal, cacheReal] = await Promise.all([inspect(resourceRoot, { bigint: true }), resolveReal(resourceRoot), resolveReal(cacheRoot)])
    if (!rootStat.isDirectory() || rootStat.isSymbolicLink?.() || !inside(cacheReal, rootReal) ||
        !await sameResolvedObject(resourceRoot, rootReal, inspect, rootStat)) return null
    const children = await list(resourceRoot, { withFileTypes: true })
    const candidates = children
      .filter((entry) => entry.isDirectory?.() && !entry.isSymbolicLink?.())
      .map((entry) => entry.name)
      .sort()
      .slice(0, 16)
    for (const child of candidates) {
      const payloadRoot = path.join(resourceRoot, child)
      const [payloadMetadata, payloadReal] = await Promise.all([inspect(payloadRoot, { bigint: true }), resolveReal(payloadRoot)])
      if (!payloadMetadata.isDirectory?.() || payloadMetadata.isSymbolicLink?.() ||
          !inside(rootReal, payloadReal) || !await sameResolvedObject(payloadRoot, payloadReal, inspect, payloadMetadata)) continue
      /** @type {Array<{relativePath: string, filePath: string, size: number, bytes?: Buffer}>} */
      const payload = []
      const pending = [payloadRoot]
      let entries = 0
      let totalBytes = 0
      let unsafe = false
      while (pending.length > 0 && !unsafe) {
        const current = /** @type {string} */ (pending.pop())
        const currentEntries = await list(current, { withFileTypes: true })
        for (const entry of currentEntries.sort((left, right) => left.name.localeCompare(right.name))) {
          if (++entries > MAX_PAYLOAD_ENTRIES || entry.isSymbolicLink?.() ||
              (!entry.isDirectory?.() && !entry.isFile?.())) { unsafe = true; break }
          const target = path.join(current, entry.name)
          const [metadata, canonical] = await Promise.all([inspect(target, { bigint: true }), resolveReal(target)])
          if (metadata.isSymbolicLink?.() || !await sameResolvedObject(target, canonical, inspect, metadata) ||
              !inside(payloadReal, canonical)) {
            unsafe = true
            break
          }
          if (entry.isDirectory?.()) {
            if (!metadata.isDirectory?.()) { unsafe = true; break }
            pending.push(target)
            continue
          }
          const size = Number(metadata.size ?? 0)
          const links = Number(metadata.nlink ?? 1)
          if (!metadata.isFile?.() || links !== 1 || !Number.isSafeInteger(size) || size < 0 ||
              size > MAX_PAYLOAD_FILE_BYTES || totalBytes + size > MAX_PAYLOAD_TOTAL_BYTES) {
            unsafe = true
            break
          }
          totalBytes += size
          payload.push({ relativePath: path.relative(payloadRoot, target).split(path.sep).join('/'), filePath: target, size })
        }
      }
      if (unsafe || payload.length === 0) continue
      payload.sort((left, right) => left.relativePath.localeCompare(right.relativePath))
      const rootFiles = new Set(payload.filter(({ relativePath }) => !relativePath.includes('/')).map(({ relativePath }) => relativePath))
      const matchedContract = profile.contracts.find((contract) => contract.every((fileName) => rootFiles.has(fileName)))
      if (!matchedContract) continue
      const values = typeof read === 'function'
        ? await Promise.all(payload.map(({ filePath }) => read(filePath, payloadRoot, MAX_PAYLOAD_FILE_BYTES)))
        : await readBatch(payload.map(({ filePath }) => ({ path: filePath, rootPath: payloadRoot })), {
            maxFileBytes: MAX_PAYLOAD_FILE_BYTES,
            maxTotalBytes: MAX_PAYLOAD_TOTAL_BYTES,
            asBuffer: true,
          })
      const digest = createHash('sha256')
      for (const [index, { relativePath, size }] of payload.entries()) {
        const value = values[index]
        const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value)
        if (bytes.byteLength !== size) throw new Error('JY200_PAYLOAD_IDENTITY_DRIFT')
        digest.update(String(Buffer.byteLength(relativePath))).update(':').update(relativePath)
        digest.update(':').update(String(bytes.byteLength)).update(':').update(bytes)
      }
      const evidence = Object.freeze({
        mode: 'jianying_managed',
        family,
        resourceIdFingerprint: sha256(resourceId),
        payloadFingerprint: digest.digest('hex'),
        files: Object.freeze([...matchedContract]),
        probeCandidate: true,
      })
      return Object.freeze({
        evidence,
        resourceId,
        payloadRoot,
        values: Object.freeze(Object.fromEntries(payload.map(({ relativePath }, index) => [relativePath, Buffer.from(values[index])]))),
      })
    }
  } catch { return null }
  return null
}

/**
 * Locate a downloaded Jianying-managed packaging payload without exposing its
 * path or raw identifiers. This is a Gate-A dev-only probe; callers must not
 * promote its result to catalog admission.
 * @param {Parameters<typeof inspectArtistEffectPayload>[0]} input
 */
export const probeArtistEffectPayload = async (input) => (await inspectArtistEffectPayload(input))?.evidence ?? null

/** @param {unknown} value @param {string} code */
const requireFingerprint = (value, code) => {
  if (typeof value !== 'string' || !FINGERPRINT.test(value)) throw new Error(code)
  return value
}

/** @param {unknown} value @param {string} code */
const requireRecord = (value, code) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(code)
  return /** @type {Record<string, any>} */ (value)
}

/** @param {Buffer|undefined} bytes @param {string} code */
const parsePrivateJson = (bytes, code) => {
  if (!Buffer.isBuffer(bytes) || bytes.byteLength === 0) throw new Error(code)
  try { return requireRecord(JSON.parse(bytes.toString('utf8')), code) } catch { throw new Error(code) }
}

/**
 * Resolve one discovery-only Catalog entry into the exact private JyResource
 * file consumed by the pinned Duo Writer. This is intentionally probe-only:
 * the public evidence remains deferred and cannot change Catalog eligibility.
 *
 * @param {{
 *   desktop: {available?: boolean, draftRoot: string},
 *   profileId: string,
 *   appVersion: string,
 *   catalogEntry: Record<string, any>,
 *   sourceMaterial: Record<string, any>,
 *   expectedIdentity: {sourceFingerprint: string, catalogFingerprint: string, desktopBindingFingerprint: string},
 *   currentIdentity: {sourceFingerprint: string, catalogFingerprint: string, desktopBindingFingerprint: string},
 *   read?: typeof readFileNoReparseBuffer,
 *   readBatch?: typeof readFilesNoReparse,
 *   list?: typeof readdir,
 *   inspect?: typeof lstat,
 *   resolveReal?: typeof realpath,
 * }} input
 */
export const resolveDuoLocalJyResourceProbeBinding = async ({
  desktop,
  profileId,
  appVersion,
  catalogEntry,
  sourceMaterial,
  expectedIdentity,
  currentIdentity,
  read = undefined,
  readBatch = readFilesNoReparse,
  list = readdir,
  inspect = lstat,
  resolveReal = realpath,
}) => {
  const entry = requireRecord(catalogEntry, 'JY200_DUO_CATALOG_BINDING_INVALID')
  const material = requireRecord(sourceMaterial, 'JY200_DUO_SOURCE_MATERIAL_INVALID')
  const expected = requireRecord(expectedIdentity, 'JY200_DUO_EVIDENCE_IDENTITY_INVALID')
  const current = requireRecord(currentIdentity, 'JY200_DUO_EVIDENCE_IDENTITY_INVALID')
  for (const key of ['sourceFingerprint', 'catalogFingerprint', 'desktopBindingFingerprint']) {
    if (requireFingerprint(expected[key], 'JY200_DUO_EVIDENCE_IDENTITY_INVALID') !==
        requireFingerprint(current[key], 'JY200_DUO_EVIDENCE_IDENTITY_INVALID')) {
      throw new Error('JY200_DUO_EVIDENCE_IDENTITY_STALE')
    }
  }
  if (!['sticker', 'flower', 'video_effect'].includes(entry.family) || entry.state !== 'discoverable' ||
      entry.writer_eligible !== false || typeof profileId !== 'string' || typeof appVersion !== 'string') {
    throw new Error('JY200_DUO_CATALOG_BINDING_INVALID')
  }
  const binding = requireRecord(entry.private_binding, 'JY200_DUO_CATALOG_BINDING_INVALID')
  const resourceId = binding.resourceId
  const effectId = binding.effectId
  if (typeof resourceId !== 'string' || !NUMERIC_RESOURCE_ID.test(resourceId) || BigInt(resourceId) > JAVA_LONG_MAX ||
      (entry.family !== 'sticker' && (typeof effectId !== 'string' || effectId.length < 4 || effectId.length > 160)) ||
      entry.packaging_token !== computePackagingResourceToken({ family: entry.family, profileId, appVersion, privateBinding: binding })) {
    throw new Error('JY200_DUO_CATALOG_BINDING_INVALID')
  }
  if (material.resource_id !== resourceId ||
      (entry.family !== 'sticker' && material.effect_id !== effectId) ||
      (entry.family === 'sticker' && material.type !== 'sticker') ||
      (entry.family === 'flower' && material.type !== 'text_effect') ||
      (entry.family === 'video_effect' && material.type !== 'video_effect')) {
    throw new Error('JY200_DUO_SOURCE_MATERIAL_MISMATCH')
  }
  const payload = await inspectArtistEffectPayload({
    desktop, resourceId, family: entry.family, read, readBatch, list, inspect, resolveReal,
  })
  if (!payload) throw new Error('JY200_DUO_LOCAL_PAYLOAD_UNAVAILABLE')

  let mainConfig
  let effect
  if (entry.family === 'flower') {
    const style = parsePrivateJson(payload.values['effectStyle.json'], 'JY200_DUO_FLOWER_STYLE_UNAVAILABLE')
    mainConfig = canonicalJson(style)
    effect = canonicalJson(material)
  } else {
    mainConfig = canonicalJson(material)
  }
  const bindingFingerprint = computePackagingEntryBindingFingerprint({ family: entry.family, privateBinding: binding })
  const sourceMaterialFingerprint = sha256(canonicalJson(material))
  const jyResource = Object.freeze({
    id: resourceId,
    name: 'OpenVideo private local resource',
    resourceId,
    type: entry.family,
    status: 1,
    mainConfig,
    ...(effect ? { effect } : {}),
    resources: Object.freeze([]),
  })
  const publicEvidence = Object.freeze({
    schema_version: 1,
    kind: 'jy200_duo_local_resource_probe_candidate',
    family: entry.family,
    packaging_token: entry.packaging_token,
    binding_fingerprint: bindingFingerprint,
    source_material_fingerprint: sourceMaterialFingerprint,
    payload_fingerprint: payload.evidence.payloadFingerprint,
    source_fingerprint: current.sourceFingerprint,
    catalog_fingerprint: current.catalogFingerprint,
    desktop_binding_fingerprint: current.desktopBindingFingerprint,
    resource_mode: 'jianying_managed',
    admission: 'deferred',
    writer_eligible: false,
    probe_candidate: true,
  })
  return Object.freeze({
    resourceType: entry.family,
    resourceId,
    effectId,
    relativeConfigPath: `${entry.family}/${resourceId}.json`,
    jyResource,
    publicEvidence,
  })
}

/**
 * Verify the post-save shape of the isolated Sticker probe without returning
 * raw draft or resource identifiers. This remains dev-only evidence and does
 * not grant catalog admission.
 * @param {{draft: unknown, expectedResourceIdFingerprint: string, initialRotation: number, expectedRotation: number}} input
 * @returns {{materials: 1, tracks: 1, segments: 1, rotation: number}|null}
 */
export const inspectArtistEffectStickerLifecycle = ({ draft, expectedResourceIdFingerprint, initialRotation, expectedRotation }) => {
  if (!/^[a-f0-9]{64}$/u.test(expectedResourceIdFingerprint) ||
      !Number.isFinite(initialRotation) || !Number.isFinite(expectedRotation) || expectedRotation === initialRotation) return null
  const candidate = /** @type {any} */ (draft)
  const stickers = Array.isArray(candidate?.materials?.stickers) ? candidate.materials.stickers : []
  const tracks = Array.isArray(candidate?.tracks)
    ? candidate.tracks.filter((/** @type {any} */ track) => track?.type === 'sticker')
    : []
  const segments = tracks.flatMap((/** @type {any} */ track) => Array.isArray(track?.segments) ? track.segments : [])
  const material = stickers[0]
  const segment = segments[0]
  if (stickers.length !== 1 || tracks.length !== 1 || segments.length !== 1 ||
      typeof material?.id !== 'string' || segment?.material_id !== material.id ||
      typeof material?.resource_id !== 'string' || sha256(material.resource_id) !== expectedResourceIdFingerprint ||
      segment?.clip?.rotation !== expectedRotation) return null
  return Object.freeze({ materials: 1, tracks: 1, segments: 1, rotation: expectedRotation })
}

/**
 * Parse the immutable direct-probe receipt used as the parent of lifecycle
 * evidence. Nested shapes are exact so omitted flags or caller extensions do
 * not become an admission shortcut.
 * @param {unknown} value
 * @param {string} expectedRunId
 * @param {string} integrityKey
 * @returns {Readonly<Record<string, any>>|null}
 */
export const parseArtistEffectStickerProbeReceipt = (value, expectedRunId, integrityKey) => {
  const source = /** @type {any} */ (value)
  /** @param {unknown} candidate @param {readonly string[]} keys */
  const exactKeys = (candidate, keys) => candidate && typeof candidate === 'object' &&
    Object.keys(/** @type {Record<string, unknown>} */ (candidate)).sort().join('\0') === [...keys].sort().join('\0')
  const expectedKeys = ['schema_version', 'kind', 'run_id', 'status', 'admission', 'writer_eligible', 'resource_mode', 'packaging_token', 'resource_id_fingerprint', 'payload_fingerprint', 'catalog_fingerprint', 'desktop_binding_fingerprint', 'writer', 'readback', 'publish', 'lifecycle', 'integrity_revision', 'integrity_signature']
  if (!RUN_ID.test(expectedRunId) || !exactKeys(source, expectedKeys) ||
      source.schema_version !== 1 || source.kind !== 'jy200_sticker_probe_candidate' || source.run_id !== expectedRunId ||
      source.status !== 'probed' || source.admission !== 'deferred' || source.writer_eligible !== false ||
      !exactKeys(source.writer, ['provider', 'commit', 'license']) ||
      source.resource_mode !== 'jianying_managed' || !PACKAGING_TOKEN.test(source.packaging_token ?? '') ||
      !exactKeys(source.readback, ['ok', 'materials', 'tracks', 'segments', 'draft_fingerprint', 'initial_rotation', 'initial_plaintext_fingerprint']) ||
      !exactKeys(source.publish, ['requested', 'completed', 'draft_id']) ||
      !exactKeys(source.lifecycle, ['opened', 'edited', 'saved', 'closed', 'reopened']) ||
      source.publish.requested !== true || source.publish.completed !== true || !DRAFT_ID.test(source.publish.draft_id ?? '') ||
      source.readback.ok !== true || source.readback.materials !== 1 || source.readback.tracks !== 1 || source.readback.segments !== 1 ||
      !Number.isFinite(source.readback.initial_rotation) || !FINGERPRINT.test(source.readback.initial_plaintext_fingerprint ?? '') ||
      !FINGERPRINT.test(source.readback.draft_fingerprint ?? '') || source.integrity_revision !== 1 ||
      !FINGERPRINT.test(source.resource_id_fingerprint ?? '') || !FINGERPRINT.test(source.payload_fingerprint ?? '') ||
      !FINGERPRINT.test(source.catalog_fingerprint ?? '') || !FINGERPRINT.test(source.desktop_binding_fingerprint ?? '') ||
      Object.values(source.lifecycle).some((flag) => flag !== false) ||
      !verifyArtistEffectStickerReceiptSignature(source, integrityKey)) return null
  return Object.freeze(source)
}

/** @param {unknown} value @param {string} expectedRunId @param {string} integrityKey */
export const parseArtistEffectStickerLifecycleReceipt = (value, expectedRunId, integrityKey) => {
  const receipt = /** @type {any} */ (value)
  const keys = [
    'schema_version', 'kind', 'source_run_id', 'source_receipt_fingerprint', 'admission', 'writer_eligible',
    'profile_id', 'app_version', 'catalog_fingerprint', 'desktop_binding_fingerprint', 'packaging_token',
    'resource_id_fingerprint', 'payload_fingerprint', 'draft_id_fingerprint', 'initial_plaintext_fingerprint',
    'post_save_plaintext_fingerprint', 'draft_content_fingerprint', 'scheme', 'readback', 'manual_attestation',
    'opened', 'edited', 'saved', 'closed', 'reopened', 'same_draft', 'persisted_rotation', 'verified_at',
    'integrity_revision', 'integrity_signature',
  ]
  const exact = receipt && typeof receipt === 'object' && Object.keys(receipt).sort().join('\0') === [...keys].sort().join('\0')
  const readbackKeys = ['materials', 'tracks', 'segments', 'rotation']
  if (!exact || !RUN_ID.test(expectedRunId) || receipt.source_run_id !== expectedRunId ||
      receipt.schema_version !== 1 || receipt.kind !== 'jy200_sticker_probe_lifecycle' || receipt.admission !== 'deferred' ||
      receipt.writer_eligible !== false || receipt.scheme !== 'encrypt_v2' || receipt.integrity_revision !== 1 ||
      !PACKAGING_TOKEN.test(receipt.packaging_token ?? '') || !['source_receipt_fingerprint', 'catalog_fingerprint',
        'desktop_binding_fingerprint', 'resource_id_fingerprint', 'payload_fingerprint', 'draft_id_fingerprint',
        'initial_plaintext_fingerprint', 'post_save_plaintext_fingerprint', 'draft_content_fingerprint'].every((key) => FINGERPRINT.test(receipt[key] ?? '')) ||
      receipt.initial_plaintext_fingerprint === receipt.post_save_plaintext_fingerprint ||
      !receipt.readback || Object.keys(receipt.readback).sort().join('\0') !== readbackKeys.sort().join('\0') ||
      receipt.readback.materials !== 1 || receipt.readback.tracks !== 1 || receipt.readback.segments !== 1 ||
      !Number.isFinite(receipt.readback.rotation) || receipt.persisted_rotation !== receipt.readback.rotation ||
      receipt.manual_attestation !== 'opened-edited-saved-closed-reopened' ||
      !['opened', 'edited', 'saved', 'closed', 'reopened', 'same_draft'].every((key) => receipt[key] === true) ||
      Number.isNaN(Date.parse(receipt.verified_at)) || !verifyArtistEffectStickerReceiptSignature(receipt, integrityKey)) return null
  return Object.freeze(receipt)
}

const identityKeys = Object.freeze([
  'desktopBindingFingerprint', 'catalogFingerprint', 'packagingToken', 'resourceIdFingerprint',
  'payloadFingerprint', 'encryptedDraftFingerprint',
])

/**
 * Compare the complete private identity immediately before evidence publication.
 * @param {unknown} expected
 * @param {unknown} observed
 */
export const assertJY200StickerEvidenceIdentityStable = (expected, observed) => {
  const left = /** @type {any} */ (expected)
  const right = /** @type {any} */ (observed)
  const valid = [left, right].every((candidate) => candidate && typeof candidate === 'object' &&
    Object.keys(candidate).sort().join('\0') === [...identityKeys].sort().join('\0') &&
    FINGERPRINT.test(candidate.desktopBindingFingerprint ?? '') && FINGERPRINT.test(candidate.catalogFingerprint ?? '') &&
    PACKAGING_TOKEN.test(candidate.packagingToken ?? '') && FINGERPRINT.test(candidate.resourceIdFingerprint ?? '') &&
    FINGERPRINT.test(candidate.payloadFingerprint ?? '') && FINGERPRINT.test(candidate.encryptedDraftFingerprint ?? ''))
  if (!valid || identityKeys.some((key) => left[key] !== right[key])) throw new Error('JY200_STICKER_PROBE_IDENTITY_DRIFT')
  return Object.freeze({ ...right })
}

export const artistEffectProbeRequiredFiles = REQUIRED_PAYLOAD_FILES
export const jianyingManagedPayloadProfiles = PAYLOAD_PROFILES
