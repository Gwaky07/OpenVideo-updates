import { createHash, randomUUID } from 'node:crypto'
import { spawn } from 'node:child_process'
import {
  lstat,
  mkdir,
  readFile,
  readdir,
  rm,
  writeFile,
} from 'node:fs/promises'
import { isAbsolute, join, relative, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

import {
  createCreativeSfxPromotionReceipt,
  fingerprintCreativeSfxDesktop,
  publishCreativeSfxPromotionReceipt,
} from '../apps/gateway/src/creative-sfx-promotion.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'

const fingerprintPattern = /^[a-f0-9]{64}$/u
const terminalStatuses = new Set(['succeeded', 'failed', 'cancelled', 'timed_out'])
const evidenceRelativeRoot = 'evidence/creative-sfx'
const pollIntervalMs = 1_000
const timeoutMs = 30 * 60_000

const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const inside = (parent, child) => {
  const fragment = relative(resolve(parent), resolve(child))
  return fragment !== '' && !fragment.startsWith('..') && !isAbsolute(fragment)
}
const wait = (milliseconds) => new Promise((accept) => setTimeout(accept, milliseconds))

const requestJson = async ({ origin, token, method = 'GET', pathname, body, headers = {} }) => {
  const response = await fetch(`${origin}${pathname}`, {
    method,
    headers: {
      accept: 'application/json',
      origin,
      ...(token ? { 'x-openvideo-local-token': token } : {}),
      ...(body === undefined ? {} : { 'content-type': 'application/json; charset=utf-8' }),
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const text = await response.text()
  const payload = text ? JSON.parse(text) : null
  if (!response.ok) {
    throw new Error(`CREATIVE_SFX_HTTP_${response.status}:${payload?.error?.code ?? 'UNKNOWN'}`)
  }
  return payload
}

const loadToken = async (dataRoot) => {
  const token = JSON.parse(await readFile(resolve(dataRoot, 'local-api-token.json'), 'utf8')).token
  if (typeof token !== 'string' || !fingerprintPattern.test(token)) {
    throw new Error('CREATIVE_SFX_LOCAL_TOKEN_INVALID')
  }
  return token
}

const pollJob = async ({ origin, token, projectId, jobId, expectedType }) => {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const job = await requestJson({
      origin,
      token,
      pathname: `/api/workbench/projects/${encodeURIComponent(projectId)}/jobs/${encodeURIComponent(jobId)}`,
    })
    if (job?.projectId !== projectId || job?.type !== expectedType) {
      throw new Error('CREATIVE_SFX_JOB_IDENTITY_INVALID')
    }
    if (terminalStatuses.has(job.status)) {
      if (job.status !== 'succeeded') {
        throw new Error(`CREATIVE_SFX_JOB_FAILED:${expectedType}:${job.error?.code ?? job.status}`)
      }
      return job
    }
    await wait(pollIntervalMs)
  }
  throw new Error(`CREATIVE_SFX_JOB_TIMEOUT:${expectedType}`)
}

export const runCreativeSfxColdStart = async ({ origin, dataRoot, projectId }) => {
  const token = await loadToken(dataRoot)
  const live = await requestJson({ origin, pathname: '/api/live' })
  if (live?.ready !== true || typeof live.bootId !== 'string' || live.bootId.length < 16) {
    throw new Error('CREATIVE_SFX_GATEWAY_NOT_READY')
  }
  const projectPath = `/api/workbench/projects/${encodeURIComponent(projectId)}`
  const timeline = await requestJson({ origin, token, pathname: `${projectPath}/editor/timeline` })
  if (timeline?.status !== 'finalized' || !fingerprintPattern.test(timeline.revisionFingerprint ?? '') ||
      !timeline.shots?.some((shot) => shot.audioRoles?.includes('sfx'))) {
    throw new Error('CREATIVE_SFX_AUTOMATIC_TIMELINE_INVALID')
  }
  const catalog = await requestJson({
    origin,
    token,
    pathname: `/api/sfx-catalog/projects/${encodeURIComponent(projectId)}`,
  })
  if (catalog?.ready !== true || catalog.count < 8 || !fingerprintPattern.test(catalog.fingerprint ?? '')) {
    throw new Error('CREATIVE_SFX_CATALOG_NOT_READY')
  }
  const timelineReference = {
    timelineId: timeline.timelineId,
    revision: timeline.revision,
    revisionFingerprint: timeline.revisionFingerprint,
  }
  const [previewAccepted, jianyingAccepted] = await Promise.all([
    requestJson({
      origin,
      token,
      method: 'POST',
      pathname: `${projectPath}/editor/preview/jobs`,
      body: timelineReference,
      headers: { 'idempotency-key': randomUUID() },
    }),
    requestJson({
      origin,
      token,
      method: 'POST',
      pathname: `${projectPath}/editor/jianying/jobs`,
      body: timelineReference,
      headers: { 'idempotency-key': randomUUID() },
    }),
  ])
  const [previewJob, jianyingJob] = await Promise.all([
    pollJob({ origin, token, projectId, jobId: previewAccepted.jobId, expectedType: 'preview_generation' }),
    pollJob({ origin, token, projectId, jobId: jianyingAccepted.jobId, expectedType: 'jianying_draft_export' }),
  ])
  const previewFingerprint = previewJob.result?.outputFingerprint
  const jianyingFingerprint = jianyingJob.result?.outputFingerprint
  if (!fingerprintPattern.test(previewFingerprint ?? '') ||
      !fingerprintPattern.test(jianyingFingerprint ?? '') ||
      jianyingJob.result?.writerProjectionFingerprint !== timeline.revisionFingerprint) {
    throw new Error('CREATIVE_SFX_DUAL_OUTPUT_READBACK_INVALID')
  }
  const receipt = {
    schemaVersion: 1,
    kind: 'creative_sfx_cold_start_dual_output',
    recordedAt: new Date().toISOString(),
    bootFingerprint: sha256(live.bootId),
    previewJobFingerprint: previewFingerprint,
    jianyingJobFingerprint: jianyingFingerprint,
    timelineFingerprint: timeline.revisionFingerprint,
    catalogFingerprint: catalog.fingerprint,
    previewSucceeded: true,
    jianyingSucceeded: true,
  }
  const root = resolve(dataRoot, evidenceRelativeRoot)
  await mkdir(root, { recursive: true, mode: 0o700 })
  const output = resolve(root, `cold-start-${Date.now()}.json`)
  await writeFile(output, `${JSON.stringify(receipt)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
  return receipt
}

const runProcess = (executable, args) => new Promise((accept, reject) => {
  const child = spawn(executable, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] })
  const stdout = []
  const stderr = []
  child.stdout.on('data', (chunk) => stdout.push(chunk))
  child.stderr.on('data', (chunk) => stderr.push(chunk))
  child.once('error', reject)
  child.once('exit', (code) => {
    if (code === 0) accept(Buffer.concat(stdout))
    else reject(new Error(`CREATIVE_SFX_MEDIA_TOOL_FAILED:${code}:${Buffer.concat(stderr).toString('utf8').slice(0, 500)}`))
  })
})

const decodePcm = async ({ ffmpeg, input, output }) => {
  await runProcess(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-i', input, '-vn', '-ac', '1', '-ar', '44100', '-f', 's16le', output])
  const bytes = await readFile(output)
  return new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2))
}

export const findPcmCorrelation = ({ source, target, expectedStartUs, sampleRate = 44_100, radiusUs = 100_000 }) => {
  if (!(source instanceof Int16Array) || !(target instanceof Int16Array) || source.length < 32 || target.length <= source.length) {
    throw new Error('CREATIVE_SFX_PCM_INVALID')
  }
  const expected = Math.round(expectedStartUs * sampleRate / 1_000_000)
  const radius = Math.round(radiusUs * sampleRate / 1_000_000)
  const first = Math.max(0, expected - radius)
  const last = Math.min(target.length - source.length, expected + radius)
  let sourceEnergy = 0
  for (const sample of source) sourceEnergy += sample * sample
  let targetEnergy = 0
  for (let index = 0; index < source.length; index += 1) targetEnergy += target[first + index] ** 2
  let bestOffset = first
  let bestCorrelation = 0
  for (let offset = first; offset <= last; offset += 1) {
    if (offset > first) {
      targetEnergy -= target[offset - 1] ** 2
      targetEnergy += target[offset + source.length - 1] ** 2
    }
    let dot = 0
    for (let index = 0; index < source.length; index += 1) dot += source[index] * target[offset + index]
    const correlation = sourceEnergy > 0 && targetEnergy > 0 ? dot / Math.sqrt(sourceEnergy * targetEnergy) : 0
    if (Math.abs(correlation) > Math.abs(bestCorrelation)) {
      bestCorrelation = correlation
      bestOffset = offset
    }
  }
  const detectedStartUs = Math.round(bestOffset * 1_000_000 / sampleRate)
  return {
    detectedStartUs,
    offsetDeltaUs: Math.abs(detectedStartUs - expectedStartUs),
    correlationPeak: bestCorrelation,
  }
}

const inspectPreview = async ({ ffmpeg, ffprobe, previewPath, sourcePath, expectedStartUs, workRoot }) => {
  const metadata = JSON.parse((await runProcess(ffprobe, [
    '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,codec_name', '-of', 'json', previewPath,
  ])).toString('utf8'))
  const video = metadata.streams?.find((stream) => stream.codec_type === 'video')
  const audio = metadata.streams?.find((stream) => stream.codec_type === 'audio')
  const previewPcmPath = resolve(workRoot, 'preview.pcm')
  const sourcePcmPath = resolve(workRoot, 'source.pcm')
  const [previewPcm, sourcePcm, previewBytes, sourceBytes] = await Promise.all([
    decodePcm({ ffmpeg, input: previewPath, output: previewPcmPath }),
    decodePcm({ ffmpeg, input: sourcePath, output: sourcePcmPath }),
    readFile(previewPath),
    readFile(sourcePath),
  ])
  const correlation = findPcmCorrelation({ source: sourcePcm, target: previewPcm, expectedStartUs })
  return {
    mediaFingerprint: sha256(previewBytes),
    sourceFingerprint: sha256(sourceBytes),
    durationUs: Math.round(Number(metadata.format?.duration) * 1_000_000),
    videoCodec: video?.codec_name,
    audioCodec: audio?.codec_name,
    ...correlation,
    offsetVerified: correlation.offsetDeltaUs <= 20_000 && Math.abs(correlation.correlationPeak) >= 0.35,
  }
}

const resolveDraftAudioSource = async ({ draftRoot, materialPath }) => {
  const separator = materialPath.indexOf('##/')
  if (separator < 0) throw new Error('CREATIVE_SFX_DRAFT_AUDIO_PATH_INVALID')
  const source = resolve(draftRoot, materialPath.slice(separator + 3).replaceAll('/', '\\'))
  if (!inside(draftRoot, source)) throw new Error('CREATIVE_SFX_DRAFT_AUDIO_PATH_INVALID')
  const metadata = await lstat(source)
  if (!metadata.isFile() || metadata.isSymbolicLink()) throw new Error('CREATIVE_SFX_DRAFT_AUDIO_PATH_INVALID')
  return source
}

const loadColdStartRuns = async ({ dataRoot, timelineFingerprint, catalogFingerprint }) => {
  const root = resolve(dataRoot, evidenceRelativeRoot)
  const candidates = []
  for (const name of await readdir(root)) {
    if (!/^cold-start-\d+\.json$/u.test(name)) continue
    try {
      const value = JSON.parse(await readFile(resolve(root, name), 'utf8'))
      if (value?.kind === 'creative_sfx_cold_start_dual_output' &&
          value.timelineFingerprint === timelineFingerprint &&
          value.catalogFingerprint === catalogFingerprint &&
          value.previewSucceeded === true && value.jianyingSucceeded === true &&
          [value.bootFingerprint, value.previewJobFingerprint, value.jianyingJobFingerprint]
            .every((entry) => fingerprintPattern.test(entry ?? ''))) candidates.push(value)
    } catch { /* malformed private evidence remains ignored */ }
  }
  candidates.sort((left, right) => Date.parse(right.recordedAt) - Date.parse(left.recordedAt))
  const unique = []
  const boots = new Set()
  for (const candidate of candidates) {
    if (boots.has(candidate.bootFingerprint)) continue
    boots.add(candidate.bootFingerprint)
    unique.push(candidate)
    if (unique.length === 3) break
  }
  if (unique.length !== 3) throw new Error('CREATIVE_SFX_THREE_COLD_STARTS_REQUIRED')
  return unique.map((run) => ({
    bootFingerprint: run.bootFingerprint,
    previewJobFingerprint: run.previewJobFingerprint,
    jianyingJobFingerprint: run.jianyingJobFingerprint,
    timelineFingerprint: run.timelineFingerprint,
    previewSucceeded: true,
    jianyingSucceeded: true,
  }))
}

export const publishCreativeSfxRealAcceptance = async ({
  origin,
  dataRoot,
  projectId,
  previewPath,
  draftRoot,
  editedDraftFingerprint,
  ffmpeg = 'ffmpeg',
  ffprobe = 'ffprobe',
}) => {
  if (![dataRoot, previewPath, draftRoot].every((value) => typeof value === 'string' && isAbsolute(value)) ||
      !fingerprintPattern.test(editedDraftFingerprint ?? '')) {
    throw new Error('CREATIVE_SFX_PUBLISH_INPUT_INVALID')
  }
  const token = await loadToken(dataRoot)
  const [timeline, catalog, manifest] = await Promise.all([
    requestJson({ origin, token, pathname: `/api/workbench/projects/${encodeURIComponent(projectId)}/editor/timeline` }),
    requestJson({ origin, token, pathname: `/api/sfx-catalog/projects/${encodeURIComponent(projectId)}` }),
    readFile(resolve('config/jianying-compatibility.json'), 'utf8').then(JSON.parse),
  ])
  if (timeline?.status !== 'finalized' || !fingerprintPattern.test(timeline.revisionFingerprint ?? '') ||
      catalog?.ready !== true || !fingerprintPattern.test(catalog.fingerprint ?? '')) {
    throw new Error('CREATIVE_SFX_RUNTIME_EVIDENCE_INVALID')
  }
  const draftInfoPath = resolve(draftRoot, 'draft_info.json')
  const encryptedDraftPath = resolve(draftRoot, 'draft_content.json')
  const [draftInfoBytes, restoredDraftBytes, desktop] = await Promise.all([
    readFile(draftInfoPath),
    readFile(encryptedDraftPath),
    detectJianyingDesktop({ compatibilityManifest: manifest }),
  ])
  const draftInfo = JSON.parse(draftInfoBytes.toString('utf8'))
  const audioSegments = draftInfo.tracks?.filter((track) => track.type === 'audio')
    .flatMap((track) => track.segments ?? []) ?? []
  const cueSegment = audioSegments.find((segment) =>
    segment.target_timerange?.start === 4_200_000 && segment.target_timerange?.duration === 1_000_000)
  const material = draftInfo.materials?.audios?.find((entry) => entry.id === cueSegment?.material_id)
  if (!cueSegment || !material || typeof material.path !== 'string') {
    throw new Error('CREATIVE_SFX_JIANYING_CUE_MISSING')
  }
  const cue = { startUs: 4_200_000, durationUs: 1_000_000, volume: 0.65 }
  const sourcePath = await resolveDraftAudioSource({ draftRoot, materialPath: material.path })
  const workRoot = resolve(dataRoot, evidenceRelativeRoot, `work-${Date.now()}`)
  await mkdir(workRoot, { recursive: true, mode: 0o700 })
  try {
    const preview = await inspectPreview({
      ffmpeg,
      ffprobe,
      previewPath,
      sourcePath,
      expectedStartUs: cue.startUs,
      workRoot,
    })
    const expectedEncodedVolume = Math.pow(10, cue.volume * 100 / 2000)
    const runs = await loadColdStartRuns({
      dataRoot,
      timelineFingerprint: timeline.revisionFingerprint,
      catalogFingerprint: catalog.fingerprint,
    })
    const containingShot = timeline.shots?.find((shot) =>
      shot.audioRoles?.includes('sfx') && cue.startUs >= shot.targetRange?.startUs &&
      cue.startUs < shot.targetRange?.startUs + shot.targetRange?.durationUs)
    if (!containingShot || preview.offsetVerified !== true) {
      throw new Error('CREATIVE_SFX_AUTOMATIC_PLACEMENT_NOT_PROVEN')
    }
    const decryptor = createJianyingDraftDecryptor({
      installRoot: desktop.installRoot,
      appVersion: desktop.version,
      expectedDllFingerprint: desktop.dllFingerprint,
    })
    const decryptedPath = resolve(workRoot, 'restored-draft.json')
    await decryptor.ensurePlaintextFile(encryptedDraftPath, decryptedPath)
    const restoredDraft = JSON.parse(await readFile(decryptedPath, 'utf8'))
    const restoredCue = restoredDraft.tracks?.filter((track) => track.type === 'audio')
      .flatMap((track) => track.segments ?? [])
      .find((segment) => segment.target_timerange?.start === cue.startUs &&
        segment.target_timerange?.duration === cue.durationUs)
    if (!restoredCue) throw new Error('CREATIVE_SFX_REOPENED_CUE_MISSING')
    const initialDraftFingerprint = sha256(draftInfoBytes)
    const restoredDraftFingerprint = sha256(restoredDraftBytes)
    const receipt = createCreativeSfxPromotionReceipt({
      profileId: desktop.profileId,
      desktopFingerprint: fingerprintCreativeSfxDesktop(desktop),
      catalogFingerprint: catalog.fingerprint,
      timelineFingerprint: timeline.revisionFingerprint,
      cue,
      preview: {
        ...preview,
        cueStartUs: cue.startUs,
        cueDurationUs: cue.durationUs,
      },
      jianying: {
        draftFingerprint: initialDraftFingerprint,
        cueStartUs: cue.startUs,
        cueDurationUs: cue.durationUs,
        canonicalVolume: cue.volume,
        encodedVolume: cueSegment.volume,
        expectedEncodedVolume,
        volumeDelta: Math.abs(cueSegment.volume - expectedEncodedVolume),
        editable: true,
      },
      lifecycle: {
        opened: true,
        edited: true,
        saved: true,
        closed: true,
        reopened: true,
        sameDraft: restoredDraft.id === draftInfo.id,
        initialDraftFingerprint,
        editedDraftFingerprint,
        restoredDraftFingerprint,
      },
      runs,
      automaticPlacementVerified: true,
    })
    await publishCreativeSfxPromotionReceipt({ dataRoot, receipt })
    return {
      receiptId: receipt.receiptId,
      profileId: receipt.profileId,
      catalogFingerprint: receipt.catalogFingerprint,
      timelineFingerprint: receipt.timelineFingerprint,
      correlationPeak: receipt.preview.correlationPeak,
      offsetDeltaUs: receipt.preview.offsetDeltaUs,
      stableReceiptCount: receipt.runs.length,
    }
  } finally {
    await rm(workRoot, { recursive: true, force: true })
  }
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : null
if (invokedPath === import.meta.url) {
  const command = process.argv[2]
  const origin = process.env.OPENVIDEO_ORIGIN || 'http://127.0.0.1:8787'
  const dataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
  const projectId = process.env.OPENVIDEO_PROJECT_ID
  if (!dataRoot || !isAbsolute(dataRoot) || !projectId) throw new Error('CREATIVE_SFX_ENV_INVALID')
  const result = command === 'run'
    ? await runCreativeSfxColdStart({ origin, dataRoot, projectId })
    : command === 'publish'
      ? await publishCreativeSfxRealAcceptance({
          origin,
          dataRoot,
          projectId,
          previewPath: process.env.OPENVIDEO_SFX_PREVIEW_MEDIA,
          draftRoot: process.env.OPENVIDEO_SFX_JIANYING_DRAFT,
          editedDraftFingerprint: process.env.OPENVIDEO_SFX_EDITED_DRAFT_FINGERPRINT,
        })
      : null
  if (!result) throw new Error('CREATIVE_SFX_COMMAND_INVALID')
  console.log(JSON.stringify(result))
}
