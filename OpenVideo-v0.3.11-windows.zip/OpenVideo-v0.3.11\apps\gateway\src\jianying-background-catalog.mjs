import { fingerprintCanonical } from './editor-agent-contracts.mjs'

const tokenPattern = /^ovjbg_v1_[A-Za-z0-9_-]{8,160}$/u
const colorPattern = /^#[0-9A-Fa-f]{8}$/u

/**
 * @typedef {{
 *   fill_token: string,
 *   fill_type: 'blur' | 'color',
 *   blur: number,
 *   color: string,
 * }} JianyingBackgroundCatalogEntry
 */

export class JianyingBackgroundCatalogError extends Error {
  /** @param {string} code */
  constructor(code) { super(code); this.code = code }
}

/** @param {unknown} value */
export const parseJianyingBackgroundCatalog = (value) => {
  if (!value || typeof value !== 'object') return null
  const candidate = /** @type {Record<string, unknown>} */ (value)
  if (candidate.schema_version !== 1 || candidate.capability_id !== 'background.video' || !Array.isArray(candidate.entries) || typeof candidate.fingerprint !== 'string') return null
  /** @type {JianyingBackgroundCatalogEntry[]} */
  const entries = candidate.entries.map((entry) => {
    const item = /** @type {Record<string, unknown>} */ (entry)
    if (
      typeof item.fill_token !== 'string' ||
      !tokenPattern.test(item.fill_token) ||
      (item.fill_type !== 'blur' && item.fill_type !== 'color') ||
      typeof item.blur !== 'number' ||
      !Number.isFinite(item.blur) ||
      item.blur < 0 ||
      item.blur > 1 ||
      typeof item.color !== 'string' ||
      !colorPattern.test(item.color)
    ) throw new JianyingBackgroundCatalogError('JY062_BACKGROUND_CATALOG_INVALID')
    return { fill_token: item.fill_token, fill_type: item.fill_type, blur: item.blur, color: item.color.toUpperCase() }
  })
  const body = { schema_version: 1, capability_id: 'background.video', entries }
  if (fingerprintCanonical(body) !== candidate.fingerprint) throw new JianyingBackgroundCatalogError('JY062_BACKGROUND_CATALOG_FINGERPRINT_INVALID')
  return Object.freeze({ ...body, fingerprint: candidate.fingerprint, entries: Object.freeze(entries) })
}

/**
 * @param {ReadonlyArray<JianyingBackgroundCatalogEntry>} entries
 */
export const createJianyingBackgroundCatalog = (entries) => {
  const body = { schema_version: 1, capability_id: 'background.video', entries: entries.map((entry) => ({ ...entry })) }
  return { ...body, fingerprint: fingerprintCanonical(body) }
}

/** @param {unknown} value @param {string} catalogFingerprint @param {{profileId: string, version: string}} desktop */
export const parseJianyingBackgroundEvidence = (value, catalogFingerprint, desktop) => {
  if (!value || typeof value !== 'object') return null
  const candidate = /** @type {Record<string, unknown>} */ (value)
  const expectedKeys = ['schema_version', 'manual_evidence_verified', 'profile_id', 'app_version', 'catalog_fingerprint', 'draft_id', 'initial_blur', 'persisted_blur', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'content_fingerprint']
  if (Object.keys(candidate).sort().join('\0') !== expectedKeys.sort().join('\0') ||
    candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.profile_id !== desktop.profileId || candidate.app_version !== desktop.version ||
    candidate.catalog_fingerprint !== catalogFingerprint || candidate.scheme !== 'encrypt_v2' ||
    candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true ||
    typeof candidate.draft_id !== 'string' || !/^OpenVideo-JY062-background-[0-9]+$/u.test(candidate.draft_id) ||
    typeof candidate.initial_blur !== 'number' || !Number.isFinite(candidate.initial_blur) || candidate.initial_blur < 0 || candidate.initial_blur > 1 ||
    typeof candidate.persisted_blur !== 'number' || !Number.isFinite(candidate.persisted_blur) || candidate.persisted_blur < 0 || candidate.persisted_blur > 1 ||
    Math.abs(candidate.initial_blur - candidate.persisted_blur) <= 1e-9 ||
    typeof candidate.content_fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(candidate.content_fingerprint)) return null
  return Object.freeze({ ...candidate })
}
