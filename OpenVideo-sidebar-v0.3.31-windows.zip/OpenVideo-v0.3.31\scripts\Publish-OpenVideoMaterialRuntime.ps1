﻿[CmdletBinding()]
param(
    [string]$SourceRoot,
    [Parameter(Mandatory = $true)][string]$DestinationRoot,
    [string]$ManifestPath,
    [switch]$RecoverOnly
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
function Get-RuntimeHash([string]$Path) {
    $hash = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return [BitConverter]::ToString($hash.ComputeHash($stream)).Replace('-', '') }
    finally { $stream.Dispose(); $hash.Dispose() }
}

# 仅升级清单声明且校验通过的程序目录；模型和用户数据保持增量合并。
function Assert-PlainPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    $current = [IO.Path]::GetPathRoot($full)
    foreach ($part in $full.Substring($current.Length).Split([char[]]@('\', '/'), [StringSplitOptions]::RemoveEmptyEntries)) {
        $current = Join-Path $current $part
        if (Test-Path -LiteralPath $current) {
            if ((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw 'OPENVIDEO_RUNTIME_REPARSE_POINT_REJECTED'
            }
        }
    }
}
function Assert-PlainTree([string]$Path) {
    Assert-PlainPath $Path
    if (Test-Path -LiteralPath $Path) {
        foreach ($entry in @(Get-ChildItem -LiteralPath $Path -Force -Recurse)) {
            if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'OPENVIDEO_RUNTIME_REPARSE_POINT_REJECTED' }
        }
    }
}
$destination = [IO.Path]::GetFullPath($DestinationRoot).TrimEnd('\')
Assert-PlainPath $destination
function Restore-Transaction([string]$Transaction) {
    Assert-PlainTree $Transaction
    $journalPath = Join-Path $Transaction 'pending.json'
    $journal = Get-Content -LiteralPath $journalPath -Raw | ConvertFrom-Json
    if ($journal.schema_version -ne 1) { throw 'OPENVIDEO_RUNTIME_RECOVERY_INVALID' }
    foreach ($entry in @($journal.groups)) {
        if ($entry.name -notmatch '^[a-zA-Z0-9_-]+$' -or $entry.had_original -isnot [bool]) { throw 'OPENVIDEO_RUNTIME_RECOVERY_INVALID' }
        $target = Join-Path $destination ('dependencies\' + $entry.name)
        $backup = Join-Path $Transaction $entry.name
        $prepared = Join-Path $Transaction ($entry.name + '.new')
        Assert-PlainTree $target
        if ((Test-Path -LiteralPath $backup) -or (-not $entry.had_original -and -not (Test-Path -LiteralPath $prepared))) {
            if (Test-Path -LiteralPath $target) {
                Move-Item -LiteralPath $target -Destination (Join-Path $Transaction ($entry.name + '.interrupted-' + [guid]::NewGuid().ToString('N')))
            }
            if (Test-Path -LiteralPath $backup) { Move-Item -LiteralPath $backup -Destination $target }
        }
    }
    Move-Item -LiteralPath $journalPath -Destination (Join-Path $Transaction 'recovered.json')
}
$backupRoot = Join-Path $destination 'runtime-upgrade-backups'
Assert-PlainPath $backupRoot
if (Test-Path -LiteralPath $backupRoot) {
    foreach ($oldTransaction in @(Get-ChildItem -LiteralPath $backupRoot -Directory -Force)) {
        if ($oldTransaction.Name -notmatch '^[a-f0-9]{32}$') { continue }
        Assert-PlainPath $oldTransaction.FullName
        if (Test-Path -LiteralPath (Join-Path $oldTransaction.FullName 'pending.json')) { Restore-Transaction $oldTransaction.FullName }
    }
}
if ($RecoverOnly) { return }
$source = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
$stageDirectory = Get-Item -LiteralPath $source -Force
$installDirectory = $stageDirectory.Parent
if (
    $stageDirectory.Name -ne 'stage' -or
    $null -eq $installDirectory -or
    $installDirectory.Name -notmatch '^\.install-[a-f0-9]{32}$' -or
    $null -eq $installDirectory.Parent -or
    -not $installDirectory.Parent.FullName.TrimEnd('\').Equals($destination, [StringComparison]::OrdinalIgnoreCase)
) { throw 'OPENVIDEO_RUNTIME_STAGE_NOT_OWNED' }
Assert-PlainTree $source
$manifest = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json
if ($manifest.schema_version -ne 1) { throw 'OPENVIDEO_RUNTIME_MANIFEST_INVALID' }
$plans = @()
$groups = @{}
foreach ($dependency in @($manifest.dependencies | Where-Object kind -eq 'executable-bundle')) {
    $paths = @($dependency.runtime_files)
    if ($paths.Count -eq 0 -or $paths.Count -ne @($dependency.runtime_artifacts).Count) { throw 'OPENVIDEO_RUNTIME_MANIFEST_INVALID' }
    $group = $null
    $expected = @{}
    foreach ($artifact in $dependency.runtime_artifacts) {
        $relative = ([string]$artifact.path).Replace('\', '/')
        if ($relative -notmatch '^dependencies/([a-zA-Z0-9_-]+)/[^:]+$' -or $relative.Split('/') -contains '..' -or $relative.Split('/') -contains '.') {
            throw 'OPENVIDEO_RUNTIME_MANIFEST_PATH_INVALID'
        }
        $artifactGroup = $Matches[1]
        if ($null -eq $group) { $group = $artifactGroup }
        if ($group -ne $artifactGroup -or $expected.ContainsKey($relative) -or $paths -notcontains $artifact.path) { throw 'OPENVIDEO_RUNTIME_MANIFEST_INVALID' }
        $expected[$relative] = $true
        $file = Join-Path $source $relative
        if (-not (Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -ne $artifact.size -or (Get-RuntimeHash $file) -ne $artifact.sha256) {
            throw 'OPENVIDEO_RUNTIME_STAGED_HASH_MISMATCH'
        }
    }
    if ($groups.ContainsKey($group)) { throw 'OPENVIDEO_RUNTIME_MANIFEST_INVALID' }
    $groups[$group] = $true
    $from = Join-Path $source "dependencies\$group"
    foreach ($file in @(Get-ChildItem -LiteralPath $from -File -Recurse -Force)) {
        $relative = $file.FullName.Substring($source.Length + 1).Replace('\', '/')
        if (-not $expected.ContainsKey($relative)) { throw 'OPENVIDEO_RUNTIME_STAGED_EXTRA_FILE' }
    }
    $target = Join-Path $destination "dependencies\$group"
    Assert-PlainTree $target
    $plans += [pscustomobject]@{ Group=$group; Source=$from; Target=$target; BackedUp=$false; Published=$false }
}
# 先检查模型冲突，确保拒绝时不会先替换程序。
$merge = Join-Path $PSScriptRoot 'Merge-OpenVideoRuntimeFiles.ps1'
& $merge -SourceRoot $source -DestinationRoot $destination -RelativePaths @('models') -CheckOnly | Out-Null
$transaction = Join-Path $destination ('runtime-upgrade-backups\' + [guid]::NewGuid().ToString('N'))
Assert-PlainPath $transaction
New-Item -ItemType Directory -Path $transaction -Force | Out-Null
try {
    # 同卷移动已校验目录，发布字节与隔离执行校验的字节完全相同。
    foreach ($plan in $plans) {
        Move-Item -LiteralPath $plan.Source -Destination (Join-Path $transaction ($plan.Group + '.new'))
    }
    $journal = @{ schema_version=1; groups=@($plans | ForEach-Object { @{ name=$_.Group; had_original=(Test-Path -LiteralPath $_.Target) } }) }
    $pendingPath = Join-Path $transaction 'pending.json'
    $pendingTemporary = Join-Path $transaction 'pending.json.tmp'
    [IO.File]::WriteAllText($pendingTemporary, ($journal | ConvertTo-Json -Depth 4), [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $pendingTemporary -Destination $pendingPath
    foreach ($plan in $plans) {
        Assert-PlainTree $plan.Target
        $backup = Join-Path $transaction $plan.Group
        if (Test-Path -LiteralPath $plan.Target) {
            Move-Item -LiteralPath $plan.Target -Destination $backup
            $plan.BackedUp = $true
        }
        New-Item -ItemType Directory -Path (Split-Path $plan.Target -Parent) -Force | Out-Null
        Move-Item -LiteralPath (Join-Path $transaction ($plan.Group + '.new')) -Destination $plan.Target
        $plan.Published = $true
    }
    & $merge -SourceRoot $source -DestinationRoot $destination -RelativePaths @('models') | Out-Null
    Move-Item -LiteralPath $pendingPath -Destination (Join-Path $transaction 'completed.json')
} catch {
    $failure = $_
    if (Test-Path -LiteralPath (Join-Path $transaction 'pending.json')) { Restore-Transaction $transaction }
    throw $failure
}
Write-Output 'OPENVIDEO_RUNTIME_UPGRADE_VERIFIED: previous binaries preserved in private runtime-upgrade-backups.'
