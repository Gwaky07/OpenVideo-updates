# 先看这里

OpenVideo 是在本机运行的创作工作台。完整解压后，双击根目录中唯一带 OpenVideo Logo 的 `Start-OpenVideo.exe`。它会打开这台电脑上的工作台；素材、剪映草稿、项目和模型密钥都保留在本机。

## 使用前准备

1. Windows 10 或 Windows 11。
2. 首次启动时可访问网络。
3. 自己的 LLM 中转配置，包括 Base URL、API Key 以及 text、vision、JSON 模型。
4. 这台电脑已安装剪映专业版。
5. 自己的素材文件夹。

即使还没有配置模型或剪映，页面仍可打开，但完整创作链路暂时不能完成。发行包不会包含其他人的密钥、素材、项目或剪映私有目录。

## 首次使用

1. 完整解压 ZIP，不要直接在压缩包预览窗口里运行。
2. 双击 `Start-OpenVideo.exe`，并保持启动窗口运行。首次启动可能需要几分钟。
3. 工作台打开后，进入左侧“系统设置”，填写自己的模型中转配置。
4. 新建项目，通过 Windows 文件夹选择器授权自己的素材目录，并确认只读使用。
5. 按“创作要求 → 分镜 → AI 剪辑 → 预览 MP4 → 剪映草稿”的顺序操作。

`OpenVideo.cmd` 是排障用的备用入口。根目录中的 `OpenVideo.exe` 是无 Logo 的旧更新兼容程序，不是日常启动器。

## 更新

`v0.3.25` 支持整产品更新。侧栏更新可以一起替换页面、Gateway、启动器和 `OpenVideo.cmd`；项目、素材、模型设置、剪映身份和私有 Catalog 都保存在用户本地数据目录中。

修改私有源码仓库后，先推送 `main`，再在开发电脑运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\Publish-OpenVideoFullUpdateQuiet.ps1 -Version v0.3.25
```

新用户应先获得完整的 `OpenVideo-v0.3.25-windows.zip`，完整解压并双击 `Start-OpenVideo.exe`。带 `.git` 的源码目录不应使用侧栏更新。

## 请勿操作

- 不要复制其他电脑的 `%LOCALAPPDATA%\OpenVideo` 或 API Key。
- 不要把素材、密钥、剪映身份或运行目录提交到 Git。
- 未配置模型时，不要期待完整视频创作链路可用。

更多说明见 `README-WINDOWS.md`。
