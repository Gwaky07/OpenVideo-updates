import { existsSync } from 'node:fs'
import { copyFile, mkdtemp, readFile, rm, writeFile, mkdir, readdir } from 'node:fs/promises'
import { spawn, execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { promisify } from 'node:util'
import { basename, dirname, join, resolve } from 'node:path'
import { tmpdir } from 'node:os'

const execFileAsync = promisify(execFile)
const [packagePathArg, installRootArg] = process.argv.slice(2)
if (!packagePathArg || !installRootArg) throw new Error('OPENVIDEO_FULL_UPDATE_ARGUMENTS_MISSING')

const packagePath = resolve(packagePathArg)
const installRoot = resolve(installRootArg).replace(/[\\/]+$/u, '')
const localAppData = process.env.LOCALAPPDATA ?? ''
const expectedRoot = resolve(
  process.env.OPENVIDEO_PROGRAM_ROOT ?? join(localAppData, 'OpenVideo', 'program'),
).replace(/[\\/]+$/u, '')
if (installRoot.toLowerCase() !== expectedRoot.toLowerCase()) {
  throw new Error('OPENVIDEO_FULL_UPDATE_INSTALL_ROOT_FORBIDDEN')
}
if (existsSync(join(installRoot, '.git'))) {
  throw new Error('OPENVIDEO_FULL_UPDATE_SOURCE_TREE_FORBIDDEN')
}
if (!existsSync(packagePath)) throw new Error('OPENVIDEO_FULL_UPDATE_PACKAGE_MISSING')

const readGatewayPort = async () => {
  const configPath = process.env.OPENVIDEO_CONFIG_PATH ?? join(localAppData, 'OpenVideo', 'config.json')
  // The configured port is only the preferred starting point. Bootstrap may
  // select a different free port for this launch and Start-OpenVideo forwards
  // that effective value to the Gateway process. Restart the exact live port
  // so the existing browser tab can observe the new boot instead of waiting
  // forever on the former fallback port.
  const activePort = Number(process.env.OPENVIDEO_GATEWAY_PORT)
  if (Number.isInteger(activePort) && activePort >= 1 && activePort <= 65535) {
    return { port: activePort, configPath }
  }
  try {
    const config = JSON.parse(await readFile(configPath, 'utf8'))
    const port = Number(config.gateway_port)
    if (Number.isInteger(port) && port >= 1 && port <= 65535) return { port, configPath }
  } catch {}
  return { port: 8787, configPath }
}

const processIdsForRoot = async () => {
  const escapedRoot = installRoot.replaceAll("'", "''")
  const command = `Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf('${escapedRoot}', [StringComparison]::OrdinalIgnoreCase) -ge 0 } | Select-Object -ExpandProperty ProcessId`
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-Command', command], {
      windowsHide: true,
      timeout: 5_000,
    })
    return stdout.split(/\r?\n/u)
      .map((line) => Number(line.trim()))
      .filter((pid) => Number.isInteger(pid) && pid > 0 && pid !== process.pid)
  } catch {
    return []
  }
}

const stopPreviousSupervisor = async ({ port }) => {
  const instancesPath = join(localAppData, 'OpenVideo', 'instances', `${port}.json`)
  let record
  try {
    record = JSON.parse(await readFile(instancesPath, 'utf8'))
  } catch {
    return
  }
  if (!record || String(record.repositoryRoot ?? '').replace(/[\\/]+$/u, '').toLowerCase() !== installRoot.toLowerCase()) return
  const gatewayPid = Number(record.pid)
  const supervisorPid = Number(record.supervisorPid)
  if (!Number.isInteger(gatewayPid) || gatewayPid < 1 || !Number.isInteger(supervisorPid) || supervisorPid < 1) return
  const escapedRoot = installRoot.replaceAll("'", "''")
  const script = [
    `$gateway = Get-CimInstance Win32_Process -Filter "ProcessId=${gatewayPid}"`,
    `$supervisor = Get-CimInstance Win32_Process -Filter "ProcessId=${supervisorPid}"`,
    `if ($null -eq $gateway -or $null -eq $supervisor -or [int]$gateway.ParentProcessId -ne ${supervisorPid}) { exit 0 }`,
    `$command = [string]$gateway.CommandLine`,
    `if ($command.IndexOf('${escapedRoot}', [StringComparison]::OrdinalIgnoreCase) -lt 0 -or [string]$supervisor.Name -notin @('powershell.exe','pwsh.exe')) { exit 0 }`,
    `Stop-Process -Id ${supervisorPid} -Force -ErrorAction SilentlyContinue`,
    `Start-Sleep -Milliseconds 500`,
    `Stop-Process -Id ${gatewayPid} -Force -ErrorAction SilentlyContinue`,
  ].join('; ')
  const encoded = Buffer.from(script, 'utf16le').toString('base64')
  try {
    await execFileAsync('powershell.exe', ['-NoProfile', '-EncodedCommand', encoded], {
      windowsHide: true,
      timeout: 20_000,
    })
  } catch {}
}

const stopRootNodeProcesses = async () => {
  for (const pid of await processIdsForRoot()) {
    try { process.kill(pid, 'SIGKILL') } catch {}
  }
  // A killed Gateway may still hold the old directory briefly. Wait until its
  // command line disappears before asking the launcher to move that directory.
  for (let attempt = 0; attempt < 40; attempt += 1) {
    if ((await processIdsForRoot()).length === 0) return
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 250))
  }
}

// Development/build callers set OPENVIDEO_UPDATE_WORK_ROOT to the repository
// `.openvideo-work` directory so a full ZIP never expands into C:\Temp. A
// packaged colleague install has no source checkout, so it falls back to its
// private OpenVideo data directory; the atomic swap itself remains there.
const updateWorkRoot = resolve(
  process.env.OPENVIDEO_UPDATE_WORK_ROOT ?? join(dirname(installRoot), 'update-work'),
)
await mkdir(updateWorkRoot, { recursive: true })
const stage = await mkdtemp(join(updateWorkRoot, 'openvideo-update-'))
let launcherSpawned = false
let payloadTransferred = false
try {
  const unpacked = join(stage, 'unpacked')
  await execFileAsync('powershell.exe', [
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-Command',
    `Expand-Archive -LiteralPath '${packagePath.replaceAll("'", "''")}' -DestinationPath '${unpacked.replaceAll("'", "''")}' -Force`,
  ], { windowsHide: true, timeout: 120_000 })
  const entries = await readdir(unpacked, { withFileTypes: true })
  const rootEntry = entries.find((entry) => entry.isDirectory())
  const payload = rootEntry ? join(unpacked, rootEntry.name) : unpacked
  // REL-057: the Gateway passes the identity the manifest promised; the package
  // must carry exactly that identity. Checked before any process is stopped.
  const expectedCommit = String(process.env.OPENVIDEO_UPDATE_EXPECTED_COMMIT ?? '').trim().toLowerCase()
  const expectedVersion = String(process.env.OPENVIDEO_UPDATE_EXPECTED_VERSION ?? '').trim()
  const expectedScope = String(process.env.OPENVIDEO_UPDATE_EXPECTED_SCOPE ?? '').trim()
  // A detached updater has no console: leave the code where support can find it.
  const identityFailure = async (/** @type {string} */ code) => {
    try {
      const failureLog = join(localAppData || dirname(installRoot), 'OpenVideo', 'launcher-logs')
      await mkdir(failureLog, { recursive: true })
      await writeFile(join(failureLog, 'update-apply-failure.log'),
        `${new Date().toISOString()} ${code} expected=${expectedCommit.slice(0, 12)} ${expectedScope}\n`, { flag: 'a' })
    } catch {}
    return new Error(code)
  }
  if (!/^[a-f0-9]{40}$/u.test(expectedCommit) || !/^(sidebar|full)$/u.test(expectedScope)) {
    throw await identityFailure('OPENVIDEO_FULL_UPDATE_IDENTITY_UNSPECIFIED')
  }
  const identityPath = join(payload, `openvideo-${expectedScope}-package.json`)
  if (!existsSync(identityPath)) throw await identityFailure('OPENVIDEO_FULL_UPDATE_IDENTITY_MISSING')
  let packageIdentity
  try {
    packageIdentity = JSON.parse((await readFile(identityPath, 'utf8')).replace(/^\uFEFF/u, ''))
  } catch {
    throw await identityFailure('OPENVIDEO_FULL_UPDATE_IDENTITY_MISSING')
  }
  const identityCommit = String(packageIdentity?.commit ?? '').trim().toLowerCase()
  const identityVersion = String(packageIdentity?.version ?? '').trim().slice(0, 32)
  if (packageIdentity?.scope !== expectedScope || identityCommit !== expectedCommit ||
      (expectedVersion && identityVersion !== expectedVersion)) {
    throw await identityFailure('OPENVIDEO_FULL_UPDATE_IDENTITY_MISMATCH')
  }
  const launcher = join(payload, 'OpenVideo.exe')
  if (!existsSync(launcher)) throw new Error('OPENVIDEO_FULL_UPDATE_RUNTIME_MISSING')

  // Keep the launcher handoff on the same volume as the portable install.
  // This avoids copying the large update payload through C:\ for packages
  // extracted to another drive. The small instance and launcher records may
  // still remain under LocalAppData.
  const stableStage = join(updateWorkRoot, 'update-staging')
  await mkdir(stableStage, { recursive: true })
  const launcherCopy = join(stableStage, 'OpenVideo-update.exe')
  await copyFile(launcher, launcherCopy)
  const logRoot = join(localAppData || tmpdir(), 'OpenVideo', 'launcher-logs')
  await mkdir(logRoot, { recursive: true })
  await writeFile(join(logRoot, 'controlled-restart.marker'), '')

  // Preserve the colleague's running product-update.json. Installed release
  // identity remains the authoritative version floor, while this file keeps
  // user-selected update channels and full-update settings unchanged.
  const existingConfigPath = join(installRoot, 'config', 'product-update.json')
  const incomingConfigPath = join(payload, 'config', 'product-update.json')
  try {
    if (existsSync(existingConfigPath) && existsSync(incomingConfigPath)) {
      const [existingRaw, incomingRaw] = await Promise.all([
        readFile(existingConfigPath, 'utf8'),
        readFile(incomingConfigPath, 'utf8'),
      ])
      const existingHash = createHash('sha256').update(existingRaw).digest('hex')
      const incomingHash = createHash('sha256').update(incomingRaw).digest('hex')
      if (existingHash !== incomingHash) {
        await mkdir(join(payload, 'config'), { recursive: true })
        await copyFile(existingConfigPath, incomingConfigPath)
        const preservedNote = `[Apply-OpenVideoFullUpdate] preserved colleague product-update.json at ${new Date().toISOString()} sha256=${existingHash}`
        console.log('OPENVIDEO_UPDATE_PRODUCT_CONFIG_PRESERVED')
        try {
          await writeFile(
            join(logRoot, 'product-update-config-preserved.log'),
            `${preservedNote}\n`,
            { flag: 'a' }
          )
        } catch {}
      }
    }
  } catch (preserveError) {
    console.log(`OPENVIDEO_UPDATE_PRODUCT_CONFIG_PRESERVE_FAILED: ${preserveError.message}`)
  }

  const { port, configPath } = await readGatewayPort()
  await stopPreviousSupervisor({ port })
  await stopRootNodeProcesses()

  // Keep the updater process outside the tree it must atomically replace.
  // Windows refuses to move a directory while a process current directory is
  // inside that directory.
  // The replacement must boot from its audited packaged runtime. Inheriting
  // Node injection variables from the old Gateway can preload development
  // code into Corepack or the replacement Gateway. On Windows, a drive path
  // supplied to `--import` is also parsed as an unsupported URL scheme and the
  // post-update prerequisite probe fails before the new release becomes live.
  const launcherEnvironment = {
    ...process.env,
    OPENVIDEO_PROGRAM_ROOT: installRoot,
    OPENVIDEO_CONFIG_PATH: configPath,
    OPENVIDEO_GATEWAY_PORT: String(port),
    OPENVIDEO_UPDATE_PAYLOAD_ROOT: payload,
  }
  delete launcherEnvironment.NODE_OPTIONS
  delete launcherEnvironment.NODE_PATH

  spawn(launcherCopy, [], {
    cwd: resolve(installRoot, '..'),
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
    env: launcherEnvironment,
  }).unref()
  launcherSpawned = true
  // The launcher moves the extracted payload to program.__next. Do not delete
  // its source directory until that handoff has happened; deleting the stage
  // immediately races the detached process and forces it onto its fallback.
  for (let attempt = 0; attempt < 240; attempt += 1) {
    if (!existsSync(payload)) {
      payloadTransferred = true
      break
    }
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 250))
  }
  if (!payloadTransferred) {
    console.log(`OPENVIDEO_UPDATE_PAYLOAD_HANDOFF_PENDING: ${payload}`)
  }
  // The portable launcher owns backup cleanup after its own health check.
} finally {
  // Before spawn, or after a confirmed directory move, this stage is ours to
  // remove. On a slow handoff keep it available for the detached launcher.
  if (!launcherSpawned || payloadTransferred) {
    await rm(stage, { recursive: true, force: true })
  }
  await rm(packagePath, { force: true })
  // The Gateway's own stage (openvideo-full-*) is left behind otherwise.
  const gatewayStage = dirname(packagePath)
  if (/^openvideo-full-[A-Za-z0-9]+$/u.test(basename(gatewayStage)) &&
      resolve(dirname(gatewayStage)).toLowerCase() === updateWorkRoot.toLowerCase()) {
    await rm(gatewayStage, { recursive: true, force: true })
  }
}
