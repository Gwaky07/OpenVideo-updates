import { execFile } from 'node:child_process'
import { lstat, readFile, readdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'

import { loadLocalRuntimeConfig } from './local-runtime.mjs'

const launcherConfigSchemaVersion = 1
const defaultRepositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..')
const execFileAsync = promisify(execFile)
const allowedConfigKeys = new Set([
  'schema_version', 'runtime_data_root', 'llm_revision', 'llm_api_key_dpapi',
  'llm_provider', 'llm_base_url', 'llm_text_model', 'llm_vision_model',
  'llm_json_model', 'short_video_factory_root', 'pyjianyingdraft_root',
  'gateway_port', 'voice', 'voice_rate', 'bgm_path',
])

/** @param {unknown} error @returns {string | number | undefined} */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error
  ? /** @type {{code?: string | number}} */ (error).code
  : undefined

export class LauncherRuntimeConfigError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'LauncherRuntimeConfigError'
    this.code = code
  }
}

/** @param {unknown} value */
const isLauncherConfigShape = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const config = /** @type {Record<string, any>} */ (value)
  return config.schema_version === launcherConfigSchemaVersion &&
    Object.keys(config).every((key) => allowedConfigKeys.has(key)) &&
    typeof config.runtime_data_root === 'string' &&
    path.isAbsolute(config.runtime_data_root) &&
    typeof config.short_video_factory_root === 'string' &&
    path.isAbsolute(config.short_video_factory_root) &&
    typeof config.pyjianyingdraft_root === 'string' &&
    path.isAbsolute(config.pyjianyingdraft_root) &&
    Number.isInteger(config.gateway_port) &&
    config.gateway_port >= 1 && config.gateway_port <= 65_535
}

/**
 * Resolve the same private config path used by Start-OpenVideo.ps1. An
 * explicit OPENVIDEO_CONFIG_PATH is accepted for tests and controlled tools;
 * the shell's OPENVIDEO_RUNTIME_DATA_ROOT is deliberately not consulted.
 * @param {NodeJS.ProcessEnv | Record<string, string | undefined>} [environment]
 */
export const resolveLauncherConfigPath = (environment = process.env) => {
  const explicit = environment.OPENVIDEO_CONFIG_PATH?.trim()
  if (explicit) {
    if (!path.isAbsolute(explicit)) throw new LauncherRuntimeConfigError('JY194_LAUNCHER_CONFIG_PATH_INVALID')
    return path.resolve(explicit)
  }
  const localAppData = environment.LOCALAPPDATA?.trim()
  if (!localAppData || !path.isAbsolute(localAppData)) {
    throw new LauncherRuntimeConfigError('JY194_LAUNCHER_CONFIG_UNAVAILABLE')
  }
  return path.resolve(localAppData, 'OpenVideo', 'config.json')
}

/** @param {string} configPath */
const readLauncherConfig = async (configPath) => {
  let readable = false
  for (const candidatePath of [configPath, `${configPath}.bak`]) {
    let raw
    try {
      raw = await readFile(candidatePath, 'utf8')
      readable = true
    } catch {
      continue
    }
    try {
      const parsed = JSON.parse(raw)
      if (isLauncherConfigShape(parsed)) return parsed
    } catch {
      // Match the launcher: an invalid primary file can still recover from a
      // valid private backup, while two invalid files remain fail-closed.
    }
  }
  throw new LauncherRuntimeConfigError(readable ? 'JY194_LAUNCHER_CONFIG_INVALID' : 'JY194_LAUNCHER_CONFIG_UNAVAILABLE')
}

/** @param {string} candidate */
const assertNoReparseAncestors = async (candidate) => {
  const resolved = path.resolve(candidate)
  let current = path.parse(resolved).root
  const segments = path.relative(current, resolved).split(path.sep).filter(Boolean)
  for (const segment of segments) {
    current = path.join(current, segment)
    try {
      const item = await lstat(current)
      if (item.isSymbolicLink()) throw new LauncherRuntimeConfigError('JY194_LAUNCHER_REPARSE_UNSAFE')
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return
      throw error
    }
  }
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => path.resolve(left).replace(/[\\/]+$/u, '').toLowerCase() ===
  path.resolve(right).replace(/[\\/]+$/u, '').toLowerCase()

/** @param {string} runtimeRoot @param {string} repositoryRoot @param {NodeJS.ProcessEnv | Record<string, string | undefined>} environment */
const validateRuntimeRoot = async (runtimeRoot, repositoryRoot, environment) => {
  const resolved = path.resolve(runtimeRoot)
  const userProfile = environment.USERPROFILE?.trim() || process.env.USERPROFILE?.trim()
  if (samePath(resolved, path.parse(resolved).root) ||
      (userProfile && samePath(resolved, userProfile))) {
    throw new LauncherRuntimeConfigError('JY194_LAUNCHER_RUNTIME_ROOT_UNSAFE')
  }
  await assertNoReparseAncestors(resolved)
  let entries = []
  try {
    const item = await lstat(resolved)
    if (!item.isDirectory() || item.isSymbolicLink()) throw new LauncherRuntimeConfigError('JY194_LAUNCHER_RUNTIME_ROOT_UNSAFE')
    entries = await readdir(resolved)
  } catch (error) {
    if (errorCode(error) === 'ENOENT') return
    throw error
  }
  const ownerPath = path.join(resolved, '.openvideo-runtime-owner.json')
  try {
    const owner = JSON.parse(await readFile(ownerPath, 'utf8'))
    const keys = Object.keys(owner).sort()
    if (keys.length !== 2 || keys[0] !== 'owner' || keys[1] !== 'schema_version' ||
        owner.schema_version !== 1 || owner.owner !== 'openvideo-local-runtime') {
      throw new LauncherRuntimeConfigError('JY194_LAUNCHER_RUNTIME_ROOT_UNOWNED')
    }
  } catch (error) {
    if (errorCode(error) !== 'ENOENT') throw error
    const legacyMarkers = new Set(['projects.json', 'authorizations.json', 'tasks.json', 'material-analysis'])
    if (entries.length > 0 && !entries.some((entry) => legacyMarkers.has(entry))) {
      throw new LauncherRuntimeConfigError('JY194_LAUNCHER_RUNTIME_ROOT_UNOWNED')
    }
  }
  if (samePath(resolved, repositoryRoot) || resolved.toLowerCase().startsWith(`${path.resolve(repositoryRoot).toLowerCase()}${path.sep}`)) {
    throw new LauncherRuntimeConfigError('JY194_LAUNCHER_RUNTIME_ROOT_UNSAFE')
  }
}

/** @param {string} root @param {string} manifestPath @param {string} code */
const validatePinnedUpstream = async (root, manifestPath, code) => {
  const resolved = path.resolve(root)
  await assertNoReparseAncestors(resolved)
  let manifest
  try {
    manifest = JSON.parse(await readFile(manifestPath, 'utf8'))
    const item = await lstat(resolved)
    if (!item.isDirectory() || item.isSymbolicLink()) throw new Error('root')
    const [commit, remote, status] = await Promise.all([
      execFileAsync('git', ['-C', resolved, 'rev-parse', 'HEAD'], { windowsHide: true, timeout: 10_000, maxBuffer: 16 * 1024 }),
      execFileAsync('git', ['-C', resolved, 'remote', 'get-url', 'origin'], { windowsHide: true, timeout: 10_000, maxBuffer: 16 * 1024 }),
      execFileAsync('git', ['-C', resolved, 'status', '--porcelain=v1'], { windowsHide: true, timeout: 10_000, maxBuffer: 64 * 1024 }),
    ])
    if (commit.stdout.trim() !== manifest.commit ||
        remote.stdout.trim().replace(/[\\/]+$/u, '') !== String(manifest.repository).trim().replace(/[\\/]+$/u, '') ||
        status.stdout.trim() !== '') throw new Error('integrity')
  } catch {
    throw new LauncherRuntimeConfigError(code)
  }
}

/**
 * Load the runtime root and writer module root from the launcher's private
 * config. This is the only supported source for runtime-aligned smoke tools;
 * a stale shell OPENVIDEO_RUNTIME_DATA_ROOT must never redirect a run.
 * @param {{environment?: NodeJS.ProcessEnv | Record<string, string | undefined>, repositoryRoot?: string}} [options]
 */
export const loadLauncherRuntimeConfig = async ({ environment = process.env, repositoryRoot } = {}) => {
  const configPath = resolveLauncherConfigPath(environment)
  await assertNoReparseAncestors(configPath)
  const config = await readLauncherConfig(configPath)
  const effectiveRepositoryRoot = path.resolve(repositoryRoot ?? defaultRepositoryRoot)

  let runtime
  try {
    await assertNoReparseAncestors(config.runtime_data_root)
    runtime = loadLocalRuntimeConfig(
      { OPENVIDEO_RUNTIME_DATA_ROOT: config.runtime_data_root },
      { repositoryRoot: effectiveRepositoryRoot },
    )
  } catch {
    throw new LauncherRuntimeConfigError('JY194_LAUNCHER_RUNTIME_ROOT_UNSAFE')
  }
  await validateRuntimeRoot(runtime.dataRoot, effectiveRepositoryRoot, environment)
  const pyJianyingDraftRoot = path.resolve(config.pyjianyingdraft_root)
  const shortVideoFactoryRoot = path.resolve(config.short_video_factory_root)
  await validatePinnedUpstream(
    pyJianyingDraftRoot,
    path.join(effectiveRepositoryRoot, 'config', 'pyjianyingdraft-upstream.json'),
    'JY194_LAUNCHER_PYJIANYINGDRAFT_INVALID',
  )
  await validatePinnedUpstream(
    shortVideoFactoryRoot,
    path.join(effectiveRepositoryRoot, 'config', 'short-video-factory-upstream.json'),
    'JY194_LAUNCHER_SHORT_VIDEO_FACTORY_INVALID',
  )
  return Object.freeze({
    source: 'launcher_config',
    configPath,
    dataRoot: runtime.dataRoot,
    gatewayPort: config.gateway_port,
    pyJianyingDraftRoot,
    shortVideoFactoryRoot,
  })
}

/**
 * Resolve the active launcher instance for this exact worktree. Linked
 * worktrees use a stable isolated port that intentionally differs from the
 * primary port stored in config.json.
 * @param {{
 *   configuredPort: number,
 *   environment?: NodeJS.ProcessEnv | Record<string, string | undefined>,
 *   repositoryRoot?: string,
 *   fetchImpl?: typeof fetch,
 * }} options
 */
export const resolveActiveLauncherGatewayPort = async ({
  configuredPort,
  environment = process.env,
  repositoryRoot = defaultRepositoryRoot,
  fetchImpl = fetch,
}) => {
  if (!Number.isInteger(configuredPort) || configuredPort < 1 || configuredPort > 65_535) {
    throw new LauncherRuntimeConfigError('JY194_LAUNCHER_GATEWAY_PORT_INVALID')
  }
  const localAppData = environment.LOCALAPPDATA?.trim()
  if (!localAppData || !path.isAbsolute(localAppData)) return configuredPort
  const instancesRoot = path.resolve(localAppData, 'OpenVideo', 'instances')
  await assertNoReparseAncestors(instancesRoot)
  let entries
  try {
    const item = await lstat(instancesRoot)
    if (!item.isDirectory() || item.isSymbolicLink()) {
      throw new LauncherRuntimeConfigError('JY194_LAUNCHER_INSTANCES_UNSAFE')
    }
    entries = await readdir(instancesRoot)
  } catch (error) {
    if (errorCode(error) === 'ENOENT') return configuredPort
    throw error
  }
  const activePorts = []
  for (const fileName of entries.filter((entry) => /^(?:[1-9]\d{0,4})\.json$/u.test(entry)).sort()) {
    try {
      const instancePath = path.join(instancesRoot, fileName)
      const item = await lstat(instancePath)
      if (!item.isFile() || item.isSymbolicLink()) continue
      const record = JSON.parse(await readFile(instancePath, 'utf8'))
      const port = Number.parseInt(fileName.slice(0, -5), 10)
      if (record?.schema_version !== 1 || record.port !== port ||
          typeof record.repositoryRoot !== 'string' || !path.isAbsolute(record.repositoryRoot) ||
          !samePath(record.repositoryRoot, repositoryRoot) ||
          typeof record.releaseRevision !== 'string' || !/^[a-f0-9]{64}$/u.test(record.releaseRevision)) continue
      const response = await fetchImpl(`http://127.0.0.1:${port}/api/live`, {
        headers: { 'sec-fetch-site': 'same-origin' },
        signal: AbortSignal.timeout(2_000),
      })
      if (!response.ok) continue
      const live = await response.json()
      if (live?.live === true && live.releaseRevision === record.releaseRevision) activePorts.push(port)
    } catch {
      // Stale or malformed instance records do not override the configured port.
    }
  }
  if (activePorts.length > 1) {
    throw new LauncherRuntimeConfigError('JY194_LAUNCHER_INSTANCE_AMBIGUOUS')
  }
  return activePorts[0] ?? configuredPort
}

/** @param {{source: string, gatewayPort: number}} config */
export const summarizeLauncherRuntimeConfig = (config) => Object.freeze({
  source: config?.source === 'launcher_config' ? 'launcher_config' : 'unavailable',
  gateway_port: Number.isInteger(config?.gatewayPort) ? config.gatewayPort : null,
  runtime_configured: config?.source === 'launcher_config',
})
