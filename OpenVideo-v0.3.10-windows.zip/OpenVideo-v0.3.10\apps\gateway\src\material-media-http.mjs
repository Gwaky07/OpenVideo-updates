import { createPreviewMediaResponse } from './workbench-preview.mjs'

const routePattern = /^\/api\/workbench\/projects\/([^/]+)\/materials\/assets\/([^/]+)\/(content|preview|hover|thumbnail)$/u
const thumbnailBatchRoutePattern = /^\/api\/workbench\/projects\/([^/]+)\/materials\/thumbnails$/u

/** @param {unknown} value @param {number} status */
const jsonResponse = (value, status) => new Response(JSON.stringify(value), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'cross-origin-resource-policy': 'same-origin',
    'x-content-type-options': 'nosniff',
  },
})

/** @param {string} code @param {number} status */
const publicError = (code, status) => jsonResponse({
  error: { code, message: 'Material media is unavailable.' },
}, status)

/** @param {unknown} error */
const errorResponse = (error) => {
  const code = error && typeof error === 'object' && 'code' in error ? error.code : null
  if (code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') return publicError('MATERIAL_MEDIA_RESCAN_REQUIRED', 409)
  if (code === 'MATERIAL_ANALYSIS_ASSET_NOT_FOUND') return publicError('MATERIAL_MEDIA_NOT_FOUND', 404)
  if (code === 'MATERIAL_ANALYSIS_MEDIA_FORMAT_UNSUPPORTED') return publicError('MATERIAL_MEDIA_FORMAT_UNSUPPORTED', 415)
  if (code === 'MATERIAL_ANALYSIS_MEDIA_RANGE_INVALID') return publicError('MATERIAL_MEDIA_RANGE_INVALID', 416)
  return publicError('MATERIAL_MEDIA_UNAVAILABLE', 503)
}

/**
 * @param {{
 *   runtime: {get: (id: string) => any},
 *   materialLibrary?: {resolveMediaBinding?: (projectId: string, assetId: string, options?: {validateAnalysis?: boolean}) => Promise<any>},
 *   materialAnalyzer: {
 *     resolveMaterialAssetResource?: (input: {authorizationId: string, projectId: string, assetId: string, signal?: AbortSignal}) => Promise<any>,
 *     resolveMaterialAssetPreview?: (input: {authorizationId: string, projectId: string, assetId: string, signal?: AbortSignal}) => Promise<any>,
 *     resolveMaterialAssetHoverPreview?: (input: {authorizationId: string, projectId: string, assetId: string, signal?: AbortSignal}) => Promise<any>,
 *     resolveMaterialAssetThumbnail?: (input: {authorizationId: string, projectId: string, assetId: string, signal?: AbortSignal}) => Promise<any>,
 *     resolveMaterialAssetThumbnails?: (input: {authorizationId: string, projectId: string, assetIds: string[], cachedOnly?: boolean, signal?: AbortSignal}) => Promise<any[]>,
 *   },
 * }} options
 */
export const createMaterialMediaRequestHandler = ({ runtime, materialAnalyzer, materialLibrary }) => {
  if (!runtime || typeof runtime.get !== 'function' || !materialAnalyzer || typeof materialAnalyzer !== 'object') {
    throw new TypeError('material_media_handler_config_invalid')
  }

  /** @param {Request} request */
  return async (request) => {
    const requestUrl = new URL(request.url)
    const pathname = requestUrl.pathname
    const batchMatch = pathname.match(thumbnailBatchRoutePattern)
    if (batchMatch) {
      if (request.method !== 'GET') return publicError('MATERIAL_MEDIA_METHOD_NOT_ALLOWED', 405)
      let projectId
      try {
        projectId = decodeURIComponent(batchMatch[1])
      } catch {
        return publicError('MATERIAL_MEDIA_REQUEST_INVALID', 400)
      }
      const assetIds = requestUrl.searchParams.getAll('assetId')
      if (
        assetIds.length < 1 ||
        assetIds.length > 24 ||
        new Set(assetIds).size !== assetIds.length ||
        assetIds.some((assetId) => !assetId || assetId.length > 160)
      ) return publicError('MATERIAL_MEDIA_REQUEST_INVALID', 400)
      const project = await runtime.get(projectId)
      let authorizationId = project?.materials?.authorizationId
      let bindingProjectId = projectId
      const localAssets = Array.isArray(project?.materials?.assets) ? project.materials.assets : []
      const hasEveryLocalAsset = project?.materials?.authorized === true && typeof authorizationId === 'string' &&
        assetIds.every((assetId) => localAssets.some((/** @type {any} */ asset) => asset?.id === assetId))
      if (!hasEveryLocalAsset) {
        try {
          const resolveMediaBinding = materialLibrary?.resolveMediaBinding
          const bindings = typeof resolveMediaBinding === 'function'
            ? await Promise.all(assetIds.map((assetId) => resolveMediaBinding(
                projectId,
                assetId,
                { validateAnalysis: false },
              )))
            : []
          const first = bindings[0]
          if (
            bindings.length !== assetIds.length ||
            !first ||
            typeof first.authorizationId !== 'string' ||
            typeof first.projectId !== 'string' ||
            bindings.some((binding, index) =>
              binding?.assetId !== assetIds[index] ||
              binding.authorizationId !== first.authorizationId ||
              binding.projectId !== first.projectId)
          ) return publicError('MATERIAL_MEDIA_NOT_FOUND', 404)
          authorizationId = first.authorizationId
          bindingProjectId = first.projectId
        } catch (error) {
          return errorResponse(error)
        }
      }
      if (typeof materialAnalyzer.resolveMaterialAssetThumbnails !== 'function') {
        return publicError('MATERIAL_MEDIA_UNAVAILABLE', 503)
      }
      try {
        const resources = await materialAnalyzer.resolveMaterialAssetThumbnails({
          authorizationId,
          projectId: bindingProjectId,
          assetIds,
          cachedOnly: requestUrl.searchParams.get('ready') === '1',
          signal: request.signal,
        })
        return jsonResponse({
          schema_version: 1,
          thumbnails: resources.filter(Boolean).map((resource) => ({
            assetId: resource.assetId,
            contentType: resource.contentType,
            data: resource.bytes.toString('base64'),
          })),
        }, 200)
      } catch (error) {
        return errorResponse(error)
      }
    }
    const match = pathname.match(routePattern)
    if (!match) return null
    if (!['GET', 'HEAD'].includes(request.method)) {
      return publicError('MATERIAL_MEDIA_METHOD_NOT_ALLOWED', 405)
    }
    let projectId
    let assetId
    try {
      projectId = decodeURIComponent(match[1])
      assetId = decodeURIComponent(match[2])
    } catch {
      return publicError('MATERIAL_MEDIA_REQUEST_INVALID', 400)
    }
    const project = await runtime.get(projectId)
    let authorizationId = project?.materials?.authorizationId
    let bindingProjectId = projectId
    if (project) {
      const assets = project.materials?.assets
      const hasLocalAsset = project.materials?.authorized === true && typeof authorizationId === 'string' &&
        Array.isArray(assets) && assets.some((asset) => asset && typeof asset === 'object' && asset.id === assetId)
      if (!hasLocalAsset && typeof materialLibrary?.resolveMediaBinding === 'function') {
        try {
          const binding = await materialLibrary.resolveMediaBinding(projectId, assetId, { validateAnalysis: false })
          if (binding?.assetId === assetId && typeof binding.authorizationId === 'string' && typeof binding.projectId === 'string') {
            authorizationId = binding.authorizationId
            bindingProjectId = binding.projectId
          }
        } catch (error) {
          return errorResponse(error)
        }
      }
      if (!hasLocalAsset && bindingProjectId === projectId) {
        if (project.materials?.authorized !== true || typeof authorizationId !== 'string' || !Array.isArray(assets)) {
          return publicError('MATERIAL_MEDIA_NOT_READY', 409)
        }
        return publicError('MATERIAL_MEDIA_NOT_FOUND', 404)
      }
    } else {
      try {
        const binding = typeof materialLibrary?.resolveMediaBinding === 'function'
          ? await materialLibrary.resolveMediaBinding(projectId, assetId, { validateAnalysis: false })
          : null
        if (!binding || binding.assetId !== assetId || typeof binding.authorizationId !== 'string' || typeof binding.projectId !== 'string') {
          return publicError('MATERIAL_MEDIA_PROJECT_NOT_FOUND', 404)
        }
        authorizationId = binding.authorizationId
        bindingProjectId = binding.projectId
      } catch (error) {
        return errorResponse(error)
      }
    }
    const resourceType = match[3]
    const resolver = resourceType === 'content'
      ? materialAnalyzer.resolveMaterialAssetResource
      : resourceType === 'preview'
        ? materialAnalyzer.resolveMaterialAssetPreview
        : resourceType === 'hover'
          ? materialAnalyzer.resolveMaterialAssetHoverPreview
          : materialAnalyzer.resolveMaterialAssetThumbnail
    if (typeof resolver !== 'function') return publicError('MATERIAL_MEDIA_UNAVAILABLE', 503)
    try {
      const resource = await resolver.call(materialAnalyzer, {
        authorizationId,
        projectId: bindingProjectId,
        assetId,
        signal: request.signal,
      })
      return createPreviewMediaResponse({
        resource,
        rangeHeader: request.headers.get('range'),
        method: request.method,
        // Every media use must reach the Gateway so authorization and the
        // current manifest are revalidated after revocation or replacement.
        cacheControl: 'private, no-cache',
        ifNoneMatch: request.headers.get('if-none-match'),
      })
    } catch (error) {
      return errorResponse(error)
    }
  }
}
