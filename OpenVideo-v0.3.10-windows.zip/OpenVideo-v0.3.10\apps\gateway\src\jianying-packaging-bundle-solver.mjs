import { createHash } from 'node:crypto'

import {
  assertPackagingParametersForCandidate,
  assertSafePackagingText,
  isOpaquePackagingToken,
  isPackagingWriterReadyEntry,
  searchPackagingResourceCandidates,
} from './jianying-packaging-resource-index.mjs'
import { projectRecommendationToRichTimeline } from './jianying-packaging-recommender.mjs'
import { selectJianyingWriterOwner } from './jianying-writer-owner-router.mjs'

const familyCapability = Object.freeze({
  flower: 'text.flower.private',
  bubble: 'text.bubble.private',
  sticker: 'sticker.named',
  filter: 'filter.video.named',
  video_effect: 'effect.video.named',
  video_animation: 'animation.video.named',
  mask: 'mask.video.named',
  blend: 'blend.video.named',
  transition: 'transition.dissolve',
  audio_effect: 'audio.effect.named',
  text_animation: 'animation.text.named',
})

const previewGapCodes = Object.freeze({
  'text.flower.private': 'FLOWER_TEXT_PREVIEW_DEGRADED',
  'text.bubble.private': 'BUBBLE_TEXT_PREVIEW_DEGRADED',
  'sticker.named': 'STICKER_PREVIEW_UNSUPPORTED',
  'filter.video.named': 'FILTER_VIDEO_PREVIEW_UNSUPPORTED',
  'effect.video.named': 'EFFECT_PREVIEW_UNSUPPORTED',
  'animation.video.named': 'ANIMATION_VIDEO_PREVIEW_UNSUPPORTED',
  'mask.video.named': 'MASK_VIDEO_PREVIEW_UNSUPPORTED',
  'blend.video.named': 'BLEND_VIDEO_PREVIEW_UNSUPPORTED',
  'audio.effect.named': 'AUDIO_EFFECT_PREVIEW_UNSUPPORTED',
  'animation.text.named': 'TEXT_ANIMATION_PREVIEW_UNSUPPORTED',
})

const scopePattern = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/u
const segmentIdPattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u
const solverSource = 'deterministic'

/**
 * @typedef {Readonly<{
 *   intentId: string,
 *   scopeId: string,
 *   families: readonly string[],
 *   query: string,
 *   targetSegmentId: string,
 *   targetRange: Readonly<{startUs: number, durationUs: number}>,
 *   parameters: Record<string, any>,
 * }>} NormalizedPackagingIntent
 */

/**
 * @typedef {Readonly<{
 *   scopeId: string,
 *   packagingToken: string,
 * }>} NegativeFeedbackEntry
 */

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {string} code @param {string} [reason] @returns {never} */
const fail = (code, reason = code) => {
  const error = /** @type {Error & {code: string}} */ (new Error(reason))
  error.code = code
  throw error
}

/** @param {unknown} value @param {string} field @param {number} max */
const safeOptionalText = (value, field, max) => {
  if (value == null || value === '') return ''
  return assertSafePackagingText(value, field, max)
}

/** @param {unknown} value */
const normalizeScopeId = (value) => {
  const scopeId = value == null || value === '' ? 'global' : assertSafePackagingText(value, 'scope_id', 128)
  if (!scopePattern.test(scopeId)) fail('JY201_SCOPE_INVALID')
  return scopeId
}

/** @param {unknown} value */
const normalizeTargetSegmentId = (value) => {
  const targetSegmentId = assertSafePackagingText(value, 'target_segment_id', 180)
  if (!segmentIdPattern.test(targetSegmentId)) fail('JY201_TARGET_SEGMENT_INVALID')
  return targetSegmentId
}

/** @param {unknown} value */
const normalizeTargetRange = (value) => {
  if (!isRecord(value) ||
      !Number.isSafeInteger(value.startUs) ||
      !Number.isSafeInteger(value.durationUs) ||
      value.startUs < 0 ||
      value.durationUs <= 0) {
    fail('JY201_TARGET_RANGE_INVALID')
  }
  return Object.freeze({
    startUs: value.startUs,
    durationUs: value.durationUs,
  })
}

/** @param {unknown} value @returns {readonly string[]} */
const normalizeFamilies = (value) => {
  const rawFamilies = Array.isArray(value) ? value : [value]
  const families = [...new Set(rawFamilies
    .filter((family) => typeof family === 'string')
    .map((family) => family.trim())
    .filter((family) => family.length > 0))]
  if (families.length === 0 || families.length > 8) fail('JY201_FAMILY_INVALID')
  for (const family of families) {
    if (!Object.hasOwn(familyCapability, family)) fail('JY201_FAMILY_INVALID')
  }
  return Object.freeze(families)
}

/** @param {unknown} value @returns {readonly NegativeFeedbackEntry[]} */
const normalizeNegativeFeedback = (value) => {
  if (value == null) return Object.freeze([])
  if (!Array.isArray(value) || value.length > 256) fail('JY201_NEGATIVE_FEEDBACK_INVALID')
  return Object.freeze(value.map((entry) => {
    if (!isRecord(entry) || !isOpaquePackagingToken(entry.packagingToken)) {
      fail('JY201_NEGATIVE_FEEDBACK_INVALID')
    }
    return Object.freeze({
      scopeId: normalizeScopeId(entry.scopeId),
      packagingToken: entry.packagingToken,
    })
  }))
}

/** @param {unknown} value @returns {NormalizedPackagingIntent} */
const normalizeIntent = (value) => {
  if (!isRecord(value)) fail('JY201_INTENT_INVALID')
  const targetRange = value.targetRange === undefined
    ? normalizeTargetRange({ startUs: value.startUs, durationUs: value.durationUs })
    : normalizeTargetRange(value.targetRange)
  const intentId = value.intentId == null || value.intentId === ''
    ? `intent-${targetRange.startUs}-${targetRange.durationUs}`
    : assertSafePackagingText(value.intentId, 'intent_id', 120)
  const parameters = value.parameters === undefined
    ? {}
    : isRecord(value.parameters)
      ? value.parameters
      : fail('JY201_PARAMETERS_INVALID')
  return Object.freeze({
    intentId,
    scopeId: normalizeScopeId(value.scopeId),
    families: normalizeFamilies(value.families ?? value.family),
    query: safeOptionalText(value.query, 'query', 200),
    targetSegmentId: normalizeTargetSegmentId(value.targetSegmentId),
    targetRange,
    parameters,
  })
}

/** @param {unknown} index @param {unknown} capabilityRegistry */
const assertSolverDependencies = (index, capabilityRegistry) => {
  if (!isRecord(index) || index.schemaVersion !== 1 || !Array.isArray(index.entries) ||
      typeof index.catalogRevisionToken !== 'string') {
    fail('JY201_INDEX_REQUIRED')
  }
  if (!capabilityRegistry || typeof capabilityRegistry !== 'object' ||
      typeof /** @type {Record<string, unknown>} */ (capabilityRegistry).assertWriterCapability !== 'function' ||
      typeof /** @type {Record<string, unknown>} */ (capabilityRegistry).list !== 'function') {
    fail('JY201_CAPABILITY_REGISTRY_REQUIRED')
  }
}

/** @param {Record<string, any>} index @param {string} packagingToken */
const findCatalogEntry = (index, packagingToken) =>
  index.entries.find((/** @type {Record<string, any>} */ entry) => entry?.packaging_token === packagingToken) ?? null

/** @param {readonly NegativeFeedbackEntry[]} negativeFeedback */
const buildNegativeFeedbackSet = (negativeFeedback) =>
  new Set(negativeFeedback.map((entry) => `${entry.scopeId}\u0000${entry.packagingToken}`))

/** @param {Record<string, any>} capabilityRegistry @param {string} capabilityId */
const assertJianyingWriterCapability = (capabilityRegistry, capabilityId) => {
  try {
    return capabilityRegistry.assertWriterCapability(capabilityId, 'jianying')
  } catch {
    return null
  }
}

/** @param {Record<string, any>} capabilityRegistry @param {readonly string[]} capabilityIds */
const summarizePreflight = (capabilityRegistry, capabilityIds) => {
  const listed = capabilityRegistry.list?.().capabilities
  const entries = new Map((Array.isArray(listed) ? listed : [])
    .filter((entry) => isRecord(entry) && typeof entry.capabilityId === 'string')
    .map((entry) => [entry.capabilityId, entry]))
  const capabilities = capabilityIds.map((capabilityId) => {
    const entry = entries.get(capabilityId)
    const jianyingReady = Boolean(assertJianyingWriterCapability(capabilityRegistry, capabilityId))
    const previewStatus = entry?.targets?.preview?.status === 'implemented' ||
      entry?.targets?.preview?.status === 'degraded' ||
      entry?.targets?.preview?.status === 'unsupported'
      ? entry.targets.preview.status
      : 'unsupported'
    const jianyingStatus = jianyingReady
      ? 'implemented'
      : entry?.targets?.jianying?.status === 'degraded'
        ? 'degraded'
        : 'unsupported'
    return Object.freeze({
      capabilityId,
      previewStatus,
      previewDegradationCode: typeof entry?.targets?.preview?.degradationCode === 'string'
        ? entry.targets.preview.degradationCode
        : null,
      jianyingStatus,
      jianyingDegradationCode: typeof entry?.targets?.jianying?.degradationCode === 'string'
        ? entry.targets.jianying.degradationCode
        : null,
    })
  })
  const previewStatuses = capabilities.map((entry) => entry.previewStatus)
  const jianyingReady = capabilities.every((entry) => entry.jianyingStatus === 'implemented')
  const previewStatus = previewStatuses.includes('unsupported')
    ? 'unsupported'
    : previewStatuses.includes('degraded')
      ? 'degraded'
      : 'implemented'
  const degradationCodes = [...new Set(capabilities
    .filter((entry) => entry.previewStatus !== 'implemented')
    .map((entry) => entry.previewDegradationCode ?? previewGapCodes[
      /** @type {keyof typeof previewGapCodes} */ (entry.capabilityId)
    ])
    .filter((value) => typeof value === 'string'))]
  return Object.freeze({
    status: !jianyingReady
      ? 'blocked'
      : previewStatus === 'implemented'
        ? 'ready'
        : 'preview_degraded',
    targets: Object.freeze({
      jianying: Object.freeze({
        status: jianyingReady ? 'ready' : 'blocked',
        capabilityIds: Object.freeze([...capabilityIds]),
      }),
      preview: Object.freeze({
        status: previewStatus === 'implemented' ? 'ready' : 'preview_degraded',
        capabilityStatus: previewStatus,
        degradationCodes: Object.freeze(degradationCodes),
      }),
    }),
    capabilities: Object.freeze(capabilities),
  })
}

/** @param {Record<string, any>} input */
const fingerprintBundle = (input) =>
  createHash('sha256').update(JSON.stringify(input)).digest('hex')

/**
 * Pick one safe candidate per intent. Search stays public-safe, but each final
 * token is re-gated against the exact admitted private entry and current target
 * capability state before it can enter the canonical bundle.
 * @param {{
 *   index: Record<string, any>,
 *   capabilityRegistry: Record<string, any>,
 *   intent: NormalizedPackagingIntent,
 *   usedTokens: Set<string>,
 *   excludedTokens: Set<string>,
 *   topNPerFamily: number,
 * }} input
 */
const selectCandidateForIntent = ({
  index,
  capabilityRegistry,
  intent,
  usedTokens,
  excludedTokens,
  topNPerFamily,
}) => {
  for (const family of intent.families) {
    const capabilityId = familyCapability[/** @type {keyof typeof familyCapability} */ (family)]
    if (typeof capabilityId !== 'string') continue
    const ranked = searchPackagingResourceCandidates(index, intent.query, {
      family,
      limit: topNPerFamily,
    })
    for (const candidate of ranked) {
      if (usedTokens.has(candidate.packagingToken) ||
          excludedTokens.has(`${intent.scopeId}\u0000${candidate.packagingToken}`)) {
        continue
      }
      const entry = findCatalogEntry(index, candidate.packagingToken)
      if (!entry || !isPackagingWriterReadyEntry(entry)) continue
      if (!assertJianyingWriterCapability(capabilityRegistry, capabilityId)) continue
      const parameters = assertPackagingParametersForCandidate(
        family,
        entry.parameter_schema ?? {},
        intent.parameters,
      )
      return Object.freeze({
        packagingToken: candidate.packagingToken,
        family,
        capabilityId,
        label: candidate.label,
        tags: candidate.tags,
        targetSegmentId: intent.targetSegmentId,
        targetRange: intent.targetRange,
        parameters,
        reason: 'deterministic bundle candidate match',
      })
    }
  }
  fail('JY201_BUNDLE_UNSOLVABLE')
}

/**
 * @param {{
 *   index: Record<string, any>,
 *   capabilityRegistry: Record<string, any>,
 *   intents: unknown,
 *   providers: unknown,
 *   admissionRegistry: unknown,
 *   negativeFeedback?: unknown,
 *   preferredProvider?: unknown,
 *   topNPerFamily?: number,
 * }} input
 */
export const solveJianyingPackagingBundle = async ({
  index,
  capabilityRegistry,
  intents,
  providers,
  admissionRegistry,
  negativeFeedback = [],
  preferredProvider = null,
  topNPerFamily = 5,
}) => {
  assertSolverDependencies(index, capabilityRegistry)
  if (!Array.isArray(intents) || intents.length === 0 || intents.length > 24) fail('JY201_INTENTS_REQUIRED')
  if (!Number.isSafeInteger(topNPerFamily) || topNPerFamily <= 0 || topNPerFamily > 20) {
    fail('JY201_TOPN_INVALID')
  }
  const boundedTopNPerFamily = /** @type {number} */ (topNPerFamily)
  const normalizedIntents = intents.map(normalizeIntent)
  const exclusions = buildNegativeFeedbackSet(normalizeNegativeFeedback(negativeFeedback))
  /** @type {Set<string>} */
  const usedTokens = new Set()
  const selected = normalizedIntents.map((intent) => {
    const choice = selectCandidateForIntent({
      index,
      capabilityRegistry,
      intent,
      usedTokens,
      excludedTokens: exclusions,
      topNPerFamily: boundedTopNPerFamily,
    })
    usedTokens.add(choice.packagingToken)
    return choice
  })
  const requiredCapabilities = Object.freeze([...new Set(selected
    .map((entry) => entry.capabilityId))]
    .sort())
  const owner = await selectJianyingWriterOwner({
    requiredCapabilities,
    providers,
    admissionRegistry,
    preferredProvider,
  })
  const recommendation = Object.freeze({
    recommendationId: `ovjrec_v1_${fingerprintBundle({
      catalogRevisionToken: index.catalogRevisionToken,
      selected: selected.map((entry) => ({
        packagingToken: entry.packagingToken,
        family: entry.family,
        targetSegmentId: entry.targetSegmentId,
        targetRange: entry.targetRange,
        parameters: entry.parameters,
      })),
    }).slice(0, 24)}`,
    catalogRevisionToken: index.catalogRevisionToken,
    source: solverSource,
    selected: Object.freeze(selected.map((entry) => Object.freeze({
      packagingToken: entry.packagingToken,
      family: entry.family,
      label: entry.label,
      tags: Object.freeze([...entry.tags]),
      targetSegmentId: entry.targetSegmentId,
      targetRange: Object.freeze({ ...entry.targetRange }),
      parameters: Object.freeze({ ...entry.parameters }),
      reason: entry.reason,
    }))),
  })
  const canonicalBindings = Object.freeze(projectRecommendationToRichTimeline(recommendation, {
    index,
    allowedTargetSegmentIds: new Set(normalizedIntents.map((intent) => intent.targetSegmentId)),
  }).map((entry) => Object.freeze(structuredClone(entry))))
  const preflight = summarizePreflight(capabilityRegistry, requiredCapabilities)
  return Object.freeze({
    bundleFingerprint: fingerprintBundle({
      catalogRevisionToken: recommendation.catalogRevisionToken,
      ownerId: owner.ownerId,
      requiredCapabilities,
      selected: recommendation.selected,
      preflightStatus: preflight.status,
    }),
    catalogRevisionToken: recommendation.catalogRevisionToken,
    owner: Object.freeze({
      ownerId: owner.ownerId,
      providerCommit: owner.providerCommit,
      ownerIdentity: owner.ownerIdentity,
      requiredCapabilities,
    }),
    recommendation,
    canonicalBindings,
    preflight,
  })
}

/**
 * @param {{
 *   index: Record<string, any>,
 *   capabilityRegistry: Record<string, any>,
 *   providers: unknown,
 *   admissionRegistry: unknown,
 *   preferredProvider?: unknown,
 *   topNPerFamily?: number,
 * }} input
 */
export const createJianyingPackagingBundleSolver = ({
  index,
  capabilityRegistry,
  providers,
  admissionRegistry,
  preferredProvider = null,
  topNPerFamily = 5,
}) => Object.freeze({
  /** @param {Omit<Parameters<typeof solveJianyingPackagingBundle>[0], 'index' | 'capabilityRegistry' | 'providers' | 'admissionRegistry' | 'preferredProvider' | 'topNPerFamily'>} input */
  solve: (input) => solveJianyingPackagingBundle({
    index,
    capabilityRegistry,
    providers,
    admissionRegistry,
    preferredProvider,
    topNPerFamily,
    ...input,
  }),
})
