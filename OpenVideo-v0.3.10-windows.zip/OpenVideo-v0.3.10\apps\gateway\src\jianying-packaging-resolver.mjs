/**
 * Auditable token → provider-neutral name / private path resolvers for Jianying packaging.
 * Never hard-codes CapCut/Jianying internal resource IDs; only opaque OpenVideo tokens.
 */

export class JianyingPackagingResolverError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'JianyingPackagingResolverError'
    this.code = code
    this.status = status
  }
}

/** Opaque transition tokens → pyJianYingDraft TransitionType member names (display names). */
const transitionNameByToken = Object.freeze({
  dissolve: '叠化',
})

/** Opaque style tokens → TextStyle / ClipSettings projection (no internal IDs). */
const textStyleByToken = Object.freeze({
  default: Object.freeze({ size: 7.8, color: Object.freeze([1.0, 1.0, 1.0]), transformY: -0.88 }),
  bottom_safe: Object.freeze({
    size: 7.8,
    color: Object.freeze([1.0, 1.0, 1.0]),
    transformY: -0.88,
  }),
  rich_emphasis: Object.freeze({
    size: 9.0,
    color: Object.freeze([1.0, 0.92, 0.2]),
    transformY: -0.15,
  }),
  title_card: Object.freeze({
    size: 8.0,
    color: Object.freeze([1.0, 1.0, 1.0]),
    transformY: 0.0,
  }),
  'caption-basic': Object.freeze({
    size: 7.8,
    color: Object.freeze([1.0, 1.0, 1.0]),
    transformY: -0.88,
  }),
  'caption-bottom-safe': Object.freeze({
    size: 7.8,
    color: Object.freeze([1.0, 1.0, 1.0]),
    transformY: -0.88,
  }),
  'rich-emphasis': Object.freeze({
    size: 9.0,
    color: Object.freeze([1.0, 0.92, 0.2]),
    transformY: -0.15,
  }),
  'title-card': Object.freeze({
    size: 8.0,
    color: Object.freeze([1.0, 1.0, 1.0]),
    transformY: 0.0,
  }),
})

const opaqueIdPattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u
const audioEffectTokenPattern = /^ovjaudfx_v1_[a-f0-9]{64}$/u
/** Recipe style token: rs-<size10>-<rrggbb>-(n|p)<abs(y*100)> */
const recipeStyleTokenPattern =
  /^rs-(\d{1,3})-([0-9a-f]{6})-([np])(\d{1,3})$/u

/** @param {unknown} value @returns {value is string} */
const isOpaqueToken = (value) => typeof value === 'string' && opaqueIdPattern.test(value)

/**
 * Encode a learned caption style into an opaque, path-free style token.
 * @param {{ size?: number | null, color?: string | null, transformY?: number | null }} style
 */
export const encodeRecipeTextStyleToken = (style = {}) => {
  const size = Number.isFinite(style.size) ? Number(style.size) : 5
  const sizePart = Math.max(1, Math.min(200, Math.round(size * 10)))
  const color = typeof style.color === 'string' && /^#[0-9a-f]{6}$/iu.test(style.color)
    ? style.color.slice(1).toLowerCase()
    : 'ffffff'
  const transformY = Number.isFinite(style.transformY) ? Number(style.transformY) : -0.8
  const yPart = Math.max(0, Math.min(200, Math.round(Math.abs(transformY) * 100)))
  const sign = transformY < 0 ? 'n' : 'p'
  return `rs-${sizePart}-${color}-${sign}${yPart}`
}

/** @param {string} token */
const parseRecipeTextStyleToken = (token) => {
  const match = recipeStyleTokenPattern.exec(token)
  if (!match) return null
  const size = Number(match[1]) / 10
  const colorHex = match[2]
  const sign = match[3] === 'n' ? -1 : 1
  const transformY = sign * (Number(match[4]) / 100)
  const r = Number.parseInt(colorHex.slice(0, 2), 16) / 255
  const g = Number.parseInt(colorHex.slice(2, 4), 16) / 255
  const b = Number.parseInt(colorHex.slice(4, 6), 16) / 255
  return {
    size,
    color: Object.freeze([r, g, b]),
    transformY,
  }
}

/**
 * @param {{
 *   resolveAudioPath?: (input: {audioToken: string}) => Promise<string | null> | string | null,
 *   resolveAudioEffectToken?: (input: {effectToken: string}) => Promise<{resourceId: string} | null> | {resourceId: string} | null,
 *   resolvePackagingToken?: (input: {packagingToken: string}) => Promise<{kind: string, resourceId: string, effectId?: string, durationUs?: number, commonMaskTemplate?: Record<string, any>, fillType?: string, blur?: number, color?: string} | null> | {kind: string, resourceId: string, effectId?: string, durationUs?: number, commonMaskTemplate?: Record<string, any>, fillType?: string, blur?: number, color?: string} | null,
 * }} [options]
 */
export const createJianyingPackagingResolver = (options = {}) => {
  const resolveAudioPath =
    typeof options.resolveAudioPath === 'function' ? options.resolveAudioPath : null
  const resolveAudioEffectTokenFn =
    typeof options.resolveAudioEffectToken === 'function' ? options.resolveAudioEffectToken : null
  const resolvePackagingTokenFn =
    typeof options.resolvePackagingToken === 'function' ? options.resolvePackagingToken : null

  return {
    /**
     * @param {string} capabilityId
     * @returns {{token: string, transitionName: string | null}}
     */
    resolveTransition(capabilityId) {
      if (capabilityId === 'transition.cut' || capabilityId === 'transition.none') {
        return { token: capabilityId.slice('transition.'.length), transitionName: null }
      }
      if (capabilityId === 'transition.dissolve') {
        return { token: 'dissolve', transitionName: transitionNameByToken.dissolve }
      }
      throw new JianyingPackagingResolverError('JY004_TRANSITION_TOKEN_UNRESOLVED')
    },

    /** @param {unknown} styleToken @param {'default' | 'bottom_safe' | 'rich_emphasis' | 'title_card'} [fallback] */
    resolveTextStyle(styleToken, fallback = 'default') {
      const token =
        styleToken === null || styleToken === undefined || styleToken === ''
          ? fallback
          : styleToken
      if (!isOpaqueToken(token)) {
        throw new JianyingPackagingResolverError('JY004_STYLE_TOKEN_UNRESOLVED')
      }
      const recipeStyle = parseRecipeTextStyleToken(token)
      if (recipeStyle) {
        return { token, style: structuredClone(recipeStyle) }
      }
      if (!Object.hasOwn(textStyleByToken, token)) {
        throw new JianyingPackagingResolverError('JY004_STYLE_TOKEN_UNRESOLVED')
      }
      return {
        token,
        style: structuredClone(
          textStyleByToken[/** @type {keyof typeof textStyleByToken} */ (token)],
        ),
      }
    },

    /** @param {unknown} audioToken */
    async resolveAudioToken(audioToken) {
      if (!isOpaqueToken(audioToken)) {
        throw new JianyingPackagingResolverError('JY002_VOICEOVER_AUDIO_MISSING')
      }
      if (!resolveAudioPath) {
        throw new JianyingPackagingResolverError('JY002_VOICEOVER_AUDIO_MISSING')
      }
      const path = await resolveAudioPath({ audioToken })
      if (typeof path !== 'string' || path.length === 0) {
        throw new JianyingPackagingResolverError('JY002_VOICEOVER_AUDIO_MISSING')
      }
      return { audioToken, path }
    },

    /** @param {unknown} effectToken */
    async resolveAudioEffectToken(effectToken) {
      if (typeof effectToken !== 'string' || !audioEffectTokenPattern.test(effectToken) || !resolveAudioEffectTokenFn) {
        throw new JianyingPackagingResolverError('JY067_AUDIO_EFFECT_TOKEN_UNRESOLVED')
      }
      let resolved
      try {
        resolved = await resolveAudioEffectTokenFn({ effectToken })
      } catch {
        throw new JianyingPackagingResolverError('JY067_AUDIO_EFFECT_TOKEN_UNRESOLVED')
      }
      if (!resolved || typeof resolved.resourceId !== 'string' || !/^[A-Za-z0-9_-]{4,80}$/u.test(resolved.resourceId)) {
        throw new JianyingPackagingResolverError('JY067_AUDIO_EFFECT_TOKEN_UNRESOLVED')
      }
      return { effectToken, resourceId: resolved.resourceId }
    },

    /** @param {unknown} packagingToken */
    async resolvePackagingToken(packagingToken) {
      if (!isOpaqueToken(packagingToken)) {
        throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
      }
      if (!resolvePackagingTokenFn) {
        throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
      }
      const resolved = await resolvePackagingTokenFn({ packagingToken })
      if (
        !resolved ||
        typeof resolved.resourceId !== 'string' ||
        !/^[A-Za-z0-9_-]{4,80}$/u.test(resolved.resourceId) ||
        !['sticker', 'effect', 'flower', 'bubble', 'mask', 'blend', 'background', 'animation'].includes(resolved.kind) ||
        (
          (resolved.kind === 'bubble' ||
            (resolved.kind === 'flower' && packagingToken.startsWith('ovjpack_v1_'))) &&
          (
            typeof resolved.effectId !== 'string' ||
            !/^[A-Za-z0-9_-]{4,80}$/u.test(resolved.effectId)
          )
        )
      ) {
        throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
      }
      const result = {
        packagingToken,
        kind: resolved.kind,
        resourceId: resolved.resourceId,
      }
      if (resolved.kind === 'flower' || resolved.kind === 'bubble' || resolved.kind === 'effect') {
        return {
          ...result,
          ...(resolved.kind === 'effect' && typeof resolved.effectId !== 'string'
            ? {}
            : { effectId: typeof resolved.effectId === 'string' ? resolved.effectId : resolved.resourceId }),
        }
      }
      if (resolved.kind === 'mask') {
        if (!resolved.commonMaskTemplate || typeof resolved.commonMaskTemplate !== 'object') {
          throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
        }
        return { ...result, commonMaskTemplate: structuredClone(resolved.commonMaskTemplate) }
      }
      if (resolved.kind === 'animation') {
        const durationUs = resolved.durationUs
        if (typeof durationUs !== 'number' || !Number.isSafeInteger(durationUs) || durationUs <= 0 || durationUs > 10_000_000) {
          throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
        }
        return { ...result, durationUs }
      }
      if (resolved.kind === 'background') {
        if (
          typeof resolved.fillType !== 'string' || !['blur', 'color'].includes(resolved.fillType) ||
          typeof resolved.blur !== 'number' || !Number.isFinite(resolved.blur) ||
          resolved.blur < 0 || resolved.blur > 1 ||
          typeof resolved.color !== 'string' || !/^#[0-9A-Fa-f]{8}$/u.test(resolved.color)
        ) throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
        return { ...result, fillType: resolved.fillType, blur: resolved.blur, color: resolved.color }
      }
      return result
    },

    listTransitionTokens: () => structuredClone(transitionNameByToken),
    listStyleTokens: () => Object.keys(textStyleByToken),
  }
}
