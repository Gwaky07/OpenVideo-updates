[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$MaterialRoot,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [string]$RepositoryRoot,
    [string]$UpstreamRoot,
    [switch]$PassThru
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)
$isWindowsPlatform = $env:OS -eq 'Windows_NT'
$pathComparison = if ($isWindowsPlatform) { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
if (-not $RepositoryRoot) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
if (-not $UpstreamRoot) { $UpstreamRoot = Join-Path $RepositoryRoot 'upstream/edit-mind' }

function Remove-TrailingDirectorySeparator {
    param([string]$Path)
    $root = [IO.Path]::GetPathRoot($Path)
    if ($Path.Length -le $root.Length) { return $Path }
    return $Path.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar))
}

function Test-ValidTcpPort {
    param([string]$Value)
    if ($Value -notmatch '^[1-9]\d{0,4}$') { return $false }
    $port = [int]$Value
    return $port -ge 1 -and $port -le 65535
}

function Get-SafeAbsolutePath {
    param([string]$Path, [bool]$MustExist, [string]$Name)

    if ($Path.IndexOfAny([char[]]@([char]44, [char]13, [char]10)) -ge 0) {
        throw "$Name contains characters that are unsafe for Docker bind-mount arguments: $Path"
    }
    $isAbsolute = [IO.Path]::IsPathRooted($Path)
    if ($isWindowsPlatform -and $Path.Length -ge 2 -and $Path[1] -eq ':') {
        $isAbsolute = $Path.Length -ge 3 -and ($Path[2] -eq '\' -or $Path[2] -eq '/')
    }
    if (-not $isAbsolute) { throw "$Name must be an absolute path: $Path" }
    $fullPath = Remove-TrailingDirectorySeparator ([IO.Path]::GetFullPath($Path))
    $rootPath = Remove-TrailingDirectorySeparator ([IO.Path]::GetPathRoot($fullPath))
    if ($fullPath.Equals($rootPath, $pathComparison)) { throw "$Name cannot be a filesystem root: $fullPath" }

    $existingPath = $fullPath
    while (-not (Test-Path -LiteralPath $existingPath)) {
        $parent = Split-Path -Parent $existingPath
        if (-not $parent -or $parent -eq $existingPath) { throw "$Name has no resolvable parent: $fullPath" }
        $existingPath = $parent
    }
    if ($MustExist -and -not (Test-Path -LiteralPath $fullPath -PathType Container)) { throw "$Name must exist as a directory: $fullPath" }

    $cursor = $existingPath
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $item.PSObject.Properties.Name -contains 'LinkType' -and $null -ne $item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "$Name crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
    return $fullPath
}

function Test-PathContains {
    param([string]$Parent, [string]$Candidate)
    $prefix = $Parent + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($Parent, $pathComparison) -or $Candidate.StartsWith($prefix, $pathComparison)
}

function New-RandomHex {
    param([int]$Bytes)
    $buffer = New-Object byte[] $Bytes
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $generator.GetBytes($buffer) } finally { $generator.Dispose() }
    return -join ($buffer | ForEach-Object { $_.ToString('x2') })
}

function Set-PrivateRuntimeAcl {
    param([string]$Path)
    if (-not $isWindowsPlatform) {
        & chmod 700 -- $Path
        if ($LASTEXITCODE -ne 0) { throw 'Unable to secure RuntimeDataRoot permissions.' }
        return
    }
    $userSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $allowedSids = @($userSid, 'S-1-5-18', 'S-1-5-32-544')
    $targets = @((Get-Item -LiteralPath $Path -Force)) + @(Get-ChildItem -LiteralPath $Path -Force -Recurse)
    foreach ($target in $targets) {
        if (($target.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "RuntimeDataRoot contains a reparse point: $($target.FullName)"
        }
        $currentAcl = Get-Acl -LiteralPath $target.FullName
        $currentRules = @($currentAcl.Access)
        $alreadyPrivate = $currentAcl.AreAccessRulesProtected -and
            $currentRules.Count -eq $allowedSids.Count -and
            @($currentRules | Where-Object {
                $_.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
                $_.IsInherited -or
                ($_.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -ne
                    [Security.AccessControl.FileSystemRights]::FullControl -or
                $allowedSids -notcontains $_.IdentityReference.Translate(
                    [Security.Principal.SecurityIdentifier]
                ).Value
            }).Count -eq 0
        if ($alreadyPrivate) { continue }
        $acl = if ($target.PSIsContainer) {
            New-Object Security.AccessControl.DirectorySecurity
        } else {
            New-Object Security.AccessControl.FileSecurity
        }
        $acl.SetAccessRuleProtection($true, $false)
        $inheritance = if ($target.PSIsContainer) {
            [Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
        } else {
            [Security.AccessControl.InheritanceFlags]::None
        }
        foreach ($sidText in $allowedSids) {
            $sid = New-Object Security.Principal.SecurityIdentifier($sidText)
            $rule = New-Object Security.AccessControl.FileSystemAccessRule(
                $sid,
                [Security.AccessControl.FileSystemRights]::FullControl,
                $inheritance,
                [Security.AccessControl.PropagationFlags]::None,
                [Security.AccessControl.AccessControlType]::Allow
            )
            [void]$acl.AddAccessRule($rule)
        }
        Set-Acl -LiteralPath $target.FullName -AclObject $acl
    }
}

$materialPath = Get-SafeAbsolutePath -Path $MaterialRoot -MustExist $true -Name 'MaterialRoot'
$runtimePath = Get-SafeAbsolutePath -Path $RuntimeDataRoot -MustExist $false -Name 'RuntimeDataRoot'
$repositoryPath = Get-SafeAbsolutePath -Path $RepositoryRoot -MustExist $true -Name 'RepositoryRoot'
$upstreamPath = Get-SafeAbsolutePath -Path $UpstreamRoot -MustExist $true -Name 'UpstreamRoot'

if ((Test-PathContains $materialPath $runtimePath) -or (Test-PathContains $runtimePath $materialPath)) {
    throw 'MaterialRoot and RuntimeDataRoot must be different and must not contain one another.'
}
if ((Test-PathContains $repositoryPath $runtimePath) -or (Test-PathContains $runtimePath $repositoryPath)) {
    throw 'RuntimeDataRoot must be separate from the OpenVideo repository.'
}
if ((Test-PathContains $upstreamPath $runtimePath) -or (Test-PathContains $runtimePath $upstreamPath)) {
    throw 'RuntimeDataRoot must be separate from the Edit Mind checkout.'
}
if ((Test-PathContains $repositoryPath $materialPath) -or (Test-PathContains $materialPath $repositoryPath)) {
    throw 'MaterialRoot must be separate from the OpenVideo repository.'
}
if ((Test-PathContains $upstreamPath $materialPath) -or (Test-PathContains $materialPath $upstreamPath)) {
    throw 'MaterialRoot must be separate from the Edit Mind checkout.'
}

$relativeDirectories = @(
    'app-data',
    'cache/redis',
    'config',
    'database/postgres',
    'indexes/chroma',
    'logs',
    'models',
    'tmp/background-jobs',
    'tmp/ml',
    'tmp/web'
)
New-Item -ItemType Directory -Path $runtimePath -Force | Out-Null
Set-PrivateRuntimeAcl -Path $runtimePath
foreach ($relativeDirectory in $relativeDirectories) {
    New-Item -ItemType Directory -Path (Join-Path $runtimePath $relativeDirectory) -Force | Out-Null
}

$composeEnvironmentPath = Join-Path $runtimePath 'config/compose.env'
if (-not (Test-Path -LiteralPath $composeEnvironmentPath)) {
    $postgresPassword = New-RandomHex -Bytes 24
    $ollamaModelAlias = "ov-$(New-RandomHex -Bytes 24)"
    $environmentLines = @(
        "SESSION_SECRET=$(New-RandomHex -Bytes 32)",
        "ENCRYPTION_KEY=$(New-RandomHex -Bytes 32)",
        'USE_OLLAMA_MODEL=true',
        'USE_GEMINI=false',
        'OLLAMA_HOST=http://ollama-bridge',
        'OLLAMA_PORT=11434',
        "OLLAMA_MODEL=$ollamaModelAlias",
        "OPENVIDEO_OLLAMA_MODEL_ALIAS=$ollamaModelAlias",
        'CHROMA_PORT=8000',
        'CHROMA_HOST_PORT=8000',
        'PORT=3745',
        'BACKGROUND_JOBS_PORT=4000',
        'ML_PORT=8765',
        'REDIS_PORT=6379',
        'POSTGRES_PORT=5432',
        'POSTGRES_USER=openvideo',
        "POSTGRES_PASSWORD=$postgresPassword",
        'POSTGRES_DB=editmind',
        "DATABASE_URL=postgresql://openvideo:$postgresPassword@postgres:5432/editmind",
        'PGDATA=/var/lib/postgresql/data/pgdata',
        'REDIS_URL=redis://redis:6379',
        'REDIS_HOST=redis',
        'CHROMA_HOST=chroma',
        'IS_PERSISTENT=TRUE',
        'ML_HOST=ml',
        'PROCESSED_VIDEOS_DIR=/app/data',
        'THUMBNAILS_PATH=/app/data/.thumbnails',
        'STITCHED_VIDEOS_DIR=/app/data/.stitched-videos',
        'FACES_DIR=/app/data/.faces',
        'UNKNOWN_FACES_DIR=/app/data/.unknown_faces',
        'KNOWN_FACES_FILE=/app/data/.faces.json',
        'KNOWN_FACES_FILE_LOADED=/app/data/.known_faces.json',
        'BACKGROUND_JOBS_URL=http://background-jobs:4000',
        'NODE_ENV=production',
        'ANONYMIZED_TELEMETRY=FALSE',
        'WEB_APP_URL=http://web:3745'
    )
    [IO.File]::WriteAllLines($composeEnvironmentPath, $environmentLines, $utf8)
}
$composeEnvironment = @(Get-Content -LiteralPath $composeEnvironmentPath -Encoding UTF8)
$composeEnvironmentChanged = $false
$fixedBridgeSettings = [ordered]@{
    USE_OLLAMA_MODEL = 'true'
    USE_GEMINI = 'false'
    OLLAMA_HOST = 'http://ollama-bridge'
    OLLAMA_PORT = '11434'
}
foreach ($setting in $fixedBridgeSettings.GetEnumerator()) {
    $matchingIndexes = @(0..($composeEnvironment.Count - 1) | Where-Object { $composeEnvironment[$_] -match "^$([regex]::Escape($setting.Key))=" })
    if ($matchingIndexes.Count -gt 1) { throw "Existing compose.env contains duplicate $($setting.Key)." }
    $expectedEntry = "$($setting.Key)=$($setting.Value)"
    if ($matchingIndexes.Count -eq 0) {
        $composeEnvironment += $expectedEntry
        $composeEnvironmentChanged = $true
    } elseif ($composeEnvironment[$matchingIndexes[0]] -ne $expectedEntry) {
        if ($setting.Key -eq 'USE_OLLAMA_MODEL' -and $composeEnvironment[$matchingIndexes[0]] -eq 'USE_OLLAMA_MODEL=false') {
            $composeEnvironment[$matchingIndexes[0]] = $expectedEntry
            $composeEnvironmentChanged = $true
        } else {
            throw "Existing compose.env has an incompatible $($setting.Key) value."
        }
    }
}

$modelEntries = @($composeEnvironment | Where-Object { $_ -match '^OLLAMA_MODEL=' })
if ($modelEntries.Count -gt 1) { throw 'Existing compose.env contains duplicate OLLAMA_MODEL.' }
if ($modelEntries.Count -eq 0) {
    $modelAlias = "ov-$(New-RandomHex -Bytes 24)"
    $composeEnvironment += "OLLAMA_MODEL=$modelAlias"
    $composeEnvironmentChanged = $true
} else {
    if ($modelEntries[0] -notmatch '^OLLAMA_MODEL=ov-[A-Za-z0-9._+-]{16,197}$') {
        throw 'Existing compose.env contains an invalid OLLAMA_MODEL.'
    }
    $modelAlias = $modelEntries[0].Substring('OLLAMA_MODEL='.Length)
}

$modelAliasEntries = @($composeEnvironment | Where-Object { $_ -match '^OPENVIDEO_OLLAMA_MODEL_ALIAS=' })
if ($modelAliasEntries.Count -gt 1) { throw 'Existing compose.env contains duplicate OPENVIDEO_OLLAMA_MODEL_ALIAS.' }
if ($modelAliasEntries.Count -eq 0) {
    $composeEnvironment += "OPENVIDEO_OLLAMA_MODEL_ALIAS=$modelAlias"
    $composeEnvironmentChanged = $true
} elseif ($modelAliasEntries[0] -ne "OPENVIDEO_OLLAMA_MODEL_ALIAS=$modelAlias") {
    throw 'Existing compose.env must bind OLLAMA_MODEL to OPENVIDEO_OLLAMA_MODEL_ALIAS.'
}

# CHROMA_PORT is the in-network client/listen port (always 8000).
# CHROMA_HOST_PORT is the loopback publish port and may differ on Windows reserved ranges.
$chromaPortIndexes = @(0..($composeEnvironment.Count - 1) | Where-Object { $composeEnvironment[$_] -match '^CHROMA_PORT=' })
if ($chromaPortIndexes.Count -gt 1) { throw 'Existing compose.env contains duplicate CHROMA_PORT.' }
$chromaHostPortIndexes = @(0..($composeEnvironment.Count - 1) | Where-Object { $composeEnvironment[$_] -match '^CHROMA_HOST_PORT=' })
if ($chromaHostPortIndexes.Count -gt 1) { throw 'Existing compose.env contains duplicate CHROMA_HOST_PORT.' }
$existingChromaPort = if ($chromaPortIndexes.Count -eq 1) { $composeEnvironment[$chromaPortIndexes[0]].Substring('CHROMA_PORT='.Length) } else { $null }
if ($chromaHostPortIndexes.Count -eq 0) {
    $migratedHostPort = if ($existingChromaPort -and $existingChromaPort -ne '8000') { $existingChromaPort } else { '8000' }
    if (-not (Test-ValidTcpPort $migratedHostPort)) { throw 'Existing compose.env contains an invalid CHROMA_PORT for host migration.' }
    $composeEnvironment += "CHROMA_HOST_PORT=$migratedHostPort"
    $composeEnvironmentChanged = $true
} else {
    $existingHostPort = $composeEnvironment[$chromaHostPortIndexes[0]].Substring('CHROMA_HOST_PORT='.Length)
    if (-not (Test-ValidTcpPort $existingHostPort)) { throw 'Existing compose.env contains an invalid CHROMA_HOST_PORT.' }
}
if ($chromaPortIndexes.Count -eq 0) {
    $composeEnvironment += 'CHROMA_PORT=8000'
    $composeEnvironmentChanged = $true
} elseif ($composeEnvironment[$chromaPortIndexes[0]] -ne 'CHROMA_PORT=8000') {
    $composeEnvironment[$chromaPortIndexes[0]] = 'CHROMA_PORT=8000'
    $composeEnvironmentChanged = $true
}

if ($composeEnvironmentChanged) {
    [IO.File]::WriteAllLines($composeEnvironmentPath, $composeEnvironment, $utf8)
}

$metadataPath = Join-Path $runtimePath 'runtime-layout.json'
$metadata = [ordered]@{
    schema_version = 1
    material_root = $materialPath
    runtime_data_root = $runtimePath
    upstream_root = $upstreamPath
    directories = $relativeDirectories
}
[IO.File]::WriteAllText($metadataPath, ($metadata | ConvertTo-Json -Depth 4), $utf8)

$result = [pscustomobject]@{
    MaterialRoot = $materialPath
    RuntimeDataRoot = $runtimePath
    RepositoryRoot = $repositoryPath
    UpstreamRoot = $upstreamPath
    ComposeEnvironmentPath = $composeEnvironmentPath
    MetadataPath = $metadataPath
}
if ($PassThru) { $result } else { Write-Host "Edit Mind read-only runtime initialized at $runtimePath" }
