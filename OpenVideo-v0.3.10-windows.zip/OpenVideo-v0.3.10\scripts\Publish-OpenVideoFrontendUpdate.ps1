[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [string]$FeedRoot,
    [string]$Summary,
    [string[]]$Notes
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$noteDefaults = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'publish-frontend-notes.json') -Encoding UTF8 -Raw | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace($Summary)) {
    $Summary = [string]$noteDefaults.summary
}
if (-not $PSBoundParameters.ContainsKey('Notes') -or -not $Notes -or $Notes.Count -eq 0) {
    $Notes = @($noteDefaults.notes | ForEach-Object { [string]$_ })
}

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
if ([string]::IsNullOrWhiteSpace($FeedRoot)) {
    $FeedRoot = "S:\Codex\releases\openvideo-updates"
}
$resolvedFeed = [IO.Path]::GetFullPath($FeedRoot)
if (-not (Test-Path -LiteralPath (Join-Path $resolvedFeed ".git"))) {
    throw "OPENVIDEO_FRONTEND_FEED_REQUIRES_GIT"
}

Push-Location $resolvedRoot
try {
    pnpm --filter @openvideo/web build
    if ($LASTEXITCODE -ne 0) { throw "OPENVIDEO_FRONTEND_BUILD_FAILED" }
} finally {
    Pop-Location
}

$dist = Join-Path $resolvedRoot "apps\web\dist"
if (-not (Test-Path -LiteralPath (Join-Path $dist "index.html"))) {
    throw "OPENVIDEO_FRONTEND_DIST_MISSING"
}

$commit = (& git -C $resolvedRoot rev-parse HEAD).Trim()
$productVersion = 'v0.1.4'
$configPath = Join-Path $resolvedRoot 'config\product-update.json'
if (Test-Path -LiteralPath $configPath) {
    $updateConfig = Get-Content -LiteralPath $configPath -Encoding UTF8 -Raw | ConvertFrom-Json
    if ($updateConfig.productVersion) {
        $productVersion = [string]$updateConfig.productVersion
    }
}
# previousCommit must represent the last code that was actually shipped in
# a public update so the next Ship can detect Gateway/launcher changes via
# diff. Persist the current published commit before overwriting it.
$publishedCodeCommit = $commit
$latestPathExisting = Join-Path $resolvedFeed 'latest.json'
if (Test-Path -LiteralPath $latestPathExisting) {
    try {
        $existingManifest = Get-Content -LiteralPath $latestPathExisting -Encoding UTF8 -Raw | ConvertFrom-Json
        if ($existingManifest -and ($existingManifest.PSObject.Properties['headCommit'])) {
            $headValue = [string]$existingManifest.headCommit
            if (-not [string]::IsNullOrWhiteSpace($headValue)) {
                $publishedCodeCommit = $headValue
            }
        }
    } catch {
        # Existing latest.json is malformed or unreadable; fall back to current commit.
    }
}
$zipPath = Join-Path $resolvedFeed "frontend.zip"
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
Compress-Archive -LiteralPath $dist -DestinationPath $zipPath -CompressionLevel Optimal
$sha = (Get-FileHash -Algorithm SHA256 -LiteralPath $zipPath).Hash.ToLowerInvariant()
$bytes = (Get-Item -LiteralPath $zipPath).Length
$manifest = [ordered]@{
    schema_version = 1
    scope = "frontend"
    commit = $publishedCodeCommit
    headCommit = $commit
    version = $productVersion
    summary = $Summary
    notes = $Notes
    package = [ordered]@{
        url = "https://raw.githubusercontent.com/Gwaky07/OpenVideo-updates/main/frontend.zip"
        sha256 = $sha
        bytes = $bytes
    }
}
$utf8 = [Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText((Join-Path $resolvedFeed "latest.json"), (($manifest | ConvertTo-Json -Depth 5) + [Environment]::NewLine), $utf8)
$readme = @(
    "# OpenVideo frontend update feed",
    "",
    "Public UI packages only. No source tree, API keys, materials, projects, or Catalog.",
    "",
    "Colleagues never log into GitHub. The workbench downloads latest.json and frontend.zip."
) -join [Environment]::NewLine
[IO.File]::WriteAllText((Join-Path $resolvedFeed "README.md"), ($readme + [Environment]::NewLine), $utf8)

& git -C $resolvedFeed add -- latest.json frontend.zip README.md
& git -C $resolvedFeed commit -m "Publish frontend $commit"
if ($LASTEXITCODE -ne 0) { throw "OPENVIDEO_FRONTEND_FEED_COMMIT_FAILED" }
& git -C $resolvedFeed push origin HEAD:main
if ($LASTEXITCODE -ne 0) { throw "OPENVIDEO_FRONTEND_FEED_PUSH_FAILED" }
Write-Host "OPENVIDEO_FRONTEND_FEED_READY commit=$commit sha256=$sha"
