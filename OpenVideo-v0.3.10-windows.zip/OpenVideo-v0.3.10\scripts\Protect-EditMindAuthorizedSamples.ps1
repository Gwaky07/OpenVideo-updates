[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ManifestPath,
    [Parameter(Mandatory)][string]$MaterialRoot,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [ValidateSet('Before', 'After')][string]$Phase = 'Before'
)

$ErrorActionPreference = 'Stop'
$pathComparison = [StringComparison]::OrdinalIgnoreCase
$videoExtensions = @('.mp4', '.mov', '.m4v', '.avi', '.mkv', '.webm')
$utf8 = New-Object Text.UTF8Encoding($false)

function Get-FullPath {
    param([string]$Path, [string]$Name, [bool]$MustExist)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "$Name is required." }
    if ([IO.Path]::GetInvalidPathChars() | Where-Object { $Path.Contains($_) }) { throw "$Name contains invalid path characters." }
    if (-not [IO.Path]::IsPathRooted($Path) -or $Path -match '^[A-Za-z]:[^\\/]') { throw "$Name must be an absolute path." }
    $full = [IO.Path]::GetFullPath($Path)
    if ($MustExist -and -not (Test-Path -LiteralPath $full)) { throw "$Name does not exist: $full" }
    $root = [IO.Path]::GetPathRoot($full)
    if ($full.Equals($root, $pathComparison)) { return $root }
    return $full.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
}

function Test-Within {
    param([string]$Root, [string]$Candidate)
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($Root, $pathComparison) -or $Candidate.StartsWith($prefix, $pathComparison)
}

function Assert-NoReparseBoundary {
    param([string]$Root, [string]$Candidate)
    $cursor = $Candidate
    while ($true) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "Authorized sample crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        if ($cursor.Equals($Root, $pathComparison)) { break }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor -or -not (Test-Within -Root $Root -Candidate $parent)) {
            throw 'Authorized sample is outside the authorized material root.'
        }
        $cursor = $parent
    }
}

function Assert-NoReparseAncestors {
    param([string]$Path, [string]$Name)
    $cursor = $Path
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "$Name crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-NotReparsePath {
    param([string]$Path, [string]$Name)
    $item = Get-Item -LiteralPath $Path -Force
    $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw "$Name must not be a symbolic link or reparse point: $Path"
    }
}

function Assert-RuntimeBoundary {
    param([string]$RuntimeRoot, [string]$RepositoryRoot)
    if (-not (Test-Path -LiteralPath $RuntimeRoot -PathType Container)) {
        throw 'RuntimeDataRoot must be an existing directory.'
    }
    $runtimeItem = Get-Item -LiteralPath $RuntimeRoot -Force
    $hasLinkType = $null -ne $runtimeItem.PSObject.Properties['LinkType'] -and [bool]$runtimeItem.LinkType
    if (($runtimeItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw 'RuntimeDataRoot must not be a symbolic link or reparse point.'
    }
    if ((Test-Within -Root $RepositoryRoot -Candidate $RuntimeRoot) -or (Test-Within -Root $RuntimeRoot -Candidate $RepositoryRoot)) {
        throw 'RuntimeDataRoot and the repository must be separate and must not contain one another.'
    }
}

function Get-Snapshot {
    param([string[]]$Paths)
    $items = @()
    foreach ($path in $Paths) {
        $resolved = [IO.Path]::GetFullPath($path)
        $item = Get-Item -LiteralPath $resolved -Force
        if ($item.PSIsContainer) { throw "Authorized sample must be a file: $resolved" }
        $sha256 = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant()
        $items += [ordered]@{
            path = $resolved
            name = $item.Name
            length = [int64]$item.Length
            last_write_time_utc = $item.LastWriteTimeUtc.ToString('o')
            sha256 = $sha256
        }
    }
    return $items
}

$repositoryPath = Get-FullPath -Path (Split-Path -Parent $PSScriptRoot) -Name 'RepositoryRoot' -MustExist $true
$materialPath = Get-FullPath -Path $MaterialRoot -Name 'MaterialRoot' -MustExist $true
$runtimePath = Get-FullPath -Path $RuntimeDataRoot -Name 'RuntimeDataRoot' -MustExist $false
Assert-NotReparsePath -Path $repositoryPath -Name 'RepositoryRoot'
if ((Test-Within -Root $repositoryPath -Candidate $materialPath) -or (Test-Within -Root $materialPath -Candidate $repositoryPath)) {
    throw 'MaterialRoot and the repository must be separate and must not contain one another.'
}
if ((Test-Within -Root $repositoryPath -Candidate $runtimePath) -or (Test-Within -Root $runtimePath -Candidate $repositoryPath)) {
    throw 'RuntimeDataRoot and the repository must be separate and must not contain one another.'
}
if ($Phase -eq 'After' -and -not (Test-Path -LiteralPath $runtimePath -PathType Container)) {
    throw 'RuntimeDataRoot must exist for After phase.'
}
if ((Test-Within -Root $materialPath -Candidate $runtimePath) -or (Test-Within -Root $runtimePath -Candidate $materialPath)) {
    throw 'MaterialRoot and RuntimeDataRoot must be separate and must not contain one another.'
}
Assert-NoReparseAncestors -Path $materialPath -Name 'MaterialRoot'
if (Test-Path -LiteralPath $runtimePath -PathType Container) { Assert-NoReparseAncestors -Path $runtimePath -Name 'RuntimeDataRoot' }
Assert-RuntimeBoundary -RuntimeRoot $runtimePath -RepositoryRoot $repositoryPath
$manifestPathFull = Get-FullPath -Path $ManifestPath -Name 'ManifestPath' -MustExist $true
if (-not (Test-Path -LiteralPath $manifestPathFull -PathType Leaf)) { throw 'ManifestPath must be an existing file.' }
if (-not (Test-Within -Root $runtimePath -Candidate $manifestPathFull)) { throw 'ManifestPath must be inside RuntimeDataRoot.' }
Assert-NoReparseBoundary -Root $runtimePath -Candidate $manifestPathFull
$manifest = Get-Content -LiteralPath $manifestPathFull -Raw -Encoding utf8 | ConvertFrom-Json
if ($manifest.schema_version -ne 1) { throw 'Manifest schema_version must be 1.' }
if ($manifest.authorization -ne 'read_only_analysis') { throw 'Manifest authorization must be read_only_analysis.' }
$rawFiles = @($manifest.files)
if ($rawFiles.Count -ne 5) { throw 'Manifest must contain exactly five authorized files.' }

$beforePath = Join-Path $runtimePath 'evidence/em-002/source-snapshot.before.json'
$afterPath = Join-Path $runtimePath 'evidence/em-002/source-snapshot.after.json'
$verificationPath = Join-Path $runtimePath 'evidence/em-002/source-verification.json'
if ($Phase -eq 'After') {
    if (-not (Test-Path -LiteralPath $beforePath -PathType Leaf)) { throw 'Before snapshot is required before after verification.' }
}

$normalized = @()
foreach ($rawPath in $rawFiles) {
    if ($rawPath -isnot [string] -or [string]::IsNullOrWhiteSpace($rawPath)) { throw 'Each authorized sample must be a non-empty file path.' }
    if ($rawPath.Contains('*') -or $rawPath.Contains('?')) { throw 'Wildcard paths are not allowed.' }
    $fullPath = Get-FullPath -Path $rawPath -Name 'Authorized sample path' -MustExist $true
    if ($normalized -contains $fullPath) { throw "Duplicate authorized sample path: $fullPath" }
    if (-not (Test-Within -Root $materialPath -Candidate $fullPath)) { throw 'Authorized sample is outside the authorized material root.' }
    Assert-NoReparseBoundary -Root $materialPath -Candidate $fullPath
    $item = Get-Item -LiteralPath $fullPath -Force
    if ($item.PSIsContainer) { throw 'Authorized sample must be a file, not a directory.' }
    if ($videoExtensions -notcontains $item.Extension.ToLowerInvariant()) { throw 'Authorized sample must use a video extension.' }
    $normalized += $fullPath
}
if ($normalized.Count -ne 5) { throw 'Normalized manifest must contain exactly five authorized files.' }

New-Item -ItemType Directory -Path (Join-Path $runtimePath 'evidence/em-002') -Force | Out-Null
$snapshot = [ordered]@{
    schema_version = 1
    phase = $Phase.ToLowerInvariant()
    sample_count = 5
    material_root = $materialPath
    files = @(Get-Snapshot -Paths $normalized)
}
if ($Phase -eq 'Before') {
    [IO.File]::WriteAllText($beforePath, ($snapshot | ConvertTo-Json -Depth 8), $utf8)
    [pscustomobject]@{ phase = 'before'; sample_count = 5; snapshot_path = $beforePath }
    exit 0
}

[IO.File]::WriteAllText($afterPath, ($snapshot | ConvertTo-Json -Depth 8), $utf8)
$before = Get-Content -LiteralPath $beforePath -Raw -Encoding utf8 | ConvertFrom-Json
$beforeJson = $before.files | ConvertTo-Json -Depth 8 -Compress
$afterJson = $snapshot.files | ConvertTo-Json -Depth 8 -Compress
if ($beforeJson -ne $afterJson) { throw 'Authorized source files changed.' }
$sanitized = [ordered]@{
    schema_version = 1
    unchanged = $true
    sample_count = 5
    compared_fields = @('path', 'name', 'length', 'last_write_time_utc', 'sha256')
}
[IO.File]::WriteAllText($verificationPath, ($sanitized | ConvertTo-Json -Depth 6), $utf8)
[pscustomobject]@{ phase = 'after'; unchanged = $true; sample_count = 5; verification_path = $verificationPath }
