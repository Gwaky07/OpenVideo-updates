import { mkdir, statfs } from 'node:fs/promises'
import { freemem, tmpdir, totalmem } from 'node:os'
import { resolve } from 'node:path'

const MEBIBYTE = 1024 * 1024

export const MATERIAL_ANALYSIS_PRIORITY_JOB_TYPES = new Set([
  'preview_generation',
  'jianying_draft_export',
])

const defaultMinimumFreeMemoryBytes = 512 * MEBIBYTE
const defaultMinimumFreeRuntimeBytes = 512 * MEBIBYTE
const defaultMinimumFreeTempBytes = 512 * MEBIBYTE
const defaultMaximumResidentSetRatio = 0.9

/** @param {unknown} value @returns {value is number} */
const finiteNumber = (value) => typeof value === 'number' && Number.isFinite(value)

/** @param {string} label @param {number} bytes */
const lowDiskDetail = (label, bytes) => {
  const freeMib = finiteNumber(bytes) ? Math.max(0, Math.floor(bytes / MEBIBYTE)) : 0
  return `${label} 剩余空间不足，素材分析已暂停，可稍后继续。当前可用约 ${freeMib} MiB。`
}

/** @param {{bavail?: unknown, bfree?: unknown, bsize?: unknown, frsize?: unknown}} stats */
const statfsFreeBytes = (stats) => {
  const availableBlocks = finiteNumber(stats?.bavail)
    ? stats.bavail
    : finiteNumber(stats?.bfree)
      ? stats.bfree
      : null
  const blockSize = finiteNumber(stats?.bsize)
    ? stats.bsize
    : finiteNumber(stats?.frsize)
      ? stats.frsize
      : null
  if (availableBlocks === null || blockSize === null) return null
  return availableBlocks * blockSize
}

/**
 * @param {{
 *   statfsImpl?: typeof statfs,
 *   getMemoryUsage?: () => {rss?: number},
 *   getFreeMemoryBytes?: () => number,
 *   getTotalMemoryBytes?: () => number,
 *   defaultRuntimeRoot?: () => string,
 *   defaultTempRoot?: () => string,
 *   minimumFreeMemoryBytes?: number,
 *   minimumFreeRuntimeBytes?: number,
 *   minimumFreeTempBytes?: number,
 *   maximumResidentSetRatio?: number,
 * }} [options]
 */
export const createMaterialAnalysisRunGovernor = (options = {}) => {
  const {
    statfsImpl = statfs,
    getMemoryUsage = () => process.memoryUsage(),
    getFreeMemoryBytes = () => freemem(),
    getTotalMemoryBytes = () => totalmem(),
    defaultRuntimeRoot = () => tmpdir(),
    defaultTempRoot = () => resolve(tmpdir(), 'openvideo-material-analysis'),
    minimumFreeMemoryBytes = defaultMinimumFreeMemoryBytes,
    minimumFreeRuntimeBytes = defaultMinimumFreeRuntimeBytes,
    minimumFreeTempBytes = defaultMinimumFreeTempBytes,
    maximumResidentSetRatio = defaultMaximumResidentSetRatio,
  } = options

  /** @param {string | null | undefined} path */
  const probeFreeBytes = async (path) => {
    if (typeof path !== 'string' || path.length === 0) return null
    const target = resolve(path)
    try {
      await mkdir(target, { recursive: true })
      return statfsFreeBytes(await statfsImpl(target))
    } catch {
      return null
    }
  }

  return {
    /**
     * @param {{
     *   activeJobTypes?: string[],
     *   runtimeRoot?: string | null,
     *   tempRoot?: string | null,
     * }} [input]
     */
    async inspect(input = {}) {
      const activeJobTypes = Array.isArray(input.activeJobTypes) ? input.activeJobTypes : []
      if (activeJobTypes.some((type) => MATERIAL_ANALYSIS_PRIORITY_JOB_TYPES.has(type))) {
        return {
          pause: true,
          reason: 'priority_job_active',
          detail: '预览或剪映导出任务优先，素材分析已暂停，可稍后继续。',
        }
      }

      const freeMemoryBytes = getFreeMemoryBytes()
      if (finiteNumber(freeMemoryBytes) && freeMemoryBytes < minimumFreeMemoryBytes) {
        const freeMib = Math.max(0, Math.floor(freeMemoryBytes / MEBIBYTE))
        return {
          pause: true,
          reason: 'low_memory_available',
          detail: `系统可用内存不足，素材分析已暂停，可稍后继续。当前可用约 ${freeMib} MiB。`,
        }
      }

      const totalMemoryBytes = getTotalMemoryBytes()
      const residentSetBytes = getMemoryUsage()?.rss
      if (
        finiteNumber(totalMemoryBytes) &&
        totalMemoryBytes > 0 &&
        finiteNumber(residentSetBytes) &&
        residentSetBytes / totalMemoryBytes >= maximumResidentSetRatio
      ) {
        return {
          pause: true,
          reason: 'high_memory_pressure',
          detail: '当前内存压力较高，素材分析已暂停，可稍后继续。',
        }
      }

      const runtimeRoot = input.runtimeRoot ?? defaultRuntimeRoot()
      const tempRoot = input.tempRoot ?? defaultTempRoot()
      const runtimeFreeBytes = await probeFreeBytes(runtimeRoot)
      if (!finiteNumber(runtimeFreeBytes)) {
        return {
          pause: true,
          reason: 'runtime_disk_probe_failed',
          detail: '无法确认分析存储空间，素材分析已暂停，可稍后重试。',
        }
      }
      if (finiteNumber(runtimeFreeBytes) && runtimeFreeBytes < minimumFreeRuntimeBytes) {
        return {
          pause: true,
          reason: 'low_runtime_disk',
          detail: lowDiskDetail('分析存储空间', runtimeFreeBytes),
        }
      }

      const tempFreeBytes = await probeFreeBytes(tempRoot)
      if (!finiteNumber(tempFreeBytes)) {
        return {
          pause: true,
          reason: 'temp_disk_probe_failed',
          detail: '无法确认临时存储空间，素材分析已暂停，可稍后重试。',
        }
      }
      if (finiteNumber(tempFreeBytes) && tempFreeBytes < minimumFreeTempBytes) {
        return {
          pause: true,
          reason: 'low_temp_disk',
          detail: lowDiskDetail('临时空间', tempFreeBytes),
        }
      }

      return {
        pause: false,
        reason: null,
        detail: null,
      }
    },
  }
}
