import { assertRichTimeline } from './rich-timeline-contracts.mjs'
import {
  canonicalJY200DuoJson,
  fingerprintJY200DuoValue,
} from './jianying-duo-direct-probe-evidence.mjs'

/**
 * @typedef {Record<string, unknown>} UnknownRecord
 * @typedef {'flower'|'sticker'|'video_effect'} BindingFamily
 * @typedef {'audio.bgm.local'|'audio.sfx.local'|'audio.voiceover.edge_tts'|'caption.basic'|'caption.bottom_safe'|'effect.video.named'|'sticker.named'|'text.flower.private'|'text.rich'|'title.card'|'track.insert'|'track.insert_many'|'transition.cut'|'transition.none'} SupportedCapability
 * @typedef {{resourceId: string, effectId?: string}} PrivateBinding
 * @typedef {{
 *   schema_version: 1,
 *   kind: 'jy200_duo_local_resource_probe_candidate',
 *   family: BindingFamily,
 *   packaging_token: string,
 *   binding_fingerprint: string,
 *   source_material_fingerprint: string,
 *   payload_fingerprint: string,
 *   source_fingerprint: string,
 *   catalog_fingerprint: string,
 *   desktop_binding_fingerprint: string,
 *   resource_mode: 'jianying_managed',
 *   admission: 'deferred',
 *   writer_eligible: false,
 *   probe_candidate: true,
 *   private_binding: PrivateBinding,
 * }} PublicBinding
 * @typedef {{
 *   family: BindingFamily,
 *   packagingToken: string,
 *   bindingFingerprint: string,
 *   sourceMaterialFingerprint: string,
 *   payloadFingerprint: string,
 *   sourceFingerprint: string,
 *   catalogFingerprint: string,
 *   desktopBindingFingerprint: string,
 *   privateBinding: PrivateBinding,
 *   publicBinding: PublicBinding,
 * }} NormalizedBinding
 * @typedef {{
 *   entries: readonly NormalizedBinding[],
 *   byToken: Map<string, NormalizedBinding>,
 *   catalogFingerprint: string,
 *   desktopBindingFingerprint: string,
 *   bindingEvidenceFingerprint: string,
 * }} NormalizedBindings
 * @typedef {{sourcePath: string, index: number}} ResolvedMaterial
 * @typedef {{
 *   draftName: string,
 *   draftLabel: string,
 *   projectId: string,
 *   summary: string,
 *   handoffMode: 'manual_open_required',
 *   desktopOpened: false,
 *   manualOpenHint: string,
 *   timelineFingerprint: string,
 *   writerProjectionFingerprint: string,
 *   bindingEvidenceFingerprint: string,
 *   currentCatalogFingerprint: string,
 *   desktopBindingFingerprint: string,
 *   executionReceiptFingerprint: string,
 *   placementSummary: PlacementSummary,
 * }} ProviderResult
 * @typedef {{
 *   outputFingerprint: string,
 *   draftName?: string,
 *   trackCount?: number,
 *   segmentCount?: number,
 * }} ReadbackOutput
 * @typedef {{
 *   flower: number,
 *   sticker: number,
 *   title: number,
 *   video: number,
 *   video_effect: number,
 *   caption: number,
 *   audio: number,
 * }} PlacementSummary
 * @typedef {{
 *   lease_id: string,
 * }} Lease
 * @typedef {{
 *   jobId: string,
 *   projectId?: string,
 *   projectName?: string,
 *   richTimeline: UnknownRecord,
 *   timeline_fingerprint: string,
 *   provider_id: string,
 *   provider_commit: string,
 *   required_capabilities: readonly string[],
 *   resolvedMaterials: unknown,
 * }} AdapterRunInput
 * @typedef {{
 *   draftName: string,
 *   draftLabel: string,
 *   timelineFingerprint: string,
 *   writerProjectionFingerprint: string,
 *   currentCatalogFingerprint: string,
 *   desktopBindingFingerprint: string,
 *   bindingEvidenceFingerprint: string,
 *   requiredCapabilities: readonly string[],
 *   providerCommit: string,
 *   providerId: string,
 *   offlineOnly: true,
 *   summary: string,
 *   handoffMode: 'manual_open_required',
 *   desktopOpened: false,
 *   manualOpenHint: string,
 *   videoMaterials: readonly UnknownRecord[],
 *   titleTexts: readonly UnknownRecord[],
 *   captionTexts: readonly UnknownRecord[],
 *   audioPlacements: readonly UnknownRecord[],
 *   packagingPlacements: Readonly<{
 *     flower: readonly UnknownRecord[],
 *     sticker: readonly UnknownRecord[],
 *     video_effect: readonly UnknownRecord[],
 *   }>,
 *   trustedBindings: readonly NormalizedBinding[],
 *   placementSummary: PlacementSummary,
 * }} WritePlan
 * @typedef {{
 *   verified: true,
 *   timeline_fingerprint: string,
 *   output_fingerprint: string,
 *   draft_id: string,
 *   summary: string,
 *   handoff_mode: 'manual_open_required',
 *   desktop_opened: false,
 *   draft_label: string,
 *   manual_open_hint: string,
 *   writer_projection_fingerprint: string,
 * }} ReadbackReceipt
 */

const PROVIDER_ID = 'duo-video'
const COMMIT = /^[a-f0-9]{40}$/u
const FINGERPRINT = /^[a-f0-9]{64}$/u
const DRAFT_NAME = /^OpenVideo-JY200-duo-direct-\d{8}-\d{6}$/u
const LEASE = /^lease_[a-z0-9]{32}$/u
const PACKAGING_TOKEN = /^ovj(?:sticker|flower|video_effect)_v1_[a-z0-9]{24}$/u
const PUBLIC_TEXT = /^[^\u0000]{1,300}$/u
const SUPPORTED_BINDING_FAMILIES = Object.freeze(['flower', 'sticker', 'video_effect'])
const SUPPORTED_CAPABILITIES = Object.freeze([
  'audio.bgm.local',
  'audio.sfx.local',
  'audio.voiceover.edge_tts',
  'caption.basic',
  'caption.bottom_safe',
  'effect.video.named',
  'sticker.named',
  'text.flower.private',
  'text.rich',
  'title.card',
  'track.insert',
  'track.insert_many',
  'transition.cut',
  'transition.none',
])
const BINDING_KEYS = Object.freeze([
  'schema_version',
  'kind',
  'family',
  'packaging_token',
  'binding_fingerprint',
  'source_material_fingerprint',
  'payload_fingerprint',
  'source_fingerprint',
  'catalog_fingerprint',
  'desktop_binding_fingerprint',
  'resource_mode',
  'admission',
  'writer_eligible',
  'probe_candidate',
  'private_binding',
])
const PROVIDER_RESULT_KEYS = Object.freeze([
  'draftName',
  'draftLabel',
  'summary',
  'handoffMode',
  'desktopOpened',
  'manualOpenHint',
  'timelineFingerprint',
  'writerProjectionFingerprint',
  'bindingEvidenceFingerprint',
  'currentCatalogFingerprint',
  'desktopBindingFingerprint',
  'executionReceiptFingerprint',
  'placementSummary',
])
const READBACK_KEYS = Object.freeze([
  'verified',
  'timeline_fingerprint',
  'output_fingerprint',
  'draft_id',
  'summary',
  'handoff_mode',
  'desktop_opened',
  'draft_label',
  'manual_open_hint',
  'writer_projection_fingerprint',
])

export class JY200DuoWorkbenchAdapterError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'JY200DuoWorkbenchAdapterError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  throw new JY200DuoWorkbenchAdapterError(code, status)
}

/** @param {unknown} value @returns {value is UnknownRecord} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @param {readonly string[]} keys @returns {value is UnknownRecord} */
const hasExactKeys = (value, keys) => isRecord(value) &&
  Object.keys(value).sort().join('\0') === [...keys].sort().join('\0')

/** @param {unknown} value */
const isAbsoluteWindowsPath = (value) => typeof value === 'string' && /^[A-Za-z]:\\/u.test(value)

/** @param {unknown} value @param {number} [maximum] */
const isSafeText = (value, maximum = 300) => typeof value === 'string' &&
  value.length > 0 &&
  value.length <= maximum &&
  PUBLIC_TEXT.test(value)

/** @param {Date} value */
const formatDraftName = (value) => {
  /** @param {number} input */
  const two = (input) => String(input).padStart(2, '0')
  return [
    'OpenVideo-JY200-duo-direct',
    `${value.getFullYear()}${two(value.getMonth() + 1)}${two(value.getDate())}`,
    `${two(value.getHours())}${two(value.getMinutes())}${two(value.getSeconds())}`,
  ].join('-')
}

/** @param {unknown} value @returns {readonly string[]} */
const normalizeRequiredCapabilities = (value) => {
  if (!Array.isArray(value) || value.length === 0) fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  const capabilities = value.map((entry) => {
    if (typeof entry !== 'string' || entry.length === 0) fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
    return entry
  })
  if (new Set(capabilities).size !== capabilities.length) fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  return Object.freeze([...capabilities].sort())
}

/** @param {unknown} value @param {number} expectedCount @returns {readonly ResolvedMaterial[]} */
const normalizeResolvedMaterials = (value, expectedCount) => {
  if (!Array.isArray(value) || value.length !== expectedCount) fail('JY200_DUO_PRIVATE_RESOLUTION_INVALID', 500)
  return Object.freeze(value.map((entry, index) => {
    if (!isRecord(entry) || !isAbsoluteWindowsPath(entry.sourcePath)) {
      fail('JY200_DUO_PRIVATE_RESOLUTION_INVALID', 500)
    }
    const sourcePath = /** @type {string} */ (entry.sourcePath)
    return Object.freeze({
      index,
      sourcePath,
    })
  }))
}

/** @param {unknown} value @returns {PrivateBinding} */
const normalizePrivateBinding = (value) => {
  if (!isRecord(value) || !isSafeText(value.resourceId, 200)) fail('JY200_DUO_BINDING_INVALID')
  if (Object.keys(value).some((key) => !['resourceId', 'effectId'].includes(key))) fail('JY200_DUO_BINDING_INVALID')
  if (Object.hasOwn(value, 'effectId') && !isSafeText(value.effectId, 200)) fail('JY200_DUO_BINDING_INVALID')
  const resourceId = /** @type {string} */ (value.resourceId)
  const effectId = typeof value.effectId === 'string' ? value.effectId : undefined
  return Object.freeze({
    resourceId,
    ...(effectId ? { effectId } : {}),
  })
}

/** @param {unknown} value @returns {NormalizedBindings} */
const normalizeBindings = (value) => {
  if (!Array.isArray(value) || value.length !== 3) fail('JY200_DUO_BINDING_INVALID')
  /** @type {NormalizedBinding[]} */
  const normalized = value.map((entry) => {
    if (!hasExactKeys(entry, BINDING_KEYS)) fail('JY200_DUO_BINDING_INVALID')
    const record = /** @type {PublicBinding} */ (entry)
    if (record.schema_version !== 1 || record.kind !== 'jy200_duo_local_resource_probe_candidate' ||
        !SUPPORTED_BINDING_FAMILIES.includes(record.family) ||
        typeof record.packaging_token !== 'string' || !PACKAGING_TOKEN.test(record.packaging_token) ||
        !FINGERPRINT.test(record.binding_fingerprint) ||
        !FINGERPRINT.test(record.source_material_fingerprint) ||
        !FINGERPRINT.test(record.payload_fingerprint) ||
        !FINGERPRINT.test(record.source_fingerprint) ||
        !FINGERPRINT.test(record.catalog_fingerprint) ||
        !FINGERPRINT.test(record.desktop_binding_fingerprint) ||
        record.resource_mode !== 'jianying_managed' ||
        record.admission !== 'deferred' ||
        record.writer_eligible !== false ||
        record.probe_candidate !== true) fail('JY200_DUO_BINDING_INVALID')
    return Object.freeze({
      family: record.family,
      packagingToken: record.packaging_token,
      bindingFingerprint: record.binding_fingerprint,
      sourceMaterialFingerprint: record.source_material_fingerprint,
      payloadFingerprint: record.payload_fingerprint,
      sourceFingerprint: record.source_fingerprint,
      catalogFingerprint: record.catalog_fingerprint,
      desktopBindingFingerprint: record.desktop_binding_fingerprint,
      privateBinding: normalizePrivateBinding(record.private_binding),
      publicBinding: Object.freeze({
        schema_version: record.schema_version,
        kind: record.kind,
        family: record.family,
        packaging_token: record.packaging_token,
        binding_fingerprint: record.binding_fingerprint,
        source_material_fingerprint: record.source_material_fingerprint,
        payload_fingerprint: record.payload_fingerprint,
        source_fingerprint: record.source_fingerprint,
        catalog_fingerprint: record.catalog_fingerprint,
        desktop_binding_fingerprint: record.desktop_binding_fingerprint,
        resource_mode: record.resource_mode,
        admission: record.admission,
        writer_eligible: record.writer_eligible,
        probe_candidate: record.probe_candidate,
        private_binding: record.private_binding,
      }),
    })
  }).sort((left, right) => left.family.localeCompare(right.family))
  if (normalized.map((entry) => entry.family).join('\0') !== SUPPORTED_BINDING_FAMILIES.join('\0')) {
    fail('JY200_DUO_BINDING_INVALID')
  }
  if (new Set(normalized.map((entry) => entry.packagingToken)).size !== normalized.length) fail('JY200_DUO_BINDING_INVALID')
  const catalogFingerprint = normalized[0].catalogFingerprint
  const desktopBindingFingerprint = normalized[0].desktopBindingFingerprint
  if (normalized.some((entry) => entry.catalogFingerprint !== catalogFingerprint ||
      entry.desktopBindingFingerprint !== desktopBindingFingerprint)) fail('JY200_DUO_BINDING_INVALID')
  return Object.freeze({
    entries: Object.freeze(normalized),
    byToken: new Map(normalized.map((entry) => [entry.packagingToken, entry])),
    catalogFingerprint,
    desktopBindingFingerprint,
    bindingEvidenceFingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(
      normalized.map((entry) => entry.publicBinding),
    )),
  })
}

/** @param {unknown} value */
const ensureNoCallerPathFields = (value) => {
  if (!isRecord(value)) fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  if (['staging_root', 'stagingRoot', 'draft_root', 'draftRoot', 'staging_lease', 'stagingLease']
    .some((key) => Object.hasOwn(value, key))) {
    fail('JY200_DUO_CALLER_PATH_DENIED')
  }
}

/** @param {unknown} value @returns {ProviderResult} */
const normalizeProviderResult = (value) => {
  if (!hasExactKeys(value, PROVIDER_RESULT_KEYS)) fail('JY200_DUO_PROVIDER_RESULT_INVALID', 502)
  const record = /** @type {ProviderResult} */ (value)
  if (!DRAFT_NAME.test(record.draftName) ||
      !isSafeText(record.draftLabel, 180) ||
      record.summary !== '剪映草稿已生成并通过结构校验，等待用户手动打开' ||
      record.handoffMode !== 'manual_open_required' ||
      record.desktopOpened !== false ||
      record.manualOpenHint !== '请在剪映专业版首页的本地草稿列表中打开该标签。' ||
      !FINGERPRINT.test(record.timelineFingerprint) ||
      record.writerProjectionFingerprint !== record.timelineFingerprint ||
      !FINGERPRINT.test(record.bindingEvidenceFingerprint) ||
      !FINGERPRINT.test(record.currentCatalogFingerprint) ||
      !FINGERPRINT.test(record.desktopBindingFingerprint) ||
      !FINGERPRINT.test(record.executionReceiptFingerprint) ||
      !isRecord(record.placementSummary)) {
    fail('JY200_DUO_PROVIDER_RESULT_INVALID', 502)
  }
  return Object.freeze(structuredClone(record))
}

/** @param {unknown} value @returns {ReadbackOutput} */
const normalizeReadbackOutput = (value) => {
  if (!isRecord(value)) {
    fail('JY200_DUO_READBACK_INVALID', 502)
  }
  const record = /** @type {ReadbackOutput} */ (value)
  const trackCount = record.trackCount
  const segmentCount = record.segmentCount
  if (!FINGERPRINT.test(record.outputFingerprint) ||
      (Object.hasOwn(record, 'draftName') && !DRAFT_NAME.test(record.draftName ?? '')) ||
      (trackCount !== undefined && (!Number.isSafeInteger(trackCount) || trackCount <= 0)) ||
      (segmentCount !== undefined && (!Number.isSafeInteger(segmentCount) || segmentCount <= 0))) {
    fail('JY200_DUO_READBACK_INVALID', 502)
  }
  return Object.freeze(structuredClone(record))
}

/** @param {readonly string[]} requiredCapabilities */
const ensureSupportedCapabilities = (requiredCapabilities) => {
  const unsupportedCapabilities = requiredCapabilities.filter((entry) => !SUPPORTED_CAPABILITIES.includes(entry))
  if (unsupportedCapabilities.length > 0) fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
}

/** @param {PlacementSummary} value @returns {PlacementSummary} */
const normalizePlacementCounts = (value) => Object.freeze({
  audio: value.audio,
  caption: value.caption,
  flower: value.flower,
  sticker: value.sticker,
  title: value.title,
  video: value.video,
  video_effect: value.video_effect,
})

/** @param {AdapterRunInput} input @param {() => Date} now @param {unknown} currentBindings @returns {WritePlan} */
const buildWritePlan = (input, now, currentBindings) => {
  ensureNoCallerPathFields(input)
  if (typeof input.jobId !== 'string' || input.jobId.length === 0 ||
      typeof input.projectId !== 'string' || input.projectId.length === 0 ||
      typeof input.projectName !== 'string' || input.projectName.trim().length === 0 ||
      input.projectName.length > 100 || /[\\/\u0000-\u001f]/u.test(input.projectName) ||
      /^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(input.projectName) ||
      typeof input.provider_id !== 'string' || input.provider_id !== PROVIDER_ID ||
      typeof input.provider_commit !== 'string' || !COMMIT.test(input.provider_commit)) {
    fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  }
  const timelineRecord = assertRichTimeline(input.richTimeline)
  if (timelineRecord.status !== 'finalized') fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  const timelineFingerprint = input.richTimeline?.revisionFingerprint
  if (typeof timelineFingerprint !== 'string' || timelineFingerprint !== input.timeline_fingerprint) {
    fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  }
  const requiredCapabilities = normalizeRequiredCapabilities(input.required_capabilities)
  const timelineCapabilities = Object.freeze(
    (Array.isArray(input.richTimeline?.capabilityRequirements) ? input.richTimeline.capabilityRequirements : [])
      .filter((/** @type {any} */ entry) => entry?.acceptance === 'implemented')
      .map((/** @type {any} */ entry) => entry.capabilityId)
      .sort(),
  )
  if (timelineCapabilities.join('\0') !== requiredCapabilities.join('\0')) {
    fail('JY200_DUO_REQUIRED_CAPABILITY_MISMATCH')
  }
  ensureSupportedCapabilities(requiredCapabilities)
  const videoTrack = timelineRecord.tracks.find((/** @type {any} */ track) => track.kind === 'video' && track.role === 'primary' && track.enabled !== false)
  if (!videoTrack || !Array.isArray(videoTrack.segments) || videoTrack.segments.length === 0) {
    fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  }
  for (const track of timelineRecord.tracks) {
    if (track.enabled === false || (Array.isArray(track.segments) && track.segments.length === 0)) continue
    if (track.kind === 'video' && track.role === 'primary') continue
    if (track.kind === 'title') continue
    if (track.kind === 'caption') continue
    if (track.kind === 'audio' && ['voiceover', 'bgm', 'sfx'].includes(track.role)) continue
    if (track.kind === 'effect') continue
    fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
  }
  const videoSegments = videoTrack.segments
  const materials = normalizeResolvedMaterials(input.resolvedMaterials, videoSegments.length)
  const trustedBindings = normalizeBindings(currentBindings)
  /** @type {UnknownRecord[]} */
  const flowerSegments = []
  /** @type {UnknownRecord[]} */
  const titleTexts = []
  /** @type {UnknownRecord[]} */
  const captionTexts = []
  /** @type {UnknownRecord[]} */
  const audioPlacements = []
  for (const track of timelineRecord.tracks.filter((/** @type {any} */ track) => track.kind === 'title' && track.enabled !== false)) {
    for (const segment of track.segments ?? []) {
      if (segment.capabilityId === 'text.flower.private') {
        if (typeof segment.templateToken !== 'string') fail('JY200_DUO_BINDING_MISSING')
        const binding = trustedBindings.byToken.get(segment.templateToken)
        if (!binding || binding.family !== 'flower') fail('JY200_DUO_BINDING_MISSING')
        flowerSegments.push(Object.freeze({
          segmentId: segment.segmentId,
          text: segment.text,
          targetStartUs: segment.targetRange.startUs,
          targetDurationUs: segment.targetRange.durationUs,
          packagingToken: binding.packagingToken,
          bindingFingerprint: binding.bindingFingerprint,
          resourceId: binding.privateBinding.resourceId,
          ...(binding.privateBinding.effectId ? { effectId: binding.privateBinding.effectId } : {}),
        }))
        continue
      }
      if (segment.capabilityId !== 'title.card' && segment.capabilityId !== 'text.rich') {
        fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
      }
      if (typeof segment.templateToken === 'string' || typeof segment.animationIn === 'string' || typeof segment.animationOut === 'string' ||
          (Array.isArray(segment.keyframes) && segment.keyframes.length > 0)) {
        fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
      }
      titleTexts.push(Object.freeze({
        segmentId: segment.segmentId,
        text: segment.text,
        kind: segment.capabilityId,
        targetStartUs: segment.targetRange.startUs,
        targetDurationUs: segment.targetRange.durationUs,
      }))
    }
  }
  for (const track of timelineRecord.tracks.filter((/** @type {any} */ track) => track.kind === 'caption' && track.enabled !== false)) {
    for (const segment of track.segments ?? []) {
      if (!['caption.basic', 'caption.bottom_safe'].includes(segment.capabilityId) ||
          typeof segment.text !== 'string' || segment.text.length === 0) {
        fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
      }
      captionTexts.push(Object.freeze({
        segmentId: segment.segmentId,
        text: segment.text,
        capabilityId: segment.capabilityId,
        targetStartUs: segment.targetRange.startUs,
        targetDurationUs: segment.targetRange.durationUs,
      }))
    }
  }
  for (const track of timelineRecord.tracks.filter((/** @type {any} */ track) => track.kind === 'audio' && track.enabled !== false)) {
    if (!['voiceover', 'bgm', 'sfx'].includes(track.role)) fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
    for (const segment of track.segments ?? []) {
      const audioToken = segment.source?.kind === 'generated'
        ? segment.source.generatedAudioId
        : segment.source?.reference?.assetId ?? segment.source?.reference?.authorizationId
      const expectedCapability = track.role === 'voiceover'
        ? 'audio.voiceover.edge_tts'
        : track.role === 'bgm' ? 'audio.bgm.local' : 'audio.sfx.local'
      if (segment.capabilityId !== expectedCapability || typeof audioToken !== 'string' || audioToken.length === 0 ||
          (Array.isArray(segment.keyframes) && segment.keyframes.length > 0)) {
        fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
      }
      audioPlacements.push(Object.freeze({
        segmentId: segment.segmentId,
        role: track.role,
        audioToken,
        sourceStartUs: segment.sourceRange.startUs,
        sourceDurationUs: segment.sourceRange.durationUs,
        targetStartUs: segment.targetRange.startUs,
        targetDurationUs: segment.targetRange.durationUs,
        volume: segment.volume,
      }))
    }
  }
  /** @type {UnknownRecord[]} */
  const stickerPlacements = []
  /** @type {UnknownRecord[]} */
  const videoEffectPlacements = []
  for (const track of timelineRecord.tracks.filter((/** @type {any} */ track) => track.kind === 'effect' && track.enabled !== false)) {
    for (const segment of track.segments ?? []) {
      if (Array.isArray(segment.keyframes) && segment.keyframes.length > 0) fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
      if (segment.capabilityId === 'sticker.named') {
        const token = segment.parameters?.packagingToken
        const binding = trustedBindings.byToken.get(token)
        if (!binding || binding.family !== 'sticker') fail('JY200_DUO_BINDING_MISSING')
        stickerPlacements.push(Object.freeze({
          segmentId: segment.segmentId,
          targetStartUs: segment.targetRange.startUs,
          targetDurationUs: segment.targetRange.durationUs,
          packagingToken: binding.packagingToken,
          bindingFingerprint: binding.bindingFingerprint,
          resourceId: binding.privateBinding.resourceId,
        }))
        continue
      }
      if (segment.capabilityId === 'effect.video.named') {
        const token = segment.parameters?.packagingToken
        const binding = trustedBindings.byToken.get(token)
        if (!binding || binding.family !== 'video_effect') fail('JY200_DUO_BINDING_MISSING')
        videoEffectPlacements.push(Object.freeze({
          segmentId: segment.segmentId,
          targetStartUs: segment.targetRange.startUs,
          targetDurationUs: segment.targetRange.durationUs,
          packagingToken: binding.packagingToken,
          bindingFingerprint: binding.bindingFingerprint,
          resourceId: binding.privateBinding.resourceId,
          ...(binding.privateBinding.effectId ? { effectId: binding.privateBinding.effectId } : {}),
        }))
        continue
      }
      fail('JY200_DUO_WORKBENCH_CAPABILITY_UNSUPPORTED')
    }
  }
  const current = now()
  const draftName = formatDraftName(current)
  if (!DRAFT_NAME.test(draftName)) fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
  const draftLabel = input.projectName.trim()
  const placementSummary = normalizePlacementCounts({
    audio: audioPlacements.length,
    caption: captionTexts.length,
    flower: flowerSegments.length,
    sticker: stickerPlacements.length,
    title: titleTexts.length,
    video: materials.length,
    video_effect: videoEffectPlacements.length,
  })
  return /** @type {WritePlan} */ (Object.freeze({
    draftName,
    draftLabel,
    projectId: input.projectId,
    timelineFingerprint,
    writerProjectionFingerprint: timelineFingerprint,
    currentCatalogFingerprint: trustedBindings.catalogFingerprint,
    desktopBindingFingerprint: trustedBindings.desktopBindingFingerprint,
    bindingEvidenceFingerprint: trustedBindings.bindingEvidenceFingerprint,
    requiredCapabilities,
    providerCommit: input.provider_commit,
    providerId: input.provider_id,
    offlineOnly: true,
    summary: '剪映草稿已生成并通过结构校验，等待用户手动打开',
    handoffMode: 'manual_open_required',
    desktopOpened: false,
    manualOpenHint: '请在剪映专业版首页的本地草稿列表中打开该标签。',
    videoMaterials: Object.freeze(videoSegments.map((/** @type {any} */ segment, /** @type {number} */ index) => Object.freeze({
      segmentId: segment.segmentId,
      sourcePath: materials[index].sourcePath,
      assetId: segment.asset.assetId,
      sceneId: segment.asset.sceneId,
      candidateId: segment.audit.candidateId,
      sourceStartUs: segment.sourceRange.startUs,
      sourceDurationUs: segment.sourceRange.durationUs,
      targetStartUs: segment.targetRange.startUs,
      targetDurationUs: segment.targetRange.durationUs,
      transitionOut: segment.transitionOut,
    }))),
    titleTexts: Object.freeze(titleTexts),
    captionTexts: Object.freeze(captionTexts),
    audioPlacements: Object.freeze(audioPlacements),
    packagingPlacements: Object.freeze({
      flower: Object.freeze(flowerSegments),
      sticker: Object.freeze(stickerPlacements),
      video_effect: Object.freeze(videoEffectPlacements),
    }),
    trustedBindings: trustedBindings.entries,
    placementSummary,
  }))
}

/**
 * Build a minimal Duo adapter that can be passed directly into
 * createExternalWriterProvider(run/readback) and separately project the
 * provider receipt back into the public Workbench DTO.
 * @param {{runner: (input: {lease: Lease, writePlan: WritePlan}) => Promise<unknown>, inspectReadback: (input: {stagingRoot: string, providerResult: ProviderResult, writePlan: WritePlan, trustedBindings: readonly NormalizedBinding[]}) => Promise<unknown>, resolveCurrentBindings: (input: UnknownRecord) => Promise<unknown>|unknown, now?: () => Date}} input
 */
export const createJY200DuoWorkbenchAdapter = ({
  runner,
  inspectReadback,
  resolveCurrentBindings,
  now = () => new Date(),
}) => {
  if (typeof runner !== 'function' || typeof inspectReadback !== 'function' ||
      typeof resolveCurrentBindings !== 'function' || typeof now !== 'function') {
    fail('JY200_DUO_WORKBENCH_ADAPTER_INVALID', 500)
  }
  /** @type {Map<string, WritePlan>} */
  const plans = new Map()

  return Object.freeze({
    supportedCapabilities: Object.freeze([...SUPPORTED_CAPABILITIES]),
    /** @param {AdapterRunInput} input @param {unknown} lease */
    async run(input, lease) {
      if (!isRecord(lease) || !LEASE.test(/** @type {string|undefined} */ (lease.lease_id) ?? '')) fail('JY200_DUO_WORKBENCH_INPUT_INVALID')
      const currentBindings = await resolveCurrentBindings(Object.freeze({
        jobId: input.jobId,
        projectId: input.projectId,
        richTimeline: input.richTimeline,
        timelineFingerprint: input.timeline_fingerprint,
        providerId: input.provider_id,
        providerCommit: input.provider_commit,
        requiredCapabilities: input.required_capabilities,
      }))
      const writePlan = buildWritePlan(input, now, currentBindings)
      const runnerResult = /** @type {UnknownRecord} */ (await runner({
        lease: /** @type {Lease} */ (lease),
        writePlan,
      }))
      if (!isRecord(runnerResult)) fail('JY200_DUO_PROVIDER_RESULT_INVALID', 502)
      if (!FINGERPRINT.test(/** @type {string|undefined} */ (runnerResult.executionReceiptFingerprint) ?? '') ||
          runnerResult.draftName !== writePlan.draftName) {
        fail('JY200_DUO_PROVIDER_RESULT_INVALID', 502)
      }
      const executionReceiptFingerprint = /** @type {string} */ (runnerResult.executionReceiptFingerprint)
      if (plans.has(executionReceiptFingerprint)) fail('JY200_DUO_PROVIDER_RESULT_INVALID', 502)
      /** @type {ProviderResult} */
      const providerResult = /** @type {ProviderResult} */ (Object.freeze({
        draftName: /** @type {string} */ (runnerResult.draftName),
        draftLabel: writePlan.draftLabel,
        summary: writePlan.summary,
        handoffMode: writePlan.handoffMode,
        desktopOpened: writePlan.desktopOpened,
        manualOpenHint: writePlan.manualOpenHint,
        timelineFingerprint: writePlan.timelineFingerprint,
        writerProjectionFingerprint: writePlan.writerProjectionFingerprint,
        bindingEvidenceFingerprint: writePlan.bindingEvidenceFingerprint,
        currentCatalogFingerprint: writePlan.currentCatalogFingerprint,
        desktopBindingFingerprint: writePlan.desktopBindingFingerprint,
        executionReceiptFingerprint,
        placementSummary: writePlan.placementSummary,
      }))
      plans.set(executionReceiptFingerprint, writePlan)
      return normalizeProviderResult(providerResult)
    },
    /** @param {UnknownRecord} input */
    async readback(input) {
      if (!isRecord(input) || !isAbsoluteWindowsPath(input.stagingRoot)) fail('JY200_DUO_READBACK_INVALID', 502)
      const providerResult = normalizeProviderResult(input.providerResult)
      if (input.timelineFingerprint !== providerResult.timelineFingerprint || input.providerId !== PROVIDER_ID) {
        fail('JY200_DUO_READBACK_INVALID', 502)
      }
      const requiredCapabilities = normalizeRequiredCapabilities(input.requiredCapabilities)
      const writePlan = plans.get(providerResult.executionReceiptFingerprint)
      if (!writePlan ||
          writePlan.requiredCapabilities.join('\0') !== requiredCapabilities.join('\0') ||
          /** @type {string|undefined} */ (input.providerCommit) !== writePlan.providerCommit) {
        fail('JY200_DUO_READBACK_INVALID', 502)
      }
      const readback = normalizeReadbackOutput(await inspectReadback({
        stagingRoot: /** @type {string} */ (input.stagingRoot),
        providerResult,
        writePlan,
        trustedBindings: writePlan.trustedBindings,
      }))
      if (Object.hasOwn(readback, 'draftName') && readback.draftName !== providerResult.draftName) {
        fail('JY200_DUO_READBACK_INVALID', 502)
      }
      plans.delete(providerResult.executionReceiptFingerprint)
      /** @type {ReadbackReceipt} */
      return /** @type {ReadbackReceipt} */ (Object.freeze({
        verified: true,
        timeline_fingerprint: providerResult.timelineFingerprint,
        output_fingerprint: readback.outputFingerprint,
        draft_id: providerResult.draftName,
        summary: providerResult.summary,
        handoff_mode: providerResult.handoffMode,
        desktop_opened: false,
        draft_label: providerResult.draftLabel,
        manual_open_hint: providerResult.manualOpenHint,
        writer_projection_fingerprint: providerResult.writerProjectionFingerprint,
      }))
    },
    /** @param {UnknownRecord} value */
    projectWorkbenchResult(value) {
      /** @type {UnknownRecord} */
      const nestedReceipt = isRecord(value.readback_receipt) ? value.readback_receipt : {}
      const receipt = hasExactKeys(nestedReceipt, READBACK_KEYS)
        ? nestedReceipt
        : value
      if (!hasExactKeys(receipt, READBACK_KEYS) ||
          receipt.verified !== true ||
          !FINGERPRINT.test(/** @type {string|undefined} */ (receipt.timeline_fingerprint) ?? '') ||
          !FINGERPRINT.test(/** @type {string|undefined} */ (receipt.output_fingerprint) ?? '') ||
          !DRAFT_NAME.test(/** @type {string|undefined} */ (receipt.draft_id) ?? '') ||
          receipt.summary !== '剪映草稿已生成并通过结构校验，等待用户手动打开' ||
          receipt.handoff_mode !== 'manual_open_required' ||
          receipt.desktop_opened !== false ||
          !isSafeText(receipt.draft_label, 180) ||
          receipt.manual_open_hint !== '请在剪映专业版首页的本地草稿列表中打开该标签。' ||
          !FINGERPRINT.test(/** @type {string|undefined} */ (receipt.writer_projection_fingerprint) ?? '')) {
        fail('JY200_DUO_WORKBENCH_RESULT_INVALID', 502)
      }
      const typedReceipt = /** @type {ReadbackReceipt} */ (receipt)
      return Object.freeze({
        draftId: typedReceipt.draft_id,
        outputFingerprint: typedReceipt.output_fingerprint,
        summary: typedReceipt.summary,
        handoffMode: typedReceipt.handoff_mode,
        desktopOpened: typedReceipt.desktop_opened,
        draftLabel: typedReceipt.draft_label,
        manualOpenHint: typedReceipt.manual_open_hint,
        writerProjectionFingerprint: typedReceipt.writer_projection_fingerprint,
      })
    },
  })
}
