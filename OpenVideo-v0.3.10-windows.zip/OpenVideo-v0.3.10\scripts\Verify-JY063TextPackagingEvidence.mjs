import { createHash } from 'node:crypto'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { parseJianyingTextPackagingCatalog } from '../apps/gateway/src/jianying-text-packaging-catalog.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const exactKeys = (value, keys) => value && typeof value === 'object' &&
  Object.keys(value).sort().join('\0') === [...keys].sort().join('\0')
const safeDraftName = (value) => typeof value === 'string' && /^OpenVideo-JY063-text-packaging-[0-9]{10,20}$/u.test(value)
const safeMediaRoot = (value) => typeof value === 'string' && path.isAbsolute(value) &&
  path.dirname(path.resolve(value)) === path.resolve(tmpdir()) && path.basename(value).startsWith('openvideo-jy063-text-packaging-')
const textOf = (material) => {
  try { const parsed = JSON.parse(material?.content); return typeof parsed?.text === 'string' ? parsed.text : null } catch { return null }
}

const main = async () => {
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy063-text-packaging')
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  if (!exactKeys(pending, ['schema_version', 'draft_id', 'profile_id', 'app_version', 'draft_root', 'media_root', 'catalog_fingerprint', 'capabilities']) ||
    pending.schema_version !== 1 || !safeDraftName(pending.draft_id) || !safeMediaRoot(pending.media_root) ||
    pending.profile_id !== 'jianying-11-1-provisional' || !Array.isArray(pending.capabilities) || pending.capabilities.length !== 3) throw new Error('JY063_EVIDENCE_LEASE_INVALID')
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== pending.profile_id || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root)) throw new Error('JY063_EVIDENCE_BINDING_INVALID')
  const draftFolder = path.resolve(desktop.draftRoot, pending.draft_id)
  if (path.dirname(draftFolder) !== path.resolve(desktop.draftRoot)) throw new Error('JY063_EVIDENCE_BINDING_INVALID')
  const catalog = parseJianyingTextPackagingCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy063-text-packaging-catalog.json'), 'utf8')))
  if (!catalog || catalog.fingerprint !== pending.catalog_fingerprint) throw new Error('JY063_EVIDENCE_BINDING_INVALID')
  const byKind = Object.fromEntries(catalog.entries.map((entry) => [entry.kind, entry]))
  const temporary = await mkdtemp(path.join(tmpdir(), 'openvideo-jy063-verify-'))
  try {
    const plaintext = path.join(temporary, 'draft_content.json')
    const decryptor = createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
    const meta = await decryptor.ensurePlaintextFile(path.join(draftFolder, 'draft_content.json'), plaintext)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY063_ENCRYPT_V2_REQUIRED')
    const bytes = await readFile(plaintext)
    const content = JSON.parse(bytes.toString('utf8'))
    const materials = content.materials ?? {}
    const tracks = content.tracks ?? []
    const stickerMaterials = (materials.stickers ?? []).filter((item) => item?.resource_id === byKind.sticker.resource_id)
    const stickerSegments = tracks.filter((track) => track?.type === 'sticker').flatMap((track) => track.segments ?? []).filter((segment) => stickerMaterials.some((material) => material.id === segment?.material_id))
    const flowerEffects = (materials.effects ?? []).filter((item) => item?.type === 'text_effect' && item?.resource_id === byKind.flower.resource_id && item?.effect_id === byKind.flower.effect_id)
    const bubbleEffects = (materials.effects ?? []).filter((item) => item?.type === 'text_shape' && item?.resource_id === byKind.bubble.resource_id && item?.effect_id === byKind.bubble.effect_id)
    const textMaterials = new Map((materials.texts ?? []).map((item) => [item.id, item]))
    const textSegments = tracks.filter((track) => track?.type === 'text').flatMap((track) => track.segments ?? [])
    const flowerSegments = textSegments.filter((segment) => flowerEffects.some((effect) => segment?.extra_material_refs?.includes(effect.id)))
    const bubbleSegments = textSegments.filter((segment) => bubbleEffects.some((effect) => segment?.extra_material_refs?.includes(effect.id)))
    const flowerResourceIds = new Set(flowerEffects.map((effect) => effect.id))
    const bubbleResourceIds = new Set(bubbleEffects.map((effect) => effect.id))
    if (stickerMaterials.length !== 1 || stickerSegments.length !== 1 || Number(stickerSegments[0]?.clip?.scale?.x) !== 1.1 || Number(stickerSegments[0]?.clip?.scale?.y) !== 1.1 ||
      flowerEffects.length < 1 || flowerSegments.length !== 1 || !flowerSegments[0]?.extra_material_refs?.some((id) => flowerResourceIds.has(id)) || textOf(textMaterials.get(flowerSegments[0].material_id)) !== 'JY063 花字已验证' ||
      bubbleEffects.length !== 1 || bubbleSegments.length !== 1 || !bubbleSegments[0]?.extra_material_refs?.some((id) => bubbleResourceIds.has(id)) || textOf(textMaterials.get(bubbleSegments[0].material_id)) !== 'JY063 气泡已验证') throw new Error('JY063_POST_SAVE_MISMATCH')
    await writeFile(path.join(evidenceRoot, 'post-save.json'), `${JSON.stringify({ schema_version: 1, manual_evidence_verified: true, profile_id: pending.profile_id, app_version: pending.app_version, catalog_fingerprint: catalog.fingerprint, capabilities: pending.capabilities, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, content_fingerprint: createHash('sha256').update(bytes).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
    await rm(pending.media_root, { recursive: true, force: true })
    await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, manual_evidence_verified: true, capabilities: pending.capabilities, scheme: 'encrypt_v2' })}\n`)
  } finally { await rm(temporary, { recursive: true, force: true }) }
}
main().catch((error) => { const code = ['JY063_EVIDENCE_LEASE_INVALID', 'JY063_EVIDENCE_BINDING_INVALID', 'JY063_ENCRYPT_V2_REQUIRED', 'JY063_POST_SAVE_MISMATCH'].includes(error?.message) ? error.message : 'JY063_VERIFY_FAILED'; process.stdout.write(`${JSON.stringify({ ok: false, code })}\n`); process.exitCode = 1 })
