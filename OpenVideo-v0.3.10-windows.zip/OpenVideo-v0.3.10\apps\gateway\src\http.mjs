import { isGatewayRequest } from './contracts.mjs'
import { isDirectorRequest } from './director-contracts.mjs'
import { DirectorError } from './director.mjs'
import { GatewayError } from './gateway.mjs'
import {
  JianyingDraftAdapterError,
  isJianyingDraftJobCommand,
  preflightJianyingDraftAdapterRequest,
} from './jianying-draft-adapter.mjs'
import { createWorkbenchHandler } from './workbench.mjs'
import { parseDraftMinerStartRequest } from './jianying-draft-resource-contracts.mjs'
import { publicNativeEvidencePreflight } from './jianying-native-evidence-preflight.mjs'

/** @param {string} key */
const normalizePublicKey = (key) =>
  String(key)
    .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
    .replace(/[^a-z0-9]+/giu, '_')
    .replace(/^_+|_+$/g, '')
    .toLowerCase()

const forbiddenExactPublicKeys = new Set(['private_path', 'local_path', 'absolute_path', 'api_key', 'base_url', 'path', 'url'])
const forbiddenPublicKeyTokens = new Set(['provider', 'transcript', 'thumbnail', 'secret', 'credential', 'password', 'token', 'path', 'url'])
const publicUrlPattern = /(?:https?|file):\/\/[^\s"'<>]+|data:[^\s"'<>]+/iu
const privateRootSegments = ['ho' + 'me', 'us' + 'ers', 'pri' + 'vate', 'v' + 'ar', 't' + 'mp', 'm' + 'nt', 'vol' + 'umes'].join('|')
const publicLocalPathPattern = new RegExp(`(?:[a-z]:[\\\\/]|\\\\\\\\[^\\\\/\\s]+[\\\\/][^\\\\/\\s]+|/(?:${privateRootSegments})/)`, 'iu')

/** @param {unknown} value @returns {boolean} */
const hasForbiddenPublicField = (value) => {
  if (typeof value === 'string') return publicUrlPattern.test(value) || publicLocalPathPattern.test(value)
  if (Array.isArray(value)) return value.some(hasForbiddenPublicField)
  if (!value || typeof value !== 'object') return false
  return Object.entries(value).some(([key, entry]) => {
    const normalizedKey = normalizePublicKey(key)
    const keyTokens = normalizedKey.split('_').filter(Boolean)
    const safeOpaquePackagingToken = normalizedKey === 'packaging_token' && typeof entry === 'string' && /^ovj[a-z0-9_]{6,180}$/u.test(entry)
    return (
      (forbiddenExactPublicKeys.has(normalizedKey) && !safeOpaquePackagingToken) ||
      (keyTokens.some((token) => forbiddenPublicKeyTokens.has(token)) && !safeOpaquePackagingToken) ||
      hasForbiddenPublicField(entry)
    )
  })
}

/** @param {unknown} body @param {number} status */
const jsonResponse = (body, status) => {
  const unsafe = status < 400 && hasForbiddenPublicField(body)
  const payload = unsafe
    ? { error: { code: 'UNSAFE_PUBLIC_RESPONSE', message: 'The response was blocked by the safe public boundary.' } }
    : body
  return new Response(JSON.stringify(payload), {
    status: unsafe ? 500 : status,
    headers: {
      'cache-control': 'no-store',
      'content-type': 'application/json; charset=utf-8',
      'x-content-type-options': 'nosniff',
    },
  })
}

const briefInteractiveSchemas = new Set(['script_polish', 'selling_points', 'packaging_suggestions'])

/** @param {{capability?: string, jsonSchema?: {name?: string}, messages?: Array<{role?: string, parts?: Array<{type?: string, text?: string}>}>}} body */
const briefInteractiveMaxTokens = (body) => {
  const name = body.jsonSchema?.name
  const userText = [...(body.messages ?? [])]
    .reverse()
    .find((message) => message.role === 'user')
    ?.parts
    ?.filter((part) => part.type === 'text' && typeof part.text === 'string')
    .map((part) => part.text)
    .join('') ?? ''
  const scriptBody = userText.match(/(?:原)?脚本\/文案：([\s\S]*)$/u)?.[1] ?? userText
  if (name === 'script_polish') {
    return Math.min(8192, Math.max(2048, scriptBody.length + 512))
  }
  if (name === 'selling_points') {
    return Math.min(2048, Math.max(512, Math.ceil(scriptBody.length / 4) + 384))
  }
  if (name === 'packaging_suggestions') {
    return Math.min(2560, Math.max(768, Math.ceil(scriptBody.length / 3) + 512))
  }
  return undefined
}

/** @param {{gateway: {generate: (request: any, options?: {signal?: AbortSignal, priority?: 'interactive' | 'background', maxTokens?: number, jsonMode?: 'strict' | 'compatible', timeoutMs?: number, maxAttempts?: number}) => Promise<unknown>}}} dependencies */
export const createGatewayHandler = ({ gateway }) => {
  /** @param {Request} request */
  return async (request) => {
    if (request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const mediaType = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase()
    if (mediaType !== 'application/json') {
      return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
    }

    let body
    try {
      body = await request.json()
    } catch {
      return jsonResponse({ error: { code: 'INVALID_REQUEST', message: 'Request body is invalid.' } }, 400)
    }

    if (!isGatewayRequest(body)) {
      return jsonResponse({ error: { code: 'INVALID_REQUEST', message: 'Request body is invalid.' } }, 400)
    }

    try {
      const briefSchemaName = body.capability === 'json' && typeof body.jsonSchema?.name === 'string'
        ? body.jsonSchema.name
        : ''
      const briefInteractive = briefInteractiveSchemas.has(briefSchemaName)
      return jsonResponse(await gateway.generate(body, {
        signal: request.signal,
        ...(briefInteractive
          ? {
            priority: 'interactive',
            jsonMode: 'compatible',
            maxTokens: briefInteractiveMaxTokens(body),
            timeoutMs: 45_000,
            maxAttempts: briefSchemaName === 'script_polish' ? 2 : 1,
          }
          : {}),
      }), 200)
    } catch (error) {
      if (error instanceof GatewayError) {
        return jsonResponse({ error: { code: error.code, message: error.message } }, error.status)
      }
      return jsonResponse({ error: { code: 'INTERNAL_ERROR', message: 'The gateway request failed.' } }, 500)
    }
  }
}

/** @param {{director: {createEditPlan: (request: unknown) => Promise<unknown>}}} dependencies */
export const createDirectorHandler = ({ director }) => {
  /** @param {Request} request */
  return async (request) => {
    if (request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const mediaType = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase()
    if (mediaType !== 'application/json') {
      return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
    }

    let body
    try {
      body = await request.json()
    } catch {
      return jsonResponse({ error: { code: 'INVALID_REQUEST', message: 'Request body is invalid.' } }, 400)
    }
    if (!isDirectorRequest(body)) {
      return jsonResponse({ error: { code: 'INVALID_REQUEST', message: 'Request body is invalid.' } }, 400)
    }
    try {
      return jsonResponse(await director.createEditPlan(body), 200)
    } catch (error) {
      if (error instanceof DirectorError) {
        return jsonResponse({ error: { code: error.code, message: error.message } }, error.status)
      }
      return jsonResponse({ error: { code: 'INTERNAL_ERROR', message: 'The director request failed.' } }, 500)
    }
  }
}

/** @param {{service: {start: (request: any) => unknown, getStatus: (jobId: string) => unknown, cancel: (jobId: string) => unknown}, registry: {get: (requestId: string) => unknown}}} dependencies */
export const createJianyingDraftHandler = ({ service, registry }) => {
  /** @param {Request} request */
  return async (request) => {
    const pathname = new URL(request.url).pathname
    const jobMatch = pathname.match(/^\/api\/jianying-draft\/jobs\/([^/]+)(\/cancel)?$/u)
    if (jobMatch) {
      let jobId
      try {
        jobId = decodeURIComponent(jobMatch[1])
      } catch {
        return jsonResponse({ error: { code: 'JY002_JOB_NOT_FOUND', message: 'Jianying export job was not found.' } }, 404)
      }
      const cancelling = jobMatch[2] === '/cancel'
      if ((!cancelling && request.method !== 'GET') || (cancelling && request.method !== 'POST')) {
        return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
      }
      const status = cancelling ? await service.cancel(jobId) : service.getStatus(jobId)
      if (!status) {
        return jsonResponse({ error: { code: 'JY002_JOB_NOT_FOUND', message: 'Jianying export job was not found.' } }, 404)
      }
      return jsonResponse(status, 200)
    }

    if (!['/api/jianying-draft/preflight', '/api/jianying-draft/export'].includes(pathname)) {
      return jsonResponse({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    if (request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const mediaType = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase()
    if (mediaType !== 'application/json') {
      return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
    }

    let body
    try {
      body = await request.json()
    } catch {
      return jsonResponse(
        { error: { code: 'JY002_ADAPTER_REQUEST_INVALID', message: 'Jianying export request needs to be rebuilt.' } },
        400,
      )
    }

    try {
      if (!isJianyingDraftJobCommand(body)) {
        return jsonResponse(
          { error: { code: 'JY002_ADAPTER_REQUEST_INVALID', message: 'Jianying export request needs to be rebuilt.' } },
          400,
        )
      }
      const adapterRequest = registry.get(body.request_id)
      if (!adapterRequest) {
        return jsonResponse(
          { error: { code: 'JY002_REQUEST_NOT_FOUND', message: 'Jianying export request is no longer available.' } },
          404,
        )
      }
      if (pathname === '/api/jianying-draft/preflight') {
        return jsonResponse(preflightJianyingDraftAdapterRequest(adapterRequest), 200)
      }
      return jsonResponse(service.start(adapterRequest), 202)
    } catch (error) {
      if (error instanceof JianyingDraftAdapterError) {
        return jsonResponse({ error: { code: error.code, message: error.message } }, 400)
      }
      return jsonResponse(
        { error: { code: 'JY002_INTERNAL_FAILURE', message: 'The Jianying export could not be completed.' } },
        500,
      )
    }
  }
}

/**
 * Same-origin discovery-only draft miner boundary. The service owns request-id
 * minting and authorization checks; this adapter accepts only an opaque handle
 * and never forwards a browser path or writer payload.
 * @param {{service: {start: (input: unknown) => Promise<{status: number, created: boolean, job: unknown}>, status: (jobId: string) => Promise<unknown>, cancel: (jobId: string) => Promise<unknown>, retry: (jobId: string) => Promise<unknown>}}} dependencies
 */
export const createJianyingDraftMinerHandler = ({ service }) => {
  /** @param {Request} request */
  return async (request) => {
    const pathname = new URL(request.url).pathname
    const match = pathname.match(/^\/api\/jianying-draft-miner\/jobs(?:\/([^/]+)(?:\/(cancel|retry))?)?$/u)
    if (!match) return jsonResponse({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    let jobId = null
    try { jobId = match[1] ? decodeURIComponent(match[1]) : null } catch {
      return jsonResponse({ error: { code: 'NATIVE004_JOB_NOT_FOUND', message: 'The discovery job was not found.' } }, 404)
    }
    const action = match[2] ?? null
    if (!jobId && request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Use POST to create a discovery job.' } }, 405)
    }
    if (jobId && !action && request.method !== 'GET') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Use GET to poll a discovery job.' } }, 405)
    }
    if (jobId && action && request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Use POST for job actions.' } }, 405)
    }
    try {
      if (jobId && !action) {
        const status = await service.status(jobId)
        return status
          ? jsonResponse(status, 200)
          : jsonResponse({ error: { code: 'NATIVE004_JOB_NOT_FOUND', message: 'The discovery job was not found.' } }, 404)
      }
      if (jobId && action) {
        const status = action === 'cancel' ? await service.cancel(jobId) : await service.retry(jobId)
        return status
          ? jsonResponse(status, 200)
          : jsonResponse({ error: { code: 'NATIVE004_JOB_NOT_FOUND', message: 'The discovery job was not found.' } }, 404)
      }
      const mediaType = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase()
      if (mediaType !== 'application/json') {
        return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
      }
      let body
      try {
        body = await request.json()
      } catch {
        return jsonResponse({ error: { code: 'NATIVE004_REQUEST_INVALID', message: 'Discovery request is invalid.' } }, 400)
      }
      parseDraftMinerStartRequest(body)
      const result = await service.start(body)
      return jsonResponse(result.job, result.status)
    } catch (error) {
      const candidate = /** @type {{code?: unknown}} */ (error)
      const code = typeof candidate?.code === 'string' && /^NATIVE004_[A-Z0-9_]+$/u.test(candidate.code)
        ? candidate.code
        : 'NATIVE004_REQUEST_INVALID'
      const status = code.includes('AUTHORIZATION') ? 403 : 400
      return jsonResponse({ error: { code, message: 'The discovery job request was rejected.' } }, status)
    }
  }
}

/**
 * Read-only exact-build evidence status. The loader is server-owned and the
 * public projection intentionally omits DLL fingerprints, paths and receipt
 * integrity material. No request body or caller path is accepted.
 * @param {{loadReceipt: () => Promise<unknown>, timeoutMs?: number}} input
 */
// Leave bounded headroom for response serialization and event-loop scheduling
// inside the product's hard 15-second request budget. The loader performs the
// complete current-identity verification itself.
export const createJianyingNativeEvidencePreflightHandler = ({ loadReceipt, timeoutMs = 14_500 }) => async (/** @type {Request} */ request) => {
  if (request.method !== 'GET') return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Evidence preflight is read-only.' } }, 405)
  if (typeof loadReceipt !== 'function' || !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 15_000) {
    return jsonResponse({ error: { code: 'NATIVE004_EVIDENCE_UNAVAILABLE', message: 'No valid evidence preflight receipt is available.' } }, 503)
  }
  try {
    const receipt = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('NATIVE004_PREFLIGHT_TIMEOUT')), timeoutMs)
      Promise.resolve(loadReceipt()).then(
        (value) => { clearTimeout(timer); resolve(value) },
        (error) => { clearTimeout(timer); reject(error) },
      )
    })
    if (!receipt) return jsonResponse({ error: { code: 'NATIVE004_EVIDENCE_UNAVAILABLE', message: 'No valid evidence preflight receipt is available.' } }, 503)
    return jsonResponse(publicNativeEvidencePreflight(receipt), 200)
  } catch {
    return jsonResponse({ error: { code: 'NATIVE004_EVIDENCE_UNAVAILABLE', message: 'No valid evidence preflight receipt is available.' } }, 503)
  }
}

export { createWorkbenchHandler }
