const emphasisRoles = Object.freeze(['problem', 'locate', 'practice', 'confirm'])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
const safeText = (value) => typeof value === 'string' ? value : ''

/**
 * Classify a highlight / packaging note into a sound role. This is the
 * deterministic fallback when the LLM assignment is unavailable.
 * @param {unknown} text
 * @param {unknown} [notes]
 */
export const classifyEmphasisSfxIntent = (text, notes = '') => {
  const classify = (hay) => {
    if (/丢分|薄弱|问题|反复|不准|痛点/u.test(hay)) return 'problem'
    if (/定位|一眼|报告|识别|追踪|学情/u.test(hay)) return 'locate'
    if (/复习|练习|专项|几何|安排|针对性/u.test(hay)) return 'practice'
    if (/提升|确认|精准|完成|预约/u.test(hay)) return 'confirm'
    return 'generic'
  }
  const fromText = classify(safeText(text))
  if (fromText !== 'generic') return fromText
  return classify(safeText(notes))
}

/**
 * Pick template SFX by emphasis intent. The pool is a reusable inventory of
 * sounds (token, duration, volume). Assignment is by meaning, not by the
 * template's original timestamps or highlight index modulo pool size.
 * @param {readonly any[]} pool
 * @param {readonly string[]} highlights
 * @param {string} [notes]
 */
export const assignTemplateSfxPoolByIntent = (pool, highlights, notes = '') => {
  const cues = Array.isArray(pool) ? pool.filter((cue) => isRecord(cue)) : []
  const texts = Array.isArray(highlights)
    ? highlights.filter((value) => typeof value === 'string' && value.trim())
    : []
  if (cues.length === 0 || texts.length === 0) return []
  /** @type {Map<string, Array<{cue: Record<string, any>, index: number}>>} */
  const buckets = new Map(emphasisRoles.map((role) => [role, []]))
  cues.forEach((cue, index) => {
    const role = emphasisRoles[Math.min(
      emphasisRoles.length - 1,
      Math.floor(index * emphasisRoles.length / cues.length),
    )]
    buckets.get(role)?.push({ cue, index })
  })
  const usedCount = new Map()
  return texts.map((highlight) => {
    const intent = classifyEmphasisSfxIntent(highlight, notes)
    const role = intent === 'generic' ? 'locate' : intent
    const bucket = (buckets.get(role)?.length ? buckets.get(role) : cues.map((cue, index) => ({ cue, index })))
      .slice()
      .sort((left, right) =>
        (usedCount.get(left.index) ?? 0) - (usedCount.get(right.index) ?? 0) || left.index - right.index)
    const chosen = bucket[0]
    usedCount.set(chosen.index, (usedCount.get(chosen.index) ?? 0) + 1)
    return { ...chosen.cue }
  })
}

/**
 * Ask the project LLM Gateway to bind each highlight to a template SFX index.
 * Fail closed to intent matching; never invent a token outside the pool.
 * @param {{
 *   pool: readonly any[],
 *   highlights: readonly string[],
 *   notes?: string,
 *   gateway?: {generate: Function} | null,
 *   signal?: AbortSignal | null,
 * }} input
 */
export const assignTemplateSfxPoolByLlm = async ({
  pool,
  highlights,
  notes = '',
  gateway = null,
  signal = null,
}) => {
  const fallback = assignTemplateSfxPoolByIntent(pool, highlights, notes)
  const cues = Array.isArray(pool) ? pool.filter((cue) => isRecord(cue)) : []
  const texts = Array.isArray(highlights)
    ? highlights.filter((value) => typeof value === 'string' && value.trim()).slice(0, 24)
    : []
  if (cues.length === 0 || texts.length === 0) return []
  if (!gateway || typeof gateway.generate !== 'function') return fallback
  try {
    const result = await gateway.generate({
      purpose: 'template_sfx_assignment',
      schema: {
        type: 'object',
        additionalProperties: false,
        required: ['assignments'],
        properties: {
          assignments: {
            type: 'array',
            minItems: texts.length,
            maxItems: texts.length,
            items: {
              type: 'object',
              additionalProperties: false,
              required: ['highlightIndex', 'poolIndex'],
              properties: {
                highlightIndex: { type: 'integer', minimum: 0, maximum: texts.length - 1 },
                poolIndex: { type: ['integer', 'null'], minimum: 0, maximum: cues.length - 1 },
              },
            },
          },
        },
      },
      input: {
        notes: safeText(notes).slice(0, 400),
        highlights: texts.map((text, index) => ({ index, text: text.slice(0, 32) })),
        pool: cues.map((cue, index) => ({
          index,
          durationMs: Number.isSafeInteger(cue.durationUs) ? Math.round(cue.durationUs / 1000) : null,
        })),
      },
      signal,
    })
    const assignments = Array.isArray(result?.assignments) ? result.assignments : []
    if (assignments.length !== texts.length) return fallback
    const mapped = texts.map((text, index) => {
      const entry = assignments.find((item) => item?.highlightIndex === index) ?? assignments[index]
      const poolIndex = entry?.poolIndex
      if (!Number.isSafeInteger(poolIndex) || poolIndex < 0 || poolIndex >= cues.length) {
        return fallback[index] ?? cues[0]
      }
      return { ...cues[poolIndex] }
    })
    return mapped.length === texts.length ? mapped : fallback
  } catch {
    return fallback
  }
}
