/**

 * Arm a one-shot controlled Gateway restart.

 * Always prefers a hard deadline so keep-alive / coordinator stop cannot

 * block exit code 75 beyond the launcher confirmation window.

 *

 * On Windows Job Object supervision, ExitCode can occasionally be unavailable

 * after WaitForExit; callers should also write a restart marker via

 * `markRestart` so the launcher can continue the restart loop.

 *

 * @param {{

 *   stop: () => Promise<void>,

 *   restartProcess: (code: number) => void,

 *   markRestart?: (code: number) => void,

 *   delayMs?: number,

 *   hardDeadlineMs?: number,

 *   setTimer?: typeof setTimeout,

 *   clearTimer?: typeof clearTimeout,

 * }} options

 * @returns {() => void}

 */

export const armControlledRestart = ({

  stop,

  restartProcess,

  markRestart,

  delayMs = 100,

  hardDeadlineMs = 1_200,

  setTimer = setTimeout,

  clearTimer = clearTimeout,

}) => {

  let armed = false

  return () => {

    if (armed) return

    armed = true

    let finished = false

    const finish = () => {

      if (finished) return

      finished = true

      clearTimer(hardDeadline)

      try {

        markRestart?.(75)

      } catch {

        // Marker is best-effort; exit code 75 remains the primary signal.

      }

      try {

        restartProcess(75)

      } catch {

        // Best-effort exit; the hard deadline or process teardown still applies.

      }

    }

    const hardDeadline = setTimer(finish, hardDeadlineMs)

    setTimer(() => {

      void Promise.resolve()

        .then(() => stop())

        .catch(() => {})

        .finally(finish)

    }, delayMs)

  }

}
