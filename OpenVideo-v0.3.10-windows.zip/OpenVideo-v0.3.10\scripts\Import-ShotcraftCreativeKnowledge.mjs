import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { readFile, readdir, stat, writeFile } from 'node:fs/promises'
import { promisify } from 'node:util'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  fingerprintCreativeKnowledge,
  isCreativeKnowledgeManifest,
  isCreativeKnowledgeSnapshot,
} from '../apps/gateway/src/creative-knowledge-contracts.mjs'

const EXPECTED_COMMIT = 'b0cb89173c9278042db78c3fb9c339814966f874'
const EXPECTED_REPOSITORY = 'https://github.com/Vincentwei1021/video-shotcraft'
const EXPECTED_LICENSE = 'Apache-2.0'
const NORMALIZER_VERSION = 'shotcraft-v1-deterministic-1'
const NORMALIZER_VERSION_V2 = 'shotcraft-v2-deterministic-1'
const allowedFrontmatter = new Set(['name', '一句话', '适用', '时长', '能量', '标签'])
const sourceCardPattern = /^references\/shots\/[a-z0-9-]+\/[a-z0-9-]+\.md$/u
const forbiddenTextPattern = /(?:[A-Za-z]:[\\/]|\\\\|\bhttps?:\/\/|\bfile:|(?:api[_ -]?key|authorization|bearer|access[_ -]?token)\s*[:=])/iu
const execFileAsync = promisify(execFile)

const fail = (message) => {
  throw new Error(`SHOTCRAFT_IMPORT_INVALID: ${message}`)
}

const safeField = (value, label, max = 1_000) => {
  if (typeof value !== 'string' || value.trim() !== value || value.length === 0 || value.length > max || forbiddenTextPattern.test(value)) {
    fail(`unsafe ${label}`)
  }
  return value
}

const parseFrontmatter = (text, sourceCard) => {
  const match = /^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/u.exec(text)
  if (!match) fail(`missing frontmatter: ${sourceCard}`)
  const fields = {}
  for (const line of match[1].split(/\r?\n/u)) {
    if (!line.trim()) continue
    const separator = line.indexOf(':')
    if (separator <= 0) fail(`malformed frontmatter: ${sourceCard}`)
    const key = line.slice(0, separator).trim()
    const value = line.slice(separator + 1).trim()
    if (!allowedFrontmatter.has(key) || Object.hasOwn(fields, key)) fail(`unknown or duplicate field ${key}: ${sourceCard}`)
    fields[key] = safeField(value, `${key} in ${sourceCard}`)
  }
  for (const required of ['name', '一句话', '适用', '时长', '能量']) {
    if (!Object.hasOwn(fields, required)) fail(`missing ${required}: ${sourceCard}`)
  }
  if (!/^[a-z0-9][a-z0-9-]{1,119}$/u.test(fields.name)) fail(`unsafe name: ${sourceCard}`)
  return { fields, body: text.slice(match[0].length) }
}

const sectionLines = (body, heading) => {
  const headingPattern = new RegExp(`^##\\s+${heading}\\s*$`, 'mu')
  const start = body.search(headingPattern)
  if (start < 0) return []
  const tail = body.slice(start).replace(/^[^\n]*\r?\n/u, '')
  const nextHeading = tail.search(/^##\s+/mu)
  const section = nextHeading < 0 ? tail : tail.slice(0, nextHeading)
  return section.split(/\r?\n/u).map((line) => line.trim()).filter((line) => line.startsWith('- ')).map((line) => line.slice(2).trim())
}

const sectionText = (body, heading) => {
  const headingPattern = new RegExp(`^##\\s+${heading}\\s*$`, 'mu')
  const start = body.search(headingPattern)
  if (start < 0) return ''
  const tail = body.slice(start).replace(/^[^\n]*\r?\n/u, '')
  const nextHeading = tail.search(/^##\s+/mu)
  return nextHeading < 0 ? tail : tail.slice(0, nextHeading)
}

const boundedList = (values) => values.filter((value) => value && !forbiddenTextPattern.test(value)).slice(0, 12)

const parseDuration = (value, sourceCard) => {
  const seconds = [...value.matchAll(/(\d+(?:\.\d+)?)\s*(?:s|秒)/giu)].map((match) => Number(match[1]))
  if (seconds.length === 0) {
    if (/\bn\/a\b|寄生型|元素级|动作段/iu.test(value)) return null
    fail(`missing duration: ${sourceCard}`)
  }
  if (seconds.some((entry) => !Number.isFinite(entry) || entry <= 0)) fail(`missing duration: ${sourceCard}`)
  return {
    minUs: Math.round(Math.min(...seconds) * 1_000_000),
    maxUs: Math.round(Math.max(...seconds) * 1_000_000),
  }
}

const parseEnergy = (value, sourceCard) => {
  if (value.includes('高')) return 'high'
  if (value.includes('低')) return 'low'
  if (value.includes('中')) return 'medium'
  fail(`unknown energy: ${sourceCard}`)
}

const parseIntents = (value) => boundedList(value.split(/[；;。]/u).map((entry) => entry.trim()).filter(Boolean))

const soundFamilyMatchers = Object.freeze([
  ['whoosh', /whoosh|呼啸|风声|扫过|笔擦|擦声/iu],
  ['impact', /impact|音爆|爆发|撞击|砸|重拳|kick/iu],
  ['riser', /riser|渐强|上升音|蓄力/iu],
  ['sparkle', /sparkle|叮|清脆|高音/iu],
  ['transition', /transition|转场|换景|切点|白闪/iu],
  ['camera', /快门|camera|咔嚓/iu],
  ['text', /打字|typing|typewriter|文字音|键盘/iu],
  ['foley', /click|pop|tick|啪|咔|轻叩|落地|机械|拟音|duk/iu],
])

const soundEvidence = (body) => {
  const explicitSection = sectionText(body, '声音')
  const inline = body.split(/\r?\n/u)
    .filter((line) => /声音|音效|拟音|配声|sound-design/iu.test(line))
    .join('\n')
  return `${explicitSection}\n${inline}`
}

const audioCueIntentsFor = (body, energy) => {
  const evidence = soundEvidence(body)
  if (!evidence.trim()) return []
  const anchor = /转场|接缝|切点|换景/iu.test(evidence)
    ? 'seam'
    : /落定|停帧|收尾|回弹后/iu.test(evidence)
      ? 'settle'
      : /撞击|命中|爆发|落地|同帧/iu.test(evidence)
        ? 'action'
        : /入场|起跑|开始/iu.test(evidence)
          ? 'shot_start'
          : 'action'
  const importance = energy === 'high' || /必须|强依赖|重拍|同帧/iu.test(evidence) ? 'high' : 'medium'
  return soundFamilyMatchers
    .filter(([, matcher]) => matcher.test(evidence))
    .map(([family]) => `${family}:${anchor}:${importance}`)
    .slice(0, 8)
}

const ruleId = (family, name, suffix = '') =>
  `shotcraft-v2-${family}-${name}${suffix ? `-${suffix}` : ''}`

const techniqueDefinitions = Object.freeze({
  'impact-feedback': {
    evidence: [/顿帧/u, /限高潮一次|全片唯一高潮/u],
    rules: [
      { family: 'rhythm_pattern', rhythmClass: 'rest', maxConsecutiveHighEnergy: 1, minRestBeats: 2 },
      { family: 'audio_cue', soundFamily: 'impact', anchor: 'action', importance: 'high', maxOccurrences: 1 },
      { family: 'global_limit', techniqueClass: 'hero_impact', maxOccurrences: 1, minRestBeats: 3 },
    ],
  },
  'line-boil': {
    evidence: [/hold/iu, /全片同时沸腾/u],
    rules: [
      { family: 'hold_budget', minHoldUs: 500_000, maxHoldUs: 2_000_000, minSourceUs: 2_000_000 },
      { family: 'global_limit', techniqueClass: 'ambient_hold', maxOccurrences: 1, minRestBeats: 1 },
    ],
  },
  'slam-entrance-moves': {
    evidence: [/hold\s*≥45f/iu, /全片砸入\s*≤2/u],
    rules: [
      { family: 'hold_budget', minHoldUs: 1_500_000, maxHoldUs: 2_500_000, minSourceUs: 2_500_000 },
      { family: 'rhythm_pattern', rhythmClass: 'decelerate', maxConsecutiveHighEnergy: 1, minRestBeats: 1 },
      { family: 'audio_cue', soundFamily: 'impact', anchor: 'action', importance: 'high', maxOccurrences: 2 },
      { family: 'global_limit', techniqueClass: 'hero_impact', maxOccurrences: 2, minRestBeats: 2 },
    ],
  },
  'smear-multiples': {
    evidence: [/真静止\s*≥20f/iu, /互斥/u],
    rules: [
      { family: 'hold_budget', minHoldUs: 667_000, maxHoldUs: 1_500_000, minSourceUs: 1_500_000 },
      { family: 'rhythm_pattern', rhythmClass: 'accelerate', maxConsecutiveHighEnergy: 2, minRestBeats: 1 },
      { family: 'global_limit', techniqueClass: 'motion_accent', maxOccurrences: 2, minRestBeats: 1 },
    ],
  },
  'shot-transitions': {
    evidence: [/一个接缝只用一式/u, /D 式\s*≤2/u],
    rules: [
      { family: 'transition_seam', capabilityId: 'transition.cut', maxOccurrences: 12, requiresSemanticRelation: false },
      { family: 'rhythm_pattern', rhythmClass: 'rest', maxConsecutiveHighEnergy: 2, minRestBeats: 1 },
      { family: 'global_limit', techniqueClass: 'hero_transition', maxOccurrences: 2, minRestBeats: 1 },
    ],
  },
  'transition-hidden-cut': {
    evidence: [/一支片一处/u, /一个接缝只用一式/u],
    rules: [
      { family: 'transition_seam', capabilityId: 'transition.cut', maxOccurrences: 1, requiresSemanticRelation: false },
      { family: 'audio_cue', soundFamily: 'transition', anchor: 'seam', importance: 'high', maxOccurrences: 1 },
      { family: 'global_limit', techniqueClass: 'hero_transition', maxOccurrences: 1, minRestBeats: 2 },
    ],
  },
  'transition-travel': {
    evidence: [/一缝一式/u, /前后\s*hold/iu],
    rules: [
      { family: 'transition_seam', capabilityId: 'transition.cut', maxOccurrences: 1, requiresSemanticRelation: true },
      { family: 'rhythm_pattern', rhythmClass: 'decelerate', maxConsecutiveHighEnergy: 2, minRestBeats: 1 },
      { family: 'global_limit', techniqueClass: 'hero_transition', maxOccurrences: 1, minRestBeats: 2 },
    ],
  },
})

const techniqueRulesFor = ({ fields, text, sourceCard }) => {
  const definition = techniqueDefinitions[fields.name]
  if (!definition || definition.evidence.some((matcher) => !matcher.test(text))) {
    fail(`unknown or changed technique card: ${sourceCard}`)
  }
  const category = sourceCard.split('/')[2]
  const roles = category === 'effects'
    ? ['effects', 'opening', 'data', 'typography']
    : category === 'rhythm'
      ? ['rhythm', 'interaction', 'camera']
      : ['transition', 'opening', 'outro']
  const energies = fields.能量.includes('低') ? ['low'] : fields.能量.includes('高') ? ['high'] : ['low', 'medium', 'high']
  return definition.rules.map((rule, index) => ({
    ruleId: ruleId(
      rule.family === 'hold_budget' ? 'hold' :
        rule.family === 'rhythm_pattern' ? 'rhythm' :
          rule.family === 'transition_seam' ? 'seam' :
            rule.family === 'audio_cue' ? 'audio' : 'limit',
      fields.name,
      String(index + 1),
    ),
    sourceCard,
    family: rule.family,
    applicableShotRoles: roles,
    applicableEnergies: energies,
    ...rule,
  }))
}

const recipeAudioRulesFor = ({ recipe, sourceCard }) => recipe.audioCueIntents.map((intent, index) => {
  const [soundFamily, anchor, importance] = intent.split(':')
  return {
    ruleId: ruleId('audio', recipe.recipeId.replace(/^shotcraft-v1-/u, ''), String(index + 1)),
    sourceCard,
    family: 'audio_cue',
    applicableShotRoles: [recipe.shotRole],
    applicableEnergies: [recipe.energy],
    soundFamily,
    anchor,
    importance,
    maxOccurrences: importance === 'high' ? 2 : 4,
  }
})

const walk = async (directory) => {
  const entries = await readdir(directory, { withFileTypes: true })
  const files = []
  for (const entry of entries) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) files.push(...await walk(path))
    else if (entry.isFile() && entry.name.endsWith('.md')) files.push(path)
  }
  return files
}

const sha256File = async (path) => createHash('sha256').update(await readFile(path)).digest('hex')

const verifySourceEvidence = async (root, expectedCommit) => {
  const licensePath = join(root, 'LICENSE')
  const licenseText = await readFile(licensePath, 'utf8').catch(() => null)
  if (!licenseText || !/Apache License\s+Version 2\.0/iu.test(licenseText)) fail('LICENSE is missing or is not Apache-2.0')
  const gitDirectory = await stat(join(root, '.git')).catch(() => null)
  if (!gitDirectory) fail('source root is not a Git checkout')
  const { stdout } = await execFileAsync('git', ['-C', root, 'rev-parse', 'HEAD'])
  const actualCommit = stdout.trim()
  if (actualCommit !== expectedCommit) fail(`source commit mismatch: expected ${expectedCommit}, got ${actualCommit}`)
  return createHash('sha256').update(licenseText).digest('hex')
}

const normalizeCard = ({ text, sourceCard, sourceCommit, schemaVersion = 1 }) => {
  const { fields, body } = parseFrontmatter(text, sourceCard)
  const durationRangeUs = parseDuration(fields.时长, sourceCard)
  if (!durationRangeUs) return null
  const category = sourceCard.split('/')[2]
  const tags = fields.标签 ? boundedList(fields.标签.split(/[、,，]/u).map((entry) => entry.trim()).filter(Boolean)) : []
  const energy = parseEnergy(fields.能量, sourceCard)
  const sound = sectionLines(body, '声音')
  const motion = sectionLines(body, '动效核心')
  const pitfalls = sectionLines(body, '已知坑')
  const allLines = [...motion, ...sound, ...pitfalls]
  const holdRules = boundedList(allLines.filter((line) => /hold|静止|停留|停闪|停顿|留白/iu.test(line)))
  const transitionIntents = boundedList(sound.filter((line) => /transition|转场|交棒|切/iu.test(line)))
  const rhythmIntents = boundedList(allLines.filter((line) => /节奏|拍|帧|beat|fps/iu.test(line)))
  const pacing = energy === 'high' ? 'driving' : energy === 'low' ? 'measured' : 'steady'
  return {
    recipeId: `shotcraft-v1-${fields.name}`,
    sourceRepository: EXPECTED_REPOSITORY,
    sourceCommit,
    sourceCard,
    license: EXPECTED_LICENSE,
    shotRole: category,
    energy,
    durationRangeUs,
    creativeIntents: parseIntents(fields.适用),
    pacing,
    holdRules,
    transitionIntents,
    rhythmIntents,
    audioCueIntents: schemaVersion === 2 ? audioCueIntentsFor(body, energy) : boundedList(sound),
    requiredAssetKinds: ['visual'],
    preferredSceneAttributes: boundedList([category, ...tags]),
    avoidConditions: pitfalls,
    realizationHints: boundedList([fields.一句话, ...motion]),
  }
}

export const importShotcraftCreativeKnowledge = async ({ sourceRoot, expectedCommit = EXPECTED_COMMIT, schemaVersion = 1 } = {}) => {
  if (!sourceRoot) fail('sourceRoot is required')
  if (!/^[a-f0-9]{40}$/u.test(expectedCommit)) fail('source commit is invalid')
  if (![1, 2].includes(schemaVersion)) fail('schema version is invalid')
  const root = resolve(sourceRoot)
  const licenseSha256 = await verifySourceEvidence(root, expectedCommit)
  const sourceCardsRoot = join(root, 'references', 'shots')
  const sourceStat = await stat(sourceCardsRoot).catch(() => null)
  if (!sourceStat?.isDirectory()) fail('references/shots is missing')
  const sourceFiles = (await walk(sourceCardsRoot))
    .filter((path) => !path.endsWith('ATTRIBUTION.md'))
    .sort((left, right) => left.localeCompare(right))
  const recipes = []
  const techniqueRules = []
  const files = []
  const skipped = []
  const techniqueSources = []
  for (const path of sourceFiles) {
    const sourceCard = relative(root, path).split(sep).join('/')
    if (!sourceCardPattern.test(sourceCard)) fail(`unsafe source card: ${sourceCard}`)
    const text = await readFile(path, 'utf8')
    const recipe = normalizeCard({ text, sourceCard, sourceCommit: expectedCommit, schemaVersion })
    const file = { path: sourceCard, sha256: await sha256File(path) }
    if (recipe) {
      recipes.push(recipe)
      files.push(file)
      if (schemaVersion === 2) techniqueRules.push(...recipeAudioRulesFor({ recipe, sourceCard }))
    } else {
      if (schemaVersion === 1) {
        skipped.push({ path: sourceCard, reason: 'non-shot technique card without standalone duration' })
      } else {
        const { fields } = parseFrontmatter(text, sourceCard)
        const rules = techniqueRulesFor({ fields, text, sourceCard })
        techniqueRules.push(...rules)
        files.push(file)
        techniqueSources.push({ path: sourceCard, rule_ids: rules.map((rule) => rule.ruleId) })
      }
    }
  }
  recipes.sort((left, right) => left.recipeId.localeCompare(right.recipeId))
  techniqueRules.sort((left, right) => left.ruleId.localeCompare(right.ruleId))
  files.sort((left, right) => left.path.localeCompare(right.path))
  techniqueSources.sort((left, right) => left.path.localeCompare(right.path))
  const snapshotBase = {
    schema_version: schemaVersion,
    normalizer_version: schemaVersion === 1 ? NORMALIZER_VERSION : NORMALIZER_VERSION_V2,
    source: { repository: EXPECTED_REPOSITORY, commit: expectedCommit, license: EXPECTED_LICENSE, license_sha256: licenseSha256 },
    recipes,
    ...(schemaVersion === 2 ? { technique_rules: techniqueRules } : {}),
  }
  const snapshot = { ...snapshotBase, snapshot_fingerprint: fingerprintCreativeKnowledge(snapshotBase) }
  const manifest = {
    schema_version: schemaVersion,
    source: snapshot.source,
    normalizer: { version: snapshot.normalizer_version, prompt_version: null, model_config_fingerprint: null },
    files,
    ...(schemaVersion === 1 ? { skipped } : { technique_sources: techniqueSources }),
    snapshot_fingerprint: snapshot.snapshot_fingerprint,
  }
  if (!isCreativeKnowledgeSnapshot(snapshot) || !isCreativeKnowledgeManifest(manifest)) fail('normalized output violates contract')
  return { snapshot, manifest }
}

const writeJson = async (path, value) => {
  await writeFile(path, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
}

const main = async () => {
  const args = process.argv.slice(2)
  const sourceIndex = args.indexOf('--source-root')
  const outputIndex = args.indexOf('--output')
  const manifestIndex = args.indexOf('--manifest')
  const versionIndex = args.indexOf('--version')
  if (sourceIndex < 0 || outputIndex < 0 || manifestIndex < 0) fail('usage: --source-root <path> --output <snapshot.json> --manifest <manifest.json>')
  const schemaVersion = versionIndex < 0 ? 1 : Number(args[versionIndex + 1])
  const { snapshot, manifest } = await importShotcraftCreativeKnowledge({ sourceRoot: args[sourceIndex + 1], schemaVersion })
  await writeJson(args[outputIndex + 1], snapshot)
  await writeJson(args[manifestIndex + 1], manifest)
  process.stdout.write(JSON.stringify({
    recipes: snapshot.recipes.length,
    technique_rules: snapshot.technique_rules?.length ?? 0,
    snapshot_fingerprint: snapshot.snapshot_fingerprint,
  }) + '\n')
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main()

export { EXPECTED_COMMIT, EXPECTED_LICENSE, EXPECTED_REPOSITORY, NORMALIZER_VERSION, NORMALIZER_VERSION_V2 }
