import { isGatewayRequest } from './contracts.mjs'
import { createProviderAdapter } from './providers/openai-compatible.mjs'

/** @typedef {import('./config.mjs').GatewayCapability} GatewayCapability */
/** @typedef {import('./config.mjs').GatewayConfig} GatewayConfig */
/** @typedef {{type: 'text', text: string} | {type: 'image', url: string}} GatewayPart */
/** @typedef {{role: 'system' | 'user' | 'assistant', parts: GatewayPart[]}} GatewayMessage */
/** @typedef {{name: string, schema: Record<string, unknown>}} GatewayJsonSchema */
/** @typedef {{capability: GatewayCapability, messages: GatewayMessage[], jsonSchema?: GatewayJsonSchema}} GatewayRequest */
/** @typedef {{capability: GatewayCapability, outputText: string, outputJson?: unknown, usage?: {inputTokens: number, outputTokens: number, totalTokens: number}}} GatewayResult */
/** @typedef {{url: string, headers: Record<string, string>, body: Record<string, unknown>, timeoutMs: number}} ProviderRequest */
/** @typedef {{status: number, body: any}} ProviderResponse */
/** @typedef {{buildRequest: (request: GatewayRequest, options?: string | {model?: string, jsonMode?: 'strict' | 'compatible'}) => ProviderRequest, parseSuccess: (request: GatewayRequest, body: any) => GatewayResult | {error: string, diagnostic?: Record<string, unknown>}}} ProviderAdapter */
/** @typedef {{signal?: AbortSignal, priority?: 'interactive' | 'background', maxTokens?: number, jsonMode?: 'strict' | 'compatible', timeoutMs?: number, maxAttempts?: number}} AbortOptions */

export class GatewayError extends Error {
  /** @param {string} code @param {string} message @param {number} [status] */
  constructor(code, message, status = 502) {
    super(message)
    this.name = 'GatewayError'
    this.code = code
    this.status = status
  }
}

/** @param {number} milliseconds @param {AbortOptions} [options] */
const defaultSleep = (milliseconds, { signal } = {}) =>
  new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(signal.reason)
      return
    }
    const timeout = setTimeout(resolve, milliseconds)
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(timeout)
        reject(signal.reason)
      },
      { once: true },
    )
  })
const maxProviderResponseBytes = 2 * 1024 * 1024

/** @param {Response} response @param {number} maximumBytes */
const readResponseTextWithLimit = async (response, maximumBytes) => {
  if (!response.body) return ''
  const reader = response.body.getReader()
  const chunks = []
  let totalBytes = 0
  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      totalBytes += value.byteLength
      if (totalBytes > maximumBytes) {
        await reader.cancel()
        return null
      }
      chunks.push(value)
    }
  } finally {
    reader.releaseLock()
  }
  const bytes = new Uint8Array(totalBytes)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  return new TextDecoder().decode(bytes)
}

/** @param {ProviderRequest} request @param {AbortOptions} [options] @returns {Promise<ProviderResponse>} */
const defaultTransport = async (request, { signal } = {}) => {
  const response = await fetch(request.url, {
    method: 'POST',
    headers: request.headers,
    body: JSON.stringify(request.body),
    signal,
  })
  const rawBody = await readResponseTextWithLimit(response, maxProviderResponseBytes)
  if (rawBody === null) {
    return { status: response.status, body: { __gatewayResponseTooLarge: true } }
  }
  let body = {}
  try {
    body = JSON.parse(rawBody)
  } catch {
    body = {}
  }
  return { status: response.status, body }
}

/** @param {() => Promise<any>} operation @param {AbortSignal} signal */
const runAbortable = async (operation, signal) => {
  if (signal.aborted) throw signal.reason
  /** @type {(reason?: unknown) => void} */
  let rejectOnAbort = () => {}
  const aborted = new Promise((_resolve, reject) => {
    rejectOnAbort = () => reject(signal.reason)
    signal.addEventListener('abort', rejectOnAbort, { once: true })
  })
  try {
    return await Promise.race([operation(), aborted])
  } finally {
    signal.removeEventListener('abort', rejectOnAbort)
  }
}

/** @param {number} status */
const classifyProviderStatus = (status) => {
  if (status === 401 || status === 403) {
    return { code: 'PROVIDER_AUTH_FAILED', message: 'The LLM provider rejected server credentials.', status: 502, retryable: false }
  }
  if (status === 408) {
    return { code: 'REQUEST_TIMEOUT', message: 'The LLM provider timed out.', status: 504, retryable: true }
  }
  if (status === 429) {
    return { code: 'RATE_LIMITED', message: 'The LLM provider is rate limited.', status: 503, retryable: true }
  }
  if (status >= 500) {
    return { code: 'UPSTREAM_UNAVAILABLE', message: 'The LLM provider is temporarily unavailable.', status: 503, retryable: true }
  }
  return { code: 'UPSTREAM_REJECTED', message: 'The LLM provider rejected the request.', status: 502, retryable: false }
}

/** @param {unknown} error */
const classifyTransportError = (error) =>
  error instanceof Error && (error.name === 'AbortError' || error.name === 'TimeoutError')
    ? { code: 'REQUEST_TIMEOUT', message: 'The LLM provider timed out.', status: 504 }
    : { code: 'UPSTREAM_UNAVAILABLE', message: 'The LLM provider is temporarily unavailable.', status: 503 }

const cancellationError = () => new GatewayError('REQUEST_CANCELLED', 'The LLM request was cancelled.', 499)

/**
 * Limits in-flight provider work without turning cancelled queued requests into
 * provider calls. A permit covers the full retry sequence so a retry cannot
 * leapfrog a request already waiting for the shared model route.
 * @param {number} limit
 */
const createConcurrencyGate = (limit) => {
  const reservedInteractive = limit >= 2 ? 1 : 0
  const backgroundLimit = Math.max(1, limit - reservedInteractive)
  let active = 0
  let backgroundActive = 0
  /** @type {Array<{resolve: (release: () => void) => void, reject: (reason: unknown) => void, signal?: AbortSignal, onAbort: () => void, priority: 'interactive' | 'background'}>} */
  const queue = []

  /** @param {'interactive' | 'background'} priority */
  const createRelease = (priority) => {
    let released = false
    return () => {
      if (released) return
      released = true
      active -= 1
      if (priority !== 'interactive') backgroundActive -= 1
      drain()
    }
  }

  /** @param {'interactive' | 'background'} priority */
  const canStart = (priority) => {
    if (active >= limit) return false
    return priority === 'interactive' || backgroundActive < backgroundLimit
  }

  const takeNext = () => {
    const interactiveIndex = queue.findIndex((entry) => entry.priority === 'interactive' && canStart('interactive'))
    if (interactiveIndex >= 0) return queue.splice(interactiveIndex, 1)[0]
    const backgroundIndex = queue.findIndex((entry) => entry.priority !== 'interactive' && canStart('background'))
    if (backgroundIndex >= 0) return queue.splice(backgroundIndex, 1)[0]
    return null
  }

  const drain = () => {
    while (true) {
      const entry = takeNext()
      if (!entry) return
      entry.signal?.removeEventListener('abort', entry.onAbort)
      if (entry.signal?.aborted) {
        entry.reject(cancellationError())
        continue
      }
      active += 1
      if (entry.priority !== 'interactive') backgroundActive += 1
      entry.resolve(createRelease(entry.priority))
    }
  }

  /** @param {AbortOptions} [options] */
  const acquire = ({ signal, priority = 'background' } = {}) => {
    const requestPriority = priority === 'interactive' ? 'interactive' : 'background'
    if (signal?.aborted) throw cancellationError()
    if (queue.length === 0 && canStart(requestPriority)) {
      active += 1
      if (requestPriority !== 'interactive') backgroundActive += 1
      return createRelease(requestPriority)
    }
    return new Promise((resolve, reject) => {
      /** @type {{resolve: (release: () => void) => void, reject: (reason: unknown) => void, signal?: AbortSignal, onAbort: () => void, priority: 'interactive' | 'background'}} */
      const entry = {
        resolve,
        reject,
        signal,
        priority: requestPriority,
        onAbort: () => {
          const index = queue.indexOf(entry)
          if (index >= 0) queue.splice(index, 1)
          reject(cancellationError())
        },
      }
      signal?.addEventListener('abort', entry.onAbort, { once: true })
      if (signal?.aborted) {
        entry.onAbort()
        return
      }
      queue.push(entry)
      drain()
    })
  }

  return { acquire }
}

/** @param {GatewayRequest} request @param {GatewayConfig} config */
const hasAllowedRemoteImageHosts = (request, config) =>
  request.messages.every((message) =>
    message.parts.every((part) => {
      if (part.type !== 'image' || part.url.startsWith('data:')) return true
      const hostname = new URL(part.url).hostname.toLowerCase()
      return config.allowedImageHosts.includes(hostname)
    }),
  )

/**
 * Text and JSON routes are both user-configured chat-completion models. When
 * one relay alias temporarily loses its backend, the other route is the only
 * bounded fallback we can use without discovering or selecting an untrusted
 * model on the user's behalf. Vision remains pinned because image support
 * cannot be inferred from text or structured-output success.
 * @param {GatewayRequest} request
 * @param {GatewayConfig} config
 */
const routeCandidates = (request, config) => {
  const primary = config.models[request.capability]
  if (request.capability === 'vision') return [primary]
  const fallback = request.capability === 'text'
    ? config.models.json
    : config.models.text
  return [...new Set([primary, fallback].filter(Boolean))]
}

/**
 * @param {{config: GatewayConfig, adapter?: ProviderAdapter, transport?: (request: ProviderRequest, options?: AbortOptions) => Promise<ProviderResponse>, sleep?: (milliseconds: number, options?: AbortOptions) => Promise<void>, logger?: (event: Record<string, unknown>) => void}} dependencies
 */
export const createGateway = ({
  config,
  adapter = createProviderAdapter(config),
  transport = defaultTransport,
  sleep = defaultSleep,
  logger = () => {},
}) => {
  const requestGate = createConcurrencyGate(
    Number.isSafeInteger(config.maxConcurrentRequests) && config.maxConcurrentRequests > 0
      ? config.maxConcurrentRequests
      : 2,
  )
  return {
  /** @param {GatewayRequest} request @param {AbortOptions} [options] @returns {Promise<GatewayResult>} */
  async generate(request, options = {}) {
    const { signal } = options
    if (!isGatewayRequest(request)) {
      throw new GatewayError('INVALID_REQUEST', 'Request body is invalid.', 400)
    }
    if (!hasAllowedRemoteImageHosts(request, config)) {
      throw new GatewayError('INVALID_REQUEST', 'Request body is invalid.', 400)
    }
    if (signal?.aborted) throw cancellationError()

    const pendingRelease = requestGate.acquire({
      signal,
      priority: options.priority === 'interactive' ? 'interactive' : 'background',
    })
    const release = typeof pendingRelease === 'function' ? pendingRelease : await pendingRelease
    try {
      const candidates = routeCandidates(request, config)
      let jsonMode = /** @type {'strict' | 'compatible'} */ (
        options.jsonMode === 'compatible' ? 'compatible' : 'strict'
      )
      const maxTokens = Number.isSafeInteger(options.maxTokens) &&
        options.maxTokens >= 1 &&
        options.maxTokens <= 16_384
        ? options.maxTokens
        : undefined
      const maxAttempts = Number.isSafeInteger(options.maxAttempts) &&
        options.maxAttempts >= 1 &&
        options.maxAttempts <= config.maxAttempts
        ? options.maxAttempts
        : config.maxAttempts
      for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
        const providerRequest = adapter.buildRequest(
          request,
          {
            model: candidates[(attempt - 1) % candidates.length],
            jsonMode,
            maxTokens,
            timeoutMs: Number.isSafeInteger(options.timeoutMs) &&
              options.timeoutMs >= 1_000 &&
              options.timeoutMs <= 120_000
              ? options.timeoutMs
              : undefined,
          },
        )
        const timeoutController = new AbortController()
        const timeout = setTimeout(() => timeoutController.abort(), providerRequest.timeoutMs)
        const attemptSignal = signal
          ? AbortSignal.any([signal, timeoutController.signal])
          : timeoutController.signal
        try {
          const response = await runAbortable(
            () => transport(providerRequest, { signal: attemptSignal }),
            attemptSignal,
          )
        if (response.status >= 200 && response.status < 300) {
          const result = adapter.parseSuccess(request, response.body)
          if ('error' in result) {
            logger({
              event: 'llm_gateway_invalid_response',
              capability: request.capability,
              category: result.error,
              retryable: result.error === 'invalid-response' || result.error === 'invalid-json',
              ...(result.diagnostic ? { diagnostic: result.diagnostic } : {}),
            })
            const retryableResponseError =
              result.error === 'invalid-response' ||
              result.error === 'invalid-json' ||
              result.error === 'schema-mismatch'
            if (!retryableResponseError || attempt === maxAttempts) {
              throw new GatewayError(
                'INVALID_UPSTREAM_RESPONSE',
                result.error === 'invalid-json'
                  ? 'The LLM provider returned invalid JSON.'
                  : result.error === 'schema-mismatch'
                    ? 'The LLM provider returned JSON that did not match the required schema.'
                    : 'The LLM provider returned an invalid response.',
              )
            }
            if (request.capability === 'json' && jsonMode === 'strict') {
              jsonMode = 'compatible'
              logger({ event: 'llm_gateway_json_compatibility_retry', reason: result.error })
            }
          } else {
            return result
          }
        } else {
          const failure = classifyProviderStatus(response.status)
          logger({ event: 'llm_gateway_attempt_failed', attempt, status: response.status, retryable: failure.retryable })
          if (
            request.capability === 'json' &&
            response.status === 400 &&
            attempt < maxAttempts
          ) {
            jsonMode = jsonMode === 'strict' ? 'compatible' : 'strict'
          } else if (!failure.retryable || attempt === maxAttempts) {
            throw new GatewayError(failure.code, failure.message, failure.status)
          }
        }
      } catch (error) {
        if (error instanceof GatewayError) throw error
        if (signal?.aborted) throw cancellationError()

        const failure = timeoutController.signal.aborted
          ? { code: 'REQUEST_TIMEOUT', message: 'The LLM provider timed out.', status: 504 }
          : classifyTransportError(error)
        logger({ event: 'llm_gateway_transport_failed', attempt, retryable: true, category: failure.code })
        if (attempt === maxAttempts) {
          throw new GatewayError(failure.code, failure.message, failure.status)
        }
      } finally {
        clearTimeout(timeout)
      }

      if (signal?.aborted) throw cancellationError()
      if (signal) {
        try {
          await runAbortable(
            () => sleep(config.retryBaseDelayMs * 2 ** (attempt - 1), { signal }),
            signal,
          )
        } catch {
          if (signal.aborted) throw cancellationError()
          throw new GatewayError('UPSTREAM_UNAVAILABLE', 'The LLM provider is temporarily unavailable.', 503)
        }
      } else {
        await sleep(config.retryBaseDelayMs * 2 ** (attempt - 1))
      }
      }

      throw new GatewayError('UPSTREAM_UNAVAILABLE', 'The LLM provider is temporarily unavailable.', 503)
    } finally {
      release()
    }
  },
  }
}
