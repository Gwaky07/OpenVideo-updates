/**
 * An uploaded Jianying draft is a writable style inventory, not a sequence.
 * Current-project copy picks looks by intent; draft order never owns placement.
 */

import { redactBriefText } from './brief-packaging.mjs'
import { withProductLlmCharter } from './product-llm-charter.mjs'

const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

const INTENT_PATTERNS = Object.freeze([
  ['cta', /告别|立即|马上|行动|提升|下单|报名|点击|趁现在|别再|开始改变/u],
  ['proof', /报告|数据|对比|变化|结果|成绩|测评|曲线|证明/u],
  ['problem', /反复|盲目|卡点|丢分|薄弱|不会|痛点|总是|还在|错题/u],
  ['method', /方法|方向|定位|诊断|路径|步骤|怎么|如何|攻略|复习/u],
  ['hook', /原来|其实|你以为|真相|注意|重点|先看/u],
])

const AFFINITY = Object.freeze({
  cta: { impact: 6, neutral: 2, detail: 0 },
  hook: { impact: 5, neutral: 2, detail: 1 },
  proof: { impact: 1, neutral: 3, detail: 6 },
  problem: { impact: 3, neutral: 4, detail: 2 },
  method: { impact: 2, neutral: 5, detail: 3 },
  emphasis: { impact: 2, neutral: 4, detail: 3 },
})

export class TemplateStyleAssignmentError extends Error {
  /**
   * @param {string} code
   * @param {number} [status]
   */
  constructor(code, status = 409) {
    super(code)
    this.name = 'TemplateStyleAssignmentError'
    this.code = code
    this.status = status
  }
}

export const classifyHighlightIntent = (text) => {
  const value = typeof text === 'string' ? text : ''
  for (const [intent, pattern] of INTENT_PATTERNS) {
    if (pattern.test(value)) return intent
  }
  return 'emphasis'
}

export const classifyStyleRole = (item) => {
  const style = record(item?.style) ? item.style : {}
  const size = Number(style.size ?? item?.styleSize)
  if (Number.isFinite(size) && size >= 48) return 'impact'
  if (Number.isFinite(size) && size <= 26) return 'detail'
  const y = Number(style.transformY)
  if (Number.isFinite(y) && y > 0.25) return 'impact'
  return 'neutral'
}

const HIGHLIGHT_LIMIT = 32

const normalizeHighlight = (value) => {
  if (typeof value !== 'string') return ''
  const redacted = redactBriefText(value).trim()
  if (!redacted || redacted.startsWith('[已移除')) return ''
  return redacted.slice(0, HIGHLIGHT_LIMIT)
}

/**
 * Current-project copy only. Draft/template original lines never enter this list.
 * @param {{
 *   packaging?: Record<string, any> | null,
 *   brief?: Record<string, any> | null,
 * }} [input]
 */
export const resolveAssignmentHighlights = ({ packaging = null, brief = null } = {}) => {
  const explicit = (Array.isArray(packaging?.keywordHighlights) ? packaging.keywordHighlights : [])
    .map(normalizeHighlight)
    .filter(Boolean)
  const fallback = [
    brief?.title,
    ...(Array.isArray(brief?.sellingPoints) ? brief.sellingPoints : []),
    ...(typeof brief?.script === 'string'
      ? brief.script.split(/[\r\n。！？!?；;]+/u)
      : []),
  ]
    .map(normalizeHighlight)
    .filter(Boolean)
  const source = explicit.length > 0 ? explicit : fallback
  const seen = new Set()
  return source.filter((value) => {
    const key = value.toLocaleLowerCase()
    if (seen.has(key)) return false
    seen.add(key)
    return true
  }).slice(0, 12)
}

const EMPTY_EVIDENCE = new Set([
  '',
  'no visible text detected',
  'no reliable speech detected',
  '未识别到可信屏幕文字。',
])

const sanitizeEvidenceText = (value, limit = 200) => {
  const text = typeof value === 'string' ? redactBriefText(value).trim() : ''
  if (!text || text.startsWith('[已移除') || EMPTY_EVIDENCE.has(text.toLocaleLowerCase())) return ''
  return text.slice(0, limit)
}

/**
 * Current-shot evidence for the packaging model. Uses analyzed scene cards
 * (multi-frame visual + OCR + ASR) plus the current voiceover. No paths.
 * @param {{
 *   editPlan?: Record<string, any> | null,
 *   sceneCards?: Array<Record<string, any>>,
 * }} [input]
 */
export const buildAssignmentScenes = ({ editPlan = null, sceneCards = [] } = {}) => {
  const cardsById = new Map()
  for (const card of Array.isArray(sceneCards) ? sceneCards : []) {
    if (!record(card)) continue
    for (const key of ['id', 'sceneId', 'scene_id']) {
      if (typeof card[key] === 'string' && card[key].trim()) cardsById.set(card[key], card)
    }
  }
  const items = (Array.isArray(editPlan?.items) ? editPlan.items : [])
    .filter((item) => record(item) && item.status === 'selected')
    .slice(0, 12)
  return items.map((item, shotIndex) => {
    const candidate = Array.isArray(item.candidates)
      ? item.candidates.find((entry) => entry?.candidate_id === item.selected_candidate_id) ?? {}
      : {}
    const card = cardsById.get(candidate.scene_id)
      ?? cardsById.get(candidate.candidate_id)
      ?? cardsById.get(candidate.asset_id)
      ?? {}
    return {
      shotIndex,
      voiceoverText: sanitizeEvidenceText(item.voiceover_text || item.sentence, 200),
      visualSummary: sanitizeEvidenceText(card.summary || item.visual_summary || item.summary || candidate.summary, 240),
      ocrText: sanitizeEvidenceText(card.ocrText || candidate.ocrText, 200),
      asrSummary: sanitizeEvidenceText(card.asrSummary || candidate.asrSummary, 200),
      shotPurpose: sanitizeEvidenceText(card.shotPurpose || candidate.shotPurpose, 80),
      recommendedUse: sanitizeEvidenceText(card.recommendedUse || candidate.recommendedUse, 160),
      visualTags: (Array.isArray(card.visualTags) ? card.visualTags : [])
        .filter((tag) => typeof tag === 'string' && tag.trim())
        .slice(0, 8),
    }
  })
}

/**
 * @param {Array<Record<string, any>>} segments
 * @param {'effect' | 'sticker'} role
 */
export const createTemplateOverlayInventory = (segments, role) => {
  if (!Array.isArray(segments) || (role !== 'effect' && role !== 'sticker')) return []
  return segments
    .filter((segment) => record(segment) && segment.role === role)
    .map((segment, index) => ({
      overlayId: `${role}:${index}`,
      role,
      decorationKind: segment.decorationKind ?? role,
    }))
}

/**
 * Collapse a learned draft into distinct writable looks.
 * Cadence already dropped overlapping companion cards. Each remaining
 * slotId is one authored material, even when sizes look the same.
 * @param {Array<Record<string, any>>} slots
 */
export const createTemplateStyleInventory = (slots) => {
  if (!Array.isArray(slots)) return []
  const seenIds = new Set()
  /** @type {Array<Record<string, any>>} */
  const inventory = []
  for (const slot of slots) {
    if (!record(slot)) continue
    const styleId = typeof slot.slotId === 'string' && slot.slotId.trim()
      ? slot.slotId
      : null
    if (!styleId || seenIds.has(styleId)) continue
    seenIds.add(styleId)
    inventory.push({
      styleId,
      slotId: styleId,
      decorationKind: slot.decorationKind ?? null,
      styleToken: slot.styleToken ?? null,
      packagingToken: slot.packagingToken ?? null,
      capabilityId: slot.capabilityId ?? 'text.rich',
      authoredDecorationKind: slot.authoredDecorationKind ?? null,
      style: record(slot.style) ? slot.style : null,
      startUs: slot.startUs,
      durationUs: slot.durationUs,
    })
  }
  return inventory
}

const scorePair = (highlight, item) => {
  const intent = classifyHighlightIntent(highlight)
  const role = classifyStyleRole(item)
  return AFFINITY[intent]?.[role] ?? 0
}

const applyValidatedAssignments = (highlights, inventory, assignments) => {
  const byStyleId = new Map(inventory.map((item) => [item.styleId, item]))
  const byText = new Map()
  for (const entry of assignments) {
    if (!record(entry)) continue
    const text = normalizeHighlight(entry.text)
    const styleId = typeof entry.styleId === 'string' ? entry.styleId : ''
    if (!text || !styleId) continue
    if (!byStyleId.has(styleId)) {
      throw new TemplateStyleAssignmentError('TEMPLATE_STYLE_ASSIGNMENT_UNKNOWN')
    }
    byText.set(text, styleId)
  }
  return highlights.map((text) => {
    const styleId = byText.get(text) ??
      [...byText.entries()].find(([key]) => key.startsWith(text) || text.startsWith(key))?.[1]
    if (!styleId) {
      throw new TemplateStyleAssignmentError('TEMPLATE_STYLE_ASSIGNMENT_INCOMPLETE')
    }
    const item = byStyleId.get(styleId)
    return {
      text,
      styleId,
      slotId: item.slotId,
      intent: classifyHighlightIntent(text),
      reason: 'llm_assignment',
      item,
    }
  })
}

const assignByIntent = (highlights, inventory) => {
  const unused = [...inventory]
  return highlights.map((text) => {
    if (unused.length === 0) {
      const item = inventory[0]
      return {
        text,
        styleId: item.styleId,
        slotId: item.slotId,
        intent: classifyHighlightIntent(text),
        reason: 'inventory_reuse',
        item,
      }
    }
    let bestIndex = 0
    let bestScore = Number.NEGATIVE_INFINITY
    for (const [index, item] of unused.entries()) {
      const score = scorePair(text, item)
      if (score > bestScore) {
        bestScore = score
        bestIndex = index
      }
    }
    const [item] = unused.splice(bestIndex, 1)
    return {
      text,
      styleId: item.styleId,
      slotId: item.slotId,
      intent: classifyHighlightIntent(text),
      reason: 'intent_match',
      item,
    }
  })
}

/**
 * @param {{
 *   highlights: string[],
 *   inventory: Array<Record<string, any>>,
 *   assignments?: Array<Record<string, any>> | null,
 * }} input
 */
export const TEMPLATE_PACKAGING_ASSIGNMENT_SYSTEM_PROMPT = withProductLlmCharter([
  'Select only from the uploaded-draft inventory. Do not invent new flowers, effects or stickers.',
  'The draft is a writable inventory, not a sequence. Do not keep draft order.',
  'Read current voiceover, multi-frame visual summary, OCR, ASR and shot purpose.',
  'Assign each highlight a known styleId from inventory only.',
  'Assign an effect only when the current shot evidence needs a listed overlayId; otherwise overlayId=null.',
  'Assign a sticker only when OCR/visual evidence gives an on-screen target and shotIndex is valid.',
  'Skip arrows, boxes and effects that would float on empty pixels.',
  'Never invent styleId or overlayId values. Never emit paths or raw resource ids.',
  'Do not output startUs, durationUs, coordinates or Jianying JSON.',
  'Gateway times each flower to the spoken caption card; you only pick looks.',
].join(' '))

export const TEMPLATE_STYLE_ASSIGNMENT_SCHEMA = Object.freeze({
  name: 'openvideo_template_style_assignment',
  schema: {
    type: 'object',
    properties: {
      assignments: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            text: { type: 'string' },
            styleId: { type: 'string' },
            reason: { type: 'string' },
          },
          required: ['text', 'styleId', 'reason'],
          additionalProperties: false,
        },
      },
      effectAssignments: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            text: { type: 'string' },
            overlayId: { type: ['string', 'null'] },
            reason: { type: 'string' },
          },
          required: ['text', 'overlayId', 'reason'],
          additionalProperties: false,
        },
      },
      stickerAssignments: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            overlayId: { type: 'string' },
            shotIndex: { type: ['integer', 'null'] },
            reason: { type: 'string' },
          },
          required: ['overlayId', 'shotIndex', 'reason'],
          additionalProperties: false,
        },
      },
    },
    required: ['assignments'],
    additionalProperties: false,
  },
})

/**
 * Ask the LLM Gateway to pick inventory looks for current copy.
 * Unknown style ids fail closed and the caller must use intent fallback.
 * @param {{
 *   generate?: Function | null,
 *   highlights: string[],
 *   inventory: Array<Record<string, any>>,
 *   scenes?: Array<Record<string, any>>,
 *   signal?: AbortSignal | null,
 * }} input
 */
const readAssignmentPayload = (result) => {
  if (record(result?.outputJson)) return result.outputJson
  if (record(result) && Array.isArray(result.assignments)) return result
  return null
}

const sanitizeOverlayAssignments = (entries, inventory, { requireText = false, requireShot = false, shotCount = 0 } = {}) => {
  const allowed = new Set((Array.isArray(inventory) ? inventory : [])
    .map((item) => item?.overlayId)
    .filter((id) => typeof id === 'string' && id.trim()))
  if (!Array.isArray(entries)) return []
  const used = new Set()
  const kept = []
  for (const entry of entries) {
    if (!record(entry)) continue
    const overlayId = entry.overlayId === null ? null : typeof entry.overlayId === 'string' ? entry.overlayId : ''
    if (!overlayId || !allowed.has(overlayId) || used.has(overlayId)) continue
    if (requireText) {
      const text = normalizeHighlight(entry.text)
      if (!text) continue
      used.add(overlayId)
      kept.push({
        text,
        overlayId,
        reason: typeof entry.reason === 'string' ? entry.reason.slice(0, 160) : 'llm_assignment',
      })
      continue
    }
    const shotIndex = Number.isSafeInteger(entry.shotIndex) ? entry.shotIndex : null
    if (requireShot && (shotIndex === null || shotIndex < 0 || shotIndex >= shotCount)) continue
    used.add(overlayId)
    kept.push({
      overlayId,
      shotIndex,
      reason: typeof entry.reason === 'string' ? entry.reason.slice(0, 160) : 'llm_assignment',
    })
  }
  return kept
}

/**
 * Ask the LLM Gateway to allocate current copy, effects and stickers from
 * analyzed shot evidence. Effects/stickers without a real target are omitted.
 * @param {{
 *   generate?: Function | null,
 *   highlights: string[],
 *   inventory: Array<Record<string, any>>,
 *   effects?: Array<Record<string, any>>,
 *   stickers?: Array<Record<string, any>>,
 *   scenes?: Array<Record<string, any>>,
 *   signal?: AbortSignal | null,
 * }} input
 */
export const completeTemplatePackagingAssignments = async ({
  generate = null,
  highlights,
  inventory,
  effects = [],
  stickers = [],
  scenes = [],
  signal = null,
}) => {
  if (typeof generate !== 'function') return null
  const copy = (Array.isArray(highlights) ? highlights : []).map(normalizeHighlight).filter(Boolean)
  const pool = Array.isArray(inventory) ? inventory.filter((item) => record(item) && item.styleId) : []
  if (copy.length === 0 || pool.length === 0) return null
  const effectPool = Array.isArray(effects) ? effects.filter((item) => record(item) && item.overlayId) : []
  const stickerPool = Array.isArray(stickers) ? stickers.filter((item) => record(item) && item.overlayId) : []
  const shotScenes = Array.isArray(scenes) ? scenes.slice(0, 12) : []
  try {
    const result = await generate({
      capability: 'json',
      messages: [
        {
          role: 'system',
          parts: [{
            type: 'text',
            text: TEMPLATE_PACKAGING_ASSIGNMENT_SYSTEM_PROMPT,
          }],
        },
        {
          role: 'user',
          parts: [{
            type: 'text',
            text: JSON.stringify({
              highlights: copy,
              inventory: pool.map((item) => ({
                styleId: item.styleId,
                decorationKind: item.decorationKind,
                styleRole: classifyStyleRole(item),
                size: item.style?.size ?? null,
              })),
              effects: effectPool.map((item) => ({ overlayId: item.overlayId })),
              stickers: stickerPool.map((item) => ({ overlayId: item.overlayId })),
              scenes: shotScenes,
            }),
          }],
        },
      ],
      jsonSchema: TEMPLATE_STYLE_ASSIGNMENT_SCHEMA,
    }, { signal })
    const payload = readAssignmentPayload(result)
    const assignments = Array.isArray(payload?.assignments) ? payload.assignments : null
    if (!Array.isArray(assignments) || assignments.length === 0) return null
    const styleAssignments = assignTemplateStyleInventory({ highlights: copy, inventory: pool, assignments })
    return {
      styleAssignments: assignments,
      effectAssignments: sanitizeOverlayAssignments(payload.effectAssignments, effectPool, { requireText: true }),
      stickerAssignments: sanitizeOverlayAssignments(payload.stickerAssignments, stickerPool, {
        requireShot: true,
        shotCount: shotScenes.length,
      }),
      resolvedStyles: styleAssignments,
    }
  } catch {
    return null
  }
}

export const completeTemplateStyleAssignments = async (input) => {
  const plan = await completeTemplatePackagingAssignments(input)
  return plan ? plan.styleAssignments : null
}

/**
 * Pick one unused inventory look for current copy. Draft ordinal is never the key.
 * @param {{
 *   seed: string,
 *   unused: Array<Record<string, any>>,
 *   fallbackPool?: Array<Record<string, any>>,
 * }} input
 */
export const pickUnusedInventoryLook = ({ seed, unused, fallbackPool = [] }) => {
  const pool = Array.isArray(unused) ? unused : []
  const fallback = Array.isArray(fallbackPool) && fallbackPool.length > 0 ? fallbackPool : pool
  if (pool.length === 0) return fallback[0] ?? null
  const text = normalizeHighlight(seed)
  let bestIndex = 0
  let bestScore = Number.NEGATIVE_INFINITY
  for (const [index, item] of pool.entries()) {
    const score = scorePair(text, item)
    if (score > bestScore) {
      bestScore = score
      bestIndex = index
    }
  }
  const [item] = pool.splice(bestIndex, 1)
  return item
}

export const assignTemplateStyleInventory = ({ highlights, inventory, assignments = null }) => {
  const copy = (Array.isArray(highlights) ? highlights : [])
    .map(normalizeHighlight)
    .filter(Boolean)
  const pool = Array.isArray(inventory) ? inventory.filter((item) => record(item) && item.styleId) : []
  if (copy.length === 0 || pool.length === 0) return []
  if (Array.isArray(assignments) && assignments.length > 0) {
    try {
      return applyValidatedAssignments(copy, pool, assignments)
    } catch (error) {
      if (error instanceof TemplateStyleAssignmentError && error.code === 'TEMPLATE_STYLE_ASSIGNMENT_INCOMPLETE') {
        return assignByIntent(copy, pool)
      }
      throw error
    }
  }
  return assignByIntent(copy, pool)
}
