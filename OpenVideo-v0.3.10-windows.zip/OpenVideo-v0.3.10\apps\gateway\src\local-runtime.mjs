import { execFile, spawn } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { tmpdir } from 'node:os'
import {
  chmodSync,
  closeSync,
  copyFileSync,
  existsSync,
  fsyncSync,
  mkdirSync,
  openSync,
  readFileSync,
  realpathSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs'
import { chmod, copyFile, lstat, mkdir, open, opendir, readFile, readdir, rename, rm, stat, unlink, writeFile } from 'node:fs/promises'
import { basename, dirname, extname, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'

import {
  isVoiceId,
  normalizeBrief,
  normalizePackaging,
  validBriefExtensions,
  validPackaging,
} from './brief-packaging.mjs'
import { isProjectTemplateBinding } from './reusable-template-contracts.mjs'

const execFileAsync = promisify(execFile)
const schemaVersion = 1
const audioExtensions = new Set(['.aac', '.flac', '.m4a', '.mp3', '.wav'])
const videoExtensions = new Set(['.avi', '.m4v', '.mkv', '.mov', '.mp4', '.webm', '.wmv'])
const referenceUploadMaxBytes = 512 * 1024 * 1024
const referenceUploadQuotaBytes = 2 * 1024 * 1024 * 1024
const defaultRepositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const windowsAclInspectionTimeoutMs = 10_000
const windowsAclMutationTimeoutMs = 120_000

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} error @returns {string | number | undefined} */
const errorCode = (error) =>
  error && typeof error === 'object' && 'code' in error
    ? /** @type {{code?: string | number}} */ (error).code
    : undefined

export class LocalRuntimeError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'LocalRuntimeError'
    this.code = code
    this.status = status
  }
}

/** @param {string} candidate */
const canonicalizePotentialPath = (candidate) => {
  let existingAncestor = resolve(candidate)
  /** @type {string[]} */
  const missingSegments = []
  while (!existsSync(existingAncestor)) {
    const parent = dirname(existingAncestor)
    if (parent === existingAncestor) break
    missingSegments.unshift(basename(existingAncestor))
    existingAncestor = parent
  }
  const canonicalAncestor = existsSync(existingAncestor)
    ? realpathSync.native(existingAncestor)
    : existingAncestor
  return resolve(canonicalAncestor, ...missingSegments)
}

/** @param {string} parent @param {string} candidate */
const isInside = (parent, candidate) => {
  const child = relative(canonicalizePotentialPath(parent), canonicalizePotentialPath(candidate))
  return child === '' || (!child.startsWith('..') && !isAbsolute(child))
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? resolve(left).toLowerCase() === resolve(right).toLowerCase()
  : resolve(left) === resolve(right)

/** @param {import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * Windows realpath may expand an 8.3 alias. A different spelling is safe only
 * when it still names the exact non-reparse filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (requestedMetadata.isSymbolicLink()) return false
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && !actualMetadata.isSymbolicLink() &&
    objectIdentity(requestedMetadata) === objectIdentity(actualMetadata)
}

/**
 * @param {NodeJS.ProcessEnv | Record<string, string | undefined>} [environment]
 * @param {{repositoryRoot?: string}} [options]
 */
export const loadLocalRuntimeConfig = (
  environment = process.env,
  { repositoryRoot = defaultRepositoryRoot } = {},
) => {
  const configuredRoot = environment.OPENVIDEO_RUNTIME_DATA_ROOT?.trim()
  if (!configuredRoot || !isAbsolute(configuredRoot)) {
    throw new LocalRuntimeError('LOCAL_RUNTIME_DATA_ROOT_REQUIRED', 500)
  }
  const dataRoot = canonicalizePotentialPath(configuredRoot)
  if (isInside(repositoryRoot, dataRoot)) {
    throw new LocalRuntimeError('LOCAL_RUNTIME_DATA_ROOT_UNSAFE', 500)
  }
  return { mode: 'production', dataRoot }
}

/** @param {unknown} value @returns {boolean} */
const hasPrivatePathInPublicRecord = (value) => {
  if (typeof value === 'string') {
    const startsWithDrivePath =
      /^[a-z]:/iu.test(value) && [47, 92].includes(value.charCodeAt(2))
    const startsWithUncPath = value.charCodeAt(0) === 92 && value.charCodeAt(1) === 92
    return startsWithDrivePath ||
      startsWithUncPath ||
      /(?:file:\/\/|\/(?:home|users|private|var|tmp|mnt|volumes)\/)/iu.test(value)
  }
  if (Array.isArray(value)) return value.some(hasPrivatePathInPublicRecord)
  if (!value || typeof value !== 'object') return false
  return Object.values(value).some(hasPrivatePathInPublicRecord)
}
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const isNonNegativeInteger = (value) => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0
/** @param {unknown} value */
const isTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @param {unknown} value @param {number} [max] */
const isText = (value, max = 12_000) => typeof value === 'string' && value.length <= max && !value.includes('\u0000')
/** @param {unknown} value @param {number} [max] */
const isOptionalLabel = (value, max = 160) => value === null || (typeof value === 'string' && safeLabel(value, max))

/** @param {unknown} value */
const validMaterialScene = (value) =>
  isRecord(value) &&
  typeof value.id === 'string' &&
  safeLabel(value.id, 160) &&
  typeof value.start === 'number' &&
  Number.isFinite(value.start) &&
  value.start >= 0 &&
  typeof value.end === 'number' &&
  Number.isFinite(value.end) &&
  value.end > value.start &&
  isText(value.summary, 500)

/** @param {unknown} value */
const validMaterialAsset = (value) =>
  isRecord(value) &&
  typeof value.id === 'string' &&
  safeLabel(value.id, 160) &&
  typeof value.label === 'string' &&
  safeLabel(value.label, 160) &&
  ['ready', 'analyzing', 'queued', 'failed'].includes(value.status) &&
  isNonNegativeInteger(value.analyzedPercent) &&
  value.analyzedPercent <= 100 &&
  typeof value.durationSeconds === 'number' &&
  value.durationSeconds >= 0 &&
  isNonNegativeInteger(value.sceneCount) &&
  (
    value.scenes === undefined ||
    (
      Array.isArray(value.scenes) &&
      value.scenes.length === value.sceneCount &&
      value.scenes.every(validMaterialScene)
    )
  )

/** @param {unknown} value */
const validMaterialAnalysisProgress = (value) =>
  value === undefined ||
  value === null ||
  (isRecord(value) &&
    isNonNegativeInteger(value.overallPercent) &&
    value.overallPercent <= 100 &&
    Array.isArray(value.assets) &&
    value.assets.length <= 10_000 &&
    value.assets.every((asset) =>
      isRecord(asset) &&
      typeof asset.id === 'string' && safeLabel(asset.id, 160) &&
      typeof asset.label === 'string' && safeLabel(asset.label, 160) &&
      ['queued', 'analyzing', 'ready', 'failed'].includes(asset.status) &&
      isNonNegativeInteger(asset.progressPercent) && asset.progressPercent <= 100 &&
      ['queued', 'metadata', 'scenes', 'asr', 'visual', 'indexing', 'complete', 'failed'].includes(asset.stage) &&
      isText(asset.detail, 160) && asset.detail.length > 0 &&
      !hasPrivatePathInPublicRecord(asset.detail)))

/** @param {unknown} value */
const validCandidate = (value) =>
  isRecord(value) &&
  typeof value.id === 'string' &&
  safeLabel(value.id, 160) &&
  typeof value.assetLabel === 'string' &&
  safeLabel(value.assetLabel, 160) &&
  typeof value.start === 'number' &&
  value.start >= 0 &&
  typeof value.end === 'number' &&
  value.end > value.start &&
  isText(value.summary, 1000) &&
  typeof value.matchScore === 'number' &&
  value.matchScore >= 0 &&
  value.matchScore <= 1 &&
  isText(value.reason, 1000)

/** @param {unknown} value */
const validSentence = (value) =>
  isRecord(value) &&
  typeof value.id === 'string' &&
  safeLabel(value.id, 160) &&
  Number.isSafeInteger(value.order) &&
  value.order > 0 &&
  isText(value.text, 8000) &&
  ['selected', 'needs_review', 'needs_capture'].includes(value.status) &&
  isOptionalLabel(value.selectedCandidateId) &&
  Array.isArray(value.candidates) &&
  value.candidates.every(validCandidate)

/** @param {unknown} value */
const validStoryboard = (value) => {
  if (value === null) return true
  if (
    !isRecord(value) ||
    typeof value.id !== 'string' ||
    !safeLabel(value.id, 160) ||
    typeof value.title !== 'string' ||
    !safeLabel(value.title, 160) ||
    !isTimestamp(value.updatedAt) ||
    !Array.isArray(value.sentences) ||
    !value.sentences.every(validSentence)
  ) return false
  const sentenceIds = new Set()
  for (const sentence of value.sentences) {
    if (sentenceIds.has(sentence.id)) return false
    sentenceIds.add(sentence.id)
    if (
      sentence.selectedCandidateId !== null &&
      !sentence.candidates.some(
        (/** @type {Record<string, any>} */ candidate) =>
          candidate.id === sentence.selectedCandidateId,
      )
    ) return false
  }
  return true
}

/** @param {unknown} value */
const validRecoveryOption = (value) =>
  isRecord(value) &&
  typeof value.code === 'string' &&
  safeLabel(value.code, 160) &&
  isText(value.title, 300) &&
  isText(value.action, 300) &&
  typeof value.stage === 'string' &&
  safeLabel(value.stage, 100) &&
  typeof value.recoverable === 'boolean'

/** @param {unknown} value */
const validTemplate = (value) =>
  isRecord(value) &&
  ['not_started', 'confirmed'].includes(value.status) &&
  isOptionalLabel(value.name) &&
  isOptionalLabel(value.version) &&
  (value.reason === null || isText(value.reason, 1000))

/** @param {unknown} value */
const validPreflight = (value) =>
  isRecord(value) &&
  ['not_started', 'ready', 'failed'].includes(value.status) &&
  (value.checkedAt === null || isTimestamp(value.checkedAt)) &&
  Array.isArray(value.checks) &&
  value.checks.every(
    (check) =>
      isRecord(check) &&
      typeof check.label === 'string' &&
      safeLabel(check.label, 160) &&
      ['pass', 'fail'].includes(check.status),
  )

/** @param {unknown} value */
const validExportJob = (value) =>
  value === null ||
  (isRecord(value) &&
    typeof value.id === 'string' &&
    safeLabel(value.id, 160) &&
    ['preflight', 'resolving_materials', 'building_draft', 'verifying_output', 'ready_to_open', 'failed', 'cancelled'].includes(value.state) &&
    isNonNegativeInteger(value.progressPercent) &&
    value.progressPercent <= 100 &&
    typeof value.recoverable === 'boolean' &&
    (value.error === null || validRecoveryOption(value.error)) &&
    (value.result === null ||
      (isRecord(value.result) &&
        typeof value.result.draftLabel === 'string' &&
        safeLabel(value.result.draftLabel, 200) &&
        typeof value.result.outputFingerprint === 'string' &&
        safeLabel(value.result.outputFingerprint, 200))))

/** @param {unknown} value */
const validFinalVideo = (value) =>
  value === undefined ||
  value === null ||
  (isRecord(value) &&
    value.status === 'ready' &&
    typeof value.resourceId === 'string' &&
    safeLabel(value.resourceId, 160) &&
    typeof value.durationSeconds === 'number' &&
    Number.isFinite(value.durationSeconds) &&
    value.durationSeconds > 0 &&
    isTimestamp(value.updatedAt))

/** @param {unknown} brief */
const validBriefRecord = (brief) => {
  if (!isRecord(brief)) return false
  const normalizedBrief = normalizeBrief(brief)
  const normalizedPackaging = normalizePackaging(normalizedBrief.packaging)
  return (
    isText(normalizedBrief.theme, 300) &&
    isText(normalizedBrief.title, 160) &&
    Array.isArray(normalizedBrief.sellingPoints) &&
    normalizedBrief.sellingPoints.every((point) => isText(point, 160)) &&
    isText(normalizedBrief.script, 8000) &&
    isText(normalizedBrief.style, 800) &&
    Number.isInteger(normalizedBrief.durationSeconds) &&
    ['portrait', 'landscape', 'square'].includes(normalizedBrief.orientation) &&
    ['none', 'required'].includes(normalizedBrief.voiceover) &&
    ['none', 'auto'].includes(normalizedBrief.captions) &&
    (normalizedBrief.savedAt === null || isTimestamp(normalizedBrief.savedAt)) &&
    (normalizedBrief.voiceId === null || isVoiceId(normalizedBrief.voiceId)) &&
    validPackaging(normalizedPackaging) &&
    validBriefExtensions({ ...normalizedBrief, packaging: normalizedPackaging })
  )
}

/** @param {unknown} record */
const validProjectRecord = (record) => {
  if (!isRecord(record)) return false
  const value = record
  const materials = value.materials
  const brief = value.brief
  const preview = value.preview
  const delivery = value.delivery
  return (
    typeof value.id === 'string' &&
    safeLabel(value.id, 160) &&
    typeof value.name === 'string' &&
    safeLabel(value.name, 100) &&
    typeof value.notes === 'string' &&
    ['active', 'completed'].includes(value.status) &&
    ['materials', 'brief', 'storyboard', 'preview', 'delivery'].includes(value.currentStage) &&
    (value.createdAt === undefined || isTimestamp(value.createdAt)) &&
    isTimestamp(value.updatedAt) &&
    isRecord(materials) &&
    (materials.authorizationId === null || (typeof materials.authorizationId === 'string' && safeLabel(materials.authorizationId, 160))) &&
    typeof materials.authorized === 'boolean' &&
    typeof materials.readOnlyConfirmed === 'boolean' &&
    (materials.folderLabel === null || (typeof materials.folderLabel === 'string' && safeLabel(materials.folderLabel, 100))) &&
    isNonNegativeInteger(materials.total) &&
    isNonNegativeInteger(materials.analyzed) &&
    isNonNegativeInteger(materials.queued) &&
    isNonNegativeInteger(materials.failed) &&
    typeof materials.analysisStatus === 'string' &&
    validMaterialAnalysisProgress(materials.analysisProgress) &&
    (materials.lastScanAt === null || isTimestamp(materials.lastScanAt)) &&
    Array.isArray(materials.assets) &&
    materials.assets.every(validMaterialAsset) &&
    validBriefRecord(brief) &&
    (value.templateBinding === undefined ||
      value.templateBinding === null ||
      isProjectTemplateBinding(value.templateBinding)) &&
    (value.pendingOutputInvalidation === undefined ||
      value.pendingOutputInvalidation === null ||
      (
        isRecord(value.pendingOutputInvalidation) &&
        Array.isArray(value.pendingOutputInvalidation.resourceIds) &&
        value.pendingOutputInvalidation.resourceIds.every(
          (resourceId) => typeof resourceId === 'string' && safeLabel(resourceId, 160),
        ) &&
        typeof value.pendingOutputInvalidation.jobsPending === 'boolean' &&
        isTimestamp(value.pendingOutputInvalidation.createdAt)
      )) &&
    (value.pendingProjectDeletion === undefined ||
      value.pendingProjectDeletion === null ||
      (
        isRecord(value.pendingProjectDeletion) &&
        Array.isArray(value.pendingProjectDeletion.resourceIds) &&
        value.pendingProjectDeletion.resourceIds.every(
          (resourceId) => typeof resourceId === 'string' && safeLabel(resourceId, 160),
        ) &&
        typeof value.pendingProjectDeletion.jobsPending === 'boolean' &&
        typeof value.pendingProjectDeletion.projectDataPending === 'boolean' &&
        typeof value.pendingProjectDeletion.referenceTemplatesPending === 'boolean' &&
        isTimestamp(value.pendingProjectDeletion.expectedUpdatedAt) &&
        isTimestamp(value.pendingProjectDeletion.createdAt)
      )) &&
    validStoryboard(value.storyboard) &&
    isRecord(preview) &&
    ['not_started', 'queued', 'ready', 'failed'].includes(preview.status) &&
    (preview.resourceId === null || (typeof preview.resourceId === 'string' && safeLabel(preview.resourceId, 160))) &&
    (preview.durationSeconds === null || (typeof preview.durationSeconds === 'number' && preview.durationSeconds >= 0)) &&
    (preview.updatedAt === null || isTimestamp(preview.updatedAt)) &&
    isRecord(delivery) &&
    validFinalVideo(delivery.finalVideo) &&
    validTemplate(delivery.template) &&
    validPreflight(delivery.preflight) &&
    validExportJob(delivery.exportJob) &&
    Array.isArray(delivery.recoveryOptions) &&
    delivery.recoveryOptions.every(validRecoveryOption) &&
    !hasPrivatePathInPublicRecord(value)
  )
}

/** @param {unknown} record */
const validAuthorizationRecord = (record) => {
  if (!record || typeof record !== 'object') return false
  const value = /** @type {Record<string, any>} */ (record)
  return (
    typeof value.id === 'string' &&
    safeLabel(value.id, 160) &&
    typeof value.projectId === 'string' &&
    safeLabel(value.projectId, 160) &&
    typeof value.absolutePath === 'string' &&
    isAbsolute(value.absolutePath) &&
    typeof value.label === 'string' &&
    safeLabel(value.label, 100) &&
    ['authorized', 'orphaned'].includes(value.status) &&
    isNonNegativeInteger(value.total) &&
    value.readOnly === true &&
    (value.purpose === undefined || ['bgm', 'voice_reference', 'reusable_template_draft', 'jianying_draft', 'jianying_draft_root'].includes(value.purpose)) &&
    (value.selectedFileName === undefined || (typeof value.selectedFileName === 'string' && safeLabel(value.selectedFileName, 260))) &&
    (value.selectedFileNames === undefined || (
      Array.isArray(value.selectedFileNames) &&
      value.selectedFileNames.length > 0 &&
      value.selectedFileNames.every((/** @type {unknown} */ name) => typeof name === 'string' && safeLabel(name, 260))
    )) &&
    isTimestamp(value.createdAt)
  )
}

/** @param {unknown} record */
const validTaskRecord = (record) => {
  if (!record || typeof record !== 'object') return false
  const value = /** @type {Record<string, any>} */ (record)
  return (
    typeof value.id === 'string' &&
    safeLabel(value.id, 160) &&
    typeof value.projectId === 'string' &&
    safeLabel(value.projectId, 160) &&
    isNonNegativeInteger(value.position) &&
    typeof value.type === 'string' &&
    safeLabel(value.type, 100) &&
    typeof value.label === 'string' &&
    safeLabel(value.label, 160) &&
    typeof value.state === 'string' &&
    ['running', 'completed', 'failed', 'cancelled', 'ready_to_open'].includes(value.state) &&
    isNonNegativeInteger(value.progressPercent) &&
    value.progressPercent <= 100 &&
    typeof value.detail === 'string' &&
    (value.error === null || validRecoveryOption(value.error)) &&
    !hasPrivatePathInPublicRecord(value)
  )
}

/** @param {string} filePath @param {(record: unknown) => boolean} validateRecord */
const readDocument = async (filePath, validateRecord) => {
  const parsed = JSON.parse(await readFile(filePath, 'utf8'))
  if (
    !parsed ||
    parsed.schema_version !== schemaVersion ||
    !Array.isArray(parsed.records) ||
    !parsed.records.every(validateRecord)
  ) {
    throw new Error('invalid_document')
  }
  return parsed
}

/** @param {string} filePath @param {{schema_version: number, records: unknown[]}} document @param {{preservePrimaryAsBackup?: boolean}} [options] */
const writeDocument = async (filePath, document, { preservePrimaryAsBackup = true } = {}) => {
  const temporaryPath = `${filePath}.${randomUUID()}.tmp`
  const backupPath = `${filePath}.bak`
  const serialized = `${JSON.stringify(document, null, 2)}\n`
  await mkdir(dirname(filePath), { recursive: true, mode: 0o700 })
  const handle = await open(temporaryPath, 'wx', 0o600)
  try {
    await handle.writeFile(serialized, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  if (preservePrimaryAsBackup) {
    try {
      await copyFile(filePath, backupPath)
      await chmod(backupPath, 0o600).catch(() => {})
    } catch (error) {
      if (errorCode(error) !== 'ENOENT') {
        await unlink(temporaryPath).catch(() => {})
        throw error
      }
    }
  }
  await rename(temporaryPath, filePath)
  await chmod(filePath, 0o600).catch(() => {})
}

/** @param {string} filePath @param {{schema_version: number, records: unknown[]}} document */
const writeDocumentSync = (filePath, document) => {
  const temporaryPath = `${filePath}.${randomUUID()}.tmp`
  const backupPath = `${filePath}.bak`
  mkdirSync(dirname(filePath), { recursive: true, mode: 0o700 })
  const descriptor = openSync(temporaryPath, 'wx', 0o600)
  try {
    writeFileSync(descriptor, `${JSON.stringify(document, null, 2)}\n`, 'utf8')
    fsyncSync(descriptor)
  } finally {
    closeSync(descriptor)
  }
  try {
    copyFileSync(filePath, backupPath)
    try { chmodSync(backupPath, 0o600) } catch {}
  } catch (error) {
    if (errorCode(error) !== 'ENOENT') {
      try { unlinkSync(temporaryPath) } catch {}
      throw error
    }
  }
  renameSync(temporaryPath, filePath)
  try { chmodSync(filePath, 0o600) } catch {}
}

/** @param {string} filePath @param {(record: unknown) => boolean} validateRecord */
const readDocumentSync = (filePath, validateRecord) => {
  const parsed = JSON.parse(readFileSync(filePath, 'utf8'))
  if (
    !parsed ||
    parsed.schema_version !== schemaVersion ||
    !Array.isArray(parsed.records) ||
    !parsed.records.every(validateRecord)
  ) {
    throw new Error('invalid_document')
  }
  return parsed
}

const syncWaitBuffer = new Int32Array(new SharedArrayBuffer(4))

/** @param {string} lockPath */
const acquireDocumentLockSync = (lockPath) => {
  const owner = `${JSON.stringify({ token: randomUUID(), pid: process.pid })}\n`
  for (let attempt = 0; attempt < 500; attempt += 1) {
    let descriptor = null
    try {
      descriptor = openSync(lockPath, 'wx', 0o600)
      writeFileSync(descriptor, owner, 'utf8')
      fsyncSync(descriptor)
      closeSync(descriptor)
      return owner
    } catch (error) {
      if (descriptor !== null) {
        try { closeSync(descriptor) } catch {}
        try { unlinkSync(lockPath) } catch {}
      }
      if (errorCode(error) !== 'EEXIST') throw error
      let existingOwner = null
      let metadata = null
      try {
        existingOwner = readFileSync(lockPath, 'utf8')
        metadata = statSync(lockPath)
      } catch {}
      let validOwner = false
      let processAlive = true
      try {
        const parsed = JSON.parse(existingOwner ?? '')
        if (
          !Number.isSafeInteger(parsed?.pid) ||
          parsed.pid < 1 ||
          typeof parsed.token !== 'string' ||
          parsed.token.length === 0
        ) throw new Error('invalid_lock')
        validOwner = true
        process.kill(parsed.pid, 0)
      } catch (ownerError) {
        processAlive = errorCode(ownerError) !== 'ESRCH'
      }
      if (
        existingOwner !== null &&
        metadata &&
        Date.now() - metadata.mtimeMs > 5 * 60_000 &&
        (!validOwner || !processAlive)
      ) {
        try {
          if (readFileSync(lockPath, 'utf8') === existingOwner) {
            unlinkSync(lockPath)
            continue
          }
        } catch {}
      }
      Atomics.wait(syncWaitBuffer, 0, 0, 10)
    }
  }
  throw new LocalRuntimeError('LOCAL_RUNTIME_STORAGE_LOCKED', 503)
}

/** @param {string} lockPath @param {string} owner */
const releaseDocumentLockSync = (lockPath, owner) => {
  try {
    if (readFileSync(lockPath, 'utf8') === owner) unlinkSync(lockPath)
  } catch {}
}

/** @param {string} filePath @param {(record: unknown) => boolean} validateRecord */
const loadOrCreateDocument = async (filePath, validateRecord) => {
  try {
    return await readDocument(filePath, validateRecord)
  } catch {
    // Recovery and initialization must recheck the document inside the lock.
  }
  const lockPath = `${filePath}.lock`
  const owner = acquireDocumentLockSync(lockPath)
  try {
    try {
      return await readDocument(filePath, validateRecord)
    } catch (primaryError) {
      try {
        const backup = await readDocument(`${filePath}.bak`, validateRecord)
        await writeDocument(filePath, backup, { preservePrimaryAsBackup: false })
        return backup
      } catch (backupError) {
        if (errorCode(primaryError) !== 'ENOENT' || errorCode(backupError) !== 'ENOENT') {
          throw new LocalRuntimeError('LOCAL_RUNTIME_STORAGE_CORRUPT', 500)
        }
        const empty = { schema_version: schemaVersion, records: [] }
        await writeDocument(filePath, empty)
        return empty
      }
    }
  } finally {
    releaseDocumentLockSync(lockPath, owner)
  }
}

/** @param {string} filePath @param {(record: unknown) => boolean} validateRecord */
const createJsonRepository = async (filePath, validateRecord) => {
  await loadOrCreateDocument(filePath, validateRecord)
  const readLatest = () => {
    try {
      return /** @type {{schema_version: number, records: Record<string, any>[]}} */ (
        readDocumentSync(filePath, validateRecord)
      )
    } catch {
      throw new LocalRuntimeError('LOCAL_RUNTIME_STORAGE_CORRUPT', 500)
    }
  }
  return {
    /** @param {string} id */
    get(id) {
      const record = readLatest().records.find((/** @type {Record<string, any>} */ entry) => entry?.id === id)
      return record ? clone(record) : null
    },
    list() {
      return clone(readLatest().records)
    },
    /** @param {Record<string, any>} record */
    save(record) {
      if (!validateRecord(record)) {
        throw new LocalRuntimeError('LOCAL_RUNTIME_RECORD_INVALID', 500)
      }
      const lockPath = `${filePath}.lock`
      const owner = acquireDocumentLockSync(lockPath)
      try {
        const nextDocument = clone(readLatest())
        const index = nextDocument.records.findIndex((/** @type {Record<string, any>} */ entry) => entry?.id === record.id)
        if (index === -1) nextDocument.records.push(clone(record))
        else nextDocument.records[index] = clone(record)
        writeDocumentSync(filePath, nextDocument)
        return clone(record)
      } finally {
        releaseDocumentLockSync(lockPath, owner)
      }
    },
    /**
     * Atomically saves only when the persisted record still exactly matches
     * the caller's previously read snapshot.
     * @param {Record<string, any>} record
     * @param {Record<string, any>} expected
     */
    saveIfCurrent(record, expected) {
      if (!validateRecord(record) || !validateRecord(expected) || record.id !== expected.id) {
        throw new LocalRuntimeError('LOCAL_RUNTIME_RECORD_INVALID', 500)
      }
      const lockPath = `${filePath}.lock`
      const owner = acquireDocumentLockSync(lockPath)
      try {
        const nextDocument = clone(readLatest())
        const index = nextDocument.records.findIndex(
          (/** @type {Record<string, any>} */ entry) => entry?.id === record.id,
        )
        const current = index === -1 ? null : nextDocument.records[index]
        if (
          !current ||
          current.updatedAt !== expected.updatedAt ||
          JSON.stringify(current.templateBinding ?? null) !==
            JSON.stringify(expected.templateBinding ?? null)
        ) return null
        nextDocument.records[index] = clone(record)
        writeDocumentSync(filePath, nextDocument)
        return clone(record)
      } finally {
        releaseDocumentLockSync(lockPath, owner)
      }
    },
    /** @param {string} id */
    remove(id) {
      const lockPath = `${filePath}.lock`
      const owner = acquireDocumentLockSync(lockPath)
      try {
        const nextDocument = clone(readLatest())
        nextDocument.records = nextDocument.records.filter(
          (/** @type {Record<string, any>} */ entry) => entry?.id !== id,
        )
        writeDocumentSync(filePath, nextDocument)
      } finally {
        releaseDocumentLockSync(lockPath, owner)
      }
    },
  }
}

const readAclScript = `
$ErrorActionPreference = 'Stop'
$acl = Get-Acl -LiteralPath $env:OPENVIDEO_ACL_ROOT
$rules = $acl.GetAccessRules(
  $true,
  $true,
  [System.Security.Principal.SecurityIdentifier]
)
@($rules | ForEach-Object {
  $_.IdentityReference.Value
}) | Sort-Object -Unique | ConvertTo-Json -Compress
`.trim()

const readOwnerScript = `
$ErrorActionPreference = 'Stop'
$acl = Get-Acl -LiteralPath $env:OPENVIDEO_ACL_ROOT
$acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value
`.trim()

/** @param {Record<string, string>} extra */
const windowsPowerShellEnvironment = (extra) => Object.fromEntries([
  ...Object.entries(process.env)
    .filter(([key, value]) => key.toLowerCase() !== 'psmodulepath' && typeof value === 'string'),
  ...Object.entries(extra),
])

// PROD-HOTFIX-006: the SID lookup, the ACL walk and the two read-backs used to be four separate
// powershell.exe calls. On this platform a bare `powershell.exe -NoProfile` costs ~1.6s to start
// regardless of what it runs, so those four spawns cost ~6.6s while the ACL walk itself measured
// ~0.4s on a 927-entry tree: the launch was paying startup, not work. The steps below run in one
// process in the same order, and the verification still reads the ACL back from disk after the
// write rather than reporting what the writer intended.
const securePrivateRootScript = `
$ErrorActionPreference = 'Stop'
$root = $env:OPENVIDEO_ACL_ROOT
$userSid = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
if ($userSid -notmatch '^S-\\d(-\\d+)+$') { throw 'invalid_sid' }
$allowedSids = @($userSid, 'S-1-5-18', 'S-1-5-32-544')
$freshlyClaimed = $env:OPENVIDEO_ACL_FRESHLY_CLAIMED -eq '1'
function Set-PrivateAcl([string]$target, [bool]$isDirectory) {
  try {
    $currentAcl = Get-Acl -LiteralPath $target
  } catch {
    # Race: material-analysis temp paths can vanish while the tree is scanned.
    if (-not [System.IO.File]::Exists($target) -and -not [System.IO.Directory]::Exists($target)) { return }
    throw
  }
  $currentRules = @($currentAcl.GetAccessRules(
    $true,
    $true,
    [System.Security.Principal.SecurityIdentifier]
  ))
  $currentOwnerSid = $currentAcl.GetOwner(
    [System.Security.Principal.SecurityIdentifier]
  ).Value
  $alreadyPrivate = $currentAcl.AreAccessRulesProtected -and
    $currentOwnerSid -eq $userSid -and
    $currentRules.Count -eq $allowedSids.Count -and
    @($currentRules | Where-Object {
      $_.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow -or
      $_.IsInherited -or
      ($_.FileSystemRights -band [System.Security.AccessControl.FileSystemRights]::FullControl) -ne
        [System.Security.AccessControl.FileSystemRights]::FullControl -or
      $allowedSids -notcontains $_.IdentityReference.Value
    }).Count -eq 0
  if ($alreadyPrivate) {
    return
  }
  # Runtime roots are claimed only from an empty/current-user-owned tree. A
  # newly created directory may inherit Administrators as owner on an elevated
  # Windows runner; only that fresh claim may be narrowed to the current user.
  $canClaimAdministratorOwner = $freshlyClaimed -and $currentOwnerSid -eq 'S-1-5-32-544'
  if ($currentOwnerSid -ne $userSid -and -not $canClaimAdministratorOwner) { throw 'unexpected_owner' }
  if ($isDirectory) {
    $acl = New-Object System.Security.AccessControl.DirectorySecurity
  } else {
    $acl = New-Object System.Security.AccessControl.FileSecurity
  }
  $accessSection = [System.Security.AccessControl.AccessControlSections]::Access
  $acl.SetSecurityDescriptorSddlForm(
    $currentAcl.GetSecurityDescriptorSddlForm($accessSection),
    $accessSection
  )
  $acl.SetAccessRuleProtection($true, $false)
  foreach ($identity in @($currentRules | ForEach-Object { $_.IdentityReference } | Select-Object -Unique)) {
    $acl.PurgeAccessRules($identity)
  }
  if ($isDirectory) {
    $inheritance = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
  } else {
    $inheritance = [System.Security.AccessControl.InheritanceFlags]::None
  }
  foreach ($sidText in $allowedSids) {
    $sid = New-Object System.Security.Principal.SecurityIdentifier($sidText)
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
      $sid,
      [System.Security.AccessControl.FileSystemRights]::FullControl,
      $inheritance,
      [System.Security.AccessControl.PropagationFlags]::None,
      [System.Security.AccessControl.AccessControlType]::Allow
    )
    [void]$acl.AddAccessRule($rule)
  }
  if ($canClaimAdministratorOwner) {
    $acl.SetOwner((New-Object System.Security.Principal.SecurityIdentifier($userSid)))
  }
  try {
    (Get-Item -LiteralPath $target -Force).SetAccessControl($acl)
  } catch {
    if (-not [System.IO.File]::Exists($target) -and -not [System.IO.Directory]::Exists($target)) { return }
    throw
  }
}
Set-PrivateAcl $root $true

# Read the applied state back from disk so Node verifies observed rights, not intended ones.
$appliedAcl = Get-Acl -LiteralPath $root
$appliedSids = @($appliedAcl.GetAccessRules(
  $true,
  $true,
  [System.Security.Principal.SecurityIdentifier]
) | ForEach-Object { $_.IdentityReference.Value }) | Sort-Object -Unique
[pscustomobject]@{
  user_sid = $userSid
  acl_sids = @($appliedSids)
  owner_sid = $appliedAcl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value
} | ConvertTo-Json -Compress
`.trim()

// PROD-HOTFIX-006: no production caller since securePrivateRuntimeRoot reads the ACL back inside its
// own single spawn. Kept because the ACL tests must be able to observe the applied rights through a
// path the writer does not control — a test that trusted the writer's own report would pass even if
// the write silently did nothing.
/** @param {string} dataRoot */
export const listWindowsAclSids = async (dataRoot) => {
  const { stdout } = await execFileAsync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command', readAclScript],
    {
      encoding: 'utf8',
      windowsHide: true,
      maxBuffer: 4096,
      timeout: windowsAclInspectionTimeoutMs,
      env: windowsPowerShellEnvironment({ OPENVIDEO_ACL_ROOT: dataRoot }),
    },
  )
  const parsed = JSON.parse(stdout.trim() || '[]')
  return Array.isArray(parsed) ? parsed : [parsed]
}

/** @param {string} dataRoot */
export const getWindowsOwnerSid = async (dataRoot) => {
  const { stdout } = await execFileAsync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command', readOwnerScript],
    {
      encoding: 'utf8',
      windowsHide: true,
      maxBuffer: 1024,
      timeout: windowsAclInspectionTimeoutMs,
      env: windowsPowerShellEnvironment({ OPENVIDEO_ACL_ROOT: dataRoot }),
    },
  )
  const ownerSid = stdout.trim()
  if (!/^S-\d(?:-\d+)+$/u.test(ownerSid)) throw new Error('invalid_owner_sid')
  return ownerSid
}

const runtimeOwnerFile = '.openvideo-runtime-owner.json'
const runtimeOwnerDocument = {
  schema_version: 1,
  owner: 'openvideo-local-runtime',
}

/** @param {string} dataRoot @returns {Promise<boolean>} */
export const claimPrivateRuntimeRoot = async (dataRoot) => {
  let current = resolve(dataRoot)
  while (true) {
    const ancestorOwnerPath = resolve(current, runtimeOwnerFile)
    if (existsSync(ancestorOwnerPath)) {
      try {
        const owner = JSON.parse(await readFile(ancestorOwnerPath, 'utf8'))
        if (
          Object.keys(owner).sort().join(',') !== 'owner,schema_version' ||
          owner.schema_version !== runtimeOwnerDocument.schema_version ||
          owner.owner !== runtimeOwnerDocument.owner
        ) throw new Error('invalid-owner')
        return false
      } catch (error) {
        const failure = new LocalRuntimeError('LOCAL_RUNTIME_ROOT_UNOWNED', 500)
        failure.cause = error
        throw failure
      }
    }
    const parent = dirname(current)
    if (parent === current) break
    current = parent
  }

  const ownerPath = resolve(dataRoot, runtimeOwnerFile)
  const entries = await readdir(dataRoot)
  if (entries.includes(runtimeOwnerFile)) {
    try {
      const owner = JSON.parse(await readFile(ownerPath, 'utf8'))
      if (
        Object.keys(owner).sort().join(',') !== 'owner,schema_version' ||
        owner.schema_version !== runtimeOwnerDocument.schema_version ||
        owner.owner !== runtimeOwnerDocument.owner
      ) throw new Error('invalid-owner')
      return false
    } catch (error) {
      const failure = new LocalRuntimeError('LOCAL_RUNTIME_ROOT_UNOWNED', 500)
      failure.cause = error
      throw failure
    }
  }
  if (entries.length > 0) {
    throw new LocalRuntimeError('LOCAL_RUNTIME_ROOT_UNOWNED', 500)
  }
  await writeFile(ownerPath, `${JSON.stringify(runtimeOwnerDocument)}\n`, {
    encoding: 'utf8',
    flag: 'wx',
    mode: 0o600,
  })
  return true
}

/** @param {string} dataRoot */
const applyPrivateRuntimeAcl = async (dataRoot) => {
  const freshlyClaimed = await claimPrivateRuntimeRoot(dataRoot)
  if (process.platform !== 'win32') {
    await chmod(dataRoot, 0o700)
    return
  }
  try {
    let stdout = ''
    let lastError = null
    for (const executable of ['pwsh.exe', 'powershell.exe']) {
      try {
        ({ stdout } = await execFileAsync(
          executable,
          ['-NoProfile', '-NonInteractive', '-Command', securePrivateRootScript],
          {
            encoding: 'utf8',
            windowsHide: true,
            maxBuffer: 16_384,
            timeout: windowsAclMutationTimeoutMs,
            env: windowsPowerShellEnvironment({
              OPENVIDEO_ACL_ROOT: dataRoot,
              OPENVIDEO_ACL_FRESHLY_CLAIMED: freshlyClaimed ? '1' : '0',
            }),
          },
        ))
        break
      } catch (error) {
        lastError = error
      }
    }
    if (!stdout) throw lastError ?? new Error('powershell-unavailable')
    const applied = JSON.parse(stdout.trim() || 'null')
    if (!applied || typeof applied !== 'object') throw new Error('unreadable_acl_report')
    const userSid = typeof applied.user_sid === 'string' ? applied.user_sid.trim() : ''
    if (!/^S-\d(?:-\d+)+$/u.test(userSid)) throw new Error('invalid_sid')
    const allowedSids = new Set([userSid, 'S-1-5-18', 'S-1-5-32-544'])
    /** @type {unknown[]} */
    const actualSids = Array.isArray(applied.acl_sids)
      ? applied.acl_sids
      : [applied.acl_sids].filter((sid) => sid !== undefined && sid !== null)
    if (
      actualSids.length !== allowedSids.size ||
      actualSids.some((/** @type {unknown} */ sid) => typeof sid !== 'string' || !allowedSids.has(sid))
    ) {
      throw new Error('unexpected_acl')
    }
    if (applied.owner_sid !== userSid) throw new Error('unexpected_owner')
  } catch (error) {
    const failure = new LocalRuntimeError('LOCAL_RUNTIME_ACL_UNSAFE', 500)
    failure.cause = error
    throw failure
  }
}

/**
 * Repairs and verifies the private runtime boundary. Managed entries are created beneath this
 * boundary and inherit the same three private ACEs. Startup must never walk the whole cache:
 * otherwise adding thumbnails or analysis artifacts would make launch time grow without bound.
 * @param {string} dataRoot
 */
export const securePrivateRuntimeRoot = async (dataRoot) => applyPrivateRuntimeAcl(dataRoot)

/**
 * Repairs and verifies only the root boundary. The launcher uses this before writing its instance
 * secret; Gateway independently revalidates the same boundary before it starts listening.
 * @param {string} dataRoot
 */
export const securePrivateRuntimeBoundary = async (dataRoot) => applyPrivateRuntimeAcl(dataRoot)

/**
 * PROD-HOTFIX-007: boot wires ten private roots through nine factories, and five of them pass the
 * same dataRoot. Coalescing keeps those checks bounded while preserving ownership validation for
 * each newly created nested root.
 *
 * The first request for an uncovered root is hardened immediately, which keeps dataRoot private
 * before any secret is written into it. Later paths inside that root inherit the private boundary;
 * finalize() revalidates the recorded roots before the listener opens.
 *
 * Scope is the boot window, never the process lifetime: securePrivateRuntimeRoot stays the default
 * everywhere, so runtime writes after boot keep re-inspecting and repairing on every call.
 *
 * @param {{
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 *   verifyPrivateRoot?: (dataRoot: string) => Promise<void>,
 * }} [options]
 */
export const createBootPrivateRootSecurer = (options = {}) => {
  const securePrivateRoot = options.securePrivateRoot ?? securePrivateRuntimeRoot
  const verifyPrivateRoot = options.verifyPrivateRoot ?? (
    options.securePrivateRoot ? securePrivateRoot : securePrivateRuntimeBoundary
  )
  /** @type {string[]} */
  const hardenedRoots = []
  let finalized = false

  /** @param {string} candidate */
  const coveredBy = (candidate) => hardenedRoots.find((root) =>
    candidate === root || candidate.startsWith(`${root}${sep}`))

  return {
    /** @param {string} dataRoot */
    securePrivateRoot: async (dataRoot) => {
      if (!isAbsolute(dataRoot)) {
        throw new LocalRuntimeError('LOCAL_RUNTIME_DATA_ROOT_REQUIRED', 500)
      }
      const target = resolve(dataRoot)
      if (finalized || !coveredBy(target)) {
        await securePrivateRoot(target)
        // Recorded only after the walk succeeds, so a failed attempt never lets a later caller
        // inherit a false success through coveredBy().
        if (!coveredBy(target)) hardenedRoots.push(target)
        return
      }
      // Already inside a root this boot hardened. claimPrivateRuntimeRoot still runs so ownership
      // violations surface at the same call they always did; only the ACL walk is deferred.
      await claimPrivateRuntimeRoot(target)
    },
    /** Revalidates recorded boundaries without closing the boot coalescing window. */
    verify: async () => {
      for (const root of hardenedRoots) {
        await verifyPrivateRoot(root)
      }
    },
    /**
     * Revalidates every recorded root after boot initialization. Files created during boot inherit
     * the private root ACL, so another complete tree walk would only repeat the same state. This must
     * still be awaited before the server accepts traffic so a changed root boundary fails closed.
     */
    finalize: async () => {
      finalized = true
      for (const root of hardenedRoots) {
        await verifyPrivateRoot(root)
      }
    },
  }
}

/** @param {{dataRoot: string, securePrivateRoot?: (dataRoot: string) => Promise<void>}} options */
export const createJsonRepositories = async ({
  dataRoot,
  securePrivateRoot = securePrivateRuntimeRoot,
}) => {
  if (!isAbsolute(dataRoot)) {
    throw new LocalRuntimeError('LOCAL_RUNTIME_DATA_ROOT_REQUIRED', 500)
  }
  await mkdir(dataRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(dataRoot)
  const projectRepository = await createJsonRepository(resolve(dataRoot, 'projects.json'), validProjectRecord)
  const authorizationRepository = await createJsonRepository(resolve(dataRoot, 'authorizations.json'), validAuthorizationRecord)
  const taskStore = await createJsonRepository(resolve(dataRoot, 'tasks.json'), validTaskRecord)
  const taskRepository = {
    get: taskStore.get,
    list: taskStore.list,
    save: taskStore.save,
    remove: taskStore.remove,
    /** @param {string} projectId */
    listByProject(projectId) {
      return taskStore
        .list()
        .filter((/** @type {Record<string, any>} */ task) => task.projectId === projectId)
        .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) => (left.position ?? 0) - (right.position ?? 0))
    },
  }
  return { projectRepository, authorizationRepository, taskRepository }
}

const trustedLoopbackHosts = new Set(['127.0.0.1', 'localhost', '[::1]'])

/** @param {Request} request */
export const isTrustedLocalHttpRequest = (request) => {
  const host = request.headers.get('host')
  if (!host) return false
  let requestOrigin
  try {
    requestOrigin = new URL(`http://${host}`)
  } catch {
    return false
  }
  if (!trustedLoopbackHosts.has(requestOrigin.hostname.toLowerCase())) return false
  const safeReadRequest = ['GET', 'HEAD'].includes(request.method)
  const requestPath = new URL(request.url).pathname
  const fetchSite = request.headers.get('sec-fetch-site')
  const directDocumentNavigation = (
    fetchSite !== null &&
    ['none', 'same-site', 'cross-site'].includes(fetchSite) &&
    !requestPath.startsWith('/api/') &&
    safeReadRequest &&
    request.headers.get('sec-fetch-mode') === 'navigate' &&
    request.headers.get('sec-fetch-dest') === 'document'
  )
  if (fetchSite && fetchSite !== 'same-origin' && !directDocumentNavigation) return false
  const origin = request.headers.get('origin')
  const writeRequest = !['GET', 'HEAD', 'OPTIONS'].includes(request.method)
  if (!origin) return !writeRequest
  try {
    const parsedOrigin = new URL(origin)
    const sameLoopbackOrigin = (
      parsedOrigin.origin === origin &&
      parsedOrigin.protocol === 'http:' &&
      parsedOrigin.host.toLowerCase() === requestOrigin.host.toLowerCase() &&
      trustedLoopbackHosts.has(parsedOrigin.hostname.toLowerCase())
    )
    const loopbackIntroNavigation = (
      directDocumentNavigation &&
      parsedOrigin.origin === origin &&
      parsedOrigin.protocol === 'http:' &&
      trustedLoopbackHosts.has(parsedOrigin.hostname.toLowerCase())
    )
    if (!sameLoopbackOrigin && !loopbackIntroNavigation) return false
  } catch {
    return false
  }
  return true
}

/**
 * Short-lived STA picker process.
 *
 * The previous warm host kept a WinForms timer and user32 foreground forcing
 * alive between selections. On some Windows/PowerShell combinations, clicking
 * Open after selecting a file raised a PowerShell event-pipeline null-method
 * exception that escaped as a modal ".NET Framework" crash dialog. A fresh
 * single-purpose process avoids that shared event state.
 *
 * The dialog still needs an on-screen owner: an unowned ShowDialog() can open
 * behind the browser/Cursor, while an off-screen owner can place the dialog
 * outside the visible desktop.
 */
const nativePickerInteropSource = [
  'using System;',
  'using System.Collections.Generic;',
  'using System.Drawing;',
  'using System.Runtime.InteropServices;',
  'using System.Text;',
  'using System.Windows.Forms;',
  '',
  '[ComImport, Guid("42f85136-db7e-439c-85f1-e4075d135fc8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
  'internal interface OpenVideoIFileDialog {',
  '  [PreserveSig] int Show(IntPtr parent);',
  '  void SetFileTypes(uint count, IntPtr specs);',
  '  void SetFileTypeIndex(uint index);',
  '  void GetFileTypeIndex(out uint index);',
  '  void Advise(IntPtr events, out uint cookie);',
  '  void Unadvise(uint cookie);',
  '  void SetOptions(uint options);',
  '  void GetOptions(out uint options);',
  '  void SetDefaultFolder(OpenVideoIShellItem folder);',
  '  void SetFolder(OpenVideoIShellItem folder);',
  '  void GetFolder(out OpenVideoIShellItem folder);',
  '  void GetCurrentSelection(out OpenVideoIShellItem item);',
  '  void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string name);',
  '  void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string name);',
  '  void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string title);',
  '  void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void GetResult(out OpenVideoIShellItem item);',
  '  void AddPlace(OpenVideoIShellItem item, int location);',
  '  void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string extension);',
  '  void Close(int hr);',
  '  void SetClientGuid(ref Guid guid);',
  '  void ClearClientData();',
  '  void SetFilter(IntPtr filter);',
  '}',
  '[ComImport, Guid("d57c7288-d4ad-4768-be02-9d969532d960"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
  'internal interface OpenVideoIFileOpenDialog {',
  '  [PreserveSig] int Show(IntPtr parent);',
  '  void SetFileTypes(uint count, IntPtr specs);',
  '  void SetFileTypeIndex(uint index);',
  '  void GetFileTypeIndex(out uint index);',
  '  void Advise(IntPtr events, out uint cookie);',
  '  void Unadvise(uint cookie);',
  '  void SetOptions(uint options);',
  '  void GetOptions(out uint options);',
  '  void SetDefaultFolder(OpenVideoIShellItem folder);',
  '  void SetFolder(OpenVideoIShellItem folder);',
  '  void GetFolder(out OpenVideoIShellItem folder);',
  '  void GetCurrentSelection(out OpenVideoIShellItem item);',
  '  void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string name);',
  '  void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string name);',
  '  void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string title);',
  '  void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void GetResult(out OpenVideoIShellItem item);',
  '  void AddPlace(OpenVideoIShellItem item, int location);',
  '  void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string extension);',
  '  void Close(int hr);',
  '  void SetClientGuid(ref Guid guid);',
  '  void ClearClientData();',
  '  void SetFilter(IntPtr filter);',
  '  void GetResults(out OpenVideoIShellItemArray items);',
  '  void GetSelectedItems(out OpenVideoIShellItemArray items);',
  '}',
  '[ComImport, Guid("b63ea76d-1f0f-41b8-91b3-1c583af08b6a"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
  'internal interface OpenVideoIShellItemArray {',
  '  void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);',
  '  void GetPropertyStore(uint flags, ref Guid riid, out IntPtr ppv);',
  '  void GetPropertyDescriptionList(IntPtr keyType, ref Guid riid, out IntPtr ppv);',
  '  void GetAttributes(uint attribFlags, uint sfgaoMask, out uint psfgaoAttribs);',
  '  void GetCount(out uint count);',
  '  void GetItemAt(uint index, out OpenVideoIShellItem item);',
  '  void EnumItems(out IntPtr penum);',
  '}',
  '[ComImport, Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
  'internal interface OpenVideoIShellItem {',
  '  void BindToHandler(IntPtr bindContext, ref Guid bhid, ref Guid riid, out IntPtr ppv);',
  '  void GetParent(out OpenVideoIShellItem parent);',
  '  void GetDisplayName(uint kind, out IntPtr name);',
  '  void GetAttributes(uint mask, out uint attributes);',
  '  void Compare(OpenVideoIShellItem other, uint hint, out int order);',
  '}',
  '[ComImport, Guid("dc1c5a9c-e88a-4dde-a5a1-60f82a20aef7")]',
  'internal class OpenVideoFileOpenDialog { }',
  '[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]',
  'internal struct OpenVideoFilterSpec {',
  '  [MarshalAs(UnmanagedType.LPWStr)] public string Name;',
  '  [MarshalAs(UnmanagedType.LPWStr)] public string Spec;',
  '}',
  '[ComImport, Guid("e6fdd21a-163f-4975-9c8c-a69fdf74899a"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]',
  'internal interface OpenVideoIFileDialogCustomize {',
  '  void EnableOpenDropDown(uint ctl);',
  '  void AddMenu(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void AddPushButton(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void AddComboBox(uint ctl);',
  '  void AddRadioButtonList(uint ctl);',
  '  void AddCheckButton(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string label, bool isChecked);',
  '  void AddEditBox(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string text);',
  '  void AddSeparator(uint ctl);',
  '  void AddText(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string text);',
  '  void SetControlLabel(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void GetEditBoxText(uint ctl, out IntPtr text);',
  '  void SetEditBoxText(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string text);',
  '  void GetCheckButtonState(uint ctl, out bool isChecked);',
  '  void SetCheckButtonState(uint ctl, bool isChecked);',
  '  void AddControlItem(uint ctl, uint item, [MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void RemoveControlItem(uint ctl, uint item);',
  '  void RemoveAllControlItems(uint ctl);',
  '  void GetControlItemState(uint ctl, uint item, out uint state);',
  '  void SetControlItemState(uint ctl, uint item, uint state);',
  '  void GetSelectedControlItem(uint ctl, out uint item);',
  '  void SetSelectedControlItem(uint ctl, uint item);',
  '  void StartVisualGroup(uint ctl, [MarshalAs(UnmanagedType.LPWStr)] string label);',
  '  void EndVisualGroup();',
  '  void MakeProminent(uint ctl);',
  '  void SetControlState(uint ctl, uint state);',
  '  void GetControlState(uint ctl, out uint state);',
  '}',
  '[ComVisible(true), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("973510db-7d7f-452b-8975-74a85828d354")]',
  'internal interface OpenVideoIFileDialogEvents {',
  '  [PreserveSig] int OnFileOk(IntPtr dialog);',
  '  [PreserveSig] int OnFolderChanging(IntPtr dialog, IntPtr folder);',
  '  [PreserveSig] int OnFolderChange(IntPtr dialog);',
  '  [PreserveSig] int OnSelectionChange(IntPtr dialog);',
  '  [PreserveSig] int OnShareViolation(IntPtr dialog, IntPtr item, out uint response);',
  '  [PreserveSig] int OnTypeChange(IntPtr dialog);',
  '  [PreserveSig] int OnOverwrite(IntPtr dialog, IntPtr item, out uint response);',
  '}',
  '[ComVisible(true), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("36116642-D445-4a4b-8D9E-4B5A1D7031C8")]',
  'internal interface OpenVideoIFileDialogControlEvents {',
  '  void OnItemSelected(IntPtr customize, uint ctl, uint item);',
  '  void OnButtonClicked(IntPtr customize, uint ctl);',
  '  void OnCheckButtonToggled(IntPtr customize, uint ctl, bool isChecked);',
  '  void OnControlActivating(IntPtr customize, uint ctl);',
  '}',
  '[ComVisible(true), ClassInterface(ClassInterfaceType.None)]',
  'sealed class OpenVideoMediaDialogSink : OpenVideoIFileDialogEvents, OpenVideoIFileDialogControlEvents {',
  '  public OpenVideoIFileOpenDialog Dialog;',
  '  public string FolderPath;',
  '  public int OnFileOk(IntPtr dialog) { return 0; }',
  '  public int OnFolderChanging(IntPtr dialog, IntPtr folder) { return 0; }',
  '  public int OnFolderChange(IntPtr dialog) { return 0; }',
  '  public int OnSelectionChange(IntPtr dialog) { return 0; }',
  '  public int OnShareViolation(IntPtr dialog, IntPtr item, out uint response) { response = 0; return 0; }',
  '  public int OnTypeChange(IntPtr dialog) { return 0; }',
  '  public int OnOverwrite(IntPtr dialog, IntPtr item, out uint response) { response = 0; return 0; }',
  '  public void OnItemSelected(IntPtr customize, uint ctl, uint item) { }',
  '  public void OnButtonClicked(IntPtr customize, uint ctl) {',
  '    if (ctl != 2 || Dialog == null) return;',
  '    FolderPath = OpenVideoExplorerMediaPicker.FolderFromDialog(Dialog);',
  '    try { Dialog.Close(0); } catch { }',
  '  }',
  '  public void OnCheckButtonToggled(IntPtr customize, uint ctl, bool isChecked) { }',
  '  public void OnControlActivating(IntPtr customize, uint ctl) { }',
  '}',
  'public static class OpenVideoExplorerFolderPicker {',
  '  private const uint FOS_PICKFOLDERS = 0x00000020;',
  '  private const uint FOS_FORCEFILESYSTEM = 0x00000040;',
  '  private const uint FOS_PATHMUSTEXIST = 0x00000800;',
  '  private const uint SIGDN_FILESYSPATH = 0x80058000;',
  '  internal static OpenVideoIFileDialog Prepare(string title) {',
  '    OpenVideoIFileDialog dialog = (OpenVideoIFileDialog)new OpenVideoFileOpenDialog();',
  '    uint options;',
  '    dialog.GetOptions(out options);',
  '    dialog.SetOptions(options | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST);',
  '    dialog.SetTitle(title);',
  '    dialog.SetOkButtonLabel("选择文件夹");',
  '    return dialog;',
  '  }',
  '  internal static string Show(OpenVideoIFileDialog dialog, IntPtr owner) {',
  '    OpenVideoIShellItem result = null;',
  '    IntPtr path = IntPtr.Zero;',
  '    try {',
  '      if (dialog.Show(owner) != 0) return null;',
  '      dialog.GetResult(out result);',
  '      result.GetDisplayName(SIGDN_FILESYSPATH, out path);',
  '      return Marshal.PtrToStringUni(path);',
  '    } finally {',
  '      if (path != IntPtr.Zero) Marshal.FreeCoTaskMem(path);',
  '      if (result != null) Marshal.ReleaseComObject(result);',
  '    }',
  '  }',
  '  public static string Pick(IntPtr owner, string title) {',
  '    OpenVideoIFileDialog dialog = null;',
  '    try {',
  '      dialog = Prepare(title);',
  '      return Show(dialog, owner);',
  '    } finally {',
  '      if (dialog != null) Marshal.ReleaseComObject(dialog);',
  '    }',
  '  }',
  '}',
  'sealed class OpenVideoPreparedMediaDialog {',
  '  public OpenVideoIFileOpenDialog Dialog;',
  '  public OpenVideoIFileDialogCustomize Customize;',
  '  public OpenVideoMediaDialogSink Sink;',
  '  public uint AdviseCookie;',
  '  public IntPtr AdvisePtr;',
  '  public IntPtr Specs;',
  '  public void Release() {',
  '    if (Dialog != null && AdviseCookie != 0) {',
  '      try { Dialog.Unadvise(AdviseCookie); } catch { }',
  '      AdviseCookie = 0;',
  '    }',
  '    if (AdvisePtr != IntPtr.Zero) { Marshal.Release(AdvisePtr); AdvisePtr = IntPtr.Zero; }',
  '    Sink = null;',
  '    if (Specs != IntPtr.Zero) { Marshal.FreeHGlobal(Specs); Specs = IntPtr.Zero; }',
  '    if (Dialog != null) { Marshal.ReleaseComObject(Dialog); Dialog = null; }',
  '    Customize = null;',
  '  }',
  '}',
  'static class OpenVideoExplorerMediaPicker {',
  '  private const uint FOS_PICKFOLDERS = 0x00000020;',
  '  private const uint FOS_FORCEFILESYSTEM = 0x00000040;',
  '  private const uint FOS_PATHMUSTEXIST = 0x00000800;',
  '  private const uint FOS_ALLOWMULTISELECT = 0x00000200;',
  '  private const uint SIGDN_FILESYSPATH = 0x80058000;',
  '  public static OpenVideoPreparedMediaDialog Prepare() {',
  '    var prepared = new OpenVideoPreparedMediaDialog();',
  '    prepared.Dialog = (OpenVideoIFileOpenDialog)new OpenVideoFileOpenDialog();',
  '    uint options;',
  '    prepared.Dialog.GetOptions(out options);',
  '    prepared.Dialog.SetOptions((options | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_ALLOWMULTISELECT) & ~FOS_PICKFOLDERS);',
  '    prepared.Dialog.SetTitle("选择要加入 OpenVideo 素材库的视频");',
  '    prepared.Dialog.SetOkButtonLabel("导入视频");',
  '    var filters = new OpenVideoFilterSpec[] {',
  '      new OpenVideoFilterSpec { Name = "视频文件", Spec = "*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v" },',
  '      new OpenVideoFilterSpec { Name = "所有文件", Spec = "*.*" },',
  '    };',
  '    int size = Marshal.SizeOf(typeof(OpenVideoFilterSpec));',
  '    prepared.Specs = Marshal.AllocHGlobal(size * filters.Length);',
  '    for (int i = 0; i < filters.Length; i++) Marshal.StructureToPtr(filters[i], IntPtr.Add(prepared.Specs, i * size), false);',
  '    prepared.Dialog.SetFileTypes((uint)filters.Length, prepared.Specs);',
  '    prepared.Dialog.SetFileTypeIndex(1);',
  '    try {',
  '      prepared.Customize = (OpenVideoIFileDialogCustomize)prepared.Dialog;',
  '      try {',
  '        prepared.Customize.EnableOpenDropDown(1);',
  '        prepared.Customize.AddControlItem(1, 1, "导入视频");',
  '        prepared.Customize.AddControlItem(1, 2, "选择这个文件夹");',
  '        prepared.Customize.SetSelectedControlItem(1, 1);',
  '      } catch { }',
  '      prepared.Customize.AddPushButton(2, "选择这个文件夹");',
  '      prepared.Customize.MakeProminent(2);',
  '      prepared.Sink = new OpenVideoMediaDialogSink();',
  '      prepared.Sink.Dialog = prepared.Dialog;',
  '      prepared.AdvisePtr = Marshal.GetComInterfaceForObject(prepared.Sink, typeof(OpenVideoIFileDialogEvents));',
  '      prepared.Dialog.Advise(prepared.AdvisePtr, out prepared.AdviseCookie);',
  '    } catch {',
  '      prepared.Customize = null;',
  '    }',
  '    return prepared;',
  '  }',
  '  public static string FolderFromDialog(OpenVideoIFileOpenDialog dialog) {',
  '    OpenVideoIShellItem current = null;',
  '    OpenVideoIShellItem folder = null;',
  '    IntPtr path = IntPtr.Zero;',
  '    try {',
  '      try {',
  '        dialog.GetCurrentSelection(out current);',
  '        uint attrs = 0;',
  '        current.GetAttributes(0x20000000, out attrs);',
  '        if ((attrs & 0x20000000) != 0) {',
  '          current.GetDisplayName(SIGDN_FILESYSPATH, out path);',
  '          var highlighted = Marshal.PtrToStringUni(path);',
  '          if (!String.IsNullOrWhiteSpace(highlighted)) return highlighted;',
  '        }',
  '      } catch {',
  '      } finally {',
  '        if (current != null) Marshal.ReleaseComObject(current);',
  '      }',
  '      dialog.GetFolder(out folder);',
  '      folder.GetDisplayName(SIGDN_FILESYSPATH, out path);',
  '      return Marshal.PtrToStringUni(path);',
  '    } finally {',
  '      if (path != IntPtr.Zero) Marshal.FreeCoTaskMem(path);',
  '      if (folder != null) Marshal.ReleaseComObject(folder);',
  '    }',
  '  }',
  '  public static string Show(OpenVideoPreparedMediaDialog prepared, IntPtr owner) {',
  '    OpenVideoIShellItem result = null;',
  '    OpenVideoIShellItemArray items = null;',
  '    IntPtr path = IntPtr.Zero;',
  '    try {',
  '      if (prepared.Dialog.Show(owner) != 0) {',
  '        if (prepared.Sink != null && !String.IsNullOrWhiteSpace(prepared.Sink.FolderPath)) return prepared.Sink.FolderPath;',
  '        return null;',
  '      }',
  '      if (prepared.Sink != null && !String.IsNullOrWhiteSpace(prepared.Sink.FolderPath)) return prepared.Sink.FolderPath;',
  '      uint item = 1;',
  '      if (prepared.Customize != null) {',
  '        try { prepared.Customize.GetSelectedControlItem(1, out item); } catch { item = 1; }',
  '      }',
  '      if (item == 2) return FolderFromDialog(prepared.Dialog);',
  '      try {',
  '        prepared.Dialog.GetResults(out items);',
  '        uint count = 0;',
  '        items.GetCount(out count);',
  '        var paths = new List<string>();',
  '        for (uint index = 0; index < count; index++) {',
  '          OpenVideoIShellItem one = null;',
  '          IntPtr name = IntPtr.Zero;',
  '          try {',
  '            items.GetItemAt(index, out one);',
  '            one.GetDisplayName(SIGDN_FILESYSPATH, out name);',
  '            var selected = Marshal.PtrToStringUni(name);',
  '            if (!String.IsNullOrWhiteSpace(selected)) paths.Add(selected);',
  '          } finally {',
  '            if (name != IntPtr.Zero) Marshal.FreeCoTaskMem(name);',
  '            if (one != null) Marshal.ReleaseComObject(one);',
  '          }',
  '        }',
  '        return paths.Count == 0 ? null : String.Join("\\n", paths);',
  '      } catch {',
  '        try {',
  '          prepared.Dialog.GetResult(out result);',
  '          result.GetDisplayName(SIGDN_FILESYSPATH, out path);',
  '          return Marshal.PtrToStringUni(path);',
  '        } catch {',
  '          return null;',
  '        }',
  '      }',
  '    } finally {',
  '      if (path != IntPtr.Zero) Marshal.FreeCoTaskMem(path);',
  '      if (result != null) Marshal.ReleaseComObject(result);',
  '      if (items != null) Marshal.ReleaseComObject(items);',
  '      prepared.Release();',
  '    }',
  '  }',
  '  public static string Pick(IntPtr owner) {',
  '    return Show(Prepare(), owner);',
  '  }',
  '}',
  'public static class OpenVideoPickerProgram {',
  '  private static string Result(string selected) {',
  '    return String.IsNullOrWhiteSpace(selected)',
  '      ? "CANCEL"',
  '      : "OK\\t" + Convert.ToBase64String(Encoding.UTF8.GetBytes(selected));',
  '  }',
  '  [STAThread]',
  '  public static void Main(string[] args) {',
  '    try {',
  '      var kind = args != null && args.Length == 1 ? args[0] : "";',
  '      Application.EnableVisualStyles();',
  '      using (var owner = new Form()) {',
  '        owner.Text = "OpenVideo";',
  '        owner.TopMost = true;',
  '        owner.ShowInTaskbar = false;',
  '        owner.FormBorderStyle = FormBorderStyle.FixedToolWindow;',
  '        owner.ControlBox = false;',
  '        owner.StartPosition = FormStartPosition.CenterScreen;',
  '        owner.Size = new Size(1, 1);',
  '        owner.Opacity = 0;',
  '        owner.Show();',
  '        owner.Activate();',
        '        OpenVideoIFileDialog preparedFolder = null;',
        '        OpenFileDialog preparedVideo = null;',
        '        if (kind == "idle") {',
        '          try { preparedFolder = OpenVideoExplorerFolderPicker.Prepare("选择 OpenVideo 只读素材文件夹"); } catch { preparedFolder = null; }',
        '          try {',
        '            preparedVideo = new OpenFileDialog();',
        '            preparedVideo.Multiselect = false;',
        '            preparedVideo.CheckFileExists = true;',
        '            preparedVideo.CheckPathExists = true;',
        '            preparedVideo.Title = "选择要加入 OpenVideo 素材库的视频";',
        '            preparedVideo.Filter = "Video files (*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v)|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v";',
        '          } catch { preparedVideo = null; }',
        '          Console.Out.WriteLine("HOST");',
        '          Console.Out.Flush();',
        '          kind = (Console.In.ReadLine() ?? "").Trim();',
        '        }',
        '        owner.BringToFront();',
        '        Console.Out.WriteLine("READY");',
        '        Console.Out.Flush();',
        '        if (kind == "folder") {',
        '          if (preparedVideo != null) preparedVideo.Dispose();',
        '          try {',
        '            Console.Out.WriteLine(Result(preparedFolder != null',
        '              ? OpenVideoExplorerFolderPicker.Show(preparedFolder, owner.Handle)',
        '              : OpenVideoExplorerFolderPicker.Pick(owner.Handle, "选择 OpenVideo 只读素材文件夹")));',
        '          } finally {',
        '            if (preparedFolder != null) { Marshal.ReleaseComObject(preparedFolder); preparedFolder = null; }',
        '          }',
        '        } else if (kind == "media") {',
        '          if (preparedFolder != null) { Marshal.ReleaseComObject(preparedFolder); preparedFolder = null; }',
        '          if (preparedVideo != null) { preparedVideo.Dispose(); preparedVideo = null; }',
        '          try {',
        '            Console.Out.WriteLine(Result(OpenVideoExplorerMediaPicker.Pick(owner.Handle)));',
        '          } catch {',
        '            Console.Out.WriteLine("CANCEL");',
        '          }',
        '        } else {',
        '          if (preparedFolder != null) { Marshal.ReleaseComObject(preparedFolder); preparedFolder = null; }',
        '          if (kind != "video" && preparedVideo != null) { preparedVideo.Dispose(); preparedVideo = null; }',
        '          using (var dialog = preparedVideo != null ? preparedVideo : new OpenFileDialog()) {',
        '            if (preparedVideo == null) {',
        '              dialog.Multiselect = false;',
        '              dialog.CheckFileExists = true;',
        '              dialog.CheckPathExists = true;',
        '              if (kind == "audio") {',
        '                dialog.Title = "选择 OpenVideo 只读音频文件";',
        '                dialog.Filter = "Audio files (*.mp3;*.wav;*.m4a;*.aac;*.flac)|*.mp3;*.wav;*.m4a;*.aac;*.flac";',
        '              } else if (kind == "video") {',
        '                dialog.Title = "选择要加入 OpenVideo 素材库的视频";',
        '                dialog.Filter = "Video files (*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v)|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.wmv;*.m4v";',
        '              } else {',
        '                throw new ArgumentException("BAD_REQUEST");',
        '              }',
        '            }',
        '            preparedVideo = null;',
        '            Console.Out.WriteLine(dialog.ShowDialog(owner) == DialogResult.OK ? Result(dialog.FileName) : "CANCEL");',
        '          }',
        '        }',
  '      }',
  '    } catch {',
  '      Console.Out.WriteLine("ERROR\\tPICK_FAILED");',
  '    } finally {',
  '      Console.Out.Flush();',
  '    }',
  '  }',
  '}',
].join('\n')

const nativePickerExecutablePath = join(
  tmpdir(),
  'OpenVideo',
  `OpenVideoExplorerPicker-${createHash('sha256').update(nativePickerInteropSource).digest('hex').slice(0, 12)}.exe`,
)

let warmPickerLock = Promise.resolve()
/** True while a PICK is waiting on the modal native dialog. */
let warmPickerBusy = false
/** @type {typeof spawn} */
let warmPickerSpawnImpl = spawn
let warmPickerReadyTimeoutMs = 30_000
let warmPickerUseIdleHost = true
/** @type {ReturnType<typeof spawn> | null} */
let idlePickerHost = null
/** @type {Promise<boolean> | null} */
let idlePickerHostStart = null

/** @param {{ spawnImpl?: typeof spawn, readyTimeoutMs?: number, useIdleHost?: boolean } | null} hooks */
export const __setWarmPickerTestHooks = (hooks) => {
  if (!hooks) {
    warmPickerSpawnImpl = spawn
    warmPickerReadyTimeoutMs = 30_000
    warmPickerUseIdleHost = true
    return
  }
  if (hooks.spawnImpl) warmPickerSpawnImpl = hooks.spawnImpl
  if (typeof hooks.readyTimeoutMs === 'number') warmPickerReadyTimeoutMs = hooks.readyTimeoutMs
  warmPickerUseIdleHost = hooks.useIdleHost === true
}

/** @param {ReturnType<typeof spawn> | null | undefined} child */
const detachNativePickerListeners = (child) => {
  if (!child) return
  try {
    child.stdout?.removeAllListeners('data')
    child.stderr?.removeAllListeners('data')
    child.removeAllListeners('error')
    child.removeAllListeners('exit')
  } catch {
    // ignore
  }
}

/** @param {ReturnType<typeof spawn> | null | undefined} child */
const killNativePickerChild = (child) => {
  if (!child || child.killed) return
  detachNativePickerListeners(child)
  try {
    child.kill()
  } catch {
    // ignore
  }
}

const killIdlePickerHost = () => {
  const child = idlePickerHost
  idlePickerHost = null
  idlePickerHostStart = null
  killNativePickerChild(child)
}

const stopWarmPickerProcess = () => {
  warmPickerBusy = false
  killIdlePickerHost()
}

const claimIdlePickerHost = () => {
  const child = idlePickerHost
  idlePickerHost = null
  if (!child || child.killed) return null
  return child
}

/** @type {Promise<boolean> | null} */
let nativePickerInteropWarmup = null

/** @param {string} value */
const quotePowerShellLiteral = (value) => `'${value.replaceAll("'", "''")}'`

const compileNativePickerInterop = async () => {
  const assemblyDirectory = dirname(nativePickerExecutablePath)
  mkdirSync(assemblyDirectory, { recursive: true })
  if (existsSync(nativePickerExecutablePath)) return true
  const temporaryAssemblyPath = join(assemblyDirectory, `OpenVideoExplorerPicker-${randomUUID()}.exe`)
  const source = Buffer.from(nativePickerInteropSource, 'utf8').toString('base64')
  const command = [
    "$ErrorActionPreference = 'Stop'",
    `$source = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${source}'))`,
    `Add-Type -TypeDefinition $source -OutputAssembly ${quotePowerShellLiteral(temporaryAssemblyPath)} -OutputType ConsoleApplication -ReferencedAssemblies @('System.Windows.Forms', 'System.Drawing')`,
    `Move-Item -LiteralPath ${quotePowerShellLiteral(temporaryAssemblyPath)} -Destination ${quotePowerShellLiteral(nativePickerExecutablePath)} -Force`,
  ].join('; ')
  try {
    await execFileAsync(
      'powershell.exe',
      ['-NoLogo', '-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', command],
      { windowsHide: true, timeout: 30_000 },
    )
    return existsSync(nativePickerExecutablePath)
  } catch {
    try { unlinkSync(temporaryAssemblyPath) } catch {}
    return false
  }
}

/** Precompile the Explorer picker outside the click path; picker calls still fail closed if this warmup misses. */
export const warmupWindowsNativePickers = () => {
  if (process.platform !== 'win32') return Promise.resolve(false)
  if (!nativePickerInteropWarmup) {
    nativePickerInteropWarmup = compileNativePickerInterop().catch(() => false)
  }
  return nativePickerInteropWarmup
}

/**
 * Keep one CLR-warm idle host ready so the next click does not pay process startup.
 * Must not run inside warmupWindowsNativePickers — boot warmup is compile-only.
 */
export const ensureWindowsNativePickerHost = async () => {
  if (process.platform !== 'win32' || !warmPickerUseIdleHost) return false
  if (idlePickerHost && !idlePickerHost.killed) return true
  if (idlePickerHostStart) return idlePickerHostStart
  idlePickerHostStart = (async () => {
    /** @type {ReturnType<typeof spawn> | null} */
    let child = null
    try {
      const compiled = await warmupWindowsNativePickers()
      if (!compiled || !existsSync(nativePickerExecutablePath)) return false
      child = warmPickerSpawnImpl(
        nativePickerExecutablePath,
        ['idle'],
        {
          windowsHide: true,
          stdio: ['pipe', 'pipe', 'pipe'],
        },
      )
      const spawned = child
      if (!spawned) return false
      await new Promise((resolve, reject) => {
        let stdout = ''
        let settled = false
        /** @type {ReturnType<typeof setTimeout> | null} */
        let timer = null
        /** @param {Error | null} error */
        const finish = (error) => {
          if (settled) return
          settled = true
          if (timer != null) clearTimeout(timer)
          spawned.stdout?.removeListener('data', onData)
          spawned.removeListener('error', onFail)
          spawned.removeListener('exit', onFail)
          if (error) reject(error)
          else resolve(undefined)
        }
        const onFail = () => finish(new Error('idle host exited'))
        const onData = (/** @type {Buffer | string} */ chunk) => {
          stdout += chunk.toString('utf8')
          if (stdout.split(/\r?\n/u).includes('HOST')) finish(null)
        }
        spawned.stdout?.on('data', onData)
        spawned.stderr?.on('data', () => {})
        spawned.on('error', onFail)
        spawned.on('exit', onFail)
        timer = setTimeout(() => finish(new Error('idle host timeout')), warmPickerReadyTimeoutMs)
      })
      idlePickerHost = child
      const unrefChild = /** @type {unknown} */ (Reflect.get(child, 'unref'))
      if (typeof unrefChild === 'function') Reflect.apply(unrefChild, child, [])
      /** @type {any} */ (child.stdout)?.unref?.()
      /** @type {any} */ (child.stderr)?.unref?.()
      /** @type {any} */ (child.stdin)?.unref?.()
      child.on('exit', () => {
        if (idlePickerHost === child) idlePickerHost = null
      })
      return true
    } catch {
      killNativePickerChild(child)
      idlePickerHost = null
      return false
    } finally {
      idlePickerHostStart = null
    }
  })()
  return idlePickerHostStart
}

/** Test / shutdown helper kept for the previous warm-host API. */
export const shutdownWindowsNativePickers = () => {
  stopWarmPickerProcess()
}

if (typeof process !== 'undefined' && typeof process.on === 'function') {
  process.on('exit', () => {
    try {
      stopWarmPickerProcess()
    } catch {
      // ignore
    }
  })
}

/**
 * @param {ReturnType<typeof spawn>} child
 * @param {string} unavailable
 * @returns {Promise<string>}
 */
const readNativePickerResult = (child, unavailable) => new Promise((resolve, reject) => {
  let settled = false
  let stdout = ''
  /** @type {ReturnType<typeof setTimeout> | null} */
  let timer = null
  const clearTimer = () => {
    if (timer == null) return
    clearTimeout(timer)
    timer = null
  }
  /** @param {unknown} error */
  const fail = (error) => {
    if (settled) return
    settled = true
    clearTimer()
    killNativePickerChild(child)
    reject(error instanceof LocalRuntimeError ? error : new LocalRuntimeError(unavailable, 503))
  }
  /** @param {string} line */
  const finish = (line) => {
    if (settled) return
    settled = true
    clearTimer()
    detachNativePickerListeners(child)
    resolve(line)
  }
  if (!child.stdout || !child.stderr) {
    fail(new LocalRuntimeError(unavailable, 503))
    return
  }
  child.stdout.on('data', (chunk) => {
    stdout += chunk.toString('utf8')
    let newline = stdout.indexOf('\n')
    while (newline >= 0 && !settled) {
      const line = stdout.slice(0, newline).replace(/\r$/u, '')
      stdout = stdout.slice(newline + 1)
      if (line === 'READY' || line === 'HOST') {
        // HOST is leftover from idle handshake; READY means the dialog is up.
        clearTimer()
      } else if (line) {
        finish(line)
      }
      newline = stdout.indexOf('\n')
    }
  })
  child.stderr.on('data', () => {
    // Keep stderr drained; the protocol line on stdout is the public result.
  })
  child.on('error', (error) => fail(error))
  child.on('exit', () => {
    if (!settled) fail(new LocalRuntimeError(unavailable, 503))
  })
  timer = setTimeout(() => fail(new LocalRuntimeError(unavailable, 503)), warmPickerReadyTimeoutMs)
})

/**
 * @param {'folder' | 'audio' | 'video' | 'media'} kind
 * @param {string} unavailable
 * @returns {Promise<string>}
 */
const spawnNativePicker = (kind, unavailable) => {
  if (process.platform !== 'win32') {
    return Promise.reject(new LocalRuntimeError('LOCAL_NATIVE_PICKER_UNSUPPORTED', 501))
  }
  const child = warmPickerSpawnImpl(
    nativePickerExecutablePath,
    [kind],
    {
      windowsHide: false,
      stdio: ['ignore', 'pipe', 'pipe'],
    },
  )
  return readNativePickerResult(child, unavailable)
}

/**
 * @param {'folder' | 'audio' | 'video' | 'media'} kind
 * @param {string} unavailable
 * @returns {Promise<string>}
 */
const pickFromIdleHost = (kind, unavailable) => {
  const child = claimIdlePickerHost()
  if (!child?.stdin) return Promise.reject(new Error('idle host unavailable'))
  try {
    child.stdin.write(`${kind}\n`)
  } catch {
    killNativePickerChild(child)
    return Promise.reject(new Error('idle host stdin failed'))
  }
  return readNativePickerResult(child, unavailable)
}

/**
 * @param {'folder' | 'audio' | 'video' | 'media'} kind
 * @returns {Promise<string>}
 */
const requestWarmNativePick = async (kind) => {
  const unavailable = {
    folder: 'LOCAL_FOLDER_PICKER_UNAVAILABLE',
    audio: 'LOCAL_AUDIO_PICKER_UNAVAILABLE',
    video: 'LOCAL_REFERENCE_VIDEO_PICKER_UNAVAILABLE',
    media: 'LOCAL_MEDIA_PICKER_UNAVAILABLE',
  }[kind]
  const busy = {
    folder: 'LOCAL_FOLDER_PICKER_BUSY',
    audio: 'LOCAL_AUDIO_PICKER_BUSY',
    video: 'LOCAL_REFERENCE_VIDEO_PICKER_BUSY',
    media: 'LOCAL_MEDIA_PICKER_BUSY',
  }[kind]
  // Claim busy synchronously so a second click fails immediately instead of
  // queueing behind a modal dialog the user cannot see.
  if (warmPickerBusy) {
    throw new LocalRuntimeError(busy, 409)
  }
  warmPickerBusy = true
  const run = async () => {
    try {
      const exeReady = existsSync(nativePickerExecutablePath)
      if (!exeReady) {
        let pickerReady = await warmupWindowsNativePickers()
        if (!pickerReady) {
          // A failed boot warmup must not poison later clicks permanently.
          nativePickerInteropWarmup = null
          pickerReady = await warmupWindowsNativePickers()
        }
        if (!pickerReady || !existsSync(nativePickerExecutablePath)) {
          throw new LocalRuntimeError(unavailable, 503)
        }
      }
      let line
      const idleReady = warmPickerUseIdleHost && idlePickerHost && !idlePickerHost.killed
      if (idleReady) {
        try {
          line = await pickFromIdleHost(kind, unavailable)
        } catch (error) {
          if (error instanceof LocalRuntimeError) throw error
          line = await spawnNativePicker(kind, unavailable)
        }
      } else {
        // Do not wait to spawn an idle host on the click path; show Explorer first.
        line = await spawnNativePicker(kind, unavailable)
      }
      void ensureWindowsNativePickerHost()
      if (line === 'CANCEL') {
        const cancelled = {
          folder: 'LOCAL_FOLDER_SELECTION_CANCELLED',
          audio: 'LOCAL_AUDIO_SELECTION_CANCELLED',
          video: 'LOCAL_REFERENCE_VIDEO_SELECTION_CANCELLED',
          media: 'LOCAL_MEDIA_SELECTION_CANCELLED',
        }[kind]
        throw new LocalRuntimeError(cancelled, 409)
      }
      if (!line.startsWith('OK\t')) {
        throw new LocalRuntimeError(unavailable, 503)
      }
      const selected = Buffer.from(line.slice(3), 'base64').toString('utf8')
      const selectedPaths = selected.split(/\r?\n/u).map((part) => part.trim()).filter(Boolean)
      if (selectedPaths.length === 0 || selectedPaths.some((path) => !isAbsolute(path))) {
        const invalid = {
          folder: 'LOCAL_FOLDER_SELECTION_INVALID',
          audio: 'LOCAL_AUDIO_SELECTION_INVALID',
          video: 'LOCAL_REFERENCE_VIDEO_SELECTION_INVALID',
          media: 'LOCAL_MEDIA_SELECTION_INVALID',
        }[kind]
        throw new LocalRuntimeError(invalid, 400)
      }
      return selectedPaths.map((path) => resolve(path)).join('\n')
    } catch (error) {
      if (error instanceof LocalRuntimeError) {
        if (error.code === 'LOCAL_NATIVE_PICKER_UNSUPPORTED') {
          const unsupported = {
            folder: 'LOCAL_FOLDER_PICKER_UNSUPPORTED',
            audio: 'LOCAL_AUDIO_PICKER_UNSUPPORTED',
            video: 'LOCAL_REFERENCE_VIDEO_PICKER_UNSUPPORTED',
            media: 'LOCAL_MEDIA_PICKER_UNSUPPORTED',
          }[kind]
          throw new LocalRuntimeError(unsupported, 501)
        }
        throw error
      }
      throw new LocalRuntimeError(unavailable, 503)
    } finally {
      warmPickerBusy = false
    }
  }
  const pending = warmPickerLock.then(run, run)
  warmPickerLock = pending.then(() => {}, () => {})
  return pending
}
export const pickWindowsFolder = async () => {
  if (process.platform !== 'win32') {
    throw new LocalRuntimeError('LOCAL_FOLDER_PICKER_UNSUPPORTED', 501)
  }
  // No per-kind queue: warmPickerBusy is claimed synchronously inside requestWarmNativePick
  // so a second click fails immediately instead of waiting behind a hidden dialog.
  try {
    return await requestWarmNativePick('folder')
  } catch (error) {
    if (error instanceof LocalRuntimeError) throw error
    throw new LocalRuntimeError('LOCAL_FOLDER_PICKER_UNAVAILABLE', 503)
  }
}

export const pickWindowsAudioFile = async () => {
  if (process.platform !== 'win32') {
    throw new LocalRuntimeError('LOCAL_AUDIO_PICKER_UNSUPPORTED', 501)
  }
  try {
    const selected = await requestWarmNativePick('audio')
    if (!audioExtensions.has(extname(selected).toLowerCase())) {
      throw new LocalRuntimeError('LOCAL_AUDIO_SELECTION_INVALID', 400)
    }
    return selected
  } catch (error) {
    if (error instanceof LocalRuntimeError) throw error
    throw new LocalRuntimeError('LOCAL_AUDIO_PICKER_UNAVAILABLE', 503)
  }
}

export const pickWindowsVideoFile = async () => {
  if (process.platform !== 'win32') {
    throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_PICKER_UNSUPPORTED', 501)
  }
  try {
    const selected = await requestWarmNativePick('video')
    if (!videoExtensions.has(extname(selected).toLowerCase())) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_SELECTION_INVALID', 400)
    }
    return selected
  } catch (error) {
    if (error instanceof LocalRuntimeError) throw error
    throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_PICKER_UNAVAILABLE', 503)
  }
}

export const pickWindowsVideoOrFolder = async () => {
  if (process.platform !== 'win32') {
    throw new LocalRuntimeError('LOCAL_MEDIA_PICKER_UNSUPPORTED', 501)
  }
  try {
    return await requestWarmNativePick('media')
  } catch (error) {
    if (error instanceof LocalRuntimeError) throw error
    throw new LocalRuntimeError('LOCAL_MEDIA_PICKER_UNAVAILABLE', 503)
  }
}

/** @param {string} root */
export const inspectFolderReadOnly = async (root) => {
  let rootStat
  try {
    rootStat = await stat(root)
  } catch {
    throw new LocalRuntimeError('LOCAL_FOLDER_PERMISSION_DENIED', 403)
  }
  if (!rootStat.isDirectory()) {
    throw new LocalRuntimeError('LOCAL_FOLDER_SELECTION_INVALID', 400)
  }
  let total = 0
  /** @param {string} current */
  const walk = async (current) => {
    let directory
    try {
      directory = await opendir(current)
      for await (const entry of directory) {
        if (entry.isSymbolicLink()) continue
        if (entry.name.startsWith('._')) continue
        const entryPath = resolve(current, entry.name)
        if (entry.isDirectory()) await walk(entryPath)
        else if (entry.isFile() && videoExtensions.has(extname(entry.name).toLowerCase())) total += 1
      }
    } catch {
      throw new LocalRuntimeError('LOCAL_FOLDER_PERMISSION_DENIED', 403)
    }
  }
  await walk(root)
  return { total }
}

/** @param {unknown} value @param {number} [max] */
const safeLabel = (value, max = 100) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= max &&
  ![...value].some((character) => [0, 47, 92].includes(character.charCodeAt(0))) &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value)

const MAX_JIANYING_DRAFT_WALK_UP = 4
const MAX_JIANYING_DRAFT_BYTES = 256n * 1024n * 1024n

/** @param {string} folder */
const inspectJianyingDraftFolder = async (folder) => {
  const absolutePath = resolve(folder)
  const contentPath = resolve(absolutePath, 'draft_content.json')
  if (!isAbsolute(absolutePath) || !isInside(absolutePath, contentPath)) return null
  try {
    const requestedFolderMetadata = await lstat(absolutePath, { bigint: true })
    const requestedContentMetadata = await lstat(contentPath, { bigint: true })
    const actualFolder = realpathSync.native(absolutePath)
    const actualContent = realpathSync.native(contentPath)
    if (
      !await sameResolvedObject(absolutePath, actualFolder, requestedFolderMetadata) ||
      !await sameResolvedObject(contentPath, actualContent, requestedContentMetadata)
    ) return null
    if (
      !requestedFolderMetadata.isDirectory() ||
      !requestedContentMetadata.isFile() ||
      requestedContentMetadata.size <= 0n ||
      requestedContentMetadata.size > MAX_JIANYING_DRAFT_BYTES
    ) return null
    return absolutePath
  } catch {
    return null
  }
}

/** @param {string} selectedPath */
const resolveJianyingDraftFolder = async (selectedPath) => {
  if (!isAbsolute(selectedPath)) {
    throw new LocalRuntimeError('LOCAL_JIANYING_DRAFT_INVALID', 400)
  }
  let current = resolve(selectedPath)
  for (let depth = 0; depth <= MAX_JIANYING_DRAFT_WALK_UP; depth += 1) {
    const draftFolder = await inspectJianyingDraftFolder(current)
    if (draftFolder) return draftFolder
    const parent = dirname(current)
    if (parent === current) break
    current = parent
  }
  throw new LocalRuntimeError('LOCAL_JIANYING_DRAFT_INVALID', 400)
}

/**
 * @param {{
 *   authorizationRepository: {
 *     save: (record: Record<string, any>) => unknown | Promise<unknown>,
 *     get: (id: string) => Record<string, any> | null,
 *     list: () => Record<string, any>[],
 *     remove: (id: string) => unknown,
 *   },
 *   dataRoot?: string,
 *   pickFolder?: () => Promise<string>,
 *   pickAudioFile?: () => Promise<string>,
 *   pickVideoFile?: () => Promise<string>,
 *   pickVideoOrFolder?: () => Promise<string>,
 *   inspectFolderReadOnly?: (root: string) => Promise<{total: number}>,
 * }} dependencies
 */
export const createLocalAuthorizationCapability = ({
  authorizationRepository,
  dataRoot,
  pickFolder = pickWindowsFolder,
  pickAudioFile = pickWindowsAudioFile,
  pickVideoFile = pickWindowsVideoFile,
  pickVideoOrFolder = pickWindowsVideoOrFolder,
  inspectFolderReadOnly: inspect = inspectFolderReadOnly,
}) => ({
  /** @param {{projectId: string, folderLabel?: string, readOnlyConfirmed: boolean, absolutePath?: string, sourceType?: 'folder' | 'file' | 'auto'}} input */
  async authorizeMaterials(input) {
    if (input?.readOnlyConfirmed !== true) {
      throw new LocalRuntimeError('LOCAL_READ_ONLY_CONFIRMATION_REQUIRED', 400)
    }
    const selectedAbsolutePath = typeof input.absolutePath === 'string' && isAbsolute(input.absolutePath)
      ? resolve(input.absolutePath)
      : input.sourceType === 'file'
        ? await pickVideoFile()
        : input.sourceType === 'auto'
          ? await pickVideoOrFolder()
          : await pickFolder()
    const selectedPaths = String(selectedAbsolutePath)
      .split(/\r?\n/u)
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => resolve(part))
    if (selectedPaths.length === 0 || selectedPaths.some((path) => !isAbsolute(path))) {
      throw new LocalRuntimeError('LOCAL_FOLDER_SELECTION_INVALID', 400)
    }
    /** @type {string[]} */
    const selectedFileNames = []
    let absolutePath
    let isFileSelection = false
    if (selectedPaths.length > 1) {
      const parents = new Set()
      for (const selectedPath of selectedPaths) {
        const selectedStat = await stat(selectedPath).catch(() => null)
        if (selectedStat?.isFile() !== true || !videoExtensions.has(extname(selectedPath).toLowerCase())) {
          throw new LocalRuntimeError('LOCAL_VIDEO_SELECTION_INVALID', 400)
        }
        parents.add(dirname(selectedPath))
        selectedFileNames.push(basename(selectedPath))
      }
      if (parents.size !== 1) {
        throw new LocalRuntimeError('LOCAL_VIDEO_SELECTION_INVALID', 400)
      }
      absolutePath = [...parents][0]
      isFileSelection = true
    } else {
      const selectedStat = await stat(selectedPaths[0]).catch(() => null)
      const isSingleFile = selectedStat?.isFile() === true
      if (isSingleFile && !videoExtensions.has(extname(selectedPaths[0]).toLowerCase())) {
        throw new LocalRuntimeError('LOCAL_VIDEO_SELECTION_INVALID', 400)
      }
      absolutePath = isSingleFile ? dirname(selectedPaths[0]) : selectedPaths[0]
      if (isSingleFile) selectedFileNames.push(basename(selectedPaths[0]))
      isFileSelection = isSingleFile
    }
    const requestedLabel = input.folderLabel
    const folderLabel = safeLabel(requestedLabel)
      ? /** @type {string} */ (requestedLabel).trim()
      : basename(resolve(absolutePath)).slice(0, 100)
    if (!safeLabel(folderLabel)) {
      throw new LocalRuntimeError('LOCAL_FOLDER_LABEL_INVALID', 400)
    }
    const total = selectedFileNames.length > 0 ? selectedFileNames.length : (await inspect(absolutePath)).total
    if (!Number.isSafeInteger(total) || total < 0) {
      throw new LocalRuntimeError('LOCAL_FOLDER_INSPECTION_INVALID', 500)
    }
    const authorizationId = randomUUID()
    await authorizationRepository.save({
      id: authorizationId,
      projectId: input.projectId,
      absolutePath: resolve(absolutePath),
      ...(selectedFileNames.length === 1 ? { selectedFileName: selectedFileNames[0] } : {}),
      ...(selectedFileNames.length > 1 ? { selectedFileNames } : {}),
      label: folderLabel,
      status: 'authorized',
      total,
      readOnly: true,
      createdAt: new Date().toISOString(),
    })
    return {
      authorizationId,
      authorized: true,
      readOnlyConfirmed: true,
      folderLabel,
      sourceType: /** @type {'file' | 'folder'} */ (isFileSelection ? 'file' : 'folder'),
      total,
      analyzed: 0,
      queued: total,
      failed: 0,
      analysisStatus: total > 0 ? 'queued' : 'ready',
      lastScanAt: new Date().toISOString(),
      assets: [],
    }
  },
  /** @param {{projectId: string, readOnlyConfirmed: boolean, absolutePath?: string}} input */
  async authorizeBgm(input) {
    if (input?.readOnlyConfirmed !== true) {
      throw new LocalRuntimeError('LOCAL_READ_ONLY_CONFIRMATION_REQUIRED', 400)
    }
    const absolutePath = typeof input.absolutePath === 'string' && isAbsolute(input.absolutePath)
      ? resolve(input.absolutePath)
      : await pickAudioFile()
    if (!isAbsolute(absolutePath) || !audioExtensions.has(extname(absolutePath).toLowerCase())) {
      throw new LocalRuntimeError('LOCAL_AUDIO_SELECTION_INVALID', 400)
    }
    let fileStat
    try {
      fileStat = await stat(absolutePath)
    } catch {
      throw new LocalRuntimeError('LOCAL_AUDIO_PERMISSION_DENIED', 403)
    }
    if (!fileStat.isFile()) {
      throw new LocalRuntimeError('LOCAL_AUDIO_SELECTION_INVALID', 400)
    }
    const extension = extname(resolve(absolutePath)).toLowerCase().replace('.', '')
    const fileName = basename(resolve(absolutePath))
    const fallbackLabel = extension && audioExtensions.has(`.${extension}`)
      ? `已授权本机音频（.${extension}）`
      : '已授权本机音频'
    const bgmLabel = safeLabel(fileName) ? fileName : fallbackLabel
    if (!safeLabel(bgmLabel)) {
      throw new LocalRuntimeError('LOCAL_AUDIO_LABEL_INVALID', 400)
    }
    const authorizationId = randomUUID()
    await authorizationRepository.save({
      id: authorizationId,
      projectId: input.projectId,
      absolutePath: resolve(absolutePath),
      label: bgmLabel,
      purpose: 'bgm',
      status: 'authorized',
      total: 1,
      readOnly: true,
      createdAt: new Date().toISOString(),
    })
    return {
      authorizationId,
      bgmLabel,
    }
  },
  /** @param {{projectId: string, readOnlyConfirmed: boolean, absolutePath?: string}} input */
  async authorizeReferenceVideo(input) {
    if (input?.readOnlyConfirmed !== true) {
      throw new LocalRuntimeError('LOCAL_READ_ONLY_CONFIRMATION_REQUIRED', 400)
    }
    const absolutePath = typeof input.absolutePath === 'string' && isAbsolute(input.absolutePath)
      ? resolve(input.absolutePath)
      : await pickVideoFile()
    if (!isAbsolute(absolutePath) || !videoExtensions.has(extname(absolutePath).toLowerCase())) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_SELECTION_INVALID', 400)
    }
    let fileStat
    try {
      fileStat = await stat(absolutePath)
    } catch {
      throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_PERMISSION_DENIED', 403)
    }
    if (!fileStat.isFile()) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_SELECTION_INVALID', 400)
    }
    const extension = extname(resolve(absolutePath)).toLowerCase()
    const label = extension && videoExtensions.has(extension)
      ? `已授权本机视频（${extension}）`
      : '已授权本机视频'
    if (!safeLabel(label)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_LABEL_INVALID', 400)
    }
    const authorizationId = randomUUID()
    await authorizationRepository.save({
      id: authorizationId,
      projectId: input.projectId,
      absolutePath: resolve(absolutePath),
      label,
      status: 'authorized',
      total: 1,
      readOnly: true,
      createdAt: new Date().toISOString(),
    })
    return { authorizationId, label }
  },
  /** @param {{projectId: string, readOnlyConfirmed: boolean, absolutePath?: string, purpose?: 'reusable_template_draft'}} input */
  async authorizeJianyingDraft(input) {
    if (input?.readOnlyConfirmed !== true) {
      throw new LocalRuntimeError('LOCAL_READ_ONLY_CONFIRMATION_REQUIRED', 400)
    }
    const selectedPath = typeof input.absolutePath === 'string' && isAbsolute(input.absolutePath)
      ? resolve(input.absolutePath)
      : await pickFolder()
    const absolutePath = await resolveJianyingDraftFolder(selectedPath)
    // Jianying draft authorizations cross the provider route as an opaque
    // capability token; keep other local authorization IDs unchanged.
    const authorizationId = `ovauth_${randomUUID().replaceAll('-', '')}`
    await authorizationRepository.save({
      id: authorizationId,
      projectId: input.projectId,
      absolutePath,
      label: '已授权剪映草稿',
      status: 'authorized',
      total: 1,
      readOnly: true,
      purpose: input.purpose === 'reusable_template_draft' ? input.purpose : 'jianying_draft',
      createdAt: new Date().toISOString(),
    })
    return { authorizationId, label: '已授权剪映草稿' }
  },
  /** @param {{projectId: string, absolutePath?: string, file?: {name?: string, size?: number, arrayBuffer: () => Promise<ArrayBuffer>}}} input */
  async uploadReferenceVideo(input) {
    if (!dataRoot || !isAbsolute(dataRoot)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_UNAVAILABLE', 503)
    }
    let sourceAbsolutePath = typeof input.absolutePath === 'string' && isAbsolute(input.absolutePath)
      ? resolve(input.absolutePath)
      : null
    if (!sourceAbsolutePath && !input.file) {
      const picked = await pickVideoFile()
      if (!isAbsolute(picked)) {
        throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_SELECTION_INVALID', 400)
      }
      sourceAbsolutePath = resolve(picked)
    }
    let extension
    let size
    /** @type {(() => Promise<Buffer>) | null} */
    let readSource = null
    if (sourceAbsolutePath) {
      extension = extname(sourceAbsolutePath).toLowerCase()
      let sourceStat
      try {
        sourceStat = await stat(sourceAbsolutePath)
      } catch {
        throw new LocalRuntimeError('LOCAL_REFERENCE_VIDEO_PERMISSION_DENIED', 403)
      }
      if (!sourceStat.isFile()) {
        throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_EXTENSION_UNSUPPORTED', 400)
      }
      size = sourceStat.size
      readSource = () => readFile(sourceAbsolutePath)
    } else {
      const file = input.file
      if (!file) throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_EXTENSION_UNSUPPORTED', 400)
      extension = extname(String(file.name ?? '')).toLowerCase()
      size = Number(file.size)
      readSource = async () => Buffer.from(await file.arrayBuffer())
    }
    if (!videoExtensions.has(extension)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_EXTENSION_UNSUPPORTED', 400)
    }
    if (!Number.isSafeInteger(size) || size <= 0 || size > referenceUploadMaxBytes) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_TOO_LARGE', 413)
    }
    const uploadRoot = resolve(dataRoot, 'reference-uploads')
    const projectRoot = resolve(uploadRoot, input.projectId)
    if (!isInside(dataRoot, projectRoot)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_TARGET_INVALID', 500)
    }
    let usedBytes = 0
    /** @param {string} current */
    const addDirectoryBytes = async (current) => {
      const directory = await opendir(current)
      for await (const entry of directory) {
        const entryPath = resolve(current, entry.name)
        if (entry.isDirectory()) await addDirectoryBytes(entryPath)
        else if (entry.isFile()) usedBytes += (await stat(entryPath)).size
      }
    }
    try {
      await mkdir(projectRoot, { recursive: true, mode: 0o700 })
      await addDirectoryBytes(uploadRoot)
    } catch (error) {
      if (errorCode(error) !== 'ENOENT') {
        throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_STORAGE_UNAVAILABLE', 503)
      }
      await mkdir(projectRoot, { recursive: true, mode: 0o700 })
    }
    if (usedBytes + size > referenceUploadQuotaBytes) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_QUOTA_EXCEEDED', 413)
    }
    const authorizationId = randomUUID()
    const targetPath = resolve(projectRoot, `${authorizationId}${extension}`)
    const temporaryPath = `${targetPath}.${randomUUID()}.tmp`
    if (!isInside(dataRoot, targetPath)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_TARGET_INVALID', 500)
    }
    try {
      if (sourceAbsolutePath) {
        await copyFile(sourceAbsolutePath, temporaryPath)
        await chmod(temporaryPath, 0o600).catch(() => {})
      } else {
        const buffer = await readSource()
        if (buffer.length !== size || buffer.length > referenceUploadMaxBytes) {
          throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_TOO_LARGE', 413)
        }
        await writeFile(temporaryPath, buffer, { flag: 'wx', mode: 0o600 })
      }
      const copiedStat = await stat(temporaryPath)
      if (!Number.isSafeInteger(copiedStat.size) || copiedStat.size <= 0 || copiedStat.size > referenceUploadMaxBytes) {
        throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_TOO_LARGE', 413)
      }
      await rename(temporaryPath, targetPath)
      await chmod(targetPath, 0o600).catch(() => {})
      await authorizationRepository.save({
        id: authorizationId,
        projectId: input.projectId,
        absolutePath: targetPath,
        label: '已上传参考视频',
        status: 'authorized',
        total: 1,
        readOnly: true,
        createdAt: new Date().toISOString(),
      })
      const previousUploads = authorizationRepository.list().filter(
        (/** @type {Record<string, any>} */ authorization) =>
          authorization.id !== authorizationId &&
          authorization.projectId === input.projectId &&
          typeof authorization.absolutePath === 'string' &&
          isInside(uploadRoot, authorization.absolutePath),
      )
      for (const previous of previousUploads) {
        await unlink(previous.absolutePath).catch((error) => {
          if (errorCode(error) !== 'ENOENT') throw error
        })
        authorizationRepository.remove(previous.id)
      }
      return { authorizationId, label: '已上传参考视频' }
    } catch (error) {
      await unlink(temporaryPath).catch(() => {})
      await unlink(targetPath).catch(() => {})
      authorizationRepository.remove(authorizationId)
      if (error instanceof LocalRuntimeError) throw error
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_FAILED', 500)
    }
  },
  /** @param {{projectId: string, authorizationId: string}} input */
  async revokeReferenceUpload(input) {
    if (!dataRoot || !isAbsolute(dataRoot)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_UNAVAILABLE', 503)
    }
    const authorization = authorizationRepository.get(input.authorizationId)
    const uploadRoot = resolve(dataRoot, 'reference-uploads')
    if (
      !authorization ||
      authorization.projectId !== input.projectId ||
      typeof authorization.absolutePath !== 'string' ||
      !isInside(uploadRoot, authorization.absolutePath)
    ) return false
    await unlink(authorization.absolutePath).catch((error) => {
      if (errorCode(error) !== 'ENOENT') throw error
    })
    authorizationRepository.remove(input.authorizationId)
    return true
  },
  /** @param {{projectId: string}} input */
  async deleteProjectAuthorizations(input) {
    if (!dataRoot || !isAbsolute(dataRoot)) {
      throw new LocalRuntimeError('LOCAL_RUNTIME_DATA_ROOT_REQUIRED', 500)
    }
    if (!safeLabel(input?.projectId, 160)) {
      throw new LocalRuntimeError('LOCAL_PROJECT_ID_INVALID', 400)
    }
    const uploadRoot = resolve(dataRoot, 'reference-uploads')
    const projectUploadRoot = resolve(uploadRoot, input.projectId)
    if (!isInside(uploadRoot, projectUploadRoot)) {
      throw new LocalRuntimeError('LOCAL_REFERENCE_UPLOAD_TARGET_INVALID', 500)
    }
    await rm(projectUploadRoot, { recursive: true, force: true })
    for (const authorization of authorizationRepository.list()) {
      if (authorization.projectId === input.projectId) {
        authorizationRepository.remove(authorization.id)
      }
    }
    return true
  },
})
