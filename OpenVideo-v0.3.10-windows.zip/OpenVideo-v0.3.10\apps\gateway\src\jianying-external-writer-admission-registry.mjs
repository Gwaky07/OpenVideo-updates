const PROVIDER = /^[a-z][a-z0-9_-]{2,63}$/u
const COMMIT = /^[a-f0-9]{40}$/u
const FINGERPRINT = /^[a-f0-9]{64}$/u
const PROFILE = /^[A-Za-z0-9][A-Za-z0-9._-]{2,95}$/u
const REVISION = /^[A-Za-z0-9][A-Za-z0-9._-]{2,95}$/u
const CAPABILITY = /^[a-z][a-z0-9_.-]{2,95}$/u
const IDENTITY_KEYS = Object.freeze([
  'adapter_revision',
  'build_digest',
  'capability_snapshot',
  'catalog_fingerprint',
  'desktop_binding_fingerprint',
  'evidence_fingerprint',
  'profile_id',
  'provider_commit',
])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
const clone = (value) => JSON.parse(JSON.stringify(value))

/** @param {unknown} value @returns {any} */
const deepFreeze = (value) => {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value
  Object.freeze(value)
  for (const child of Object.values(value)) deepFreeze(child)
  return value
}

/** @param {unknown} value @returns {string} */
const canonical = (value) => {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`
  if (!isRecord(value)) return JSON.stringify(value)
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`
}

/** @param {unknown} values */
const normalizeCapabilities = (values) => {
  if (!Array.isArray(values) || values.length === 0 || values.length > 64 ||
      values.some((value) => typeof value !== 'string' || !CAPABILITY.test(value)) ||
      new Set(values).size !== values.length) throw new Error('JY200_CAPABILITY_SET_INVALID')
  return Object.freeze([...values].sort())
}

/** @param {unknown} value */
const normalizeIdentity = (value) => {
  if (!isRecord(value) || Object.keys(value).sort().join('\0') !== IDENTITY_KEYS.join('\0') ||
      typeof value.provider_commit !== 'string' || !COMMIT.test(value.provider_commit) ||
      typeof value.build_digest !== 'string' || !FINGERPRINT.test(value.build_digest) ||
      typeof value.desktop_binding_fingerprint !== 'string' || !FINGERPRINT.test(value.desktop_binding_fingerprint) ||
      typeof value.catalog_fingerprint !== 'string' || !FINGERPRINT.test(value.catalog_fingerprint) ||
      typeof value.evidence_fingerprint !== 'string' || !FINGERPRINT.test(value.evidence_fingerprint) ||
      typeof value.profile_id !== 'string' || !PROFILE.test(value.profile_id) ||
      typeof value.adapter_revision !== 'string' || !REVISION.test(value.adapter_revision) ||
      !isRecord(value.capability_snapshot) || Object.keys(value.capability_snapshot).join('\0') !== 'capabilities') {
    throw new Error('JY200_PROVIDER_IDENTITY_INVALID')
  }
  const identity = clone(value)
  identity.capability_snapshot.capabilities = [...normalizeCapabilities(identity.capability_snapshot.capabilities)]
  return deepFreeze(identity)
}

/**
 * Create one process-private admission authority. Handles are empty frozen
 * objects whose meaning exists only in this authority's WeakMap; callers
 * cannot recreate or serialize them.
 */
/** @param {{resolveCurrentIdentity?: (provider: string) => Promise<unknown>|unknown}} [options] */
export const createTrustedExternalWriterAdmissionAuthority = ({ resolveCurrentIdentity } = {}) => {
  if (typeof resolveCurrentIdentity !== 'function') throw new Error('JY200_CURRENT_IDENTITY_READER_REQUIRED')
  /** @type {WeakMap<object, {provider: string, identity: Record<string, any>, identityCanonical: string, revoked: boolean}>} */
  const records = new WeakMap()
  const registry = Object.freeze({
    /** @param {unknown} handle */
    async isCurrent(handle) {
      if (!handle || typeof handle !== 'object') return false
      const record = records.get(/** @type {object} */ (handle))
      if (!record || record.revoked === true) return false
      try {
        const currentIdentity = await resolveCurrentIdentity(record.provider)
        return canonical(normalizeIdentity(currentIdentity)) === record.identityCanonical
      } catch { return false }
    },
    /** @param {unknown} handle */
    async describe(handle) {
      if (!await this.isCurrent(handle)) return null
      const record = records.get(/** @type {object} */ (handle))
      if (!record) return null
      return Object.freeze({
        provider: record.provider,
        commit: record.identity.provider_commit,
        capabilities: record.identity.capability_snapshot.capabilities,
        identity: record.identity,
      })
    },
  })
  return Object.freeze({
    registry,
    /** @param {{provider: unknown, identity: unknown}} input */
    issue({ provider, identity }) {
      if (typeof provider !== 'string' || !PROVIDER.test(provider)) throw new Error('JY200_PROVIDER_INVALID')
      const normalized = normalizeIdentity(identity)
      const handle = Object.freeze({})
      records.set(handle, {
        provider,
        identity: normalized,
        identityCanonical: canonical(normalized),
        revoked: false,
      })
      return handle
    },
    /** @param {unknown} handle */
    revoke(handle) {
      if (!handle || typeof handle !== 'object') return false
      const record = records.get(/** @type {object} */ (handle))
      if (!record || record.revoked === true) return false
      record.revoked = true
      return true
    },
  })
}
