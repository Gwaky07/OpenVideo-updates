import { createHash } from 'node:crypto'

import { isCreativeBeatIntent } from './creative-retrieval.mjs'
import { isSafeCreativeText } from './creative-text-safety.mjs'
import { isDirectorCandidate } from './director-contracts.mjs'

export const CREATIVE_AB_RUBRIC_PROFILE = 'creative-planning-ab-v1'
export const CREATIVE_AB_STABLE_RUN_COUNT = 3

const safeIdPattern = /^[A-Za-z0-9._:-]{1,160}$/u
const sha256Pattern = /^[a-f0-9]{64}$/u
const gitCommitPattern = /^[a-f0-9]{40}$/u
const scoreWeights = Object.freeze({
  preferredCandidate: 0.3,
  evidence: 0.2,
  assetKinds: 0.15,
  sourceRange: 0.1,
  independentJudge: 0.25,
})
const gateKeys = Object.freeze([
  'flag_off_unchanged', 'b_semantic_not_lower', 'b_role_rhythm_higher',
  'b_semantic_threshold', 'b_role_rhythm_threshold', 'source_ranges_valid',
])
const evaluationKeys = Object.freeze([
  'schema_version', 'rubric_profile', 'benchmark_id', 'benchmark_fingerprint',
  'model_fingerprint', 'capability_snapshot_fingerprint', 'knowledge_snapshot_fingerprint',
  'flag_off_output_difference_count', 'thresholds', 'verdict', 'gates', 'variants',
])
const thresholdKeys = Object.freeze(['minimum_semantic_score', 'minimum_role_rhythm_score'])
const aggregateKeys = Object.freeze([
  'semantic_score', 'role_rhythm_score', 'preferred_candidate_rate',
  'invalid_source_range_count', 'cases',
])
const caseScoreKeys = Object.freeze([
  'case_id', 'selected_candidate_id', 'semantic_score', 'role_rhythm_score',
  'preferred_candidate_matched', 'source_range_valid', 'judge_reason',
])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const isSafeId = (value) => typeof value === 'string' && safeIdPattern.test(value)
/** @param {unknown} value @param {number} [maximumLength] */
const isSafeText = (value, maximumLength = 200) => isSafeCreativeText(value, maximumLength, { trimmed: true })
/** @param {unknown} value */
const isUnitScore = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1
/** @param {unknown} value */
const isSafeStringList = (value) => Array.isArray(value) && value.length > 0 && value.length <= 8 &&
  new Set(value).size === value.length && value.every((entry) => isSafeText(entry, 80))
/** @param {Record<string, any>} value @param {readonly string[]} keys */
const hasExactKeys = (value, keys) => Object.keys(value).length === keys.length &&
  keys.every((key) => Object.hasOwn(value, key))

/** @param {unknown} value */
const isBenchmarkCandidate = (value) => isRecord(value) &&
  Object.keys(value).length === 2 &&
  isDirectorCandidate(value.director) &&
  isSafeText(value.director.source, 240) &&
  isSafeText(value.director.summary, 500) &&
  Array.isArray(value.director.tags) && value.director.tags.every((/** @type {unknown} */ entry) => isSafeText(entry, 80)) &&
  isRecord(value.evidence) &&
  Object.keys(value.evidence).length === 4 &&
  isSafeStringList(value.evidence.asset_kinds) &&
  isSafeStringList(value.evidence.shot_roles) &&
  isSafeStringList(value.evidence.pacings) &&
  isSafeStringList(value.evidence.keywords)

/** @param {unknown} value */
const isBenchmarkCase = (value) => {
  if (!isRecord(value) || Object.keys(value).length !== 5) return false
  if (!isSafeId(value.case_id) || !isRecord(value.sentence) ||
      Object.keys(value.sentence).length !== 2 || !isSafeId(value.sentence.id) ||
      !isSafeText(value.sentence.text, 4_000) || !isCreativeBeatIntent(value.intent)) return false
  if (!isRecord(value.expected) || Object.keys(value.expected).length !== 5 ||
      !isSafeStringList(value.expected.preferred_candidate_ids) ||
      !isSafeStringList(value.expected.required_asset_kinds) ||
      !isSafeText(value.expected.shot_role, 40) || !isSafeText(value.expected.pacing, 40) ||
      !isSafeStringList(value.expected.evidence_keywords)) return false
  if (!Array.isArray(value.candidates) || value.candidates.length < 3 || value.candidates.length > 10 ||
      !value.candidates.every(isBenchmarkCandidate)) return false
  const candidateIds = value.candidates.map((entry) => entry.director.candidate_id)
  return new Set(candidateIds).size === candidateIds.length &&
    value.expected.preferred_candidate_ids.every((/** @type {string} */ candidateId) => candidateIds.includes(candidateId))
}

/** @param {unknown} value */
export const validateCreativeAbBenchmark = (value) => {
  if (!isRecord(value) || Object.keys(value).length !== 7 || value.schema_version !== 1 ||
      value.rubric_profile !== CREATIVE_AB_RUBRIC_PROFILE || !isSafeId(value.benchmark_id) ||
      !isRecord(value.flag_off_baseline) || Object.keys(value.flag_off_baseline).length !== 3 ||
      !gitCommitPattern.test(value.flag_off_baseline.source_commit) ||
      !sha256Pattern.test(value.flag_off_baseline.model_fingerprint) ||
      !isRecord(value.flag_off_baseline.selected_candidate_ids) ||
      !Array.isArray(value.allowed_capability_ids) || value.allowed_capability_ids.length === 0 ||
      value.allowed_capability_ids.length > 8 || !value.allowed_capability_ids.every(isSafeId) ||
      new Set(value.allowed_capability_ids).size !== value.allowed_capability_ids.length ||
      !Array.isArray(value.cases) || value.cases.length < 3 || value.cases.length > 30 ||
      !value.cases.every(isBenchmarkCase) ||
      !isRecord(value.thresholds) || Object.keys(value.thresholds).length !== 3 ||
      !isUnitScore(value.thresholds.minimum_semantic_score) ||
      !isUnitScore(value.thresholds.minimum_role_rhythm_score) ||
      !Number.isSafeInteger(value.thresholds.stable_run_count) ||
      value.thresholds.stable_run_count !== CREATIVE_AB_STABLE_RUN_COUNT) {
    throw new Error('CREATIVE_AB_BENCHMARK_INVALID')
  }
  const caseIds = value.cases.map((entry) => entry.case_id)
  const sentenceIds = value.cases.map((entry) => entry.sentence.id)
  const baselineCaseIds = Object.keys(value.flag_off_baseline.selected_candidate_ids)
  const baselineMatches = baselineCaseIds.length === caseIds.length &&
    baselineCaseIds.every((caseId) => caseIds.includes(caseId)) &&
    value.cases.every((benchmarkCase) => benchmarkCase.candidates.some((/** @type {Record<string, any>} */ entry) =>
      entry.director.candidate_id === value.flag_off_baseline.selected_candidate_ids[benchmarkCase.case_id]))
  if (new Set(caseIds).size !== caseIds.length || new Set(sentenceIds).size !== sentenceIds.length || !baselineMatches) {
    throw new Error('CREATIVE_AB_BENCHMARK_INVALID')
  }
  if (value.cases.some((benchmarkCase, index) =>
    benchmarkCase.sentence.id !== `sentence-${String(index + 1).padStart(3, '0')}`)) {
    throw new Error('CREATIVE_AB_BENCHMARK_INVALID')
  }
  return structuredClone(value)
}

/** @param {Record<string, any>} benchmark */
export const fingerprintCreativeAbBenchmark = (benchmark) => createHash('sha256')
  .update(JSON.stringify(validateCreativeAbBenchmark(benchmark)))
  .digest('hex')

/** @param {Record<string, any>} benchmark @param {unknown} rankings */
const normalizeRankings = (benchmark, rankings) => {
  if (!isRecord(rankings) || Object.keys(rankings).length !== benchmark.cases.length) {
    throw new Error('CREATIVE_AB_OBSERVATION_INVALID')
  }
  const normalized = new Map()
  for (const benchmarkCase of benchmark.cases) {
    const candidateIds = new Set(benchmarkCase.candidates.map((/** @type {Record<string, any>} */ entry) => entry.director.candidate_id))
    const ranked = rankings[benchmarkCase.case_id]
    if (!Array.isArray(ranked) || ranked.length === 0 || ranked.length > 3 ||
        new Set(ranked).size !== ranked.length || !ranked.every((candidateId) =>
          isSafeId(candidateId) && candidateIds.has(candidateId))) {
      throw new Error('CREATIVE_AB_OBSERVATION_INVALID')
    }
    normalized.set(benchmarkCase.case_id, [...ranked])
  }
  return normalized
}

/** @param {Record<string, any>} benchmark @param {unknown} rankings @param {string} modelFingerprint */
export const measureCreativeFlagOffDrift = (benchmark, rankings, modelFingerprint) => {
  const validated = validateCreativeAbBenchmark(benchmark)
  const normalized = normalizeRankings(validated, rankings)
  let differenceCount = modelFingerprint === validated.flag_off_baseline.model_fingerprint ? 0 : 1
  for (const benchmarkCase of validated.cases) {
    if (normalized.get(benchmarkCase.case_id)?.[0] !==
        validated.flag_off_baseline.selected_candidate_ids[benchmarkCase.case_id]) {
      differenceCount += 1
    }
  }
  return Object.freeze({
    source_commit: validated.flag_off_baseline.source_commit,
    model_fingerprint_matches: modelFingerprint === validated.flag_off_baseline.model_fingerprint,
    output_difference_count: differenceCount,
  })
}

/** @param {Record<string, any>} benchmark @param {unknown} assessments */
const normalizeJudgeAssessments = (benchmark, assessments) => {
  if (!Array.isArray(assessments)) throw new Error('CREATIVE_AB_JUDGE_INVALID')
  const knownCandidates = new Map(benchmark.cases.map((/** @type {Record<string, any>} */ benchmarkCase) => [
    benchmarkCase.case_id,
    new Set(benchmarkCase.candidates.map((/** @type {Record<string, any>} */ entry) => entry.director.candidate_id)),
  ]))
  const normalized = new Map()
  for (const assessment of assessments) {
    if (!isRecord(assessment) || Object.keys(assessment).length !== 4 ||
        !isSafeId(assessment.case_id) || !isSafeId(assessment.candidate_id) ||
        !knownCandidates.get(assessment.case_id)?.has(assessment.candidate_id) ||
        !isUnitScore(assessment.semantic_score) || !isSafeText(assessment.reason, 240)) {
      throw new Error('CREATIVE_AB_JUDGE_INVALID')
    }
    const key = `${assessment.case_id}\u0000${assessment.candidate_id}`
    if (normalized.has(key)) throw new Error('CREATIVE_AB_JUDGE_INVALID')
    normalized.set(key, structuredClone(assessment))
  }
  return normalized
}

/** @param {string[]} left @param {string[]} right */
const overlapRate = (left, right) => {
  const expected = new Set(left.map((entry) => entry.toLocaleLowerCase('zh-CN')))
  const observed = new Set(right.map((entry) => entry.toLocaleLowerCase('zh-CN')))
  return [...expected].filter((entry) => observed.has(entry)).length / expected.size
}

/** @param {Record<string, any>} benchmarkCase @param {string[]} ranking @param {Map<string, Record<string, any>>} judge */
const scoreCase = (benchmarkCase, ranking, judge) => {
  const selectedId = ranking[0]
  const candidate = benchmarkCase.candidates.find((/** @type {Record<string, any>} */ entry) => entry.director.candidate_id === selectedId)
  if (!candidate) throw new Error('CREATIVE_AB_OBSERVATION_INVALID')
  const assessment = judge.get(`${benchmarkCase.case_id}\u0000${selectedId}`)
  if (!assessment) throw new Error('CREATIVE_AB_JUDGE_INVALID')
  const preferredIndex = benchmarkCase.expected.preferred_candidate_ids.indexOf(selectedId)
  const preferredCandidate = preferredIndex < 0
    ? 0
    : 1 - preferredIndex / benchmarkCase.expected.preferred_candidate_ids.length
  const evidence = overlapRate(benchmarkCase.expected.evidence_keywords, candidate.evidence.keywords)
  const assetKinds = overlapRate(benchmarkCase.expected.required_asset_kinds, candidate.evidence.asset_kinds)
  const sourceRange = candidate.director.start >= 0 && candidate.director.end > candidate.director.start ? 1 : 0
  const semanticScore = Number((
    preferredCandidate * scoreWeights.preferredCandidate +
    evidence * scoreWeights.evidence +
    assetKinds * scoreWeights.assetKinds +
    sourceRange * scoreWeights.sourceRange +
    assessment.semantic_score * scoreWeights.independentJudge
  ).toFixed(6))
  const shotRoleMatched = candidate.evidence.shot_roles.includes(benchmarkCase.expected.shot_role)
  const pacingMatched = candidate.evidence.pacings.includes(benchmarkCase.expected.pacing)
  return Object.freeze({
    case_id: benchmarkCase.case_id,
    selected_candidate_id: selectedId,
    semantic_score: semanticScore,
    role_rhythm_score: Number(((Number(shotRoleMatched) + Number(pacingMatched)) / 2).toFixed(6)),
    preferred_candidate_matched: preferredIndex >= 0,
    source_range_valid: sourceRange === 1,
    judge_reason: assessment.reason,
  })
}

/** @param {Record<string, any>[]} cases */
const aggregate = (cases) => ({
  semantic_score: Number((cases.reduce((total, entry) => total + entry.semantic_score, 0) / cases.length).toFixed(6)),
  role_rhythm_score: Number((cases.reduce((total, entry) => total + entry.role_rhythm_score, 0) / cases.length).toFixed(6)),
  preferred_candidate_rate: Number((cases.filter((entry) => entry.preferred_candidate_matched).length / cases.length).toFixed(6)),
  invalid_source_range_count: cases.filter((entry) => !entry.source_range_valid).length,
})

/** @param {unknown} value */
const isCaseScore = (value) => isRecord(value) && hasExactKeys(value, caseScoreKeys) &&
  isSafeId(value.case_id) && isSafeId(value.selected_candidate_id) &&
  isUnitScore(value.semantic_score) && isUnitScore(value.role_rhythm_score) &&
  typeof value.preferred_candidate_matched === 'boolean' &&
  typeof value.source_range_valid === 'boolean' && isSafeText(value.judge_reason, 240)

/** @param {unknown} value */
const isAggregate = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, aggregateKeys) ||
      !isUnitScore(value.semantic_score) || !isUnitScore(value.role_rhythm_score) ||
      !isUnitScore(value.preferred_candidate_rate) ||
      !Number.isSafeInteger(value.invalid_source_range_count) || value.invalid_source_range_count < 0 ||
      !Array.isArray(value.cases) || value.cases.length === 0 || value.cases.length > 30 ||
      !value.cases.every(isCaseScore)) return false
  const caseIds = value.cases.map((entry) => entry.case_id)
  if (new Set(caseIds).size !== caseIds.length) return false
  const recomputed = aggregate(value.cases)
  return value.semantic_score === recomputed.semantic_score &&
    value.role_rhythm_score === recomputed.role_rhythm_score &&
    value.preferred_candidate_rate === recomputed.preferred_candidate_rate &&
    value.invalid_source_range_count === recomputed.invalid_source_range_count
}

/** @param {unknown} value */
export const isCreativeAbEvaluation = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, evaluationKeys) ||
      value.schema_version !== 1 || value.rubric_profile !== CREATIVE_AB_RUBRIC_PROFILE ||
      !isSafeId(value.benchmark_id) || !sha256Pattern.test(value.benchmark_fingerprint) ||
      !sha256Pattern.test(value.model_fingerprint) ||
      !sha256Pattern.test(value.capability_snapshot_fingerprint) ||
      !sha256Pattern.test(value.knowledge_snapshot_fingerprint) ||
      !Number.isSafeInteger(value.flag_off_output_difference_count) ||
      value.flag_off_output_difference_count < 0 ||
      !isRecord(value.thresholds) || !hasExactKeys(value.thresholds, thresholdKeys) ||
      !isUnitScore(value.thresholds.minimum_semantic_score) ||
      !isUnitScore(value.thresholds.minimum_role_rhythm_score) ||
      !['PASS', 'HOLD'].includes(value.verdict) ||
      !isRecord(value.gates) || !hasExactKeys(value.gates, gateKeys) ||
      !gateKeys.every((key) => typeof value.gates[key] === 'boolean') ||
      !isRecord(value.variants) || !hasExactKeys(value.variants, ['A', 'B']) ||
      !isAggregate(value.variants.A) || !isAggregate(value.variants.B)) return false
  const aIds = value.variants.A.cases.map((/** @type {Record<string, any>} */ entry) => entry.case_id)
  const bIds = value.variants.B.cases.map((/** @type {Record<string, any>} */ entry) => entry.case_id)
  if (aIds.length !== bIds.length || aIds.some((/** @type {string} */ caseId, /** @type {number} */ index) =>
    caseId !== bIds[index])) return false
  return value.gates.b_semantic_not_lower ===
      (value.variants.B.semantic_score >= value.variants.A.semantic_score) &&
    value.gates.b_role_rhythm_higher ===
      (value.variants.B.role_rhythm_score > value.variants.A.role_rhythm_score) &&
    value.gates.source_ranges_valid ===
      (value.variants.A.invalid_source_range_count === 0 && value.variants.B.invalid_source_range_count === 0) &&
    value.gates.flag_off_unchanged === (value.flag_off_output_difference_count === 0) &&
    value.gates.b_semantic_threshold ===
      (value.variants.B.semantic_score >= value.thresholds.minimum_semantic_score) &&
    value.gates.b_role_rhythm_threshold ===
      (value.variants.B.role_rhythm_score >= value.thresholds.minimum_role_rhythm_score) &&
    value.verdict === (gateKeys.every((key) => value.gates[key]) ? 'PASS' : 'HOLD')
}

/** @param {unknown} value */
export const isCreativeAbFailedAttempt = (value) => isRecord(value) &&
  hasExactKeys(value, ['schema_version', 'attempt_status', 'failure_code']) &&
  value.schema_version === 1 && value.attempt_status === 'failed' &&
  typeof value.failure_code === 'string' && /^[A-Z][A-Z0-9_]{2,120}$/u.test(value.failure_code)

/** @param {string} failureCode */
export const createCreativeAbFailedAttempt = (failureCode) => {
  const value = { schema_version: 1, attempt_status: 'failed', failure_code: failureCode }
  if (!isCreativeAbFailedAttempt(value)) throw new Error('CREATIVE_AB_FAILURE_CODE_INVALID')
  return Object.freeze(value)
}

/**
 * @param {{benchmark: Record<string, any>, aRankings: unknown, bRankings: unknown, judgeAssessments: unknown, modelFingerprint: string, capabilitySnapshotFingerprint: string, knowledgeSnapshotFingerprint: string, flagOffOutputDifferenceCount?: number}} input
 */
export const evaluateCreativeAbRun = (input) => {
  const benchmark = validateCreativeAbBenchmark(input?.benchmark)
  if (!sha256Pattern.test(input?.modelFingerprint) ||
      !sha256Pattern.test(input?.capabilitySnapshotFingerprint) ||
      !sha256Pattern.test(input?.knowledgeSnapshotFingerprint) ||
      !Number.isSafeInteger(input?.flagOffOutputDifferenceCount ?? 0) ||
      (input?.flagOffOutputDifferenceCount ?? 0) < 0) {
    throw new Error('CREATIVE_AB_OBSERVATION_INVALID')
  }
  const aRankings = normalizeRankings(benchmark, input.aRankings)
  const bRankings = normalizeRankings(benchmark, input.bRankings)
  const judge = normalizeJudgeAssessments(benchmark, input.judgeAssessments)
  const aCases = benchmark.cases.map((/** @type {Record<string, any>} */ benchmarkCase) => scoreCase(
    benchmarkCase,
    aRankings.get(benchmarkCase.case_id),
    judge,
  ))
  const bCases = benchmark.cases.map((/** @type {Record<string, any>} */ benchmarkCase) => scoreCase(
    benchmarkCase,
    bRankings.get(benchmarkCase.case_id),
    judge,
  ))
  const a = aggregate(aCases)
  const b = aggregate(bCases)
  const gates = {
    flag_off_unchanged: (input.flagOffOutputDifferenceCount ?? 0) === 0,
    b_semantic_not_lower: b.semantic_score >= a.semantic_score,
    b_role_rhythm_higher: b.role_rhythm_score > a.role_rhythm_score,
    b_semantic_threshold: b.semantic_score >= benchmark.thresholds.minimum_semantic_score,
    b_role_rhythm_threshold: b.role_rhythm_score >= benchmark.thresholds.minimum_role_rhythm_score,
    source_ranges_valid: a.invalid_source_range_count === 0 && b.invalid_source_range_count === 0,
  }
  return Object.freeze({
    schema_version: 1,
    rubric_profile: CREATIVE_AB_RUBRIC_PROFILE,
    benchmark_id: benchmark.benchmark_id,
    benchmark_fingerprint: fingerprintCreativeAbBenchmark(benchmark),
    model_fingerprint: input.modelFingerprint,
    capability_snapshot_fingerprint: input.capabilitySnapshotFingerprint,
    knowledge_snapshot_fingerprint: input.knowledgeSnapshotFingerprint,
    flag_off_output_difference_count: input.flagOffOutputDifferenceCount ?? 0,
    thresholds: Object.freeze({
      minimum_semantic_score: benchmark.thresholds.minimum_semantic_score,
      minimum_role_rhythm_score: benchmark.thresholds.minimum_role_rhythm_score,
    }),
    verdict: Object.values(gates).every(Boolean) ? 'PASS' : 'HOLD',
    gates: Object.freeze(gates),
    variants: Object.freeze({
      A: Object.freeze({ ...a, cases: Object.freeze(aCases) }),
      B: Object.freeze({ ...b, cases: Object.freeze(bCases) }),
    }),
  })
}

/** @param {unknown} runs */
export const evaluateCreativeRolloutWindow = (runs, { invalidReceiptCount = 0 } = {}) => {
  if (!Number.isSafeInteger(invalidReceiptCount) || invalidReceiptCount < 0) {
    throw new Error('CREATIVE_AB_RECEIPT_HISTORY_INVALID')
  }
  if (invalidReceiptCount > 0) {
    return Object.freeze({ verdict: 'HOLD', reason: 'receipt_invalid', qualifying_run_count: 0 })
  }
  if (!Array.isArray(runs) || runs.length < CREATIVE_AB_STABLE_RUN_COUNT) {
    return Object.freeze({ verdict: 'HOLD', reason: 'stable_window_incomplete', qualifying_run_count: 0 })
  }
  const window = runs.slice(-CREATIVE_AB_STABLE_RUN_COUNT)
  if (window.some(isCreativeAbFailedAttempt)) {
    return Object.freeze({ verdict: 'HOLD', reason: 'run_failed', qualifying_run_count: 0 })
  }
  if (window.some((run) => !isCreativeAbEvaluation(run))) {
    return Object.freeze({ verdict: 'HOLD', reason: 'receipt_invalid', qualifying_run_count: 0 })
  }
  const first = window[0]
  const identityMatches = window.every((run) =>
    run.rubric_profile === first?.rubric_profile &&
    run.benchmark_id === first?.benchmark_id &&
    run.benchmark_fingerprint === first?.benchmark_fingerprint &&
    run.model_fingerprint === first?.model_fingerprint &&
    run.capability_snapshot_fingerprint === first?.capability_snapshot_fingerprint &&
    run.knowledge_snapshot_fingerprint === first?.knowledge_snapshot_fingerprint &&
    run.thresholds.minimum_semantic_score === first?.thresholds.minimum_semantic_score &&
    run.thresholds.minimum_role_rhythm_score === first?.thresholds.minimum_role_rhythm_score)
  const passed = identityMatches && window.every((run) => run.verdict === 'PASS')
  return Object.freeze({
    verdict: passed ? 'ELIGIBLE' : 'HOLD',
    reason: passed ? 'stable_window_passed' : identityMatches ? 'run_failed' : 'identity_drift',
    qualifying_run_count: passed ? CREATIVE_AB_STABLE_RUN_COUNT : 0,
  })
}

export const creativeAbEvaluationContract = Object.freeze({ scoreWeights })
