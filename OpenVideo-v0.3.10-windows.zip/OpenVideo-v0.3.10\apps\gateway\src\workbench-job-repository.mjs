import { createHash, randomUUID } from 'node:crypto'
import { existsSync, realpathSync } from 'node:fs'
import { chmod, copyFile, mkdir, open, readFile, rename, rm, stat } from 'node:fs/promises'
import { basename, dirname, isAbsolute, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import { securePrivateRuntimeRoot } from './local-runtime.mjs'
import { assertCheckpoint, assertJobRecord } from './workbench-job-contracts.mjs'

const schemaVersion = 1
const jobSchemaVersion = 3
const defaultRepositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const terminalStatuses = new Set(['succeeded', 'failed', 'cancelled', 'timed_out'])
const dismissibleStatuses = new Set(['failed', 'cancelled', 'timed_out'])
const activeOwnerTokens = new Set()
const transientWindowsDeleteCodes = new Set(['EPERM', 'EBUSY', 'EACCES'])
const transientWindowsFileOperationAttempts = 60
const incompleteLockRecoveryMs = 1_000

/** @typedef {{projectId: string, jobId: string, dismissedAt: string}} JobDismissal */
/** @typedef {{schema_version: number, records: Record<string, any>[], dismissals: JobDismissal[]}} LockedDocument */

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} error */
const errorCode = (error) =>
  error && typeof error === 'object' && 'code' in error
    ? /** @type {{code?: unknown}} */ (error).code
    : undefined
/** @param {unknown} value */
const isTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @param {unknown} value */
const isIdentifier = (value) =>
  typeof value === 'string' && value.trim().length > 0 && value.length <= 200 && !value.includes('\u0000')
/** @param {string} candidate */
const canonicalizePotentialPath = (candidate) => {
  let existingAncestor = resolve(candidate)
  /** @type {string[]} */
  const missingSegments = []
  while (!existsSync(existingAncestor)) {
    const parent = dirname(existingAncestor)
    if (parent === existingAncestor) break
    missingSegments.unshift(basename(existingAncestor))
    existingAncestor = parent
  }
  const canonicalAncestor = existsSync(existingAncestor)
    ? realpathSync.native(existingAncestor)
    : existingAncestor
  return resolve(canonicalAncestor, ...missingSegments)
}
/** @param {string} parent @param {string} candidate */
const isInside = (parent, candidate) => {
  const child = relative(canonicalizePotentialPath(parent), canonicalizePotentialPath(candidate))
  return child === '' || (!child.startsWith('..') && !isAbsolute(child))
}
/** @param {unknown} value @returns {boolean} */
const isJsonValue = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true
  if (typeof value === 'number') return Number.isFinite(value)
  if (Array.isArray(value)) return value.length <= 10_000 && value.every(isJsonValue)
  return isRecord(value) &&
    Object.keys(value).length <= 10_000 &&
    Object.entries(value).every(([key, entry]) =>
      key.length > 0 && key.length <= 200 && !key.includes('\u0000') && isJsonValue(entry))
}
/** @param {unknown} value @param {string[]} keys @returns {value is Record<string, any>} */
const exactKeys = (value, keys) =>
  isRecord(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')

/** @param {unknown} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value)
  }
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value)
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`
  if (isRecord(value)) {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`
  }
  throw new TypeError('non_json_value')
}

/** @param {unknown} value */
const normalizeJobDocument = (value) => {
  if (!isRecord(value) || !Array.isArray(value.records)) return value
  const document = clone(value)
  if ([1, 2].includes(document.schema_version)) {
    for (const record of document.records) {
      if (
        isRecord(record) &&
        ['storyboard_generation', 'preview_generation'].includes(record.type) &&
        exactKeys(record.result, ['resourceId', 'summary'])
      ) {
        record.result = {
          resourceId: record.result.resourceId,
          summary: record.result.summary,
          outputFingerprint: createHash('sha256')
            .update(stableStringify(record.result))
            .digest('hex'),
          templateFingerprint: null,
          templateRevision: null,
        }
      }
    }
  } else if (document.schema_version !== jobSchemaVersion) {
    return value
  }
  // Older Jianying export jobs persisted the human-facing draft label as
  // resourceId. Current public contracts require an opaque ASCII identifier;
  // retain the record while removing that legacy value from public output.
  for (const record of document.records) {
    if (record?.type !== 'jianying_draft_export' || !isRecord(record.result)) continue
    const resourceId = record.result.resourceId
    if (typeof resourceId !== 'string' || /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u.test(resourceId)) continue
    record.result.resourceId = `draft-${createHash('sha256').update(resourceId).digest('hex').slice(0, 24)}`
  }
  document.schema_version = jobSchemaVersion
  if (!Array.isArray(document.dismissals)) document.dismissals = []
  return document
}

export class WorkbenchJobRepositoryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'WorkbenchJobRepositoryError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] */
const repositoryError = (code, status) => new WorkbenchJobRepositoryError(code, status)

/** @param {unknown} value */
const validJobDocument = (value) => {
  if (
    !isRecord(value) ||
    value.schema_version !== jobSchemaVersion ||
    !Array.isArray(value.records) ||
    !Array.isArray(value.dismissals)
  ) {
    return false
  }
  try {
    value.records.forEach(assertJobRecord)
    const recordIds = new Set(value.records.map((record) => `${record.projectId}\u0000${record.jobId}`))
    const dismissalIds = new Set()
    for (const dismissal of value.dismissals) {
      if (
        !exactKeys(dismissal, ['dismissedAt', 'jobId', 'projectId']) ||
        !isIdentifier(dismissal.projectId) ||
        !isIdentifier(dismissal.jobId) ||
        !isTimestamp(dismissal.dismissedAt)
      ) return false
      const identity = `${dismissal.projectId}\u0000${dismissal.jobId}`
      const dismissedRecord = value.records.find((record) =>
        `${record.projectId}\u0000${record.jobId}` === identity)
      if (
        !recordIds.has(identity) ||
        !dismissibleStatuses.has(dismissedRecord?.status) ||
        dismissalIds.has(identity)
      ) return false
      dismissalIds.add(identity)
    }
    const identities = new Set()
    const idempotencyKeys = new Set()
    for (const record of value.records) {
      const identity = `${record.projectId}\u0000${record.jobId}`
      const idempotency = `${record.projectId}\u0000${record.idempotencyKey}`
      if (identities.has(identity) || idempotencyKeys.has(idempotency)) return false
      identities.add(identity)
      idempotencyKeys.add(idempotency)
    }
    return true
  } catch {
    return false
  }
}

const editPlanKeys = [
  'candidates',
  'createdAt',
  'draft',
  'final',
  'fingerprint',
  'generation',
  'jobId',
  'projectId',
  'status',
  'updatedAt',
]
/** @param {any} value */
const validEditPlan = (value) =>
  exactKeys(value, editPlanKeys) &&
  isIdentifier(value.projectId) &&
  isIdentifier(value.jobId) &&
  typeof value.fingerprint === 'string' &&
  /^[a-f0-9]{64}$/u.test(value.fingerprint) &&
  Number.isSafeInteger(value.generation) &&
  value.generation > 0 &&
  ['draft', 'candidates_ready', 'finalized'].includes(value.status) &&
  isJsonValue(value.draft) &&
  (value.candidates === null || isJsonValue(value.candidates)) &&
  (value.final === null || isJsonValue(value.final)) &&
  isTimestamp(value.createdAt) &&
  isTimestamp(value.updatedAt) &&
  (value.status !== 'candidates_ready' || value.candidates !== null) &&
  (value.status !== 'finalized' || (value.candidates !== null && value.final !== null))

/** @param {unknown} value */
const validEditPlanDocument = (value) =>
  isRecord(value) &&
  value.schema_version === schemaVersion &&
  Array.isArray(value.records) &&
  value.records.every(validEditPlan) &&
  new Set(value.records.map((record) =>
    `${record.projectId}\u0000${record.jobId}\u0000${record.fingerprint}\u0000${record.generation}`))
    .size === value.records.length

/** @param {() => Promise<void>} operation @param {number} [maximumAttempts] */
const runWithTransientWindowsRetries = async (
  operation,
  maximumAttempts = transientWindowsFileOperationAttempts,
) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    try {
      await operation()
      return
    } catch (error) {
      if (
        !transientWindowsDeleteCodes.has(String(errorCode(error))) ||
        attempt + 1 >= maximumAttempts
      ) throw error
      await delay(Math.min(160, 10 * (2 ** Math.min(attempt, 4))))
    }
  }
}

/** @param {string} source @param {string} destination */
const renameWithTransientRetries = (source, destination) =>
  runWithTransientWindowsRetries(() => rename(source, destination))

/** @param {string} source @param {string} destination */
const copyFileWithTransientRetries = (source, destination) =>
  runWithTransientWindowsRetries(() => copyFile(source, destination))

/** @param {string} filePath @param {unknown} document */
const writeAtomic = async (filePath, document) => {
  const temporaryPath = `${filePath}.${randomUUID()}.tmp`
  const backupPath = `${filePath}.bak`
  await mkdir(dirname(filePath), { recursive: true, mode: 0o700 })
  const handle = await open(temporaryPath, 'wx', 0o600)
  try {
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  try {
    await copyFileWithTransientRetries(filePath, backupPath)
    await chmod(backupPath, 0o600).catch(() => {})
  } catch (error) {
    if (errorCode(error) !== 'ENOENT') {
      await rm(temporaryPath, { force: true }).catch(() => {})
      throw error
    }
  }
  try {
    await renameWithTransientRetries(temporaryPath, filePath)
    await chmod(filePath, 0o600).catch(() => {})
  } catch (error) {
    await rm(temporaryPath, { force: true }).catch(() => {})
    throw error
  }
}

/** @param {string} filePath @param {unknown} document */
const repairPrimary = async (filePath, document) => {
  const temporaryPath = `${filePath}.${randomUUID()}.repair`
  const handle = await open(temporaryPath, 'wx', 0o600)
  try {
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  await renameWithTransientRetries(temporaryPath, filePath)
  await chmod(filePath, 0o600).catch(() => {})
}

/**
 * @param {string} filePath
 * @param {(value: unknown) => boolean} validate
 * @param {boolean} [allowCreate]
 * @param {(value: unknown) => unknown} [normalize]
 * @param {() => {schema_version: number, records: Record<string, any>[]}} [createDocument]
 */
const readDocument = async (
  filePath,
  validate,
  allowCreate = false,
  normalize = (value) => value,
  createDocument = () => ({ schema_version: schemaVersion, records: [] }),
) => {
  try {
    const primary = normalize(JSON.parse(await readFile(filePath, 'utf8')))
    if (!validate(primary)) throw new Error('invalid_primary')
    return primary
  } catch (primaryError) {
    try {
      const backup = normalize(JSON.parse(await readFile(`${filePath}.bak`, 'utf8')))
      if (!validate(backup)) throw new Error('invalid_backup')
      await repairPrimary(filePath, backup)
      return backup
    } catch (backupError) {
      if (allowCreate && errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') {
        return createDocument()
      }
      throw repositoryError('WORKBENCH_JOB_STORAGE_CORRUPT')
    }
  }
}

/** @param {number} milliseconds */
const delay = (milliseconds) =>
  new Promise((resolveDelay) => setTimeout(resolveDelay, milliseconds))

/**
 * Removes only the lock content observed by the caller. A changed owner is never removed.
 * @param {string} lockPath
 * @param {string} expectedOwner
 * @param {number} [maximumAttempts]
 */
const removeOwnedLock = async (lockPath, expectedOwner, maximumAttempts = 20) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    const currentOwner = await readFile(lockPath, 'utf8').catch((error) => {
      if (errorCode(error) === 'ENOENT') return null
      throw error
    })
    if (currentOwner === null || currentOwner !== expectedOwner) return true
    try {
      await rm(lockPath)
      return true
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return true
      if (!transientWindowsDeleteCodes.has(String(errorCode(error)))) throw error
      if (attempt + 1 < maximumAttempts) await delay(10)
    }
  }
  return false
}

/** @param {string} lockPath */
const acquireLock = async (lockPath) => {
  const token = randomUUID()
  const owner = `${JSON.stringify({ token, pid: process.pid })}\n`
  for (let attempt = 0; attempt < 500; attempt += 1) {
    /** @type {import('node:fs/promises').FileHandle | null} */
    let handle = null
    try {
      handle = await open(lockPath, 'wx', 0o600)
      activeOwnerTokens.add(token)
      await handle.writeFile(owner, 'utf8')
      await handle.sync()
      return { handle, owner, token }
    } catch (error) {
      if (handle) {
        await handle.close().catch(() => {})
        const failedOwner = await readFile(lockPath, 'utf8').catch(() => null)
        if (failedOwner !== null) {
          await removeOwnedLock(lockPath, failedOwner).catch(() => false)
        }
        activeOwnerTokens.delete(token)
      }
      if (
        process.platform === 'win32' &&
        transientWindowsDeleteCodes.has(String(errorCode(error)))
      ) {
        await delay(10)
        continue
      }
      if (errorCode(error) !== 'EEXIST') throw error
      const existingOwner = await readFile(lockPath, 'utf8').catch(() => null)
      const metadata = await stat(lockPath).catch(() => null)
      let processAlive = true
      /** @type {number | null} */
      let parsedPid = null
      /** @type {string | null} */
      let parsedToken = null
      let validOwner = false
      try {
        const parsed = JSON.parse(existingOwner ?? '')
        if (
          !Number.isSafeInteger(parsed?.pid) ||
          parsed.pid < 1 ||
          typeof parsed.token !== 'string' ||
          parsed.token.length === 0
        ) throw new Error('invalid_lock')
        const pid = Number(parsed.pid)
        parsedPid = pid
        parsedToken = parsed.token
        validOwner = true
        process.kill(pid, 0)
      } catch (processError) {
        processAlive = errorCode(processError) !== 'ESRCH'
      }
      const orphanedCurrentProcessOwner =
        parsedPid === process.pid &&
        parsedToken !== null &&
        !activeOwnerTokens.has(parsedToken)
      const abandonedIncompleteLock =
        existingOwner === '' &&
        metadata &&
        Date.now() - metadata.mtimeMs > incompleteLockRecoveryMs
      if (
        existingOwner !== null &&
        metadata &&
        (
          orphanedCurrentProcessOwner ||
          (validOwner && !processAlive) ||
          abandonedIncompleteLock ||
          (
            Date.now() - metadata.mtimeMs > 5 * 60_000 &&
            (!validOwner || !processAlive)
          )
        ) &&
        await readFile(lockPath, 'utf8').catch(() => null) === existingOwner
      ) {
        if (await removeOwnedLock(lockPath, existingOwner)) continue
      }
      await delay(10)
    }
  }
  throw repositoryError('WORKBENCH_JOB_STORAGE_LOCKED', 503)
}

/** @param {string} lockPath @param {{handle: import('node:fs/promises').FileHandle, owner: string, token: string}} lock */
const releaseLock = async (lockPath, lock) => {
  try {
    await lock.handle.close().catch(() => {})
    await removeOwnedLock(lockPath, lock.owner)
  } finally {
    activeOwnerTokens.delete(lock.token)
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   repositoryRoot?: string,
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 * }} options
 * @param {string} fileName
 * @param {(value: unknown) => boolean} validate
 * @param {{
 *   normalize?: (value: unknown) => unknown,
 *   createDocument?: () => LockedDocument,
 * }} [documentOptions]
 */
const createLockedStore = async ({
  dataRoot,
  repositoryRoot = defaultRepositoryRoot,
  securePrivateRoot = securePrivateRuntimeRoot,
}, fileName, validate, documentOptions = {}) => {
  if (!isAbsolute(dataRoot)) throw repositoryError('WORKBENCH_JOB_DATA_ROOT_REQUIRED')
  if (isInside(repositoryRoot, dataRoot)) throw repositoryError('WORKBENCH_JOB_DATA_ROOT_UNSAFE')
  await mkdir(dataRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(dataRoot)
  const filePath = resolve(dataRoot, fileName)
  const lockPath = `${filePath}.lock`
  /** @type {Promise<unknown>} */
  let writeQueue = Promise.resolve()
  /** @type {string | null} */
  let cachedPrimaryText = null
  /** @type {LockedDocument | null} */
  let cachedDocument = null
  /** @param {unknown} value */
  const normalizeStoreDocument = (value) => /** @type {LockedDocument} */ (
    documentOptions.normalize ? documentOptions.normalize(value) : value
  )

  const readStoreDocument = async () => {
    try {
      const primaryText = await readFile(filePath, 'utf8')
      if (cachedDocument && primaryText === cachedPrimaryText) return cachedDocument
      const primary = normalizeStoreDocument(JSON.parse(primaryText))
      if (!validate(primary)) throw new Error('invalid_primary')
      cachedPrimaryText = primaryText
      cachedDocument = primary
      return primary
    } catch {
      const recovered = /** @type {LockedDocument} */ (
        await readDocument(
          filePath,
          validate,
          true,
          documentOptions.normalize,
          documentOptions.createDocument,
        )
      )
      cachedPrimaryText = await readFile(filePath, 'utf8').catch(() => null)
      cachedDocument = recovered
      return recovered
    }
  }

  /** @template T @param {(document: LockedDocument) => Promise<{document: LockedDocument, result: T}>} operation */
  const mutate = (operation) => {
    const run = async () => {
      const lock = await acquireLock(lockPath)
      try {
        const document = await readStoreDocument()
        const output = await operation(clone(document))
        if (!validate(output.document)) throw repositoryError('WORKBENCH_JOB_RECORD_INVALID')
        await writeAtomic(filePath, output.document)
        cachedPrimaryText = `${JSON.stringify(output.document, null, 2)}\n`
        cachedDocument = normalizeStoreDocument(clone(output.document))
        return clone(output.result)
      } finally {
        await releaseLock(lockPath, lock)
      }
    }
    const result = writeQueue.then(run, run)
    writeQueue = result.then(() => undefined, () => undefined)
    return result
  }

  const read = async () => readStoreDocument()

  const initialize = await acquireLock(lockPath)
  try {
    const document = await readStoreDocument()
    const persisted = await readFile(filePath, 'utf8').catch(() => null)
    if (
      persisted === null ||
      JSON.stringify(JSON.parse(persisted)) !== JSON.stringify(document)
    ) {
      await writeAtomic(filePath, document)
    }
    cachedPrimaryText = await readFile(filePath, 'utf8').catch(() => null)
    cachedDocument = document
  } finally {
    await releaseLock(lockPath, initialize)
  }
  return { mutate, read }
}

/** @param {Record<string, any>} job @param {string} attemptId @param {number} generation @param {string | null} leaseToken */
const assertFence = (job, attemptId, generation, leaseToken) => {
  const attempt = job.attempts.at(-1)
  if (
    !attempt ||
    attempt.attemptId !== attemptId ||
    attempt.generation !== generation ||
    (attempt.lease === null ? leaseToken !== null : attempt.lease.token !== leaseToken)
  ) throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
  return attempt
}

/**
 * @param {{
 *   dataRoot: string,
 *   repositoryRoot?: string,
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 * }} options
 */
export const createWorkbenchJobRepository = async (options) => {
  const store = await createLockedStore(options, 'workbench-jobs.json', validJobDocument, {
    normalize: normalizeJobDocument,
    createDocument: () => ({ schema_version: jobSchemaVersion, records: [], dismissals: [] }),
  })
  return {
    /** @param {unknown} value */
    async createOrGet(value) {
      const candidate = assertJobRecord(value)
      return store.mutate(async (document) => {
        const existing = document.records.find((record) =>
          record.projectId === candidate.projectId &&
          record.idempotencyKey === candidate.idempotencyKey)
        if (existing) {
          if (
            existing.privateInput.inputFingerprint !== candidate.privateInput.inputFingerprint
          ) throw repositoryError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
          return { document, result: existing }
        }
        const identityConflict = document.records.some((record) =>
          record.projectId === candidate.projectId && record.jobId === candidate.jobId)
        if (identityConflict) throw repositoryError('WORKBENCH_JOB_ID_CONFLICT', 409)
        document.records.push(candidate)
        return { document, result: candidate }
      })
    },
    /**
     * Atomically creates or replays a job while preventing another active job of
     * the same type from being created for the project.
     * @param {unknown} value
     */
    async createOrGetExclusiveByType(value) {
      const candidate = assertJobRecord(value)
      return store.mutate(async (document) => {
        const existing = document.records.find((record) =>
          record.projectId === candidate.projectId &&
          record.idempotencyKey === candidate.idempotencyKey)
        if (existing) {
          if (existing.privateInput.inputFingerprint !== candidate.privateInput.inputFingerprint) {
            throw repositoryError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
          }
          return { document, result: existing }
        }
        const activeConflict = document.records.some((record) =>
          record.projectId === candidate.projectId &&
          record.type === candidate.type &&
          ['queued', 'running', 'cancelling'].includes(record.status))
        if (activeConflict) {
          throw repositoryError('WORKBENCH_JOB_TYPE_ALREADY_RUNNING', 409)
        }
        const identityConflict = document.records.some((record) =>
          record.projectId === candidate.projectId && record.jobId === candidate.jobId)
        if (identityConflict) throw repositoryError('WORKBENCH_JOB_ID_CONFLICT', 409)
        document.records.push(candidate)
        return { document, result: candidate }
      })
    },
    /**
     * Atomically validates a parent execution fence and creates/replays a child job.
     * @param {{projectId: string, jobId: string, attemptId: string, generation: number, leaseToken: string, now: string}} fence
     * @param {unknown} value
     */
    async createOrGetFenced(fence, value) {
      if (!isTimestamp(fence?.now)) {
        throw repositoryError('WORKBENCH_JOB_FENCE_TIME_INVALID', 400)
      }
      const candidate = assertJobRecord(value)
      return store.mutate(async (document) => {
        const parent = document.records.find((record) =>
          record.projectId === fence.projectId && record.jobId === fence.jobId)
        if (!parent) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const attempt = assertFence(
          parent,
          fence.attemptId,
          fence.generation,
          fence.leaseToken,
        )
        if (
          parent.status !== 'running' ||
          attempt.status !== 'running' ||
          attempt.lease === null ||
          Date.parse(attempt.lease.expiresAt) <= Date.parse(fence.now)
        ) {
          throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
        }
        const existing = document.records.find((record) =>
          record.projectId === candidate.projectId &&
          record.idempotencyKey === candidate.idempotencyKey)
        if (existing) {
          if (existing.privateInput.inputFingerprint !== candidate.privateInput.inputFingerprint) {
            throw repositoryError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
          }
          return { document, result: existing }
        }
        const identityConflict = document.records.some((record) =>
          record.projectId === candidate.projectId && record.jobId === candidate.jobId)
        if (identityConflict) throw repositoryError('WORKBENCH_JOB_ID_CONFLICT', 409)
        document.records.push(candidate)
        return { document, result: candidate }
      })
    },
    /** @param {string} projectId @param {string} jobId */
    async get(projectId, jobId) {
      const document = await store.read()
      const record = document.records.find((job) => job.projectId === projectId && job.jobId === jobId)
      return record ? clone(record) : null
    },
    /** @param {string} projectId @param {string} idempotencyKey */
    async getByIdempotencyKey(projectId, idempotencyKey) {
      const document = await store.read()
      const record = document.records.find((job) =>
        job.projectId === projectId && job.idempotencyKey === idempotencyKey)
      return record ? clone(record) : null
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, leaseToken: string, now: string}} input */
    async assertExecutionFence(input) {
      if (!isTimestamp(input?.now)) {
        throw repositoryError('WORKBENCH_JOB_FENCE_TIME_INVALID', 400)
      }
      const document = await store.read()
      const job = document.records.find((record) =>
        record.projectId === input.projectId && record.jobId === input.jobId)
      if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
      const attempt = assertFence(
        job,
        input.attemptId,
        input.generation,
        input.leaseToken,
      )
      if (
        job.status !== 'running' ||
        attempt.status !== 'running' ||
        attempt.lease === null ||
        Date.parse(attempt.lease.expiresAt) <= Date.parse(input.now)
      ) {
        throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
      }
      return true
    },
    /**
     * Holds the job store lock while a fenced external commit executes.
     * @param {{projectId: string, jobId: string, attemptId: string, generation: number, leaseToken: string, now: string}} input
     * @param {() => Promise<unknown>} operation
     */
    async withExecutionFence(input, operation) {
      if (!isTimestamp(input?.now) || typeof operation !== 'function') {
        throw repositoryError('WORKBENCH_JOB_FENCE_OPERATION_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const attempt = assertFence(
          job,
          input.attemptId,
          input.generation,
          input.leaseToken,
        )
        if (
          job.status !== 'running' ||
          attempt.status !== 'running' ||
          attempt.lease === null ||
          Date.parse(attempt.lease.expiresAt) <= Date.parse(input.now)
        ) {
          throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
        }
        const result = await operation()
        return { document, result }
      })
    },
    /** @param {string} projectId */
    async listByProject(projectId) {
      return this.listByProjects([projectId])
    },
    /** @param {string[]} projectIds */
    async listByProjects(projectIds) {
      const allowed = new Set((Array.isArray(projectIds) ? projectIds : []).filter((value) =>
        typeof value === 'string' && value.trim().length > 0))
      if (!allowed.size) return []
      const document = await store.read()
      const dismissed = new Set(document.dismissals.map((entry) =>
        `${entry.projectId}\u0000${entry.jobId}`))
      return clone(document.records.filter((job) =>
        allowed.has(job.projectId) &&
        !dismissed.has(`${job.projectId}\u0000${job.jobId}`)))
    },
    /** @param {{projectId: string, jobIds: string[], dismissedAt: string}} input */
    async dismissTerminal(input) {
      if (
        !isIdentifier(input?.projectId) ||
        !Array.isArray(input?.jobIds) ||
        input.jobIds.length === 0 ||
        input.jobIds.some((jobId) => !isIdentifier(jobId)) ||
        !isTimestamp(input?.dismissedAt)
      ) throw repositoryError('WORKBENCH_JOB_DISMISS_INVALID', 400)
      const requested = new Set(input.jobIds)
      return store.mutate(async (document) => {
        const jobs = document.records.filter((record) =>
          record.projectId === input.projectId && requested.has(record.jobId))
        if (jobs.length !== requested.size) {
          throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        }
        if (jobs.some((job) => !dismissibleStatuses.has(job.status))) {
          throw repositoryError('WORKBENCH_JOB_NOT_DISMISSIBLE', 409)
        }
        const dismissed = new Set(document.dismissals.map((entry) =>
          `${entry.projectId}\u0000${entry.jobId}`))
        for (const job of jobs) {
          const identity = `${job.projectId}\u0000${job.jobId}`
          if (dismissed.has(identity)) continue
          document.dismissals.push({
            projectId: job.projectId,
            jobId: job.jobId,
            dismissedAt: input.dismissedAt,
          })
          dismissed.add(identity)
        }
        return { document, result: jobs.map((job) => job.jobId) }
      })
    },
    /** @param {{now: string, retentionDays?: number, maximumPerProject?: number}} input */
    async pruneTerminal(input) {
      const retentionDays = input?.retentionDays ?? 30
      const maximumPerProject = input?.maximumPerProject ?? 100
      if (
        !isTimestamp(input?.now) ||
        !Number.isSafeInteger(retentionDays) ||
        retentionDays < 1 ||
        !Number.isSafeInteger(maximumPerProject) ||
        maximumPerProject < 1
      ) throw repositoryError('WORKBENCH_JOB_PRUNE_INVALID', 400)
      return store.mutate(async (document) => {
        const cutoff = Date.parse(input.now) - retentionDays * 24 * 60 * 60 * 1_000
        const dismissed = new Map(document.dismissals.map((entry) => [
          `${entry.projectId}\u0000${entry.jobId}`,
          entry,
        ]))
        const removable = new Set()
        for (const record of document.records) {
          const identity = `${record.projectId}\u0000${record.jobId}`
          const dismissal = dismissed.get(identity)
          if (
            dismissal &&
            dismissibleStatuses.has(record.status) &&
            Date.parse(dismissal.dismissedAt) < cutoff
          ) removable.add(identity)
        }
        /** @type {Map<string, Record<string, any>[]>} */
        const byProject = new Map()
        for (const record of document.records) {
          if (!terminalStatuses.has(record.status)) continue
          const entries = byProject.get(record.projectId) ?? []
          entries.push(record)
          byProject.set(record.projectId, entries)
        }
        for (const entries of byProject.values()) {
          const candidates = entries
            .filter((record) =>
              dismissibleStatuses.has(record.status) &&
              dismissed.has(`${record.projectId}\u0000${record.jobId}`))
            .sort((left, right) => Date.parse(right.updatedAt) - Date.parse(left.updatedAt))
          for (const record of candidates.slice(maximumPerProject)) {
            removable.add(`${record.projectId}\u0000${record.jobId}`)
          }
        }
        if (!removable.size) return { document, result: [] }
        const removedJobIds = document.records
          .filter((record) => removable.has(`${record.projectId}\u0000${record.jobId}`))
          .map((record) => record.jobId)
        document.records = document.records.filter((record) =>
          !removable.has(`${record.projectId}\u0000${record.jobId}`))
        document.dismissals = document.dismissals.filter((entry) =>
          !removable.has(`${entry.projectId}\u0000${entry.jobId}`))
        return { document, result: removedJobIds }
      })
    },
    /** @param {string} projectId */
    async removeByProject(projectId) {
      if (!isIdentifier(projectId)) throw repositoryError('WORKBENCH_JOB_INPUT_INVALID', 400)
      return store.mutate(async (document) => {
        const retained = document.records.filter((job) => job.projectId !== projectId)
        const removed = document.records.length - retained.length
        document.records = retained
        document.dismissals = document.dismissals.filter((entry) => entry.projectId !== projectId)
        return { document, result: removed }
      })
    },
    /** @param {{projectId: string, types: string[], invalidatedAt: string, createdBefore?: string}} input */
    async invalidateProjectOutputs(input) {
      if (
        !isIdentifier(input?.projectId) ||
        !Array.isArray(input?.types) ||
        input.types.length === 0 ||
        input.types.some((type) => !isIdentifier(type)) ||
        !isTimestamp(input?.invalidatedAt) ||
        (input.createdBefore !== undefined && !isTimestamp(input.createdBefore))
      ) throw repositoryError('WORKBENCH_JOB_INVALIDATION_INVALID', 400)
      const types = new Set(input.types)
      const createdBeforeMs = input.createdBefore === undefined
        ? Number.POSITIVE_INFINITY
        : Date.parse(input.createdBefore)
      return store.mutate(async (document) => {
        const invalidated = []
        for (const job of document.records) {
          if (job.projectId !== input.projectId || !types.has(job.type)) continue
          if (Date.parse(job.createdAt) > createdBeforeMs) continue
          if (job.error?.code === 'WORKBENCH_JOB_INPUT_INVALIDATED') {
            invalidated.push(job)
            continue
          }
          if (terminalStatuses.has(job.status)) {
            job.attempts.push({
              attemptId: randomUUID(),
              generation: job.attempts.at(-1).generation + 1,
              deadlineAt: null,
              status: 'cancelled',
              startedAt: input.invalidatedAt,
              finishedAt: input.invalidatedAt,
              lease: null,
              error: {
                code: 'WORKBENCH_JOB_INPUT_INVALIDATED',
                recoverable: false,
              },
            })
          } else {
            const attempt = job.attempts.at(-1)
            attempt.status = 'cancelled'
            attempt.startedAt ??= input.invalidatedAt
            attempt.finishedAt = input.invalidatedAt
            attempt.lease = null
            attempt.error = {
              code: 'WORKBENCH_JOB_INPUT_INVALIDATED',
              recoverable: false,
            }
          }
          job.status = 'cancelled'
          job.updatedAt = input.invalidatedAt
          job.cancelRequestedAt ??= input.invalidatedAt
          job.checkpoint = null
          job.result = null
          job.error = {
            code: 'WORKBENCH_JOB_INPUT_INVALIDATED',
            recoverable: false,
          }
          assertJobRecord(job)
          invalidated.push(job)
        }
        return { document, result: invalidated }
      })
    },
    /** @param {string} now */
    async listRecoverable(now) {
      if (!isTimestamp(now)) throw repositoryError('WORKBENCH_JOB_RECOVERY_TIME_INVALID', 400)
      const document = await store.read()
      return clone(document.records.filter((job) => {
        if (job.status === 'queued' || job.status === 'cancelling') return true
        if (job.status !== 'running') return false
        const lease = job.attempts.at(-1)?.lease
        return lease !== null && Date.parse(lease.expiresAt) <= Date.parse(now)
      }))
    },
    /** @param {{projectId: string, jobId: string, ownerId: string, leaseDurationMs: number, now: string, deadlineAt: string | null}} input */
    async claim(input) {
      if (
        !isIdentifier(input?.ownerId) ||
        !Number.isSafeInteger(input?.leaseDurationMs) ||
        input.leaseDurationMs < 1 ||
        input.leaseDurationMs > 24 * 60 * 60_000 ||
        !isTimestamp(input?.now) ||
        (
          input?.deadlineAt !== null &&
          (!isTimestamp(input?.deadlineAt) || Date.parse(input.deadlineAt) <= Date.parse(input.now))
        )
      ) throw repositoryError('WORKBENCH_JOB_CLAIM_INVALID', 400)
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        if (input.deadlineAt === null && job.type !== 'material_analysis') {
          throw repositoryError('WORKBENCH_JOB_CLAIM_INVALID', 400)
        }
        let attempt = job.attempts.at(-1)
        if (!attempt || !['queued', 'running'].includes(attempt.status) || job.status === 'cancelling') {
          throw repositoryError('WORKBENCH_JOB_NOT_CLAIMABLE', 409)
        }
        if (
          attempt.lease &&
          Date.parse(attempt.lease.expiresAt) > Date.parse(input.now)
        ) throw repositoryError('WORKBENCH_JOB_LEASE_ACTIVE', 409)
        if (
          job.status === 'running' &&
          attempt.status === 'running' &&
          attempt.lease &&
          Date.parse(attempt.lease.expiresAt) <= Date.parse(input.now)
        ) {
          // Editor-agent recovery starts a new generation because its private
          // tool execution history must be replayed from a fenced checkpoint.
          // Provider jobs (including preview) can safely resume the same
          // attempt; keeping its generation preserves checkpoint ownership.
          if (job.type === 'editor_agent') {
            attempt.status = 'failed'
            attempt.finishedAt = input.now
            attempt.lease = null
            attempt.error = {
              code: 'WORKBENCH_EDITOR_AGENT_LEASE_EXPIRED',
              recoverable: true,
            }
            const generation = attempt.generation + 1
            attempt = {
              attemptId: randomUUID(),
              generation,
              deadlineAt: input.deadlineAt,
              status: 'queued',
              startedAt: null,
              finishedAt: null,
              lease: null,
              error: null,
            }
            job.attempts.push(attempt)
            if (job.checkpoint) {
              job.checkpoint = {
                ...job.checkpoint,
                generation,
                updatedAt: input.now,
              }
            }
          } else {
            attempt.lease = null
            attempt.deadlineAt = job.type === 'material_analysis' ? null : input.deadlineAt
          }
        }
        attempt.status = 'running'
        attempt.startedAt ??= input.now
        attempt.deadlineAt = job.type === 'material_analysis'
          ? null
          : attempt.deadlineAt ?? input.deadlineAt
        attempt.lease = {
          token: randomUUID(),
          generation: attempt.generation,
          ownerId: input.ownerId,
          acquiredAt: input.now,
          expiresAt: new Date(Date.parse(input.now) + input.leaseDurationMs).toISOString(),
        }
        job.status = 'running'
        job.updatedAt = input.now
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, leaseToken: string, leaseDurationMs: number, renewedAt: string}} input */
    async renewLease(input) {
      if (
        !Number.isSafeInteger(input?.leaseDurationMs) ||
        input.leaseDurationMs < 1 ||
        input.leaseDurationMs > 24 * 60 * 60_000 ||
        !isTimestamp(input?.renewedAt)
      ) throw repositoryError('WORKBENCH_JOB_LEASE_RENEWAL_INVALID', 400)
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const attempt = assertFence(
          job,
          input.attemptId,
          input.generation,
          input.leaseToken,
        )
        if (
          job.status !== 'running' ||
          attempt.status !== 'running' ||
          attempt.lease === null ||
          Date.parse(attempt.lease.expiresAt) <= Date.parse(input.renewedAt)
        ) throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
        attempt.lease.expiresAt =
          new Date(Date.parse(input.renewedAt) + input.leaseDurationMs).toISOString()
        job.updatedAt = input.renewedAt
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, leaseToken: string, generation: number, checkpoint: unknown}} input */
    async saveCheckpoint(input) {
      const checkpoint = assertCheckpoint(input?.checkpoint)
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const attempt = assertFence(job, input.attemptId, input.generation, input.leaseToken)
        if (
          job.status !== 'running' ||
          attempt.status !== 'running' ||
          attempt.lease === null ||
          checkpoint.generation !== input.generation
        ) {
          throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
        }
        /** @type {Record<string, any>} */
        const monotonicCheckpoint = {
          ...checkpoint,
          progressPercent: Math.max(
            checkpoint.progressPercent,
            job.checkpoint?.progressPercent ?? 0,
          ),
        }
        job.checkpoint = monotonicCheckpoint
        job.updatedAt = monotonicCheckpoint.updatedAt
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, leaseToken: string, releasedAt: string, resetDeadline?: boolean}} input */
    async releaseForShutdown(input) {
      if (!isTimestamp(input?.releasedAt)) {
        throw repositoryError('WORKBENCH_JOB_SHUTDOWN_RELEASE_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const attempt = assertFence(
          job,
          input.attemptId,
          input.generation,
          input.leaseToken,
        )
        if (
          job.status !== 'running' ||
          attempt.status !== 'running' ||
          attempt.lease === null ||
          Date.parse(attempt.lease.expiresAt) <= Date.parse(input.releasedAt)
        ) throw repositoryError('WORKBENCH_JOB_LEASE_FENCED', 409)
        attempt.status = 'queued'
        attempt.lease = null
        if (input.resetDeadline === true) {
          attempt.startedAt = null
          attempt.deadlineAt = null
        }
        job.status = 'queued'
        job.updatedAt = input.releasedAt
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /** @param {{projectId: string, jobId: string, requestedAt: string}} input */
    async requestCancel(input) {
      if (!isTimestamp(input?.requestedAt)) throw repositoryError('WORKBENCH_JOB_CANCEL_INVALID', 400)
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        if (terminalStatuses.has(job.status)) return { document, result: job }
        // Keep the running attempt/lease identity so the active worker can still
        // settle cancellation. Mutation fences already reject status!=='running'
        // (saveCheckpoint / createOrGetFenced / withExecutionFence).
        job.status = 'cancelling'
        job.cancelRequestedAt ??= input.requestedAt
        job.updatedAt = input.requestedAt
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, leaseToken: string | null, status: string, finishedAt: string, result: unknown, error: unknown}} input */
    async finish(input) {
      if (!terminalStatuses.has(input?.status) || !isTimestamp(input?.finishedAt)) {
        throw repositoryError('WORKBENCH_JOB_FINISH_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        if (job.error?.code === 'WORKBENCH_JOB_INPUT_INVALIDATED') {
          return { document, result: job }
        }
        if (
          (job.status === 'cancelling' || job.cancelRequestedAt) &&
          input.status !== 'cancelled'
        ) {
          throw repositoryError('WORKBENCH_JOB_FINISH_INVALID', 409)
        }
        const attempt = assertFence(job, input.attemptId, input.generation, input.leaseToken)
        attempt.status = input.status
        attempt.startedAt ??= input.finishedAt
        attempt.finishedAt = input.finishedAt
        attempt.lease = null
        attempt.error = input.error
        job.status = input.status
        job.updatedAt = input.finishedAt
        job.result = input.result
        job.error = input.error
        if (job.status === 'succeeded') {
          const dismissed = new Set(document.dismissals.map((entry) =>
            `${entry.projectId}\u0000${entry.jobId}`))
          for (const older of document.records) {
            if (
              older.projectId !== job.projectId ||
              older.type !== job.type ||
              older.jobId === job.jobId ||
              !['failed', 'cancelled', 'timed_out'].includes(older.status)
            ) continue
            const identity = `${older.projectId}\u0000${older.jobId}`
            if (dismissed.has(identity)) continue
            document.dismissals.push({
              projectId: older.projectId,
              jobId: older.jobId,
              dismissedAt: input.finishedAt,
            })
            dismissed.add(identity)
          }
        }
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /**
     * An Editor parent is only successful while every output child still has a
     * valid durable binding to that parent. Resolve the parent from the stored
     * child record instead of trusting a claimed in-memory job, which may have
     * crossed an untrusted scheduling boundary.
     * @param {{projectId: string, childJobId: string, failedAt: string}} input
     */
    async failEditorParentForInvalidChild(input) {
      if (
        !isIdentifier(input?.projectId) ||
        !isIdentifier(input?.childJobId) ||
        !isTimestamp(input?.failedAt)
      ) throw repositoryError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 400)
      return store.mutate(async (document) => {
        const child = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.childJobId)
        const parentJobId = child?.privateInput?.editorParentJobId
        const instructionFingerprint = child?.privateInput?.editorInstructionFingerprint
        if (
          !child ||
          !['preview_generation', 'jianying_draft_export'].includes(child.type) ||
          child.privateInput?.editorBound !== true ||
          !isIdentifier(parentJobId) ||
          typeof instructionFingerprint !== 'string' ||
          !/^[a-f0-9]{64}$/u.test(instructionFingerprint)
        ) return { document, result: null }
        const parent = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === parentJobId)
        if (
          !parent ||
          parent.type !== 'editor_agent' ||
          parent.privateInput?.instructionFingerprint !== instructionFingerprint ||
          !['queued', 'running', 'succeeded'].includes(parent.status)
        ) return { document, result: null }
        const attempt = parent.attempts.at(-1)
        if (!attempt || !['queued', 'running', 'succeeded'].includes(attempt.status)) {
          return { document, result: null }
        }
        const failParent = (/** @type {Record<string, any>} */ record) => {
          const currentAttempt = record.attempts.at(-1)
          if (!currentAttempt || !['queued', 'running', 'succeeded'].includes(currentAttempt.status)) return
          const error = { code: 'WORKBENCH_EDITOR_AGENT_FAILED', recoverable: true }
          currentAttempt.status = 'failed'
          currentAttempt.startedAt ??= input.failedAt
          currentAttempt.deadlineAt ??= input.failedAt
          currentAttempt.finishedAt = input.failedAt
          currentAttempt.lease = null
          currentAttempt.error = error
          record.status = 'failed'
          record.updatedAt = input.failedAt
          record.result = null
          record.error = error
          assertJobRecord(record)
        }
        failParent(parent)
        // A second active Editor with the same immutable instruction cannot be
        // legitimate: normal creation is exclusive per project. Treat it as a
        // forged replay so it cannot block the next valid edit.
        for (const candidate of document.records) {
          if (
            candidate.projectId === input.projectId &&
            candidate.jobId !== parent.jobId &&
            candidate.type === 'editor_agent' &&
            candidate.privateInput?.instructionFingerprint === instructionFingerprint &&
            ['queued', 'running', 'succeeded'].includes(candidate.status)
          ) failParent(candidate)
        }
        return { document, result: clone(parent) }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, expectedGeneration: number, retriedAt: string}} input */
    async retry(input) {
      if (
        !isIdentifier(input?.attemptId) ||
        !Number.isSafeInteger(input?.expectedGeneration) ||
        input.expectedGeneration < 1 ||
        !isTimestamp(input?.retriedAt)
      ) {
        throw repositoryError('WORKBENCH_JOB_RETRY_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const latestGeneration = job.attempts.at(-1).generation
        if (
          latestGeneration === input.expectedGeneration + 1 &&
          ['queued', 'running', 'cancelling'].includes(job.status)
        ) {
          document.dismissals = document.dismissals.filter((entry) =>
            entry.projectId !== job.projectId || entry.jobId !== job.jobId)
          return { document, result: job }
        }
        if (latestGeneration !== input.expectedGeneration) {
          throw repositoryError('WORKBENCH_JOB_RETRY_FENCED', 409)
        }
        if (job.error?.code === 'WORKBENCH_JOB_INPUT_INVALIDATED') {
          throw repositoryError('WORKBENCH_JOB_NOT_RETRYABLE', 409)
        }
        if (!['failed', 'cancelled', 'timed_out'].includes(job.status)) {
          throw repositoryError('WORKBENCH_JOB_NOT_RETRYABLE', 409)
        }
        const activeConflict = document.records.some((record) =>
          record.projectId === job.projectId &&
          record.type === job.type &&
          record.jobId !== job.jobId &&
          ['queued', 'running', 'cancelling'].includes(record.status))
        if (activeConflict && ['material_analysis', 'editor_agent'].includes(job.type)) {
          throw repositoryError('WORKBENCH_JOB_TYPE_ALREADY_RUNNING', 409)
        }
        const generation = job.attempts.at(-1).generation + 1
        job.attempts.push({
          attemptId: input.attemptId,
          generation,
          deadlineAt: null,
          status: 'queued',
          startedAt: null,
          finishedAt: null,
          lease: null,
          error: null,
        })
        job.status = 'queued'
        job.updatedAt = input.retriedAt
        job.cancelRequestedAt = null
        const preserveAutomaticOutputCheckpoint =
          job.type === 'editor_agent' &&
          job.privateInput?.automaticOutputs === true &&
          Array.isArray(job.checkpoint?.data?.committedExecutions) &&
          job.checkpoint.data.committedExecutions.length > 0
        // Carry the last durable percentage into the new generation as a
        // public progress floor. The stage is explicit about recovery while
        // the worker repeats any necessary internal work.
        if (job.checkpoint) {
          job.checkpoint = {
            generation,
            stage: 'retry_queued',
            progressPercent: job.checkpoint.progressPercent,
            updatedAt: input.retriedAt,
            data: preserveAutomaticOutputCheckpoint
              ? {
                  ...job.checkpoint.data,
                  detail: '任务正在从上次进度恢复',
                }
              : { detail: '任务正在从上次进度恢复' },
          }
        }
        job.result = null
        job.error = null
        document.dismissals = document.dismissals.filter((entry) =>
          entry.projectId !== job.projectId || entry.jobId !== job.jobId)
        assertJobRecord(job)
        return { document, result: job }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, failedAt: string}} input */
    async failRetryPreparation(input) {
      if (
        !isIdentifier(input?.attemptId) ||
        !Number.isSafeInteger(input?.generation) ||
        input.generation < 2 ||
        !isTimestamp(input?.failedAt)
      ) {
        throw repositoryError('WORKBENCH_JOB_RETRY_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const job = document.records.find((record) =>
          record.projectId === input.projectId && record.jobId === input.jobId)
        if (!job) throw repositoryError('WORKBENCH_JOB_NOT_FOUND', 404)
        const attempt = job.attempts.at(-1)
        if (
          job.status !== 'queued' ||
          attempt?.status !== 'queued' ||
          attempt.attemptId !== input.attemptId ||
          attempt.generation !== input.generation ||
          attempt.lease !== null
        ) {
          throw repositoryError('WORKBENCH_JOB_RETRY_FENCED', 409)
        }
        const error = {
          code: 'WORKBENCH_JOB_RETRY_PREPARATION_FAILED',
          recoverable: true,
        }
        attempt.status = 'failed'
        attempt.startedAt = input.failedAt
        if (job.type !== 'material_analysis') attempt.deadlineAt = input.failedAt
        attempt.finishedAt = input.failedAt
        attempt.error = error
        job.status = 'failed'
        job.updatedAt = input.failedAt
        job.error = error
        assertJobRecord(job)
        return { document, result: job }
      })
    },
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   repositoryRoot?: string,
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 * }} options
 */
export const createEditPlanRepository = async (options) => {
  const store = await createLockedStore(options, 'workbench-edit-plans.json', validEditPlanDocument)
  /** @param {Record<string, any>} record @param {{projectId: string, jobId: string, fingerprint: string, generation: number}} input */
  const matches = (record, input) =>
    record.projectId === input.projectId &&
    record.jobId === input.jobId &&
    record.fingerprint === input.fingerprint &&
    record.generation === input.generation
  /** @param {{projectId: string, jobId: string, fingerprint: string, generation: number}} input */
  const validateIdentity = (input) => {
    if (
      !isIdentifier(input?.projectId) ||
      !isIdentifier(input?.jobId) ||
      typeof input?.fingerprint !== 'string' ||
      !/^[a-f0-9]{64}$/u.test(input.fingerprint) ||
      !Number.isSafeInteger(input.generation) ||
      input.generation < 1
    ) throw repositoryError('WORKBENCH_EDIT_PLAN_INVALID', 400)
  }
  return {
    /** @param {{projectId: string, jobId: string, fingerprint: string, generation: number, draft: unknown, updatedAt: string}} input */
    async draft(input) {
      validateIdentity(input)
      if (!isJsonValue(input.draft) || !isTimestamp(input.updatedAt)) {
        throw repositoryError('WORKBENCH_EDIT_PLAN_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const existing = document.records.find((record) => matches(record, input))
        const record = {
          projectId: input.projectId,
          jobId: input.jobId,
          fingerprint: input.fingerprint,
          generation: input.generation,
          status: 'draft',
          draft: clone(input.draft),
          candidates: null,
          final: null,
          createdAt: existing?.createdAt ?? input.updatedAt,
          updatedAt: input.updatedAt,
        }
        if (existing) document.records[document.records.indexOf(existing)] = record
        else document.records.push(record)
        return { document, result: record }
      })
    },
    /** @param {{projectId: string, jobId: string, fingerprint: string, generation: number, candidates: unknown, updatedAt: string}} input */
    async candidates(input) {
      validateIdentity(input)
      if (!isJsonValue(input.candidates) || !isTimestamp(input.updatedAt)) {
        throw repositoryError('WORKBENCH_EDIT_PLAN_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const record = document.records.find((entry) => matches(entry, input))
        if (!record || !matches(record, input)) {
          throw repositoryError('WORKBENCH_EDIT_PLAN_MISMATCH', 409)
        }
        record.status = 'candidates_ready'
        record.candidates = clone(input.candidates)
        record.final = null
        record.updatedAt = input.updatedAt
        return { document, result: record }
      })
    },
    /** @param {{projectId: string, jobId: string, fingerprint: string, generation: number, final: unknown, updatedAt: string}} input */
    async finalize(input) {
      validateIdentity(input)
      if (!isJsonValue(input.final) || !isTimestamp(input.updatedAt)) {
        throw repositoryError('WORKBENCH_EDIT_PLAN_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const record = document.records.find((entry) => matches(entry, input))
        if (!record || !matches(record, input) || record.candidates === null) {
          throw repositoryError('WORKBENCH_EDIT_PLAN_MISMATCH', 409)
        }
        record.status = 'finalized'
        record.final = clone(input.final)
        record.updatedAt = input.updatedAt
        return { document, result: record }
      })
    },
    /** @param {{projectId: string, jobId: string, fingerprint: string, generation: number}} input */
    async get(input) {
      validateIdentity(input)
      const document = await store.read()
      const record = document.records.find((entry) => matches(entry, input))
      return record ? clone(record) : null
    },
    /** @param {{projectId: string, planId: string}} input */
    async getFinalized(input) {
      if (!isIdentifier(input?.projectId) || !isIdentifier(input?.planId)) {
        throw repositoryError('WORKBENCH_EDIT_PLAN_INVALID', 400)
      }
      const document = await store.read()
      const record = document.records.find((entry) =>
        entry.projectId === input.projectId &&
        entry.status === 'finalized' &&
        entry.final &&
        typeof entry.final === 'object' &&
        !Array.isArray(entry.final) &&
        entry.final.plan_id === input.planId)
      return record ? clone(record) : null
    },
    /** @param {string} projectId */
    async removeByProject(projectId) {
      if (!isIdentifier(projectId)) throw repositoryError('WORKBENCH_EDIT_PLAN_INVALID', 400)
      return store.mutate(async (document) => {
        const retained = document.records.filter((record) => record.projectId !== projectId)
        const removed = document.records.length - retained.length
        document.records = retained
        return { document, result: removed }
      })
    },
  }
}
