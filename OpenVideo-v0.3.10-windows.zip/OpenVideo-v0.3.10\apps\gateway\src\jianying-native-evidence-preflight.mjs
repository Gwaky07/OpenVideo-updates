// @ts-nocheck -- Runtime validators are the authoritative boundary; this
// module intentionally accepts opaque injected summaries from private seams.
import { createHash, randomBytes } from 'node:crypto'
import { lstat, mkdir, realpath, rename, rm, writeFile, readFile } from 'node:fs/promises'
import { join, isAbsolute, resolve } from 'node:path'

// These are only syntactic fallbacks for an unavailable desktop. A successful
// probe always derives the expected binding from the detected installation.
const expectedProfileId = 'jianying-runtime-detected'
const expectedAppVersion = '0.0.0.0'
const currentEvidenceScope = 'current_profile_evidence_probe'
const legacyEvidenceScope = 'exact_11_3_evidence_probe'
const acceptedEvidenceScopes = new Set([currentEvidenceScope, legacyEvidenceScope])
const receiptRevision = 'native-004-jianying-evidence-preflight-v1'
const fingerprintPattern = /^[a-f0-9]{64}$/u
const privateIdentityText = (value) => typeof value === 'string' && value.length > 0 && value.length <= 512 && !/[\u0000-\u001f\u007f]/u.test(value)
const receiptIdPattern = /^ovnative004preflight_v1_[0-9]{10,20}_[a-f0-9]{8,64}$/u
const defaultReceiptMaxAgeMs = 7 * 24 * 60 * 60 * 1000
const receiptClockSkewMs = 5 * 60 * 1000
const statusSet = new Set(['ready', 'partial', 'fail'])
const knownBlockers = new Set([
  'NATIVE004_DESKTOP_UNAVAILABLE',
  'NATIVE004_EXACT_PROFILE_REQUIRED',
  'NATIVE004_RESOURCE_ROOTS_UNAVAILABLE',
  'NATIVE004_CATALOG_MISSING',
  'NATIVE004_CATALOG_STALE',
  'NATIVE004_DRAFT_UNAVAILABLE',
  'NATIVE004_SAME_DRAFT_EVIDENCE_MISSING',
  'NATIVE004_DECRYPT_SCHEME_UNAVAILABLE',
  'NATIVE004_RECEIPT_INVALID',
])

const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
const exactKeys = (value, keys) => record(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key))
const safeCount = (value) => Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000_000
const safeTimelineStart = (value) => Number.isSafeInteger(value) && value >= 0
const safeTimelineDuration = (value) => Number.isSafeInteger(value) && value > 0
const safeVersion = (value) => typeof value === 'string' && /^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(value)
const safeProfile = (value) => typeof value === 'string' && /^jianying-[a-z0-9-]{1,60}$/u.test(value)
const safeFamily = (value) => typeof value === 'string' && /^[a-z][a-z0-9_.-]{1,63}$/u.test(value)
const safeCode = (value) => typeof value === 'string' && /^NATIVE004_[A-Z0-9_]{1,80}$/u.test(value) && knownBlockers.has(value)

const samePath = (left, right) => process.platform === 'win32'
  ? resolve(left).toLowerCase() === resolve(right).toLowerCase()
  : resolve(left) === resolve(right)

const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (requestedMetadata.isSymbolicLink()) return false
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && !actualMetadata.isSymbolicLink() &&
    objectIdentity(requestedMetadata) === objectIdentity(actualMetadata)
}

const sortedUnique = (values, predicate) => Object.freeze([...new Set(values.filter(predicate))].sort())

const validateSummary = (value) => {
  if (!record(value) || !exactKeys(value, ['available', 'entries', 'families', 'profileId', 'appVersion'])) return false
  return value.available === true || value.available === false
    ? safeCount(value.entries) && Array.isArray(value.families) && value.families.length <= 64 && value.families.every(safeFamily) &&
      (value.profileId === null || safeProfile(value.profileId)) && (value.appVersion === null || safeVersion(value.appVersion))
    : false
}

const validateRootSummary = (value) => record(value) && exactKeys(value, ['available', 'rootCount', 'jsonFiles', 'bytes']) &&
  (value.available === true || value.available === false) && safeCount(value.rootCount) && safeCount(value.jsonFiles) && safeCount(value.bytes)

const validateEvidenceSummary = (value) => {
  if (!record(value) || !exactKeys(value, ['available', 'receiptCount', 'sameDraftReceipts', 'openedEditedSavedReopened', 'profileId', 'appVersion'])) return false
  return (value.available === true || value.available === false) && safeCount(value.receiptCount) && safeCount(value.sameDraftReceipts) &&
    value.sameDraftReceipts <= value.receiptCount && (value.available === true || (value.receiptCount === 0 && value.sameDraftReceipts === 0 && value.openedEditedSavedReopened === false && value.profileId === null && value.appVersion === null)) &&
    (value.sameDraftReceipts === 0 || value.openedEditedSavedReopened === true) &&
    (value.openedEditedSavedReopened === true || value.openedEditedSavedReopened === false) &&
    (value.profileId === null || safeProfile(value.profileId)) && (value.appVersion === null || safeVersion(value.appVersion))
}

const validateCodec = (value) => record(value) && exactKeys(value, ['scheme', 'supported']) &&
  (value.scheme === null || (typeof value.scheme === 'string' && /^[a-z][a-z0-9_]{1,40}$/u.test(value.scheme))) &&
  (value.supported === true || value.supported === false)

const validateDesktop = (value) => record(value) && exactKeys(value, ['available', 'profileId', 'appVersion', 'provisional', 'dllFingerprintPresent']) &&
  (value.available === true || value.available === false) && (value.profileId === null || safeProfile(value.profileId)) &&
  (value.appVersion === null || safeVersion(value.appVersion)) && (value.provisional === true || value.provisional === false) &&
  (value.dllFingerprintPresent === true || value.dllFingerprintPresent === false)

const unsignedReceipt = (receipt) => {
  const { integrity_fingerprint: _fingerprint, ...unsigned } = receipt
  return unsigned
}

const canonical = (value) => Array.isArray(value)
  ? `[${value.map(canonical).join(',')}]`
  : !record(value) ? JSON.stringify(value)
    : `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`

const integrityFingerprint = (receipt) => createHash('sha256').update(canonical(unsignedReceipt(receipt))).digest('hex')

const deriveBlockers = ({ desktop, roots, catalog, evidence, codec, draftAvailable, expectedProfile = expectedProfileId, expectedVersion = expectedAppVersion }) => {
  const blockers = []
  if (desktop.available !== true) blockers.push('NATIVE004_DESKTOP_UNAVAILABLE')
  if (desktop.profileId !== expectedProfile || desktop.appVersion !== expectedVersion) blockers.push('NATIVE004_EXACT_PROFILE_REQUIRED')
  if (roots.available !== true || roots.rootCount === 0) blockers.push('NATIVE004_RESOURCE_ROOTS_UNAVAILABLE')
  if (catalog.available !== true || catalog.entries === 0) blockers.push('NATIVE004_CATALOG_MISSING')
  else if (catalog.profileId !== expectedProfile || catalog.appVersion !== expectedVersion) blockers.push('NATIVE004_CATALOG_STALE')
  if (draftAvailable !== true) blockers.push('NATIVE004_DRAFT_UNAVAILABLE')
  if (evidence.available !== true || evidence.sameDraftReceipts === 0 || evidence.openedEditedSavedReopened !== true) blockers.push('NATIVE004_SAME_DRAFT_EVIDENCE_MISSING')
  else if (evidence.profileId !== expectedProfile || evidence.appVersion !== expectedVersion) blockers.push('NATIVE004_CATALOG_STALE')
  if (codec.supported !== true) blockers.push('NATIVE004_DECRYPT_SCHEME_UNAVAILABLE')
  return sortedUnique(blockers, safeCode)
}

const securePrivateRoot = async (candidate) => {
  const root = resolve(candidate)
  await mkdir(root, { recursive: true, mode: 0o700 })
  const metadata = await lstat(root, { bigint: true })
  const actual = await realpath(root)
  if (!metadata.isDirectory() || !await sameResolvedObject(root, actual, metadata)) {
    throw new Error('NATIVE004_PRIVATE_ROOT_UNSAFE')
  }
}

const replaceAtomic = async (temporary, output) => {
  const backup = `${output}.bak`
  let moved = false
  try {
    try {
      await lstat(output)
      await rename(output, backup)
      moved = true
    } catch {
      // Recover an older receipt if a prior process crashed after moving the
      // primary to backup but before installing its replacement.
      try { await lstat(backup); await rename(backup, output) } catch { /* first publication */ }
    }
    await rename(temporary, output)
    if (moved) await rm(backup, { force: true })
  } catch (error) {
    if (moved) { try { await rename(backup, output) } catch { /* preserve fail-closed error */ } }
    throw error
  }
}

/**
 * Build a private, path-free receipt from server-owned summaries. This does
 * not inspect or decode drafts; callers must provide only bounded summaries.
 */
export const createNativeEvidencePreflightReceipt = ({
  desktop,
  roots,
  catalog,
  evidence,
  codec,
  draftAvailable = false,
  expectedProfile = typeof desktop?.profileId === 'string' ? desktop.profileId : expectedProfileId,
  expectedVersion = typeof desktop?.version === 'string' ? desktop.version : expectedAppVersion,
  catalogFingerprint = null,
  evidenceIdentityFingerprint = null,
  rootIdentityFingerprint = null,
  now = Date.now(),
  nonce = randomBytes(8).toString('hex'),
}) => {
  const safeDesktop = record(desktop)
    ? {
        available: desktop.available === true,
        profileId: typeof desktop.profileId === 'string' ? desktop.profileId : null,
        appVersion: typeof desktop.version === 'string' ? desktop.version : null,
        provisional: desktop.provisional === true,
        dllFingerprintPresent: typeof desktop.dllFingerprint === 'string' && fingerprintPattern.test(desktop.dllFingerprint),
      }
    : { available: false, profileId: null, appVersion: null, provisional: false, dllFingerprintPresent: false }
  const safeRoots = record(roots) ? roots : { available: false, rootCount: 0, jsonFiles: 0, bytes: 0 }
  const safeCatalog = record(catalog) ? catalog : { available: false, entries: 0, families: [], profileId: null, appVersion: null }
  const safeEvidence = record(evidence) ? evidence : { available: false, receiptCount: 0, sameDraftReceipts: 0, openedEditedSavedReopened: false, profileId: null, appVersion: null }
  const safeCodec = record(codec) ? codec : { scheme: null, supported: false }
  if (!validateDesktop(safeDesktop) || !validateRootSummary(safeRoots) || !validateSummary(safeCatalog) || !validateEvidenceSummary(safeEvidence) || !validateCodec(safeCodec) ||
      !safeProfile(expectedProfile) || !safeVersion(expectedVersion) ||
      (catalogFingerprint !== null && !fingerprintPattern.test(catalogFingerprint)) ||
      (evidenceIdentityFingerprint !== null && !fingerprintPattern.test(evidenceIdentityFingerprint)) ||
      (rootIdentityFingerprint !== null && !fingerprintPattern.test(rootIdentityFingerprint)) ||
      (safeEvidence.available === true && evidenceIdentityFingerprint === null) ||
      !Number.isSafeInteger(now) || now < 0 || typeof nonce !== 'string' || !/^[a-f0-9]{8,64}$/u.test(nonce) || draftAvailable !== true && draftAvailable !== false) {
    throw new Error('NATIVE004_RECEIPT_INVALID')
  }
  const uniqueBlockers = deriveBlockers({ desktop: safeDesktop, roots: safeRoots, catalog: safeCatalog, evidence: safeEvidence, codec: safeCodec, draftAvailable, expectedProfile, expectedVersion })
  const status = safeDesktop.available !== true || safeRoots.available !== true ? 'fail' : uniqueBlockers.length === 0 ? 'ready' : 'partial'
  const receipt = {
    schema_version: 1,
    kind: 'native_004_jianying_evidence_preflight_receipt',
    receipt_id: `ovnative004preflight_v1_${now}_${nonce}`,
    status,
    scope: currentEvidenceScope,
    desktop: safeDesktop,
    expected_profile_id: expectedProfile,
    expected_app_version: expectedVersion,
    catalog_fingerprint: catalogFingerprint,
    evidence_identity_fingerprint: safeEvidence.available === true ? evidenceIdentityFingerprint : null,
    root_identity_fingerprint: rootIdentityFingerprint,
    roots: safeRoots,
    catalog: { available: safeCatalog.available, entries: safeCatalog.entries, families: sortedUnique(safeCatalog.families, safeFamily), profileId: safeCatalog.profileId, appVersion: safeCatalog.appVersion },
    evidence: safeEvidence,
    codec: safeCodec,
    draft_available: draftAvailable,
    blockers: uniqueBlockers,
    integrity_revision: receiptRevision,
  }
  return Object.freeze({ ...receipt, integrity_fingerprint: integrityFingerprint(receipt) })
}

/**
 * Run server-owned checks and return a private receipt; no caller path is accepted.
 * @param {{detectDesktop: Function, summarizeRoots: Function, summarizeCatalog: Function, summarizeEvidence: Function, resolveEvidenceIdentity?: Function, resolveCodec: Function, resolveDraftAvailability: Function, expectedProfile?: string, expectedVersion?: string, catalogFingerprint?: string|null, rootIdentityFingerprint?: string|null}} input
 */
export const runNativeEvidencePreflight = async ({ detectDesktop, summarizeRoots, summarizeCatalog, summarizeEvidence, resolveEvidenceIdentity = async () => null, resolveCodec, resolveDraftAvailability, expectedProfile = undefined, expectedVersion = undefined, catalogFingerprint = null, rootIdentityFingerprint = null }) => {
  if (typeof detectDesktop !== 'function' || typeof summarizeRoots !== 'function' || typeof summarizeCatalog !== 'function' || typeof summarizeEvidence !== 'function' || typeof resolveCodec !== 'function' || typeof resolveDraftAvailability !== 'function') throw new Error('NATIVE004_RECEIPT_INVALID')
  let desktop = null
  try {
    const candidate = await detectDesktop()
    desktop = record(candidate) && candidate.available === true && typeof candidate.profileId === 'string' && typeof candidate.version === 'string'
      ? candidate
      : null
  } catch { desktop = null }
  let roots; try { roots = await summarizeRoots(desktop); if (!validateRootSummary(roots)) throw new Error('invalid') } catch { roots = { available: false, rootCount: 0, jsonFiles: 0, bytes: 0 } }
  let catalog; try { catalog = await summarizeCatalog(desktop); if (!validateSummary(catalog)) throw new Error('invalid') } catch { catalog = { available: false, entries: 0, families: [], profileId: null, appVersion: null } }
  let evidence; try { evidence = await summarizeEvidence(desktop); if (!validateEvidenceSummary(evidence)) throw new Error('invalid') } catch { evidence = { available: false, receiptCount: 0, sameDraftReceipts: 0, openedEditedSavedReopened: false, profileId: null, appVersion: null } }
  let evidenceIdentityFingerprint = null
  if (evidence.available === true) {
    try { evidenceIdentityFingerprint = fingerprintNativeEvidenceIdentity(await resolveEvidenceIdentity()) } catch { evidenceIdentityFingerprint = null }
    if (evidenceIdentityFingerprint === null) {
      evidence = { available: false, receiptCount: 0, sameDraftReceipts: 0, openedEditedSavedReopened: false, profileId: null, appVersion: null }
    }
  }
  let codec; try { codec = await resolveCodec(desktop); if (!validateCodec(codec)) throw new Error('invalid') } catch { codec = { scheme: null, supported: false } }
  let draftAvailable = false; try { draftAvailable = await resolveDraftAvailability(desktop) === true } catch { draftAvailable = false }
  return createNativeEvidencePreflightReceipt({
    desktop,
    roots,
    catalog,
    evidence,
    codec,
    draftAvailable,
    ...(expectedProfile === undefined ? {} : { expectedProfile }),
    ...(expectedVersion === undefined ? {} : { expectedVersion }),
    catalogFingerprint,
    evidenceIdentityFingerprint,
    rootIdentityFingerprint,
  })
}

export const publicNativeEvidencePreflight = (receipt) => {
  if (!parseNativeEvidencePreflightReceipt(receipt)) throw new Error('NATIVE004_RECEIPT_INVALID')
  return Object.freeze({ schema_version: 1, status: receipt.status, scope: currentEvidenceScope, profile_id: receipt.desktop.profileId, app_version: receipt.desktop.appVersion, resource_root_count: receipt.roots.rootCount, catalog_entries: receipt.catalog.entries, evidence_receipts: receipt.evidence.receiptCount, same_draft_evidence: receipt.evidence.sameDraftReceipts, blockers: receipt.blockers })
}

const receiptKeys = Object.freeze(['schema_version', 'kind', 'receipt_id', 'status', 'scope', 'desktop', 'expected_profile_id', 'expected_app_version', 'catalog_fingerprint', 'evidence_identity_fingerprint', 'root_identity_fingerprint', 'roots', 'catalog', 'evidence', 'codec', 'draft_available', 'blockers', 'integrity_revision', 'integrity_fingerprint'])
const preRootIdentityReceiptKeys = Object.freeze(['schema_version', 'kind', 'receipt_id', 'status', 'scope', 'desktop', 'expected_profile_id', 'expected_app_version', 'catalog_fingerprint', 'evidence_identity_fingerprint', 'roots', 'catalog', 'evidence', 'codec', 'draft_available', 'blockers', 'integrity_revision', 'integrity_fingerprint'])
const previousCurrentReceiptKeys = Object.freeze(['schema_version', 'kind', 'receipt_id', 'status', 'scope', 'desktop', 'expected_profile_id', 'expected_app_version', 'catalog_fingerprint', 'roots', 'catalog', 'evidence', 'codec', 'draft_available', 'blockers', 'integrity_revision', 'integrity_fingerprint'])
const legacyReceiptKeys = Object.freeze(['schema_version', 'kind', 'receipt_id', 'status', 'scope', 'desktop', 'catalog_fingerprint', 'roots', 'catalog', 'evidence', 'codec', 'draft_available', 'blockers', 'integrity_revision', 'integrity_fingerprint'])

export const parseNativeEvidencePreflightReceipt = (receipt) => {
  const currentReceipt = exactKeys(receipt, receiptKeys)
  const preRootIdentityReceipt = exactKeys(receipt, preRootIdentityReceiptKeys)
  const previousCurrentReceipt = exactKeys(receipt, previousCurrentReceiptKeys)
  const legacyReceipt = exactKeys(receipt, legacyReceiptKeys)
  const scopeShapeValid = receipt.scope === currentEvidenceScope ? currentReceipt || preRootIdentityReceipt || previousCurrentReceipt : receipt.scope === legacyEvidenceScope ? legacyReceipt : false
  if ((!currentReceipt && !preRootIdentityReceipt && !previousCurrentReceipt && !legacyReceipt) || !scopeShapeValid || receipt.schema_version !== 1 || receipt.kind !== 'native_004_jianying_evidence_preflight_receipt' ||
      !receiptIdPattern.test(receipt.receipt_id ?? '') || !statusSet.has(receipt.status) || !acceptedEvidenceScopes.has(receipt.scope) ||
      !validateDesktop(receipt.desktop) || (currentReceipt || preRootIdentityReceipt || previousCurrentReceipt) && (!safeProfile(receipt.expected_profile_id) || !safeVersion(receipt.expected_app_version) || (receipt.catalog_fingerprint !== null && !fingerprintPattern.test(receipt.catalog_fingerprint))) || (currentReceipt || preRootIdentityReceipt) && (receipt.evidence_identity_fingerprint !== null && !fingerprintPattern.test(receipt.evidence_identity_fingerprint)) || currentReceipt && receipt.root_identity_fingerprint !== null && !fingerprintPattern.test(receipt.root_identity_fingerprint) || !validateRootSummary(receipt.roots) || !validateSummary(receipt.catalog) || !validateEvidenceSummary(receipt.evidence) ||
      currentReceipt && receipt.root_identity_fingerprint !== null && !fingerprintPattern.test(receipt.root_identity_fingerprint) ||
      !validateCodec(receipt.codec) || (receipt.draft_available !== true && receipt.draft_available !== false) || !Array.isArray(receipt.blockers) ||
      receipt.blockers.length > knownBlockers.size || new Set(receipt.blockers).size !== receipt.blockers.length || receipt.blockers.some((value) => !safeCode(value)) || receipt.integrity_revision !== receiptRevision ||
      !fingerprintPattern.test(receipt.integrity_fingerprint ?? '') || integrityFingerprint(receipt) !== receipt.integrity_fingerprint) return null
  const expectedProfile = legacyReceipt ? receipt.desktop.profileId ?? expectedProfileId : receipt.expected_profile_id
  const expectedVersion = legacyReceipt ? receipt.desktop.appVersion ?? expectedAppVersion : receipt.expected_app_version
  const expectedBlockers = deriveBlockers({ desktop: receipt.desktop, roots: receipt.roots, catalog: receipt.catalog, evidence: receipt.evidence, codec: receipt.codec, draftAvailable: receipt.draft_available, expectedProfile, expectedVersion })
  const expectedStatus = receipt.desktop.available !== true || receipt.roots.available !== true ? 'fail' : expectedBlockers.length === 0 ? 'ready' : 'partial'
  if (receipt.status !== expectedStatus || canonical(receipt.blockers) !== canonical(expectedBlockers)) return null
  return Object.freeze({ ...receipt })
}

/**
 * A valid signature is not sufficient evidence if the private preflight was
 * copied from a previous machine state. Keep the freshness policy private and
 * bounded; callers may tighten it but cannot disable it with an invalid value.
 */
export const isNativeEvidencePreflightReceiptFresh = (receipt, { now = Date.now(), maxAgeMs = defaultReceiptMaxAgeMs } = {}) => {
  if (!parseNativeEvidencePreflightReceipt(receipt) || !Number.isSafeInteger(now) || now < 0 ||
      !Number.isSafeInteger(maxAgeMs) || maxAgeMs < 0 || maxAgeMs > defaultReceiptMaxAgeMs) return false
  const timestamp = Number(receipt.receipt_id.match(/^ovnative004preflight_v1_([0-9]{10,20})_/u)?.[1] ?? NaN)
  return Number.isSafeInteger(timestamp) && timestamp <= now + receiptClockSkewMs && now - timestamp <= maxAgeMs
}

/** Bind a private lifecycle receipt without copying its identifiers into the aggregate receipt. */
export const fingerprintNativeEvidenceIdentity = (identity) => {
  if (!record(identity) || !exactKeys(identity, ['evidenceId', 'draftId', 'bundleFingerprint', 'preOpenFingerprint', 'postSaveFingerprint', 'contentFingerprint', 'catalogFingerprint', 'integrityRevision', 'integritySignature', 'admittedBindings', 'admittedBindingCount']) ||
      !privateIdentityText(identity.evidenceId) || !privateIdentityText(identity.draftId) ||
      ![identity.bundleFingerprint, identity.preOpenFingerprint].every((value) => value === null || fingerprintPattern.test(value)) ||
      ![identity.postSaveFingerprint, identity.contentFingerprint, identity.catalogFingerprint].every((value) => fingerprintPattern.test(value)) ||
      !(identity.integrityRevision === null || Number.isSafeInteger(identity.integrityRevision) || privateIdentityText(identity.integrityRevision)) ||
      !privateIdentityText(identity.integritySignature) || !Array.isArray(identity.admittedBindings) || identity.admittedBindings.length > 128 ||
      !safeCount(identity.admittedBindingCount) || identity.admittedBindingCount !== identity.admittedBindings.length) return null
  const bindings = identity.admittedBindings.map((binding) => {
    if (!record(binding) || !exactKeys(binding, ['packaging_token', 'family', 'binding_fingerprint', 'target_start_us', 'target_duration_us']) ||
        !privateIdentityText(binding.packaging_token) || !safeFamily(binding.family) || !fingerprintPattern.test(binding.binding_fingerprint) ||
        !safeTimelineStart(binding.target_start_us) || !safeTimelineDuration(binding.target_duration_us)) return null
    return { ...binding }
  })
  if (bindings.some((binding) => binding === null)) return null
  return createHash('sha256').update(canonical({ ...identity, admittedBindings: bindings })).digest('hex')
}

/** Coalesce callers while rejecting an identity that changes during either read. */
export const createStableNativeEvidenceIdentityReader = ({ readIdentity }) => {
  if (typeof readIdentity !== 'function') throw new Error('NATIVE004_RECEIPT_INVALID')
  let inFlight = null
  return async () => {
    if (inFlight) return inFlight
    const operation = (async () => {
      try {
        // The second observation is an end-of-operation generation check.
        // Keeping it sequential ensures a concurrent caller cannot make two
        // old snapshots look stable while the first observation is in flight.
        const initial = await readIdentity()
        const latest = await readIdentity()
        if (!record(initial) || !record(latest) || canonical(initial) !== canonical(latest)) return null
        return initial
      } catch {
        return null
      }
    })()
    inFlight = operation
    try { return await operation } finally { if (inFlight === operation) inFlight = null }
  }
}

/**
 * Revalidate a stored aggregate receipt against the current server-owned
 * catalog and admission snapshot. Equivalent current admissions may reuse the
 * aggregate receipt; revoked or count-drifted admissions may not.
 */
export const isNativeEvidencePreflightReceiptCurrent = (receipt, identity) => {
  const parsed = parseNativeEvidencePreflightReceipt(receipt)
  if (!parsed || !record(identity) || (identity.catalogAvailable !== true && identity.catalogAvailable !== false) ||
      !safeCount(identity.entries) || !Array.isArray(identity.families) || !identity.families.every(safeFamily) ||
      (identity.profileId !== null && !safeProfile(identity.profileId)) ||
      (identity.appVersion !== null && !safeVersion(identity.appVersion)) ||
      (identity.catalogFingerprint !== null && !fingerprintPattern.test(identity.catalogFingerprint)) ||
      !safeCount(identity.resourceRootCount) || !fingerprintPattern.test(identity.rootSetFingerprint ?? '') ||
      (identity.desktopAvailable !== true && identity.desktopAvailable !== false) ||
      (identity.draftAvailable !== true && identity.draftAvailable !== false) ||
      (identity.admitted !== true && identity.admitted !== false) || !safeCount(identity.admittedBindingCount)) return false
  const evidenceIdentityFingerprint = fingerprintNativeEvidenceIdentity(identity.evidenceIdentity)
  const families = sortedUnique(identity.families, safeFamily)
  const catalogMatches = parsed.catalog.available === identity.catalogAvailable && (identity.catalogAvailable !== true
    ? parsed.catalog.entries === identity.entries && canonical(parsed.catalog.families) === canonical(families) && parsed.catalog.profileId === null && parsed.catalog.appVersion === null
    : parsed.catalog.profileId === identity.profileId && parsed.catalog.appVersion === identity.appVersion &&
      parsed.catalog.entries === identity.entries && canonical(parsed.catalog.families) === canonical(families)
  )
  const admissionMatches = identity.admitted === true
    ? parsed.evidence.available === true && parsed.evidence.sameDraftReceipts === 1 &&
      parsed.evidence.receiptCount === identity.admittedBindingCount &&
      parsed.evidence.profileId === identity.profileId && parsed.evidence.appVersion === identity.appVersion &&
      evidenceIdentityFingerprint !== null && parsed.evidence_identity_fingerprint === evidenceIdentityFingerprint
    : parsed.evidence.available === false && parsed.evidence.sameDraftReceipts === 0 &&
      parsed.evidence.receiptCount === 0 && identity.admittedBindingCount === 0 && parsed.evidence_identity_fingerprint === null
  const runtimeMatches = parsed.desktop.available === identity.desktopAvailable &&
    parsed.roots.rootCount === identity.resourceRootCount &&
    parsed.root_identity_fingerprint !== null && parsed.root_identity_fingerprint === identity.rootSetFingerprint &&
    parsed.draft_available === identity.draftAvailable
  return parsed.desktop.profileId === identity.profileId && parsed.desktop.appVersion === identity.appVersion &&
    runtimeMatches && catalogMatches && parsed.catalog_fingerprint === identity.catalogFingerprint && admissionMatches
}

// Receipt publication is server-owned.  A detached refresh can discover that
// it became stale only after its atomic replace completes; serialize that
// replace and the ownership-checked cleanup so it can never delete a receipt
// that a newer generation published in the gap between read and removal.
/** @type {Promise<void>} */
let nativeEvidenceReceiptPublicationTail = Promise.resolve()

const acquireNativeEvidenceReceiptPublicationLock = async () => {
  const previous = nativeEvidenceReceiptPublicationTail
  /** @type {() => void} */
  let release = () => {}
  nativeEvidenceReceiptPublicationTail = new Promise((resolve) => { release = resolve })
  await previous
  return release
}

/** Publish only inside a server-owned private runtime root using an atomic replace. */
export const publishNativeEvidencePreflightReceipt = async ({ dataRoot, receipt, fileName = 'preflight-receipt.json', secureRoot = securePrivateRoot, isCurrent = () => true }) => {
  if (typeof dataRoot !== 'string' || !isAbsolute(dataRoot) || typeof secureRoot !== 'function' || typeof isCurrent !== 'function' || !/^[a-z0-9][a-z0-9-]{0,80}\.json$/u.test(fileName) || !parseNativeEvidencePreflightReceipt(receipt)) throw new Error('NATIVE004_RECEIPT_INVALID')
  const root = join(resolve(dataRoot), 'evidence', 'native-004')
  const output = join(root, fileName)
  const temporary = `${output}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
  const bytes = `${JSON.stringify(receipt)}\n`
  const release = await acquireNativeEvidenceReceiptPublicationLock()
  try {
    if (!isCurrent()) throw new Error('NATIVE004_PREFLIGHT_STALE')
    await secureRoot(resolve(dataRoot)); await secureRoot(root)
    await writeFile(temporary, bytes, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    if (!isCurrent()) throw new Error('NATIVE004_PREFLIGHT_STALE')
    await replaceAtomic(temporary, output)
    // A timeout may detach this generation while the atomic replace awaits.
    // Remove only our exact bytes, never a newer generation's receipt.
    if (!isCurrent()) {
      const published = await readFile(output, 'utf8').catch(() => null)
      if (published === bytes) await rm(output, { force: true })
      throw new Error('NATIVE004_PREFLIGHT_STALE')
    }
  } finally {
    await rm(temporary, { force: true })
    release()
  }
  return Object.freeze({ ok: true, status: receipt.status, blocker_count: receipt.blockers.length })
}

export const loadNativeEvidencePreflightReceipt = async ({ dataRoot, fileName = 'preflight-receipt.json', secureRoot = securePrivateRoot, now = Date.now(), maxAgeMs = defaultReceiptMaxAgeMs }) => {
  if (typeof dataRoot !== 'string' || !isAbsolute(dataRoot) || !/^[a-z0-9][a-z0-9-]{0,80}\.json$/u.test(fileName)) throw new Error('NATIVE004_RECEIPT_INVALID')
  try {
    const root = join(resolve(dataRoot), 'evidence', 'native-004')
    await secureRoot(resolve(dataRoot)); await secureRoot(root)
    const receipt = parseNativeEvidencePreflightReceipt(JSON.parse(await readFile(join(root, fileName), 'utf8')))
    return receipt && isNativeEvidencePreflightReceiptFresh(receipt, { now, maxAgeMs }) ? receipt : null
  } catch { return null }
}

/**
 * Keep server-owned evidence refreshes single-flight and bounded. A timeout
 * operation. A timed-out generation is detached so the next recovery attempt
 * obtains a new current identity; the operation receives `isCurrent` and must
 * refuse to publish a late generation.
 * @template T
 * @param {{operation: () => Promise<T> | T, timeoutMs?: number}} input
 * @returns {{run: (options?: {timeoutMs?: number}) => Promise<T>}}
 */
export const createNativeEvidenceRefreshGate = ({ operation, timeoutMs = 15_000 }) => {
  if (typeof operation !== 'function' || !Number.isSafeInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > 15_000) {
    throw new Error('NATIVE004_REFRESH_GATE_INVALID')
  }
  /** @type {Promise<any> | null} */
  let inFlight = null
  let generation = 0
  const run = ({ timeoutMs: callerTimeoutMs = timeoutMs } = {}) => {
    if (!Number.isSafeInteger(callerTimeoutMs) || callerTimeoutMs <= 0 || callerTimeoutMs > timeoutMs) {
      return Promise.reject(new Error('NATIVE004_REFRESH_GATE_INVALID'))
    }
    if (!inFlight) {
      const currentGeneration = ++generation
      let operationPromise
      try {
        operationPromise = Promise.resolve(operation({
          generation: currentGeneration,
          isCurrent: () => currentGeneration === generation,
        }))
      } catch (error) { operationPromise = Promise.reject(error) }
      /** @type {Promise<any>} */
      let settled
      settled = operationPromise.finally(() => {
        if (inFlight === settled) inFlight = null
      })
      inFlight = settled
    }
    const current = inFlight
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        if (inFlight === current) {
          generation += 1
          inFlight = null
        }
        reject(new Error('NATIVE004_PREFLIGHT_TIMEOUT'))
      }, callerTimeoutMs)
      current.then((value) => { clearTimeout(timer); resolve(value) }, (error) => { clearTimeout(timer); reject(error) })
    })
  }
  return Object.freeze({ run })
}

/**
 * Retry the existing bounded refresh gate during startup without creating a
 * second refresh manager. Each non-timeout failure gets a fresh gate operation;
 * timeout coalescing remains owned by the gate so late results cannot publish
 * outside its identity checks.
 * @param {{refresh: (timeoutMs: number) => Promise<unknown>, attempts?: number, backoffMs?: number, deadlineMs?: number, now?: () => number, sleep?: (ms: number) => Promise<void>}} input
 * @returns {Promise<unknown>}
 */
/**
 * Startup already has a 15-second rebuild budget. When a fresh receipt still
 * matches the current desktop / catalog / admission identity, reuse it instead
 * of forcing another full Native scan that routinely times out on large
 * private resource trees.
 * @param {{loadReceipt: () => Promise<unknown>, readIdentity: () => Promise<unknown>}} input
 */
export const adoptCurrentNativeEvidenceStartupReceipt = async ({
  loadReceipt,
  readIdentity,
}) => {
  if (typeof loadReceipt !== 'function' || typeof readIdentity !== 'function') {
    throw new Error('NATIVE004_STARTUP_RECOVERY_INVALID')
  }
  const receipt = await loadReceipt()
  if (!record(receipt) || !parseNativeEvidencePreflightReceipt(receipt)) return null
  try {
    const identity = await readIdentity()
    return isNativeEvidencePreflightReceiptCurrent(receipt, identity) ? receipt : null
  } catch {
    return null
  }
}

export const runNativeEvidenceStartupRecovery = async ({
  refresh,
  attempts = 3,
  backoffMs = 250,
  deadlineMs = 15_000,
  now = Date.now,
  sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
}) => {
  if (typeof refresh !== 'function' || !Number.isSafeInteger(attempts) || attempts < 1 || attempts > 3 ||
      !Number.isSafeInteger(backoffMs) || backoffMs < 0 || backoffMs > 5_000 ||
      !Number.isSafeInteger(deadlineMs) || deadlineMs <= 0 || deadlineMs > 15_000 ||
      typeof now !== 'function' || typeof sleep !== 'function') {
    throw new Error('NATIVE004_STARTUP_RECOVERY_INVALID')
  }
  const startedAt = now()
  if (!Number.isFinite(startedAt)) throw new Error('NATIVE004_STARTUP_RECOVERY_INVALID')
  let lastError = null
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const remainingMs = Math.floor(deadlineMs - (now() - startedAt))
    if (remainingMs <= 0) throw new Error('NATIVE004_PREFLIGHT_TIMEOUT')
    try { return await refresh(remainingMs) } catch (error) {
      lastError = error
      if (attempt + 1 < attempts && backoffMs > 0) {
        const remainingAfterFailure = Math.floor(deadlineMs - (now() - startedAt))
        const delay = Math.min(backoffMs * (attempt + 1), Math.max(0, remainingAfterFailure - 1))
        if (delay > 0) await sleep(delay)
      }
    }
  }
  throw lastError ?? new Error('NATIVE004_EVIDENCE_REFRESH_FAILED')
}

export { expectedProfileId, expectedAppVersion, receiptRevision }
