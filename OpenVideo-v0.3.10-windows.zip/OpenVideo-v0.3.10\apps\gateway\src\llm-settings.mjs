import { spawn } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { copyFile, lstat, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve } from 'node:path'

const schemaVersion = 1
const inputKeys = ['apiKey', 'baseUrl', 'jsonModel', 'textModel', 'visionModel']
const modelPattern = /^[a-z0-9][a-z0-9._:/-]{0,159}$/iu

/**
 * @typedef {{
 *   baseUrl: string,
 *   apiKey: string,
 *   textModel: string,
 *   visionModel: string,
 *   jsonModel: string,
 * }} LlmSettingsInput
 * @typedef {{
 *   baseUrl: string,
 *   apiKey: string,
 * }} LlmModelsProbeInput
 * @typedef {{
 *   schema_version: 1,
 *   models: string[],
 * }} LlmModelsList
 * @typedef {{
 *   schema_version: 1,
 *   configured: boolean,
 *   reachable: boolean,
 *   checkedAt: string,
 *   reason: 'unconfigured' | 'auth_failed' | 'unreachable' | 'invalid_response' | null,
 * }} LlmConnectionStatus
 * @typedef {(input: {secret: string, revision: string}) => Promise<string>} ProtectSecret
 * @typedef {(input: {protectedSecret: string, revision: string}) => Promise<string | null>} UnprotectSecret
 * @typedef {{
 *   revision: string,
 *   provider: string,
 *   baseUrl: string,
 *   apiKey: string,
 *   textModel: string,
 *   visionModel: string,
 *   jsonModel: string,
 * }} LlmRuntimeConfig
 * @typedef {{
 *   readPublic: () => Promise<Record<string, unknown>>,
 *   save: (input: unknown) => Promise<{
 *     public: Record<string, unknown>,
 *     runtime: LlmRuntimeConfig,
 *   }>,
 *   listModels: (input: unknown) => Promise<LlmModelsList>,
 *   probeStatus: () => Promise<LlmConnectionStatus>,
 *   resolveRuntimeConfig: () => Promise<LlmRuntimeConfig | null>,
 * }} LlmSettingsService
 */

const modelsProbeKeys = ['apiKey', 'baseUrl']
const maxListedModels = 200
const modelsRequestTimeoutMs = 15_000
const modelsRequestAttempts = 2
const modelsRetryDelayMs = 250
const statusCacheMs = 120_000
const generateProbeTimeoutMs = 90_000
const connectivityProbeSchema = Object.freeze({
  name: 'llm_connectivity_probe',
  schema: Object.freeze({
    type: 'object',
    additionalProperties: false,
    required: ['confirmation'],
    properties: Object.freeze({
      confirmation: Object.freeze({ type: 'string', const: 'ok' }),
    }),
  }),
})
const retryableModelsStatuses = new Set([408, 425, 429, 500, 502, 503, 504])

/** @param {unknown} error */
const reasonFromProbeError = (error) => {
  const code = error && typeof error === 'object' && 'code' in error
    ? String(/** @type {{code?: unknown}} */ (error).code)
    : ''
  if (code === 'PROVIDER_AUTH_FAILED' || code === 'LLM_MODELS_AUTH_FAILED') return 'auth_failed'
  if (
    code === 'LLM_MODELS_INVALID_RESPONSE' ||
    code === 'LLM_GATEWAY_RESPONSE_INVALID' ||
    code === 'INVALID_UPSTREAM_RESPONSE' ||
    code === 'invalid_llm_probe'
  ) return 'invalid_response'
  return 'unreachable'
}

/** @param {unknown} reason */
const toStatusReason = (reason) => {
  if (reason === 'unconfigured' || reason === 'auth_failed' || reason === 'unreachable' || reason === 'invalid_response') {
    return reason
  }
  return 'unreachable'
}

/** @param {{configured: boolean, reachable: boolean, reason: LlmConnectionStatus['reason']}} input @returns {LlmConnectionStatus} */
const toConnectionStatus = ({ configured, reachable, reason }) => ({
  schema_version: /** @type {1} */ (1),
  configured,
  reachable,
  checkedAt: new Date().toISOString(),
  reason: reachable ? null : toStatusReason(reason),
})

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) =>
  Boolean(value) && typeof value === 'object' && !Array.isArray(value)

export class LlmSettingsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'LlmSettingsError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value */
const validateBaseUrl = (value) => {
  if (typeof value !== 'string' || value.length > 2_048 || value.trim() !== value) return null
  try {
    const normalized = value.replace(/\/+$/u, '')
    const parsed = new URL(normalized)
    if (
      parsed.protocol !== 'https:' ||
      parsed.username ||
      parsed.password ||
      parsed.search ||
      parsed.hash
    ) return null
    return parsed.pathname === '/' ? `${normalized}/v1` : normalized
  } catch {
    return null
  }
}

/** @param {unknown} input @returns {LlmSettingsInput} */
const validateInput = (input) => {
  if (
    !isRecord(input) ||
    Object.keys(input).sort().join('\u0000') !== inputKeys.join('\u0000')
  ) throw new LlmSettingsError('LLM_SETTINGS_INVALID')
  const baseUrl = validateBaseUrl(input.baseUrl)
  if (
    !baseUrl ||
    typeof input.apiKey !== 'string' ||
    input.apiKey.length > 4_096 ||
    /[\u0000\r\n]/u.test(input.apiKey) ||
    typeof input.textModel !== 'string' ||
    typeof input.visionModel !== 'string' ||
    typeof input.jsonModel !== 'string' ||
    !modelPattern.test(input.textModel) ||
    !modelPattern.test(input.visionModel) ||
    !modelPattern.test(input.jsonModel)
  ) throw new LlmSettingsError('LLM_SETTINGS_INVALID')
  return {
    baseUrl,
    apiKey: input.apiKey,
    textModel: input.textModel,
    visionModel: input.visionModel,
    jsonModel: input.jsonModel,
  }
}

/** @param {unknown} input @returns {LlmModelsProbeInput} */
const validateModelsProbeInput = (input) => {
  if (
    !isRecord(input) ||
    Object.keys(input).sort().join('\u0000') !== modelsProbeKeys.join('\u0000')
  ) throw new LlmSettingsError('LLM_SETTINGS_INVALID')
  const baseUrl = validateBaseUrl(input.baseUrl)
  if (
    !baseUrl ||
    typeof input.apiKey !== 'string' ||
    input.apiKey.length > 4_096 ||
    /[\u0000\r\n]/u.test(input.apiKey)
  ) throw new LlmSettingsError('LLM_SETTINGS_INVALID')
  return {
    baseUrl,
    apiKey: input.apiKey,
  }
}

/** @param {unknown} body @returns {string[]} */
const parseUpstreamModelIds = (body) => {
  const rows = Array.isArray(body)
    ? body
    : isRecord(body) && Array.isArray(body.data)
      ? body.data
      : null
  if (!rows) throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
  /** @type {string[]} */
  const models = []
  const seen = new Set()
  for (const row of rows) {
    const id = typeof row === 'string'
      ? row
      : isRecord(row) && typeof row.id === 'string'
        ? row.id
        : null
    if (!id || !modelPattern.test(id) || seen.has(id)) continue
    seen.add(id)
    models.push(id)
    if (models.length >= maxListedModels) break
  }
  return models.sort((left, right) => left.localeCompare(right))
}

/** @param {string} configPath @returns {Promise<Record<string, unknown>>} */
const readConfig = async (configPath) => {
  const parseConfig = (/** @type {string} */ text) => {
    const parsed = JSON.parse(text)
    if (!isRecord(parsed) || parsed.schema_version !== schemaVersion) {
      throw new Error('invalid_config')
    }
    return parsed
  }
  try {
    return parseConfig(await readFile(configPath, 'utf8'))
  } catch (primaryError) {
    try {
      const backupText = await readFile(`${configPath}.bak`, 'utf8')
      const recovered = parseConfig(backupText)
      const recoveryPath = `${configPath}.${randomUUID()}.recovery`
      await writeFile(recoveryPath, backupText, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
      try {
        await rename(recoveryPath, configPath)
      } finally {
        await rm(recoveryPath, { force: true })
      }
      return recovered
    } catch {
      if (
        primaryError &&
        typeof primaryError === 'object' &&
        'code' in primaryError &&
        primaryError.code === 'ENOENT'
      ) return { schema_version: schemaVersion }
      throw new LlmSettingsError('LLM_SETTINGS_STORAGE_INVALID', 500)
    }
  }
}

/**
 * @param {string} revision
 * @param {string} protectedSecret
 */
const apiKeyVerifyCacheKey = (revision, protectedSecret) =>
  `${revision}\u0000${protectedSecret}`

/**
 * @param {Record<string, unknown>} config
 * @param {UnprotectSecret} unprotectSecret
 * @param {{
 *   verifyCache?: Map<string, boolean>,
 *   knownApiKeySaved?: boolean,
 * }} [options]
 */
const toPublicSettings = async (config, unprotectSecret, options = {}) => {
  const revision = typeof config.llm_revision === 'string' ? config.llm_revision : null
  let apiKeySaved = false
  if (revision && typeof config.llm_api_key_dpapi === 'string') {
    if (typeof options.knownApiKeySaved === 'boolean') {
      apiKeySaved = options.knownApiKeySaved
      if (apiKeySaved) {
        options.verifyCache?.set(
          apiKeyVerifyCacheKey(revision, config.llm_api_key_dpapi),
          true,
        )
      }
    } else {
      const cacheKey = apiKeyVerifyCacheKey(revision, config.llm_api_key_dpapi)
      if (options.verifyCache?.has(cacheKey)) {
        apiKeySaved = Boolean(options.verifyCache.get(cacheKey))
      } else if (
        process.env.OPENVIDEO_LLM_REVISION === revision &&
        typeof process.env.OPENVIDEO_LLM_API_KEY === 'string' &&
        process.env.OPENVIDEO_LLM_API_KEY.length > 0
      ) {
        // Launcher already decrypted this revision into the process environment.
        apiKeySaved = true
        options.verifyCache?.set(cacheKey, true)
      } else {
        try {
          apiKeySaved = Boolean(await unprotectSecret({
            protectedSecret: config.llm_api_key_dpapi,
            revision,
          }))
        } catch {
          apiKeySaved = false
        }
        if (apiKeySaved) options.verifyCache?.set(cacheKey, true)
      }
    }
  }
  const configuredBaseUrl = typeof config.llm_base_url === 'string' ? config.llm_base_url : ''
  const baseUrl = validateBaseUrl(configuredBaseUrl) ?? ''
  const textModel = typeof config.llm_text_model === 'string' ? config.llm_text_model : ''
  const visionModel = typeof config.llm_vision_model === 'string' ? config.llm_vision_model : ''
  const jsonModel = typeof config.llm_json_model === 'string' ? config.llm_json_model : ''
  const modelsValid = [textModel, visionModel, jsonModel].every(
    (model) => modelPattern.test(model) && !model.startsWith('REPLACE_WITH_'),
  )
  return {
    schema_version: schemaVersion,
    revision,
    configured: Boolean(
      baseUrl &&
      !configuredBaseUrl.includes('REPLACE_WITH_') &&
      modelsValid &&
      apiKeySaved,
    ),
    provider: 'openai-compatible',
    baseUrl,
    textModel,
    visionModel,
    jsonModel,
    apiKeySaved,
  }
}

/** @type {ProtectSecret} */
export const protectSecretWithDpapi = async ({ secret, revision }) => {
  if (process.platform !== 'win32') {
    throw new LlmSettingsError('LLM_SETTINGS_DPAPI_UNAVAILABLE', 503)
  }
  const script = [
    "$ErrorActionPreference = 'Stop'",
    'Add-Type -AssemblyName System.Security',
    '$plain = [Text.Encoding]::UTF8.GetBytes([Console]::In.ReadToEnd())',
    '$entropy = [Text.Encoding]::UTF8.GetBytes($env:OPENVIDEO_LLM_REVISION)',
    '$cipher = [Security.Cryptography.ProtectedData]::Protect($plain, $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)',
    '[Console]::Out.Write([Convert]::ToBase64String($cipher))',
  ].join('; ')
  /** @type {Promise<string>} */
  return new Promise((resolve, reject) => {
    /** @type {Buffer[]} */
    const chunks = []
    const child = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      {
        env: { ...process.env, OPENVIDEO_LLM_REVISION: revision },
        stdio: ['pipe', 'pipe', 'ignore'],
        windowsHide: true,
      },
    )
    child.stdout.on('data', (chunk) => chunks.push(chunk))
    child.once('error', () => reject(new LlmSettingsError('LLM_SETTINGS_DPAPI_FAILED', 500)))
    child.once('exit', (code) => {
      const protectedSecret = Buffer.concat(chunks).toString('utf8')
      if (code === 0 && protectedSecret.length > 0 && protectedSecret.length <= 16_384) {
        resolve(protectedSecret)
      }
      else reject(new LlmSettingsError('LLM_SETTINGS_DPAPI_FAILED', 500))
    })
    child.stdin.end(secret)
  })
}

/** @type {UnprotectSecret} */
export const unprotectSecretWithDpapi = async ({ protectedSecret, revision }) => {
  if (process.platform !== 'win32') {
    throw new LlmSettingsError('LLM_SETTINGS_DPAPI_UNAVAILABLE', 503)
  }
  const script = [
    "$ErrorActionPreference = 'Stop'",
    'Add-Type -AssemblyName System.Security',
    '$cipher = [Convert]::FromBase64String([Console]::In.ReadToEnd())',
    '$entropy = [Text.Encoding]::UTF8.GetBytes($env:OPENVIDEO_LLM_REVISION)',
    '$plain = [Security.Cryptography.ProtectedData]::Unprotect($cipher, $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)',
    '[Console]::Out.Write([Text.Encoding]::UTF8.GetString($plain))',
  ].join('; ')
  /** @type {string} */
  const plaintext = await new Promise((resolve, reject) => {
    /** @type {Buffer[]} */
    const chunks = []
    let length = 0
    const child = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      {
        env: { ...process.env, OPENVIDEO_LLM_REVISION: revision },
        stdio: ['pipe', 'pipe', 'ignore'],
        windowsHide: true,
      },
    )
    child.stdout.on('data', (chunk) => {
      length += chunk.length
      if (length <= 8_192) chunks.push(chunk)
      else child.kill()
    })
    child.once('error', () => reject(new LlmSettingsError('LLM_SETTINGS_DPAPI_FAILED', 500)))
    child.once('exit', (code) => {
      if (code === 0 && length <= 8_192) resolve(Buffer.concat(chunks).toString('utf8'))
      else reject(new LlmSettingsError('LLM_SETTINGS_DPAPI_FAILED', 500))
    })
    child.stdin.end(protectedSecret)
  })
  return plaintext || null
}

/**
 * @param {{
 *   configPath: string,
 *   privateConfigRoot: string,
 *   secretPath?: string,
 *   protectSecret?: ProtectSecret,
 *   unprotectSecret?: UnprotectSecret,
 *   fetchImpl?: typeof fetch,
 *   probeGenerate?: () => Promise<{outputJson?: unknown}>,
 * }} options
 * @returns {LlmSettingsService}
 */
export const createLlmSettingsService = ({
  configPath,
  privateConfigRoot,
  protectSecret = protectSecretWithDpapi,
  unprotectSecret = unprotectSecretWithDpapi,
  fetchImpl = globalThis.fetch.bind(globalThis),
  probeGenerate,
}) => {
  if (
    !configPath ||
    !privateConfigRoot ||
    !isAbsolute(configPath) ||
    !isAbsolute(privateConfigRoot) ||
    relative(resolve(privateConfigRoot), resolve(configPath)).startsWith('..') ||
    isAbsolute(relative(resolve(privateConfigRoot), resolve(configPath))) ||
    typeof protectSecret !== 'function' ||
    typeof unprotectSecret !== 'function' ||
    typeof fetchImpl !== 'function'
  ) {
    throw new LlmSettingsError('LLM_SETTINGS_STORAGE_INVALID', 500)
  }
  let serialization = Promise.resolve()
  /** @type {Map<string, boolean>} */
  const apiKeyVerifyCache = new Map()
  /** @type {{ expiresAt: number, value: LlmConnectionStatus } | null} */
  let statusCache = null
  /** @type {Promise<LlmConnectionStatus> | null} */
  let probeInFlight = null
  let probeGeneration = 0
  const resolvedConfigPath = resolve(configPath)
  const resolvedPrivateRoot = resolve(privateConfigRoot)
  const ensurePrivatePath = async () => {
    const segments = relative(resolvedPrivateRoot, dirname(resolvedConfigPath))
      .split(/[\\/]/u)
      .filter(Boolean)
    let current = resolvedPrivateRoot
    for (const segment of ['', ...segments]) {
      if (segment) current = resolve(current, segment)
      try {
        if ((await lstat(current)).isSymbolicLink()) {
          throw new LlmSettingsError('LLM_SETTINGS_STORAGE_INVALID', 500)
        }
      } catch (error) {
        if (error instanceof LlmSettingsError) throw error
        if (!error || typeof error !== 'object' || !('code' in error) || error.code !== 'ENOENT') {
          throw new LlmSettingsError('LLM_SETTINGS_STORAGE_INVALID', 500)
        }
      }
    }
    try {
      if ((await lstat(resolvedConfigPath)).isSymbolicLink()) {
        throw new LlmSettingsError('LLM_SETTINGS_STORAGE_INVALID', 500)
      }
    } catch (error) {
      if (error instanceof LlmSettingsError) throw error
      if (!error || typeof error !== 'object' || !('code' in error) || error.code !== 'ENOENT') {
        throw new LlmSettingsError('LLM_SETTINGS_STORAGE_INVALID', 500)
      }
    }
  }
  /** @template T @param {() => Promise<T>} operation @returns {Promise<T>} */
  const runSerialized = (operation) => {
    const result = serialization.then(operation, operation)
    serialization = result.then(() => {}, () => {})
    return result
  }
  /** @param {string} baseUrl @param {string} apiKey */
  const requestUpstreamModels = async (baseUrl, apiKey) => {
    /** @type {Response | undefined} */
    let response
    for (let attempt = 1; attempt <= modelsRequestAttempts; attempt += 1) {
      try {
        response = await fetchImpl(`${baseUrl}/models`, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          signal: AbortSignal.timeout(modelsRequestTimeoutMs),
        })
      } catch {
        if (attempt === modelsRequestAttempts) throw new LlmSettingsError('LLM_MODELS_UNREACHABLE', 502)
        await new Promise((resolve) => setTimeout(resolve, modelsRetryDelayMs))
        continue
      }
      if (response.status === 401 || response.status === 403) {
        throw new LlmSettingsError('LLM_MODELS_AUTH_FAILED', 502)
      }
      if (response.ok || !retryableModelsStatuses.has(response.status) || attempt === modelsRequestAttempts) break
      await new Promise((resolve) => setTimeout(resolve, modelsRetryDelayMs))
    }
    if (!response || !response.ok) throw new LlmSettingsError('LLM_MODELS_UNREACHABLE', 502)
    let body
    try {
      body = await response.json()
    } catch {
      throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
    }
    return parseUpstreamModelIds(body)
  }
  /**
   * Same confirmation the settings live chip and "重新检测" button require. A models
   * directory ping is not enough for AI Editor / storyboard JSON work.
   * @param {LlmRuntimeConfig} runtime
   */
  const requestUpstreamJsonProbe = async (runtime) => {
    /** @type {Response | undefined} */
    let response
    try {
      response = await fetchImpl(`${runtime.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${runtime.apiKey}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          model: runtime.jsonModel,
          messages: [{
            role: 'user',
            content: 'Return exactly {"confirmation":"ok"}.',
          }],
          max_tokens: 256,
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: connectivityProbeSchema.name,
              strict: true,
              schema: connectivityProbeSchema.schema,
            },
          },
        }),
        signal: AbortSignal.timeout(generateProbeTimeoutMs),
      })
    } catch {
      throw new LlmSettingsError('LLM_MODELS_UNREACHABLE', 502)
    }
    if (response.status === 401 || response.status === 403) {
      throw new LlmSettingsError('LLM_MODELS_AUTH_FAILED', 502)
    }
    if (!response.ok) throw new LlmSettingsError('LLM_MODELS_UNREACHABLE', 502)
    let body
    try {
      body = await response.json()
    } catch {
      throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
    }
    const content = body?.choices?.[0]?.message?.content
    if (typeof content !== 'string') {
      throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
    }
    try {
      const parsed = JSON.parse(content.trim())
      if (parsed?.confirmation !== 'ok') {
        throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
      }
    } catch (error) {
      if (error instanceof LlmSettingsError) throw error
      throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
    }
  }
  const readRuntimeUnlocked = async () => {
    const current = await readConfig(resolvedConfigPath)
    const revision = typeof current.llm_revision === 'string' ? current.llm_revision : null
    const protectedSecret = typeof current.llm_api_key_dpapi === 'string'
      ? current.llm_api_key_dpapi
      : null
    const configuredBaseUrl = typeof current.llm_base_url === 'string' ? current.llm_base_url : ''
    const baseUrl = validateBaseUrl(configuredBaseUrl)
    const textModel = typeof current.llm_text_model === 'string' ? current.llm_text_model : ''
    const visionModel = typeof current.llm_vision_model === 'string' ? current.llm_vision_model : ''
    const jsonModel = typeof current.llm_json_model === 'string' ? current.llm_json_model : ''
    if (
      !revision ||
      !protectedSecret ||
      !baseUrl ||
      !modelPattern.test(textModel) ||
      !modelPattern.test(visionModel) ||
      !modelPattern.test(jsonModel)
    ) {
      return null
    }
    const apiKey = await unprotectSecret({
      protectedSecret,
      revision,
    }) || ''
    if (!apiKey) return null
    return {
      revision,
      provider: 'openai-compatible',
      baseUrl,
      apiKey,
      textModel,
      visionModel,
      jsonModel,
    }
  }
  return {
    readPublic() {
      return runSerialized(async () => {
        await ensurePrivatePath()
        return toPublicSettings(await readConfig(resolvedConfigPath), unprotectSecret, {
          verifyCache: apiKeyVerifyCache,
        })
      })
    },
    save(input) {
      return runSerialized(async () => {
        await ensurePrivatePath()
        const validated = validateInput(input)
        const current = await readConfig(resolvedConfigPath)
        const currentRevision = typeof current.llm_revision === 'string'
          ? current.llm_revision
          : null
        const currentProtected = typeof current.llm_api_key_dpapi === 'string'
          ? current.llm_api_key_dpapi
          : null
        const keyUnchanged = validated.apiKey.length === 0
        /** @type {string} */
        let apiKey
        /** @type {string} */
        let revision
        /** @type {string} */
        let protectedSecret

        if (keyUnchanged) {
          if (!currentRevision || !currentProtected) {
            throw new LlmSettingsError('LLM_SETTINGS_API_KEY_REQUIRED', 400)
          }
          if (
            process.env.OPENVIDEO_LLM_REVISION === currentRevision &&
            typeof process.env.OPENVIDEO_LLM_API_KEY === 'string' &&
            process.env.OPENVIDEO_LLM_API_KEY.length > 0
          ) {
            apiKey = process.env.OPENVIDEO_LLM_API_KEY
          } else {
            apiKey = await unprotectSecret({
              protectedSecret: currentProtected,
              revision: currentRevision,
            }) || ''
          }
          if (!apiKey) throw new LlmSettingsError('LLM_SETTINGS_API_KEY_REQUIRED', 400)
          // Keep the existing DPAPI blob and revision when the key is unchanged.
          revision = currentRevision
          protectedSecret = currentProtected
        } else {
          apiKey = validated.apiKey
          revision = randomUUID()
          protectedSecret = await protectSecret({
            secret: apiKey,
            revision,
          })
        }

        const next = {
          ...current,
          llm_revision: revision,
          llm_api_key_dpapi: protectedSecret,
          llm_provider: 'openai-compatible',
          llm_base_url: validated.baseUrl,
          llm_text_model: validated.textModel,
          llm_vision_model: validated.visionModel,
          llm_json_model: validated.jsonModel,
        }
        await mkdir(dirname(resolvedConfigPath), { recursive: true, mode: 0o700 })
        const configTemporaryPath = `${resolvedConfigPath}.${randomUUID()}.tmp`
        await writeFile(configTemporaryPath, `${JSON.stringify(next, null, 2)}\n`, {
          encoding: 'utf8',
          mode: 0o600,
          flag: 'wx',
        })
        try {
          await copyFile(resolvedConfigPath, `${resolvedConfigPath}.bak`).catch((error) => {
            if (error?.code !== 'ENOENT') throw error
          })
          await rename(configTemporaryPath, resolvedConfigPath)
          await copyFile(resolvedConfigPath, `${resolvedConfigPath}.bak`).catch(() => {})
        } catch (error) {
          throw error instanceof LlmSettingsError
            ? error
            : new LlmSettingsError('LLM_SETTINGS_STORAGE_WRITE_FAILED', 500)
        } finally {
          await rm(configTemporaryPath, { force: true })
        }
        apiKeyVerifyCache.clear()
        statusCache = null
        probeGeneration += 1
        const publicSettings = await toPublicSettings(next, unprotectSecret, {
          verifyCache: apiKeyVerifyCache,
          knownApiKeySaved: true,
        })
        return {
          public: publicSettings,
          runtime: {
            revision,
            provider: 'openai-compatible',
            baseUrl: validated.baseUrl,
            apiKey,
            textModel: validated.textModel,
            visionModel: validated.visionModel,
            jsonModel: validated.jsonModel,
          },
        }
      })
    },
    resolveRuntimeConfig() {
      return runSerialized(async () => {
        await ensurePrivatePath()
        return readRuntimeUnlocked()
      })
    },
    probeStatus() {
      if (statusCache && statusCache.expiresAt > Date.now()) {
        return Promise.resolve(statusCache.value)
      }
      if (probeInFlight) return probeInFlight
      const startedGeneration = probeGeneration
      probeInFlight = (async () => {
        try {
          await ensurePrivatePath()
          const runtime = await readRuntimeUnlocked()
          if (!runtime) {
            return toConnectionStatus({
              configured: false,
              reachable: false,
              reason: 'unconfigured',
            })
          }
          try {
            if (typeof probeGenerate === 'function') {
              const generated = await probeGenerate()
              if (generated?.outputJson?.confirmation !== 'ok') {
                throw new LlmSettingsError('LLM_MODELS_INVALID_RESPONSE', 502)
              }
            } else {
              await requestUpstreamJsonProbe(runtime)
            }
            const connected = toConnectionStatus({
              configured: true,
              reachable: true,
              reason: null,
            })
            if (startedGeneration === probeGeneration) {
              statusCache = { expiresAt: Date.now() + statusCacheMs, value: connected }
            }
            return connected
          } catch (error) {
            return toConnectionStatus({
              configured: true,
              reachable: false,
              reason: reasonFromProbeError(error),
            })
          }
        } catch {
          return toConnectionStatus({
            configured: true,
            reachable: false,
            reason: 'unreachable',
          })
        } finally {
          probeInFlight = null
        }
      })()
      return probeInFlight
    },
    listModels(input) {
      return runSerialized(async () => {
        const validated = validateModelsProbeInput(input)
        let apiKey = validated.apiKey
        if (!apiKey) {
          await ensurePrivatePath()
          const config = await readConfig(resolvedConfigPath)
          const revision = typeof config.llm_revision === 'string' ? config.llm_revision : null
          const protectedSecret = typeof config.llm_api_key_dpapi === 'string'
            ? config.llm_api_key_dpapi
            : null
          if (!revision || !protectedSecret) {
            throw new LlmSettingsError('LLM_SETTINGS_API_KEY_REQUIRED', 400)
          }
          apiKey = await unprotectSecret({ protectedSecret, revision }) || ''
          if (!apiKey) throw new LlmSettingsError('LLM_SETTINGS_API_KEY_REQUIRED', 400)
        }
        const models = await requestUpstreamModels(validated.baseUrl, apiKey)
        return {
          schema_version: 1,
          models,
        }
      })
    },
  }
}

/** @param {unknown} body @param {number} [status] */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  },
})

/**
 * @param {{service: LlmSettingsService, applyRuntimeConfig?: (runtime: LlmRuntimeConfig) => Promise<void>}} options
 * @returns {(request: Request) => Promise<Response>}
 */
export const createLlmSettingsHandler = ({ service, applyRuntimeConfig }) => async (request) => {
  const pathname = new URL(request.url).pathname
  if (pathname === '/api/settings/llm/status') {
    if (request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
      return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
    }
    try {
      await request.json()
      return jsonResponse(await service.probeStatus())
    } catch {
      return jsonResponse(toConnectionStatus({
        configured: true,
        reachable: false,
        reason: 'unreachable',
      }))
    }
  }
  if (pathname === '/api/settings/llm/models') {
    if (request.method !== 'POST') {
      return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
      return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
    }
    try {
      return jsonResponse(await service.listModels(await request.json()))
    } catch (error) {
      const status = error instanceof LlmSettingsError ? error.status : 502
      const code = error instanceof LlmSettingsError ? error.code : 'LLM_MODELS_UNREACHABLE'
      return jsonResponse({ error: { code, message: 'The model list could not be loaded safely.' } }, status)
    }
  }

  if (pathname !== '/api/settings/llm') {
    return jsonResponse({ error: { code: 'NOT_FOUND', message: 'Not found.' } }, 404)
  }
  if (request.method === 'GET') return jsonResponse(await service.readPublic())
  if (request.method !== 'PUT') {
    return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  }
  if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
  }
  try {
    const { public: saved, runtime } = await service.save(await request.json())
    if (applyRuntimeConfig) {
      await applyRuntimeConfig(runtime)
    }
    return jsonResponse({ ...saved, restartRequired: false }, 200)
  } catch (error) {
    const status = error instanceof LlmSettingsError ? error.status : 400
    const code = error instanceof LlmSettingsError ? error.code : 'LLM_SETTINGS_INVALID'
    return jsonResponse({ error: { code, message: 'The LLM settings could not be saved.' } }, status)
  }
}
