import {
  persistJianyingPrivateResourceCatalog,
  scanJianyingPrivateResourceCatalog,
  NATIVE018_PRIVATE_DRAFT_CATALOG_FILENAME,
  JY172_PRIVATE_PACKAGING_CATALOG_FILENAME,
} from './jianying-private-resource-scanner.mjs'
import {
  compileJianYingPrivateCandidateCatalog,
  createPyJianYingDraftResourceCandidateDescriptor,
  createPyJianYingDraftResourceFamilyClassifier,
  loadPyJianYingDraftPackagingMetadataSnapshot,
} from './jianying-private-candidate-catalog-compiler.mjs'
import {
  computePackagingCatalogRevisionToken,
  isPackagingCatalogBoundToDesktop,
  parsePrivatePackagingResourceIndex,
  summarizePackagingResourceReadiness,
} from './jianying-packaging-resource-index.mjs'
import { readFileNoReparse, readFilesNoReparse } from './jianying-native-safe-file.mjs'
import { buildFamilyVersionBatchRefreshPlan } from './jianying-private-batch-refresh.mjs'
import path from 'node:path'
import { existsSync } from 'node:fs'
import { lstat } from 'node:fs/promises'
import { createHash } from 'node:crypto'

export class JianyingPrivateResourceCatalogError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) { super(code); this.code = code; this.status = status }
}

const providerIdPattern = /^(?:user_draft|duo_video_probe)$/u
const draftAuthorizationPattern = /^ovauth_[A-Za-z0-9_-]{8,160}$/u
const MAX_PERSISTED_CATALOG_READ_BYTES = 32 * 1024 * 1024
const MAX_BATCH_CATALOG_READ_BYTES = 4 * 1024 * 1024
const DEFAULT_REFRESH_READY_WAIT_TIMEOUT_MS = 10_000
const DEFAULT_REFRESH_SCAN_TIMEOUT_MS = 10_000

/** Wait for an in-flight read before replacing the persisted catalog, but never leave a local refresh request hanging forever. */
const waitForCurrentReadiness = async (/** @type {Promise<unknown>} */ operation, /** @type {number} */ timeoutMs) => {
  let timer
  try {
    await Promise.race([
      operation,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new JianyingPrivateResourceCatalogError('JY135_REFRESH_BUSY', 503)), timeoutMs)
      }),
    ])
  } finally {
    if (timer) clearTimeout(timer)
  }
}

/** Parse server-owned roots; browser payloads never participate. */
export const parseJianyingPrivateResourceRoots = (/** @type {NodeJS.ProcessEnv} */ environment = process.env) => {
  const raw = environment.OPENVIDEO_JIANYING_RESOURCE_ROOTS
  if (typeof raw !== 'string' || raw.trim() === '') return Object.freeze([])
  let parsed
  try { parsed = JSON.parse(raw) } catch { throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_ROOTS_INVALID', 503) }
  if (!Array.isArray(parsed) || parsed.length === 0 || parsed.length > 16 || parsed.some((root) => typeof root !== 'string' || !path.isAbsolute(root))) {
    throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_ROOTS_INVALID', 503)
  }
  return Object.freeze([...new Set(parsed.map((root) => path.resolve(root)))])
}

/** @param {NodeJS.ProcessEnv} environment */
export const parseJianyingPyModuleRoot = (environment = process.env) => {
  const raw = [environment.OPENVIDEO_PYJIANYINGDRAFT_ROOT, environment.OPENVIDEO_JY002_PYTHON_MODULE_ROOT]
    .find((value) => typeof value === 'string' && value.trim() !== '')
  if (typeof raw !== 'string') return null
  if (!path.isAbsolute(raw.trim())) {
    throw new JianyingPrivateResourceCatalogError('JY149_METADATA_MODULE_ROOT_INVALID', 503)
  }
  return path.resolve(raw.trim())
}

/** @param {{moduleRoot: string | null, pythonExecutable?: string}} input */
const defaultLoadMetadata = async ({ moduleRoot, pythonExecutable }) => moduleRoot
  ? loadPyJianYingDraftPackagingMetadataSnapshot({ moduleRoot, pythonExecutable })
  : null

/** @param {string} dataRoot @param {string} fileName @returns {Promise<Record<string, any>|null>} */
const readPrivateCatalogIndex = async (dataRoot, fileName) => {
  try {
    const catalogRoot = path.join(path.resolve(dataRoot), 'catalogs')
    const persisted = JSON.parse(await readFileNoReparse(
      path.join(catalogRoot, fileName),
      catalogRoot,
      MAX_PERSISTED_CATALOG_READ_BYTES,
    ))
    if (
      typeof persisted?.profile_id !== 'string' ||
      !/^jianying-[a-z0-9-]{1,60}$/u.test(persisted.profile_id) ||
      typeof persisted?.app_version !== 'string' ||
      !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(persisted.app_version)
    ) return null
    return parsePrivatePackagingResourceIndex(persisted, { profileId: persisted.profile_id, appVersion: persisted.app_version })
  } catch { return null }
}

/**
 * Read the persisted catalog set through one bounded Windows helper.
 * @param {string} dataRoot
 * @param {string[]} fileNames
 * @returns {Promise<(Record<string, any>|null)[]>}
 */
const readPrivateCatalogSet = async (dataRoot, fileNames) => {
  const catalogRoot = path.join(path.resolve(dataRoot), 'catalogs')
  try {
    const candidates = await Promise.all(fileNames.map(async (fileName, index) => {
      const filePath = path.join(catalogRoot, fileName)
      try {
        const stats = await lstat(filePath)
        return { index, path: filePath, rootPath: catalogRoot, size: stats.size }
      } catch { return null }
    }))
    const present = /** @type {{index: number, path: string, rootPath: string, size: number}[]} */ (
      candidates.filter((candidate) => candidate !== null)
    )
    if (present.length === 0) return fileNames.map(() => null)
    if (present.some(({ size }) => size > MAX_BATCH_CATALOG_READ_BYTES)) {
      return await Promise.all(fileNames.map((fileName) => readPrivateCatalogIndex(dataRoot, fileName)))
    }
    const values = await readFilesNoReparse(
      present.map(({ path: filePath, rootPath }) => ({ path: filePath, rootPath })),
      { maxFileBytes: MAX_PERSISTED_CATALOG_READ_BYTES, maxTotalBytes: MAX_PERSISTED_CATALOG_READ_BYTES * present.length },
    )
    const parsed = /** @type {(Record<string, any>|null)[]} */ (fileNames.map(() => null))
    values.forEach((raw, valueIndex) => {
      try {
        const persisted = JSON.parse(String(raw))
        if (typeof persisted?.profile_id !== 'string' || !/^jianying-[a-z0-9-]{1,60}$/u.test(persisted.profile_id) ||
            typeof persisted?.app_version !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(persisted.app_version)) return
        parsed[present[valueIndex].index] = parsePrivatePackagingResourceIndex(persisted, { profileId: persisted.profile_id, appVersion: persisted.app_version })
      } catch { /* malformed catalog remains unavailable */ }
    })
    return parsed
  } catch {
    // Optional catalogs may be absent. Preserve the existing per-file fallback
    // while still using the batch fast path for the normal complete runtime.
    return await Promise.all(fileNames.map((fileName) => readPrivateCatalogIndex(dataRoot, fileName)))
  }
}

/** @param {Record<string, any>|null} catalog @returns {PrivateCatalogSummary|null} */
const summarizePrivateCatalogIndex = (catalog) => catalog
  ? Object.freeze({
      available: true,
      entries: catalog.entries.length,
      families: Object.freeze([...new Set(catalog.entries.map((/** @type {Record<string, any>} */ entry) => entry.family))]),
      profile: catalog.profileId,
      version: catalog.appVersion,
    })
  : null

/** @param {string} dataRoot @param {string} fileName @returns {Promise<PrivateCatalogSummary|null>} */
const readPrivateCatalogSummary = async (dataRoot, fileName) => {
  return summarizePrivateCatalogIndex(await readPrivateCatalogIndex(dataRoot, fileName))
}

/** @typedef {{available: boolean, entries: number, families: readonly string[], profile: string|null, version: string|null}} PrivateCatalogSummary */
/** @typedef {{schema_version: 1, status: 'ready'|'empty'|'stale'|'desktop_unavailable'|'unavailable', entries: number, families: readonly string[], writer_eligible: number, writer_eligible_families: readonly string[], profile: string|null, version: string|null}} PrivateCatalogReadiness */
/** @typedef {PrivateCatalogReadiness & {catalogFingerprint: string|null, packagingIndex: unknown|null, packagingEvidence: Record<string, any>|null, rootSetFingerprint: string|null}} InternalCatalogReadiness */
/** @typedef {{roots: readonly string[], desktop?: Record<string, any>|null}} DynamicRootState */
/** @param {unknown} value @returns {value is DynamicRootState} */
const isDynamicRootState = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value) && Array.isArray(/** @type {Record<string, unknown>} */ (value).roots)

/** @typedef {{isDirectory: () => boolean, isSymbolicLink: () => boolean, dev: number|bigint, ino: number|bigint, birthtimeMs: number}} PrivateRootStat */
/** @param {readonly string[]} roots @param {(root: string) => Promise<PrivateRootStat>} statRoot @returns {Promise<string>} Bind evidence to private root object identities without exposing paths. */
const fingerprintPrivateRootSet = async (roots, statRoot) => {
  const identities = []
  for (const root of [...new Set(roots)].sort()) {
    const stat = await statRoot(root)
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_ROOTS_INVALID', 503)
    const resolved = path.resolve(root).replaceAll('\\', '/')
    identities.push({
      path: process.platform === 'win32' ? resolved.toLowerCase() : resolved,
      dev: String(stat.dev),
      ino: String(stat.ino),
      birthtime_ms: Number.isFinite(stat.birthtimeMs) ? stat.birthtimeMs : null,
    })
  }
  return createHash('sha256').update(JSON.stringify(identities)).digest('hex')
}
/** @param {{dataRoot: string, roots?: readonly string[], resolveRoots?: () => Promise<readonly string[]|{roots: readonly string[], desktop?: Record<string, any>|null}>, detectDesktop: () => Promise<{available?: boolean, profileId?: string, version?: string, executablePath?: string, installRoot?: string, dllFingerprint?: string, draftRoot?: string}>, loadAdmittedIndex?: (desktop: Record<string, any>, candidateCatalogFingerprint: string, options?: {captureEvidence?: (evidence: Record<string, any>) => void, captureCatalogCandidates?: (candidates: readonly {fileName: string, catalogFingerprint: string, catalogRawFingerprint?: string, privateSourceBinding: Record<string, any>|null}[]) => void|Promise<void>}) => Promise<unknown>, scan?: typeof scanJianyingPrivateResourceCatalog, persist?: typeof persistJianyingPrivateResourceCatalog, persistCandidate?: typeof persistJianyingPrivateResourceCatalog, loadMetadata?: (input: {moduleRoot: string | null, pythonExecutable?: string, profileId: string, appVersion: string}) => Promise<unknown>, compile?: typeof compileJianYingPrivateCandidateCatalog, invokeProvider?: (input: {providerId: string, draftAuthorizationId?: string}) => Promise<unknown>, validatePrivateSourceBinding?: (input: {draftAuthorizationId: string, sourceFingerprint: string}) => Promise<boolean>, scannerCandidateFileName?: string, providerCandidateFileName?: string, refreshReadyWaitTimeoutMs?: number, refreshScanTimeoutMs?: number, environment?: NodeJS.ProcessEnv, statRoot?: (root: string) => Promise<PrivateRootStat>}} input */
export const createJianyingPrivateResourceCatalogService = ({
  dataRoot,
  roots = undefined,
  resolveRoots = undefined,
  detectDesktop,
  loadAdmittedIndex = async () => null,
  scan = scanJianyingPrivateResourceCatalog,
  persist = persistJianyingPrivateResourceCatalog,
  persistCandidate = persist,
  loadMetadata = defaultLoadMetadata,
  compile = compileJianYingPrivateCandidateCatalog,
  invokeProvider = undefined,
  validatePrivateSourceBinding = undefined,
  scannerCandidateFileName = JY172_PRIVATE_PACKAGING_CATALOG_FILENAME,
  providerCandidateFileName = NATIVE018_PRIVATE_DRAFT_CATALOG_FILENAME,
  refreshReadyWaitTimeoutMs = DEFAULT_REFRESH_READY_WAIT_TIMEOUT_MS,
  refreshScanTimeoutMs = DEFAULT_REFRESH_SCAN_TIMEOUT_MS,
  environment = process.env,
  statRoot = lstat,
}) => {
  if (!Array.isArray(roots) && typeof resolveRoots !== 'function') throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_ROOTS_INVALID', 503)
  const refreshReadyWaitTimeout = Number.isSafeInteger(refreshReadyWaitTimeoutMs) && refreshReadyWaitTimeoutMs > 0
    ? refreshReadyWaitTimeoutMs
    : DEFAULT_REFRESH_READY_WAIT_TIMEOUT_MS
  const refreshScanTimeout = Number.isSafeInteger(refreshScanTimeoutMs) && refreshScanTimeoutMs > 0
    ? refreshScanTimeoutMs
    : DEFAULT_REFRESH_SCAN_TIMEOUT_MS
  const loadRootState = async () => {
    const value = typeof resolveRoots === 'function' ? await resolveRoots() : roots
    const dynamicState = isDynamicRootState(value) ? value : null
    const resolvedRoots = Array.isArray(value) ? value : dynamicState?.roots
    const desktop = dynamicState?.desktop ?? null
    if (!Array.isArray(resolvedRoots) || resolvedRoots.length > 16 || resolvedRoots.some((root) => typeof root !== 'string' || !path.isAbsolute(root))) {
      throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_ROOTS_INVALID', 503)
    }
    return Object.freeze({
      roots: Object.freeze([...new Set(resolvedRoots.map((root) => path.resolve(root)))]),
      desktop: desktop && typeof desktop === 'object' && !Array.isArray(desktop) ? desktop : null,
    })
  }
  /** @type {PrivateCatalogSummary & {candidate: PrivateCatalogSummary|null}} */
  let latest = Object.freeze({
    available: false, entries: 0, families: Object.freeze([]), profile: null, version: null, candidate: null,
  })
  /** @type {Record<string, any> | null} */
  let scannerCandidateIndex = null
  /** @type {Record<string, any> | null} */
  let providerCandidateIndex = null
  let loaded = false
  /** @type {Promise<void> | null} */
  let persistedLoadPromise = null
  /** @type {Promise<Readonly<InternalCatalogReadiness>> | null} */
  let readinessInFlight = null
  const resetPersisted = () => {
    loaded = false
    scannerCandidateIndex = null
    providerCandidateIndex = null
  }
  const loadPersisted = async ({ force = false } = {}) => {
    if (force) {
      if (persistedLoadPromise) await persistedLoadPromise
      resetPersisted()
    }
    if (loaded) return
    if (persistedLoadPromise) return persistedLoadPromise
    persistedLoadPromise = (async () => {
      const [scannerIndex, persistedScannerIndex, persistedProviderIndex] = await readPrivateCatalogSet(dataRoot, [
        'jy135-private-resource-catalog.json', scannerCandidateFileName, providerCandidateFileName,
      ])
      const scanner = summarizePrivateCatalogIndex(scannerIndex)
      // Keep provider-assisted draft output independent from the ordinary
      // scanner candidate. A valid user-draft snapshot takes precedence for
      // this service, but refresh still writes only the scanner file.
      // A legacy JY172 file may have been written by the old user-draft route.
      // Never treat that private-source-bound artifact as a scanner candidate;
      // only the dedicated NATIVE-018 file may rehydrate it.
      scannerCandidateIndex = persistedScannerIndex?.privateSourceBinding ? null : persistedScannerIndex
      providerCandidateIndex = persistedProviderIndex
      latest = Object.freeze({ ...(scanner ?? {
        available: false, entries: 0, families: Object.freeze([]), profile: null, version: null,
      }), candidate: null })
      loaded = true
    })()
    try {
      await persistedLoadPromise
    } finally {
      persistedLoadPromise = null
    }
  }
  /** @param {Record<string, any>|null|undefined} index */
  const providerCatalogBindingIsCurrent = async (index) => {
    const binding = index?.privateSourceBinding
    if (!binding) return true
    if (typeof validatePrivateSourceBinding !== 'function') return false
    try {
      return await validatePrivateSourceBinding({
        draftAuthorizationId: binding.draft_authorization_id,
        sourceFingerprint: binding.source_fingerprint,
      }) === true
    } catch {
      return false
    }
  }
  /** @param {Record<string, any>|null|undefined} desktop */
  const desktopBindingFrom = (desktop) => {
    if (desktop?.available === true && typeof desktop.profileId === 'string' && typeof desktop.version === 'string') {
      return /** @type {{profileId: string, version: string, executablePath?: string, installRoot?: string, dllFingerprint?: string}} */ ({
        profileId: desktop.profileId,
        version: desktop.version,
        executablePath: desktop.executablePath,
        installRoot: desktop.installRoot,
        dllFingerprint: desktop.dllFingerprint,
      })
    }
    return null
  }
  /** @returns {Readonly<InternalCatalogReadiness>} */
  const unavailableReadiness = () => /** @type {Readonly<InternalCatalogReadiness>} */ (Object.freeze({
    schema_version: 1, status: 'unavailable', entries: 0,
    families: Object.freeze([]), writer_eligible: 0,
    writer_eligible_families: Object.freeze([]), profile: null, version: null,
    catalogFingerprint: null, packagingIndex: null, packagingEvidence: null, rootSetFingerprint: null,
  }))
  /** @param {Record<string, any>|null} [observedDesktop] */
  const selectCandidateSnapshot = async (observedDesktop = null) => {
    // Capture all mutable persisted state before validation. Concurrent forced
    // reloads must not replace one request's selected catalog between its
    // source check and admission/readback checks.
    const providerIndex = providerCandidateIndex
    const scannerIndex = scannerCandidateIndex
    const latestState = latest
    const providerCurrent = await providerCatalogBindingIsCurrent(providerIndex)
    const desktopBindingCandidate = desktopBindingFrom(observedDesktop)
    // A still-authorized user-draft snapshot must not hide the current
    // scanner after a Jianying upgrade. Source binding only proves the
    // draft still exists; desktop profile/version/binding decides currency.
    const providerDesktopBound = Boolean(
      providerIndex &&
      (!desktopBindingCandidate || isPackagingCatalogBoundToDesktop(providerIndex, desktopBindingCandidate)),
    )
    const index = providerCurrent && providerDesktopBound ? providerIndex : scannerIndex
    return Object.freeze({
      index,
      providerSelected: Boolean(providerCurrent && providerDesktopBound),
      catalogFingerprint: index?.catalogFingerprint ?? null,
      summary: Object.freeze({
        ...latestState,
        candidate: summarizePrivateCatalogIndex(index),
      }),
    })
  }
  /** @param {Record<string, any>|null} [observedDesktop] */
  const selectCandidateState = async (observedDesktop = null) => (await selectCandidateSnapshot(observedDesktop)).summary
  const resolveObservedDesktop = async () => {
    const rootState = await loadRootState()
    if (rootState.desktop) return rootState.desktop
    try { return await detectDesktop() } catch { return null }
  }
  /**
   * @param {DynamicRootState | null} [observedRootState]
   * @param {{requireCurrentCatalogObservation?: boolean}} [options]
   * @returns {Promise<Readonly<InternalCatalogReadiness>>}
   */
  const readReadiness = async (observedRootState = null, { requireCurrentCatalogObservation = false } = {}) => {
      const rootState = observedRootState ?? await loadRootState()
      const activeRoots = rootState.roots
      if (activeRoots.length === 0) {
        return unavailableReadiness()
      }
      let desktop = rootState.desktop
      if (!desktop) {
        try { desktop = await detectDesktop() } catch { desktop = null }
      }
      const selected = await selectCandidateSnapshot(desktop)
      const candidate = selected.summary.candidate
      // Freeze the selected catalog and fingerprint for this readiness
      // evaluation. Another concurrent force reload may update the service's
      // mutable cache, but it must not mix its candidate with this request's
      // desktop/admission checks.
      const evaluatedIndex = selected.index
      const evaluatedCatalogFingerprint = selected.catalogFingerprint
      const scannerCandidateSelected = evaluatedIndex === scannerCandidateIndex
      if (!candidate) {
        return unavailableReadiness()
      }
      let rootSetFingerprint = null
      if (scannerCandidateSelected && typeof evaluatedIndex?.privateRootSetFingerprint === 'string') {
        try { rootSetFingerprint = await fingerprintPrivateRootSet(activeRoots, statRoot) } catch { /* fail closed below */ }
      }
      const desktopAvailable = desktop?.available === true &&
        typeof desktop.profileId === 'string' && typeof desktop.version === 'string'
      const desktopBindingCandidate = desktopBindingFrom(desktop)
      let current = desktopBindingCandidate !== null &&
        isPackagingCatalogBoundToDesktop(evaluatedIndex, desktopBindingCandidate) &&
        (!scannerCandidateSelected || (rootSetFingerprint !== null && evaluatedIndex?.privateRootSetFingerprint === rootSetFingerprint))
      let writerReadiness = null
      let admittedIndex = null
      let admittedEvidence = null
      let observedCatalogFingerprint = null
      let catalogCandidatesObserved = false
      if (current && desktop && typeof evaluatedCatalogFingerprint === 'string') {
        try {
          const candidateAdmittedIndex = await loadAdmittedIndex(desktop, evaluatedCatalogFingerprint, {
            captureEvidence: (evidence) => { admittedEvidence = evidence },
            captureCatalogCandidates: async (candidates) => {
              catalogCandidatesObserved = true
              const provider = candidates.find((candidate) => candidate.fileName === providerCandidateFileName)
              if (provider?.privateSourceBinding && await providerCatalogBindingIsCurrent({ privateSourceBinding: provider.privateSourceBinding })) {
                observedCatalogFingerprint = provider.catalogFingerprint
                return
              }
              const scanner = candidates.find((candidate) => candidate.fileName === scannerCandidateFileName && !candidate.privateSourceBinding)
              observedCatalogFingerprint = scanner?.catalogFingerprint ?? null
            },
          })
          const admitted = summarizePackagingResourceReadiness(candidateAdmittedIndex)
          if (catalogCandidatesObserved && observedCatalogFingerprint === evaluatedCatalogFingerprint &&
              admitted.catalogRevisionToken === computePackagingCatalogRevisionToken(evaluatedCatalogFingerprint)) {
            writerReadiness = admitted
            admittedIndex = candidateAdmittedIndex
          } else {
            admittedEvidence = null
          }
        } catch { /* missing, stale or malformed admission remains zero and fail-closed */ }
      }
      if ((catalogCandidatesObserved && observedCatalogFingerprint !== evaluatedCatalogFingerprint) ||
          (requireCurrentCatalogObservation && !catalogCandidatesObserved)) {
        current = false
        writerReadiness = null
        admittedIndex = null
        admittedEvidence = null
      }
      if (current && scannerCandidateSelected) {
        let finalRootSetFingerprint = null
        try { finalRootSetFingerprint = await fingerprintPrivateRootSet(activeRoots, statRoot) } catch { /* fail closed below */ }
        if (finalRootSetFingerprint !== rootSetFingerprint) {
          current = false
          writerReadiness = null
          admittedIndex = null
          admittedEvidence = null
        }
      }
      return Object.freeze({
        schema_version: 1,
        status: current ? (candidate.entries > 0 ? 'ready' : 'empty') : desktopAvailable ? 'stale' : 'desktop_unavailable',
        entries: candidate.entries,
        families: candidate.families,
        writer_eligible: writerReadiness?.writerEligible ?? 0,
        writer_eligible_families: writerReadiness?.writerEligibleFamilies ?? Object.freeze([]),
        profile: candidate.profile,
        version: candidate.version,
        catalogFingerprint: evaluatedCatalogFingerprint,
        packagingIndex: admittedIndex ?? (current && !selected.providerSelected ? evaluatedIndex : null),
        packagingEvidence: admittedEvidence,
        rootSetFingerprint,
      })
    }
  /** @returns {Promise<Readonly<InternalCatalogReadiness>>} */
  const readReadinessSingleFlight = () => {
    if (readinessInFlight) return readinessInFlight
    const operation = readReadiness()
    readinessInFlight = operation
    const clear = () => { if (readinessInFlight === operation) readinessInFlight = null }
    void operation.then(clear, clear)
    return operation
  }
  return Object.freeze({
    summary: async () => {
      await loadPersisted()
      return selectCandidateState(await resolveObservedDesktop())
    },
    /** @param {{providerId: string, draftAuthorizationId?: string}} input */
    invokeProvider: async ({ providerId, draftAuthorizationId = undefined }) => {
      if (typeof invokeProvider !== 'function') throw new JianyingPrivateResourceCatalogError('NATIVE016_PROVIDER_UNAVAILABLE', 503)
      try {
        const result = await invokeProvider({ providerId, ...(draftAuthorizationId ? { draftAuthorizationId } : {}) })
        // Provider persistence can replace the candidate catalog after the
        // service has already been read by the workbench. Force the next
        // summary/readiness call to reparse the private file.
        await loadPersisted({ force: true })
        return result
      } catch (error) {
        if (error instanceof JianyingPrivateResourceCatalogError) throw error
        const providerError = /** @type {{code?: unknown, status?: unknown}} */ (error)
        const providerCode = providerError && typeof providerError.code === 'string' ? providerError.code : ''
        const providerStatus = providerError && typeof providerError.status === 'number' && Number.isInteger(providerError.status) ? providerError.status : 503
        if (providerError && /^(?:NATIVE016|NATIVE017)_[A-Z_]+$/u.test(providerCode)) {
          throw new JianyingPrivateResourceCatalogError(providerCode, providerStatus)
        }
        throw new JianyingPrivateResourceCatalogError('NATIVE016_PROVIDER_FAILED', 503)
      }
    },
    /** @returns {Promise<PrivateCatalogReadiness>} */
    readiness: async () => {
      await loadPersisted()
      const readiness = await readReadinessSingleFlight()
      const {
        catalogFingerprint: _catalogFingerprint,
        packagingIndex: _packagingIndex,
        packagingEvidence: _packagingEvidence,
        rootSetFingerprint: _rootSetFingerprint,
        ...publicReadiness
      } = readiness
      return /** @type {Readonly<PrivateCatalogReadiness>} */ (Object.freeze(publicReadiness))
    },
    /** Server-internal execution gate; never expose private bindings or paths. */
    workbenchReadiness: async function () {
      await loadPersisted({ force: true })
      const readiness = await readReadiness()
      return Object.freeze({
        ready: readiness.status === 'ready' && readiness.writer_eligible > 0,
        catalogAvailable: readiness.status === 'ready' || readiness.status === 'empty',
        profileId: readiness.profile,
        appVersion: readiness.version,
        catalogFingerprint: readiness.catalogFingerprint,
      })
    },
    /** Server-internal current admitted snapshot for the dynamic resolver. */
    workbenchPackagingSnapshot: async function () {
      await loadPersisted({ force: true })
      const readiness = await readReadiness()
      return Object.freeze({
        ready: readiness.status === 'ready' && readiness.writer_eligible > 0,
        catalogAvailable: readiness.status === 'ready' || readiness.status === 'empty',
        entries: readiness.entries,
        families: readiness.families,
        profileId: readiness.profile,
        appVersion: readiness.version,
        catalogFingerprint: readiness.catalogFingerprint,
        packagingIndex: readiness.packagingIndex,
        packagingEvidence: readiness.packagingEvidence,
      })
    },
    /**
     * Server-internal Duo-only source snapshot. A user-draft catalog has its
     * own signed Duo lifecycle/admission path, so it must not be forced
     * through the Native JY132 evidence registry. This intentionally does not
     * make the candidate Native-writer-ready or expose it through public APIs.
     */
    workbenchDuoPackagingSnapshot: async function () {
      // Reuse the immutable persisted candidate after the first load. The
      // checks below still revalidate desktop binding and the authorized
      // source fingerprint on every call, without invoking Native's broader
      // admitted-index scan for this independently admitted Duo candidate.
      await loadPersisted()
      const rootState = await loadRootState()
      let desktop = rootState.desktop
      if (!desktop) {
        try { desktop = await detectDesktop() } catch { desktop = null }
      }
      const selected = await selectCandidateSnapshot(desktop)
      const selectedProviderIndex = selected.providerSelected
        ? selected.index
        : null
      const desktopAvailable = desktop?.available === true &&
        typeof desktop.profileId === 'string' && typeof desktop.version === 'string'
      const desktopBindingCandidate = desktopAvailable && desktop
        ? /** @type {{profileId: string, version: string, executablePath?: string, installRoot?: string, dllFingerprint?: string}} */ ({
            profileId: desktop.profileId,
            version: desktop.version,
            executablePath: desktop.executablePath,
            installRoot: desktop.installRoot,
            dllFingerprint: desktop.dllFingerprint,
          })
        : null
      const providerEntries = selectedProviderIndex && Array.isArray(selectedProviderIndex.entries)
        ? /** @type {Array<{family: string}>} */ (selectedProviderIndex.entries)
        : []
      const currentProvider = selectedProviderIndex !== null && desktopAvailable &&
        desktopBindingCandidate !== null &&
        isPackagingCatalogBoundToDesktop(selectedProviderIndex, desktopBindingCandidate) &&
        await providerCatalogBindingIsCurrent(selectedProviderIndex)
      return Object.freeze({
        ready: currentProvider,
        catalogAvailable: currentProvider,
        entries: currentProvider ? providerEntries.length : 0,
        families: currentProvider ? Object.freeze([...new Set(providerEntries.map((entry) => entry.family))]) : Object.freeze([]),
        profileId: currentProvider ? selectedProviderIndex.profileId : null,
        appVersion: currentProvider ? selectedProviderIndex.appVersion : null,
        catalogFingerprint: currentProvider ? selectedProviderIndex.catalogFingerprint : null,
        // Do not substitute this field in the Native snapshot above. Duo's
        // resolver still requires its independently signed admitted receipt.
        packagingIndex: currentProvider ? selectedProviderIndex : null,
        packagingEvidence: null,
      })
    },
    /** Evidence identity always reparses candidate precedence and binds root object identity. */
    nativeEvidenceSnapshot: async function ({ forceCatalogReload = true } = {}) {
      await loadPersisted({ force: forceCatalogReload })
      const rootState = await loadRootState()
      const readiness = await readReadiness(rootState, { requireCurrentCatalogObservation: !forceCatalogReload })
      const desktop = rootState.desktop
      const desktopAvailable = desktop?.available === true &&
        typeof desktop.profileId === 'string' && typeof desktop.version === 'string'
      const draftAvailable = desktopAvailable && typeof desktop?.draftRoot === 'string' &&
        path.isAbsolute(desktop.draftRoot) && existsSync(desktop.draftRoot)
      return Object.freeze({
        ready: readiness.status === 'ready' && readiness.writer_eligible > 0,
        catalogAvailable: readiness.status === 'ready' || readiness.status === 'empty',
        entries: readiness.entries,
        families: readiness.families,
        profileId: readiness.profile,
        appVersion: readiness.version,
        catalogFingerprint: readiness.catalogFingerprint,
        packagingIndex: readiness.packagingIndex,
        packagingEvidence: readiness.packagingEvidence,
        resourceRootCount: rootState.roots.length,
        rootSetFingerprint: readiness.rootSetFingerprint ?? await fingerprintPrivateRootSet(rootState.roots, statRoot),
        desktopAvailable,
        draftAvailable,
      })
    },
    /** Return only the bounded, family/version-scoped safe refresh projection. */
    familyRefreshPlan: async function ({ maxPerFamily = undefined, maxTotal = undefined } = {}) {
      await loadPersisted()
      const current = await readReadinessSingleFlight()
      if (!['ready', 'empty'].includes(current.status) || !current.packagingIndex) {
        throw new JianyingPrivateResourceCatalogError('JY179_REFRESH_INDEX_STALE', 409)
      }
      const packagingIndex = /** @type {Record<string, any>} */ (current.packagingIndex)
      if (current.profile !== packagingIndex.profileId || current.version !== packagingIndex.appVersion) {
        throw new JianyingPrivateResourceCatalogError('JY179_REFRESH_INDEX_STALE', 409)
      }
      if (current.catalogFingerprint !== packagingIndex.catalogFingerprint) {
        throw new JianyingPrivateResourceCatalogError('JY179_REFRESH_INDEX_STALE', 409)
      }
      try {
        return buildFamilyVersionBatchRefreshPlan(packagingIndex, { maxPerFamily, maxTotal })
      } catch {
        throw new JianyingPrivateResourceCatalogError('JY179_REFRESH_INDEX_UNAVAILABLE', 503)
      }
    },
    refresh: async () => {
      if (readinessInFlight) await waitForCurrentReadiness(readinessInFlight, refreshReadyWaitTimeout)
      const rootState = await loadRootState()
      const activeRoots = rootState.roots
      if (activeRoots.length === 0) throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_ROOTS_REQUIRED', 503)
      const desktop = rootState.desktop ?? await detectDesktop()
      if (!desktop?.available || typeof desktop.profileId !== 'string' || typeof desktop.version !== 'string') {
        throw new JianyingPrivateResourceCatalogError('JY135_DESKTOP_UNAVAILABLE', 503)
      }
      let metadataSnapshot = null
      try {
        metadataSnapshot = await loadMetadata({
          moduleRoot: parseJianyingPyModuleRoot(environment),
          pythonExecutable: environment.OPENVIDEO_JY002_PYTHON_EXECUTABLE?.trim() || 'python',
          profileId: desktop.profileId,
          appVersion: desktop.version,
        })
      } catch {
        throw new JianyingPrivateResourceCatalogError('JY149_CANDIDATE_CATALOG_COMPILE_FAILED', 503)
      }
      let scannedCatalog
      const scanRootSetFingerprint = await fingerprintPrivateRootSet(activeRoots, statRoot)
      try {
        scannedCatalog = await scan({
          roots: activeRoots,
          profileId: desktop.profileId,
          appVersion: desktop.version,
          desktop,
          privateRootSetFingerprint: scanRootSetFingerprint,
          maxElapsedMs: refreshScanTimeout,
          classifyFamily: metadataSnapshot ? createPyJianYingDraftResourceFamilyClassifier(metadataSnapshot) : undefined,
          describeCandidate: metadataSnapshot ? createPyJianYingDraftResourceCandidateDescriptor(metadataSnapshot) : undefined,
        })
      } catch (error) {
        if (error instanceof Error && error.message === 'JY135_SCAN_TIMEOUT') {
          throw new JianyingPrivateResourceCatalogError('JY135_RESOURCE_SCAN_TIMEOUT', 503)
        }
        throw error
      }
      if (scannedCatalog?.private_root_set_fingerprint !== scanRootSetFingerprint) {
        throw new JianyingPrivateResourceCatalogError('JY200_PRIVATE_ROOT_BINDING_INVALID', 503)
      }
      /** @type {typeof scannedCatalog} */
      let catalog = scannedCatalog
      try {
        if (metadataSnapshot) {
          catalog = /** @type {typeof scannedCatalog} */ (compile({
            metadataSnapshot, scannedCatalog, profileId: desktop.profileId, appVersion: desktop.version,
          }))
        }
      } catch {
        throw new JianyingPrivateResourceCatalogError('JY149_CANDIDATE_CATALOG_COMPILE_FAILED', 503)
      }
      const finalRootSetFingerprint = await fingerprintPrivateRootSet(activeRoots, statRoot)
      if (finalRootSetFingerprint !== scanRootSetFingerprint || catalog?.private_root_set_fingerprint !== scanRootSetFingerprint) {
        throw new JianyingPrivateResourceCatalogError('JY200_PRIVATE_ROOT_BINDING_STALE', 503)
      }
      await persist({ catalog, dataRoot })
      // Keep the scanner artifact for diagnostics and publish the same
      // profile/version-bound discovery index under a separate candidate name.
      // Production admission still requires a signed same-draft evidence record;
      // this never marks a scanned entry writer-eligible by itself.
      await persistCandidate({ catalog, dataRoot, fileName: scannerCandidateFileName })
      // Keep a bounded in-memory fallback for callers that inject persistence
      // during tests or a transient write-recovery path. A real persisted file
      // still wins after reload; this fallback must never replace a provider
      // candidate that reloads successfully below.
      let refreshedScannerIndex = null
      try {
        refreshedScannerIndex = parsePrivatePackagingResourceIndex(catalog, {
          profileId: desktop.profileId,
          appVersion: desktop.version,
        })
      } catch { /* injected persistence may return only a scan summary */ }
      // Reload both sources so a scanner refresh cannot replace an existing
      // authorized user-draft candidate in the service projection.
      loaded = false
      scannerCandidateIndex = null
      providerCandidateIndex = null
      await loadPersisted()
      if (!scannerCandidateIndex && refreshedScannerIndex) {
        scannerCandidateIndex = refreshedScannerIndex
        latest = Object.freeze({ ...latest, ...summarizePrivateCatalogIndex(refreshedScannerIndex) })
      }
      return selectCandidateState(desktop)
    },
  })
}

/** HTTP boundary intentionally accepts no caller-provided paths or raw IDs. */
/** @param {{service: {summary: () => Promise<unknown>, readiness?: () => Promise<unknown>, familyRefreshPlan?: (options?: Record<string, unknown>) => Promise<unknown>, refresh: () => Promise<unknown>, invokeProvider?: (input: {providerId: string, draftAuthorizationId?: string}) => Promise<unknown>}}} input */
export const createJianyingPrivateResourceCatalogHandler = ({ service }) => async (/** @type {Request} */ request) => {
  try {
    if (request.method === 'GET') {
      const view = new URL(request.url).searchParams.get('view')
      if (view === 'readiness') {
        if (typeof service.readiness !== 'function') throw new JianyingPrivateResourceCatalogError('JY174_READINESS_UNAVAILABLE', 503)
        return Response.json(await service.readiness())
      }
      if (view === 'family_refresh') {
        if (typeof service.familyRefreshPlan !== 'function') throw new JianyingPrivateResourceCatalogError('JY179_REFRESH_INDEX_UNAVAILABLE', 503)
        const params = new URL(request.url).searchParams
        /** @param {string} name */
        const parseBound = (name) => {
          const raw = params.get(name)
          if (raw === null || raw === '') return undefined
          if (!/^\d{1,3}$/u.test(raw)) throw new JianyingPrivateResourceCatalogError('JY179_REFRESH_OPTIONS_INVALID')
          return Number(raw)
        }
        return Response.json(await service.familyRefreshPlan({ maxPerFamily: parseBound('max_per_family'), maxTotal: parseBound('max_total') }))
      }
      return Response.json(await service.summary())
    }
    if (request.method === 'POST') {
      if (request.body) {
        if ((request.headers.get('content-type') ?? '').split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
          throw new JianyingPrivateResourceCatalogError('UNSUPPORTED_MEDIA_TYPE', 415)
        }
        let input
        try { input = await request.json() } catch { throw new JianyingPrivateResourceCatalogError('JY175_INPUT_INVALID') }
        const keys = input && typeof input === 'object' && !Array.isArray(input) ? Object.keys(input) : []
        const providerRequestValid = keys.length === 1 && typeof input.provider_id === 'string' && providerIdPattern.test(input.provider_id)
        const draftRequestValid = keys.length === 2 && input.provider_id === 'user_draft' &&
          typeof input.draft_authorization_id === 'string' && draftAuthorizationPattern.test(input.draft_authorization_id)
        if (!input || typeof input !== 'object' || Array.isArray(input) ||
            (keys.length !== 0 && !providerRequestValid && !draftRequestValid)) {
          throw new JianyingPrivateResourceCatalogError('JY175_INPUT_INVALID')
        }
        if (Object.hasOwn(input, 'provider_id')) {
          if (typeof service.invokeProvider !== 'function') throw new JianyingPrivateResourceCatalogError('NATIVE016_PROVIDER_UNAVAILABLE', 503)
          return Response.json(await service.invokeProvider({
            providerId: input.provider_id,
            ...(Object.hasOwn(input, 'draft_authorization_id') ? { draftAuthorizationId: input.draft_authorization_id } : {}),
          }), { status: 201 })
        }
      }
      await service.refresh()
      if (typeof service.readiness !== 'function') throw new JianyingPrivateResourceCatalogError('JY174_READINESS_UNAVAILABLE', 503)
      return Response.json(await service.readiness(), { status: 201 })
    }
    return Response.json({ error: { code: 'METHOD_NOT_ALLOWED' } }, { status: 405 })
  } catch (error) {
    const known = error instanceof JianyingPrivateResourceCatalogError
    const providerError = /** @type {{code?: unknown}} */ (error)
    const providerCode = !known && providerError && typeof providerError.code === 'string' &&
      /^NATIVE(?:014|015|016|017)_[A-Z_]+$/u.test(providerError.code) ? providerError.code : null
    return Response.json({ error: { code: known ? error.code : providerCode ?? 'JY135_RESOURCE_SCAN_FAILED' } }, { status: known ? error.status : 503 })
  }
}
