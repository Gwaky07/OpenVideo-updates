[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$pnpmCommand = Get-Command pnpm.cmd -ErrorAction SilentlyContinue
$pnpm = if ($pnpmCommand) { $pnpmCommand.Source } else { (Get-Command corepack.cmd -ErrorAction Stop).Source }
function Invoke-Pnpm {
    param([string[]]$Arguments)
    if ($pnpmCommand) {
        & $pnpm @Arguments
    }
    else {
        & $pnpm pnpm @Arguments
    }
}

Push-Location $RepositoryRoot
try {
    Invoke-Pnpm -Arguments @('--filter', '@openvideo/gateway', 'lint')
    if ($LASTEXITCODE -ne 0) { throw 'Gateway lint failed.' }
    Invoke-Pnpm -Arguments @('--filter', '@openvideo/gateway', 'typecheck')
    if ($LASTEXITCODE -ne 0) { throw 'Gateway typecheck failed.' }
    Invoke-Pnpm -Arguments @('--filter', '@openvideo/gateway', 'test')
    if ($LASTEXITCODE -ne 0) { throw 'Gateway tests failed.' }
    Invoke-Pnpm -Arguments @('--filter', '@openvideo/gateway', 'build')
    if ($LASTEXITCODE -ne 0) { throw 'Gateway build failed.' }
}
finally {
    Pop-Location
}

Write-Host 'OpenVideo LLM Gateway checks passed.' -ForegroundColor Green
