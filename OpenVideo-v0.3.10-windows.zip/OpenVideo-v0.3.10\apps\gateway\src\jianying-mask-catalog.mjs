import { createHash } from 'node:crypto'

const resourcePattern = /^[A-Za-z0-9_-]{4,80}$/u
const tokenPattern = /^ovjmask_v2_[a-f0-9]{64}$/u
const admittedProfileId = 'jianying-11-1-provisional'
const admittedVersion = '11.1.0.14287'
/** @param {unknown} body */
const fingerprint = (body) => createHash('sha256').update(JSON.stringify(body)).digest('hex')
/** @param {unknown} value @param {readonly string[]} keys */
const hasExactKeys = (value, keys) => Boolean(value) && typeof value === 'object' &&
  Object.keys(/** @type {Record<string, unknown>} */ (value)).sort().join('\0') === [...keys].sort().join('\0')

/** @param {any} template @param {string} resourceId */
const validTemplate = (template, resourceId) => {
  const stringKeys = ['type', 'category', 'category_name', 'category_id', 'resource_id', 'constant_material_id', 'name', 'resource_type', 'path']
  return hasExactKeys(template, ['id', ...stringKeys, 'config', 'text_config']) &&
    typeof template.id === 'string' && template.id.length > 0 && template.id.length <= 512 &&
    stringKeys.every((key) => typeof template[key] === 'string' && template[key].length > 0 && template[key].length <= 512) &&
    template.resource_id === resourceId &&
    hasExactKeys(template.config, ['width', 'height']) &&
    ['width', 'height'].every((key) => typeof template.config[key] === 'number' && Number.isFinite(template.config[key]) && template.config[key] > 0) &&
    hasExactKeys(template.text_config, ['align_type']) && Number.isSafeInteger(template.text_config.align_type)
}

/** Parse the owner-private JY-045 common-mask catalog for the writer boundary. */
/** @param {unknown} value */
export const parseJianyingMaskCatalog = (value) => {
  /** @type {any} */ const candidate = value
  if (!hasExactKeys(candidate, ['schema_version', 'kind', 'catalog_version', 'entries', 'catalog_fingerprint']) ||
    candidate.schema_version !== 2 || candidate.kind !== 'jy045_mask_catalog' || candidate.catalog_version !== '2.0.0' ||
    !Array.isArray(candidate.entries) || candidate.entries.length !== 1 || typeof candidate.catalog_fingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(candidate.catalog_fingerprint)) return null
  const [entry] = candidate.entries
  if (!hasExactKeys(entry, ['capability_id', 'mask_token', 'display_name', 'resource_id', 'common_mask_template']) ||
    entry.capability_id !== 'mask.video.named' || typeof entry.mask_token !== 'string' || !tokenPattern.test(entry.mask_token) ||
    typeof entry.display_name !== 'string' || entry.display_name.length === 0 || typeof entry.resource_id !== 'string' ||
    !resourcePattern.test(entry.resource_id) || entry.mask_token !== `ovjmask_v2_${createHash('sha256').update(entry.resource_id).digest('hex')}` ||
    !validTemplate(entry.common_mask_template, entry.resource_id)) return null
  const body = { schema_version: candidate.schema_version, kind: candidate.kind, catalog_version: candidate.catalog_version, entries: candidate.entries }
  if (candidate.catalog_fingerprint !== fingerprint(body)) return null
  return Object.freeze({ fingerprint: candidate.catalog_fingerprint, entries: Object.freeze([Object.freeze({ maskToken: entry.mask_token, resourceId: entry.resource_id, commonMaskTemplate: structuredClone(entry.common_mask_template) })]) })
}

/** @param {unknown} value @param {string} catalogFingerprint @param {{profileId: string, version: string}} desktop */
export const parseJianyingMaskEvidence = (value, catalogFingerprint, desktop) => {
  /** @type {any} */ const candidate = value
  const keys = ['schema_version', 'manual_evidence_verified', 'manual_attestation', 'profile_id', 'app_version', 'catalog_fingerprint', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'matching_mask_count', 'attached', 'persisted_width', 'persisted_height', 'temporary_media_cleaned']
  if (!hasExactKeys(candidate, keys) || candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.manual_attestation !== 'opened-edited-saved-reopened' || desktop.profileId !== admittedProfileId || desktop.version !== admittedVersion ||
    candidate.profile_id !== admittedProfileId || candidate.app_version !== admittedVersion || candidate.catalog_fingerprint !== catalogFingerprint ||
    candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true ||
    candidate.matching_mask_count !== 1 || candidate.attached !== true || candidate.persisted_width !== 0.65 ||
    candidate.persisted_height !== 0.3640625 || candidate.temporary_media_cleaned !== true) return null
  return Object.freeze({ ...candidate })
}

/** @param {{entries: readonly {maskToken: string, resourceId: string, commonMaskTemplate: Record<string, any>}[]} | null} catalog @param {unknown} token */
export const resolveJianyingMaskToken = (catalog, token) => {
  if (typeof token !== 'string' || !tokenPattern.test(token)) return null
  const entry = catalog?.entries?.find((candidate) => candidate.maskToken === token)
  return entry ? { resourceId: entry.resourceId, commonMaskTemplate: structuredClone(entry.commonMaskTemplate) } : null
}

/** Side-effect-free production admission gate for the private JY-045 artifacts. */
/** @param {{dataRoot: string, desktop: {profileId: string, version: string}, readFile: (...args: any[]) => Promise<any>, joinPath: (...parts: string[]) => string}} input */
export const loadJianyingMaskCapability = async ({ dataRoot, desktop, readFile, joinPath }) => {
  try {
    const catalog = parseJianyingMaskCatalog(JSON.parse(await readFile(joinPath(dataRoot, 'catalogs', 'jy045-mask-catalog.json'), 'utf8')))
    const evidence = JSON.parse(await readFile(joinPath(dataRoot, 'evidence', 'jy045-mask', 'post-save.json'), 'utf8'))
    return catalog && parseJianyingMaskEvidence(evidence, catalog.fingerprint, desktop) ? catalog : null
  } catch {
    return null
  }
}
