import { GatewayConfigError, routeModel } from '../config.mjs'
import { validateJsonSchema } from '../json-schema.mjs'

/** @typedef {import('../config.mjs').GatewayCapability} GatewayCapability */
/** @typedef {import('../config.mjs').GatewayConfig} GatewayConfig */
/** @typedef {{type: 'text', text: string} | {type: 'image', url: string}} GatewayPart */
/** @typedef {{role: 'system' | 'user' | 'assistant', parts: GatewayPart[]}} GatewayMessage */
/** @typedef {{name: string, schema: Record<string, unknown>}} GatewayJsonSchema */
/** @typedef {{capability: GatewayCapability, messages: GatewayMessage[], jsonSchema?: GatewayJsonSchema}} GatewayRequest */
/** @typedef {{capability: GatewayCapability, outputText: string, outputJson?: unknown, usage?: {inputTokens: number, outputTokens: number, totalTokens: number}}} GatewayResult */

/** @param {GatewayPart[]} parts */
const toProviderContent = (parts) => {
  if (parts.length === 1 && parts[0].type === 'text') return parts[0].text
  return parts.map((part) =>
    part.type === 'text' ? { type: 'text', text: part.text } : { type: 'image_url', image_url: { url: part.url } },
  )
}

/** @param {number} value */
const normalizeTokenCount = (value) => (Number.isSafeInteger(value) && value >= 0 ? value : 0)
const maxProviderOutputTextLength = 1_000_000

/** @param {string} value */
const extractJsonText = (value) => {
  const trimmed = value.trim()
  if (!trimmed) return null
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/iu)
  if (fenced?.[1]) return fenced[1].trim()

  const candidates = []
  let start = -1
  /** @type {string[]} */
  let stack = []
  let inString = false
  let escaped = false
  let malformed = false

  for (let index = 0; index < trimmed.length; index += 1) {
    const character = trimmed[index]
    if (start === -1) {
      if (character === '{' || character === '[') {
        start = index
        stack = [character]
        inString = false
        escaped = false
      }
      continue
    }

    if (inString) {
      if (escaped) escaped = false
      else if (character === '\\') escaped = true
      else if (character === '"') inString = false
      continue
    }
    if (character === '"') {
      inString = true
      continue
    }
    if (character === '{' || character === '[') {
      stack.push(character)
      continue
    }
    if (character !== '}' && character !== ']') continue

    const opening = stack.at(-1)
    if ((opening === '{' && character !== '}') || (opening === '[' && character !== ']')) {
      malformed = true
      break
    }
    stack.pop()
    if (stack.length === 0) {
      candidates.push(trimmed.slice(start, index + 1))
      start = -1
    }
  }

  if (malformed || start !== -1 || candidates.length !== 1) return null
  try {
    JSON.parse(candidates[0])
  } catch {
    return null
  }
  return candidates[0]
}

/** @param {any} body */
const safeResponseDiagnostic = (body) => {
  const choice = body?.choices?.[0]
  const message = choice?.message
  const content = typeof message?.content === 'string' ? message.content : ''
  const reasoning = typeof message?.reasoning_content === 'string' ? message.reasoning_content : ''
  const sample = (content.trim() || reasoning.trim())
  return {
    choiceCount: Array.isArray(body?.choices) ? body.choices.length : -1,
    finishReason: typeof choice?.finish_reason === 'string' ? choice.finish_reason.slice(0, 40) : 'missing',
    contentType: typeof message?.content,
    reasoningContentType: typeof message?.reasoning_content,
    refusalPresent: typeof message?.refusal === 'string' && message.refusal.length > 0,
    completionTokens: normalizeTokenCount(body?.usage?.completion_tokens),
    outputLength: sample.length,
    startsWithBrace: sample.trimStart().startsWith('{'),
    hasMarkdownFence: sample.includes('```'),
  }
}

/** @param {GatewayRequest} request @param {any} body @returns {GatewayResult | {error: string, diagnostic?: Record<string, unknown>}} */
const parseSuccess = (request, body) => {
  const message = body?.choices?.[0]?.message
  const primaryContent = typeof message?.content === 'string' && message.content.trim()
    ? message.content
    : undefined
  const reasoningContent = typeof message?.reasoning_content === 'string' && message.reasoning_content.trim()
    ? message.reasoning_content
    : undefined
  const outputText = primaryContent ?? reasoningContent
  if (typeof outputText !== 'string' || outputText.length > maxProviderOutputTextLength) {
    return { error: 'invalid-response', diagnostic: safeResponseDiagnostic(body) }
  }

  /** @type {GatewayResult} */
  const result = { capability: request.capability, outputText }
  if (request.capability === 'json') {
    const jsonText = extractJsonText(outputText)
    if (!jsonText) return { error: 'invalid-json', diagnostic: safeResponseDiagnostic(body) }
    try {
      result.outputJson = JSON.parse(jsonText)
      result.outputText = jsonText
    } catch {
      return { error: 'invalid-json', diagnostic: safeResponseDiagnostic(body) }
    }
    if (!validateJsonSchema(request.jsonSchema?.schema, result.outputJson)) {
      return { error: 'schema-mismatch', diagnostic: safeResponseDiagnostic(body) }
    }
  }
  if (body.usage) {
    result.usage = {
      inputTokens: normalizeTokenCount(body.usage.prompt_tokens),
      outputTokens: normalizeTokenCount(body.usage.completion_tokens),
      totalTokens: normalizeTokenCount(body.usage.total_tokens),
    }
  }
  return result
}

/** @param {GatewayConfig} config */
const createOpenAiCompatibleAdapter = (config) => ({
  /**
   * @param {GatewayRequest} request
   * @param {string | {model?: string, jsonMode?: 'strict' | 'compatible', maxTokens?: number, timeoutMs?: number}} [options]
   */
  buildRequest(request, options = {}) {
    const model = typeof options === 'string' ? options : options.model ?? routeModel(config, request.capability)
    const jsonMode = typeof options === 'string' ? 'strict' : options.jsonMode ?? 'strict'
    const requestedMaxTokens = typeof options === 'string' ? undefined : options.maxTokens
    const requestedTimeoutMs = typeof options === 'string' ? undefined : options.timeoutMs
    const maxTokens = Number.isSafeInteger(requestedMaxTokens) &&
      requestedMaxTokens >= 1 &&
      requestedMaxTokens <= 16_384
      ? requestedMaxTokens
      : 16_384
    const timeoutMs = Number.isSafeInteger(requestedTimeoutMs) &&
      requestedTimeoutMs >= 1_000 &&
      requestedTimeoutMs <= 120_000
      ? requestedTimeoutMs
      : config.requestTimeoutMs
    const providerMessages = request.messages.map((message) => ({
      role: message.role,
      content: toProviderContent(message.parts),
    }))
    /** @type {Record<string, unknown>} */
    const body = {
      model,
       messages: providerMessages,
      // Bound completion work for providers that otherwise keep reasoning
      // routes open long after a useful response can be returned.
      max_tokens: maxTokens,
    }
    if (request.capability === 'json') {
      if (jsonMode === 'strict') {
        body.response_format = {
          type: 'json_schema',
          json_schema: { name: request.jsonSchema?.name, strict: true, schema: request.jsonSchema?.schema },
        }
      } else {
        body.response_format = { type: 'json_object' }
        body.messages = [
          ...providerMessages,
          {
            role: 'system',
            content: 'Return exactly one JSON value that satisfies the requested schema. Do not include commentary or Markdown.',
          },
        ]
      }
    }
    return {
      url: `${config.baseUrl}/chat/completions`,
      headers: { authorization: `Bearer ${config.credential}`, 'content-type': 'application/json' },
      body,
      timeoutMs,
    }
  },
  parseSuccess,
})

/** @param {GatewayConfig} config */
export const createProviderAdapter = (config) => {
  if (config.provider === 'openai-compatible') return createOpenAiCompatibleAdapter(config)
  throw new GatewayConfigError(`Unsupported LLM provider adapter: ${config.provider}`)
}
