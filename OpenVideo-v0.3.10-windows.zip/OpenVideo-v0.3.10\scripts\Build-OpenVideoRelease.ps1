[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^v[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$')]
    [string]$Version,
    [string]$RepositoryRoot,
    [string]$OutputDirectory,
    [string]$RuntimeAssetStagerScript
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-Sha256Hex {
    param([Parameter(Mandatory = $true)][string]$Path)

    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    try {
        $hasher = [Security.Cryptography.SHA256]::Create()
        try {
            return ([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
        } finally {
            $hasher.Dispose()
        }
    } finally {
        $stream.Dispose()
    }
}

function Invoke-NodeChecked {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$FailureCode
    )

    & node @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw $FailureCode
    }
}

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $OutputDirectory = Join-Path $resolvedRoot 'release'
}
$resolvedOutput = [IO.Path]::GetFullPath($OutputDirectory)
if ([string]::IsNullOrWhiteSpace($RuntimeAssetStagerScript)) {
    $RuntimeAssetStagerScript = Join-Path $resolvedRoot 'scripts\Install-JY200DuoWriterRuntime.mjs'
}
$resolvedRuntimeAssetStagerScript = [IO.Path]::GetFullPath($RuntimeAssetStagerScript)
$stagerRoot = Split-Path -Parent $resolvedRuntimeAssetStagerScript
$status = (& git -C $resolvedRoot status --porcelain=v1 --untracked-files=no) -join ''
if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_RELEASE_GIT_STATUS_FAILED' }
if (-not [string]::IsNullOrWhiteSpace($status)) { throw 'OPENVIDEO_RELEASE_REQUIRES_CLEAN_TRACKED_TREE' }

$commit = (& git -C $resolvedRoot rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_RELEASE_COMMIT_UNAVAILABLE' }
$archiveName = "OpenVideo-$Version-windows-source.zip"
$archivePath = Join-Path $resolvedOutput $archiveName
$metadataPath = Join-Path $resolvedOutput "OpenVideo-$Version-release-metadata.json"
$stagingRoot = Join-Path $resolvedOutput ".release-$([guid]::NewGuid().ToString('N'))"
$trackedArchivePath = Join-Path $stagingRoot 'tracked-source.zip'
$expandedRoot = Join-Path $stagingRoot "OpenVideo-$Version"
New-Item -ItemType Directory -Path $resolvedOutput -Force | Out-Null
Remove-Item -LiteralPath $archivePath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $metadataPath -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null

try {
    & git -C $resolvedRoot archive --format=zip --prefix="OpenVideo-$Version/" --output=$trackedArchivePath HEAD
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $trackedArchivePath -PathType Leaf)) {
        throw 'OPENVIDEO_RELEASE_ARCHIVE_FAILED'
    }

    Expand-Archive -LiteralPath $trackedArchivePath -DestinationPath $stagingRoot -Force
    if (-not (Test-Path -LiteralPath $expandedRoot -PathType Container)) {
        throw 'OPENVIDEO_RELEASE_ARCHIVE_FAILED'
    }

    Invoke-NodeChecked -Arguments @(
        $resolvedRuntimeAssetStagerScript,
        '--stage-release-assets',
        $expandedRoot,
        '--root',
        $resolvedRoot,
        '--stager-root',
        $stagerRoot
    ) -FailureCode 'OPENVIDEO_RELEASE_RUNTIME_ASSETS_FAILED'

    $noticesPath = Join-Path $expandedRoot 'docs\licenses\THIRD-PARTY-NOTICES.md'
    if (-not (Test-Path -LiteralPath $noticesPath -PathType Leaf)) {
        throw 'OPENVIDEO_RELEASE_NOTICE_MISSING'
    }

    Compress-Archive -LiteralPath $expandedRoot -DestinationPath $archivePath -CompressionLevel Optimal -Force
    if (-not (Test-Path -LiteralPath $archivePath -PathType Leaf)) {
        throw 'OPENVIDEO_RELEASE_ARCHIVE_FAILED'
    }

    $duoManifest = Get-Content -LiteralPath (Join-Path $resolvedRoot 'config\duo-video-upstream.json') -Raw | ConvertFrom-Json
    $writerFingerprint = [string]$duoManifest.writer_only_runtime.verified_build.manifest_fingerprint
    $javaFingerprint = [string]$duoManifest.writer_only_runtime.private_java_distribution.inventory_fingerprint
    $javaArchiveRoot = [string]$duoManifest.writer_only_runtime.private_java_distribution.archive_root

    $metadata = [ordered]@{
        schema_version = 1
        version = $Version
        commit = $commit
        archive = $archiveName
        archive_sha256 = Get-Sha256Hex -Path $archivePath
        built_at = [DateTimeOffset]::UtcNow.ToString('O')
        bundled_upstreams = $false
        runtime_data_bundled = $false
        duo_private_java_bundled = Test-Path -LiteralPath (Join-Path $expandedRoot "runtime-assets\duo-video\java\$javaFingerprint\$javaArchiveRoot\release") -PathType Leaf
        duo_writer_runtime_bundled = Test-Path -LiteralPath (Join-Path $expandedRoot "runtime-assets\duo-video\writer\$writerFingerprint\openvideo-duo-writer-runtime.json") -PathType Leaf
        third_party_notices_bundled = Test-Path -LiteralPath $noticesPath -PathType Leaf
    }
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    [IO.File]::WriteAllText($metadataPath, (($metadata | ConvertTo-Json -Depth 5) + "`n"), $utf8)
    Write-Host "OPENVIDEO_RELEASE_READY: $archivePath" -ForegroundColor Green
    Write-Host "OPENVIDEO_RELEASE_SHA256: $($metadata.archive_sha256)"
} finally {
    Remove-Item -LiteralPath $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue
}
