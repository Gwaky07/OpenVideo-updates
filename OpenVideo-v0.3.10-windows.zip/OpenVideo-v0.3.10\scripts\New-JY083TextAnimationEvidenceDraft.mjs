import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { createScaleEvidenceTimeline, projectScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const manifest = require('../config/jianying-compatibility.json')
const execFileAsync = promisify(execFile)
const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== 'jianying-11-1-provisional' || desktop.version !== '11.1.0.14287') throw new Error('JY083_PROFILE_UNSUPPORTED')
  const root = loadLocalRuntimeConfig().dataRoot
  const catalog = JSON.parse(await readFile(path.join(root, 'catalogs', 'jy083-text-animation-catalog.json'), 'utf8'))
  const entry = catalog.entries?.[0]
  if (!entry?.resource_id || !entry?.animation_token || !Number.isSafeInteger(entry?.duration_us)) throw new Error('JY083_PRIVATE_CATALOG_MISSING')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy083-text-animation-'))
  const mediaOwner = randomUUID(); let writer = null; let request = null; let pendingPersisted = false; let released = false; let pendingPath = null
  try {
  await writeFile(path.join(mediaRoot, '.openvideo-jy083-owner'), mediaOwner, { encoding: 'utf8', mode: 0o600 })
  const video = path.join(mediaRoot, 'video.mp4'); const audio = path.join(mediaRoot, 'voice.wav')
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', video])
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audio])
  const projected = projectScaleEvidenceTimeline(desktop.profileId, createScaleEvidenceTimeline())
  const draftId = `OpenVideo-JY083-text-animation-${Date.now()}`
  writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments: [{ segment_id: 'title-jy083', text: 'OpenVideo text animation', target_start_us: 0, target_duration_us: 4_000_000 }], timelinePackaging: { ...projected.packaging, text_animation_segments: [{ target_segment_id: 'title-jy083', resource_id: entry.resource_id, duration_us: entry.duration_us, target_start_us: 0, target_duration_us: 4_000_000 }], sfx_segments: [], effect_segments: [], sticker_segments: [], filter_segments: [], animation_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
  request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: video }], voiceovers: [{ path: audio }] }
  const result = await writer.writeDraft(request)
  if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY083_WRITE_VERIFY_FAILED')
  const encrypted = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
  const evidenceRoot = path.join(root, 'evidence', 'jy083-text-animation'); await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  pendingPath = path.join(evidenceRoot, 'pending.json')
  await writeFile(pendingPath, `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, media_owner: mediaOwner, profile_id: desktop.profileId, app_version: desktop.version, catalog_fingerprint: catalog.fingerprint, resource_id: entry.resource_id, pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
  pendingPersisted = true
  if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY083_RELEASE_FAILED')
  released = true
  process.stdout.write(JSON.stringify({ ok: true, manual_open_required: true, draft_prefix: 'OpenVideo-JY083-text-animation-', animation_name: '收拢', initial_duration_seconds: entry.duration_us / 1_000_000, change_duration_seconds: 1, profile: desktop.profileId, version: desktop.version }) + '\n')
  } catch (error) {
    if (!released && pendingPersisted && pendingPath) await rm(pendingPath, { force: true })
    if (!released && writer && request) { try { await writer.cleanupDraft({ job_id: request.job_id }) } catch { /* preserve original error */ } }
    if (!released) await rm(mediaRoot, { recursive: true, force: true })
    throw error
  }
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY083_DRAFT_FAILED' }) + '\n'); process.exitCode = 1 })
