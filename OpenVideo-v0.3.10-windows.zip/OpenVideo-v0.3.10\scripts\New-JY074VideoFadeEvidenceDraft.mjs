import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'

const run = promisify(execFile)
const durationUs = 4_000_000
const initial = { fadeInUs: 500_000, fadeOutUs: 800_000 }
const timeline = () => {
  const tracks = [
    { trackId: 'video-primary', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary', segments: [{
      segmentId: 'jy074-video', kind: 'video', asset: { authorizationId: 'jy074-auth', assetId: 'jy074-video', sceneId: 'jy074-scene' },
      sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs }, fit: 'cover', volume: 1,
      speed: { numerator: 1, denominator: 1 }, keyframes: [],
      effects: [{ capabilityId: 'audio.video.fade', offsetRange: { startUs: 0, durationUs }, intensity: 1, parameters: initial }],
      audit: { origin: 'editor', candidateId: 'jy074-candidate', instructionFingerprint: null },
      transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
    }] },
    { trackId: 'voiceover-guide', order: 1, enabled: true, locked: false, kind: 'audio', role: 'voiceover', segments: [] },
  ]
  const draft = { schemaVersion: 1, timelineId: 'jy074-video-fade', projectId: 'jy074', revision: 1, parentRevision: null, parentRevisionFingerprint: null,
    status: 'draft', createdAt: '2026-08-12T00:00:00.000Z', durationUs, orientation: 'portrait', fps: { numerator: 30, denominator: 1 },
    source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null }, tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks) }
  return finalizeRichTimeline(sealRichTimeline(draft))
}

const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  if (desktop?.available !== true || desktop.profileId !== 'jianying-11-1-provisional') throw new Error('JY074_PROFILE_UNSUPPORTED')
  const registry = createEditorCapabilityRegistry({ jianyingProfileId: desktop.profileId, privateCatalogCapabilities: ['audio.video.fade'] })
  const projected = projectRichTimelineToJianyingExport(timeline(), { capabilityRegistry: registry })
  const draftId = `OpenVideo-JY074-video-fade-${Date.now()}`
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy074-video-fade-'))
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT,
    getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', captionSegments: [], titleSegments: [], keywordHighlights: [],
      timelinePackaging: { ...projected.packaging, sfx_segments: [], effect_segments: [], sticker_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
  const request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: videoPath }], voiceovers: [] }
  let result = null; let released = false; let stage = 'media'
  try {
    await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000', '-t', '4', '-shortest', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', videoPath])
    stage = 'write'; result = await writer.writeDraft(request)
    stage = 'verify'
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY074_DRAFT_VERIFY_FAILED')
    stage = 'readback'; const encrypted = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
    const root = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy074-video-fade')
    await mkdir(root, { recursive: true, mode: 0o700 }); await securePrivateRuntimeRoot(root)
    await writeFile(path.join(root, 'pending.json'), `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, profile_id: desktop.profileId, app_version: desktop.version, initial, pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
    stage = 'release'; if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY074_DRAFT_RELEASE_FAILED')
    released = true
    process.stdout.write(`${JSON.stringify({ ok: true, draft_id: draftId, manual_open_required: true, expected_fade: '0.5s / 0.8s', verification: 'open-save-reopen without changing the values', version: desktop.version })}\n`)
  } catch (error) {
    if (!released && result) { try { await writer.cleanupDraft({ job_id: request.job_id }) } catch { /* preserve original */ } }
    if (!released) await rm(mediaRoot, { recursive: true, force: true })
    error.jy074Stage = stage; throw error
  }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY074_DRAFT_FAILED', stage: error?.jy074Stage ?? error?.stage ?? error?.details?.stage ?? null })}\n`); process.exitCode = 1 })
