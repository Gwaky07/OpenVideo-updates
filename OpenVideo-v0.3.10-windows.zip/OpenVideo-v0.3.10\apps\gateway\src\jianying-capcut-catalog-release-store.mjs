import { createHash, randomUUID } from 'node:crypto'
import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'

import {
  CAPCUT_CATALOG_MAX_SHARD_ENTRIES,
  CAPCUT_CATALOG_SCHEMA_VERSION,
  CAPCUT_MATE_PINNED_COMMIT,
  CAPCUT_MATE_SOURCE,
  CAPCUT_MATE_RIGHTS_MODE,
} from './jianying-capcut-catalog-importer.mjs'

const pointerFileName = 'current-release.json'
const releasesDirName = 'releases'
const backupSchemaVersion = 2
const hex64Pattern = /^[a-f0-9]{64}$/u
const shardIdPattern = /^shard-[0-9]{5}$/u
const allowedFamilies = new Set(['flower', 'sticker', 'video_effect'])

/**
 * @typedef {Record<string, any>} CapCutCatalogManifest
 * @typedef {{schemaVersion: number, shardId: string, entries: Record<string, any>[]}} CapCutShardDocument
 * @typedef {{releaseId: string, manifest: CapCutCatalogManifest}} CapCutReleaseMetadata
 * @typedef {{releaseId: string, manifest: CapCutCatalogManifest, shards: CapCutShardDocument[]}} CapCutRelease
 */

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {unknown} */
const sortJson = (value) => {
  if (Array.isArray(value)) return value.map(sortJson)
  if (!isRecord(value)) return value
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, sortJson(value[key])]))
}

/** @param {unknown} value @returns {string} */
const stableJson = (value) => JSON.stringify(sortJson(value))

/** @param {string | Buffer} value @returns {string} */
const sha256 = (value) => createHash('sha256').update(value).digest('hex')

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  const error = new Error(code)
  Object.assign(error, { code, status })
  throw error
}

/** @param {unknown} value @param {string} code @returns {string} */
const assertFingerprint = (value, code) => {
  if (typeof value !== 'string' || !hex64Pattern.test(value)) fail(code)
  return value
}

/** @param {unknown} manifest @returns {CapCutCatalogManifest} */
const assertManifest = (manifest) => {
  if (isRecord(manifest) && Number.isSafeInteger(manifest.schemaVersion) &&
      manifest.schemaVersion < CAPCUT_CATALOG_SCHEMA_VERSION) {
    fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
  }
  if (!isRecord(manifest) || manifest.schemaVersion !== CAPCUT_CATALOG_SCHEMA_VERSION ||
      manifest.rightsMode !== CAPCUT_MATE_RIGHTS_MODE || manifest.sourceCommit !== CAPCUT_MATE_PINNED_COMMIT) {
    fail('CAPCUT_CATALOG_MANIFEST_INVALID')
  }
  const { manifestFingerprint: ignored, ...unsigned } = manifest
  assertFingerprint(manifest.manifestFingerprint, 'CAPCUT_CATALOG_MANIFEST_FINGERPRINT_INVALID')
  if (sha256(stableJson(unsigned)) !== manifest.manifestFingerprint) fail('CAPCUT_CATALOG_MANIFEST_FINGERPRINT_MISMATCH')
  if (!Array.isArray(manifest.shards) || manifest.shards.length === 0) fail('CAPCUT_CATALOG_MANIFEST_SHARDS_INVALID')
  const shardIds = new Set()
  for (const shard of manifest.shards) {
    if (!isRecord(shard) || typeof shard.shardId !== 'string' || !shardIdPattern.test(shard.shardId) ||
        !Number.isSafeInteger(shard.entries) || shard.entries < 1 || shard.entries > CAPCUT_CATALOG_MAX_SHARD_ENTRIES) {
      fail('CAPCUT_CATALOG_MANIFEST_SHARDS_INVALID')
    }
    assertFingerprint(shard.fingerprint, 'CAPCUT_CATALOG_SHARD_FINGERPRINT_INVALID')
    if (shardIds.has(shard.shardId)) fail('CAPCUT_CATALOG_MANIFEST_SHARDS_INVALID')
    shardIds.add(shard.shardId)
  }
  return /** @type {CapCutCatalogManifest} */ (manifest)
}

/** @param {unknown} releaseId @returns {string} */
const assertReleaseId = (releaseId) => {
  if (typeof releaseId !== 'string' || !/^release_[a-f0-9]{32}$/u.test(releaseId)) fail('CAPCUT_CATALOG_RELEASE_ID_INVALID')
  return releaseId
}

/** Validate the persisted discovery shape before it can be reported ready. */
/** @param {unknown} entry */
const assertShardEntry = (entry) => {
  if (!isRecord(entry) || entry.schema_version !== CAPCUT_CATALOG_SCHEMA_VERSION ||
      entry.source !== CAPCUT_MATE_SOURCE || entry.rights_mode !== CAPCUT_MATE_RIGHTS_MODE ||
      !allowedFamilies.has(entry.family) || entry.state !== 'discoverable' || entry.writer_eligible !== undefined ||
      !isRecord(entry.private_binding) || entry.private_binding.source !== CAPCUT_MATE_SOURCE ||
      entry.private_binding.family !== entry.family || typeof entry.private_binding.source_file !== 'string' ||
      !Number.isSafeInteger(entry.private_binding.source_index) || typeof entry.private_binding.raw_identity !== 'string' ||
      !hex64Pattern.test(entry.private_binding.source_fingerprint ?? '') || !Array.isArray(entry.tags) ||
      !isRecord(entry.parameters_schema)) fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
  const components = entry.private_binding.raw_identity_components
  if (!isRecord(components)) fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
  if (entry.family === 'video_effect' &&
      (typeof entry.entity !== 'string' || entry.entity.length === 0 || entry.private_binding.entity !== entry.entity ||
       typeof components.resource_id !== 'string' || typeof components.effect_id !== 'string' ||
       components.resource_id.length === 0 || components.effect_id.length === 0)) {
    fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
  }
  if (entry.family !== 'video_effect' &&
      typeof components.id !== 'string' && typeof components.resource_id !== 'string' &&
      typeof components.effect_id !== 'string' && typeof components.material_id !== 'string' &&
      typeof components.sticker_id !== 'string') fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
}

/** @param {Record<string, any>} manifest @param {readonly {shardId: string, entries: readonly Record<string, any>[]}[]} shards */
const assertManifestTotals = (manifest, shards) => {
  const totals = new Map()
  for (const shard of shards) for (const entry of shard.entries) {
    assertShardEntry(entry)
    totals.set(entry.family, (totals.get(entry.family) ?? 0) + 1)
  }
  for (const family of /** @type {readonly Record<string, any>[]} */ (manifest.families)) {
    if ((totals.get(family.family) ?? 0) !== family.total) fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
  }
  if ([...totals.values()].reduce((sum, value) => sum + value, 0) !== /** @type {readonly Record<string, any>[]} */ (manifest.shards).reduce((sum, shard) => sum + shard.entries, 0)) {
    fail('CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED')
  }
}

/** @param {string} root @param {string} child @returns {boolean} */
const within = (root, child) => {
  const relative = path.relative(path.resolve(root), path.resolve(child))
  return relative === '' || (!!relative && !relative.startsWith('..') && !path.isAbsolute(relative))
}

/** @param {string} filePath @param {unknown} value @returns {Promise<void>} */
const writeJsonAtomic = async (filePath, value) => {
  await mkdir(path.dirname(filePath), { recursive: true })
  const temp = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${randomUUID()}.tmp`)
  await writeFile(temp, `${stableJson(value)}\n`, 'utf8')
  await rename(temp, filePath)
}

/** @param {unknown} current */
const publicRelease = (current) => {
  if (!isRecord(current)) return null
  const manifest = assertManifest(current.manifest)
  return Object.freeze({
    schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION,
    releaseId: current.releaseId,
    manifestFingerprint: manifest.manifestFingerprint,
    source: manifest.source,
    sourceCommit: manifest.sourceCommit,
    rightsMode: manifest.rightsMode,
    families: manifest.families,
    shards: manifest.shards.map((/** @type {Record<string, any>} */ shard) => ({ shardId: shard.shardId, entries: shard.entries, fingerprint: shard.fingerprint })),
  })
}

/** @param {AsyncIterable<unknown> | Iterable<unknown>} shards @returns {AsyncIterator<unknown> | Iterator<unknown>} */
const shardIterator = (shards) => {
  const candidate = /** @type {Record<PropertyKey, unknown>} */ (/** @type {unknown} */ (shards))
  const asyncFactory = candidate[Symbol.asyncIterator]
  if (typeof asyncFactory === 'function') return /** @type {() => AsyncIterator<unknown>} */ (asyncFactory).call(shards)
  const syncFactory = candidate[Symbol.iterator]
  if (typeof syncFactory === 'function') return /** @type {() => Iterator<unknown>} */ (syncFactory).call(shards)
  fail('CAPCUT_CATALOG_SHARDS_INVALID')
}

/** @param {{releaseRoot: string}} input */
export const createCapCutCatalogReleaseStore = ({ releaseRoot }) => {
  if (typeof releaseRoot !== 'string' || !releaseRoot.trim()) fail('CAPCUT_CATALOG_RELEASE_ROOT_INVALID')
  const root = path.resolve(releaseRoot)
  const releasesRoot = path.join(root, releasesDirName)
  const pointerPath = path.join(root, pointerFileName)

  /** @param {string} releaseDir @param {Record<string, any>} shard @returns {Promise<CapCutShardDocument>} */
  const readShard = async (releaseDir, shard) => {
    const shardPath = path.join(releaseDir, 'shards', `${shard.shardId}.json`)
    if (!within(releaseDir, shardPath)) fail('CAPCUT_CATALOG_RELEASE_PATH_INVALID')
    const shardDocument = JSON.parse(await readFile(shardPath, 'utf8'))
    if (!isRecord(shardDocument) || shardDocument.schemaVersion !== CAPCUT_CATALOG_SCHEMA_VERSION ||
        shardDocument.shardId !== shard.shardId || !Array.isArray(shardDocument.entries) ||
        shardDocument.entries.length !== shard.entries ||
        sha256(stableJson(shardDocument.entries)) !== shard.fingerprint) {
      fail('CAPCUT_CATALOG_SHARD_FINGERPRINT_MISMATCH')
    }
    return /** @type {CapCutShardDocument} */ (Object.freeze(shardDocument))
  }

  /** @param {unknown} releaseId @param {{verifyShards?: boolean}} [options] @returns {Promise<CapCutReleaseMetadata>} */
  const readReleaseMetadata = async (releaseId, { verifyShards = false } = {}) => {
    const safeReleaseId = assertReleaseId(releaseId)
    const releaseDir = path.join(releasesRoot, safeReleaseId)
    if (!within(releasesRoot, releaseDir)) fail('CAPCUT_CATALOG_RELEASE_PATH_INVALID')
    const manifest = assertManifest(JSON.parse(await readFile(path.join(releaseDir, 'manifest.json'), 'utf8')))
    if (verifyShards) {
      const shards = []
      for (const shard of manifest.shards) shards.push(await readShard(releaseDir, shard))
      assertManifestTotals(manifest, shards)
    }
    return /** @type {CapCutReleaseMetadata} */ (Object.freeze({ releaseId: safeReleaseId, manifest }))
  }

  /** @param {unknown} releaseId @returns {Promise<CapCutRelease>} */
  const readRelease = async (releaseId) => {
    const metadata = await readReleaseMetadata(releaseId)
    const releaseDir = path.join(releasesRoot, metadata.releaseId)
    /** @type {CapCutShardDocument[]} */
    const shards = []
    for (const shard of metadata.manifest.shards) shards.push(await readShard(releaseDir, shard))
    return /** @type {CapCutRelease} */ (Object.freeze({ ...metadata, shards }))
  }

  /** @returns {Promise<{schemaVersion: 1, releaseId: string, manifestFingerprint: string}>} */
  const readPointer = async () => {
    const pointer = JSON.parse(await readFile(pointerPath, 'utf8'))
    if (!isRecord(pointer) || pointer.schemaVersion !== 1) fail('CAPCUT_CATALOG_POINTER_INVALID')
    assertReleaseId(pointer.releaseId)
    assertFingerprint(pointer.manifestFingerprint, 'CAPCUT_CATALOG_POINTER_FINGERPRINT_INVALID')
    return /** @type {{schemaVersion: 1, releaseId: string, manifestFingerprint: string}} */ (pointer)
  }

  const manager = {
    /** @param {{manifest: unknown, shards: AsyncIterable<unknown> | Iterable<unknown>}} input */
    async publish({ manifest, shards }) {
      const safeManifest = assertManifest(manifest)
      const iterable = shardIterator(shards)
      const releaseId = `release_${safeManifest.manifestFingerprint.slice(0, 16)}${sha256(randomUUID()).slice(0, 16)}`
      const releaseDir = path.join(releasesRoot, releaseId)
      const stagingDir = path.join(root, `.staging-${releaseId}`)
      if (!within(root, stagingDir) || !within(releasesRoot, releaseDir)) fail('CAPCUT_CATALOG_RELEASE_PATH_INVALID')
      await rm(stagingDir, { recursive: true, force: true })
      await mkdir(path.join(stagingDir, 'shards'), { recursive: true })
      try {
        await writeJsonAtomic(path.join(stagingDir, 'manifest.json'), safeManifest)
        const writtenShards = []
        for (const shardManifest of safeManifest.shards) {
          const next = await iterable.next()
          const shard = next.value
          if (next.done || !isRecord(shard) || shard.shardId !== shardManifest.shardId ||
              !Array.isArray(shard.entries) || shard.entries.length !== shardManifest.entries ||
              sha256(stableJson(shard.entries)) !== shardManifest.fingerprint) {
            fail('CAPCUT_CATALOG_SHARD_FINGERPRINT_MISMATCH')
          }
          await writeJsonAtomic(path.join(stagingDir, 'shards', `${shardManifest.shardId}.json`), {
            schemaVersion: CAPCUT_CATALOG_SCHEMA_VERSION,
            shardId: shardManifest.shardId,
            entries: shard.entries,
          })
          writtenShards.push({ shardId: shardManifest.shardId, entries: shard.entries })
        }
        if (!(await iterable.next()).done) fail('CAPCUT_CATALOG_SHARDS_INVALID')
        assertManifestTotals(safeManifest, writtenShards)
        await mkdir(releasesRoot, { recursive: true })
        await rm(releaseDir, { recursive: true, force: true })
        await rename(stagingDir, releaseDir)
        const pointer = Object.freeze({ schemaVersion: 1, releaseId, manifestFingerprint: safeManifest.manifestFingerprint })
        await writeJsonAtomic(pointerPath, pointer)
        return await readReleaseMetadata(releaseId, { verifyShards: true })
      } catch (error) {
        await rm(stagingDir, { recursive: true, force: true }).catch(() => {})
        throw error
      }
    },
    /** @param {unknown} releaseId */
    async rollback(releaseId) {
      const release = await readReleaseMetadata(releaseId, { verifyShards: true })
      await writeJsonAtomic(pointerPath, {
        schemaVersion: 1,
        releaseId: release.releaseId,
        manifestFingerprint: release.manifest.manifestFingerprint,
      })
      return release
    },
    async readCurrentMetadata({ verifyShards = false } = {}) {
      const pointer = await readPointer()
      const release = await readReleaseMetadata(pointer.releaseId, { verifyShards })
      if (release.manifest.manifestFingerprint !== pointer.manifestFingerprint) fail('CAPCUT_CATALOG_POINTER_FINGERPRINT_MISMATCH')
      return release
    },
    async readCurrent() {
      const pointer = await readPointer()
      const release = await readRelease(pointer.releaseId)
      if (release.manifest.manifestFingerprint !== pointer.manifestFingerprint) fail('CAPCUT_CATALOG_POINTER_FINGERPRINT_MISMATCH')
      return release
    },
    async *readCurrentShards() {
      const release = await manager.readCurrentMetadata()
      const releaseDir = path.join(releasesRoot, release.releaseId)
      for (const shard of release.manifest.shards) yield await readShard(releaseDir, shard)
    },
    async readPublicCurrent() {
      return publicRelease(await manager.readCurrentMetadata({ verifyShards: true }))
    },
  }
  return Object.freeze(manager)
}

/** @param {{store: ReturnType<typeof createCapCutCatalogReleaseStore>, sign: (payload: Buffer) => string | Promise<string>}} input */
export const createCapCutCatalogBackup = async ({ store, sign }) => {
  if (!store || typeof store.readCurrent !== 'function' || typeof sign !== 'function') fail('CAPCUT_CATALOG_BACKUP_INPUT_INVALID')
  const current = await store.readCurrent()
  const payload = Object.freeze({
    schemaVersion: backupSchemaVersion,
    rightsMode: CAPCUT_MATE_RIGHTS_MODE,
    releaseId: current.releaseId,
    manifest: current.manifest,
    shards: current.shards,
  })
  const payloadBytes = Buffer.from(stableJson(payload))
  const signature = await sign(payloadBytes)
  if (typeof signature !== 'string' || !signature) fail('CAPCUT_CATALOG_BACKUP_SIGNATURE_INVALID')
  return Object.freeze({
    schemaVersion: backupSchemaVersion,
    payload,
    signature,
    payloadFingerprint: sha256(payloadBytes),
    publicSummary: publicRelease(current),
  })
}

/** @param {{backup: Record<string, any>, releaseRoot: string, verify: (payload: Buffer, signature: string) => boolean | Promise<boolean>}} input */
export const restoreCapCutCatalogBackup = async ({ backup, releaseRoot, verify }) => {
  if (!isRecord(backup) || backup.schemaVersion !== backupSchemaVersion || !isRecord(backup.payload) || typeof verify !== 'function') {
    fail('CAPCUT_CATALOG_BACKUP_INVALID')
  }
  const payloadBytes = Buffer.from(stableJson(backup.payload))
  if (sha256(payloadBytes) !== backup.payloadFingerprint) fail('CAPCUT_CATALOG_BACKUP_SIGNATURE_INVALID')
  if (!await verify(payloadBytes, backup.signature)) fail('CAPCUT_CATALOG_BACKUP_SIGNATURE_INVALID')
  assertManifest(backup.payload.manifest)
  const store = createCapCutCatalogReleaseStore({ releaseRoot })
  const restored = await store.publish({ manifest: backup.payload.manifest, shards: backup.payload.shards })
  await store.rollback(restored.releaseId)
  return store
}
