const templateIds = ['product-focus', 'guided-story', 'step-by-step', 'beat-montage', 'universal-adaptive']
const contentGoals = ['product_showcase', 'narrative', 'tutorial', 'montage']
const orientations = ['portrait', 'landscape', 'square']
const pacingValues = ['calm', 'balanced', 'dynamic']
const maxIdentifierLength = 180

/** @typedef {{ min: number, max: number }} DurationRange */
/** @typedef {{ min: number, recommended: number, max: number }} SlotCount */
/** @typedef {{ video: true, voiceover: boolean, captions: boolean, bgm: boolean }} TrackCapabilities */
/** @typedef {{ synthetic_preview: true, jianying_preparation: true }} Compatibility */
/** @typedef {{ template_id: string, version: 1 }} TemplateReference */
/** @typedef {{ schema_version: 1, kind: 'fixed_template', template_id: string, version: 1, content_goals: string[], supported_orientations: string[], pacing: string[], duration_seconds: DurationRange, slot_count: SlotCount, tracks: TrackCapabilities, compatibility: Compatibility, audit_label: string }} FixedTemplate */
/** @typedef {{ schema_version: 1, kind: 'template_selection_request', project_id: string, content_goal: string, orientation: string, pacing: string, target_duration_seconds: number, voiceover_required: boolean, captions_required: boolean }} TemplateSelectionRequest */
/** @typedef {{ template_id: string, version: 1, score: number, matched_rules: string[], excluded_reasons: string[] }} RankedCandidate */
/** @typedef {{ schema_version: 1, kind: 'template_selection_decision', project_id: string, selected_template: TemplateReference, ranked_candidates: RankedCandidate[], selection_reason_codes: string[] }} TemplateSelectionDecision */
/** @typedef {{ schema_version: 1, kind: 'template_draft_request', project_id: string, template_ref: TemplateReference, selection: TemplateSelectionDecision, confirmation: 'required' }} TemplateDraftRequest */

/** @type {FixedTemplate[]} */
const fixedTemplates = [
  {
    schema_version: 1,
    kind: 'fixed_template',
    template_id: 'product-focus',
    version: 1,
    content_goals: ['product_showcase'],
    supported_orientations: ['portrait', 'landscape', 'square'],
    pacing: ['calm', 'balanced'],
    duration_seconds: { min: 15, max: 60 },
    slot_count: { min: 4, recommended: 6, max: 10 },
    tracks: { video: true, voiceover: true, captions: true, bgm: true },
    compatibility: { synthetic_preview: true, jianying_preparation: true },
    audit_label: 'product-detail-sequence',
  },
  {
    schema_version: 1,
    kind: 'fixed_template',
    template_id: 'guided-story',
    version: 1,
    content_goals: ['narrative'],
    supported_orientations: ['landscape', 'portrait'],
    pacing: ['calm', 'balanced'],
    duration_seconds: { min: 30, max: 120 },
    slot_count: { min: 5, recommended: 8, max: 14 },
    tracks: { video: true, voiceover: true, captions: true, bgm: true },
    compatibility: { synthetic_preview: true, jianying_preparation: true },
    audit_label: 'guided-narrative-sequence',
  },
  {
    schema_version: 1,
    kind: 'fixed_template',
    template_id: 'step-by-step',
    version: 1,
    content_goals: ['tutorial'],
    supported_orientations: ['landscape', 'portrait', 'square'],
    pacing: ['calm', 'balanced'],
    duration_seconds: { min: 30, max: 150 },
    slot_count: { min: 4, recommended: 7, max: 12 },
    tracks: { video: true, voiceover: true, captions: true, bgm: false },
    compatibility: { synthetic_preview: true, jianying_preparation: true },
    audit_label: 'ordered-instruction-sequence',
  },
  {
    schema_version: 1,
    kind: 'fixed_template',
    template_id: 'beat-montage',
    version: 1,
    content_goals: ['montage'],
    supported_orientations: ['portrait', 'landscape', 'square'],
    pacing: ['dynamic'],
    duration_seconds: { min: 10, max: 45 },
    slot_count: { min: 6, recommended: 10, max: 18 },
    tracks: { video: true, voiceover: false, captions: true, bgm: true },
    compatibility: { synthetic_preview: true, jianying_preparation: true },
    audit_label: 'music-led-montage-sequence',
  },
  {
    schema_version: 1,
    kind: 'fixed_template',
    template_id: 'universal-adaptive',
    version: 1,
    content_goals: ['product_showcase', 'narrative', 'tutorial', 'montage'],
    supported_orientations: ['portrait', 'landscape', 'square'],
    pacing: ['calm', 'balanced', 'dynamic'],
    duration_seconds: { min: 1, max: 180 },
    slot_count: { min: 1, recommended: 6, max: 24 },
    tracks: { video: true, voiceover: true, captions: true, bgm: true },
    compatibility: { synthetic_preview: true, jianying_preparation: true },
    audit_label: 'adaptive-reference-sequence',
  },
]

const templateKeys = [
  'schema_version',
  'kind',
  'template_id',
  'version',
  'content_goals',
  'supported_orientations',
  'pacing',
  'duration_seconds',
  'slot_count',
  'tracks',
  'compatibility',
  'audit_label',
]
const selectionRequestKeys = [
  'schema_version',
  'kind',
  'project_id',
  'content_goal',
  'orientation',
  'pacing',
  'target_duration_seconds',
  'voiceover_required',
  'captions_required',
]
const rankedCandidateKeys = ['template_id', 'version', 'score', 'matched_rules', 'excluded_reasons']
const selectionKeys = [
  'schema_version',
  'kind',
  'project_id',
  'selected_template',
  'ranked_candidates',
  'selection_reason_codes',
]
const draftRequestKeys = [
  'schema_version',
  'kind',
  'project_id',
  'template_ref',
  'selection',
  'confirmation',
]

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {Record<string, unknown>} value @param {string[]} allowed */
const hasExactKeys = (value, allowed) =>
  Object.keys(value).length === allowed.length &&
  Object.keys(value).every((key) => allowed.includes(key)) &&
  allowed.every((key) => Object.hasOwn(value, key))

/** @param {unknown} left @param {unknown} right @returns {boolean} */
const valuesEqual = (left, right) => {
  if (left === right) return true
  if (Array.isArray(left) || Array.isArray(right)) {
    return (
      Array.isArray(left) &&
      Array.isArray(right) &&
      left.length === right.length &&
      left.every((entry, index) => valuesEqual(entry, right[index]))
    )
  }
  if (!isRecord(left) || !isRecord(right)) return false
  const leftKeys = Object.keys(left)
  const rightKeys = Object.keys(right)
  return (
    leftKeys.length === rightKeys.length &&
    leftKeys.every((key) => Object.hasOwn(right, key) && valuesEqual(left[key], right[key]))
  )
}

/** @param {string} value */
const hasUnsafeIdentifierCharacter = (value) =>
  Array.from(value).some((character) => {
    const code = character.charCodeAt(0)
    return character === String.fromCharCode(92) || character === '/' || code <= 31
  })

/** @param {unknown} value @returns {value is string} */
const isSafeIdentifier = (value) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= maxIdentifierLength &&
  value === value.trim() &&
  !hasUnsafeIdentifierCharacter(value) &&
  !/^[a-z]:/iu.test(value) &&
  !/^file:/iu.test(value)

/** @param {unknown} value @param {string[]} allowed @returns {value is string[]} */
const isEnumArray = (value, allowed) =>
  Array.isArray(value) &&
  value.length > 0 &&
  new Set(value).size === value.length &&
  value.every((entry) => typeof entry === 'string' && allowed.includes(entry))

/** @param {unknown} value @returns {value is number} */
const isInteger = (value) => typeof value === 'number' && Number.isInteger(value)

/** @param {unknown} value @returns {value is DurationRange} */
const isDurationRange = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['min', 'max']) &&
  isInteger(value.min) &&
  isInteger(value.max) &&
  value.min >= 1 &&
  value.max <= 180 &&
  value.min <= value.max

/** @param {unknown} value @returns {value is SlotCount} */
const isSlotCount = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['min', 'recommended', 'max']) &&
  isInteger(value.min) &&
  isInteger(value.recommended) &&
  isInteger(value.max) &&
  value.min >= 1 &&
  value.min <= value.recommended &&
  value.recommended <= value.max &&
  value.max <= 24

/** @param {unknown} value @returns {value is TrackCapabilities} */
const isTrackCapabilities = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['video', 'voiceover', 'captions', 'bgm']) &&
  value.video === true &&
  typeof value.voiceover === 'boolean' &&
  typeof value.captions === 'boolean' &&
  typeof value.bgm === 'boolean'

/** @param {unknown} value @returns {value is Compatibility} */
const isCompatibility = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['synthetic_preview', 'jianying_preparation']) &&
  value.synthetic_preview === true &&
  value.jianying_preparation === true

/** @param {unknown} value @returns {value is TemplateReference} */
const isTemplateReference = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['template_id', 'version']) &&
  typeof value.template_id === 'string' &&
  templateIds.includes(value.template_id) &&
  value.version === 1

/** @param {unknown} value @returns {value is FixedTemplate} */
export const isFixedTemplate = (value) =>
  isRecord(value) &&
  hasExactKeys(value, templateKeys) &&
  value.schema_version === 1 &&
  value.kind === 'fixed_template' &&
  typeof value.template_id === 'string' &&
  templateIds.includes(value.template_id) &&
  value.version === 1 &&
  isEnumArray(value.content_goals, contentGoals) &&
  isEnumArray(value.supported_orientations, orientations) &&
  isEnumArray(value.pacing, pacingValues) &&
  isDurationRange(value.duration_seconds) &&
  isSlotCount(value.slot_count) &&
  isTrackCapabilities(value.tracks) &&
  isCompatibility(value.compatibility) &&
  isSafeIdentifier(value.audit_label)

/** @param {unknown} value @returns {value is TemplateSelectionRequest} */
export const isTemplateSelectionRequest = (value) =>
  isRecord(value) &&
  hasExactKeys(value, selectionRequestKeys) &&
  value.schema_version === 1 &&
  value.kind === 'template_selection_request' &&
  isSafeIdentifier(value.project_id) &&
  typeof value.content_goal === 'string' &&
  contentGoals.includes(value.content_goal) &&
  typeof value.orientation === 'string' &&
  orientations.includes(value.orientation) &&
  typeof value.pacing === 'string' &&
  pacingValues.includes(value.pacing) &&
  isInteger(value.target_duration_seconds) &&
  value.target_duration_seconds >= 1 &&
  value.target_duration_seconds <= 180 &&
  typeof value.voiceover_required === 'boolean' &&
  typeof value.captions_required === 'boolean'

/** @param {TemplateSelectionRequest} request @param {FixedTemplate} template @returns {RankedCandidate} */
const scoreTemplate = (request, template) => {
  /** @type {string[]} */
  const matchedRules = []
  /** @type {string[]} */
  const excludedReasons = []
  let score = 0

  /** @param {boolean} condition @param {number} points @param {string} matchedCode @param {string} excludedCode */
  const match = (condition, points, matchedCode, excludedCode) => {
    if (condition) {
      score += points
      matchedRules.push(matchedCode)
    } else {
      excludedReasons.push(excludedCode)
    }
  }

  match(template.content_goals.includes(request.content_goal), 40, 'CONTENT_GOAL_MATCH', 'CONTENT_GOAL_MISMATCH')
  match(template.supported_orientations.includes(request.orientation), 20, 'ORIENTATION_MATCH', 'ORIENTATION_MISMATCH')
  match(template.pacing.includes(request.pacing), 15, 'PACING_MATCH', 'PACING_MISMATCH')
  match(
    request.target_duration_seconds >= template.duration_seconds.min && request.target_duration_seconds <= template.duration_seconds.max,
    15,
    'DURATION_IN_RANGE',
    'DURATION_OUT_OF_RANGE',
  )
  match(request.voiceover_required === false || template.tracks.voiceover, 5, 'VOICEOVER_SUPPORTED', 'VOICEOVER_UNSUPPORTED')
  match(request.captions_required === false || template.tracks.captions, 5, 'CAPTIONS_SUPPORTED', 'CAPTIONS_UNSUPPORTED')

  return {
    template_id: template.template_id,
    version: template.version,
    score,
    matched_rules: matchedRules,
    excluded_reasons: excludedReasons,
  }
}

/** @param {TemplateSelectionRequest} request @param {FixedTemplate} template */
const isHardCompatible = (request, template) =>
  template.content_goals.includes(request.content_goal) &&
  template.supported_orientations.includes(request.orientation) &&
  request.target_duration_seconds >= template.duration_seconds.min &&
  request.target_duration_seconds <= template.duration_seconds.max &&
  (request.voiceover_required === false || template.tracks.voiceover) &&
  (request.captions_required === false || template.tracks.captions)

/** @param {TemplateSelectionRequest} request @returns {TemplateSelectionDecision} */
const buildSelectionDecision = (request) => {
  const rankedCandidates = fixedTemplates
    .filter((template) => isHardCompatible(request, template))
    .map((template) => scoreTemplate(request, template))
    .sort((left, right) => right.score - left.score || String(left.template_id).localeCompare(String(right.template_id)))
  if (rankedCandidates.length === 0) {
    throw new TemplateLibraryError('no_compatible_fixed_template')
  }
  const winner = rankedCandidates[0]
  return {
    schema_version: 1,
    kind: 'template_selection_decision',
    project_id: request.project_id,
    selected_template: { template_id: winner.template_id, version: winner.version },
    ranked_candidates: rankedCandidates,
    selection_reason_codes: [...winner.matched_rules],
  }
}

/** @param {unknown} value @returns {value is RankedCandidate} */
const isRankedCandidate = (value) =>
  isRecord(value) &&
  hasExactKeys(value, rankedCandidateKeys) &&
  templateIds.includes(String(value.template_id)) &&
  value.version === 1 &&
  isInteger(value.score) &&
  value.score >= 0 &&
  value.score <= 100 &&
  Array.isArray(value.matched_rules) &&
  value.matched_rules.every(isSafeIdentifier) &&
  Array.isArray(value.excluded_reasons) &&
  value.excluded_reasons.every(isSafeIdentifier) &&
  value.matched_rules.length + value.excluded_reasons.length === 6

/** @param {unknown} request @param {unknown} value @returns {value is TemplateSelectionDecision} */
export const isTemplateSelectionDecision = (request, value) => {
  if (!isTemplateSelectionRequest(request) || !isRecord(value) || !hasExactKeys(value, selectionKeys)) return false
  if (
    value.schema_version !== 1 ||
    value.kind !== 'template_selection_decision' ||
    value.project_id !== request.project_id ||
    !isTemplateReference(value.selected_template) ||
    !Array.isArray(value.ranked_candidates) ||
    value.ranked_candidates.length === 0 ||
    !value.ranked_candidates.every(isRankedCandidate) ||
    !Array.isArray(value.selection_reason_codes) ||
    !value.selection_reason_codes.every(isSafeIdentifier)
  ) {
    return false
  }
  return valuesEqual(value, buildSelectionDecision(request))
}

/**
 * Validates the self-contained v1 selection audit without recalculating it
 * against the mutable built-in catalog.
 * @param {unknown} request
 * @param {unknown} value
 */
export const isHistoricalTemplateSelectionDecision = (request, value) => {
  if (!isTemplateSelectionRequest(request) || !isRecord(value) || !hasExactKeys(value, selectionKeys)) {
    return false
  }
  if (
    value.schema_version !== 1 ||
    value.kind !== 'template_selection_decision' ||
    value.project_id !== request.project_id ||
    !isTemplateReference(value.selected_template) ||
    !Array.isArray(value.ranked_candidates) ||
    value.ranked_candidates.length === 0 ||
    !value.ranked_candidates.every(isRankedCandidate) ||
    new Set(value.ranked_candidates.map((candidate) =>
      `${candidate.template_id}\u0000${candidate.version}`)).size !== value.ranked_candidates.length ||
    !Array.isArray(value.selection_reason_codes) ||
    !value.selection_reason_codes.every(isSafeIdentifier)
  ) {
    return false
  }
  const ranked = /** @type {RankedCandidate[]} */ (value.ranked_candidates)
  const sorted = ranked.every((candidate, index) =>
    index === 0 ||
    ranked[index - 1].score > candidate.score ||
    (
      ranked[index - 1].score === candidate.score &&
      String(ranked[index - 1].template_id).localeCompare(String(candidate.template_id)) <= 0
    ))
  return (
    sorted &&
    valuesEqual(value.selected_template, {
      template_id: ranked[0].template_id,
      version: ranked[0].version,
    }) &&
    valuesEqual(value.selection_reason_codes, ranked[0].matched_rules)
  )
}

export class TemplateLibraryError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'TemplateLibraryError'
    this.code = code
  }
}

export const listFixedTemplates = () => clone(fixedTemplates)

/** @param {unknown} request */
export const selectFixedTemplate = (request) => {
  if (!isTemplateSelectionRequest(request)) {
    throw new TemplateLibraryError('invalid_template_selection_request')
  }
  return buildSelectionDecision(request)
}

/** @param {unknown} request @param {unknown} value @returns {value is TemplateDraftRequest} */
export const isTemplateDraftRequest = (request, value) => {
  if (!isTemplateSelectionRequest(request) || !isRecord(value) || !hasExactKeys(value, draftRequestKeys)) return false
  return (
    value.schema_version === 1 &&
    value.kind === 'template_draft_request' &&
    value.project_id === request.project_id &&
    isTemplateReference(value.template_ref) &&
    isTemplateSelectionDecision(request, value.selection) &&
    value.confirmation === 'required' &&
    valuesEqual(value.template_ref, value.selection.selected_template)
  )
}

/** @param {unknown} request @param {unknown} value */
export const isHistoricalTemplateDraftRequest = (request, value) => {
  if (!isTemplateSelectionRequest(request) || !isRecord(value) || !hasExactKeys(value, draftRequestKeys)) {
    return false
  }
  return (
    value.schema_version === 1 &&
    value.kind === 'template_draft_request' &&
    value.project_id === request.project_id &&
    isTemplateReference(value.template_ref) &&
    isHistoricalTemplateSelectionDecision(request, value.selection) &&
    isRecord(value.selection) &&
    value.confirmation === 'required' &&
    valuesEqual(value.template_ref, value.selection.selected_template)
  )
}

/** @param {unknown} request @param {unknown} selection @returns {TemplateDraftRequest} */
export const createTemplateDraftRequest = (request, selection) => {
  if (!isTemplateSelectionRequest(request)) {
    throw new TemplateLibraryError('invalid_template_selection_request')
  }
  const canonicalSelection = buildSelectionDecision(request)
  if (!isRecord(selection) || !hasExactKeys(selection, selectionKeys)) {
    throw new TemplateLibraryError('invalid_template_selection_decision')
  }
  if (!valuesEqual(selection, canonicalSelection)) {
    throw new TemplateLibraryError('template_selection_mismatch')
  }
  const selectedTemplate = canonicalSelection.selected_template
  return {
    schema_version: 1,
    kind: 'template_draft_request',
    project_id: request.project_id,
    template_ref: clone(selectedTemplate),
    selection: clone(canonicalSelection),
    confirmation: 'required',
  }
}

if (!fixedTemplates.every(isFixedTemplate)) {
  throw new Error('invalid_builtin_template_catalog')
}
