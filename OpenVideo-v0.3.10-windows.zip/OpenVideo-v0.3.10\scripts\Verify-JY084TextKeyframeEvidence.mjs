import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rename, rm, rmdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY084_MANUAL_ATTESTATION_REQUIRED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot; const root = path.join(dataRoot, 'evidence', 'jy084-text-keyframe'); const pendingPath = path.join(root, 'pending.json'); const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  const keys = ['schema_version', 'draft_id', 'draft_root', 'media_root', 'media_owner', 'profile_id', 'app_version', 'target_text', 'target_start_us', 'target_duration_us', 'keyframe_ids', 'pre_open_fingerprint']
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  const admitted = (pending.profile_id === 'jianying-11-1-provisional' && pending.app_version === '11.1.0.14287') || (pending.profile_id === 'jianying-11-2-provisional' && pending.app_version === '11.2.0.14339')
  if (Object.keys(pending).sort().join('\0') !== keys.sort().join('\0') || pending.schema_version !== 1 || !admitted || typeof pending.target_text !== 'string' || !Number.isSafeInteger(pending.target_start_us) || !Number.isSafeInteger(pending.target_duration_us) || !Array.isArray(pending.keyframe_ids) || pending.keyframe_ids.length !== 2 || pending.keyframe_ids.some((point, index) => !point || typeof point.id !== 'string' || !/^[a-f0-9]{32}$/u.test(point.id) || point.offset_us !== (index === 0 ? 500_000 : 1_000_000) || point.initial_value !== (index === 0 ? 1 : 1.2)) || !/^[a-f0-9]{64}$/u.test(pending.pre_open_fingerprint) || desktop?.profileId !== pending.profile_id || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root)) throw new Error('JY084_EVIDENCE_BINDING_INVALID')
  const canonicalTemp = await realpath(tmpdir()); const canonicalMedia = await realpath(pending.media_root); const relative = path.relative(canonicalTemp, canonicalMedia); const metadata = await lstat(pending.media_root); const ownerPath = path.join(pending.media_root, '.openvideo-jy084-owner')
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative) || !path.basename(canonicalMedia).startsWith('openvideo-jy084-text-keyframe-') || !metadata.isDirectory() || metadata.isSymbolicLink() || await readFile(ownerPath, 'utf8') !== pending.media_owner) throw new Error('JY084_TEMP_OWNERSHIP_INVALID')
  const encryptedPath = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json'); const encrypted = await readFile(encryptedPath); if (createHash('sha256').update(encrypted).digest('hex') === pending.pre_open_fingerprint) throw new Error('JY084_MANUAL_EDIT_NOT_PERSISTED'); const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy084-verify-'))
  try {
    const plain = path.join(tempRoot, 'draft_content.json'); const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(encryptedPath, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY084_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8')); const titles = content?.tracks?.filter((track) => track?.name === 'title-primary').flatMap((track) => track.segments ?? []) ?? []
    const hasHalfSecondOffset = (point) => point && (point.time_offset === 500_000 || point.timeOffset === 500_000) && point?.values?.[0] === 1
    const hasOneSecondOffset = (point) => point && (point.time_offset === 1_000_000 || point.timeOffset === 1_000_000)
    const hasCanonicalStart = (range) => pending.target_start_us === 0 && range && (!Object.hasOwn(range, 'start') || range.start === 0)
    const matched = titles.filter((segment) => hasCanonicalStart(segment?.target_timerange) && segment?.target_timerange?.duration === pending.target_duration_us && Array.isArray(segment?.common_keyframes) && segment.common_keyframes.some((list) => list?.property_type === 'KFTypeScaleX' && Array.isArray(list?.keyframe_list) && list.keyframe_list.length === 2 && list.keyframe_list[0]?.id === pending.keyframe_ids[0].id && list.keyframe_list[1]?.id === pending.keyframe_ids[1].id && hasHalfSecondOffset(list.keyframe_list[0]) && hasOneSecondOffset(list.keyframe_list[1]) && list.keyframe_list[1]?.values?.[0] === 1.4))
    if (matched.length !== 1) {
      const error = new Error('JY084_TEXT_KEYFRAME_PERSISTENCE_INVALID')
      error.diagnostic = titles.map((segment) => ({
        keyframeLists: Array.isArray(segment?.common_keyframes)
          ? segment.common_keyframes.map((list) => ({
              propertyType: list?.property_type ?? null,
              points: Array.isArray(list?.keyframe_list)
                ? list.keyframe_list.map((point) => ({ offsetUs: point?.time_offset ?? null, values: point?.values ?? null }))
                : null,
            }))
          : null,
      }))
      throw error
    }
    const postSaveFingerprint = createHash('sha256').update(encrypted).digest('hex')
    const record = { schema_version: 1, manual_evidence_verified: true, manual_attestation: 'opened-edited-saved-reopened', profile_id: pending.profile_id, app_version: desktop.version, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, matching_keyframe_count: 2, temporary_media_cleaned: true, draft_id: pending.draft_id, target_text: pending.target_text, target_start_us: pending.target_start_us, target_duration_us: pending.target_duration_us, keyframe_ids: [{ id: pending.keyframe_ids[0].id, offset_us: 500_000, value: 1 }, { id: pending.keyframe_ids[1].id, offset_us: 1_000_000, value: 1.4 }], pre_open_fingerprint: pending.pre_open_fingerprint, post_save_fingerprint: postSaveFingerprint }
    await securePrivateRuntimeRoot(root); const staged = path.join(root, 'post-save.pending.json'); await writeFile(staged, `${JSON.stringify(record)}\n`, { encoding: 'utf8', mode: 0o600 }); await rm(path.join(pending.media_root, 'video.mp4'), { force: true }); await rm(path.join(pending.media_root, 'voice.wav'), { force: true }); await rm(ownerPath, { force: true }); await rmdir(pending.media_root); await rename(staged, path.join(root, 'post-save.json')); await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, capability: 'transform.text.keyframe', scheme: 'encrypt_v2', matchingKeyframeCount: 2, temporaryMediaCleaned: true })}\n`)
  } finally { await rm(tempRoot, { recursive: true, force: true }) }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.message ?? 'JY084_VERIFY_FAILED', ...(error?.diagnostic ? { diagnostic: error.diagnostic } : {})})}\n`); process.exitCode = 1 })
