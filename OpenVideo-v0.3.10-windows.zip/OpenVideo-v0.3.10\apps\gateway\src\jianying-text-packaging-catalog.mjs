import { fingerprintCanonical } from './editor-agent-contracts.mjs'

const tokenPattern = /^ovjpack_v1_[A-Za-z0-9_-]{12,160}$/u
const resourcePattern = /^[A-Za-z0-9_-]{4,80}$/u
const capabilityByKind = Object.freeze({
  sticker: 'sticker.named',
  flower: 'text.flower.private',
  bubble: 'text.bubble.private',
})

export class JianyingTextPackagingCatalogError extends Error {
  /** @param {string} code */
  constructor(code) { super(code); this.code = code }
}

/** @param {unknown} value */
export const parseJianyingTextPackagingCatalog = (value) => {
  /** @type {any} */
  const candidate = value
  if (!candidate || typeof candidate !== 'object' || candidate.schema_version !== 1 || !Array.isArray(candidate.entries) || typeof candidate.fingerprint !== 'string') return null
  const entries = candidate.entries.map((/** @type {any} */ entry) => {
    if (!entry || typeof entry !== 'object' || !['sticker', 'flower', 'bubble'].includes(entry.kind) ||
      !tokenPattern.test(entry.packaging_token) || entry.capability_id !== /** @type {any} */ (capabilityByKind)[entry.kind] ||
      typeof entry.resource_id !== 'string' || !resourcePattern.test(entry.resource_id)) {
      throw new JianyingTextPackagingCatalogError('JY063_TEXT_PACKAGING_CATALOG_INVALID')
    }
    if ((entry.kind === 'flower' && entry.effect_id !== entry.resource_id) ||
      (entry.kind === 'bubble' && (typeof entry.effect_id !== 'string' || !resourcePattern.test(entry.effect_id)))) {
      throw new JianyingTextPackagingCatalogError('JY063_TEXT_PACKAGING_CATALOG_INVALID')
    }
    /** @type {any} */
    const normalized = {
      kind: entry.kind,
      capability_id: entry.capability_id,
      packaging_token: entry.packaging_token,
      resource_id: entry.resource_id,
    }
    if (entry.kind !== 'sticker') normalized.effect_id = entry.effect_id
    return normalized
  })
  if (new Set(entries.map((/** @type {any} */ entry) => entry.packaging_token)).size !== entries.length) {
    throw new JianyingTextPackagingCatalogError('JY063_TEXT_PACKAGING_CATALOG_INVALID')
  }
  if (entries.length !== 3 || new Set(entries.map((/** @type {any} */ entry) => entry.kind)).size !== 3) {
    throw new JianyingTextPackagingCatalogError('JY063_TEXT_PACKAGING_CATALOG_INCOMPLETE')
  }
  const body = { schema_version: 1, entries }
  if (fingerprintCanonical(body) !== candidate.fingerprint) {
    throw new JianyingTextPackagingCatalogError('JY063_TEXT_PACKAGING_CATALOG_FINGERPRINT_INVALID')
  }
  return Object.freeze({ ...body, fingerprint: candidate.fingerprint, entries: Object.freeze(entries) })
}

/** @param {Array<Record<string, unknown>>} entries */
export const createJianyingTextPackagingCatalog = (entries) => {
  const body = { schema_version: 1, entries: entries.map((entry) => ({ ...entry })) }
  const parsed = parseJianyingTextPackagingCatalog({ ...body, fingerprint: fingerprintCanonical(body) })
  if (!parsed) throw new JianyingTextPackagingCatalogError('JY063_TEXT_PACKAGING_CATALOG_INVALID')
  return parsed
}

/** @param {unknown} value @param {string} catalogFingerprint @param {{profileId: string, version: string}} desktop */
export const parseJianyingTextPackagingEvidence = (value, catalogFingerprint, desktop) => {
  /** @type {any} */ const candidate = value
  const requiredCapabilities = ['sticker.named', 'text.flower.private', 'text.bubble.private']
  if (!candidate || !exactPostSaveKeys(candidate) || candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.profile_id !== desktop.profileId || candidate.app_version !== desktop.version || candidate.catalog_fingerprint !== catalogFingerprint ||
    candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true ||
    !Array.isArray(candidate.capabilities) || candidate.capabilities.length !== 3 ||
    !requiredCapabilities.every((capabilityId) => candidate.capabilities.includes(capabilityId)) ||
    typeof candidate.content_fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(candidate.content_fingerprint)) return null
  return Object.freeze({ ...candidate, capabilities: Object.freeze([...candidate.capabilities]) })
}

/**
 * @param {ReturnType<typeof parseJianyingTextPackagingCatalog>} catalog
 * @param {ReturnType<typeof parseJianyingTextPackagingEvidence>} evidence
 */
export const admitJianyingTextPackagingCatalog = (catalog, evidence) => {
  if (!catalog || !evidence || evidence.catalog_fingerprint !== catalog.fingerprint) return null
  return catalog
}

/**
 * @param {ReturnType<typeof parseJianyingTextPackagingCatalog>} catalog
 * @param {string} packagingToken
 */
export const resolveJianyingTextPackagingToken = (catalog, packagingToken) => {
  if (!catalog) return null
  const entry = catalog.entries.find((/** @type {any} */ candidate) => candidate.packaging_token === packagingToken)
  if (!entry) return null
  if (entry.kind === 'sticker') return Object.freeze({ kind: 'sticker', resourceId: entry.resource_id })
  if (entry.kind === 'flower') return Object.freeze({ kind: 'flower', resourceId: entry.resource_id })
  return Object.freeze({ kind: 'bubble', resourceId: entry.resource_id, effectId: entry.effect_id })
}

/** @param {any} value */
const exactPostSaveKeys = (value) => Object.keys(value).sort().join('\0') === [
  'schema_version', 'manual_evidence_verified', 'profile_id', 'app_version', 'catalog_fingerprint', 'capabilities', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'content_fingerprint',
].sort().join('\0')
