/**
 * Template FlowerText / sticker / effect cards are a style pool.
 * A project draft only receives the matched placements, never the whole pool.
 */

import { extendWindowsToCoverRange } from './voiceover-packaging-timing.mjs'

const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

const safePositiveInt = (value) => Number.isSafeInteger(value) && value > 0 ? value : null
const safeStartInt = (value) => Number.isSafeInteger(value) && value >= 0 ? value : null

/**
 * Canonical RichTimeline shots use targetRange.startUs. Writer / overlay
 * copies may still use target_timerange, target_range, or target_start_us.
 * Start and duration must come from the same schema; mixing them recreates
 * opening-clustered first-hits.
 */
export const toPackagingVideoRange = (segment) => {
  const pairs = [
    [segment?.targetRange?.startUs, segment?.targetRange?.durationUs],
    [segment?.target_timerange?.start, segment?.target_timerange?.duration],
    [segment?.target_range?.start, segment?.target_range?.duration],
    [segment?.target_start_us, segment?.target_duration_us],
  ]
  for (const [start, duration] of pairs) {
    const nextStart = safeStartInt(start)
    const nextDuration = safePositiveInt(duration)
    if (nextStart != null && nextDuration != null) return { start: nextStart, duration: nextDuration }
  }
  return null
}

export const normalizePackagingCueText = (value) =>
  typeof value === 'string' ? value.trim().toLocaleLowerCase() : ''

export const packagingRangesOverlap = (leftStart, leftDuration, rightStart, rightDuration) =>
  Number.isSafeInteger(leftStart) &&
  Number.isSafeInteger(leftDuration) &&
  Number.isSafeInteger(rightStart) &&
  Number.isSafeInteger(rightDuration) &&
  leftDuration > 0 &&
  rightDuration > 0 &&
  leftStart < rightStart + rightDuration &&
  rightStart < leftStart + leftDuration

/**
 * Keep the authored cadence: one visible card at a time. Later companions that
 * share a screen with an earlier slot stay unused instead of taking a second
 * project keyword.
 * @template T
 * @param {T[]} items
 * @param {(item: T) => {start: number, duration: number} | null} getRange
 */
export const selectNonOverlappingPackagingItems = (items, getRange) => {
  if (!Array.isArray(items)) return []
  const ordered = items
    .map((item, index) => ({ item, index, range: getRange(item) }))
    .sort((left, right) => {
      const leftStart = left.range?.start
      const rightStart = right.range?.start
      if (Number.isSafeInteger(leftStart) && Number.isSafeInteger(rightStart) && leftStart !== rightStart) {
        return leftStart - rightStart
      }
      return left.index - right.index
    })
  /** @type {T[]} */
  const kept = []
  for (const entry of ordered) {
    if (entry.range && kept.some((previous) => {
      const previousRange = getRange(previous)
      return previousRange && packagingRangesOverlap(
        entry.range.start,
        entry.range.duration,
        previousRange.start,
        previousRange.duration,
      )
    })) continue
    kept.push(entry.item)
  }
  return kept
}

const MIN_SPREAD_FLOWER_US = 700_000

const isTimedRichReplacement = (item) =>
  record(item) &&
  Number.isSafeInteger(item.targetStartUs) &&
  Number.isSafeInteger(item.targetDurationUs) &&
  item.targetDurationUs > 0

/**
 * Keep one card on screen at a time. Brief keyword order is locked: a leftover
 * may only start after the previous keyword, never by filling an earlier empty
 * shot. Opening shots stay empty until the first spoken/timed match.
 * @param {Array<Record<string, any>>} unique
 * @param {Array<{start: number, duration: number}>} shots
 */
export const spreadRichReplacementsAcrossShots = (unique, shots) => {
  if (!Array.isArray(unique) || unique.length === 0) return []
  if (!Array.isArray(shots) || shots.length === 0) {
    return selectNonOverlappingPackagingItems(
      unique.filter(isTimedRichReplacement),
      (item) => ({ start: item.targetStartUs, duration: item.targetDurationUs }),
    )
  }
  /** @type {number[]} */
  const occupiedEnd = shots.map((shot) => shot.start)
  const firstTimed = unique.find((item) => isTimedRichReplacement(item))
  const firstTimedStartUs = firstTimed ? firstTimed.targetStartUs : -1

  const bind = (item, shotIndex, startUs, ceilingUs = Number.POSITIVE_INFINITY) => {
    const shot = shots[shotIndex]
    const start = Math.max(shot.start, startUs)
    const remaining = Math.min(shot.start + shot.duration, ceilingUs) - start
    if (remaining < 400_000) return null
    const preferred = isTimedRichReplacement(item) ? item.targetDurationUs : MIN_SPREAD_FLOWER_US
    const duration = Math.min(Math.max(preferred, Math.min(MIN_SPREAD_FLOWER_US, remaining)), remaining)
    return {
      ...item,
      slot: 'rich',
      targetStartUs: start,
      targetDurationUs: duration,
    }
  }
  const bindAfterFloor = (item, floorUs, ceilingUs) => {
    for (const [shotIndex, shot] of shots.entries()) {
      if (shot.start >= ceilingUs) continue
      const placed = bind(item, shotIndex, Math.max(floorUs, occupiedEnd[shotIndex], shot.start), ceilingUs)
      if (!placed) continue
      occupiedEnd[shotIndex] = placed.targetStartUs + placed.targetDurationUs
      return placed
    }
    return null
  }

  /** @type {Array<Record<string, any>>} */
  const sequential = []
  let previousStartUs = -1
  for (const [itemIndex, item] of unique.entries()) {
    const floorUs = previousStartUs >= 0
      ? previousStartUs + 400_000
      : isTimedRichReplacement(item) ? item.targetStartUs : firstTimedStartUs
    const keepTimed = isTimedRichReplacement(item) && (previousStartUs < 0 || item.targetStartUs >= previousStartUs)
    const laterAnchor = keepTimed ? item.targetStartUs : Math.max(previousStartUs, 0)
    const nextTimedStartUs = unique.slice(itemIndex + 1).find((later) =>
      isTimedRichReplacement(later) && later.targetStartUs > laterAnchor)?.targetStartUs
    const ceilingUs = Number.isSafeInteger(nextTimedStartUs) ? nextTimedStartUs : Number.POSITIVE_INFINITY
    let placed = null
    if (keepTimed) {
      const center = item.targetStartUs + Math.floor(item.targetDurationUs / 2)
      const shotIndex = shots.findIndex((range) =>
        center >= range.start && center < range.start + range.duration)
      if (shotIndex >= 0) {
        placed = bind(item, shotIndex, Math.max(item.targetStartUs, floorUs, occupiedEnd[shotIndex]), ceilingUs)
        if (placed) occupiedEnd[shotIndex] = placed.targetStartUs + placed.targetDurationUs
      }
    }
    if (!placed) {
      if (floorUs < 0) continue
      placed = bindAfterFloor(item, floorUs, ceilingUs)
    }
    if (!placed) continue
    sequential.push(placed)
    previousStartUs = placed.targetStartUs
  }

  return sequential.sort((left, right) => left.targetStartUs - right.targetStartUs)
}

/**
 * Keep each distinct project line once. The template style pool may be larger
 * than the current copy; unused looks stay unused. Timed cards that share a
 * screen are reduced to the earlier cadence hit. When video shots are known,
 * leftover keywords stay after the previous brief keyword instead of filling earlier empty shots.
 * @param {Array<string | Record<string, any>>} replacements
 * @param {Array<{start: number, duration: number}>} [_videoRanges]
 * @param {{ projectDurationUs?: number }} [options]
 */
export const selectMatchedRichTextReplacements = (replacements, _videoRanges = [], options = {}) => {
  if (!Array.isArray(replacements)) return []
  /** @type {Array<Record<string, any>>} */
  const rich = []
  /** @type {Array<string | Record<string, any>>} */
  const rest = []
  for (const item of replacements) {
    if (record(item) && item.slot === 'rich' && typeof item.text === 'string' && item.text.trim()) {
      rich.push(item)
      continue
    }
    rest.push(item)
  }
  const seen = new Set()
  const unique = []
  for (const item of rich) {
    const key = normalizePackagingCueText(item.text)
    if (!key || seen.has(key)) continue
    seen.add(key)
    unique.push(item)
  }
  const shots = Array.isArray(_videoRanges)
    ? _videoRanges
      .map((range) => toPackagingVideoRange(range) ?? (
        Number.isSafeInteger(range?.start) &&
        Number.isSafeInteger(range?.duration) &&
        range.duration > 0
          ? { start: range.start, duration: range.duration }
          : null
      ))
      .filter(Boolean)
    : []
  const candidates = shots.length > 0
    ? spreadRichReplacementsAcrossShots(unique, shots)
    : selectNonOverlappingPackagingItems(
      unique.filter(isTimedRichReplacement).length > 0
        ? unique.filter(isTimedRichReplacement)
        : unique,
      (item) => isTimedRichReplacement(item)
        ? { start: item.targetStartUs, duration: item.targetDurationUs }
        : null,
    )
  const timedCandidates = candidates.filter(isTimedRichReplacement)
  const inferredEndUs = Math.max(
    shots.reduce((end, shot) => Math.max(end, shot.start + shot.duration), 0),
    timedCandidates.reduce(
      (end, item) => Math.max(end, item.targetStartUs + item.targetDurationUs),
      0,
    ),
  )
  const writerDurationUs = Number.isSafeInteger(options?.projectDurationUs) && options.projectDurationUs > 0
    ? options.projectDurationUs
    : 0
  const projectEndUs = writerDurationUs > 0 ? writerDurationUs : inferredEndUs
  const held = projectEndUs > 0 && timedCandidates.length > 0
    ? extendWindowsToCoverRange(
      timedCandidates.map((item) => ({
        startUs: item.targetStartUs,
        durationUs: item.targetDurationUs,
      })),
      { startUs: 0, durationUs: projectEndUs },
    )
    : []
  const heldByIndex = new Map(timedCandidates.map((item, index) => [item, held[index]]))
  return [
    ...candidates.map((item) => {
      const window = heldByIndex.get(item)
      return window
        ? { ...item, targetStartUs: window.startUs, targetDurationUs: window.durationUs }
        : item
    }),
    ...rest,
  ]
}
