import json
import os
import subprocess
import sys
from pathlib import Path

MAX_INPUT_BYTES = 16_384
MAX_TRACKS = 200
MAX_SEGMENTS = 4_000


def emit(payload):
    sys.stdout.buffer.write(
        json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    )


def fail(code, diagnostic=None):
    payload = {"ok": False, "code": code}
    if diagnostic is not None:
        payload["diagnostic"] = diagnostic
    emit(payload)
    raise SystemExit(0)


def load_payload():
    raw = sys.stdin.buffer.readline(MAX_INPUT_BYTES + 1)
    if not raw or len(raw) > MAX_INPUT_BYTES or not raw.endswith(b"\n"):
        fail("JY_TEMPLATE_INPUT_INVALID")
    try:
        payload = json.loads(raw[:-1].decode("utf-8"))
    except Exception:
        fail("JY_TEMPLATE_INPUT_INVALID")
    if not isinstance(payload, dict):
        fail("JY_TEMPLATE_INPUT_INVALID")
    return payload


def verify_upstream(module_root, expected_commit):
    try:
        root = Path(module_root).resolve()
        if not root.is_dir() or len(expected_commit) != 40:
            fail("JY_TEMPLATE_UPSTREAM_INVALID")
        repository_root = Path(
            subprocess.run(
                ["git", "-C", str(root), "rev-parse", "--show-toplevel"],
                check=True,
                capture_output=True,
                text=True,
                timeout=5,
            ).stdout.strip()
        ).resolve()
        actual_commit = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip()
        status = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain", "--untracked-files=all"],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout
        import pyJianYingDraft as draft

        module_file = Path(draft.__file__).resolve()
        if (
            repository_root != root
            or actual_commit != expected_commit
            or status.strip()
            or os.path.commonpath([str(root), str(module_file)]) != str(root)
            or not hasattr(draft, "DraftFolder")
        ):
            fail("JY_TEMPLATE_UPSTREAM_INVALID")
        return draft
    except SystemExit:
        raise
    except Exception:
        fail("JY_TEMPLATE_UPSTREAM_INVALID")


def timerange(value):
    if not isinstance(value, dict):
        return None
    start = value.get("start", 0)
    duration = value.get("duration")
    if (
        not isinstance(start, int)
        or start < 0
        or not isinstance(duration, int)
        or duration <= 0
    ):
        return None
    return {"start": start, "duration": duration}


def sanitize_materials(content):
    source = content.get("materials")
    if not isinstance(source, dict):
        source = {}
    result = {}
    allowed = {
        "audios": ("id", "name"),
        "effects": ("id", "name"),
        "flowers": ("id", "name"),
        "stickers": ("id", "name"),
        "texts": ("id", "text_size", "text_color", "alignment"),
    }
    for bucket, keys in allowed.items():
        values = source.get(bucket)
        if not isinstance(values, list):
            result[bucket] = []
            continue
        sanitized = []
        for value in values:
            if not isinstance(value, dict):
                continue
            item = {key: value[key] for key in keys if key in value}
            if isinstance(item.get("id"), str):
                sanitized.append(item)
        result[bucket] = sanitized
    return result


def sanitize_tracks(content):
    tracks = content.get("tracks")
    if not isinstance(tracks, list) or len(tracks) > MAX_TRACKS:
        fail("JY_TEMPLATE_STRUCTURE_INVALID")
    result = []
    segment_count = 0
    for track in tracks:
        if not isinstance(track, dict) or track.get("type") not in ["video", "audio", "text"]:
            continue
        segments = track.get("segments")
        if not isinstance(segments, list):
            continue
        sanitized_segments = []
        for segment in segments:
            segment_count += 1
            if segment_count > MAX_SEGMENTS:
                fail("JY_TEMPLATE_STRUCTURE_INVALID")
            if not isinstance(segment, dict):
                continue
            target = timerange(segment.get("target_timerange"))
            if target is None:
                continue
            item = {"target_timerange": target}
            if isinstance(segment.get("material_id"), str):
                item["material_id"] = segment["material_id"]
            source = timerange(segment.get("source_timerange"))
            if source is not None:
                item["source_timerange"] = source
            refs = segment.get("extra_material_refs")
            if isinstance(refs, list):
                item["extra_material_refs"] = [
                    value for value in refs if isinstance(value, str)
                ][:64]
            if isinstance(segment.get("volume"), (int, float)):
                item["volume"] = segment["volume"]
            clip = segment.get("clip")
            transform = clip.get("transform") if isinstance(clip, dict) else None
            if isinstance(transform, dict):
                item["clip"] = {
                    "transform": {
                        key: transform[key]
                        for key in ["x", "y"]
                        if isinstance(transform.get(key), (int, float))
                    }
                }
            sanitized_segments.append(item)
        result.append(
            {
                "type": track["type"],
                "name": track.get("name", "") if isinstance(track.get("name"), str) else "",
                "segments": sanitized_segments,
            }
        )
    return result


def inspect(payload):
    required = {
        "action",
        "draft_folder",
        "python_module_root",
        "expected_upstream_commit",
    }
    allowed_optional = {
        "decrypt_helper",
        "jianying_install_dir",
        "jianying_app_version",
    }
    keys = set(payload.keys())
    if not required.issubset(keys) or not keys.issubset(required | allowed_optional):
        fail("JY_TEMPLATE_INPUT_INVALID")
    draft_folder = Path(payload["draft_folder"]).resolve()
    if (
        not draft_folder.is_dir()
        or not (draft_folder / "draft_content.json").is_file()
        or draft_folder.parent == draft_folder
    ):
        fail("JY_TEMPLATE_SOURCE_INVALID")
    draft = verify_upstream(
        payload["python_module_root"], payload["expected_upstream_commit"]
    )
    from pyJianYingDraft.draft_content_loader import load_draft_content
    from pyJianYingDraft.exceptions import DraftContentLoadFailed

    decrypt_helper = payload.get("decrypt_helper")
    install_dir = payload.get("jianying_install_dir")
    app_version = payload.get("jianying_app_version")

    def fallback_loader(raw_data: bytes):
        if not isinstance(app_version, str) or not app_version.strip():
            fail("JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION")
        # Keep in sync with apps/gateway/src/jianying-draft-decrypt.mjs encrypt_v2 matrix.
        parts = []
        try:
            parts = [int(piece) for piece in app_version.strip().split(".")]
        except ValueError:
            fail("JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION")
        while len(parts) < 4:
            parts.append(0)
        if len(parts) != 4 or any(part < 0 for part in parts):
            fail("JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION")
        minimum = (10, 3, 0, 0)
        maximum = (11, 2, 0, 0)
        version_tuple = tuple(parts[:4])
        if not (minimum <= version_tuple < maximum):
            fail("JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION")
        if not isinstance(decrypt_helper, str) or not decrypt_helper.strip():
            fail("JY_TEMPLATE_DECRYPT_HELPER_MISSING")
        if not isinstance(install_dir, str) or not install_dir.strip():
            fail("JY_TEMPLATE_DECRYPT_INSTALL_MISSING")
        helper = Path(decrypt_helper)
        install = Path(install_dir)
        if not helper.is_file() or not (install / "videoeditor.dll").is_file():
            fail("JY_TEMPLATE_DECRYPT_INSTALL_MISSING")
        import tempfile

        with tempfile.TemporaryDirectory(prefix="openvideo-jy-fallback-") as temporary:
            encrypted = Path(temporary) / "draft_content.enc"
            plaintext = Path(temporary) / "draft_content.json"
            encrypted.write_bytes(raw_data)
            completed = subprocess.run(
                [
                    str(helper),
                    "--install-dir",
                    str(install),
                    "--decrypt",
                    str(encrypted),
                    str(plaintext),
                ],
                capture_output=True,
                timeout=60,
                check=False,
            )
            if completed.returncode != 0 or not plaintext.is_file():
                fail(
                    "JY_TEMPLATE_DECRYPT_FAILED",
                    {"stage": "fallback_decrypt", "exception_type": "CalledProcessError"},
                )
            text = plaintext.read_text(encoding="utf-8")
            if not text.lstrip().startswith("{"):
                fail(
                    "JY_TEMPLATE_DECRYPT_FAILED",
                    {"stage": "fallback_decrypt", "exception_type": "InvalidPlaintext"},
                )
            return text

    try:
        content = load_draft_content(
            str(draft_folder / "draft_content.json"),
            fallback_loader=fallback_loader
            if isinstance(decrypt_helper, str) and decrypt_helper.strip()
            else None,
        )
    except SystemExit:
        raise
    except DraftContentLoadFailed:
        fail("JY_TEMPLATE_FALLBACK_REQUIRED")
    except Exception as exc:
        fail(
            "JY_TEMPLATE_READ_FAILED",
            {"stage": "load_template", "exception_type": type(exc).__name__},
        )
    canvas = content.get("canvas_config")
    duration = content.get("duration")
    if (
        not isinstance(canvas, dict)
        or not isinstance(canvas.get("width"), int)
        or canvas["width"] <= 0
        or not isinstance(canvas.get("height"), int)
        or canvas["height"] <= 0
        or not isinstance(duration, int)
        or duration <= 0
    ):
        fail("JY_TEMPLATE_STRUCTURE_INVALID")
    platform = content.get("platform")
    app_version = (
        platform.get("app_version")
        if isinstance(platform, dict) and isinstance(platform.get("app_version"), str)
        else None
    )
    emit(
        {
            "ok": True,
            "content": {
                "duration": duration,
                "canvas_config": {
                    "width": canvas["width"],
                    "height": canvas["height"],
                },
                "platform": {"app_version": app_version},
                "materials": sanitize_materials(content),
                "tracks": sanitize_tracks(content),
            },
        }
    )


def main():
    payload = load_payload()
    if payload.get("action") == "inspect":
        inspect(payload)
        return
    fail("JY_TEMPLATE_INPUT_INVALID")


if __name__ == "__main__":
    main()
