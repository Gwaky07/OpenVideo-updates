import { isAbsolute } from 'node:path'

const statusKeys = new Set(['available', 'state', 'code', 'provider', 'commit', 'license'])
const requestKeys = new Set([
  'projectId',
  'jobId',
  'outputDurationSeconds',
  'outputSize',
  'script',
  'voiceover',
  'captions',
  'bgmPath',
  'clips',
])
const requestKeysWithBgmVolume = new Set([...requestKeys, 'bgmVolume'])
const requestKeysWithTemplateGuidance = new Set([...requestKeys, 'templateGuidance'])
const requestKeysWithTemplateGuidanceAndBgmVolume = new Set([
  ...requestKeysWithBgmVolume,
  'templateGuidance',
])
const clipKeys = new Set(['candidateId', 'sourcePath', 'start', 'end'])
const resultKeys = new Set(['resourceId', 'durationSeconds', 'provider', 'features'])
const legacyVoiceoverKeys = new Set(['enabled', 'rate', 'voice'])
const voiceoverKeys = new Set(['audioPath', 'assetId', 'enabled', 'rate', 'voice'])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {Record<string, any>} value @param {Set<string>} keys */
const hasExactKeys = (value, keys) =>
  Object.keys(value).length === keys.size && Object.keys(value).every((key) => keys.has(key))
/** @param {unknown} value @param {number} maximum */
const identifier = (value, maximum = 200) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maximum &&
  !value.includes('\u0000') &&
  !value.includes('\\') &&
  !value.includes('/') &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value)
/** @param {unknown} value @param {number} maximum */
const text = (value, maximum) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maximum &&
  !value.includes('\u0000')
/** @param {unknown} value */
const positiveFinite = (value) => typeof value === 'number' && Number.isFinite(value) && value > 0
/** @param {unknown} value */
const sha = (value) => typeof value === 'string' && /^[a-f0-9]{40}$/u.test(value)
/** @param {unknown} value */
const validTemplateGuidance = (value) => {
  if (value === null) return true
  if (
    !isRecord(value) ||
    value.schemaVersion !== 1 ||
    value.source !== 'project_template_binding' ||
    !identifier(value.libraryTemplateId) ||
    !Number.isSafeInteger(value.revision) ||
    value.revision < 1 ||
    typeof value.fingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.fingerprint) ||
    !Number.isSafeInteger(value.targetDurationMs) ||
    value.targetDurationMs < 1_000 ||
    value.targetDurationMs > 180_000 ||
    !['calm', 'balanced', 'dynamic'].includes(value.pacing) ||
    !Array.isArray(value.slots) ||
    value.slots.length < 1 ||
    !isRecord(value.rules)
  ) return false
  return value.slots.every((slot, index) =>
    isRecord(slot) &&
    slot.order === index + 1 &&
    identifier(slot.role, 80) &&
    Number.isSafeInteger(slot.recommendedDurationMs) &&
    slot.recommendedDurationMs > 0 &&
    identifier(slot.transitionOut, 80))
}

export const shortVideoFactoryErrorCodes = Object.freeze({
  unavailable: 'SHORT_VIDEO_FACTORY_UNAVAILABLE',
  integrityMismatch: 'SHORT_VIDEO_FACTORY_INTEGRITY_MISMATCH',
  inputInvalid: 'SHORT_VIDEO_FACTORY_INPUT_INVALID',
  processFailed: 'SHORT_VIDEO_FACTORY_PROCESS_FAILED',
  bridgeFailed: 'SHORT_VIDEO_FACTORY_BRIDGE_FAILED',
  timedOut: 'SHORT_VIDEO_FACTORY_TIMED_OUT',
  ttsFailed: 'SHORT_VIDEO_FACTORY_TTS_FAILED',
  renderFailed: 'SHORT_VIDEO_FACTORY_RENDER_FAILED',
  outputInvalid: 'SHORT_VIDEO_FACTORY_OUTPUT_INVALID',
  cancelled: 'SHORT_VIDEO_FACTORY_CANCELLED',
  // A sentence's narration is longer than the scene picked for it, and shots are
  // never looped or extended past their scene, so the render cannot be honest.
  materialDurationInsufficient: 'SHORT_VIDEO_FACTORY_MATERIAL_DURATION_INSUFFICIENT',
  // Narration for the whole script exceeds the 180s upstream render ceiling.
  scriptTooLong: 'SHORT_VIDEO_FACTORY_SCRIPT_TOO_LONG',
})

/** @param {unknown} value */
export const validShortVideoFactoryStatus = (value) =>
  isRecord(value) &&
  hasExactKeys(value, statusKeys) &&
  typeof value.available === 'boolean' &&
  (value.state === 'ready' || value.state === 'blocked') &&
  (value.code === null || identifier(value.code, 160)) &&
  value.provider === 'short-video-factory' &&
  sha(value.commit) &&
  value.license === 'AGPL-3.0'

/** @param {unknown} value */
export const validShortVideoFactoryRequest = (value) =>
  isRecord(value) &&
  (
    hasExactKeys(value, requestKeys) ||
    hasExactKeys(value, requestKeysWithBgmVolume) ||
    hasExactKeys(value, requestKeysWithTemplateGuidance) ||
    hasExactKeys(value, requestKeysWithTemplateGuidanceAndBgmVolume)
  ) &&
  identifier(value.projectId) &&
  identifier(value.jobId) &&
  positiveFinite(value.outputDurationSeconds) &&
  value.outputDurationSeconds <= 180 &&
  isRecord(value.outputSize) &&
  hasExactKeys(value.outputSize, new Set(['width', 'height'])) &&
  Number.isSafeInteger(value.outputSize.width) &&
  Number.isSafeInteger(value.outputSize.height) &&
  value.outputSize.width >= 320 &&
  value.outputSize.height >= 320 &&
  value.outputSize.width <= 3840 &&
  value.outputSize.height <= 3840 &&
  value.outputSize.width % 2 === 0 &&
  value.outputSize.height % 2 === 0 &&
  text(value.script, 8000) &&
  isRecord(value.voiceover) &&
  (hasExactKeys(value.voiceover, legacyVoiceoverKeys) || hasExactKeys(value.voiceover, voiceoverKeys)) &&
  typeof value.voiceover.enabled === 'boolean' &&
  (
    value.voiceover.enabled
      ? (
          (
            identifier(value.voiceover.voice) &&
            (value.voiceover.audioPath === undefined || value.voiceover.audioPath === null) &&
            (value.voiceover.assetId === undefined || value.voiceover.assetId === null)
          ) ||
          (
            value.voiceover.voice === null &&
            typeof value.voiceover.audioPath === 'string' &&
            isAbsolute(value.voiceover.audioPath) &&
            !value.voiceover.audioPath.includes('\u0000') &&
            identifier(value.voiceover.assetId)
          )
        )
      : value.voiceover.voice === null &&
        (value.voiceover.audioPath === undefined || value.voiceover.audioPath === null) &&
        (value.voiceover.assetId === undefined || value.voiceover.assetId === null)
  ) &&
  Number.isSafeInteger(value.voiceover.rate) &&
  value.voiceover.rate >= -100 &&
  value.voiceover.rate <= 100 &&
  isRecord(value.captions) &&
  hasExactKeys(value.captions, new Set(['enabled'])) &&
  typeof value.captions.enabled === 'boolean' &&
  (value.bgmPath === null ||
    (typeof value.bgmPath === 'string' && isAbsolute(value.bgmPath) && !value.bgmPath.includes('\u0000'))) &&
  (value.bgmVolume === undefined ||
    (typeof value.bgmVolume === 'number' && Number.isFinite(value.bgmVolume) && value.bgmVolume >= 0 && value.bgmVolume <= 1)) &&
  (value.templateGuidance === undefined || validTemplateGuidance(value.templateGuidance)) &&
  Array.isArray(value.clips) &&
  value.clips.length > 0 &&
  value.clips.length <= 30 &&
  value.clips.every((clip) =>
    isRecord(clip) &&
    hasExactKeys(clip, clipKeys) &&
    identifier(clip.candidateId) &&
    typeof clip.sourcePath === 'string' &&
    isAbsolute(clip.sourcePath) &&
    !clip.sourcePath.includes('\u0000') &&
    typeof clip.start === 'number' &&
    Number.isFinite(clip.start) &&
    clip.start >= 0 &&
    positiveFinite(clip.end) &&
    clip.end > clip.start)

/** @param {unknown} value */
export const validShortVideoFactoryResult = (value) =>
  isRecord(value) &&
  hasExactKeys(value, resultKeys) &&
  identifier(value.resourceId) &&
  positiveFinite(value.durationSeconds) &&
  value.durationSeconds <= 180 &&
  ['short-video-factory', 'short-video-factory+openvideo-bgm-mixer'].includes(value.provider) &&
  isRecord(value.features) &&
  hasExactKeys(value.features, new Set(['voiceover', 'captions', 'bgm'])) &&
  Object.values(value.features).every((enabled) => typeof enabled === 'boolean')
