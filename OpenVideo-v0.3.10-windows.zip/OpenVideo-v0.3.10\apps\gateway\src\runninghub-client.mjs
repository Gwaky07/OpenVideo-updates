import { createWriteStream } from 'node:fs'
import { readFile, rename, rm, stat } from 'node:fs/promises'
import { lookup as dnsLookup } from 'node:dns/promises'
import { basename } from 'node:path'
import { Readable, Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { setTimeout as delay } from 'node:timers/promises'

const maxReferenceBytes = 10 * 1024 * 1024
const maxOutputBytes = 100 * 1024 * 1024
const terminalStatuses = new Set(['SUCCESS', 'FAILED'])
const activeStatuses = new Set(['QUEUED', 'RUNNING'])
const identifierPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,179}$/u

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const identifier = (value) => typeof value === 'string' && identifierPattern.test(value)

export class RunningHubClientError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 502) {
    super(code)
    this.name = 'RunningHubClientError'
    this.code = code
    this.status = status
  }
}

/** @param {string} address */
const blockedIpv4 = (address) => {
  const parts = address.split('.').map((value) => Number.parseInt(value, 10))
  if (parts.length !== 4 || parts.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) return true
  const [first, second] = parts
  return (
    first === 0 ||
    first === 10 ||
    first === 127 ||
    (first === 100 && second >= 64 && second <= 127) ||
    (first === 169 && second === 254) ||
    (first === 172 && second >= 16 && second <= 31) ||
    (first === 192 && [0, 168].includes(second)) ||
    (first === 198 && [18, 19].includes(second)) ||
    first >= 224
  )
}

/** @param {string} address */
const blockedAddress = (address) => {
  const normalized = address.toLowerCase()
  if (normalized.includes('.')) {
    return blockedIpv4(normalized.replace(/^::ffff:/u, ''))
  }
  return (
    normalized === '::' ||
    normalized === '::1' ||
    normalized.startsWith('fc') ||
    normalized.startsWith('fd') ||
    /^fe[89ab]/u.test(normalized)
  )
}

/** @param {unknown} value */
const outputUrl = (value) => {
  if (!isRecord(value)) return null
  const direct = [value.fileUrl, value.file_url, value.url].find((entry) => typeof entry === 'string')
  return typeof direct === 'string' ? direct : null
}

/** @param {unknown} value */
const responseData = (value) => {
  if (!isRecord(value) || !('code' in value)) {
    throw new RunningHubClientError('RUNNINGHUB_RESPONSE_INVALID')
  }
  if (![0, 200].includes(Number(value.code))) {
    const numericCode = Number(value.code)
    const authenticationFailed = [412, 802, 806, 1002].includes(numericCode)
    throw new RunningHubClientError(
      authenticationFailed
        ? 'RUNNINGHUB_AUTHENTICATION_FAILED'
        : numericCode === 416
          ? 'RUNNINGHUB_BALANCE_INSUFFICIENT'
          : numericCode === 421
            ? 'RUNNINGHUB_RATE_LIMITED'
            : 'RUNNINGHUB_REQUEST_FAILED',
      authenticationFailed ? 401 : numericCode === 416 ? 402 : numericCode === 421 ? 429 : 502,
    )
  }
  if (!('data' in value)) throw new RunningHubClientError('RUNNINGHUB_RESPONSE_INVALID')
  return value.data
}

/** @param {unknown} value */
const responsePayload = (value) => isRecord(value) && 'code' in value ? responseData(value) : value

/** @param {Response} response */
const parseJson = async (response) => {
  let value
  try {
    value = await response.json()
  } catch {
    throw new RunningHubClientError('RUNNINGHUB_RESPONSE_INVALID')
  }
  if (!response.ok) {
    throw new RunningHubClientError(
      response.status === 401 || response.status === 403
        ? 'RUNNINGHUB_AUTHENTICATION_FAILED'
        : response.status === 429
          ? 'RUNNINGHUB_RATE_LIMITED'
          : 'RUNNINGHUB_REQUEST_FAILED',
      response.status === 429 ? 429 : 502,
    )
  }
  return value
}

/**
 * @param {{
 *   settings: Record<string, any>,
 *   fetcher?: typeof fetch,
 *   lookup?: typeof dnsLookup,
 *   wait?: typeof delay,
 *   pollIntervalMs?: number,
 *   requestTimeoutMs?: number,
 * }} input
 */
export const createRunningHubClient = ({
  settings,
  fetcher = fetch,
  lookup = dnsLookup,
  wait = delay,
  pollIntervalMs = 2_000,
  requestTimeoutMs = 60_000,
}) => {
  if (
    !isRecord(settings) ||
    typeof settings.baseUrl !== 'string' ||
    !settings.baseUrl.startsWith('https://') ||
    typeof settings.apiKey !== 'string' ||
    !settings.apiKey ||
    !['voice_clone_v3', 'workflow'].includes(settings.mode)
  ) throw new RunningHubClientError('RUNNINGHUB_CONFIGURATION_REQUIRED', 409)

  /** @param {string} path @param {RequestInit} [init] */
  const requestJson = async (path, init = {}) => {
    const signal = init.signal
      ? AbortSignal.any([init.signal, AbortSignal.timeout(requestTimeoutMs)])
      : AbortSignal.timeout(requestTimeoutMs)
    try {
      return await parseJson(await fetcher(`${settings.baseUrl}${path}`, {
        ...init,
        signal,
      }))
    } catch (error) {
      if (error instanceof RunningHubClientError) throw error
      if (init.signal?.aborted) throw error
      if (signal.aborted) throw new RunningHubClientError('RUNNINGHUB_REQUEST_TIMED_OUT', 504)
      throw new RunningHubClientError('RUNNINGHUB_REQUEST_FAILED')
    }
  }

  /** @param {string} value */
  const assertPublicUrl = async (value) => {
    let parsed
    try {
      parsed = new URL(value)
    } catch {
      throw new RunningHubClientError('RUNNINGHUB_OUTPUT_URL_INVALID')
    }
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password) {
      throw new RunningHubClientError('RUNNINGHUB_OUTPUT_URL_INVALID')
    }
    if (['localhost', 'localhost.localdomain'].includes(parsed.hostname.toLowerCase())) {
      throw new RunningHubClientError('RUNNINGHUB_OUTPUT_URL_INVALID')
    }
    let addresses
    try {
      addresses = await lookup(parsed.hostname, { all: true, verbatim: true })
    } catch {
      throw new RunningHubClientError('RUNNINGHUB_OUTPUT_URL_INVALID')
    }
    if (!Array.isArray(addresses) || addresses.length === 0 || addresses.some((entry) => blockedAddress(entry.address))) {
      throw new RunningHubClientError('RUNNINGHUB_OUTPUT_URL_INVALID')
    }
    return parsed
  }

  return {
    async probe() {
      // Official account probe: POST /uc/openapi/accountStatus with Bearer + body.apikey.
      // /openapi/v2/user/info/current is not a valid account endpoint and returns opaque V2 errors.
      const value = responseData(await requestJson('/uc/openapi/accountStatus', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${settings.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ apikey: settings.apiKey }),
      }))
      if (!isRecord(value)) throw new RunningHubClientError('RUNNINGHUB_RESPONSE_INVALID')
      const remainCoins = typeof value.remainCoins === 'string' || typeof value.remainCoins === 'number'
        ? Number(value.remainCoins)
        : Number.NaN
      const remainMoney = typeof value.remainMoney === 'string' || typeof value.remainMoney === 'number'
        ? String(value.remainMoney).slice(0, 64)
        : null
      return {
        schema_version: 1,
        provider: 'runninghub',
        reachable: true,
        currentBalance: Number.isFinite(remainCoins) ? remainCoins : null,
        realTimeUsdBalance: remainMoney,
      }
    },
    /** @param {string} path @param {AbortSignal} [signal] */
    async uploadReference(path, signal) {
      const metadata = await stat(path).catch(() => null)
      if (!metadata?.isFile() || metadata.size <= 0 || metadata.size > maxReferenceBytes) {
        throw new RunningHubClientError('RUNNINGHUB_REFERENCE_AUDIO_INVALID', 400)
      }
      const form = new FormData()
      form.set('file', new Blob([await readFile(path)]), basename(path))
      const value = responseData(await requestJson('/openapi/v2/media/upload/binary', {
        method: 'POST',
        headers: { Authorization: `Bearer ${settings.apiKey}` },
        body: form,
        signal,
      }))
      const fileName = isRecord(value) && typeof value.fileName === 'string'
        ? value.fileName
        : isRecord(value) && typeof value.filename === 'string'
          ? value.filename
          : null
      if (!isRecord(value) || typeof value.download_url !== 'string' || !fileName) {
        throw new RunningHubClientError('RUNNINGHUB_UPLOAD_RESPONSE_INVALID')
      }
      await assertPublicUrl(value.download_url)
      return { downloadUrl: value.download_url, fileName }
    },
    /** @param {{text: string, reference: {downloadUrl: string, fileName: string}, voiceId: string, signal?: AbortSignal}} input */
    async submitSynthesis(input) {
      if (
        typeof input?.text !== 'string' ||
        input.text.trim().length === 0 ||
        input.text.length > 20_000 ||
        !identifier(input.voiceId)
      ) throw new RunningHubClientError('RUNNINGHUB_SYNTHESIS_INPUT_INVALID', 400)
      let value
      if (settings.mode === 'voice_clone_v3') {
        value = responsePayload(await requestJson(
          '/openapi/v2/rhart-audio/text-to-audio/voice-clone',
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${settings.apiKey}`,
              'content-type': 'application/json',
            },
            body: JSON.stringify({
              audio: input.reference.downloadUrl,
              custom_voice_id: input.voiceId,
              text: input.text,
              accuracy: 0.7,
              need_noise_reduction: false,
              need_volume_normalization: false,
              model: settings.modelId,
            }),
            signal: input.signal,
          },
        ))
      } else {
        value = responsePayload(await requestJson('/task/openapi/create', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${settings.apiKey}`,
            'content-type': 'application/json',
          },
          body: JSON.stringify({
            apiKey: settings.apiKey,
            workflowId: settings.workflowId,
            nodeInfoList: [
              {
                nodeId: settings.textNodeId,
                fieldName: settings.textFieldName,
                fieldValue: input.text,
              },
              {
                nodeId: settings.audioNodeId,
                fieldName: settings.audioFieldName,
                fieldValue: input.reference.fileName,
              },
            ],
          }),
          signal: input.signal,
        }))
      }
      const taskId = isRecord(value) ? value.taskId : null
      if (!identifier(taskId)) {
        const providerErrorCode = isRecord(value) && (typeof value.errorCode === 'string' || typeof value.errorCode === 'number')
          ? String(value.errorCode)
          : null
        if (providerErrorCode === '1014') {
          throw new RunningHubClientError('RUNNINGHUB_ENTERPRISE_KEY_REQUIRED', 403)
        }
        throw new RunningHubClientError(
          providerErrorCode ? 'RUNNINGHUB_REQUEST_FAILED' : 'RUNNINGHUB_TASK_RESPONSE_INVALID',
        )
      }
      return { taskId }
    },
    /** @param {string} taskId @param {AbortSignal} [signal] */
    async query(taskId, signal) {
      if (!identifier(taskId)) throw new RunningHubClientError('RUNNINGHUB_TASK_ID_INVALID', 400)
      const data = responsePayload(await requestJson('/openapi/v2/query', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${settings.apiKey}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({ taskId }),
        signal,
      }))
      if (!isRecord(data) || !['QUEUED', 'RUNNING', 'SUCCESS', 'FAILED'].includes(data.status)) {
        throw new RunningHubClientError('RUNNINGHUB_TASK_RESPONSE_INVALID')
      }
      const results = Array.isArray(data.results) ? data.results : []
      return {
        status: data.status,
        errorCode: typeof data.errorCode === 'string' ? data.errorCode.slice(0, 120) : null,
        errorMessage: typeof data.errorMessage === 'string' ? data.errorMessage.slice(0, 500) : null,
        results,
      }
    },
    /** @param {string} taskId */
    async cancel(taskId) {
      if (!identifier(taskId)) return false
      try {
        const value = await requestJson('/task/openapi/cancel', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${settings.apiKey}`,
            'content-type': 'application/json',
          },
          body: JSON.stringify({ apiKey: settings.apiKey, taskId }),
        })
        return isRecord(value) && value.code === 0
      } catch {
        return false
      }
    },
    /** @param {string} taskId @param {{signal?: AbortSignal, onStatus?: (status: string) => unknown, timeoutMs?: number}} [options] */
    async waitForResult(taskId, { signal, onStatus, timeoutMs = 30 * 60_000 } = {}) {
      const deadline = Date.now() + timeoutMs
      while (Date.now() < deadline) {
        signal?.throwIfAborted()
        const state = await this.query(taskId, signal)
        onStatus?.(state.status)
        if (terminalStatuses.has(state.status)) {
          if (state.status === 'FAILED') throw new RunningHubClientError('RUNNINGHUB_TASK_FAILED')
          const url = state.results.map(outputUrl).find(Boolean)
          if (!url) throw new RunningHubClientError('RUNNINGHUB_AUDIO_OUTPUT_MISSING')
          await assertPublicUrl(url)
          return { url, results: state.results }
        }
        if (!activeStatuses.has(state.status)) throw new RunningHubClientError('RUNNINGHUB_TASK_RESPONSE_INVALID')
        await wait(pollIntervalMs, undefined, { signal })
      }
      throw new RunningHubClientError('RUNNINGHUB_TASK_TIMED_OUT', 504)
    },
    /** @param {string} url @param {string} outputPath @param {AbortSignal} [signal] */
    async download(url, outputPath, signal) {
      let current = await assertPublicUrl(url)
      let response
      for (let redirects = 0; redirects <= 3; redirects += 1) {
        response = await fetcher(current, {
          method: 'GET',
          redirect: 'manual',
          signal,
        })
        if ([301, 302, 303, 307, 308].includes(response.status)) {
          const location = response.headers.get('location')
          if (!location) throw new RunningHubClientError('RUNNINGHUB_DOWNLOAD_FAILED')
          current = await assertPublicUrl(new URL(location, current).toString())
          continue
        }
        break
      }
      if (!response?.ok || !response.body) throw new RunningHubClientError('RUNNINGHUB_DOWNLOAD_FAILED')
      const declaredBytes = Number(response.headers.get('content-length'))
      if (Number.isFinite(declaredBytes) && declaredBytes > maxOutputBytes) {
        throw new RunningHubClientError('RUNNINGHUB_AUDIO_OUTPUT_TOO_LARGE')
      }
      const temporaryPath = `${outputPath}.download`
      let receivedBytes = 0
      const limiter = new Transform({
        transform(chunk, _encoding, callback) {
          receivedBytes += chunk.length
          callback(
            receivedBytes > maxOutputBytes
              ? new RunningHubClientError('RUNNINGHUB_AUDIO_OUTPUT_TOO_LARGE')
              : null,
            chunk,
          )
        },
      })
      try {
        await pipeline(
          Readable.from(/** @type {AsyncIterable<Uint8Array>} */ (response.body)),
          limiter,
          createWriteStream(temporaryPath, { flags: 'wx', mode: 0o600 }),
        )
        const metadata = await stat(temporaryPath)
        if (!metadata.isFile() || metadata.size === 0) throw new RunningHubClientError('RUNNINGHUB_AUDIO_OUTPUT_MISSING')
        await rename(temporaryPath, outputPath)
        return { bytes: metadata.size }
      } finally {
        await rm(temporaryPath, { force: true }).catch(() => {})
      }
    },
  }
}
