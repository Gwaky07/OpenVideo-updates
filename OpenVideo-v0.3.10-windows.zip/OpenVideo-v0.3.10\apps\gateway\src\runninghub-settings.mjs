import { randomUUID } from 'node:crypto'
import { copyFile, lstat, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve } from 'node:path'

import {
  protectSecretWithDpapi,
  unprotectSecretWithDpapi,
} from './llm-settings.mjs'
import { RunningHubClientError } from './runninghub-client.mjs'

const schemaVersion = 1
const defaultBaseUrl = 'https://www.runninghub.cn'
const defaultModelId = 'speech-2.6-hd'
const allowedVoiceModels = new Set([
  'speech-02-hd',
  'speech-02-turbo',
  'speech-2.6-hd',
  'speech-2.6-turbo',
])
const allowedBaseUrls = new Set([
  'https://www.runninghub.cn',
  'https://www.runninghub.ai',
])
const inputKeys = [
  'apiKey',
  'audioFieldName',
  'audioNodeId',
  'baseUrl',
  'mode',
  'modelId',
  'textFieldName',
  'textNodeId',
  'workflowId',
]
const identifierPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u
const fieldPattern = /^[A-Za-z_][A-Za-z0-9_.-]{0,79}$/u

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}
/** @param {unknown} value @param {RegExp} pattern */
const normalizedIdentifier = (value, pattern) =>
  typeof value === 'string' && value.trim() === value && pattern.test(value)
    ? value
    : null

export class RunningHubSettingsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'RunningHubSettingsError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value */
const normalizedBaseUrl = (value) => {
  if (typeof value !== 'string' || value.trim() !== value) return null
  const normalized = value.replace(/\/+$/u, '')
  return allowedBaseUrls.has(normalized) ? normalized : null
}

/** @param {unknown} input @param {boolean} apiKeyOptional */
const validateInput = (input, apiKeyOptional) => {
  if (
    !isRecord(input) ||
    Object.keys(input).sort().join('\u0000') !== [...inputKeys].sort().join('\u0000')
  ) throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_INVALID')
  const apiKey = typeof input.apiKey === 'string' ? input.apiKey.trim() : ''
  if ((!apiKeyOptional && !apiKey) || apiKey.length > 512) {
    throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_API_KEY_INVALID')
  }
  const baseUrl = normalizedBaseUrl(input.baseUrl)
  const mode = input.mode === 'workflow' ? 'workflow' : input.mode === 'voice_clone_v3' ? 'voice_clone_v3' : null
  const modelId = normalizedIdentifier(input.modelId, identifierPattern)
  if (!baseUrl || !mode || !modelId || !allowedVoiceModels.has(modelId)) {
    throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_INVALID')
  }
  const workflowId = input.workflowId === '' ? '' : normalizedIdentifier(input.workflowId, identifierPattern)
  const textNodeId = input.textNodeId === '' ? '' : normalizedIdentifier(input.textNodeId, identifierPattern)
  const audioNodeId = input.audioNodeId === '' ? '' : normalizedIdentifier(input.audioNodeId, identifierPattern)
  const textFieldName = input.textFieldName === '' ? '' : normalizedIdentifier(input.textFieldName, fieldPattern)
  const audioFieldName = input.audioFieldName === '' ? '' : normalizedIdentifier(input.audioFieldName, fieldPattern)
  if (
    workflowId === null ||
    textNodeId === null ||
    audioNodeId === null ||
    textFieldName === null ||
    audioFieldName === null ||
    (mode === 'workflow' && !workflowId) ||
    (mode === 'workflow' && !textNodeId) ||
    (mode === 'workflow' && !audioNodeId) ||
    (mode === 'workflow' && !textFieldName) ||
    (mode === 'workflow' && !audioFieldName)
  ) throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_WORKFLOW_INVALID')
  return {
    apiKey,
    baseUrl,
    mode,
    modelId,
    workflowId,
    textNodeId,
    textFieldName,
    audioNodeId,
    audioFieldName,
  }
}

const emptyDocument = () => ({
  schema_version: schemaVersion,
  revision: null,
  provider: 'runninghub',
  base_url: defaultBaseUrl,
  // Product default is custom workflow (IndexTTS2). Official MiniMax V3 remains
  // readable for legacy private configs but is no longer offered in settings UI.
  mode: 'workflow',
  model_id: defaultModelId,
  workflow_id: '',
  text_node_id: '',
  text_field_name: 'text',
  audio_node_id: '',
  audio_field_name: 'audio',
  api_key_dpapi: null,
})

/** @param {Record<string, unknown>} document */
const hasStoredApiKey = (document) =>
  typeof document.revision === 'string' &&
  typeof document.api_key_dpapi === 'string' &&
  document.api_key_dpapi.length > 0

/** @param {unknown} value */
const validDocument = (value) => {
  if (!isRecord(value)) return false
  return (
    value.schema_version === schemaVersion &&
    (value.revision === null || Boolean(normalizedIdentifier(value.revision, identifierPattern))) &&
    value.provider === 'runninghub' &&
    Boolean(normalizedBaseUrl(value.base_url)) &&
    ['voice_clone_v3', 'workflow'].includes(String(value.mode)) &&
    Boolean(normalizedIdentifier(value.model_id, identifierPattern)) &&
    allowedVoiceModels.has(String(value.model_id)) &&
    typeof value.workflow_id === 'string' && value.workflow_id.length <= 128 &&
    typeof value.text_node_id === 'string' && value.text_node_id.length <= 128 &&
    typeof value.text_field_name === 'string' && value.text_field_name.length <= 80 &&
    typeof value.audio_node_id === 'string' && value.audio_node_id.length <= 128 &&
    typeof value.audio_field_name === 'string' && value.audio_field_name.length <= 80 &&
    (value.api_key_dpapi === null ||
      (typeof value.api_key_dpapi === 'string' && value.api_key_dpapi.length <= 16_384))
  )
}

/** @param {unknown} error */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error
  ? String(error.code)
  : null

/** @param {string} path */
const readDocumentFile = async (path) => {
  const parsed = JSON.parse(await readFile(path, 'utf8'))
  if (!validDocument(parsed)) throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_INVALID', 500)
  return parsed
}

/** @param {string} path @param {Record<string, unknown>} document @param {{preservePrimaryAsBackup?: boolean}} [options] */
const writeDocument = async (path, document, { preservePrimaryAsBackup = true } = {}) => {
  const temporaryPath = `${path}.${randomUUID()}.tmp`
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  await writeFile(temporaryPath, `${JSON.stringify(document, null, 2)}\n`, {
    encoding: 'utf8',
    flag: 'wx',
    mode: 0o600,
  })
  try {
    if (preservePrimaryAsBackup) {
      await copyFile(path, `${path}.bak`).catch((error) => {
        if (errorCode(error) !== 'ENOENT') throw error
      })
    }
    await rename(temporaryPath, path)
    await copyFile(path, `${path}.bak`).catch(() => {})
  } finally {
    await rm(temporaryPath, { force: true })
  }
}

/** @param {string} path */
const readDocument = async (path) => {
  try {
    return await readDocumentFile(path)
  } catch (primaryError) {
    try {
      const backup = await readDocumentFile(`${path}.bak`)
      await writeDocument(path, backup, { preservePrimaryAsBackup: false })
      return backup
    } catch (backupError) {
      if (errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') {
        return emptyDocument()
      }
      throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_INVALID', 500)
    }
  }
}

/** @param {Record<string, unknown>} document @param {boolean} apiKeySaved */
const publicDocument = (document, apiKeySaved) => ({
  schema_version: schemaVersion,
  revision: document.revision,
  configured: apiKeySaved && (
    document.mode === 'voice_clone_v3' ||
    Boolean(
      document.workflow_id &&
      document.text_node_id &&
      document.text_field_name &&
      document.audio_node_id &&
      document.audio_field_name,
    )
  ),
  provider: 'runninghub',
  baseUrl: document.base_url,
  mode: document.mode,
  modelId: document.model_id,
  workflowId: document.workflow_id,
  textNodeId: document.text_node_id,
  textFieldName: document.text_field_name,
  audioNodeId: document.audio_node_id,
  audioFieldName: document.audio_field_name,
  apiKeySaved,
})

/**
 * @param {{
 *   settingsPath: string,
 *   privateConfigRoot: string,
 *   protectSecret?: typeof protectSecretWithDpapi,
 *   unprotectSecret?: typeof unprotectSecretWithDpapi,
 * }} input
 */
export const createRunningHubSettingsService = ({
  settingsPath,
  privateConfigRoot,
  protectSecret = protectSecretWithDpapi,
  unprotectSecret = unprotectSecretWithDpapi,
}) => {
  if (!isAbsolute(settingsPath) || !isAbsolute(privateConfigRoot)) {
    throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_INVALID', 500)
  }
  const resolvedRoot = resolve(privateConfigRoot)
  const resolvedPath = resolve(settingsPath)
  if (!inside(resolvedRoot, resolvedPath) || resolvedRoot === resolvedPath) {
    throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_INVALID', 500)
  }
  let serialization = Promise.resolve()
  /** @template T @param {() => Promise<T>} operation */
  const runSerialized = (operation) => {
    const result = serialization.then(operation, operation)
    serialization = result.then(() => {}, () => {})
    return result
  }
  const ensureStorage = async () => {
    await mkdir(resolvedRoot, { recursive: true, mode: 0o700 })
    for (const path of [resolvedRoot, resolvedPath]) {
      try {
        if ((await lstat(path)).isSymbolicLink()) {
          throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_INVALID', 500)
        }
      } catch (error) {
        if (error instanceof RunningHubSettingsError) throw error
        if (!error || typeof error !== 'object' || !('code' in error) || error.code !== 'ENOENT') {
          throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_INVALID', 500)
        }
      }
    }
  }
  /** @param {Record<string, unknown>} document */
  const readSecret = async (document) => {
    if (typeof document.api_key_dpapi !== 'string' || typeof document.revision !== 'string') return null
    try {
      return await unprotectSecret({
        protectedSecret: document.api_key_dpapi,
        revision: document.revision,
      })
    } catch {
      throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_DPAPI_FAILED', 500)
    }
  }
  return {
    readPublic() {
      return runSerialized(async () => {
        await ensureStorage()
        const document = await readDocument(resolvedPath)
        // Public GET must stay local-disk fast. DPAPI decrypt (PowerShell) is reserved
        // for private/save/test paths; ciphertext presence is enough for apiKeySaved.
        return publicDocument(document, hasStoredApiKey(document))
      })
    },
    readPrivate() {
      return runSerialized(async () => {
        await ensureStorage()
        const document = await readDocument(resolvedPath)
        const apiKey = await readSecret(document)
        if (!apiKey) throw new RunningHubSettingsError('RUNNINGHUB_CONFIGURATION_REQUIRED', 409)
        const value = publicDocument(document, true)
        if (!value.configured) throw new RunningHubSettingsError('RUNNINGHUB_CONFIGURATION_REQUIRED', 409)
        return { ...value, apiKey }
      })
    },
    /** @param {unknown} input */
    save(input) {
      return runSerialized(async () => {
        await ensureStorage()
        const current = await readDocument(resolvedPath)
        const currentSecret = await readSecret(current)
        const validated = validateInput(input, Boolean(currentSecret))
        const apiKey = validated.apiKey || currentSecret
        if (!apiKey) throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_API_KEY_INVALID')
        const revision = randomUUID()
        let protectedSecret
        try {
          protectedSecret = await protectSecret({ secret: apiKey, revision })
        } catch {
          throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_DPAPI_FAILED', 500)
        }
        const next = {
          schema_version: schemaVersion,
          revision,
          provider: 'runninghub',
          base_url: validated.baseUrl,
          mode: validated.mode,
          model_id: validated.modelId,
          workflow_id: validated.workflowId,
          text_node_id: validated.textNodeId,
          text_field_name: validated.textFieldName,
          audio_node_id: validated.audioNodeId,
          audio_field_name: validated.audioFieldName,
          api_key_dpapi: protectedSecret,
        }
        try {
          await writeDocument(resolvedPath, next)
        } catch {
          throw new RunningHubSettingsError('RUNNINGHUB_SETTINGS_STORAGE_WRITE_FAILED', 500)
        }
        return publicDocument(next, true)
      })
    },
  }
}

/** @param {unknown} body @param {number} [status] */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  },
})

/**
 * @param {{
 *   service: ReturnType<typeof createRunningHubSettingsService>,
 *   probe: (settings: Record<string, any>) => Promise<Record<string, unknown>>,
 * }} input
 */
export const createRunningHubSettingsHandler = ({ service, probe }) => async (/** @type {Request} */ request) => {
  const pathname = new URL(request.url).pathname
  try {
    if (pathname === '/api/settings/runninghub' && request.method === 'GET') {
      return jsonResponse(await service.readPublic())
    }
    if (pathname === '/api/settings/runninghub' && request.method === 'PUT') {
      if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
        return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
      }
      return jsonResponse(await service.save(await request.json()), 200)
    }
    if (pathname === '/api/settings/runninghub/test' && request.method === 'POST') {
      return jsonResponse(await probe(await service.readPrivate()))
    }
    return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  } catch (error) {
    if (error instanceof RunningHubSettingsError) {
      return jsonResponse({
        error: { code: error.code, message: 'RunningHub settings operation failed safely.' },
      }, error.status)
    }
    if (error instanceof RunningHubClientError) {
      return jsonResponse({
        error: { code: error.code, message: 'RunningHub remote operation failed safely.' },
      }, error.status)
    }
    return jsonResponse({
      error: {
        code: 'RUNNINGHUB_SETTINGS_OPERATION_FAILED',
        message: 'RunningHub settings operation failed safely.',
      },
    }, 502)
  }
}
