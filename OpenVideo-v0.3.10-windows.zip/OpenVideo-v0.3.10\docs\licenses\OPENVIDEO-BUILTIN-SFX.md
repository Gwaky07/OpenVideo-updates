# OpenVideo Generated Starter SFX

OpenVideo generates its starter sound-effect pack at runtime from deterministic
PCM synthesis implemented in `apps/gateway/src/generated-sfx-library.mjs`.

- No third-party audio, Shotcraft media, recorded sample or downloaded asset is
  included or executed.
- The generated WAV files live only below `OPENVIDEO_RUNTIME_DATA_ROOT` and are
  not committed to Git.
- The pack provides one bounded starter sound for each approved semantic family:
  camera, foley, impact, riser, sparkle, text, transition and whoosh.
- Users may import additional authorized local sounds. Those files retain their
  project authorization and are never promoted to the global starter identity.

The generator and its output are part of OpenVideo's own product implementation.
