import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rename, rm, rmdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { parseJianyingAudioEffectCatalog, resolveJianyingAudioEffectToken } from '../apps/gateway/src/jianying-audio-effect-catalog.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY067_MANUAL_ATTESTATION_REQUIRED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy067-audio-effect')
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  const catalog = parseJianyingAudioEffectCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy064-audio-effect-catalog.json'), 'utf8')))
  const binding = resolveJianyingAudioEffectToken(catalog, pending.effect_token)
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop.profileId !== pending.profile_id || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root) || catalog.fingerprint !== pending.catalog_fingerprint) throw new Error('JY067_EVIDENCE_BINDING_INVALID')
  const mediaRoot = path.resolve(pending.media_root)
  const canonicalTemp = await realpath(tmpdir())
  const canonicalMedia = await realpath(mediaRoot)
  const mediaRelative = path.relative(canonicalTemp, canonicalMedia)
  const mediaMetadata = await lstat(mediaRoot)
  const owner = await readFile(path.join(mediaRoot, '.openvideo-jy067-owner'), 'utf8')
  if (!mediaRelative || mediaRelative.startsWith('..') || path.isAbsolute(mediaRelative) || !path.basename(canonicalMedia).startsWith('openvideo-jy067-audio-') || !mediaMetadata.isDirectory() || mediaMetadata.isSymbolicLink() || owner !== pending.media_owner) throw new Error('JY067_TEMP_OWNERSHIP_INVALID')
  const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy067-verify-'))
  try {
    const encryptedPath = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json')
    const encryptedBytes = await readFile(encryptedPath)
    const postSaveFingerprint = createHash('sha256').update(encryptedBytes).digest('hex')
    if (postSaveFingerprint === pending.pre_open_fingerprint) throw new Error('JY067_MANUAL_EDIT_NOT_PERSISTED')
    const plaintext = path.join(tempRoot, 'draft_content.json')
    const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(encryptedPath, plaintext)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY067_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plaintext, 'utf8'))
    const sfxTrack = content.tracks?.find((track) => track?.name === 'sfx-primary')
    const sfxSegment = sfxTrack?.segments?.find((segment) => (segment?.target_timerange?.start ?? 0) === 0 && segment?.target_timerange?.duration === 4_000_000)
    const audioEffects = content.materials?.audio_effects ?? []
    const matchingSfxSegments = (sfxTrack?.segments ?? []).filter((segment) => (segment?.target_timerange?.start ?? 0) === 0 && segment?.target_timerange?.duration === 4_000_000)
    const matches = audioEffects.filter((effect) => effect?.resource_id === binding.resourceId && sfxSegment?.extra_material_refs?.includes(effect.id))
    const referenceCount = content.tracks?.flatMap((track) => track?.segments ?? []).filter((segment) => matches[0] && segment?.extra_material_refs?.includes(matches[0].id)).length ?? 0
    const attachedAudioEffectRefs = (sfxSegment?.extra_material_refs ?? []).filter((reference) => audioEffects.some((effect) => effect?.id === reference))
    if (matchingSfxSegments.length !== 1 || audioEffects.length !== 1 || matches.length !== 1 || referenceCount !== 1 || attachedAudioEffectRefs.length !== 1) {
      throw Object.assign(new Error('JY067_AUDIO_EFFECT_PERSISTENCE_INVALID'), {
        diagnostic: {
          matchingSfxSegmentCount: matchingSfxSegments.length,
          audioEffectCount: audioEffects.length,
          matchingEffectCount: matches.length,
          referenceCount,
          attachedAudioEffectRefCount: attachedAudioEffectRefs.length,
          sfxRanges: (sfxTrack?.segments ?? []).map((segment) => ({ start: segment?.target_timerange?.start ?? null, duration: segment?.target_timerange?.duration ?? null })),
        },
      })
    }
    await rm(path.join(mediaRoot, 'video.mp4'), { force: true })
    await rm(path.join(mediaRoot, 'audio.wav'), { force: true })
    await rm(path.join(mediaRoot, '.openvideo-jy067-owner'), { force: true })
    await rmdir(mediaRoot)
    await rm(pendingPath, { force: true })
    const postSavePath = path.join(evidenceRoot, 'post-save.json')
    const stagedPostSavePath = path.join(evidenceRoot, 'post-save.pending.json')
    await writeFile(stagedPostSavePath, `${JSON.stringify({ schema_version: 1, manual_evidence_verified: true, manual_attestation: 'opened-edited-saved-reopened', profile_id: pending.profile_id, app_version: pending.app_version, catalog_fingerprint: pending.catalog_fingerprint, scheme: 'encrypt_v2', pre_open_fingerprint: pending.pre_open_fingerprint, post_save_fingerprint: postSaveFingerprint, opened: true, edited: true, saved: true, reopened: true, matching_effect_count: 1, attached: true, temporary_media_cleaned: true })}\n`, { encoding: 'utf8', mode: 0o600 })
    await rename(stagedPostSavePath, postSavePath)
    process.stdout.write(`${JSON.stringify({ ok: true, capability: 'audio.effect.named', scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, matchingEffectCount: 1, attached: true, temporaryMediaCleaned: true })}\n`)
  } finally { await rm(tempRoot, { recursive: true, force: true }) }
}

main().catch((error) => {
  process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY067_VERIFY_FAILED', ...(error?.diagnostic ? { diagnostic: error.diagnostic } : {}) })}\n`)
  process.exitCode = 1
})
