import { execFile as execFileCallback, spawn } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { link, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'

import {
  resolveDuoLocalJyResourceProbeBinding,
  fingerprintCanonicalJY200Draft,
  validateJY200ProbeArtifactTree,
  validateJY200ProbeStagingRoot,
} from '../apps/gateway/src/jianying-artist-effect-probe.mjs'
import {
  canonicalJY200DuoJson,
  createJY200DuoProbeExecutionReceipt,
  fingerprintJY200DuoExecutionDraft,
  fingerprintJY200DuoProductRuntime,
  fingerprintJY200DuoValue,
  parseJY200DuoProbeExecutionReceipt,
} from '../apps/gateway/src/jianying-duo-direct-probe-evidence.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { createJianyingPrivateDraftDecoder } from '../apps/gateway/src/jianying-private-draft-decoder.mjs'
import { createJsonRepositories } from '../apps/gateway/src/local-runtime.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import { readFileNoReparse } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { loadPackagingResourceEvidenceIntegrityKey } from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import {
  validateInstalledDuoWriterRuntime,
} from './Build-JY200DuoWriterRuntime.mjs'
import { inspectJY200DuoInstalledRuntime } from './Install-JY200DuoWriterRuntime.mjs'
import { validateJY200DuoPrivateJavaRuntime } from './JY200DuoPrivateJavaRuntime.mjs'

const execFile = promisify(execFileCallback)
const repositoryRoot = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const authorizationPattern = /^ovauth_[A-Za-z0-9_-]{8,160}$/u
const tokenPattern = /^ovj(?:sticker|flower|video_effect)_v1_[a-f0-9]{24}$/u
const draftNamePattern = /^OpenVideo-JY200-duo-direct-[0-9]{8}-[0-9]{6}$/u
const runtimeIdentity = (runtime) => canonicalJY200DuoJson({
  buildDigest: runtime.buildDigest,
  classpathEntries: [...runtime.classpathEntries],
})

const powershellExecutionLockSource = `
$ErrorActionPreference = 'Stop'
$handles = [System.Collections.Generic.List[System.IDisposable]]::new()
try {
  $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($env:OPENVIDEO_JY200_EXECUTION_ROOTS))
  $roots = [string[]](ConvertFrom-Json -InputObject $json)
  foreach ($rawRoot in $roots) {
    $root = [IO.Path]::GetFullPath([string]$rawRoot)
    $rootItem = Get-Item -LiteralPath $root -Force
    if (-not $rootItem.PSIsContainer -or (($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
      throw 'JY200_DUO_EXECUTION_ROOT_UNSAFE'
    }
    $queue = [System.Collections.Generic.Queue[string]]::new()
    $queue.Enqueue($root)
    while ($queue.Count -gt 0) {
      $directory = $queue.Dequeue()
      foreach ($item in Get-ChildItem -LiteralPath $directory -Force) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
          throw 'JY200_DUO_EXECUTION_REPARSE_DENIED'
        }
        if ($item.PSIsContainer) {
          $queue.Enqueue($item.FullName)
        } else {
          $handles.Add([IO.File]::Open($item.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read))
        }
      }
    }
  }
  [Console]::Out.WriteLine('OPENVIDEO_JY200_EXECUTION_LOCKED')
  [Console]::Out.Flush()
  if ([Console]::In.ReadLine() -ne 'release') { throw 'JY200_DUO_EXECUTION_LOCK_ABORTED' }
} finally {
  for ($index = $handles.Count - 1; $index -ge 0; $index -= 1) { $handles[$index].Dispose() }
}
`.trim()

const resolveWindowsPowerShell = () => {
  const windowsRoot = process.env.SystemRoot ?? process.env.WINDIR
  if (typeof windowsRoot !== 'string' || !path.isAbsolute(windowsRoot)) {
    throw new Error('JY200_DUO_EXECUTION_LOCK_UNAVAILABLE')
  }
  return path.join(windowsRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
}

/**
 * Hold Windows no-write/no-delete handles over both verified runtime trees for
 * the full child-process lifetime. The caller revalidates after the handles
 * are acquired, closing the validate-to-execute replacement window.
 */
export const withJY200DuoWindowsExecutionLock = async ({ roots, execute, timeoutMs = 45_000 }) => {
  if (process.platform !== 'win32' || !Array.isArray(roots) || roots.length === 0 ||
      roots.some((root) => typeof root !== 'string' || !path.isAbsolute(root)) ||
      typeof execute !== 'function' || !Number.isSafeInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > 120_000) {
    throw new Error('JY200_DUO_EXECUTION_LOCK_UNAVAILABLE')
  }
  const encodedCommand = Buffer.from(powershellExecutionLockSource, 'utf16le').toString('base64')
  const environment = safeEnvironment()
  environment.OPENVIDEO_JY200_EXECUTION_ROOTS = Buffer.from(JSON.stringify(
    [...new Set(roots.map((root) => path.resolve(root)))],
  ), 'utf8').toString('base64')
  const child = spawn(resolveWindowsPowerShell(), [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encodedCommand,
  ], {
    env: environment,
    windowsHide: true,
    stdio: ['pipe', 'pipe', 'pipe'],
  })
  let stdout = ''
  let stderr = ''
  let settled = false
  const exited = new Promise((resolve) => child.once('exit', (code, signal) => resolve({ code, signal })))
  const ready = new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('JY200_DUO_EXECUTION_LOCK_TIMEOUT')), timeoutMs)
    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    child.stdout.on('data', (chunk) => {
      stdout += chunk
      if (!settled && stdout.includes('OPENVIDEO_JY200_EXECUTION_LOCKED')) {
        settled = true
        clearTimeout(timer)
        resolve(undefined)
      }
    })
    child.stderr.on('data', (chunk) => { stderr = `${stderr}${chunk}`.slice(-4096) })
    child.once('error', () => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(new Error('JY200_DUO_EXECUTION_LOCK_UNAVAILABLE'))
    })
    child.once('exit', () => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(new Error(stderr ? 'JY200_DUO_EXECUTION_LOCK_FAILED' : 'JY200_DUO_EXECUTION_LOCK_UNAVAILABLE'))
    })
  })
  try {
    await ready
    return await execute()
  } finally {
    if (child.exitCode === null) child.stdin.end('release\n')
    const outcome = await Promise.race([
      exited,
      new Promise((resolve) => setTimeout(() => resolve(null), 5_000)),
    ])
    if (outcome === null && child.exitCode === null) child.kill()
  }
}

/**
 * Execute only between two complete runtime validations, then verify every
 * generated resource config again. A changed JAR or config can never produce
 * a signed execution receipt.
 */
export const runVerifiedJY200DuoRuntime = async ({
  runtimeRoot,
  manifest,
  configExpectations,
  execute,
  additionalExecutionRoots = [],
  validateRuntime = validateInstalledDuoWriterRuntime,
  javaRuntimeRoot = undefined,
  javaDistribution = undefined,
  validateJavaRuntime = validateJY200DuoPrivateJavaRuntime,
  readConfig = (target) => readFileNoReparse(target, runtimeRoot, 4 * 1024 * 1024),
  withExecutionLock = withJY200DuoWindowsExecutionLock,
}) => {
  if (!Array.isArray(additionalExecutionRoots) ||
      additionalExecutionRoots.some((root) => typeof root !== 'string' || !path.isAbsolute(root))) {
    throw new Error('JY200_DUO_EXECUTION_LOCK_UNAVAILABLE')
  }
  const before = await validateRuntime({ runtimeRoot, manifest })
  const beforeJava = javaRuntimeRoot
    ? await validateJavaRuntime({ runtimeRoot: javaRuntimeRoot, distribution: javaDistribution })
    : null
  const assertConfigsCurrent = async () => {
    for (const expectation of configExpectations) {
      if ((await readConfig(expectation.target)).toString() !== expectation.expected) {
        throw new Error('JY200_DUO_LOCAL_RESOURCE_REPLACED')
      }
    }
  }
  return withExecutionLock({
    roots: [runtimeRoot, ...(javaRuntimeRoot ? [javaRuntimeRoot] : []), ...additionalExecutionRoots],
    execute: async () => {
      const [locked, lockedJava] = await Promise.all([
        validateRuntime({ runtimeRoot, manifest }),
        javaRuntimeRoot
          ? validateJavaRuntime({ runtimeRoot: javaRuntimeRoot, distribution: javaDistribution })
          : null,
      ])
      if (runtimeIdentity(before) !== runtimeIdentity(locked)) throw new Error('JY200_DUO_RUNTIME_REPLACED')
      if (beforeJava?.inventoryFingerprint !== lockedJava?.inventoryFingerprint) {
        throw new Error('JY200_DUO_PRIVATE_JAVA_REPLACED')
      }
      await assertConfigsCurrent()
      await execute(locked)
      const [after, afterJava] = await Promise.all([
        validateRuntime({ runtimeRoot, manifest }),
        javaRuntimeRoot
          ? validateJavaRuntime({ runtimeRoot: javaRuntimeRoot, distribution: javaDistribution })
          : null,
      ])
      if (runtimeIdentity(locked) !== runtimeIdentity(after)) throw new Error('JY200_DUO_RUNTIME_REPLACED')
      if (lockedJava?.inventoryFingerprint !== afterJava?.inventoryFingerprint) {
        throw new Error('JY200_DUO_PRIVATE_JAVA_REPLACED')
      }
      await assertConfigsCurrent()
      return Object.freeze({
        ...after,
        writerBuildDigest: after.buildDigest,
        buildDigest: lockedJava
          ? fingerprintJY200DuoProductRuntime({
              writerBuildDigest: after.buildDigest,
              javaInventoryFingerprint: afterJava.inventoryFingerprint,
            })
          : after.buildDigest,
      })
    },
  })
}

/** @param {Record<string, any>} receipt */
export const createJY200DuoExecutionReceiptFileName = (receipt) => [
  fingerprintJY200DuoValue(canonicalJY200DuoJson({
    draft_id_fingerprint: receipt.draft_id_fingerprint,
    build_digest: receipt.build_digest,
    binding_set_fingerprint: receipt.binding_set_fingerprint,
    binding_evidence_fingerprint: receipt.binding_evidence_fingerprint,
  })),
  'json',
].join('.')

export const publishJY200DuoExecutionReceipt = async ({ evidenceRoot, receipt, integrityKey }) => {
  const output = path.join(evidenceRoot, createJY200DuoExecutionReceiptFileName(receipt))
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const staged = `${output}.${process.pid}.tmp`
  try {
    await writeFile(staged, `${JSON.stringify(receipt, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    try {
      await link(staged, output)
      return output
    } catch (error) {
      if (error?.code !== 'EEXIST') throw error
      const existing = parseJY200DuoProbeExecutionReceipt(JSON.parse(await readFile(output, 'utf8')), integrityKey)
      if (!existing || canonicalJY200DuoJson(existing) !== canonicalJY200DuoJson(receipt)) {
        throw new Error('JY200_DUO_EXECUTION_RECEIPT_CONFLICT')
      }
      return output
    }
  } finally {
    await rm(staged, { force: true })
  }
}

const runnerSource = `
import com.duoec.video.builder.ProjectBuilder;
import com.duoec.video.jy.JianyingBuilder;
import com.duoec.video.jy.JianyingProjectBuildState;
import com.duoec.video.project.VideoProject;
import com.duoec.video.project.material.BaseTextMaterial;
import java.io.File;

public final class OpenVideoJY200DuoLocalProbe {
    public static void main(String[] args) {
        if (args.length != 5) throw new IllegalArgumentException("JY200_DUO_PROBE_ARGUMENT_INVALID");
        String outputRoot = args[0];
        String draftName = args[1];
        long stickerId = Long.parseLong(args[2]);
        long flowerId = Long.parseLong(args[3]);
        long videoEffectId = Long.parseLong(args[4]);
        JianyingProjectBuildState.DEBUG_JY_DRAFT_DIR = outputRoot + File.separator;
        VideoProject project = ProjectBuilder.createProject(200000000000000001L, draftName, 1080, 1920)
            .setTest(true)
            .buildScript(0, script -> script
                .buildNewText("OpenVideo", 0L, 3000L, text -> text
                    .setPosition(0, 0)
                    .setStyle(new BaseTextMaterial.TextStyle()
                        .setFontSize(28).setBold(false).setItalic(false).setTextAlign(1)
                        .setFillColor("#FFFFFF").setStrokeColor("#000000").setStrokeWidth(4))
                    .addWord(0, 9, word -> word.setFlowerId(flowerId)))
                .buildNewSticker(stickerId, 0L, 3000L, sticker -> sticker
                    .setPosition(240, -300)
                    .setZoom(7000, 7000))
                .builderNewVideoEffect(videoEffectId, 0L, 3000L, effect -> {}))
            .getProject();
        new JianyingBuilder().build(project);
    }
}
`.trimStart()

const safeEnvironment = () => {
  /** @type {NodeJS.ProcessEnv} */
  const output = {}
  for (const expected of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP']) {
    const actual = Object.keys(process.env).find((key) => key.toLowerCase() === expected.toLowerCase())
    if (actual && typeof process.env[actual] === 'string') output[expected] = process.env[actual]
  }
  return output
}

const runJava = async ({ javaExecutable, javacExecutable, buildRoot, classpath, probeRoot, draftName, stickerId, flowerId, videoEffectId }) => {
  const sourceRoot = path.join(probeRoot, 'java')
  const classesRoot = path.join(probeRoot, 'classes')
  await mkdir(sourceRoot, { recursive: true, mode: 0o700 })
  await mkdir(classesRoot, { recursive: true, mode: 0o700 })
  const sourcePath = path.join(sourceRoot, 'OpenVideoJY200DuoLocalProbe.java')
  await writeFile(sourcePath, runnerSource, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
  const options = { cwd: buildRoot, env: safeEnvironment(), windowsHide: true, timeout: 60_000, maxBuffer: 64 * 1024 }
  await execFile(javacExecutable, ['-encoding', 'UTF-8', '-cp', classpath, '-d', classesRoot, sourcePath], options)
  await execFile(javaExecutable, [
    '-cp', `${classesRoot}${path.delimiter}${classpath}`,
    'OpenVideoJY200DuoLocalProbe', probeRoot, draftName, stickerId, flowerId, videoEffectId,
  ], options)
}

export const inspectDuoLocalResourceReadback = ({ draft, sticker, flower, videoEffect }) => {
  const effects = Array.isArray(draft?.materials?.effects) ? draft.materials.effects : []
  const texts = Array.isArray(draft?.materials?.texts) ? draft.materials.texts : []
  const stickers = Array.isArray(draft?.materials?.stickers) ? draft.materials.stickers : []
  const videoEffects = Array.isArray(draft?.materials?.video_effects) ? draft.materials.video_effects : []
  const tracks = Array.isArray(draft?.tracks) ? draft.tracks : []
  const stickerMatches = stickers.filter((entry) => entry?.resource_id === sticker.resourceId)
  const flowerMatches = effects.filter((entry) => entry?.resource_id === flower.resourceId && entry?.effect_id === flower.effectId)
  const videoMatches = videoEffects.filter((entry) => entry?.resource_id === videoEffect.resourceId && entry?.effect_id === videoEffect.effectId)
  const stickerSegments = tracks.filter((track) => track?.type === 'sticker').flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
  const textSegments = tracks.filter((track) => track?.type === 'text').flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
  const effectSegments = tracks.filter((track) => track?.type === 'effect').flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
  const textMaterial = textSegments.length === 1 ? texts.find((entry) => entry?.id === textSegments[0]?.material_id) : null
  let flowerStyles = null
  try {
    const content = JSON.parse(textMaterial?.content)
    flowerStyles = Array.isArray(content?.styles) ? content.styles : null
  } catch {}
  const flowerStyle = flowerStyles?.length === 1 ? flowerStyles[0]?.effectStyle : null
  if (stickerMatches.length !== 1 || flowerMatches.length !== 1 || videoMatches.length !== 1 ||
      stickerSegments.length !== 1 || stickerSegments[0]?.material_id !== stickerMatches[0]?.id ||
      textSegments.length !== 1 || !textMaterial || flowerStyle?.id !== flower.resourceId ||
      typeof flowerMatches[0]?.path !== 'string' || flowerStyle?.path !== flowerMatches[0].path ||
      effectSegments.length !== 1 || effectSegments[0]?.material_id !== videoMatches[0]?.id) {
    throw new Error('JY200_DUO_LOCAL_READBACK_FAILED')
  }
  return Object.freeze({
    stickerMaterials: 1,
    flowerMaterials: 1,
    videoEffectMaterials: 1,
    stickerSegments: 1,
    textSegments: 1,
    effectSegments: 1,
    draftFingerprint: fingerprintCanonicalJY200Draft(draft),
  })
}

const inspectReadback = async ({ draftRoot, sticker, flower, videoEffect }) => {
  const draft = JSON.parse(await readFile(path.join(draftRoot, 'draft_info.json'), 'utf8'))
  return Object.freeze({
    readback: inspectDuoLocalResourceReadback({ draft, sticker, flower, videoEffect }),
    executionDraftFingerprint: fingerprintJY200DuoExecutionDraft(draft),
  })
}

export const runDuoLocalResourceProbe = async ({ authorizationId, stickerToken, flowerToken, videoEffectToken, existingRuntimeRoot = undefined }) => {
  const tokens = [stickerToken, flowerToken, videoEffectToken]
  if (!authorizationPattern.test(authorizationId ?? '') || tokens.some((token) => !tokenPattern.test(token ?? '')) ||
      new Set(tokens).size !== tokens.length) {
    throw new Error('JY200_DUO_LOCAL_PROBE_INPUT_INVALID')
  }
  const runtime = await loadLauncherRuntimeConfig({ repositoryRoot })
  // The Launcher has already secured this runtime root during boot. A probe must not
  // trigger another recursive Windows ACL walk over the whole user data tree before
  // it can even read its authorization; production callers keep the default securer.
  const repositories = await createJsonRepositories({
    dataRoot: runtime.dataRoot,
    securePrivateRoot: async () => {},
  })
  const authorization = await repositories.authorizationRepository.get(authorizationId)
  if (!authorization || authorization.status !== 'authorized' || authorization.readOnly !== true || authorization.purpose !== 'jianying_draft') {
    throw new Error('JY200_DUO_LOCAL_AUTHORIZATION_UNAVAILABLE')
  }
  const compatibilityManifest = JSON.parse(await readFile(path.join(repositoryRoot, 'config', 'jianying-compatibility.json'), 'utf8'))
  const duoManifest = JSON.parse(await readFile(path.join(repositoryRoot, 'config', 'duo-video-upstream.json'), 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  const decoder = createJianyingPrivateDraftDecoder()
  const selected = await Promise.all(tokens.map((packagingToken) =>
    decoder.extractDuoProbeMaterial({ authorization, desktop, packagingToken })))
  const firstIdentity = selected.map((value) => ({
    sourceFingerprint: value.sourceFingerprint,
    catalogFingerprint: value.catalogFingerprint,
    desktopBindingFingerprint: value.desktopBinding.binding_fingerprint,
  }))
  const bindings = await Promise.all(selected.map((value, index) => resolveDuoLocalJyResourceProbeBinding({
    desktop,
    profileId: value.profileId,
    appVersion: value.appVersion,
    catalogEntry: value.catalogEntry,
    sourceMaterial: value.sourceMaterial,
    expectedIdentity: firstIdentity[index],
    currentIdentity: firstIdentity[index],
  })))
  const sticker = bindings.find((value) => value.resourceType === 'sticker')
  const flower = bindings.find((value) => value.resourceType === 'flower')
  const videoEffect = bindings.find((value) => value.resourceType === 'video_effect')
  if (!sticker || !flower || !videoEffect) throw new Error('JY200_DUO_LOCAL_FAMILY_SET_INVALID')

  const installedProductRuntime = await inspectJY200DuoInstalledRuntime({
    dataRoot: runtime.dataRoot,
    manifest: duoManifest,
  })
  if (!installedProductRuntime.available ||
      (existingRuntimeRoot && path.resolve(existingRuntimeRoot) !== path.resolve(installedProductRuntime.runtimeRoot))) {
    throw new Error('JY200_DUO_INSTALLED_RUNTIME_UNAVAILABLE')
  }
  const runtimeBuild = Object.freeze({ stagingRoot: installedProductRuntime.runtimeRoot })
  await validateJY200ProbeStagingRoot({ runtimeRoot: runtime.dataRoot, stagingRoot: runtimeBuild.stagingRoot, liveDraftRoot: desktop.draftRoot })
  const probeRoot = path.join(runtime.dataRoot, 'JY-200', 'duo-local-probes', randomUUID())
  await mkdir(probeRoot, { recursive: true, mode: 0o700 })
  await validateJY200ProbeStagingRoot({ runtimeRoot: runtime.dataRoot, stagingRoot: probeRoot, liveDraftRoot: desktop.draftRoot })
  const configExpectations = []
  for (const binding of bindings) {
    const target = path.join(runtimeBuild.stagingRoot, 'tmp', 'rs', binding.relativeConfigPath)
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 })
    const expected = `${JSON.stringify(binding.jyResource)}\n`
    try {
      const existing = await readFile(target, 'utf8')
      if (existing !== expected) throw new Error('JY200_DUO_LOCAL_RESOURCE_REPLACED')
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
      await writeFile(target, expected, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    }
    configExpectations.push(Object.freeze({ target, expected }))
  }
  const now = new Date()
  const digits = (value) => String(value).padStart(2, '0')
  const draftName = `OpenVideo-JY200-duo-direct-${now.getFullYear()}${digits(now.getMonth() + 1)}${digits(now.getDate())}-${digits(now.getHours())}${digits(now.getMinutes())}${digits(now.getSeconds())}`
  if (!draftNamePattern.test(draftName)) throw new Error('JY200_DUO_LOCAL_DRAFT_NAME_INVALID')
  const installedRuntime = await runVerifiedJY200DuoRuntime({
    runtimeRoot: runtimeBuild.stagingRoot,
    manifest: duoManifest,
    javaRuntimeRoot: installedProductRuntime.privateJava.runtimeRoot,
    javaDistribution: duoManifest.writer_only_runtime.private_java_distribution,
    configExpectations,
    execute: (validatedRuntime) => runJava({
      javaExecutable: installedProductRuntime.privateJava.javaExecutable,
      javacExecutable: installedProductRuntime.privateJava.javacExecutable,
      buildRoot: runtimeBuild.stagingRoot,
      classpath: validatedRuntime.classpathEntries.join(path.delimiter),
      probeRoot,
      draftName,
      stickerId: sticker.resourceId,
      flowerId: flower.resourceId,
      videoEffectId: videoEffect.resourceId,
    }),
  })
  const draftRoot = path.join(probeRoot, draftName)
  await validateJY200ProbeArtifactTree({ stagingRoot: probeRoot, artifactRoot: draftRoot, maxEntries: 1024 })
  const inspected = await inspectReadback({ draftRoot, sticker, flower, videoEffect })
  const readback = inspected.readback
  const finalDesktop = await detectJianyingDesktop({ compatibilityManifest })
  const finalSelected = await Promise.all(tokens.map((packagingToken) =>
    decoder.extractDuoProbeMaterial({ authorization, desktop: finalDesktop, packagingToken })))
  const finalIdentity = finalSelected.map((value) => ({
    sourceFingerprint: value.sourceFingerprint,
    catalogFingerprint: value.catalogFingerprint,
    desktopBindingFingerprint: value.desktopBinding.binding_fingerprint,
  }))
  const finalBindings = await Promise.all(finalSelected.map((value, index) => resolveDuoLocalJyResourceProbeBinding({
    desktop: finalDesktop,
    profileId: value.profileId,
    appVersion: value.appVersion,
    catalogEntry: value.catalogEntry,
    sourceMaterial: value.sourceMaterial,
    expectedIdentity: firstIdentity[index],
    currentIdentity: finalIdentity[index],
  })))
  if (JSON.stringify(finalBindings.map((value) => value.publicEvidence)) !==
      JSON.stringify(bindings.map((value) => value.publicEvidence))) {
    throw new Error('JY200_DUO_EVIDENCE_IDENTITY_STALE')
  }
  const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({
    evidenceRoot: path.join(runtime.dataRoot, 'evidence', 'jy132-packaging-resources'),
  })
  const executionReceipt = createJY200DuoProbeExecutionReceipt({
    providerCommit: duoManifest.commit,
    buildDigest: installedRuntime.buildDigest,
    profileId: finalDesktop.profileId,
    appVersion: finalDesktop.version,
    desktopBindingFingerprint: finalIdentity[0].desktopBindingFingerprint,
    currentCatalogFingerprint: finalIdentity[0].catalogFingerprint,
    draftId: draftName,
    initialDraftFingerprint: inspected.executionDraftFingerprint,
    bindingEvidence: finalBindings.map((value) => value.publicEvidence),
  }, integrityKey)
  await publishJY200DuoExecutionReceipt({
    evidenceRoot: path.join(runtime.dataRoot, 'evidence', 'jy200-duo-execution'),
    receipt: executionReceipt,
    integrityKey,
  })
  return Object.freeze({
    ok: true,
    status: 'probe_candidate_written',
    admission: 'deferred',
    writerEligible: false,
    catalogBound: false,
    families: Object.freeze(['sticker', 'flower', 'video_effect']),
    readback,
    draftName,
    privateProbeRoot: probeRoot,
    buildDigest: installedRuntime.buildDigest,
    evidence: Object.freeze(bindings.map((value) => value.publicEvidence)),
    executionReceiptFingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(executionReceipt)),
  })
}

const main = async () => {
  try {
    const [authorizationId, stickerToken, flowerToken, videoEffectToken, existingRuntimeRoot] = process.argv.slice(2)
    const result = await runDuoLocalResourceProbe({ authorizationId, stickerToken, flowerToken, videoEffectToken, existingRuntimeRoot })
    process.stdout.write(`${JSON.stringify({
      ok: result.ok,
      status: result.status,
      admission: result.admission,
      writerEligible: result.writerEligible,
      catalogBound: result.catalogBound,
      families: result.families,
      readback: result.readback,
      draftName: result.draftName,
      executionReceiptFingerprint: result.executionReceiptFingerprint,
    })}\n`)
  } catch (error) {
    const reason = error instanceof Error && /^(?:JY200|NATIVE018)_[A-Z0-9_]+$/u.test(error.message)
      ? error.message
      : 'JY200_DUO_LOCAL_PROBE_FAILED'
    process.stdout.write(`${JSON.stringify({ ok: false, admission: 'deferred', writerEligible: false, catalogBound: false, reason })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
