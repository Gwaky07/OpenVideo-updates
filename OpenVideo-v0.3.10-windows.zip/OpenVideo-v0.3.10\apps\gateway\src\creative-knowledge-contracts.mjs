// @ts-nocheck Runtime schema guards intentionally validate unknown JSON values.
import { createHash } from 'node:crypto'

const sha256Pattern = /^[a-f0-9]{64}$/u
const sourceCommitPattern = /^[a-f0-9]{40}$/u
const recipeIdPattern = /^shotcraft-v1-[a-z0-9][a-z0-9-]{1,119}$/u
const techniqueRuleIdPattern = /^shotcraft-v2-(?:hold|rhythm|seam|audio|limit)-[a-z0-9][a-z0-9-]{1,159}$/u
const sourceCardPattern = /^references\/shots\/[a-z0-9-]+\/[a-z0-9-]+\.md$/u
const maxTextLength = 1_000
const maxListItems = 12
const maxRecipes = 200
const maxTechniqueRules = 800

const recipeKeys = [
  'recipeId',
  'sourceRepository',
  'sourceCommit',
  'sourceCard',
  'license',
  'shotRole',
  'energy',
  'durationRangeUs',
  'creativeIntents',
  'pacing',
  'holdRules',
  'transitionIntents',
  'rhythmIntents',
  'audioCueIntents',
  'requiredAssetKinds',
  'preferredSceneAttributes',
  'avoidConditions',
  'realizationHints',
]

const snapshotKeys = ['schema_version', 'normalizer_version', 'source', 'recipes', 'snapshot_fingerprint']
const snapshotV2Keys = ['schema_version', 'normalizer_version', 'source', 'recipes', 'technique_rules', 'snapshot_fingerprint']
const sourceKeys = ['repository', 'commit', 'license', 'license_sha256']
const manifestKeys = ['schema_version', 'source', 'normalizer', 'files', 'skipped', 'snapshot_fingerprint']
const manifestV2Keys = ['schema_version', 'source', 'normalizer', 'files', 'technique_sources', 'snapshot_fingerprint']
const normalizerKeys = ['version', 'prompt_version', 'model_config_fingerprint']
const fileKeys = ['path', 'sha256']
const skippedKeys = ['path', 'reason']
const techniqueSourceKeys = ['path', 'rule_ids']
const durationKeys = ['minUs', 'maxUs']
const energies = new Set(['low', 'medium', 'high'])
const shotRoles = new Set(['camera', 'data', 'effects', 'interaction', 'opening', 'outro', 'rhythm', 'transition', 'typography', 'ui-entrance'])
const rhythmClasses = new Set(['steady', 'accelerate', 'decelerate', 'rest'])
const soundFamilies = new Set(['whoosh', 'impact', 'riser', 'sparkle', 'transition', 'camera', 'text', 'foley'])
const audioAnchors = new Set(['shot_start', 'action', 'settle', 'seam', 'shot_end'])
const importanceLevels = new Set(['low', 'medium', 'high'])
const techniqueClasses = new Set(['ambient_hold', 'hero_impact', 'hero_transition', 'motion_accent'])

const hasExactKeys = (value, keys) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const actual = Object.keys(value)
  return actual.length === keys.length && keys.every((key) => Object.hasOwn(value, key)) &&
    actual.every((key) => keys.includes(key))
}

const containsPrivateReference = (value) =>
  typeof value === 'string' && /(?:[A-Za-z]:[\\/]|\\\\|\bhttps?:\/\/|\bfile:|(?:api[_ -]?key|authorization|bearer|access[_ -]?token)\s*[:=])/iu.test(value)

const isSafeText = (value, maximum = maxTextLength) =>
  typeof value === 'string' && value.length > 0 && value.length <= maximum &&
  value === value.trim() && !/[\u0000-\u001f]/u.test(value) && !containsPrivateReference(value)

const isSafeList = (value) => Array.isArray(value) && value.length <= maxListItems && value.every((entry) => isSafeText(entry))

const safeIdList = (value, maximum) => Array.isArray(value) && value.length <= maximum &&
  new Set(value).size === value.length && value.every((entry) =>
    typeof entry === 'string' && /^[A-Za-z0-9._:-]{1,200}$/u.test(entry))

const isSafeSource = (value) => typeof value === 'string' && /^https:\/\//u.test(value) && value.length <= 300

const isSafeCommit = (value) => typeof value === 'string' && sourceCommitPattern.test(value)

const isSafeLicense = (value) => isSafeText(value, 160) && !/[<>]/u.test(value)

const isSafeDuration = (value) => hasExactKeys(value, durationKeys) &&
  Number.isInteger(value.minUs) && Number.isInteger(value.maxUs) &&
  value.minUs > 0 && value.minUs <= value.maxUs && value.maxUs <= 86_400_000_000

const isRoleList = (value) => Array.isArray(value) && value.length <= shotRoles.size &&
  new Set(value).size === value.length && value.every((entry) => shotRoles.has(entry))

const isEnergyList = (value) => Array.isArray(value) && value.length <= energies.size &&
  new Set(value).size === value.length && value.every((entry) => energies.has(entry))

const isBoundedInteger = (value, minimum, maximum) =>
  Number.isSafeInteger(value) && value >= minimum && value <= maximum

/** @param {unknown} value */
export const isCreativeTechniqueRule = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      !techniqueRuleIdPattern.test(value.ruleId ?? '') || !sourceCardPattern.test(value.sourceCard ?? '')) return false
  const common = isRoleList(value.applicableShotRoles) && isEnergyList(value.applicableEnergies)
  if (!common) return false
  if (value.family === 'hold_budget') {
    return hasExactKeys(value, [
      'ruleId', 'sourceCard', 'family', 'applicableShotRoles', 'applicableEnergies',
      'minHoldUs', 'maxHoldUs', 'minSourceUs',
    ]) && isBoundedInteger(value.minHoldUs, 0, 5_000_000) &&
      isBoundedInteger(value.maxHoldUs, value.minHoldUs, 10_000_000) &&
      isBoundedInteger(value.minSourceUs, value.maxHoldUs, 30_000_000)
  }
  if (value.family === 'rhythm_pattern') {
    return hasExactKeys(value, [
      'ruleId', 'sourceCard', 'family', 'applicableShotRoles', 'applicableEnergies',
      'rhythmClass', 'maxConsecutiveHighEnergy', 'minRestBeats',
    ]) && rhythmClasses.has(value.rhythmClass) &&
      isBoundedInteger(value.maxConsecutiveHighEnergy, 1, 6) &&
      isBoundedInteger(value.minRestBeats, 0, 6)
  }
  if (value.family === 'transition_seam') {
    return hasExactKeys(value, [
      'ruleId', 'sourceCard', 'family', 'applicableShotRoles', 'applicableEnergies',
      'capabilityId', 'maxOccurrences', 'requiresSemanticRelation',
    ]) && ['transition.cut', 'transition.none'].includes(value.capabilityId) &&
      isBoundedInteger(value.maxOccurrences, 1, 12) && typeof value.requiresSemanticRelation === 'boolean'
  }
  if (value.family === 'audio_cue') {
    return hasExactKeys(value, [
      'ruleId', 'sourceCard', 'family', 'applicableShotRoles', 'applicableEnergies',
      'soundFamily', 'anchor', 'importance', 'maxOccurrences',
    ]) && soundFamilies.has(value.soundFamily) && audioAnchors.has(value.anchor) &&
      importanceLevels.has(value.importance) && isBoundedInteger(value.maxOccurrences, 1, 12)
  }
  if (value.family === 'global_limit') {
    return hasExactKeys(value, [
      'ruleId', 'sourceCard', 'family', 'applicableShotRoles', 'applicableEnergies',
      'techniqueClass', 'maxOccurrences', 'minRestBeats',
    ]) && techniqueClasses.has(value.techniqueClass) &&
      isBoundedInteger(value.maxOccurrences, 1, 12) && isBoundedInteger(value.minRestBeats, 0, 12)
  }
  return false
}

/** @param {unknown} value */
export const isCreativeRecipe = (value) => {
  if (!hasExactKeys(value, recipeKeys)) return false
  return (
    recipeIdPattern.test(value.recipeId) &&
    isSafeSource(value.sourceRepository) &&
    isSafeCommit(value.sourceCommit) &&
    sourceCardPattern.test(value.sourceCard) &&
    isSafeLicense(value.license) &&
    isSafeText(value.shotRole, 80) &&
    energies.has(value.energy) &&
    isSafeDuration(value.durationRangeUs) &&
    isSafeList(value.creativeIntents) &&
    isSafeText(value.pacing, 80) &&
    isSafeList(value.holdRules) &&
    isSafeList(value.transitionIntents) &&
    isSafeList(value.rhythmIntents) &&
    isSafeList(value.audioCueIntents) &&
    isSafeList(value.requiredAssetKinds) &&
    isSafeList(value.preferredSceneAttributes, 120) &&
    isSafeList(value.avoidConditions) &&
    isSafeList(value.realizationHints)
  )
}

/** @param {unknown} value */
export const isCreativeKnowledgeSnapshot = (value) => {
  const isV1 = value?.schema_version === 1 && hasExactKeys(value, snapshotKeys)
  const isV2 = value?.schema_version === 2 && hasExactKeys(value, snapshotV2Keys)
  if (!isV1 && !isV2) return false
  if (!isSafeText(value.normalizer_version, 120) || !hasExactKeys(value.source, sourceKeys)) return false
  if (!isSafeSource(value.source.repository) || !isSafeCommit(value.source.commit) || !isSafeLicense(value.source.license) || !sha256Pattern.test(value.source.license_sha256)) return false
  if (!Array.isArray(value.recipes) || value.recipes.length === 0 || value.recipes.length > maxRecipes) return false
  if (!value.recipes.every(isCreativeRecipe)) return false
  const ids = value.recipes.map((recipe) => recipe.recipeId)
  if (new Set(ids).size !== ids.length || !sha256Pattern.test(value.snapshot_fingerprint)) return false
  if (isV1) return true
  if (!Array.isArray(value.technique_rules) || value.technique_rules.length === 0 ||
      value.technique_rules.length > maxTechniqueRules || !value.technique_rules.every(isCreativeTechniqueRule)) return false
  const ruleIds = value.technique_rules.map((rule) => rule.ruleId)
  return new Set(ruleIds).size === ruleIds.length
}

/** @param {unknown} value */
export const isCreativeKnowledgeManifest = (value) => {
  const isV1 = value?.schema_version === 1 && hasExactKeys(value, manifestKeys)
  const isV2 = value?.schema_version === 2 && hasExactKeys(value, manifestV2Keys)
  if (!isV1 && !isV2) return false
  if (!hasExactKeys(value.source, sourceKeys) || !isSafeSource(value.source.repository) ||
      !isSafeCommit(value.source.commit) || !isSafeLicense(value.source.license) || !sha256Pattern.test(value.source.license_sha256)) return false
  if (!hasExactKeys(value.normalizer, normalizerKeys) || !isSafeText(value.normalizer.version, 120)) return false
  if (value.normalizer.prompt_version !== null && !isSafeText(value.normalizer.prompt_version, 120)) return false
  if (value.normalizer.model_config_fingerprint !== null && !sha256Pattern.test(value.normalizer.model_config_fingerprint)) return false
  if (!Array.isArray(value.files) || value.files.length === 0 || value.files.length > maxRecipes) return false
  if (!value.files.every((entry) => hasExactKeys(entry, fileKeys) && sourceCardPattern.test(entry.path) && sha256Pattern.test(entry.sha256))) return false
  const paths = value.files.map((entry) => entry.path)
  if (new Set(paths).size !== paths.length) return false
  if (!sha256Pattern.test(value.snapshot_fingerprint)) return false
  if (isV1) {
    if (!Array.isArray(value.skipped) || value.skipped.length > maxRecipes) return false
    if (!value.skipped.every((entry) => hasExactKeys(entry, skippedKeys) && sourceCardPattern.test(entry.path) && isSafeText(entry.reason, 160))) return false
    const skippedPaths = value.skipped.map((entry) => entry.path)
    return new Set(skippedPaths).size === skippedPaths.length && !paths.some((path) => skippedPaths.includes(path))
  }
  if (!Array.isArray(value.technique_sources) || value.technique_sources.length === 0 || value.technique_sources.length > maxRecipes) return false
  if (!value.technique_sources.every((entry) => hasExactKeys(entry, techniqueSourceKeys) &&
      sourceCardPattern.test(entry.path) && safeIdList(entry.rule_ids, 100) && entry.rule_ids.length > 0 &&
      entry.rule_ids.every((id) => techniqueRuleIdPattern.test(id)))) return false
  const techniquePaths = value.technique_sources.map((entry) => entry.path)
  return new Set(techniquePaths).size === techniquePaths.length && techniquePaths.every((path) => paths.includes(path))
}

const canonicalize = (value) => {
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(',')}}`
  }
  return JSON.stringify(value)
}

/** @param {unknown} value */
export const fingerprintCreativeKnowledge = (value) =>
  createHash('sha256').update(canonicalize(value)).digest('hex')

export const fingerprintCreativeKnowledgeSnapshot = ({ snapshot_fingerprint: _snapshotFingerprint, ...snapshotBase }) =>
  fingerprintCreativeKnowledge(snapshotBase)

export const creativeKnowledgeLimits = Object.freeze({ maxRecipes, maxTechniqueRules, maxListItems, maxTextLength })
