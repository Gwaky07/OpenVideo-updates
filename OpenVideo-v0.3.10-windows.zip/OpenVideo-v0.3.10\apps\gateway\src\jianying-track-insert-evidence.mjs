import { lstat, realpath } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import path from 'node:path'

const fingerprintPattern = /^[a-f0-9]{64}$/u
export const admittedJY092DesktopVersion = '11.2.0.14339'

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}

/** @param {unknown} evidence @param {Record<string, any>} desktop */
export const parseJianyingTrackInsertEvidence = (evidence, desktop) => {
  if (!evidence || typeof evidence !== 'object' || Array.isArray(evidence)) return false
  const value = /** @type {Record<string, any>} */ (evidence)
  const draftId = typeof value.draft_id === 'string' && /^OpenVideo-JY092-track-insert-[0-9]+$/u.test(value.draft_id)
  const binding = draftId && fingerprintPattern.test(value.pre_open_fingerprint)
    ? createHash('sha256').update(`${value.draft_id}:${value.pre_open_fingerprint}`).digest('hex')
    : null
  return value.schema_version === 2 && draftId && value.manual_evidence_verified === true && value.evidence_binding === binding &&
    value.profile_id === 'jianying-11-2-provisional' &&
    value.profile_id === desktop?.profileId && value.app_version === admittedJY092DesktopVersion &&
    desktop?.version === admittedJY092DesktopVersion &&
    value.scheme === 'encrypt_v2' &&
    Array.isArray(value.track_names) && value.track_names.join('|') === 'video-primary|voiceover-primary' &&
    value.auxiliary_track_index === 1 && value.auxiliary_segment_count === 1 &&
    typeof value.auxiliary_volume === 'number' && value.auxiliary_volume >= 0.45 && value.auxiliary_volume <= 0.55 &&
    fingerprintPattern.test(value.pre_open_fingerprint) && fingerprintPattern.test(value.post_save_fingerprint) &&
    value.pre_open_fingerprint !== value.post_save_fingerprint &&
    value.observed?.track_order === true && value.observed?.auxiliary_edit === true &&
    value.observed?.encrypted_persistence === true && value.observed?.temporary_media_cleaned === true &&
    value.manual_attestation?.opened === true && value.manual_attestation?.edited === true &&
    value.manual_attestation?.saved === true && value.manual_attestation?.reopened === true
}

/** @param {unknown} candidate */
export const assertOwnedJY092MediaRoot = async (candidate) => {
  if (typeof candidate !== 'string' || !path.isAbsolute(candidate)) throw new Error('JY092_MEDIA_ROOT_INVALID')
  const resolved = path.resolve(candidate)
  if (path.dirname(resolved) !== path.resolve(tmpdir()) || !path.basename(resolved).startsWith('openvideo-jy092-track-insert-')) {
    throw new Error('JY092_MEDIA_ROOT_INVALID')
  }
  const metadata = await lstat(resolved, { bigint: true })
  const actual = await realpath(resolved)
  if (!metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameResolvedObject(resolved, actual, metadata)) {
    throw new Error('JY092_MEDIA_ROOT_INVALID')
  }
  return resolved
}
