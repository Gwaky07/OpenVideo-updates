import { execFile as execFileCallback } from 'node:child_process'
import { createHash } from 'node:crypto'
import { link, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'

import {
  fingerprintCanonicalJY200Draft,
  validateJY200ProbeStagingRoot,
} from '../apps/gateway/src/jianying-artist-effect-probe.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import {
  bindJY200DuoLifecycleToCurrentCatalog,
  canonicalJY200DuoJson,
  createJY200DuoDirectLifecycleReceipt,
  createJY200DuoLocalCatalogLifecycleReceipt,
  fingerprintJY200DuoExecutionDraft,
  fingerprintJY200DuoProductRuntime,
  fingerprintJY200DuoValue,
  inspectJY200DuoDirectLifecycle,
  parseJY200DuoDirectLifecycleReceipt,
  parseJY200DuoLocalCatalogLifecycleReceipt,
  parseJY200DuoProbeExecutionReceipt,
} from '../apps/gateway/src/jianying-duo-direct-probe-evidence.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { createJianyingDesktopBinding, parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import {
  createCapabilityPromotionReceiptsFromAdmittedPackagingIndex,
  loadPackagingResourceEvidenceIntegrityKey,
  loadPackagingResourceIndexForProduction,
} from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import { inspectJY200DuoInstalledRuntime } from './Install-JY200DuoWriterRuntime.mjs'

const execFile = promisify(execFileCallback)
const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const draftIdPattern = /^OpenVideo-JY200-duo-direct-[0-9]{8}-(?:[0-9]{4}|[0-9]{6})$/u
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const stableReceiptIdentity = (value) => Object.fromEntries(Object.entries(value)
  .filter(([key]) => key !== 'verified_at' && key !== 'integrity_signature'))

const loadMatchingExecutionReceipt = async ({
  dataRoot,
  draftId,
  buildDigest,
  initialDraftFingerprint,
  desktopBindingFingerprint,
  catalogFingerprint,
  catalogBinding,
  integrityKey,
}) => {
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy200-duo-execution')
  const entries = (await readdir(evidenceRoot)).filter((entry) => /^[a-f0-9]{64}\.json$/u.test(entry))
  if (entries.length === 0 || entries.length > 256) throw new Error('JY200_DUO_EXECUTION_RECEIPT_REQUIRED')
  const parsed = await Promise.all(entries.map(async (entry) => {
    try {
      return parseJY200DuoProbeExecutionReceipt(
        JSON.parse(await readFileNoReparse(path.join(evidenceRoot, entry), evidenceRoot, 4 * 1024 * 1024)),
        integrityKey,
      )
    } catch { return null }
  }))
  const candidates = parsed.filter((receipt) => receipt && receipt.draft_id === draftId &&
    receipt.build_digest === buildDigest && receipt.binding_set_fingerprint === catalogBinding.binding_set_fingerprint)
  if (candidates.length !== 1) throw new Error('JY200_DUO_EXECUTION_RECEIPT_REQUIRED')
  const receipt = candidates[0]
  const executionBindings = receipt?.binding_evidence?.map((binding) => ({
    family: binding.family,
    packaging_token: binding.packaging_token,
    binding_fingerprint: binding.binding_fingerprint,
  }))
  if (!receipt || receipt.draft_id !== draftId || receipt.build_digest !== buildDigest ||
      receipt.initial_draft_fingerprint !== initialDraftFingerprint ||
      receipt.desktop_binding_fingerprint !== desktopBindingFingerprint ||
      receipt.current_catalog_fingerprint !== catalogFingerprint ||
      canonicalJY200DuoJson(executionBindings) !== canonicalJY200DuoJson(catalogBinding.binding_evidence)) {
    throw new Error('JY200_DUO_EXECUTION_RECEIPT_MISMATCH')
  }
  return receipt
}

const readCatalog = async (dataRoot, desktop) => {
  const catalogRoot = path.join(dataRoot, 'catalogs')
  return parsePrivatePackagingResourceIndex(
    JSON.parse(await readFileNoReparse(path.join(catalogRoot, 'native018-private-draft-catalog.json'), catalogRoot, 32 * 1024 * 1024)),
    { profileId: desktop.profileId, appVersion: desktop.version },
  )
}

const safeAuditPath = (value) => typeof value === 'string' && value.length > 0 &&
  !path.isAbsolute(value) && value.split('/').every((segment) =>
    segment.length > 0 && segment !== '.' && segment !== '..' && !/[\\:\0-\x1f]/u.test(segment))

const readPinnedAuditBlob = async ({ audit, commit, runGit, upstreamRoot }) => {
  if (!safeAuditPath(audit?.path)) throw new Error('JY200_DUO_UPSTREAM_AUDIT_INVALID')
  const { stdout: treeBytes } = await runGit('git.exe', [
    '-C', upstreamRoot, 'ls-tree', '-z', commit, '--', audit.path,
  ], { timeout: 10_000, windowsHide: true, maxBuffer: 1024 * 1024, encoding: 'buffer' })
  const entries = treeBytes.toString('utf8').split('\0').filter(Boolean)
  const match = entries.length === 1
    ? /^(100644) blob ([a-f0-9]{40,64})\t(.+)$/u.exec(entries[0])
    : null
  if (!match || match[3] !== audit.path) throw new Error('JY200_DUO_UPSTREAM_AUDIT_INVALID')
  const { stdout } = await runGit('git.exe', ['-C', upstreamRoot, 'cat-file', 'blob', match[2]], {
    timeout: 10_000, windowsHide: true, maxBuffer: 32 * 1024 * 1024, encoding: 'buffer',
  })
  return stdout
}

export const verifyUpstream = async (manifest, upstreamRoot, {
  runGit = execFile,
  readBuffer = readFileNoReparseBuffer,
} = {}) => {
  const [{ stdout: head }, { stdout: status }] = await Promise.all([
    runGit('git.exe', ['-C', upstreamRoot, 'rev-parse', 'HEAD'], { timeout: 10_000, windowsHide: true }),
    runGit('git.exe', ['-C', upstreamRoot, 'status', '--porcelain'], { timeout: 10_000, windowsHide: true }),
  ])
  if (head.trim() !== manifest.commit || status.trim() !== '') throw new Error('JY200_DUO_UPSTREAM_IDENTITY_INVALID')
  for (const audit of manifest.audit_files ?? []) {
    const bytes = await readPinnedAuditBlob({ audit, commit: manifest.commit, runGit, upstreamRoot })
    if (bytes.byteLength !== audit.size || sha256(bytes) !== audit.sha256) throw new Error('JY200_DUO_UPSTREAM_AUDIT_INVALID')
  }
  const jarRoot = path.join(upstreamRoot, 'duo-video-jy', 'target')
  const jar = await readBuffer(path.join(jarRoot, 'duo-video-jy-1.0.0-SNAPSHOT.jar'), jarRoot, 8 * 1024 * 1024)
  return Object.freeze({ commit: manifest.commit, buildDigest: sha256(jar) })
}

const publishReceipt = async ({ output, receipt, integrityKey, parseReceipt = parseJY200DuoDirectLifecycleReceipt }) => {
  await mkdir(path.dirname(output), { recursive: true, mode: 0o700 })
  const staged = `${output}.${process.pid}.tmp`
  try {
    await writeFile(staged, `${JSON.stringify(receipt, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    try {
      await link(staged, output)
      return receipt
    } catch (error) {
      if (/** @type {{code?: string}} */ (error)?.code !== 'EEXIST') throw error
      const existing = parseReceipt(JSON.parse(await readFile(output, 'utf8')), integrityKey)
      if (!existing || canonicalJY200DuoJson(stableReceiptIdentity(existing)) !==
          canonicalJY200DuoJson(stableReceiptIdentity(receipt))) {
        throw new Error('JY200_DUO_LIFECYCLE_RECEIPT_CONFLICT')
      }
      return existing
    }
  } finally {
    await rm(staged, { force: true })
  }
}

/** @param {string[]} [argv] */
export const verifyJY200DuoDirectProbe = async (argv = process.argv.slice(2)) => {
  const draftId = argv[0]
  const expectedRotation = Number(argv.find((argument) => argument.startsWith('--rotation='))?.slice('--rotation='.length))
  const expectedTextX = Number(argv.find((argument) => argument.startsWith('--text-transform-x='))?.slice('--text-transform-x='.length))
  const expectedTextY = Number(argv.find((argument) => argument.startsWith('--text-transform-y='))?.slice('--text-transform-y='.length))
  const expectedAudioVolumeDb = Number(argv.find((argument) => argument.startsWith('--audio-volume='))?.slice('--audio-volume='.length))
  const expectedAudioVolume = Number.isFinite(expectedAudioVolumeDb)
    ? 10 ** (expectedAudioVolumeDb / 20)
    : null
  const expectedTextTransform = Number.isFinite(expectedTextX) && Number.isFinite(expectedTextY)
    ? Object.freeze({ x: expectedTextX, y: expectedTextY })
    : null
  const attested = argv.includes('--manual-attestation=opened-edited-saved-closed-reopened')
  const localCatalog = argv.includes('--local-catalog')
  const runtimeRootArgument = argv.find((argument) => argument.startsWith('--runtime-root='))?.slice('--runtime-root='.length)
  if (!draftIdPattern.test(draftId ?? '') ||
      (!Number.isFinite(expectedRotation) && !expectedTextTransform && !Number.isFinite(expectedAudioVolume)) ||
      (localCatalog && !expectedTextTransform && !Number.isFinite(expectedAudioVolume)) || !attested ||
      (localCatalog && (!runtimeRootArgument || !path.isAbsolute(runtimeRootArgument)))) {
    throw new Error('JY200_DUO_LIFECYCLE_ARGUMENTS_INVALID')
  }
  const runtime = await loadLauncherRuntimeConfig({ repositoryRoot: root })
  const [compatibilityManifest, upstreamManifest] = await Promise.all([
    readFileNoReparse(path.join(root, 'config', 'jianying-compatibility.json'), root).then(JSON.parse),
    readFileNoReparse(path.join(root, 'config', 'duo-video-upstream.json'), root).then(JSON.parse),
  ])
  const upstreamRoot = path.join(root, 'upstream', 'duo-video')
  const upstream = await verifyUpstream(upstreamManifest, upstreamRoot)
  const initialDesktop = await detectJianyingDesktop({ compatibilityManifest })
  let buildDigest = upstream.buildDigest
  if (localCatalog) {
    await validateJY200ProbeStagingRoot({
      runtimeRoot: runtime.dataRoot,
      stagingRoot: runtimeRootArgument,
      liveDraftRoot: initialDesktop.draftRoot,
    })
    const installedRuntime = await inspectJY200DuoInstalledRuntime({
      dataRoot: runtime.dataRoot,
      manifest: upstreamManifest,
    })
    if (!installedRuntime.available ||
        path.resolve(runtimeRootArgument) !== path.resolve(installedRuntime.runtimeRoot)) {
      throw new Error('JY200_DUO_INSTALLED_RUNTIME_UNAVAILABLE')
    }
    buildDigest = fingerprintJY200DuoProductRuntime({
      writerBuildDigest: installedRuntime.buildDigest,
      javaInventoryFingerprint: installedRuntime.privateJava.inventoryFingerprint,
    })
  }
  const initialCatalog = await readCatalog(runtime.dataRoot, initialDesktop)
  const draftRoot = path.join(initialDesktop.draftRoot, draftId)
  const initialBytes = await readFileNoReparseBuffer(path.join(draftRoot, 'draft_info.json'), initialDesktop.draftRoot, 16 * 1024 * 1024)
  const encryptedBytes = await readFileNoReparseBuffer(path.join(draftRoot, 'draft_content.json'), initialDesktop.draftRoot, 16 * 1024 * 1024)
  const temporaryRoot = await mkdtemp(path.join(os.tmpdir(), 'openvideo-jy200-duo-verify-'))
  try {
    const encryptedPath = path.join(temporaryRoot, 'draft_content.encrypt_v2')
    const plaintextPath = path.join(temporaryRoot, 'draft_content.json')
    await writeFile(encryptedPath, encryptedBytes, { mode: 0o600, flag: 'wx' })
    const decrypt = await createJianyingDraftDecryptor({
      installRoot: initialDesktop.installRoot,
      appVersion: initialDesktop.version,
      expectedDllFingerprint: initialDesktop.dllFingerprint,
    }).ensurePlaintextFile(encryptedPath, plaintextPath)
    if (decrypt.scheme !== 'encrypt_v2' && decrypt.decryptedFrom !== 'encrypt_v2') throw new Error('JY200_DUO_ENCRYPT_V2_REQUIRED')
    const initialDraft = JSON.parse(initialBytes.toString('utf8'))
    const postSaveDraft = JSON.parse(await readFileNoReparse(plaintextPath, temporaryRoot, 32 * 1024 * 1024))
    const readback = inspectJY200DuoDirectLifecycle({
      initialDraft,
      postSaveDraft,
      expectedRotation,
      expectedTextTransform: expectedTextTransform ?? undefined,
      expectedAudioVolume: expectedAudioVolume ?? undefined,
    })
    if (!readback) throw new Error('JY200_DUO_LIFECYCLE_READBACK_INVALID')

    let initialCatalogBinding = null
    if (localCatalog) {
      let evidence = null
      const admittedIndex = await loadPackagingResourceIndexForProduction({
        dataRoot: runtime.dataRoot,
        desktop: initialDesktop,
        candidateCatalogFingerprint: initialCatalog.catalogFingerprint,
        captureEvidence: (value) => { evidence = value },
      })
      const capabilities = createCapabilityPromotionReceiptsFromAdmittedPackagingIndex({
        index: admittedIndex,
        desktop: { profileId: initialDesktop.profileId, version: initialDesktop.version },
      }).map((receipt) => receipt.capabilityId)
      if (!['effect.video.named', 'sticker.named', 'text.flower.private'].every((capability) => capabilities.includes(capability))) {
        throw new Error('JY200_DUO_LOCAL_CAPABILITY_EVIDENCE_REQUIRED')
      }
      initialCatalogBinding = bindJY200DuoLifecycleToCurrentCatalog({ initialDraft, admittedIndex, evidence })
      if (!initialCatalogBinding) throw new Error('JY200_DUO_LOCAL_CATALOG_BINDING_INVALID')
    }

    const finalDesktop = await detectJianyingDesktop({ compatibilityManifest })
    const finalCatalog = await readCatalog(runtime.dataRoot, finalDesktop)
    const finalEncrypted = await readFileNoReparseBuffer(path.join(finalDesktop.draftRoot, draftId, 'draft_content.json'), finalDesktop.draftRoot, 16 * 1024 * 1024)
    const initialBinding = createJianyingDesktopBinding(initialDesktop).binding_fingerprint
    const finalBinding = createJianyingDesktopBinding(finalDesktop).binding_fingerprint
    if (initialBinding !== finalBinding || initialCatalog.catalogFingerprint !== finalCatalog.catalogFingerprint ||
        !encryptedBytes.equals(finalEncrypted)) throw new Error('JY200_DUO_LIFECYCLE_IDENTITY_DRIFT')

    const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({
      evidenceRoot: path.join(runtime.dataRoot, 'evidence', 'jy132-packaging-resources'),
    })
    let finalCatalogBinding = null
    if (localCatalog) {
      let evidence = null
      const admittedIndex = await loadPackagingResourceIndexForProduction({
        dataRoot: runtime.dataRoot,
        desktop: finalDesktop,
        candidateCatalogFingerprint: finalCatalog.catalogFingerprint,
        captureEvidence: (value) => { evidence = value },
      })
      finalCatalogBinding = bindJY200DuoLifecycleToCurrentCatalog({ initialDraft, admittedIndex, evidence })
      if (!finalCatalogBinding || JSON.stringify(finalCatalogBinding) !== JSON.stringify(initialCatalogBinding)) {
        throw new Error('JY200_DUO_LOCAL_CATALOG_IDENTITY_DRIFT')
      }
    }
    const initialDraftFingerprint = fingerprintJY200DuoExecutionDraft(initialDraft)
    const executionReceipt = localCatalog
      ? await loadMatchingExecutionReceipt({
          dataRoot: runtime.dataRoot,
          draftId,
          buildDigest,
          initialDraftFingerprint,
          desktopBindingFingerprint: finalBinding,
          catalogFingerprint: finalCatalog.catalogFingerprint,
          catalogBinding: finalCatalogBinding,
          integrityKey,
        })
      : null
    const executionReceiptFingerprint = executionReceipt
      ? fingerprintJY200DuoValue(canonicalJY200DuoJson(executionReceipt))
      : null
    const receiptInput = {
      draftId,
      providerCommit: upstream.commit,
      buildDigest,
      profileId: finalDesktop.profileId,
      appVersion: finalDesktop.version,
      desktopBindingFingerprint: finalBinding,
      currentCatalogFingerprint: finalCatalog.catalogFingerprint,
      initialDraftFingerprint,
      postSaveDraftFingerprint: fingerprintCanonicalJY200Draft(postSaveDraft),
      encryptedDraftFingerprint: fingerprintJY200DuoValue(finalEncrypted),
      resourceSetFingerprint: readback.resource_set_fingerprint,
      readback,
      ...(localCatalog ? {
        catalogBinding: finalCatalogBinding,
        executionReceiptFingerprint,
        executionBindingEvidenceFingerprint: executionReceipt.binding_evidence_fingerprint,
      } : {}),
    }
    const receipt = localCatalog
      ? createJY200DuoLocalCatalogLifecycleReceipt(receiptInput, integrityKey)
      : createJY200DuoDirectLifecycleReceipt(receiptInput, integrityKey)
    const evidenceRoot = path.join(runtime.dataRoot, 'evidence', localCatalog ? 'jy200-duo-local' : 'jy200-duo-direct')
    const receiptGeneration = localCatalog
      ? {
          draft_id_fingerprint: receipt.draft_id_fingerprint,
          build_digest: receipt.build_digest,
          binding_set_fingerprint: receipt.binding_set_fingerprint,
          current_evidence_fingerprint: receipt.current_evidence_fingerprint,
          execution_receipt_fingerprint: receipt.execution_receipt_fingerprint,
        }
      : { draft_id_fingerprint: receipt.draft_id_fingerprint, build_digest: receipt.build_digest }
    const output = path.join(evidenceRoot, `${fingerprintJY200DuoValue(canonicalJY200DuoJson(receiptGeneration))}.json`)
    const published = await publishReceipt({
      output,
      receipt,
      integrityKey,
      parseReceipt: localCatalog ? parseJY200DuoLocalCatalogLifecycleReceipt : parseJY200DuoDirectLifecycleReceipt,
    })
    return Object.freeze({
      ok: true,
      status: published.status,
      admission: published.admission,
      writerEligible: published.writer_eligible,
      provider: published.provider,
      externalResourceDependent: published.external_resource_dependent,
      catalogBound: published.catalog_bound,
      readback: published.readback,
      lifecycle: { opened: true, edited: true, saved: true, closed: true, reopened: true, sameDraft: true },
      evidenceFingerprint: sha256(Buffer.from(canonicalJY200DuoJson(published))),
    })
  } finally {
    await rm(temporaryRoot, { recursive: true, force: true })
  }
}

const main = async () => {
  try {
    process.stdout.write(`${JSON.stringify(await verifyJY200DuoDirectProbe())}\n`)
  } catch (error) {
    const reason = error instanceof Error && /^JY200_[A-Z0-9_]+$/u.test(error.message) ? error.message : 'JY200_DUO_LIFECYCLE_FAILED'
    process.stdout.write(`${JSON.stringify({ ok: false, status: 'deferred', admission: 'deferred', writerEligible: false, reason })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
