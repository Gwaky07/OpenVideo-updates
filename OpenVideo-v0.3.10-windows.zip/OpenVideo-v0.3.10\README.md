# OpenVideo Local Material Editor

本仓库用于开发“本地实拍素材 → 文案匹配画面 → 自动初剪 → 可编辑剪映草稿”的 OpenVideo 产品。

## 当前正式架构

```text
本地原始素材文件夹（只读）
→ OpenVideo 独立素材分析 provider（转录、场景索引、自然语言搜索）
→ OpenVideo LLM Gateway / AI Director / 白名单 AI Editor Agent
→ RichTimeline（唯一 immutable revision / fingerprint）
→ short-video-factory（preview MP4：切镜、配音、普通字幕、本地 BGM）
→ pyJianYingDraft（剪映多轨草稿：切镜、配音、字幕、本地 BGM 等已实现项）
```

对外能力声明必须以 `apps/gateway/src/editor-capability-registry.mjs` 为准。
滤镜、贴纸、命名特效等 registry 中为 `unsupported` 的能力不得宣传为已完成；Preview `degraded` 项不得宣称与剪映视觉等价。详见 `docs/RELEASE-NOTES-AI-EDITOR-MVP.md`。

OpenVideo 主仓库只保存自有前端、适配器、AI Director、数据契约、测试和部署配置；不复制第三方上游源码，不提交真实素材、索引、缓存、模型或密钥。

## 总项目根

`<OPENVIDEO_ROOT>` 是唯一项目根、Git 根、Codex 总控制台目录和 GitHub 推送目录。

正式主链第三方仓库只作为本地依赖放在被 Git 忽略的 `upstream/`：

- `upstream/short-video-factory`
- `upstream/pyJianYingDraft`

`upstream/edit-mind` 仅是开发期行为参考，不属于发行依赖，不会被启动器下载或启动。所有上游仓库默认只读，不属于 OpenVideo GitHub 提交或源码发行包。

## 当前阶段

产品路线已完成真实本地 MVP（`REL-001`）与后续发布修复链；当前滚动终点为 `REL-007 / AI-EDITOR-RELEASE`：固化自然语言 AI Editor MVP 的能力声明、安装/升级/回滚与许可证证据。

主链提供完整 OpenVideo 项目工作台：项目新建与总览、只读素材授权、扫描与分析状态、主题/标题/卖点/脚本/风格输入、分镜 Top 3 与替换、自然语言 Editor 微调、真实 preview MP4、剪映草稿导出、任务进度以及可恢复错误。公开宣传范围见 `docs/RELEASE-NOTES-AI-EDITOR-MVP.md`；剪映桌面打开与模板演示样片仍是发布硬门禁。

项目采用本地验收优先、阶段性推送 GitHub 的工作方式；GitHub Actions 仅为手动可选复核，不替代本地发布门禁。

## Windows 普通用户启动

同事先读根目录的 `先看这里.md`（英文系统读 `START-HERE.md`）。环境要求：Windows 10/11。下载当前私有 GitHub Release ZIP、完整解压并双击 `OpenVideo.cmd`；压缩包可放在任意电脑、任意目录。启动入口会先复用已安装的 Node.js LTS、Git 和 Windows Python Launcher 中登记的 `py -3.12`，仅在依赖确实缺失时通过 Windows Package Manager 补齐，并在本机获取、校验和构建固定正式 provider。

双击根目录的 `OpenVideo.cmd`。如果需要带产品 Logo 的桌面入口，先双击 `Create-OpenVideoShortcut.cmd`；它会在当前电脑桌面生成快捷方式，并自动使用当前解压目录，移动到另一台电脑后重新运行一次即可。工作台会直接打开，未配置 LLM 只禁用相关 AI 操作，不阻塞项目和非 AI 页面；Base URL、API Key 与模型统一在前端“模型设置”中填写并自动重启生效。日常使用不需要编辑 JSON、在终端输入密钥或执行开发命令，也不依赖 Docker Desktop、WSL 或 Compose。Gateway 会在 `127.0.0.1` 同源托管 Web 与 `/api/*`。

API Key 以 Windows CurrentUser DPAPI 密文随仓库外私有配置原子保存，浏览器不会读取或持久化明文。详细下载、首次配置、自动重启和故障恢复见 `README-WINDOWS.md`。当前交付是私有 GitHub Release 中的可执行源码 ZIP，不声称已经提供 MSI 安装器。

## Windows 开发者启动

如果对方要在自己电脑继续开发，推荐从 GitHub clone 私有仓库，而不是只下载 Release ZIP。Release ZIP 适合普通使用；`git clone` 会保留历史、分支、远端和后续 pull/push 能力。

首次开发环境准备：

```powershell
git clone https://github.com/Gwaky07/OpenVideo.git
cd OpenVideo
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/Setup-OpenVideoDeveloper.ps1 -RepositoryRoot . -InstallBrowsers
```

根目录只保留日常使用的 `OpenVideo.cmd`。开发环境准备不再提供第二个根目录启动器，请直接运行上面的 `scripts/Setup-OpenVideoDeveloper.ps1` 命令；它会复用普通启动器同一套 Node.js LTS、Git、Python 3.12 检查，安装 pnpm workspace 依赖，拉取并校验固定正式 provider，随后执行一次生产构建验证。`-InstallBrowsers` 会额外安装 Chromium 供 Playwright e2e 使用。

常用开发命令：

```powershell
pnpm dev          # Web-only Vite development
pnpm start:local  # Gateway 同源托管的完整本地工作台
pnpm test         # Gateway + Web tests
pnpm build        # Gateway + Web production build
pnpm test:e2e     # 浏览器 e2e；需要 Playwright Chromium
```

正式开发任务仍按 `AGENTS.md` 使用独立 `task/<TASK-ID>-<slug>` 分支和必要时的 git worktree；私有运行数据、API Key、真实素材、生成视频、索引、模型和日志都必须留在仓库外。

## 前端专项开发

环境要求：Node.js `>=22.22.0`、pnpm `11.9.0`。

```powershell
pnpm install --frozen-lockfile
pnpm dev
```

前端专项验收：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/Test-OpenVideoWeb.ps1 -RepositoryRoot .
```

开发态可使用 Vite；正式运行必须由 Gateway 同源托管生产构建。密钥和私有运行配置不得进入 Git。

## 完整本地验收

以下命令必须从总项目根执行：

```powershell
pnpm install --frozen-lockfile
pnpm lint
pnpm typecheck
pnpm test
pnpm build
pnpm test:e2e
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/Test-LocalAcceptance.ps1 -RepositoryRoot .
```

`pnpm test:e2e` 会启动合成 Gateway 与 Vite 服务，在 Chromium 中验证桌面、窄屏和完整新项目流程；截图写入被 Git 忽略的 `apps/web/test-results/`。合成验收不会读取真实素材、调用真实 LLM 提供商或打开剪映桌面端。

生产集成必须继续通过服务端同源 `/api/*` 边界接入真实能力。浏览器不得接收绝对素材路径、转录、缩略图、密钥、提供商配置、草稿输出路径或本机运行配置。

## 内部使用与许可证边界

- 当前私有 Release 可供仓库所有者授权的协作者在自己的 Windows 电脑使用；根包与两个工作区包仍标记为 `private`，仓库没有授予公众复制、修改或再分发权的根许可证文件。
- 在仓库所有者以后明确决定公开方式、选择 OpenVideo 项目许可证并完成法律复核前，不执行公开开源发布，也不把当前代码复制到公开发行包。
- `upstream/` 中的 short-video-factory 与 pyJianYingDraft 是本机外部正式依赖，不属于 OpenVideo Git 提交或源码发行包；Edit Mind 仅为开发参考。使用或分发前必须分别遵守固定版本许可证。
- 当前 `pnpm-lock.yaml` 的生产依赖许可证可通过 `pnpm licenses list --prod --json` 复核；新增或升级依赖必须重新执行该检查。
- 生产依赖漏洞可用 `pnpm audit --prod --audit-level high --registry https://registry.npmjs.org` 复核；显式指定官方 registry 是因为本机镜像不提供 npm audit endpoint。

## 文档入口

- AI Editor MVP 发布说明：`docs/RELEASE-NOTES-AI-EDITOR-MVP.md`
- Windows 使用说明：`README-WINDOWS.md`
- Windows 升级与回滚：`docs/WINDOWS-UPGRADE-ROLLBACK.md`
- 第三方 NOTICE：`docs/licenses/THIRD-PARTY-NOTICES.md`
- 滚动任务路线：`docs/tasks/ROADMAP.md`
- 当前任务状态：`docs/tasks/STATUS.json`
- 上游固定边界：`docs/UPSTREAM-DEPENDENCIES.md`
- 包装能力矩阵：`docs/architecture/PACKAGING-CAPABILITY-MATRIX.md`
- 仓库执行规则：`AGENTS.md`
- 总项目目标与阶段计划：`PROJECT-PLAN.md`
