/**
 * Clean-room structural probe for a private Jianying draft snapshot.
 *
 * The caller is responsible for obtaining a decoded snapshot through a
 * version-bound private codec. This module never opens a draft path, invokes
 * Jianying, or emits resource IDs, paths, text, or other leaf values. It is
 * intentionally useful before a packaging writer is admitted: the probe can
 * compare a source draft with a modified draft and report only structural
 * material/track deltas.
 */

const MAX_NODES = 100_000
const MAX_DEPTH = 48
const MAX_KEYS = 256
const MAX_COUNTER_KEYS = 256
const SAFE_KEY = /^[A-Za-z0-9_.-]{1,96}$/u

const FAMILY_ALIASES = new Map([
  ['effects', 'video_effect'], ['effect', 'video_effect'], ['video_effects', 'video_effect'],
  ['stickers', 'sticker'], ['sticker', 'sticker'],
  ['animations', 'video_animation'], ['material_animations', 'video_animation'],
  ['masks', 'mask'], ['mask', 'mask'],
  ['filters', 'filter'], ['filter', 'filter'],
  ['mix_modes', 'blend'], ['blend', 'blend'],
  ['text_effects', 'flower'], ['flower', 'flower'],
  ['bubbles', 'bubble'], ['bubble', 'bubble'],
  ['transitions', 'transition'], ['transition', 'transition'],
  ['audio_effects', 'audio_effect'], ['sfx', 'sfx'], ['bgm', 'bgm'],
])

/** @param {unknown} value */
const normalizeHint = (value) => {
  if (typeof value !== 'string') return null
  const key = value.trim().toLocaleLowerCase().replaceAll('-', '_').replaceAll(' ', '_')
  return FAMILY_ALIASES.get(key) ?? null
}

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} code @returns {never} */
const fail = (code) => { const error = /** @type {Error & {code: string}} */ (new Error(code)); error.code = code; throw error }

/** @param {number} value */
const bucket = (value) => value === 0 ? 'empty' : value === 1 ? 'one' : value <= 8 ? 'small' : value <= 64 ? 'medium' : 'large'

const createAccumulator = () => {
  /** @type {Map<string, number>} */
  const families = new Map()
  /** @type {Map<string, number>} */
  const arrays = new Map()
  /** @type {Map<string, number>} */
  const shapes = new Map()
  /** @type {Map<string, number>} */
  const tracks = new Map()
  /** @type {Map<string, number>} */
  const refs = new Map()
  let nodes = 0
  let documents = 0
  let truncated = false

  /** @param {Map<string, number>} map @param {string} key @param {number} [amount] */
  const inc = (map, key, amount = 1) => {
    if (!map.has(key) && map.size >= MAX_COUNTER_KEYS) {
      truncated = true
      return
    }
    map.set(key, (map.get(key) ?? 0) + amount)
  }
  /** @param {unknown} value @param {string | null} [hint] @param {number} [depth] */
  const observe = (value, hint = null, depth = 0) => {
    if (nodes >= MAX_NODES || depth > MAX_DEPTH) { truncated = true; return }
    nodes += 1
    if (Array.isArray(value)) {
      inc(arrays, bucket(value.length))
      if (value.length > MAX_KEYS) truncated = true
      const limit = Math.min(value.length, MAX_KEYS)
      for (let index = 0; index < limit; index += 1) observe(value[index], hint, depth + 1)
      return
    }
    if (!isRecord(value)) return
    const allKeys = Object.keys(value)
    const keys = allKeys.slice(0, MAX_KEYS)
    if (allKeys.length > MAX_KEYS) truncated = true
    const shape = keys.filter((key) => SAFE_KEY.test(key)).sort().join('|')
    if (shape) inc(shapes, shape.length <= 512 ? shape : 'large_shape')

    const typeHint = normalizeHint(value.type) ?? normalizeHint(value.category)
    const family = typeHint ?? hint
    if (family) inc(families, family)

    if (typeof value.name === 'string' && typeof value.type === 'string' && /track/u.test(value.type)) inc(tracks, normalizeHint(value.type) ?? 'other')
    for (const key of keys) {
      const child = value[key]
      const childHint = normalizeHint(key) ?? family
      if (key === 'resource_id' || key === 'resourceId' || key === 'effect_id' || key === 'effectId') {
        if (family) inc(refs, family)
        continue
      }
      observe(child, childHint, depth + 1)
    }
  }
  return {
    document(/** @type {unknown} */ value) { documents += 1; observe(value) },
    finish() {
      /** @param {Map<string, number>} map */
      const sorted = (map) => Object.freeze(Object.fromEntries([...map.entries()].sort(([a], [b]) => a.localeCompare(b))))
      return Object.freeze({
        schema_version: 1,
        documents,
        nodes,
        truncated,
        family_counts: sorted(families),
        resource_reference_counts: sorted(refs),
        track_type_counts: sorted(tracks),
        array_length_buckets: sorted(arrays),
        object_shape_counts: sorted(shapes),
      })
    },
  }
}

/** @param {unknown} snapshot */
export const inspectPrivateDraftStructure = (snapshot) => {
  if (!isRecord(snapshot) && !Array.isArray(snapshot)) fail('JY184_DRAFT_SNAPSHOT_INVALID')
  const accumulator = createAccumulator()
  accumulator.document(snapshot)
  return accumulator.finish()
}

/**
 * Compare two private snapshots. Only bounded structural counts are returned.
 * @param {{before: unknown, after: unknown, profileId: string, appVersion: string}} input
 */
export const comparePrivateDraftStructures = ({ before, after, profileId, appVersion }) => {
  if (typeof profileId !== 'string' || !/^jianying-[a-z0-9-]{1,60}$/u.test(profileId) ||
      typeof appVersion !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(appVersion)) {
    fail('JY184_DRAFT_PROFILE_INVALID')
  }
  const left = inspectPrivateDraftStructure(before)
  const right = inspectPrivateDraftStructure(after)
  /** @param {Readonly<Record<string, number>>} a @param {Readonly<Record<string, number>>} b */
  const delta = (a, b) => {
    const keys = new Set([...Object.keys(a), ...Object.keys(b)])
    return Object.freeze(Object.fromEntries([...keys].sort().map((key) => [key, (b[key] ?? 0) - (a[key] ?? 0)]).filter(([, value]) => value !== 0)))
  }
  return Object.freeze({
    schema_version: 1,
    before: left,
    after: right,
    delta: Object.freeze({
      family_counts: delta(left.family_counts, right.family_counts),
      resource_reference_counts: delta(left.resource_reference_counts, right.resource_reference_counts),
      track_type_counts: delta(left.track_type_counts, right.track_type_counts),
    }),
    bounded: right.truncated !== true && left.truncated !== true,
  })
}
