/**
 * Narrows a private catalog entry to the fields the Jianying writer needs. The caller must keep
 * this result inside the server-to-writer boundary; public contracts retain only opaque tokens.
 * @param {{kind: string, resourceId: string, effectId?: string}} resolved
 */
export const toJianyingPackagingResolution = (resolved) => ({
  kind: resolved.kind,
  resourceId: resolved.resourceId,
  ...(typeof resolved.effectId === 'string' ? { effectId: resolved.effectId } : {}),
})
