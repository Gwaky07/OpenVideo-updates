import { randomUUID } from 'node:crypto'
import { lstat, mkdir, readdir, readFile, realpath, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'

import {
  PACKAGING_RESOURCE_FAMILIES,
  assertSafePackagingText,
  computePackagingCatalogFingerprint,
  computePackagingResourceToken,
  createJianyingDesktopBinding,
} from './jianying-packaging-resource-index.mjs'
import { readFilesNoReparse } from './jianying-native-safe-file.mjs'

/** @typedef {{isDirectory: () => boolean, isFile: () => boolean, isSymbolicLink?: () => boolean, size?: number}} FileInfo */
/** @typedef {{name: string, isSymbolicLink: () => boolean, isFile?: () => boolean}} DirentLike */
const familySet = new Set(PACKAGING_RESOURCE_FAMILIES)
export const JY135_PRIVATE_RESOURCE_CATALOG_FILENAME = 'jy135-private-resource-catalog.json'
export const JY172_PRIVATE_PACKAGING_CATALOG_FILENAME = 'jy172-private-packaging-catalog.json'
// User-draft provider output is kept separate from the ordinary scanner
// candidate so a later metadata refresh cannot replace an authorized draft
// snapshot with unrelated local-resource results.
export const NATIVE018_PRIVATE_DRAFT_CATALOG_FILENAME = 'native018-private-draft-catalog.json'
const safeLabel = (/** @type {unknown} */ value) => {
  try { assertSafePackagingText(value, 'catalog_label', 160); return true } catch { return false }
}
const resourceId = /^[A-Za-z0-9_-]{4,160}$/u
const jsonFile = /\.json$/iu
const isRecord = (/** @type {unknown} */ value) => Boolean(value && typeof value === 'object' && !Array.isArray(value))

const familyAliases = new Map([
  ['text_effect', 'flower'], ['flower', 'flower'], ['text_bubble', 'bubble'], ['bubble', 'bubble'],
  ['sticker', 'sticker'], ['filter', 'filter'], ['video_effect', 'video_effect'], ['effect', 'video_effect'],
  ['video_animation', 'video_animation'], ['animation', 'video_animation'], ['mask', 'mask'],
  ['blend', 'blend'], ['mix_mode', 'blend'], ['transition', 'transition'], ['audio_effect', 'audio_effect'],
  ['text_animation', 'text_animation'], ['bgm', 'bgm'], ['sfx', 'sfx'],
])

const normalizeFamily = (/** @type {unknown} */ value) => {
  if (typeof value !== 'string') return null
  const normalized = value.trim().toLocaleLowerCase().replaceAll('-', '_').replaceAll(' ', '_')
  return familyAliases.get(normalized) ?? (familySet.has(normalized) ? normalized : null)
}

const bindingFor = (/** @type {string} */ family, /** @type {Record<string, any>} */ value, /** @type {{entity?: string, effectId?: string}|null} */ descriptor = null) => {
  const resource = value.resource_id ?? value.resourceId ?? value.id
  const effect = value.effect_id ?? value.effectId ?? descriptor?.effectId
  if (typeof resource !== 'string' || !resourceId.test(resource)) return null
  if ((family === 'flower' || family === 'bubble') && (typeof effect !== 'string' || !resourceId.test(effect))) return null
  if (family === 'video_effect') {
    const entity = descriptor?.entity ?? value.entity
    const validEffect = typeof effect === 'string' && resourceId.test(effect)
    return {
      resourceId: resource,
      ...(validEffect ? { effectId: effect } : {}),
      ...(validEffect && ['scene', 'character', 'generic'].includes(entity) ? { entity } : {}),
    }
  }
  if (family === 'video_animation') {
    const durationUs = Number(value.duration_us ?? value.durationUs ?? value.duration)
    if (!Number.isSafeInteger(durationUs) || durationUs <= 0 || durationUs > 10_000_000) return null
    return { resourceId: resource, durationUs }
  }
  if (family === 'mask') {
    const template = value.common_mask_template ?? value.commonMaskTemplate
    return template && typeof template === 'object' ? { resourceId: resource, commonMaskTemplate: structuredClone(template) } : null
  }
  return family === 'flower' || family === 'bubble'
    ? { resourceId: resource, effectId: effect }
    : { resourceId: resource }
}

const collectCandidates = (/** @type {unknown} */ value, /** @type {string|null} */ hint, /** @type {{family: string, label: string, private_binding: Record<string, any>}[]} */ output, /** @type {((candidate: Record<string, any>) => string|null)|undefined} */ classifyFamily, /** @type {string} */ root, depth = 0, /** @type {((candidate: Record<string, any>) => {family: string, label: string, entity?: string, effectId?: string}|null)|undefined} */ describeCandidate = undefined) => {
  if (depth > SCAN_LIMITS.maxJsonDepth) return
  if (Array.isArray(value)) {
    for (const item of value) collectCandidates(item, hint, output, classifyFamily, root, depth + 1, describeCandidate)
    return
  }
  if (!value || typeof value !== 'object') return
  const candidate = /** @type {Record<string, any>} */ (value)
  // With a pinned private-metadata classifier, self-reported JSON family
  // labels are untrusted hints and must not override its exact mapping.
  const classifiedFamily = classifyFamily ? normalizeFamily(classifyFamily(candidate)) : null
  const descriptor = describeCandidate?.(candidate) ?? null
  const descriptorFamily = descriptor ? normalizeFamily(descriptor.family) : null
  const family = classifyFamily
    ? (descriptor && classifiedFamily && descriptorFamily === classifiedFamily ? descriptorFamily : classifiedFamily)
    : normalizeFamily(candidate.family ?? candidate.type ?? candidate.category ?? hint)
  if (family) {
    const binding = bindingFor(family, candidate, descriptor)
    const label = typeof describeCandidate === 'function'
      ? descriptor?.label
      : candidate.name ?? candidate.title ?? candidate.label ?? candidate.effect_name
    if (binding && safeLabel(label)) output.push({ family, label: label.trim(), private_binding: binding })
  }
  for (const [key, child] of Object.entries(value)) {
    if (key === 'private_binding' || key === 'resource_id' || key === 'effect_id') continue
    collectCandidates(child, normalizeFamily(key) ?? family, output, classifyFamily, root, depth + 1, describeCandidate)
  }
}

const SCAN_LIMITS = Object.freeze({ maxDepth: 32, maxJsonDepth: 48, maxFiles: 4096, maxCandidates: 20000, maxFileBytes: 4 * 1024 * 1024 })
const SCAN_DIRECTORY_CONCURRENCY = 32
// Jianying resource IDs are decimal int64 values and commonly use all
// nineteen digits (for example 6981791065204331044).
const numericResourceDirectory = /^[1-9][0-9]{3,19}$/u
const isContained = (/** @type {string} */ root, /** @type {string} */ candidate) => candidate === root || candidate.startsWith(`${root}${path.sep}`)

/**
 * Jianying's managed effect cache stores the resource identity in the first
 * directory below the trusted bucket (for example `Cache/effect/<resource>`)
 * while config.json contains only implementation metadata. Recover that
 * identity for the pinned metadata classifier; the directory has already
 * passed the no-reparse/containment checks in the scanner walk.
 * @param {string} sourcePath @param {string} root
 * @returns {string|null}
 */
const inferResourceIdFromPath = (sourcePath, root) => {
  const relative = path.relative(path.resolve(root), path.resolve(sourcePath))
  if (!relative || path.isAbsolute(relative) || relative.startsWith('..')) return null
  const first = relative.split(path.sep, 1)[0]
  return numericResourceDirectory.test(first) ? first : null
}

/** @param {string} current @param {string|null} resolvedRoot @param {() => Promise<FileInfo>} inspect @param {() => Promise<string>} resolveReal */
const inspectSafe = async (current, resolvedRoot, inspect, resolveReal) => {
  const info = await inspect()
  if (info.isSymbolicLink?.()) throw new Error('JY135_REPARSE_POINT_REJECTED')
  const resolvedCurrent = await resolveReal()
  const containmentRoot = resolvedRoot ?? resolvedCurrent
  if (!isContained(containmentRoot, resolvedCurrent)) throw new Error('JY135_REPARSE_POINT_REJECTED')
  return { info, resolvedRoot: containmentRoot }
}

/** Scan only explicit private Jianying metadata roots into a private catalog. */
/** @param {{roots: readonly string[], profileId: string, appVersion: string, privateRootSetFingerprint?: string, desktop?: {profileId?: string, version?: string, executablePath?: string, installRoot?: string, dllFingerprint?: string}, classifyFamily?: (candidate: Record<string, any>) => string|null, describeCandidate?: (candidate: Record<string, any>) => {family: string, label: string, entity?: string, effectId?: string}|null, observeMetadata?: (value: unknown) => void, maxElapsedMs?: number, readFile?: typeof readFile, readFilesNoReparse?: typeof readFilesNoReparse, readdir?: typeof readdir, lstat?: typeof lstat, realpath?: typeof realpath}} input */
export const scanJianyingPrivateResourceCatalog = async ({ roots, profileId, appVersion, privateRootSetFingerprint = undefined, desktop = undefined, classifyFamily = undefined, describeCandidate = undefined, observeMetadata = undefined, maxElapsedMs = undefined, readFile: read = readFile, readFilesNoReparse: readNativeBatch = readFilesNoReparse, readdir: list = readdir, lstat: inspect = lstat, realpath: resolveReal = realpath }) => {
  if (!Array.isArray(roots) || roots.length === 0 || typeof profileId !== 'string' || typeof appVersion !== 'string') {
    throw new Error('JY135_SCAN_INPUT_INVALID')
  }
  if (privateRootSetFingerprint !== undefined && !/^[a-f0-9]{64}$/u.test(privateRootSetFingerprint)) {
    throw new Error('JY200_PRIVATE_ROOT_BINDING_INVALID')
  }
  const requestedElapsedMs = Number(maxElapsedMs)
  const boundedElapsedMs = Number.isSafeInteger(requestedElapsedMs) && requestedElapsedMs > 0 ? requestedElapsedMs : null
  const deadline = boundedElapsedMs === null ? null : Date.now() + boundedElapsedMs
  const assertWithinDeadline = () => {
    if (deadline !== null && Date.now() >= deadline) throw new Error('JY135_SCAN_TIMEOUT')
  }
  /** @type {{family: string, label: string, private_binding: Record<string, any>}[]} */
  const candidates = []
  /** @type {{path: string, rootPath: string, hint: string}[]} */
  const metadataFiles = []
  let fileCount = 0
  /** @typedef {{current: string, root: string, depth: number, resolvedRoot: string|null}} PendingScanNode */
  /** @param {PendingScanNode} node @returns {Promise<PendingScanNode[]>} */
  const inspectNode = async ({ current, root, depth, resolvedRoot }) => {
    assertWithinDeadline()
    if (depth > SCAN_LIMITS.maxDepth) throw new Error('JY135_SCAN_LIMIT_EXCEEDED')
    const inspected = await inspectSafe(current, resolvedRoot, () => inspect(current), () => resolveReal(current))
    const { info } = inspected
    if (info.isDirectory()) {
      const children = await list(current, { withFileTypes: true })
      if (children.length > SCAN_LIMITS.maxFiles - fileCount) throw new Error('JY135_SCAN_LIMIT_EXCEEDED')
      for (const name of /** @type {DirentLike[]} */ (children)) {
        assertWithinDeadline()
        if (name.isSymbolicLink()) continue
        // A real Dirent lets us avoid a no-reparse lstat for ordinary binary
        // assets. Directories and JSON metadata still go through visit(),
        // which preserves containment and reparse validation before parsing.
        if (name.isFile?.() && !jsonFile.test(name.name)) continue
        pending.push({ current: path.join(current, name.name), root, depth: depth + 1, resolvedRoot: inspected.resolvedRoot })
      }
      return []
    }
    if (!info.isFile() || !jsonFile.test(current)) return []
    fileCount += 1
    if (fileCount > SCAN_LIMITS.maxFiles) throw new Error('JY135_SCAN_LIMIT_EXCEEDED')
    if (typeof info.size === 'number' && info.size > SCAN_LIMITS.maxFileBytes) throw new Error('JY135_SCAN_LIMIT_EXCEEDED')
    metadataFiles.push({ path: current, rootPath: root, hint: path.basename(current, '.json') })
    return []
  }
  const collectRaw = (/** @type {string} */ raw, /** @type {string} */ hint, /** @type {string} */ root, /** @type {string} */ sourcePath) => {
    try {
      if (Buffer.byteLength(raw, 'utf8') > SCAN_LIMITS.maxFileBytes) throw new Error('JY135_SCAN_LIMIT_EXCEEDED')
      const parsed = JSON.parse(raw)
      observeMetadata?.(parsed)
      // Managed effect payloads commonly omit resource_id from config.json.
      // Feed a bounded synthetic identity only to the private classifier; the
      // resulting entry is still discovery-only until signed writer evidence.
      const inferredResourceId = inferResourceIdFromPath(sourcePath, root)
      const classifiedInput = inferredResourceId && isRecord(parsed) &&
        !Object.hasOwn(parsed, 'resource_id') && !Object.hasOwn(parsed, 'resourceId')
        ? { ...parsed, resource_id: inferredResourceId }
        : parsed
      collectCandidates(classifiedInput, hint, candidates, classifyFamily, root, 0, describeCandidate)
      if (candidates.length > SCAN_LIMITS.maxCandidates) throw new Error('JY135_SCAN_LIMIT_EXCEEDED')
    } catch (error) {
      if (error instanceof Error && error.message === 'JY135_SCAN_LIMIT_EXCEEDED') throw error
      /* ignore unrelated or encrypted metadata */
    }
  }
  /** @type {PendingScanNode[]} */
  const pending = []
  for (const root of roots) {
    assertWithinDeadline()
    if (typeof root !== 'string' || !path.isAbsolute(root)) throw new Error('JY135_SCAN_ROOT_INVALID')
    pending.push({ current: root, root, depth: 0, resolvedRoot: null })
  }
  let pendingOffset = 0
  while (pendingOffset < pending.length) {
    const batch = pending.slice(pendingOffset, pendingOffset + SCAN_DIRECTORY_CONCURRENCY)
    pendingOffset += batch.length
    await Promise.all(batch.map(inspectNode))
    assertWithinDeadline()
  }
  metadataFiles.sort((left, right) => left.path.localeCompare(right.path))
  const useNativeBatch = process.platform === 'win32' && read === readFile
  if (useNativeBatch && metadataFiles.length > 0) {
    let contents
    try {
      const timeoutMs = deadline === null ? undefined : Math.max(1, deadline - Date.now())
      contents = await readNativeBatch(metadataFiles.map(({ path, rootPath }) => ({ path, rootPath })), timeoutMs === undefined ? undefined : { timeoutMs })
      assertWithinDeadline()
    } catch (error) {
      if (error instanceof Error && error.message === 'JY135_SCAN_TIMEOUT') throw error
      throw new Error('JY135_NATIVE_READ_FAILED')
    }
    if (!Array.isArray(contents) || contents.length !== metadataFiles.length) throw new Error('JY135_NATIVE_READ_FAILED')
    for (let index = 0; index < contents.length; index += 1) {
      const content = /** @type {string} */ (Buffer.isBuffer(contents[index]) ? contents[index].toString('utf8') : contents[index])
      collectRaw(content, metadataFiles[index].hint, metadataFiles[index].rootPath, metadataFiles[index].path)
    }
  } else if (!useNativeBatch) {
    for (const file of metadataFiles) {
      assertWithinDeadline()
        try { collectRaw(await read(file.path, 'utf8'), file.hint, file.rootPath, file.path) } catch (error) {
        if (error instanceof Error && error.message === 'JY135_SCAN_LIMIT_EXCEEDED') throw error
        // Unreadable unrelated metadata is not catalog input outside production Windows.
      }
      assertWithinDeadline()
    }
  }
  const seen = new Set()
  const entries = candidates.flatMap(({ family, label, private_binding }) => {
    const packaging_token = computePackagingResourceToken({ family, profileId, appVersion, privateBinding: private_binding })
    if (seen.has(packaging_token)) return []
    seen.add(packaging_token)
    return [{ packaging_token, family, label, tags: ['local-scan'], state: 'discoverable', writer_eligible: false, private_binding }]
  })
  // Discovery-only scans may run before a desktop probe is available. Keep
  // the binding absent in that phase; production admission requires an exact
  // executable/install/DLL binding through isPackagingCatalogBoundToDesktop.
  const desktopBinding = desktop?.executablePath && desktop?.installRoot && desktop?.dllFingerprint
    ? createJianyingDesktopBinding(desktop)
    : undefined
  return Object.freeze({
    schema_version: 1,
    profile_id: profileId,
    app_version: appVersion,
    ...(desktopBinding ? { desktop_binding: desktopBinding } : {}),
    ...(privateRootSetFingerprint ? { private_root_set_fingerprint: privateRootSetFingerprint } : {}),
    catalog_fingerprint: computePackagingCatalogFingerprint({ profileId, appVersion, entries, desktopBinding, privateRootSetFingerprint }),
    entries,
  })
}

/** Persist the scanner result only inside the configured private runtime root. */
/** @param {{catalog: any, dataRoot: string, fileName?: string, writeFile?: typeof writeFile, mkdir?: typeof mkdir, rename?: typeof rename}} input */
export const persistJianyingPrivateResourceCatalog = async ({ catalog, dataRoot, fileName = JY135_PRIVATE_RESOURCE_CATALOG_FILENAME, writeFile: write = writeFile, mkdir: makeDir = mkdir, rename: move = rename }) => {
  if (!catalog || catalog.schema_version !== 1 || typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot)) {
    throw new Error('JY135_PERSIST_INPUT_INVALID')
  }
  if (![JY135_PRIVATE_RESOURCE_CATALOG_FILENAME, JY172_PRIVATE_PACKAGING_CATALOG_FILENAME, NATIVE018_PRIVATE_DRAFT_CATALOG_FILENAME].includes(fileName)) {
    throw new Error('JY172_CATALOG_FILENAME_INVALID')
  }
  const catalogRoot = path.join(path.resolve(dataRoot), 'catalogs')
  const target = path.join(catalogRoot, fileName)
  const temporary = `${target}.tmp-${randomUUID()}`
  await makeDir(catalogRoot, { recursive: true })
  try {
    await write(temporary, `${JSON.stringify(catalog)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await move(temporary, target)
  } catch (error) {
    try { await (await import('node:fs/promises')).rm(temporary, { force: true }) } catch { /* best effort cleanup */ }
    throw error
  }
  return Object.freeze({ ok: true, entries: catalog.entries.length, families: [...new Set(catalog.entries.map((/** @type {{family: string}} */ entry) => entry.family))] })
}
