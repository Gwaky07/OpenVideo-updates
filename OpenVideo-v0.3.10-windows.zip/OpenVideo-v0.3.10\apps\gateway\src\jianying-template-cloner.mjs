import { createHash, randomUUID } from 'node:crypto'
import {
  chmod,
  copyFile,
  lstat,
  mkdir,
  readdir,
  readFile,
  rename,
  rm,
  writeFile,
} from 'node:fs/promises'
import { isAbsolute, join, relative, resolve } from 'node:path'

import {
  collectJianyingNestedTextMaterialIds,
  isJianyingTextMaterialContent,
  jianyingTextMaterialContentString,
  locateJianyingMaterialById,
  resolveJianyingEditableTextMaterials,
} from './jianying-text-template.mjs'
import { replaceJianyingTextMaterialContent } from './replication-recipe.mjs'

export class JianyingTemplateCloneError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'JianyingTemplateCloneError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

const overlayIndex = (overlayId, role) => {
  const match = new RegExp(`^${role}:(\\d+)$`, 'u').exec(typeof overlayId === 'string' ? overlayId : '')
  if (!match) return null
  const index = Number.parseInt(match[1], 10)
  return Number.isSafeInteger(index) ? index : null
}

/** Numbered Jianying lanes such as `花字1` / `花字 2` still carry flower text. */
export const isJianyingFlowerTextTrackName = (name) =>
  /flower\s*text|花字|贴纸文字/iu.test(String(name ?? '').trim())

const isExactTitleTrackName = (name) =>
  /^(?:title|标题)$/iu.test(String(name ?? '').trim())

const isExactCaptionTrackName = (name) =>
  /^(?:subtitles|字幕)$/iu.test(String(name ?? '').trim())

/** Any non-caption/title text lane can carry template flower copy. */
export const isJianyingOverlayRichTextTrack = (track) =>
  Boolean(track) &&
  track.type === 'text' &&
  !isExactTitleTrackName(track.name) &&
  !isExactCaptionTrackName(track.name)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const fragment = relative(resolve(parent), resolve(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}
/** @param {unknown} value @param {string} [code] */
const absoluteFile = async (value, code = 'JY_TEMPLATE_CLONE_ASSET_INVALID') => {
  if (typeof value !== 'string' || !isAbsolute(value)) throw new JianyingTemplateCloneError(code, 400)
  const metadata = await lstat(value).catch(() => null)
  if (!metadata || !metadata.isFile() || metadata.isSymbolicLink()) {
    throw new JianyingTemplateCloneError(code, 409)
  }
  return resolve(value)
}

/** @param {string} source @param {string} target */
const copyTree = async (source, target) => {
  const metadata = await lstat(source).catch(() => null)
  if (!metadata || metadata.isSymbolicLink()) throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_SOURCE_INVALID', 409)
  if (metadata.isDirectory()) {
    await mkdir(target, { recursive: true, mode: 0o700 })
    const children = await readdir(source)
    for (const child of children) await copyTree(join(source, child), join(target, child))
    return
  }
  if (!metadata.isFile()) throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_SOURCE_INVALID', 409)
  await mkdir(resolve(target, '..'), { recursive: true, mode: 0o700 })
  await copyFile(source, target)
  await chmod(target, 0o600).catch(() => {})
}

/** @param {Record<string, any>} content */
const materialMap = (content) => {
  const materials = record(content.materials) ? content.materials : {}
  const map = new Map()
  for (const entries of Object.values(materials)) {
    if (!Array.isArray(entries)) continue
    for (const entry of entries) {
      if (record(entry) && typeof entry.id === 'string') map.set(entry.id, entry)
    }
  }
  return map
}

/** @param {unknown} value @param {(entry: string) => string} replaceString @returns {any} */
const replaceStrings = (value, replaceString) => {
  if (typeof value === 'string') return replaceString(value)
  if (Array.isArray(value)) return value.map((entry) => replaceStrings(entry, replaceString))
  if (!record(value)) return value
  return Object.fromEntries(
    Object.entries(value).map(([key, entry]) => [key, replaceStrings(entry, replaceString)]),
  )
}

/** @param {unknown} value @param {Set<string>} knownIds @param {Set<string>} found */
const collectKnownIds = (value, knownIds, found) => {
  if (typeof value === 'string') {
    if (knownIds.has(value)) found.add(value)
    return
  }
  if (Array.isArray(value)) {
    for (const entry of value) collectKnownIds(entry, knownIds, found)
    return
  }
  if (!record(value)) return
  for (const entry of Object.values(value)) collectKnownIds(entry, knownIds, found)
}

/** @param {Record<string, any>} timerange @param {number} scale @param {number} targetDurationUs */
const scaleTimerange = (timerange, scale, targetDurationUs) => {
  if (!record(timerange) || !Number.isSafeInteger(timerange.duration)) return timerange
  const start = Number.isSafeInteger(timerange.start) ? timerange.start : 0
  const scaledStart = Math.max(0, Math.min(targetDurationUs - 1, Math.round(start * scale)))
  const scaledDuration = Math.max(
    1,
    Math.min(targetDurationUs - scaledStart, Math.round(timerange.duration * scale)),
  )
  return { ...timerange, start: scaledStart, duration: scaledDuration }
}

/** @param {string} materialId @param {number} startUs @param {number} durationUs */
const templateTextSlotId = (materialId, startUs, durationUs) =>
  `txt-${createHash('sha256').update(`${materialId}\u0000${startUs}\u0000${durationUs}`).digest('hex').slice(0, 24)}`

/** @param {string} prefix @param {unknown[]} parts */
const stableOverlayId = (prefix, parts) =>
  `${prefix}_${createHash('sha256').update(parts.map((part) => String(part ?? '')).join('\u0000')).digest('hex').slice(0, 28)}`

/** Project copy stays exactly as authored. Template line breaks are style, not a rewrite rule. */
const visibleFlowerText = (nextText) => String(nextText ?? '').trim()

/** @param {Record<string, any>} materials @param {unknown} materialId */
const locateTextMaterial = (materials, materialId) => {
  const located = locateJianyingMaterialById(materials, materialId)
  if (!located || !isJianyingTextMaterialContent(located.entry.content)) return null
  return located
}

/**
 * Overlay packaging tracks from a private blueprint onto an already generated
 * draft. Existing video, narration, BGM and captions remain authoritative.
 * @param {{blueprintFolder: string, draftFolder: string, targetDurationUs: number, textReplacements?: Array<string | {text: string, slot?: 'rich' | 'title' | 'caption', slotId?: string, trackName?: string, segmentIndex?: number, targetStartUs?: number, targetDurationUs?: number}>, reuseOverflowRichText?: boolean}} input
 */
export const overlayJianyingTemplatePackaging = async ({
  blueprintFolder,
  draftFolder,
  targetDurationUs,
  textReplacements = [],
  reuseOverflowRichText = true,
  effectAssignments = [],
  stickerAssignments = [],
}) => {
  if (!isAbsolute(blueprintFolder) || !isAbsolute(draftFolder) || !Number.isSafeInteger(targetDurationUs) || targetDurationUs <= 0) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_OVERLAY_INPUT_INVALID', 400)
  }
  const blueprintPath = join(resolve(blueprintFolder), 'draft_content.json')
  const draftPath = join(resolve(draftFolder), 'draft_content.json')
  let blueprint
  let draft
  try {
    blueprint = JSON.parse(await readFile(blueprintPath, 'utf8'))
    draft = JSON.parse(await readFile(draftPath, 'utf8'))
  } catch {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_OVERLAY_STRUCTURE_INVALID', 409)
  }
  if (!record(blueprint) || !record(draft) || !Array.isArray(blueprint.tracks) || !Array.isArray(draft.tracks)) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_OVERLAY_STRUCTURE_INVALID', 409)
  }
  const packagingTracks = blueprint.tracks.filter((/** @type {any} */ track) => {
    if (!record(track) || !Array.isArray(track.segments)) return false
    const name = typeof track.name === 'string' ? track.name : ''
    if (track.type === 'text') {
      return track.segments.length > 0
    }
    return track.type === 'sticker' || track.type === 'effect'
  })
  if (packagingTracks.length === 0) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_OVERLAY_EMPTY', 409)
  }
  const sourceMaterials = record(blueprint.materials) ? blueprint.materials : {}
  const materialById = new Map()
  for (const [arrayName, entries] of Object.entries(sourceMaterials)) {
    if (!Array.isArray(entries)) continue
    for (const entry of entries) {
      if (record(entry) && typeof entry.id === 'string') materialById.set(entry.id, { arrayName, entry })
    }
  }
  const knownIds = new Set(materialById.keys())
  const requiredIds = new Set()
  for (const track of packagingTracks) collectKnownIds(track, knownIds, requiredIds)
  let changed = true
  while (changed) {
    changed = false
    for (const id of [...requiredIds]) {
      const found = new Set()
      collectKnownIds(materialById.get(id)?.entry, knownIds, found)
      for (const dependency of found) {
        if (!requiredIds.has(dependency)) {
          requiredIds.add(dependency)
          changed = true
        }
      }
    }
  }
  const idMap = new Map([...requiredIds].map((id) => [id, `ov_${createHash('sha256').update(id).digest('hex').slice(0, 28)}`]))
  const mappedMaterialIds = new Set(idMap.values())
  /** @param {string} value */
  const replaceId = (value) => idMap.get(value) ?? value
  const duration = Number.isSafeInteger(blueprint.duration) && blueprint.duration > 0
    ? blueprint.duration
    : targetDurationUs
  const scale = targetDurationUs / duration
  /** @type {Map<string, Record<string, any>>} */
  const textSegmentsBySlotId = new Map()
  let danglingReferenceCount = 0
  const copiedTracks = packagingTracks.map((track, trackIndex) => {
    const copied = /** @type {Record<string, any>} */ (replaceStrings(track, replaceId))
    copied.id = stableOverlayId('ov_track', [track.id, trackIndex, track.type, track.name])
    if (isJianyingOverlayRichTextTrack(track) && (typeof copied.name !== 'string' || !copied.name.trim())) {
      copied.name = 'FlowerText'
    }
    copied.segments = copied.segments.map((/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => {
      const copiedSegment = /** @type {Record<string, any>} */ ({
        ...segment,
        id: stableOverlayId('ov_segment', [track.id, trackIndex, track.type, track.name, segment.id, index]),
        target_timerange: scaleTimerange(segment.target_timerange, scale, targetDurationUs),
      })
      if (Array.isArray(copiedSegment.extra_material_refs)) {
        const retainedReferences = copiedSegment.extra_material_refs.filter((/** @type {unknown} */ reference) =>
          typeof reference === 'string' && mappedMaterialIds.has(reference))
        danglingReferenceCount += copiedSegment.extra_material_refs.length - retainedReferences.length
        copiedSegment.extra_material_refs = retainedReferences
      }
      const sourceSegment = track.segments[index]
      const sourceMaterialId = typeof sourceSegment?.material_id === 'string' ? sourceSegment.material_id : null
      const sourceRange = record(sourceSegment?.target_timerange) ? sourceSegment.target_timerange : null
      const sourceStart = Number.isSafeInteger(sourceRange?.start) ? sourceRange.start : 0
      if (
        track.type === 'text' &&
        sourceMaterialId &&
        sourceStart >= 0 &&
        Number.isSafeInteger(sourceRange?.duration) &&
        sourceRange.duration > 0
      ) {
        const slotId = templateTextSlotId(sourceMaterialId, sourceStart, sourceRange.duration)
        if (textSegmentsBySlotId.has(slotId)) {
          throw new JianyingTemplateCloneError('JY_TEMPLATE_OVERLAY_SLOT_DUPLICATE', 409)
        }
        textSegmentsBySlotId.set(slotId, copiedSegment)
      }
      return copiedSegment
    })
    return copied
  })
  const nextMaterials = record(draft.materials) ? draft.materials : {}
  const existingMaterialIds = new Set()
  for (const entries of Object.values(nextMaterials)) {
    if (!Array.isArray(entries)) continue
    for (const entry of entries) {
      if (record(entry) && typeof entry.id === 'string') existingMaterialIds.add(entry.id)
    }
  }
  if ([...idMap.values()].some((id) => existingMaterialIds.has(id))) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_OVERLAY_ID_COLLISION', 409)
  }
  const appendedMaterials = new Set()
  for (const id of requiredIds) {
    const source = materialById.get(id)
    if (!source) continue
    if (!Array.isArray(nextMaterials[source.arrayName])) nextMaterials[source.arrayName] = []
    const copiedMaterial = replaceStrings(source.entry, replaceId)
    nextMaterials[source.arrayName].push(copiedMaterial)
    appendedMaterials.add(copiedMaterial)
  }
  const richTextTracks = copiedTracks.filter((track) => isJianyingOverlayRichTextTrack(track))
  const titleTextTracks = copiedTracks.filter((track) =>
    track.type === 'text' && isExactTitleTrackName(track.name))
  const captionTextTracks = copiedTracks.filter((track) =>
    track.type === 'text' && isExactCaptionTrackName(track.name))
  // Freeze the authored style pool before generated segments are appended;
  // otherwise a newly cloned segment would become the next cycle's source.
  const authoredTextOf = (/** @type {string | undefined} */ materialId, extraIds = []) => {
    const material = resolveJianyingEditableTextMaterials(nextMaterials, materialId, extraIds)[0]
    const content = record(material) ? jianyingTextMaterialContentString(material) : null
    if (typeof content !== 'string') return ''
    try {
      const parsed = JSON.parse(content)
      return record(parsed) && typeof parsed.text === 'string' ? parsed.text : ''
    } catch {
      return ''
    }
  }
  const richSourcePool = richTextTracks.flatMap((/** @type {Record<string, any>} */ track) =>
    track.segments.map((/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => ({
      track,
      segment,
      index,
      sourceText: authoredTextOf(segment.material_id, segment.extra_material_refs),
    })),
  )
  const captionSourcePool = captionTextTracks.flatMap((/** @type {Record<string, any>} */ track) =>
    track.segments.map((/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => ({ track, segment, index })),
  )
  let replacementIndex = 0
  const usedTextSegments = new Set()
  const appliedRichReplacementIndexes = new Set()
  /** @type {Array<{start: number, duration: number}>} */
  const appliedRichRanges = []
  const applyReplacement = (
    /** @type {Record<string, any>} */ track,
    /** @type {Record<string, any>} */ segment,
    /** @type {Record<string, any>} */ replacement,
  ) => {
    if (!record(segment) || typeof replacement?.text !== 'string' || !replacement.text.trim()) return
      const hasTargetStart = Object.hasOwn(replacement, 'targetStartUs')
      const hasTargetDuration = Object.hasOwn(replacement, 'targetDurationUs')
      if (hasTargetStart !== hasTargetDuration) {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_RANGE_INVALID', 409)
      }
      if (
        hasTargetStart &&
        (!Number.isSafeInteger(replacement.targetStartUs) ||
          !Number.isSafeInteger(replacement.targetDurationUs) ||
          replacement.targetStartUs < 0 ||
          replacement.targetDurationUs <= 0 ||
          replacement.targetStartUs + replacement.targetDurationUs > targetDurationUs)
      ) {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_RANGE_INVALID', 409)
      }
      const materialsToRewrite = resolveJianyingEditableTextMaterials(
        nextMaterials,
        segment.material_id,
        Array.isArray(segment.extra_material_refs) ? segment.extra_material_refs : [],
      )
      if (materialsToRewrite.length === 0) {
        throw Object.assign(new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 409), {
          materialId: typeof segment.material_id === 'string' ? segment.material_id : null,
          stage: 'apply-replacement',
        })
      }
      const nextStart = hasTargetStart
        ? replacement.targetStartUs
        : segment.target_timerange?.start
      const nextDuration = hasTargetDuration
        ? replacement.targetDurationUs
        : segment.target_timerange?.duration
      if (
        replacement.slot === 'rich' &&
        appliedRichRanges.some((range) =>
          Number.isSafeInteger(nextStart) &&
          Number.isSafeInteger(nextDuration) &&
          nextStart < range.start + range.duration &&
          range.start < nextStart + nextDuration)
      ) {
        return
      }
      const nextVisible = replacement.slot === 'rich'
        ? visibleFlowerText(replacement.text)
        : replacement.text
      for (const material of materialsToRewrite) {
        const currentContent = jianyingTextMaterialContentString(material)
        if (typeof currentContent !== 'string') {
          throw Object.assign(new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 409), {
            materialId: typeof segment.material_id === 'string' ? segment.material_id : null,
            stage: 'apply-replacement',
          })
        }
        const replaced = replaceJianyingTextMaterialContent(currentContent, nextVisible)
        if (replaced === null) throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_JSON_INVALID', 409)
        material.content = replaced
      }
      // Only the visible string changes. Authored clip.scale, transform, and
      // styles[].size stay on the copied FlowerText / Subtitles material.
      if (hasTargetStart) {
        segment.target_timerange = {
          start: replacement.targetStartUs,
          duration: replacement.targetDurationUs,
        }
      }
      usedTextSegments.add(segment)
      if (
        replacement.slot === 'rich' &&
        Number.isSafeInteger(segment.target_timerange?.start) &&
        Number.isSafeInteger(segment.target_timerange?.duration) &&
        segment.target_timerange.duration > 0
      ) {
        appliedRichRanges.push({
          start: segment.target_timerange.start,
          duration: segment.target_timerange.duration,
          text: nextVisible,
        })
      }
  }

  // A source draft can expose fewer FlowerText segments than the current
  // script needs. Reuse the copied template segment/material pair by adding a
  // new segment instance; this keeps the real template animation/effect while
  // allowing every generated highlight to receive a visual slot.
  const cloneRichSegment = (/** @type {{track: Record<string, any>, segment: Record<string, any>, replacementIndex: number}} */ { track, segment, replacementIndex }) => {
    const cloned = structuredClone(segment)
    cloned.id = stableOverlayId('ov_segment_reuse', [
      track.id,
      segment.id,
      replacementIndex,
      cloned.material_id,
    ])
    // A Jianying text material is mutable JSON. Reusing the same material ID
    // would make each later replacement overwrite every earlier FlowerText
    // segment. Give every generated slot its own material while retaining the
    // copied template content, style, and animation references.
    const materialLocation = locateJianyingMaterialById(nextMaterials, cloned.material_id)
    if (!materialLocation?.entry) {
      throw Object.assign(new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 409), {
        materialId: typeof cloned.material_id === 'string' ? cloned.material_id : null,
        stage: 'clone-rich-segment',
      })
    }
    const copiedMaterial = structuredClone(materialLocation.entry)
    copiedMaterial.id = stableOverlayId('ov_material_reuse', [
      copiedMaterial.id,
      track.id,
      segment.id,
      replacementIndex,
    ])
    const nestedIds = [
      ...collectJianyingNestedTextMaterialIds(copiedMaterial),
      ...(Array.isArray(cloned.extra_material_refs) ? cloned.extra_material_refs : []),
    ].filter((id, index, ids) => typeof id === 'string' && ids.indexOf(id) === index)
    /** @type {Map<string, string>} */
    const nestedIdMap = new Map()
    for (const nestedId of nestedIds) {
      const nestedLocation = locateTextMaterial(nextMaterials, nestedId)
      if (!nestedLocation?.entry) {
        if (collectJianyingNestedTextMaterialIds(copiedMaterial).includes(nestedId)) {
          throw Object.assign(new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 409), {
            materialId: nestedId,
            stage: 'clone-rich-segment',
          })
        }
        continue
      }
      const copiedNested = structuredClone(nestedLocation.entry)
      copiedNested.id = stableOverlayId('ov_material_reuse_text', [
        copiedNested.id,
        copiedMaterial.id,
        track.id,
        segment.id,
        replacementIndex,
      ])
      if (!Array.isArray(nextMaterials.texts)) nextMaterials.texts = []
      nextMaterials.texts.push(copiedNested)
      appendedMaterials.add(copiedNested)
      nestedIdMap.set(nestedId, copiedNested.id)
    }
    const remapNestedId = (/** @type {unknown} */ value) =>
      typeof value === 'string' && nestedIdMap.has(value) ? nestedIdMap.get(value) : value
    const remappedMaterial = replaceStrings(copiedMaterial, remapNestedId)
    remappedMaterial.id = copiedMaterial.id
    if (Array.isArray(cloned.extra_material_refs)) {
      cloned.extra_material_refs = cloned.extra_material_refs.map((reference) =>
        typeof reference === 'string' && nestedIdMap.has(reference) ? nestedIdMap.get(reference) : reference)
    }
    nextMaterials[materialLocation.arrayName].push(remappedMaterial)
    appendedMaterials.add(remappedMaterial)
    cloned.material_id = remappedMaterial.id
    track.segments.push(cloned)
    return { track, segment: cloned, index: track.segments.length - 1 }
  }
  for (const [inputIndex, replacement] of textReplacements.entries()) {
    if (typeof replacement === 'string') {
      let remaining = replacementIndex
      replacementIndex += 1
      for (const track of copiedTracks) {
        if (track.type !== 'text') continue
        if (remaining >= track.segments.length) {
          remaining -= track.segments.length
          continue
        }
        applyReplacement(track, track.segments[remaining], { text: replacement })
        break
      }
      continue
    }
    if (!record(replacement) || typeof replacement.text !== 'string' || !replacement.text.trim()) continue
    const candidates = replacement.slot === 'rich'
      ? richTextTracks
      : replacement.slot === 'title'
        ? titleTextTracks
        : replacement.slot === 'caption'
          ? captionTextTracks
          : copiedTracks.filter((track) => track.type === 'text')
    const eligible = (typeof replacement.trackName === 'string'
      ? candidates.filter((candidate) => candidate.name === replacement.trackName)
      : candidates)
      .flatMap((/** @type {Record<string, any>} */ track) => track.segments.map((/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => ({ track, segment, index })))
      .filter((/** @type {{track: Record<string, any>, segment: Record<string, any>, index: number}} */ candidate) =>
        !usedTextSegments.has(candidate.segment) &&
        (!Number.isSafeInteger(replacement.segmentIndex) || replacement.segmentIndex === candidate.index))
    const replacementSlotId = typeof replacement.slotId === 'string' ? replacement.slotId : null
    let target = replacementSlotId !== null
      ? eligible.find((/** @type {{segment: Record<string, any>}} */ candidate) => textSegmentsBySlotId.get(replacementSlotId) === candidate.segment)
      : eligible[0]
    /** @type {{sourceText?: string} | null} */
    let overflowSource = null
    if (!target && (replacement.slot === 'rich' || replacement.slot === 'caption') && reuseOverflowRichText) {
      // The canonical timeline may carry the public logical slot labels
      // (`template-rich-1` ...), while the imported blueprint only exposes
      // private material/range-derived slot ids. Preserve the authored style
      // by resolving those labels to the corresponding source slot ordinal.
      // Exact private ids still take precedence when a blueprint supplies
      // them, and overflow continues to cycle the immutable style pool.
      const overflowPool = replacement.slot === 'caption' ? captionSourcePool : richSourcePool
      const logicalSlotMatch = replacementSlotId !== null
        ? /^template-rich-(\d+)$/iu.exec(replacementSlotId)
        : null
      const logicalSlotIndex = logicalSlotMatch
        ? Number.parseInt(logicalSlotMatch[1], 10) - 1
        : null
      const source = replacementSlotId !== null
        ? textSegmentsBySlotId.get(replacementSlotId)
          ? overflowPool.find((candidate) => textSegmentsBySlotId.get(replacementSlotId) === candidate.segment)
          : logicalSlotIndex !== null && Number.isSafeInteger(logicalSlotIndex) && logicalSlotIndex >= 0 && overflowPool.length > 0
            ? overflowPool[logicalSlotIndex % overflowPool.length]
            : overflowPool.length > 0
              ? overflowPool[inputIndex % overflowPool.length]
              : null
        : overflowPool.length > 0
          ? overflowPool[inputIndex % overflowPool.length]
          : null
      if (source) {
        overflowSource = source
        target = cloneRichSegment({ ...source, replacementIndex: inputIndex })
      }
    }
    if (!target) {
      // A bound FlowerText draft cannot silently drop project copy. Extra
      // captions may stay on the generated lane; unmatched rich text must
      // fail closed instead of shipping sticker-only packaging.
      if (replacement.slot === 'rich') {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_RICH_TEXT_SLOT_UNAVAILABLE', 409)
      }
      continue
    }
    applyReplacement(target.track, target.segment, {
      ...replacement,
      ...(typeof overflowSource?.sourceText === 'string' ? { authoredText: overflowSource.sourceText } : {}),
    })
    if (replacement.slot === 'rich') appliedRichReplacementIndexes.add(inputIndex)
  }
  const placeAssignedLooks = (tracks, hits, assignments, role) => {
    const pool = tracks.map((track) => ({
      track,
      segment: Array.isArray(track.segments) ? track.segments[0] : null,
    })).filter((item) => item.segment)
    for (const track of tracks) track.segments = []
    if (!Array.isArray(assignments) || assignments.length === 0 || pool.length === 0) return
    for (const [index, assignment] of assignments.entries()) {
      const sourceIndex = overlayIndex(assignment.overlayId, role)
      const source = Number.isSafeInteger(sourceIndex) ? pool[sourceIndex] : null
      if (!source) continue
      const hit = Array.isArray(hits)
        ? hits.find((range) => range.text === assignment.text)
        : null
      const start = Number.isSafeInteger(assignment.targetStartUs)
        ? assignment.targetStartUs
        : hit?.start
      const duration = Number.isSafeInteger(assignment.targetDurationUs)
        ? assignment.targetDurationUs
        : hit?.duration
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(duration) || duration <= 0) continue
      const cloned = structuredClone(source.segment)
      cloned.id = stableOverlayId('ov_segment_packaging', [
        source.track.id,
        source.segment.id,
        role,
        index,
        start,
        duration,
      ])
      cloned.target_timerange = { start, duration }
      source.track.segments.push(cloned)
    }
  }
  // Stickers and video effects stay unused unless the model named a current
  // shot target. Draft order and name matching never place them.
  placeAssignedLooks(
    copiedTracks.filter((track) => track.type === 'effect'),
    appliedRichRanges,
    effectAssignments,
    'effect',
  )
  placeAssignedLooks(
    copiedTracks.filter((track) => track.type === 'sticker'),
    [],
    stickerAssignments,
    'sticker',
  )
  // Template text is content, not merely decoration. A segment without an
  // explicit project binding must not carry the template's former copy into
  // a newly delivered draft. Unused style-pool cards are dropped.
  const copiedMaterialIds = new Set([
    ...idMap.values(),
    ...[...appendedMaterials].map((entry) => entry?.id),
  ].filter((id) => typeof id === 'string'))
  /** @type {Record<string, any>[]} */
  const retainedTracks = copiedTracks.flatMap((track) => {
    if (track.type !== 'text') {
      return Array.isArray(track.segments) && track.segments.length > 0 ? [track] : []
    }
    const segments = track.segments.filter((/** @type {Record<string, any>} */ segment) => usedTextSegments.has(segment))
    return segments.length > 0 ? [{ ...track, segments }] : []
  })
  copiedTracks.length = 0
  copiedTracks.push(...retainedTracks)
  const copiedMaterialById = new Map([...appendedMaterials].map((entry) => [entry.id, entry]))
  const retainedMaterialIds = new Set()
  for (const track of copiedTracks) collectKnownIds(track, copiedMaterialIds, retainedMaterialIds)
  changed = true
  while (changed) {
    changed = false
    for (const id of [...retainedMaterialIds]) {
      const found = new Set()
      collectKnownIds(copiedMaterialById.get(id), copiedMaterialIds, found)
      for (const dependency of found) {
        if (!retainedMaterialIds.has(dependency)) {
          retainedMaterialIds.add(dependency)
          changed = true
        }
      }
    }
  }
  requiredIds.clear()
  for (const [sourceId, copiedId] of idMap) {
    if (retainedMaterialIds.has(copiedId)) requiredIds.add(sourceId)
  }
  for (const [arrayName, entries] of Object.entries(nextMaterials)) {
    if (!Array.isArray(entries)) continue
    nextMaterials[arrayName] = entries.filter((entry) =>
      !appendedMaterials.has(entry) || retainedMaterialIds.has(entry?.id))
  }
  draft.materials = nextMaterials
  draft.tracks.push(...copiedTracks)
  const richReplacementIndexes = [...appliedRichReplacementIndexes]
  const bytes = Buffer.from(JSON.stringify(draft, null, 2), 'utf8')
  await writeFile(draftPath, bytes, { mode: 0o600 })
  return {
    outputFingerprint: createHash('sha256').update(bytes).digest('hex'),
    trackCount: copiedTracks.length,
    materialCount: requiredIds.size,
    danglingReferenceCount,
    richReplacementIndexes,
  }
}

/**
 * Clone a private plaintext Jianying blueprint while retaining all proprietary
 * material references. Only explicitly supplied video/audio/text bindings are
 * changed. The result remains private and is never returned as a public DTO.
 * @param {{
 *   sourceFolder: string,
 *   destinationFolder: string,
 *   videoAssets?: Array<{path: string, segmentIndex?: number, sourceStartUs?: number}>,
 *   audioAssets?: Array<{path: string, trackName?: string, trackIndex?: number, segmentIndex?: number}>,
 *   textReplacements?: Array<{text: string, trackName?: string, segmentIndex?: number}>,
 * }} input
 */
export const cloneJianyingDraft = async ({
  sourceFolder,
  destinationFolder,
  videoAssets = [],
  audioAssets = [],
  textReplacements = [],
}) => {
  if (!isAbsolute(sourceFolder) || !isAbsolute(destinationFolder)) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_SOURCE_INVALID', 400)
  }
  const source = resolve(sourceFolder)
  const destination = resolve(destinationFolder)
  if (source === destination || !inside(resolve(destination, '..'), destination)) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_DESTINATION_INVALID', 400)
  }
  const sourceStat = await lstat(source).catch(() => null)
  if (!sourceStat?.isDirectory() || sourceStat.isSymbolicLink()) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_SOURCE_INVALID', 409)
  }
  if (await lstat(destination).catch(() => null)) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_OUTPUT_CONFLICT', 409)
  }
  if (!Array.isArray(videoAssets) || !Array.isArray(audioAssets) || !Array.isArray(textReplacements)) {
    throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_INPUT_INVALID', 400)
  }
  const temporary = resolve(resolve(destination, '..'), `.openvideo-clone-${randomUUID()}`)
  try {
    await copyTree(source, temporary)
    const contentPath = join(temporary, 'draft_content.json')
    const content = JSON.parse(await readFile(contentPath, 'utf8'))
    if (!record(content) || !Array.isArray(content.tracks)) {
      throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_STRUCTURE_INVALID', 409)
    }
    const materials = materialMap(content)
    const videoTracks = content.tracks.filter((/** @type {any} */ track) => record(track) && track.type === 'video')
    const audioTracks = content.tracks.filter((/** @type {any} */ track) => record(track) && track.type === 'audio')
    const textTracks = content.tracks.filter((/** @type {any} */ track) => record(track) && track.type === 'text')

    for (const [index, binding] of videoAssets.entries()) {
      const path = await absoluteFile(binding?.path)
      const segmentIndex = Number.isSafeInteger(binding?.segmentIndex)
        ? /** @type {number} */ (binding.segmentIndex)
        : index
      const segment = videoTracks[0]?.segments?.[segmentIndex]
      if (!record(segment) || typeof segment.material_id !== 'string') {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_VIDEO_SLOT_INVALID', 409)
      }
      const material = materials.get(segment.material_id)
      if (!material) throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_STRUCTURE_INVALID', 409)
      material.path = path
      const sourceStartUs = Number.isSafeInteger(binding.sourceStartUs)
        ? /** @type {number} */ (binding.sourceStartUs)
        : null
      if (sourceStartUs !== null && sourceStartUs >= 0) {
        if (!record(segment.source_timerange)) segment.source_timerange = { start: 0, duration: segment.target_timerange?.duration || 1 }
        segment.source_timerange.start = sourceStartUs
      }
    }
    for (const [index, binding] of audioAssets.entries()) {
      const path = await absoluteFile(binding?.path)
      const track = typeof binding.trackName === 'string'
        ? audioTracks.find((/** @type {any} */ candidate) => candidate.name === binding.trackName)
        : audioTracks[Number.isSafeInteger(binding.trackIndex)
          ? /** @type {number} */ (binding.trackIndex)
          : 0]
      const segmentIndex = Number.isSafeInteger(binding?.segmentIndex)
        ? /** @type {number} */ (binding.segmentIndex)
        : index
      const segment = track?.segments?.[segmentIndex]
      if (!record(segment) || typeof segment.material_id !== 'string') {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_AUDIO_SLOT_INVALID', 409)
      }
      const material = materials.get(segment.material_id)
      if (!material) throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_STRUCTURE_INVALID', 409)
      material.path = path
    }
    for (const [index, replacement] of textReplacements.entries()) {
      const track = typeof replacement.trackName === 'string'
        ? textTracks.find((/** @type {any} */ candidate) => candidate.name === replacement.trackName)
        : textTracks[0]
      const segmentIndex = Number.isSafeInteger(replacement?.segmentIndex)
        ? /** @type {number} */ (replacement.segmentIndex)
        : index
      const segment = track?.segments?.[segmentIndex]
      if (!record(segment) || typeof segment.material_id !== 'string' || typeof replacement.text !== 'string' || !replacement.text.trim()) {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 400)
      }
      const materialsToRewrite = resolveJianyingEditableTextMaterials(
        content.materials,
        segment.material_id,
        Array.isArray(segment.extra_material_refs) ? segment.extra_material_refs : [],
      )
      if (materialsToRewrite.length === 0) {
        throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 409)
      }
      for (const material of materialsToRewrite) {
        const current = jianyingTextMaterialContentString(material)
        if (typeof current !== 'string') {
          throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_SLOT_INVALID', 409)
        }
        const next = replaceJianyingTextMaterialContent(current, replacement.text)
        if (next === null) throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_TEXT_JSON_INVALID', 409)
        material.content = next
      }
    }
    const outputBytes = Buffer.from(JSON.stringify(content, null, 2), 'utf8')
    await writeFile(contentPath, outputBytes, { mode: 0o600 })
    await rename(temporary, destination)
    return {
      draftId: destination.split(/[\\/]/u).pop() || null,
      outputFingerprint: createHash('sha256').update(outputBytes).digest('hex'),
      sourceBlueprintCloned: true,
    }
  } catch (error) {
    await rm(temporary, { recursive: true, force: true }).catch(() => {})
    if (error instanceof JianyingTemplateCloneError) throw error
    throw new JianyingTemplateCloneError('JY_TEMPLATE_CLONE_FAILED', 502)
  }
}
