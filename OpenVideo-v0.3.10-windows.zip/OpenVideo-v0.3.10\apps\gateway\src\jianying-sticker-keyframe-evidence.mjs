import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingDraftDecryptor } from './jianying-draft-decrypt.mjs'
import { protectSecretWithDpapi, unprotectSecretWithDpapi } from './llm-settings.mjs'

const integrityRevision = 'jy113-sticker-keyframe-evidence-v1'
const signaturePattern = /^[A-Za-z0-9_-]{43}$/u
const integrityKeyFilename = 'integrity-key.json'

/** @type {Readonly<Record<string, string>>} */
const admittedProfiles = Object.freeze({
  'jianying-11-2-provisional': '11.2.0.14339',
})

/** @param {Record<string, any>} evidence */
const unsignedEvidence = (evidence) => {
  const { integrity_revision: _revision, integrity_signature: _signature, ...unsigned } = evidence
  return unsigned
}

/** @param {unknown} value @returns {string} */
const canonicalEvidence = (value) => {
  if (Array.isArray(value)) return `[${value.map(canonicalEvidence).join(',')}]`
  if (!value || typeof value !== 'object') return JSON.stringify(value)
  const record = /** @type {Record<string, unknown>} */ (value)
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${canonicalEvidence(record[key])}`).join(',')}}`
}

/** @param {Record<string, any>} evidence @param {string} key */
export const signJianyingStickerKeyframeEvidence = (evidence, key) =>
  createHmac('sha256', key).update(canonicalEvidence(unsignedEvidence(evidence))).digest('base64url')

/** @param {string} catalogFingerprint @param {string} resourceId @param {string} key */
/** @param {Record<string, any>} evidence @param {string} key */
export const verifyJianyingStickerKeyframeEvidenceSignature = (evidence, key) => {
  if (typeof key !== 'string' || !/^[a-f0-9]{64}$/u.test(key) || !signaturePattern.test(evidence?.integrity_signature ?? '')) return false
  const expected = signJianyingStickerKeyframeEvidence(evidence, key)
  return timingSafeEqual(Buffer.from(expected), Buffer.from(evidence.integrity_signature))
}

/** @param {string} evidenceRoot */
export const resolveJianyingStickerKeyframeIntegrityKeyPath = (evidenceRoot) => path.resolve(evidenceRoot, integrityKeyFilename)

/**
 * A missing or malformed key is never silently replaced at admission time.
 * Only the evidence generator may create the per-user DPAPI-protected key.
 * @param {{evidenceRoot: string, create?: boolean, protect?: (input: {secret: string, revision: string}) => Promise<string>, unprotect?: (input: {protectedSecret: string, revision: string}) => Promise<string | null>}} input
 */
export const loadJianyingStickerKeyframeIntegrityKey = async ({ evidenceRoot, create = false, protect = protectSecretWithDpapi, unprotect = unprotectSecretWithDpapi }) => {
  const keyPath = resolveJianyingStickerKeyframeIntegrityKeyPath(evidenceRoot)
  let record
  try { record = JSON.parse(await readFile(keyPath, 'utf8')) } catch (error) {
    const fileError = /** @type {{code?: string}} */ (error)
    if (fileError?.code !== 'ENOENT' || !create) throw new Error('JY113_EVIDENCE_INTEGRITY_KEY_REQUIRED')
    const key = randomBytes(32).toString('hex')
    const protectedKey = await protect({ secret: key, revision: integrityRevision })
    if (typeof protectedKey !== 'string' || protectedKey.length === 0) throw new Error('JY113_EVIDENCE_INTEGRITY_KEY_PROTECT_FAILED')
    await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
    const temporary = `${keyPath}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
    try {
      await writeFile(temporary, `${JSON.stringify({ schema_version: 1, kind: 'jy113_sticker_key_integrity', revision: integrityRevision, protected_key: protectedKey })}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
      await rename(temporary, keyPath)
    } finally { await rm(temporary, { force: true }) }
    return key
  }
  if (!record || Object.keys(record).sort().join('\0') !== ['schema_version', 'kind', 'revision', 'protected_key'].sort().join('\0') || record.schema_version !== 1 || record.kind !== 'jy113_sticker_key_integrity' || record.revision !== integrityRevision || typeof record.protected_key !== 'string') throw new Error('JY113_EVIDENCE_INTEGRITY_KEY_INVALID')
  const key = await unprotect({ protectedSecret: record.protected_key, revision: integrityRevision })
  if (typeof key !== 'string' || !/^[a-f0-9]{64}$/u.test(key)) throw new Error('JY113_EVIDENCE_INTEGRITY_KEY_INVALID')
  return key
}

/** @param {unknown} value @param {{profileId: string, version: string}} desktop @param {string} catalogFingerprint */
export const parseJianyingStickerKeyframeEvidence = (value, desktop, catalogFingerprint) => {
  /** @type {any} */ const candidate = value
  const keys = ['schema_version', 'manual_evidence_verified', 'manual_attestation', 'profile_id', 'app_version', 'catalog_fingerprint', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'matching_keyframe_count', 'temporary_media_cleaned', 'draft_id', 'target_start_us', 'target_duration_us', 'keyframe_ids', 'pre_open_fingerprint', 'post_save_fingerprint', 'integrity_revision', 'integrity_signature']
  /** @type {Array<{id?: unknown, offset_us?: unknown, value?: unknown}>} */
  const keyframeIds = Array.isArray(candidate?.keyframe_ids) ? candidate.keyframe_ids : []
  if (!candidate || Object.keys(candidate).sort().join('\0') !== keys.sort().join('\0') || candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true || candidate.manual_attestation !== 'opened-edited-saved-reopened' || admittedProfiles[desktop.profileId] !== desktop.version || candidate.profile_id !== desktop.profileId || candidate.app_version !== desktop.version || candidate.catalog_fingerprint !== catalogFingerprint || !/^[a-f0-9]{64}$/u.test(catalogFingerprint) || candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true || candidate.matching_keyframe_count !== 2 || candidate.temporary_media_cleaned !== true || typeof candidate.draft_id !== 'string' || !/^OpenVideo-JY113-sticker-keyframe-[0-9]{10,20}$/u.test(candidate.draft_id) || !Number.isSafeInteger(candidate.target_start_us) || candidate.target_start_us !== 0 || !Number.isSafeInteger(candidate.target_duration_us) || candidate.target_duration_us !== 4_000_000 || keyframeIds.length !== 2 || keyframeIds.some((point, index) => typeof point?.id !== 'string' || !/^[a-f0-9]{32}$/u.test(point.id) || point.offset_us !== (index === 0 ? 500_000 : 1_000_000) || point.value !== (index === 0 ? 1 : 1.4)) || !/^[a-f0-9]{64}$/u.test(candidate.pre_open_fingerprint) || !/^[a-f0-9]{64}$/u.test(candidate.post_save_fingerprint) || candidate.pre_open_fingerprint === candidate.post_save_fingerprint || candidate.integrity_revision !== integrityRevision || !signaturePattern.test(candidate.integrity_signature)) return null
  return Object.freeze({ ...candidate, keyframe_ids: Object.freeze(keyframeIds.map((point) => Object.freeze({ ...point }))) })
}

/** @param {Record<string, any>} content @param {Readonly<Record<string, any>>} evidence */
export const matchesJianyingStickerKeyframeDraft = (content, evidence) => {
  const tracks = Array.isArray(content?.tracks) ? content.tracks : []
  const segments = tracks.filter((/** @type {any} */ track) => track?.name === 'sticker-1').flatMap((/** @type {any} */ track) => Array.isArray(track.segments) ? track.segments : [])
  /** @type {(point: any, index: number) => boolean} */
  const pointMatches = (point, index) => point && point.id === evidence.keyframe_ids[index].id && (point.time_offset === evidence.keyframe_ids[index].offset_us || point.timeOffset === evidence.keyframe_ids[index].offset_us) && point.values?.[0] === evidence.keyframe_ids[index].value
  return segments.filter((/** @type {any} */ segment) => (segment?.target_timerange?.start ?? 0) === evidence.target_start_us && segment?.target_timerange?.duration === evidence.target_duration_us && Array.isArray(segment?.common_keyframes) && segment.common_keyframes.filter((/** @type {any} */ list) => list?.property_type === 'KFTypeScaleX').length === 1 && (() => { const points = segment.common_keyframes.find((/** @type {any} */ list) => list?.property_type === 'KFTypeScaleX')?.keyframe_list; return Array.isArray(points) && points.length === 2 && pointMatches(points[0], 0) && pointMatches(points[1], 1) })()).length === 1
}

/**
 * Admission verifies mutable evidence against the current encrypted draft every
 * time the production process starts. A signed record alone is never enough.
 * @param {{evidence: unknown, desktop: {profileId: string, version: string, draftRoot: string, installRoot: string, dllFingerprint?: string}, catalogFingerprint: string, integrityKey: string, readEncrypted?: (file: string) => Promise<Buffer>, decrypt?: (input: {encryptedPath: string, plaintextPath: string}) => Promise<{scheme?: string, decryptedFrom?: string}>, readPlaintext?: (file: string) => Promise<string>}} input
 */
export const verifyJianyingStickerKeyframeEvidence = async ({ evidence, desktop, catalogFingerprint, integrityKey, readEncrypted = readFile, decrypt, readPlaintext = (file) => readFile(file, 'utf8') }) => {
  const parsed = parseJianyingStickerKeyframeEvidence(evidence, desktop, catalogFingerprint)
  if (!parsed || !verifyJianyingStickerKeyframeEvidenceSignature(parsed, integrityKey)) return false
  const draftFolder = path.resolve(desktop.draftRoot, parsed.draft_id)
  if (path.dirname(draftFolder) !== path.resolve(desktop.draftRoot)) return false
  const encryptedPath = path.join(draftFolder, 'draft_content.json')
  let encrypted
  try { encrypted = await readEncrypted(encryptedPath) } catch { return false }
  if (createHash('sha256').update(encrypted).digest('hex') !== parsed.post_save_fingerprint) return false
  const inspectRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy113-runtime-verify-'))
  try {
    const plaintextPath = path.join(inspectRoot, 'draft_content.json')
    const result = decrypt
      ? await decrypt({ encryptedPath, plaintextPath })
      : await createJianyingDraftDecryptor({
        installRoot: desktop.installRoot,
        appVersion: desktop.version,
        expectedDllFingerprint: desktop.dllFingerprint,
      }).ensurePlaintextFile(encryptedPath, plaintextPath)
    const decryptResult = /** @type {{scheme?: string, decryptedFrom?: string}} */ (result)
    if (decryptResult?.scheme !== 'encrypt_v2' && decryptResult?.decryptedFrom !== 'encrypt_v2') return false
    return matchesJianyingStickerKeyframeDraft(JSON.parse(await readPlaintext(plaintextPath)), parsed)
  } catch { return false } finally { await rm(inspectRoot, { recursive: true, force: true }) }
}

export { integrityRevision }
