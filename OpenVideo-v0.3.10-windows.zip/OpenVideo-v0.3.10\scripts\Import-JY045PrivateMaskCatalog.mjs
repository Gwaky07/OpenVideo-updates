import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import { promisify } from 'node:util'
import path from 'node:path'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'

const run = promisify(execFile)
const main = async () => {
  const root = loadLocalRuntimeConfig().dataRoot
  const moduleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  const { stdout } = await run('python', ['-c', 'import pyJianYingDraft as d, json; x=next(iter(d.MaskType)); print(json.dumps({"resource_id":x.value.resource_id},ensure_ascii=False))'], { env: { ...process.env, PYTHONPATH: moduleRoot }, windowsHide: true })
  const upstream = JSON.parse(stdout)
  const lease = JSON.parse(await readFile(path.join(root, 'evidence', 'jy045-mask', 'pending.json'), 'utf8'))
  const manifest = (await import('../config/jianying-compatibility.json', { with: { type: 'json' } })).default
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), 'openvideo-jy045-catalog-'))
  let template
  try {
    const temp = path.join(tempRoot, 'manual-baseline.json')
    const decryptor = createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
    await decryptor.ensurePlaintextFile(path.join(lease.draftRoot, lease.draftId, 'draft_content.json'), temp)
    const content = JSON.parse(await readFile(temp, 'utf8'))
    template = content?.materials?.common_mask?.[0]
  } finally {
    await rm(tempRoot, { recursive: true, force: true })
  }
  if (!template || typeof template !== 'object' || typeof template.resource_id !== 'string' || !template.config || typeof template.config.width !== 'number' || typeof template.config.height !== 'number') throw new Error('JY045_MANUAL_MASK_BASELINE_MISSING')
  const entry = {
    capability_id: 'mask.video.named',
    mask_token: `ovjmask_v2_${createHash('sha256').update(upstream.resource_id).digest('hex')}`,
    display_name: template.name,
    resource_id: template.resource_id,
    common_mask_template: template,
  }
  const catalog = { schema_version: 2, kind: 'jy045_mask_catalog', catalog_version: '2.0.0', entries: [entry] }
  catalog.catalog_fingerprint = createHash('sha256').update(JSON.stringify(catalog)).digest('hex')
  await writeFile(path.join(root, 'catalogs', 'jy045-mask-catalog.json'), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(JSON.stringify({ ok: true, capability: entry.capability_id, manual_baseline: true }) + '\n')
}
main().catch(error => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY045_CATALOG_FAILED' }) + '\n'); process.exitCode = 1 })
