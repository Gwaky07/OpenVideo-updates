import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import { readFileNoReparse } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { loadPackagingResourceEvidenceIntegrityKey } from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { readLatestJY200DuoTechnicalLifecycleReceipt } from '../apps/gateway/src/jianying-duo-current-admission.mjs'
import {
  createJY200DuoProductAdmissionReceipt,
  publishJY200DuoProductAdmissionReceipt,
} from '../apps/gateway/src/jianying-duo-product-admission.mjs'
import { createJianyingWriterPublicationRepository } from '../apps/gateway/src/jianying-writer-publication-repository.mjs'

const repositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const jobArgument = process.argv.findIndex((entry) => entry === '--job-id')
const jobId = jobArgument >= 0 ? process.argv[jobArgument + 1] : null

if (typeof jobId !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}$/u.test(jobId)) {
  throw new Error('JY200_DUO_PRODUCT_ADMISSION_JOB_REQUIRED')
}

const runtime = await loadLauncherRuntimeConfig({ repositoryRoot })
const manifest = JSON.parse(await readFile(path.join(repositoryRoot, 'config', 'duo-video-upstream.json'), 'utf8'))
const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({
  evidenceRoot: path.join(runtime.dataRoot, 'evidence', 'jy132-packaging-resources'),
})
const lifecycle = await readLatestJY200DuoTechnicalLifecycleReceipt(runtime.dataRoot)
if (!lifecycle || !Object.hasOwn(lifecycle, 'execution_receipt')) {
  throw new Error('JY200_DUO_PRODUCT_ADMISSION_LIFECYCLE_REQUIRED')
}
const publicationRepository = await createJianyingWriterPublicationRepository({
  dataRoot: runtime.dataRoot,
  repositoryRoot,
})
const publicationRecord = await publicationRepository.getPrivate(jobId)
if (!publicationRecord) throw new Error('JY200_DUO_PRODUCT_ADMISSION_PUBLICATION_REQUIRED')
const timelineStore = JSON.parse(await readFileNoReparse(
  path.join(runtime.dataRoot, 'rich-timelines.json'), runtime.dataRoot, 32 * 1024 * 1024,
))
const matchingTimelines = Array.isArray(timelineStore?.revisions)
  ? timelineStore.revisions.filter((/** @type {Record<string, any>} */ timeline) =>
    timeline?.status === 'finalized' && timeline?.revisionFingerprint === publicationRecord.timelineFingerprint)
  : []
if (matchingTimelines.length !== 1) throw new Error('JY200_DUO_PRODUCT_ADMISSION_TIMELINE_REQUIRED')

const receipt = createJY200DuoProductAdmissionReceipt({
  lifecycleReceipt: lifecycle,
  executionReceipt: lifecycle.execution_receipt,
  publicationRecord,
  richTimeline: matchingTimelines[0],
  manifest,
}, integrityKey)
const result = await publishJY200DuoProductAdmissionReceipt({
  dataRoot: runtime.dataRoot,
  receipt,
  integrityKey,
})

process.stdout.write(`${JSON.stringify({
  provider: result.provider,
  admission: result.admission,
  writer_eligible: result.writer_eligible,
  receipt_fingerprint: result.receipt_fingerprint,
  remote_resources: 'denied',
})}\n`)
