import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'

import {
  extractBlueprintAssets,
  listIngestibleAudio,
  pickIngestibleAudio,
} from './template-blueprint-assets.mjs'
import {
  applyPackagingSegmentsToReplicationRecipe,
  applyTextPackagingToReplicationRecipe,
  bindLocalAudioToReplicationRecipe,
  bindVoiceProfileToReplicationRecipe,
  createReplicationRecipeFromJianyingDraft,
  isReplicationRecipe,
} from './replication-recipe.mjs'

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Older approved recipes were learned before FlowerText track names and
 * overlay stickers became authoritative. Rebuild from the immutable
 * blueprint so refresh / editable-revision / first ingest all share one path.
 * @param {Record<string, any>} recipe
 * @param {string} draftFolder
 */
const normalizeAuthoredDecorations = (recipe) => {
  if (recipe.source?.kind !== 'jianying_draft') return recipe
  const textSegments = Array.isArray(recipe.textSegments)
    ? recipe.textSegments.map((segment) => (
      segment.role === 'rich_text' && (segment.decorationKind === null || segment.decorationKind === undefined)
        ? { ...segment, decorationKind: 'flower' }
        : segment
    ))
    : recipe.textSegments
  return { ...recipe, textSegments }
}

const rebuildJianyingDraftRecipe = async (recipe, draftFolder) => {
  if (recipe.source?.kind !== 'jianying_draft') return recipe
  const contentPath = join(draftFolder, 'draft_content.json')
  if (!existsSync(contentPath)) return normalizeAuthoredDecorations(recipe)
  let content
  try {
    content = JSON.parse(await readFile(contentPath, 'utf8'))
  } catch {
    return normalizeAuthoredDecorations(recipe)
  }
  if (!record(content)) return normalizeAuthoredDecorations(recipe)
  let rebuilt
  try {
    rebuilt = createReplicationRecipeFromJianyingDraft({
      blueprintId: recipe.source.blueprintId,
      fingerprint: recipe.source.fingerprint,
      content,
    })
  } catch {
    // Partial or inspect-sanitized blueprints still receive asset binding.
    // Never fail a later template refresh because one draft cannot rebuild.
    return normalizeAuthoredDecorations(recipe)
  }
  const previousCues = Array.isArray(recipe.audioCues) ? recipe.audioCues : []
  const preserved = {
    bgmAudioToken: previousCues.find((cue) =>
      cue.role === 'bgm' && typeof cue.audioToken === 'string')?.audioToken ?? null,
    sfxBindings: previousCues
      .filter((cue) => cue.role === 'sfx' && typeof cue.audioToken === 'string')
      .map((cue) => ({
        startUs: cue.startUs,
        durationUs: cue.durationUs,
        audioToken: cue.audioToken,
      })),
  }
  let next = rebuilt
  const missingBoundCues = previousCues.filter((cue) => {
    if (typeof cue.audioToken !== 'string' || !cue.audioToken) return false
    return !next.audioCues.some((candidate) =>
      candidate.role === cue.role &&
      candidate.startUs === cue.startUs &&
      candidate.durationUs === cue.durationUs)
  })
  if (missingBoundCues.length > 0) {
    next = {
      ...next,
      audioCues: [...next.audioCues, ...missingBoundCues].sort((left, right) => {
        const roles = { voiceover: 0, bgm: 1, sfx: 2 }
        return (roles[left.role] ?? 99) - (roles[right.role] ?? 99) || left.startUs - right.startUs
      }),
    }
  }
  if (preserved.bgmAudioToken || preserved.sfxBindings.length > 0) {
    next = bindLocalAudioToReplicationRecipe(next, preserved)
  }
  if (typeof recipe.voiceProfileId === 'string' && recipe.voiceProfileId) {
    next = bindVoiceProfileToReplicationRecipe(next, recipe.voiceProfileId)
  }
  return next
}

/**
 * Auto-ingest draft-local BGM/SFX and bind opaque packaging tokens onto a recipe.
 * Public recipe stays path-/resource_id-free; private map lives in template-media-store.
 *
 * Always rebuild Jianying draft recipes from the current blueprint first.
 * That keeps flower decorations, overlay stickers, and audio windows current
 * for every later template, not only the draft that first exposed a gap.
 * @param {{
 *   recipe: Record<string, any>,
 *   draftFolder: string,
 *   libraryTemplateId: string,
 *   templateMediaStore: {
 *     ingestAudio: Function,
 *     writePackagingMap: Function,
 *   },
 *   env?: NodeJS.ProcessEnv,
 * }} input
 */
export const applyBlueprintAssetsToRecipe = async ({
  recipe,
  draftFolder,
  libraryTemplateId,
  templateMediaStore,
  env = process.env,
}) => {
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  if (
    !templateMediaStore ||
    typeof templateMediaStore.ingestAudio !== 'function' ||
    typeof templateMediaStore.writePackagingMap !== 'function'
  ) {
    throw new Error('TEMPLATE_MEDIA_UNAVAILABLE')
  }

  let next = await rebuildJianyingDraftRecipe(recipe, draftFolder)
  const extracted = await extractBlueprintAssets({ draftFolder, env })

  /** @type {{ bgmAudioToken?: string | null, sfxBindings?: Array<{ startUs: number, durationUs: number, audioToken: string }> }} */
  const audioTokens = {}
  const bgm = pickIngestibleAudio(extracted.audioCandidates, 'bgm')
  if (bgm?.absolutePath) {
    const ingested = await templateMediaStore.ingestAudio(libraryTemplateId, {
      sourcePath: bgm.absolutePath,
      role: 'bgm',
    })
    audioTokens.bgmAudioToken = ingested.audioToken
  }
  /** @type {Array<{ startUs: number, durationUs: number, audioToken: string }>} */
  const sfxBindings = []
  for (const candidate of listIngestibleAudio(extracted.audioCandidates, 'sfx')) {
    const ingested = await templateMediaStore.ingestAudio(libraryTemplateId, {
      sourcePath: candidate.absolutePath,
      role: 'sfx',
    })
    sfxBindings.push({
      startUs: candidate.startUs,
      durationUs: candidate.durationUs,
      audioToken: ingested.audioToken,
    })
  }
  if (sfxBindings.length > 0) audioTokens.sfxBindings = sfxBindings
  if (Object.keys(audioTokens).length > 0) {
    next = bindLocalAudioToReplicationRecipe(next, audioTokens)
  }

  /** @type {Array<Record<string, any>>} */
  const packagingMap = []
  /** @type {Array<{ packagingToken: string, role: 'sticker' | 'effect', startUs: number, durationUs: number }>} */
  const packagingSegments = []
  /** @type {Array<{ packagingToken: string, decorationKind: 'flower' | 'bubble', startUs: number, durationUs: number }>} */
  const textPackagingBindings = []
  for (const entry of extracted.packagingPrivate) {
    if (!record(entry) || typeof entry.resourceId !== 'string') continue
    const kind = ['sticker', 'effect', 'flower', 'bubble'].includes(entry.kind)
      ? entry.kind
      : null
    if (!kind) continue
    const digest = createHash('sha256')
      .update(`${kind}\u0000${entry.effectId ?? ''}\u0000${entry.resourceId}\u0000${entry.startUs}\u0000${entry.durationUs}`)
      .digest('hex')
    const packagingToken = `pkg_${kind}_${digest.slice(0, 24)}`
    packagingMap.push({
      token: packagingToken,
      kind,
      resourceId: entry.resourceId,
      ...(['bubble', 'effect'].includes(kind) && typeof entry.effectId === 'string'
        ? { effectId: entry.effectId }
        : {}),
      fingerprint: digest,
    })
    if (kind === 'flower' || kind === 'bubble') {
      textPackagingBindings.push({
        packagingToken,
        decorationKind: kind,
        ...(typeof entry.slotId === 'string' ? { slotId: entry.slotId } : {}),
        startUs: entry.startUs,
        durationUs: entry.durationUs,
      })
    } else {
      packagingSegments.push({
        packagingToken,
        role: kind,
        startUs: entry.startUs,
        durationUs: entry.durationUs,
      })
    }
  }
  // Newer Jianying drafts store authored FlowerText motion as a nested
  // sticker_animation material. Bind the real nested resource to the same
  // text slot so the writer can resolve it without falling back to captions.
  for (const entry of extracted.templateTextAnimations) {
    if (
      !record(entry) ||
      typeof entry.animationResourceId !== 'string' ||
      !/^[A-Za-z0-9_-]{4,80}$/u.test(entry.animationResourceId)
    ) continue
    const digest = createHash('sha256')
      .update(`flower\u0000${entry.animationResourceId}\u0000${entry.startUs}\u0000${entry.durationUs}`)
      .digest('hex')
    const packagingToken = `pkg_flower_${digest.slice(0, 24)}`
    packagingMap.push({
      token: packagingToken,
      kind: 'flower',
      resourceId: entry.animationResourceId,
      effectId: entry.animationResourceId,
      fingerprint: digest,
    })
    textPackagingBindings.push({
      packagingToken,
      decorationKind: 'flower',
      ...(typeof entry.slotId === 'string' ? { slotId: entry.slotId } : {}),
      startUs: entry.startUs,
      durationUs: entry.durationUs,
    })
  }
  if (packagingMap.length > 0) {
    await templateMediaStore.writePackagingMap(libraryTemplateId, packagingMap)
    if (packagingSegments.length > 0) {
      next = applyPackagingSegmentsToReplicationRecipe(next, packagingSegments)
    }
    if (textPackagingBindings.length > 0) {
      next = applyTextPackagingToReplicationRecipe(next, textPackagingBindings)
    }
  }

  return {
    recipe: next,
    audioReady: {
      bgm: Boolean(audioTokens.bgmAudioToken),
      sfx: Boolean(audioTokens.sfxBindings?.length),
    },
    packagingCount: packagingSegments.length + textPackagingBindings.length,
  }
}
