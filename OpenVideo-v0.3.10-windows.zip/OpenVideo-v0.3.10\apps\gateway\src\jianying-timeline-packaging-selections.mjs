const familyByCapability = Object.freeze({
  'text.flower.private': 'flower',
  'sticker.named': 'sticker',
  'effect.video.named': 'video_effect',
})

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {string} family @param {unknown} token */
const validToken = (family, token) => typeof token === 'string' &&
  new RegExp(`^ovj${family}_v1_[a-z0-9_-]{1,96}$`, 'u').test(token)

/** @typedef {{packagingToken: string, family: string, label?: string, targetSegmentId?: string | null}} TimelinePackagingSelection */

/**
 * Read the opaque packaging resources actually present in a canonical
 * RichTimeline. Current revisions declare them in source.packagingSelections;
 * older Agent revisions may retain only the segment-level token that the
 * Writer consumes, so those segments are the stronger fallback authority.
 * @param {unknown} timeline
 * @returns {readonly TimelinePackagingSelection[]}
 */
export const readTimelinePackagingSelections = (timeline) => {
  if (!isRecord(timeline)) return Object.freeze([])
  /** @type {Map<string, Record<string, any>>} */
  const declaredByToken = new Map()
  for (const selection of Array.isArray(timeline.source?.packagingSelections)
    ? timeline.source.packagingSelections
    : []) {
    if (typeof selection?.family === 'string' && validToken(selection.family, selection.packagingToken)) {
      declaredByToken.set(selection.packagingToken, selection)
    }
  }
  const primarySegments = (Array.isArray(timeline.tracks) ? timeline.tracks : [])
    .filter((track) => track?.enabled !== false && track?.kind === 'video' && track?.role === 'primary')
    .flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
  /** @param {unknown} range */
  const targetFor = (range) => {
    if (!isRecord(range) || !Number.isSafeInteger(range.startUs) || !Number.isSafeInteger(range.durationUs)) return null
    const endUs = range.startUs + range.durationUs
    const matches = primarySegments.filter((segment) => isRecord(segment?.targetRange) &&
      segment.targetRange.startUs < endUs &&
      range.startUs < segment.targetRange.startUs + segment.targetRange.durationUs)
    return matches.length === 1 && typeof matches[0].segmentId === 'string' ? matches[0].segmentId : null
  }
  /** @type {Map<string, TimelinePackagingSelection>} */
  const inline = new Map()
  for (const track of Array.isArray(timeline.tracks) ? timeline.tracks : []) {
    if (!isRecord(track) || track.enabled === false || !Array.isArray(track.segments)) continue
    for (const segment of track.segments) {
      if (!isRecord(segment)) continue
      const family = typeof segment.capabilityId === 'string'
        ? familyByCapability[/** @type {keyof typeof familyByCapability} */ (segment.capabilityId)]
        : undefined
      if (!family) continue
      const token = family === 'flower' ? segment.templateToken : segment.parameters?.packagingToken
      if (token == null) continue
      if (!validToken(family, token)) return Object.freeze([])
      const prior = inline.get(token)
      if (prior && prior.family !== family) return Object.freeze([])
      const declared = declaredByToken.get(token)
      inline.set(token, Object.freeze({
        packagingToken: token,
        family,
        label: typeof declared?.label === 'string' ? declared.label : /** @type {Record<string, string>} */ ({
          flower: '花字包装',
          sticker: '贴纸包装',
          video_effect: '视频特效',
        })[family],
        targetSegmentId: typeof declared?.targetSegmentId === 'string'
          ? declared.targetSegmentId
          : targetFor(segment.targetRange),
      }))
    }
  }
  if (inline.size > 0) {
    return inline.size <= 24 ? Object.freeze([...inline.values()]) : Object.freeze([])
  }

  const declared = timeline.source?.packagingSelections
  if (!Array.isArray(declared) || declared.length < 1 || declared.length > 24) return Object.freeze([])
  /** @type {Map<string, TimelinePackagingSelection>} */
  const selections = new Map()
  for (const selection of declared) {
    const family = selection?.family
    const token = selection?.packagingToken
    if (typeof family !== 'string' || !validToken(family, token) || selections.has(token)) {
      return Object.freeze([])
    }
    selections.set(token, Object.freeze({
      packagingToken: token,
      family,
      label: selection.label,
      targetSegmentId: selection.targetSegmentId,
    }))
  }
  return Object.freeze([...selections.values()])
}
