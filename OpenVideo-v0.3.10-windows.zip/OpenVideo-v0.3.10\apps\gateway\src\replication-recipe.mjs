import { createHash } from 'node:crypto'

import { createEditorCapabilityRegistry } from './editor-capability-registry.mjs'
import { isJianyingTextTemplateMaterial } from './jianying-text-template.mjs'

const sourceKinds = new Set(['jianying_draft', 'video_analysis'])
const runtimeStatuses = new Set(['implemented', 'degraded', 'unsupported'])
const audioRoles = new Set(['voiceover', 'bgm', 'sfx'])
const textRoles = new Set(['caption', 'rich_text'])

const recipeCapabilityRegistry = createEditorCapabilityRegistry({
  privateCatalogCapabilities: [
    'audio.effect.named',
    'animation.text.named',
    'animation.video.named',
    'audio.video.fade',
    'background.video',
    'blend.video.named',
    'chroma.video',
    'effect.video.named',
    'filter.video.named',
    'filter.video.track_named',
    'mask.video.named',
    'sticker.named',
    'text.bubble.private',
    'text.flower.private',
    'track.insert_many',
    'transform.sticker.keyframe',
    'transform.text.keyframe',
  ],
})

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const integer = (value) => Number.isSafeInteger(value) && /** @type {number} */ (value) >= 0
/** @param {unknown} value */
const opaqueId = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {unknown} value */
const sha256 = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value)
/** @param {unknown} value @returns {boolean} */
function containsPrivateRecipeData(value) {
  if (typeof value === 'string') {
    const lower = value.toLowerCase()
    return /^[a-z]:[\\/]/iu.test(value) ||
      /^\\\\/u.test(value) ||
      lower.includes(`file:${'/'.repeat(2)}`) ||
      /\/(?:home|users|private|var|tmp|mnt|volumes)\//iu.test(value)
  }
  if (Array.isArray(value)) return value.some(containsPrivateRecipeData)
  if (!record(value)) return false
  for (const [key, entry] of Object.entries(value)) {
    const opaqueResourceKey = key === 'audioToken' || key === 'packagingToken'
    if ((
      !opaqueResourceKey &&
      /(?:path|url|transcript|media|thumbnail|provider|credential|secret|password|api[_-]?key|base[_-]?url|token)/iu.test(key)
    ) || containsPrivateRecipeData(entry)) return true
  }
  return false
}
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  record(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} value */
const timerange = (value) =>
  record(value) &&
  (value.start === undefined || integer(value.start)) &&
  Number.isSafeInteger(value.duration) &&
  value.duration > 0

/** @param {Record<string, any>} value */
const timerangeStart = (value) => (integer(value.start) ? value.start : 0)

/** @param {string} materialId @param {number} startUs @param {number} durationUs */
export const replicationTextSlotId = (materialId, startUs, durationUs) =>
  `txt-${createHash('sha256').update(`${materialId}\u0000${startUs}\u0000${durationUs}`).digest('hex').slice(0, 24)}`

/** @param {unknown} value */
const finiteNumber = (value) =>
  typeof value === 'number' && Number.isFinite(value) && !Number.isNaN(value)

/** @param {unknown} value */
const safeColor = (value) =>
  typeof value === 'string' && /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/iu.test(value)
    ? value.toLowerCase()
    : null

/** @param {unknown} value */
const safeJianyingVersion = (value) =>
  value === null ||
  (typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._+-]{0,39}$/u.test(value))

/**
 * Map recipe-facing capability IDs onto the authoritative writer registry.
 * `audio.voice.clone` is a recipe UX id; writer truth is edge_tts once bound.
 * @param {string} recipeCapabilityId
 */
const registryCapabilityId = (recipeCapabilityId) => {
  if (recipeCapabilityId === 'audio.voice.clone') return 'audio.voiceover.edge_tts'
  if (recipeCapabilityId === 'editing.timing') return 'transition.cut'
  return recipeCapabilityId
}

/**
 * @param {string} recipeCapabilityId
 * @returns {{ previewStatus: 'implemented' | 'degraded' | 'unsupported', jianyingStatus: 'implemented' | 'degraded' | 'unsupported' }}
 */
const writerStatuses = (recipeCapabilityId) => {
  const registryId = registryCapabilityId(recipeCapabilityId)
  const entry = recipeCapabilityRegistry.list().capabilities
    .find((item) => item.capabilityId === registryId)
  if (!entry) {
    return { previewStatus: 'unsupported', jianyingStatus: 'unsupported' }
  }
  return {
    previewStatus: /** @type {'implemented' | 'degraded' | 'unsupported'} */ (
      entry.targets.preview.status
    ),
    jianyingStatus: /** @type {'implemented' | 'degraded' | 'unsupported'} */ (
      entry.targets.jianying.status
    ),
  }
}

/**
 * Only style values are projected. Text content, material identifiers and paths
 * remain private in the blueprint store.
 * @param {Record<string, any>} material
 * @param {Record<string, any>} segment
 */
const nestedFillColor = (nested) => {
  const style = Array.isArray(nested?.document?.styles)
    ? nested.document.styles.find((entry) => record(entry))
    : null
  const rgb = record(style?.fill?.content?.solid)
    ? style.fill.content.solid.color
    : record(style?.fill?.solid)
      ? style.fill.solid.color
      : null
  if (!Array.isArray(rgb) || rgb.length < 3 || !rgb.slice(0, 3).every(finiteNumber)) return null
  const hex = `#${rgb.slice(0, 3).map((channel) =>
    Math.round(Math.min(1, Math.max(0, channel)) * 255).toString(16).padStart(2, '0')).join('')}`
  return safeColor(hex)
}

const publicTextStyle = (material, segment) => {
  const transform = record(segment.clip?.transform) ? segment.clip.transform : {}
  const nested = parseJianyingTextMaterialContent(material.content)
  const nestedSize = Array.isArray(nested?.document?.styles)
    ? nested.document.styles.find((style) => record(style) && finiteNumber(style.size))?.size
    : null
  return {
    size: finiteNumber(material.text_size)
      ? material.text_size
      : finiteNumber(nestedSize) ? nestedSize : null,
    color: safeColor(material.text_color) ?? nestedFillColor(nested),
    alignment: Number.isSafeInteger(material.alignment) ? material.alignment : null,
    transformX: finiteNumber(transform.x) ? transform.x : 0,
    transformY: finiteNumber(transform.y) ? transform.y : 0,
  }
}

/**
 * Jianying stores styled text as a JSON document inside material.content.
 * Treat the outer string as an opaque container: callers must never replace it
 * with the visible text, or Jianying will render the JSON itself as a caption.
 * @param {unknown} content
 * @returns {{text: string, document: Record<string, any>} | null}
 */
export const parseJianyingTextMaterialContent = (content) => {
  if (typeof content !== 'string' || !content.trim()) return null
  try {
    const document = JSON.parse(content)
    if (!record(document) || typeof document.text !== 'string') return null
    return { text: document.text, document }
  } catch {
    return null
  }
}

/** @param {unknown} range @param {number} oldLength @param {number} nextLength */
const scaleTextRange = (range, oldLength, nextLength) => {
  const scale = oldLength > 0 ? nextLength / oldLength : 1
  /** @param {number} value */
  const clamp = (value) => Math.max(0, Math.min(nextLength, Math.round(value * scale)))
  if (Array.isArray(range) && range.length === 2 && range.every(integer)) {
    return [clamp(range[0]), clamp(range[1])]
  }
  if (record(range) && integer(range.start) && integer(range.end)) {
    return { ...range, start: clamp(range.start), end: clamp(range.end) }
  }
  return range
}

/**
 * Replace only the nested visible text while preserving all style and material
 * references. Plain text materials are supported as a compatibility fallback.
 * @param {unknown} content
 * @param {string} nextText
 * @returns {string | null}
 */
export const replaceJianyingTextMaterialContent = (content, nextText) => {
  if (typeof nextText !== 'string' || !nextText.trim()) return null
  const parsed = parseJianyingTextMaterialContent(content)
  if (!parsed) {
    if (typeof content !== 'string' || !content.trim()) return null
    const first = content.trimStart()[0]
    // A JSON-looking material must not be downgraded to plain text on parse
    // failure; doing so is exactly how FlowerText JSON becomes visible text.
    return first === '{' || first === '[' ? null : nextText
  }
  const document = structuredClone(parsed.document)
  document.text = nextText
  if (Array.isArray(document.styles)) {
    document.styles = document.styles.map((style) => {
      if (!record(style) || !Object.hasOwn(style, 'range')) return style
      return {
        ...style,
        range: scaleTextRange(style.range, parsed.text.length, nextText.length),
      }
    })
  }
  return JSON.stringify(document)
}

/**
 * Jianying “花字” often appears as preset-styled subtitle (font/stroke/shadow/bg),
 * not only as materials.flowers entries.
 * @param {Record<string, any>} material
 * @param {Record<string, any>} segment
 * @param {Record<string, any[]>} materialArrays
 */
const isStyledFlowerText = (material, segment, materialArrays) => {
  if (isJianyingTextTemplateMaterial(material)) return true
  if (materialArrays.text_templates?.some((entry) => entry.id === material.id)) return true
  const refs = Array.isArray(segment.extra_material_refs) ? segment.extra_material_refs : []
  if (refs.some((reference) => materialArrays.flowers?.some((entry) => entry.id === reference))) {
    return true
  }
  if (refs.some((reference) =>
    materialArrays.material_animations?.some((entry) => entry.id === reference))) {
    return true
  }
  if (refs.some((reference) =>
    materialArrays.effects?.some((entry) =>
      entry.id === reference && ['text_effect', 'text_shape'].includes(entry.type)))) {
    return true
  }
  const template = record(material.caption_template_info) ? material.caption_template_info : null
  if (template && typeof template.resource_id === 'string' && template.resource_id.trim()) {
    return true
  }
  const parsedContent = parseJianyingTextMaterialContent(material.content)
  if (!parsedContent || !Array.isArray(parsedContent.document.styles)) return false
  return parsedContent.document.styles.some((style) => {
      if (!record(style)) return false
      if (record(style.font)) return true
      if (record(style.background)) return true
      if (Array.isArray(style.strokes) && style.strokes.length > 0 && record(style.font)) return true
      return false
    })
}

/**
 * @param {string} trackName
 * @param {string} materialName
 * @param {Record<string, any>} [material]
 */
const inferAudioRole = (trackName, materialName, material = {}) => {
  const type = typeof material.type === 'string' ? material.type.toLowerCase() : ''
  const category = typeof material.category_name === 'string'
    ? material.category_name.toLowerCase()
    : ''
  if (type === 'music' || /音乐库|曲库/.test(category)) return 'bgm'
  const value = `${trackName}\u0000${materialName}`.toLowerCase()
  if (/(?:bgm|背景|音乐|music)/u.test(value)) return 'bgm'
  if (/(?:voiceover|narration|speech|配音|口播|解说)/u.test(value)) return 'voiceover'
  if (type === 'extract_music') {
    return 'sfx'
  }
  if (/(?:音效|sfx|effect|foley|叮|提示音)/u.test(value)) return 'sfx'
  return 'voiceover'
}

/**
 * @param {string} id
 * @param {boolean} learned
 * @param {'implemented' | 'degraded' | 'unsupported'} previewStatus
 * @param {'implemented' | 'degraded' | 'unsupported'} jianyingStatus
 * @param {'jianying_draft' | 'video_analysis'} source
 * @param {string | null} [blockedReason]
 */
const capability = (
  id,
  learned,
  previewStatus,
  jianyingStatus,
  source,
  blockedReason = null,
) => ({
  id,
  learned,
  previewStatus,
  jianyingStatus,
  source,
  blockedReason,
})

/**
 * Learned facts never inflate writer status above the registry.
 * Missing portable assets or authorization keep an explicit blockedReason.
 * @param {string} id
 * @param {boolean} learned
 * @param {'jianying_draft' | 'video_analysis'} source
 * @param {string | null} [blockedReason]
 */
const projectedCapability = (id, learned, source, blockedReason = null) => {
  if (!learned) {
    return capability(id, false, 'unsupported', 'unsupported', source, null)
  }
  if (blockedReason) {
    return capability(id, true, 'unsupported', 'unsupported', source, blockedReason)
  }
  const statuses = writerStatuses(id)
  return capability(id, true, statuses.previewStatus, statuses.jianyingStatus, source, null)
}

/**
 * Convert normalized pyJianYingDraft content into a public, path-free recipe.
 * The lossless source remains in the private blueprint store referenced by ID.
 * @param {{
 *   blueprintId: string,
 *   fingerprint: string,
 *   content: Record<string, any>,
 *   sourceKind?: 'jianying_draft' | 'video_analysis',
 * }} input
 */
export const createReplicationRecipeFromJianyingDraft = ({
  blueprintId,
  fingerprint,
  content,
  sourceKind = 'jianying_draft',
}) => {
  if (
    !sourceKinds.has(sourceKind) ||
    !opaqueId(blueprintId) ||
    !sha256(fingerprint) ||
    !record(content) ||
    !Number.isSafeInteger(content.duration) ||
    content.duration <= 0 ||
    !record(content.canvas_config) ||
    !Number.isSafeInteger(content.canvas_config.width) ||
    !Number.isSafeInteger(content.canvas_config.height) ||
    !Array.isArray(content.tracks)
  ) throw new Error('REPLICATION_RECIPE_SOURCE_INVALID')

  const materials = record(content.materials) ? content.materials : {}
  const materialArrays = Object.fromEntries(
    Object.entries(materials).map(([key, entries]) => [
      key,
      Array.isArray(entries) ? entries.filter(record) : [],
    ]),
  )
  const byMaterialId = new Map()
  for (const entries of Object.values(materialArrays)) {
    for (const entry of entries) {
      if (typeof entry.id === 'string') byMaterialId.set(entry.id, entry)
    }
  }

  /** @type {Array<Record<string, any>>} */
  const videoSlots = []
  /** @type {Array<Record<string, any>>} */
  const textSegments = []
  /** @type {Array<Record<string, any>>} */
  const audioCues = []
  let videoOrder = 0
  for (const track of content.tracks) {
    if (!record(track) || !Array.isArray(track.segments)) continue
    const trackName = typeof track.name === 'string' ? track.name : ''
    for (const segment of track.segments) {
      if (!record(segment) || !timerange(segment.target_timerange)) continue
      const material = typeof segment.material_id === 'string'
        ? byMaterialId.get(segment.material_id) ?? {}
        : {}
      if (track.type === 'video') {
        videoOrder += 1
        videoSlots.push({
          order: videoOrder,
          startUs: timerangeStart(segment.target_timerange),
          durationUs: segment.target_timerange.duration,
          sourceStartUs: timerange(segment.source_timerange)
            ? timerangeStart(segment.source_timerange)
            : 0,
        })
      } else if (track.type === 'text') {
        const authoredFlowerTrack = /flower\s*text|花字|贴纸文字/iu.test(trackName.trim())
        const richText = isStyledFlowerText(material, segment, materialArrays) || authoredFlowerTrack
        textSegments.push({
          ...(typeof segment.material_id === 'string'
            ? { slotId: replicationTextSlotId(segment.material_id, timerangeStart(segment.target_timerange), segment.target_timerange.duration) }
            : {}),
          role: richText ? 'rich_text' : 'caption',
          startUs: timerangeStart(segment.target_timerange),
          durationUs: segment.target_timerange.duration,
          style: publicTextStyle(material, segment),
          packagingToken: null,
          // The real AnimateDiff blueprint stores most FlowerText styling in
          // the text material itself. Those slots have no extra effect ref,
          // so the track name is the authoritative decoration signal.
          // Authored emphasis is a decoration. Track name, extra refs, or
          // styled rich text all become flower unless a bubble shape is
          // explicitly linked. Leaving decorationKind null made later
          // templates look like plain title text and invited catalog substitutes.
          decorationKind: richText
            ? (textDecorationKind(segment, materialArrays) ?? 'flower')
            : null,
        })
      } else if (track.type === 'audio') {
        const materialName = typeof material.name === 'string' ? material.name : ''
        audioCues.push({
          role: inferAudioRole(trackName, materialName, material),
          startUs: timerangeStart(segment.target_timerange),
          durationUs: segment.target_timerange.duration,
          volume: finiteNumber(segment.volume)
            ? Math.max(0, Math.min(1, segment.volume))
            : 1,
        })
      }
    }
  }
  videoSlots.sort((left, right) => left.startUs - right.startUs || left.order - right.order)
  videoSlots.forEach((slot, index) => { slot.order = index + 1 })
  textSegments.sort((left, right) => left.startUs - right.startUs)
  audioCues.sort((left, right) => {
    const roles = /** @type {Record<string, number>} */ ({ voiceover: 0, bgm: 1, sfx: 2 })
    return (roles[left.role] ?? 99) - (roles[right.role] ?? 99) || left.startUs - right.startUs
  })

  const richTextCount = textSegments.filter((entry) => entry.role === 'rich_text').length
  const stickerSegmentCount = (Array.isArray(content.tracks) ? content.tracks : [])
    .filter((track) => record(track) && track.type === 'sticker' && Array.isArray(track.segments))
    .reduce((count, track) => count + track.segments.length, 0)
  const packaging = {
    effectCount: materialArrays.effects?.length ?? 0,
    flowerTextCount: Math.max(
      materialArrays.flowers?.length ?? 0,
      materialArrays.text_templates?.length ?? 0,
      richTextCount,
    ),
    stickerCount: Math.max(materialArrays.stickers?.length ?? 0, stickerSegmentCount),
  }
  const hasVoice = audioCues.some((entry) => entry.role === 'voiceover')
  const hasBgm = audioCues.some((entry) => entry.role === 'bgm')
  const hasSfx = audioCues.some((entry) => entry.role === 'sfx')
  const hasCaptions = textSegments.some((entry) => entry.role === 'caption')
  const hasRichText = richTextCount > 0
  const capabilities = [
    projectedCapability('editing.timing', videoSlots.length > 0, sourceKind),
    projectedCapability('caption.basic', hasCaptions, sourceKind),
    projectedCapability('text.rich', hasRichText, sourceKind),
    projectedCapability(
      'audio.voice.clone',
      hasVoice,
      sourceKind,
      hasVoice ? 'voice_authorization_required' : null,
    ),
    // Draft audio paths are stripped; without a project-side opaque audioToken
    // writers cannot replay BGM/SFX even though the registry supports local audio.
    projectedCapability(
      'audio.bgm.local',
      hasBgm,
      sourceKind,
      hasBgm ? 'local_asset_rebinding_required' : null,
    ),
    projectedCapability(
      'audio.sfx.local',
      hasSfx,
      sourceKind,
      hasSfx ? 'local_asset_rebinding_required' : null,
    ),
    // Until opaque packaging tokens are bound, learned packaging stays blocked.
    projectedCapability(
      'effect.video.named',
      packaging.effectCount > 0,
      sourceKind,
      packaging.effectCount > 0 ? 'packaging_token_required' : null,
    ),
    // Uploaded Jianying drafts keep the sticker track in the private
    // blueprint. Overlay copies that track; a catalog token is optional.
    // Video-analysis recipes still need an explicit packaging token.
    projectedCapability(
      'sticker.named',
      packaging.stickerCount > 0,
      sourceKind,
      packaging.stickerCount > 0 && sourceKind !== 'jianying_draft'
        ? 'packaging_token_required'
        : null,
    ),
  ]

  const recipe = {
    schemaVersion: 1,
    source: {
      kind: sourceKind,
      fidelity: sourceKind === 'jianying_draft' ? 'structural' : 'estimated',
      blueprintId: sourceKind === 'jianying_draft' ? blueprintId : null,
      fingerprint,
      jianyingVersion: sourceKind === 'jianying_draft' && typeof content.platform?.app_version === 'string'
        ? content.platform.app_version.slice(0, 40)
        : null,
    },
    durationUs: content.duration,
    canvas: {
      width: content.canvas_config.width,
      height: content.canvas_config.height,
    },
    videoSlots,
    textSegments,
    audioCues: audioCues.map((cue) => ({ ...cue, audioToken: null })),
    packaging,
    packagingSegments: [],
    voiceProfileId: null,
    capabilities,
  }
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  return recipe
}

/**
 * Creates a portable visual-approximation recipe from evidence extracted from
 * a finished reference video. It never invents Jianying resource IDs, flower
 * text, effects, stickers, or original audio.
 * @param {{
 *   fingerprint: string,
 *   orientation: 'portrait' | 'landscape' | 'square',
 *   targetDurationSeconds: number,
 *   analysis: {duration_ms: number, shots: Array<{order: number, start_ms: number, end_ms: number}>, caption_cadence: {mode: 'none' | 'steady' | 'burst', cards_per_minute: number}},
 * }} input
 */
export const createReplicationRecipeFromReferenceAnalysis = (input) => {
  if (
    !record(input) || !sha256(input.fingerprint) ||
    !['portrait', 'landscape', 'square'].includes(input.orientation) ||
    !Number.isSafeInteger(input.targetDurationSeconds) || input.targetDurationSeconds < 1 ||
    !record(input.analysis) || !Number.isSafeInteger(input.analysis.duration_ms) ||
    input.analysis.duration_ms < 1_000 || !Array.isArray(input.analysis.shots) ||
    input.analysis.shots.length === 0 || !record(input.analysis.caption_cadence)
  ) throw new Error('REFERENCE_VIDEO_RECIPE_SOURCE_INVALID')

  const durationUs = input.targetDurationSeconds * 1_000_000
  const referenceDurationUs = input.analysis.duration_ms * 1_000
  const shots = input.analysis.shots.slice().sort((left, right) => left.order - right.order)
  const videoSegments = shots.map((shot, index) => {
    if (
      !record(shot) || !Number.isSafeInteger(shot.start_ms) ||
      !Number.isSafeInteger(shot.end_ms) || shot.start_ms < 0 ||
      shot.end_ms <= shot.start_ms || shot.end_ms > input.analysis.duration_ms
    ) throw new Error('REFERENCE_VIDEO_RECIPE_SHOT_INVALID')
    const startUs = Math.round(shot.start_ms * 1_000 * durationUs / referenceDurationUs)
    const endUs = index === shots.length - 1
      ? durationUs
      : Math.max(startUs + 1, Math.round(shot.end_ms * 1_000 * durationUs / referenceDurationUs))
    return {
      material_id: `reference-slot-${index + 1}`,
      target_timerange: { start: startUs, duration: endUs - startUs },
      // This is the real reference-video cut point, not a fake zero offset.
      source_timerange: { start: shot.start_ms * 1_000, duration: (shot.end_ms - shot.start_ms) * 1_000 },
    }
  })
  const cadence = input.analysis.caption_cadence
  const captionCount = cadence.mode === 'none'
    ? 0
    : Math.max(1, Math.min(24, Math.round(cadence.cards_per_minute * input.targetDurationSeconds / 60)))
  const textSegments = Array.from({ length: captionCount }, (_, index) => {
    const start = Math.floor(index * durationUs / captionCount)
    const end = index === captionCount - 1 ? durationUs : Math.floor((index + 1) * durationUs / captionCount)
    return {
      material_id: `caption-${index + 1}`,
      target_timerange: { start, duration: Math.max(1, end - start) },
      clip: { transform: { x: 0, y: -0.82 } },
    }
  })
  return createReplicationRecipeFromJianyingDraft({
    blueprintId: `video_${input.fingerprint.slice(0, 24)}`,
    fingerprint: input.fingerprint,
    sourceKind: 'video_analysis',
    content: {
      duration: durationUs,
      canvas_config: input.orientation === 'landscape'
        ? { width: 1920, height: 1080 }
        : input.orientation === 'square' ? { width: 1080, height: 1080 } : { width: 1080, height: 1920 },
      platform: { app_version: null },
      materials: {
        audios: [], effects: [], flowers: [], stickers: [],
        texts: textSegments.map((segment) => ({
          id: segment.material_id, text_size: 8, text_color: '#ffffff', alignment: 1,
        })),
      },
      tracks: [
        { type: 'video', name: 'reference-video', segments: videoSegments },
        ...(textSegments.length > 0 ? [{ type: 'text', name: 'captions', segments: textSegments }] : []),
      ],
    },
  })
}

/** @param {unknown} value */
export const isReplicationRecipe = (value) => {
  if (
    !record(value) ||
    containsPrivateRecipeData(value) ||
    !exactKeys(value, [
      'audioCues', 'canvas', 'capabilities', 'durationUs', 'packaging', 'schemaVersion',
      'source', 'textSegments', 'videoSlots',
      ...(Object.hasOwn(value, 'packagingSegments') ? ['packagingSegments'] : []),
      ...(Object.hasOwn(value, 'voiceProfileId') ? ['voiceProfileId'] : []),
    ]) ||
    value.schemaVersion !== 1 ||
    !record(value.source) ||
    !exactKeys(value.source, [
      'blueprintId', 'fidelity', 'fingerprint', 'jianyingVersion', 'kind',
    ]) ||
    !sourceKinds.has(value.source.kind) ||
    !['structural', 'estimated'].includes(value.source.fidelity) ||
    !sha256(value.source.fingerprint) ||
    !safeJianyingVersion(value.source.jianyingVersion) ||
    !Number.isSafeInteger(value.durationUs) ||
    value.durationUs <= 0 ||
    !record(value.canvas) ||
    !exactKeys(value.canvas, ['height', 'width']) ||
    !Number.isSafeInteger(value.canvas.width) ||
    value.canvas.width <= 0 ||
    !Number.isSafeInteger(value.canvas.height) ||
    value.canvas.height <= 0 ||
    !Array.isArray(value.videoSlots) ||
    !Array.isArray(value.textSegments) ||
    !Array.isArray(value.audioCues) ||
    !record(value.packaging) ||
    !exactKeys(value.packaging, ['effectCount', 'flowerTextCount', 'stickerCount']) ||
    !integer(value.packaging.effectCount) ||
    !integer(value.packaging.flowerTextCount) ||
    !integer(value.packaging.stickerCount) ||
    !Array.isArray(value.capabilities)
  ) return false
  if (value.packagingSegments !== undefined && !Array.isArray(value.packagingSegments)) return false
  if (
    value.voiceProfileId !== undefined &&
    value.voiceProfileId !== null &&
    !opaqueId(value.voiceProfileId)
  ) return false
  if (
    (value.source.kind === 'jianying_draft' && !opaqueId(value.source.blueprintId)) ||
    (value.source.kind === 'video_analysis' && value.source.blueprintId !== null)
  ) return false
  if (!value.videoSlots.every((slot, index) =>
    record(slot) &&
    exactKeys(slot, ['durationUs', 'order', 'sourceStartUs', 'startUs']) &&
    slot.order === index + 1 &&
    integer(slot.startUs) &&
    Number.isSafeInteger(slot.durationUs) &&
    slot.durationUs > 0 &&
    integer(slot.sourceStartUs))) return false
  if (!value.textSegments.every((segment) =>
    record(segment) &&
    (
      exactKeys(segment, ['durationUs', 'role', 'slotId', 'startUs', 'style']) ||
      exactKeys(segment, ['durationUs', 'role', 'startUs', 'style']) ||
      exactKeys(segment, ['decorationKind', 'durationUs', 'packagingToken', 'role', 'startUs', 'style']) ||
      exactKeys(segment, ['decorationKind', 'durationUs', 'packagingToken', 'role', 'slotId', 'startUs', 'style'])
    ) &&
    textRoles.has(segment.role) &&
    integer(segment.startUs) &&
    Number.isSafeInteger(segment.durationUs) &&
    segment.durationUs > 0 &&
    record(segment.style) &&
    exactKeys(segment.style, ['alignment', 'color', 'size', 'transformX', 'transformY']) &&
    (segment.style.size === null || finiteNumber(segment.style.size)) &&
    (segment.style.color === null || safeColor(segment.style.color) !== null) &&
    (segment.style.alignment === null || Number.isSafeInteger(segment.style.alignment)) &&
    finiteNumber(segment.style.transformX) &&
    finiteNumber(segment.style.transformY) &&
    (segment.packagingToken === undefined || segment.packagingToken === null || opaqueId(segment.packagingToken)) &&
    (segment.slotId === undefined || opaqueId(segment.slotId)) &&
    (segment.decorationKind === undefined || segment.decorationKind === null || ['flower', 'bubble'].includes(segment.decorationKind)))) return false
  if (!value.audioCues.every((cue) =>
    record(cue) &&
    Object.keys(cue).sort().join('\u0000') === ['audioToken', 'durationUs', 'role', 'startUs', 'volume'].join('\u0000') &&
    audioRoles.has(cue.role) &&
    integer(cue.startUs) &&
    Number.isSafeInteger(cue.durationUs) &&
    cue.durationUs > 0 &&
    finiteNumber(cue.volume) &&
    cue.volume >= 0 &&
    cue.volume <= 1 &&
    (cue.audioToken === null || opaqueId(cue.audioToken)))) return false
  if (Array.isArray(value.packagingSegments) && !value.packagingSegments.every((segment) =>
    record(segment) &&
    Object.keys(segment).sort().join('\u0000') ===
      ['durationUs', 'packagingToken', 'role', 'startUs'].join('\u0000') &&
    opaqueId(segment.packagingToken) &&
    ['sticker', 'effect'].includes(segment.role) &&
    integer(segment.startUs) &&
    Number.isSafeInteger(segment.durationUs) &&
    segment.durationUs > 0 &&
    !Object.hasOwn(segment, 'resource_id') &&
    !Object.hasOwn(segment, 'resourceId') &&
    !Object.hasOwn(segment, 'path'))) return false
  return value.capabilities.every((entry) =>
    record(entry) &&
    exactKeys(entry, [
      'blockedReason', 'id', 'jianyingStatus', 'learned', 'previewStatus', 'source',
    ]) &&
    opaqueId(entry.id.replaceAll('.', '_')) &&
    typeof entry.learned === 'boolean' &&
    runtimeStatuses.has(entry.previewStatus) &&
    runtimeStatuses.has(entry.jianyingStatus) &&
    sourceKinds.has(entry.source) &&
    (entry.blockedReason === null || opaqueId(entry.blockedReason)))
}

/** @param {unknown} value @returns {string} */
const stableJson = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value)
  }
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value)
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`
  if (!record(value)) throw new Error('REPLICATION_RECIPE_INVALID')
  return `{${Object.keys(value)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`)
    .join(',')}}`
}

/**
 * Stable identity for the complete executable recipe, independent of JSON key order.
 * @param {unknown} recipe
 */
export const replicationRecipeFingerprint = (recipe) => {
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  return createHash('sha256').update(stableJson(recipe)).digest('hex')
}

// Blueprint extract and recipe cues can differ by a few frames after
// inspect/sanitize. Prefer an exact window, then the nearest unused cue
// within 250ms, then leftover equal-count pairing by authored order.
const SFX_NEAR_MATCH_US = 250_000

/**
 * @param {Record<string, any>} cue
 * @param {Array<{ startUs: number, durationUs: number, audioToken: string }>} bindings
 * @param {Set<number>} used
 */
const matchSfxBindingIndex = (cue, bindings, used) => {
  let exact = -1
  for (const [index, binding] of bindings.entries()) {
    if (used.has(index)) continue
    if (binding.startUs === cue.startUs && binding.durationUs === cue.durationUs) {
      exact = index
      break
    }
  }
  if (exact >= 0) return exact
  let nearest = -1
  let nearestDelta = Infinity
  for (const [index, binding] of bindings.entries()) {
    if (used.has(index)) continue
    const delta = Math.abs(binding.startUs - cue.startUs)
    if (delta <= SFX_NEAR_MATCH_US && delta < nearestDelta) {
      nearest = index
      nearestDelta = delta
    }
  }
  return nearest
}

/**
 * @param {Array<Record<string, any>>} audioCues
 * @param {Array<{ startUs: number, durationUs: number, audioToken: string }>} bindings
 * @param {Set<number>} used
 */
const pairRemainingSfxBindings = (audioCues, bindings, used) => {
  const unbound = audioCues
    .map((cue, index) => ({ cue, index }))
    .filter(({ cue }) => cue.role === 'sfx' && !opaqueId(cue.audioToken))
    .sort((left, right) => left.cue.startUs - right.cue.startUs)
  const unused = bindings
    .map((binding, index) => ({ binding, index }))
    .filter(({ index }) => !used.has(index))
    .sort((left, right) => left.binding.startUs - right.binding.startUs)
  if (unbound.length === 0 || unbound.length !== unused.length) return audioCues
  const next = audioCues.slice()
  for (const [offset, { cue, index }] of unbound.entries()) {
    used.add(unused[offset].index)
    next[index] = { ...cue, audioToken: unused[offset].binding.audioToken }
  }
  return next
}

/**
 * Bind opaque local audio tokens onto recipe cues (BGM/SFX).
 * @param {Record<string, any>} recipe
 * @param {{
 *   bgmAudioToken?: string | null,
 *   sfxAudioToken?: string | null,
 *   sfxBindings?: Array<{ startUs: number, durationUs: number, audioToken: string }>,
 * }} tokens
 */
export const bindLocalAudioToReplicationRecipe = (recipe, tokens = {}) => {
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  const next = structuredClone(recipe)
  const bgmToken = tokens.bgmAudioToken === undefined ? undefined : tokens.bgmAudioToken
  const sfxToken = tokens.sfxAudioToken === undefined ? undefined : tokens.sfxAudioToken
  const sfxBindings = Array.isArray(tokens.sfxBindings) ? tokens.sfxBindings : null
  if (!(bgmToken === undefined || bgmToken === null || opaqueId(bgmToken))) {
    throw new Error('REPLICATION_RECIPE_AUDIO_INVALID')
  }
  if (!(sfxToken === undefined || sfxToken === null || opaqueId(sfxToken))) {
    throw new Error('REPLICATION_RECIPE_AUDIO_INVALID')
  }
  if (sfxBindings) {
    for (const binding of sfxBindings) {
      if (
        !record(binding) ||
        !integer(binding.startUs) ||
        !Number.isSafeInteger(binding.durationUs) ||
        binding.durationUs <= 0 ||
        !opaqueId(binding.audioToken)
      ) {
        throw new Error('REPLICATION_RECIPE_AUDIO_INVALID')
      }
    }
  }
  const usedSfxBindings = new Set()
  next.audioCues = next.audioCues.map((/** @type {Record<string, any>} */ cue) => {
    if (cue.role === 'bgm' && bgmToken !== undefined) return { ...cue, audioToken: bgmToken }
    if (cue.role === 'sfx') {
      if (sfxBindings) {
        const matchIndex = matchSfxBindingIndex(cue, sfxBindings, usedSfxBindings)
        if (matchIndex >= 0) {
          usedSfxBindings.add(matchIndex)
          return { ...cue, audioToken: sfxBindings[matchIndex].audioToken }
        }
      }
      if (sfxToken !== undefined) return { ...cue, audioToken: sfxToken }
    }
    return cue
  })
  if (sfxBindings) {
    next.audioCues = pairRemainingSfxBindings(next.audioCues, sfxBindings, usedSfxBindings)
  }
  next.capabilities = next.capabilities.map((/** @type {Record<string, any>} */ entry) => {
    if (entry.id === 'audio.bgm.local' && entry.learned) {
      const hasToken = next.audioCues.some((/** @type {Record<string, any>} */ cue) =>
        cue.role === 'bgm' && opaqueId(cue.audioToken))
      if (hasToken) {
        const statuses = writerStatuses('audio.bgm.local')
        return { ...entry, ...statuses, blockedReason: null }
      }
      return projectedCapability('audio.bgm.local', true, entry.source, 'local_asset_rebinding_required')
    }
    if (entry.id === 'audio.sfx.local' && entry.learned) {
      const sfxCues = next.audioCues.filter((/** @type {Record<string, any>} */ cue) => cue.role === 'sfx')
      const hasToken = sfxCues.length > 0 &&
        sfxCues.every((/** @type {Record<string, any>} */ cue) => opaqueId(cue.audioToken))
      if (hasToken) {
        const statuses = writerStatuses('audio.sfx.local')
        return { ...entry, ...statuses, blockedReason: null }
      }
      return projectedCapability('audio.sfx.local', true, entry.source, 'local_asset_rebinding_required')
    }
    return entry
  })
  if (!isReplicationRecipe(next)) throw new Error('REPLICATION_RECIPE_INVALID')
  return next
}

const VISUAL_BLEND_CAPABILITIES = new Set([
  'text.rich',
  'effect.video.named',
  'sticker.named',
])

/**
 * Keeps the primary template's edit rhythm and audio ownership while adding
 * portable visual packaging from one approved companion template.
 * @param {Record<string, any>} primary
 * @param {Record<string, any>} companion
 */
export const blendReplicationRecipeVisuals = (primary, companion) => {
  if (!isReplicationRecipe(primary) || !isReplicationRecipe(companion)) {
    throw new Error('REPLICATION_RECIPE_BLEND_INVALID')
  }
  if (
    primary.canvas.width * companion.canvas.height !==
    companion.canvas.width * primary.canvas.height
  ) {
    throw new Error('REPLICATION_RECIPE_BLEND_ORIENTATION_INCOMPATIBLE')
  }

  const next = structuredClone(primary)
  const scale = primary.durationUs / companion.durationUs
  /** @param {Record<string, any>} segment */
  const scaleSegment = (segment) => {
    const startUs = Math.min(
      Math.max(0, Math.round(segment.startUs * scale)),
      Math.max(0, primary.durationUs - 1),
    )
    return {
      ...structuredClone(segment),
      startUs,
      durationUs: Math.max(
        1,
        Math.min(Math.round(segment.durationUs * scale), primary.durationUs - startUs),
      ),
    }
  }
  const visualTexts = companion.textSegments
    .filter((/** @type {Record<string, any>} */ segment) => segment.role === 'rich_text')
    .map(scaleSegment)
  const visualPackaging = Array.isArray(companion.packagingSegments)
    ? companion.packagingSegments.map(scaleSegment)
    : []

  next.textSegments = [...next.textSegments, ...visualTexts]
    .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) =>
      left.startUs - right.startUs || left.role.localeCompare(right.role))
  next.packagingSegments = [
    ...(Array.isArray(next.packagingSegments) ? next.packagingSegments : []),
    ...visualPackaging,
  ]
    .filter((/** @type {Record<string, any>} */ segment, index, values) => values.findIndex((candidate) =>
      candidate.role === segment.role &&
      candidate.packagingToken === segment.packagingToken &&
      candidate.startUs === segment.startUs &&
      candidate.durationUs === segment.durationUs) === index)
    .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) =>
      left.startUs - right.startUs || left.role.localeCompare(right.role))
  next.packaging = {
    effectCount: next.packagingSegments.filter((/** @type {Record<string, any>} */ segment) => segment.role === 'effect').length,
    flowerTextCount: next.textSegments.filter((/** @type {Record<string, any>} */ segment) => segment.role === 'rich_text').length,
    stickerCount: next.packagingSegments.filter((/** @type {Record<string, any>} */ segment) => segment.role === 'sticker').length,
  }

  const capabilities = new Map(next.capabilities.map((/** @type {Record<string, any>} */ entry) => [entry.id, entry]))
  for (const entry of companion.capabilities) {
    if (!VISUAL_BLEND_CAPABILITIES.has(entry.id) || entry.learned !== true) continue
    const current = capabilities.get(entry.id)
    if (!current || current.learned !== true || current.jianyingStatus === 'unsupported') {
      capabilities.set(entry.id, structuredClone(entry))
    }
  }
  next.capabilities = [...capabilities.values()]
  if (!isReplicationRecipe(next)) throw new Error('REPLICATION_RECIPE_BLEND_INVALID')
  return next
}

/**
 * Add one server-owned SFX cue when a learned draft has no SFX lane. Callers
 * choose only the authorized audio asset; timing and volume stay bounded here.
 * @param {Record<string, any>} recipe
 */
export const addControlledLocalSfxCueToReplicationRecipe = (recipe) => {
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  const next = structuredClone(recipe)
  if (next.audioCues.some((/** @type {Record<string, any>} */ cue) => cue.role === 'sfx')) return next
  const firstCutUs = next.videoSlots
    .map((/** @type {Record<string, any>} */ slot) => slot.startUs)
    .find((/** @type {number} */ startUs) => Number.isSafeInteger(startUs) && startUs > 0)
  const startUs = Number.isSafeInteger(firstCutUs) ? firstCutUs : 0
  const remainingUs = next.durationUs - startUs
  if (!Number.isSafeInteger(remainingUs) || remainingUs <= 0) {
    throw new Error('REPLICATION_RECIPE_AUDIO_INVALID')
  }
  next.audioCues.push({
    role: 'sfx',
    startUs,
    durationUs: Math.min(1_000_000, remainingUs),
    volume: 0.65,
    audioToken: null,
  })
  next.audioCues.sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) => {
    const roles = /** @type {Record<string, number>} */ ({ voiceover: 0, bgm: 1, sfx: 2 })
    return (roles[left.role] ?? 99) - (roles[right.role] ?? 99) || left.startUs - right.startUs
  })
  next.capabilities = next.capabilities.map((/** @type {Record<string, any>} */ entry) =>
    entry.id === 'audio.sfx.local'
      ? projectedCapability('audio.sfx.local', true, entry.source, 'local_asset_rebinding_required')
      : entry)
  if (!isReplicationRecipe(next)) throw new Error('REPLICATION_RECIPE_INVALID')
  return next
}

/**
 * Attach opaque packaging segments (sticker/effect). Writer statuses follow registry.
 * @param {Record<string, any>} recipe
 * @param {Array<{ packagingToken: string, role: 'sticker' | 'effect', startUs: number, durationUs: number }>} segments
 */
export const applyPackagingSegmentsToReplicationRecipe = (recipe, segments) => {
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  if (!Array.isArray(segments)) throw new Error('REPLICATION_RECIPE_PACKAGING_INVALID')
  const next = structuredClone(recipe)
  next.packagingSegments = segments.map((segment) => {
    if (
      !record(segment) ||
      !opaqueId(segment.packagingToken) ||
      !['sticker', 'effect'].includes(segment.role) ||
      !integer(segment.startUs) ||
      !Number.isSafeInteger(segment.durationUs) ||
      segment.durationUs <= 0
    ) throw new Error('REPLICATION_RECIPE_PACKAGING_INVALID')
    return {
      packagingToken: segment.packagingToken,
      role: segment.role,
      startUs: segment.startUs,
      durationUs: segment.durationUs,
    }
  })
  const hasEffect = next.packagingSegments.some(
    (/** @type {Record<string, any>} */ segment) => segment.role === 'effect',
  )
  const hasSticker = next.packagingSegments.some(
    (/** @type {Record<string, any>} */ segment) => segment.role === 'sticker',
  )
  next.packaging = {
    ...next.packaging,
    effectCount: Math.max(next.packaging.effectCount ?? 0, hasEffect ? 1 : 0),
    stickerCount: Math.max(next.packaging.stickerCount ?? 0, hasSticker ? 1 : 0),
  }
  next.capabilities = next.capabilities.map((/** @type {Record<string, any>} */ entry) => {
    if (entry.id === 'effect.video.named') {
      if (!entry.learned && !hasEffect) return entry
      if (hasEffect) {
        const statuses = writerStatuses('effect.video.named')
        return {
          ...entry,
          learned: true,
          previewStatus: statuses.previewStatus,
          jianyingStatus: statuses.jianyingStatus,
          blockedReason: null,
        }
      }
      return projectedCapability('effect.video.named', true, entry.source, 'packaging_token_required')
    }
    if (entry.id === 'sticker.named') {
      if (!entry.learned && !hasSticker) return entry
      if (hasSticker) {
        const statuses = writerStatuses('sticker.named')
        return {
          ...entry,
          learned: true,
          previewStatus: statuses.previewStatus,
          jianyingStatus: statuses.jianyingStatus,
          blockedReason: null,
        }
      }
      return projectedCapability('sticker.named', true, entry.source, 'packaging_token_required')
    }
    return entry
  })
  if (!isReplicationRecipe(next)) throw new Error('REPLICATION_RECIPE_INVALID')
  return next
}

/** @param {Record<string, any>} segment @param {Record<string, any[]>} materialArrays */
const textDecorationKind = (segment, materialArrays) => {
  const refs = Array.isArray(segment.extra_material_refs) ? segment.extra_material_refs : []
  for (const reference of refs) {
    const effect = materialArrays.effects?.find((entry) => entry.id === reference)
    if (effect?.type === 'text_effect') return 'flower'
    if (effect?.type === 'text_shape') return 'bubble'
    const animation = materialArrays.material_animations?.find((entry) => entry.id === reference)
    if (animation?.type === 'sticker_animation') return 'flower'
  }
  if (refs.some((reference) => materialArrays.flowers?.some((entry) => entry.id === reference))) return 'flower'
  return null
}

/** Bind private flower/bubble catalog tokens to matching rich-text slots/windows. */
/** @param {Record<string, any>} recipe @param {Array<Record<string, any>>} bindings */
export const applyTextPackagingToReplicationRecipe = (recipe, bindings) => {
  if (!isReplicationRecipe(recipe) || !Array.isArray(bindings)) {
    throw new Error('REPLICATION_RECIPE_PACKAGING_INVALID')
  }
  const next = structuredClone(recipe)
  for (const binding of bindings) {
    if (
      !record(binding) ||
      !opaqueId(binding.packagingToken) ||
      !['flower', 'bubble'].includes(binding.decorationKind) ||
      (binding.slotId !== undefined && !opaqueId(binding.slotId)) ||
      !integer(binding.startUs) ||
      !Number.isSafeInteger(binding.durationUs) ||
      binding.durationUs <= 0
    ) throw new Error('REPLICATION_RECIPE_PACKAGING_INVALID')
    const match = next.textSegments.find((/** @type {Record<string, any>} */ segment) =>
      segment.role === 'rich_text' &&
      (typeof binding.slotId === 'string'
        ? segment.slotId === binding.slotId
        : segment.startUs === binding.startUs && segment.durationUs === binding.durationUs))
    if (!match) throw new Error('REPLICATION_RECIPE_PACKAGING_TEXT_MISSING')
    match.packagingToken = binding.packagingToken
    match.decorationKind = binding.decorationKind
  }
  if (!isReplicationRecipe(next)) throw new Error('REPLICATION_RECIPE_INVALID')
  return next
}
/**
 * Bind a ready Workbench voice to a recipe. The public Writer capability stays
 * provider-neutral: Edge TTS, an authorized clone, or a Jianying preset all
 * produce the same generated voiceover contract before export.
 * @param {Record<string, any>} recipe
 * @param {string | null} voiceProfileId
 */
export const bindVoiceProfileToReplicationRecipe = (recipe, voiceProfileId) => {
  if (!isReplicationRecipe(recipe)) throw new Error('REPLICATION_RECIPE_INVALID')
  if (!(voiceProfileId === null || opaqueId(voiceProfileId))) {
    throw new Error('REPLICATION_RECIPE_VOICE_INVALID')
  }
  const next = structuredClone(recipe)
  next.voiceProfileId = voiceProfileId
  next.capabilities = next.capabilities.map((/** @type {Record<string, any>} */ entry) => {
    if (!['audio.voice.clone', 'audio.voiceover.edge_tts'].includes(entry.id)) return entry
    if (!entry.learned) return entry
    if (voiceProfileId) {
      const statuses = writerStatuses('audio.voiceover.edge_tts')
      return {
        ...entry,
        id: 'audio.voiceover.edge_tts',
        previewStatus: statuses.previewStatus,
        jianyingStatus: statuses.jianyingStatus,
        blockedReason: null,
      }
    }
    return {
      ...entry,
      id: 'audio.voice.clone',
      previewStatus: 'unsupported',
      jianyingStatus: 'unsupported',
      blockedReason: 'voice_authorization_required',
    }
  })
  if (!isReplicationRecipe(next)) throw new Error('REPLICATION_RECIPE_INVALID')
  return next
}
