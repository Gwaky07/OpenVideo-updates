/** @typedef {'text' | 'vision' | 'json'} GatewayCapability */
/**
 * @typedef {object} GatewayConfig
 * @property {string} provider
 * @property {string} baseUrl
 * @property {string} credential
 * @property {Record<GatewayCapability, string>} models
 * @property {string[]} allowedImageHosts
 * @property {number} maxAttempts
 * @property {number} maxConcurrentRequests
 * @property {number} retryBaseDelayMs
 * @property {number} requestTimeoutMs
 */

const requiredVariables = [
  'OPENVIDEO_LLM_PROVIDER',
  'OPENVIDEO_LLM_BASE_URL',
  'OPENVIDEO_LLM_API_KEY',
  'OPENVIDEO_LLM_TEXT_MODEL',
  'OPENVIDEO_LLM_VISION_MODEL',
  'OPENVIDEO_LLM_JSON_MODEL',
]

const limits = {
  maxAttempts: 8,
  maxConcurrentRequests: 8,
  maxRetryBaseDelayMs: 10_000,
  maxRequestTimeoutMs: 120_000,
}

/** @param {string | undefined} value */
const parseAllowedImageHosts = (value) => {
  if (!value?.trim()) return []
  const hosts = value.split(',').map((host) => host.trim().toLowerCase()).filter(Boolean)
  if (
    hosts.length === 0 ||
    new Set(hosts).size !== hosts.length ||
    !hosts.every((host) => /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(host) && !host.includes('..'))
  ) {
    throw new GatewayConfigError('OPENVIDEO_LLM_IMAGE_HOST_ALLOWLIST must contain comma-separated DNS hostnames.')
  }
  return hosts
}

export class GatewayConfigError extends Error {
  /** @param {string} message */
  constructor(message) {
    super(message)
    this.name = 'GatewayConfigError'
  }
}

/** @param {string | undefined} value @param {number} fallback @param {string} name @param {number} maximum */
const parsePositiveInteger = (value, fallback, name, maximum) => {
  if (value === undefined || value === '') {
    return fallback
  }

  if (!/^[1-9]\d*$/.test(value)) {
    throw new GatewayConfigError(`${name} must be a positive integer.`)
  }
  const parsed = Number(value)
  if (!Number.isSafeInteger(parsed) || parsed > maximum) {
    throw new GatewayConfigError(`${name} must be a positive integer no greater than ${maximum}.`)
  }
  return parsed
}

/** @param {NodeJS.ProcessEnv} [environment] @returns {GatewayConfig} */
export const loadGatewayConfig = (environment = process.env) => {
  const missing = requiredVariables.filter((name) => !environment[name]?.trim())
  if (missing.length > 0) {
    throw new GatewayConfigError(`Missing required environment variables: ${missing.join(', ')}`)
  }

  const baseUrl = environment.OPENVIDEO_LLM_BASE_URL?.trim().replace(/\/+$/, '') ?? ''
  let parsedUrl
  try {
    parsedUrl = new URL(baseUrl)
  } catch {
    throw new GatewayConfigError('OPENVIDEO_LLM_BASE_URL must be a valid HTTPS URL.')
  }

  const allowInsecureLocalhost =
    environment.OPENVIDEO_LLM_ALLOW_INSECURE_LOCALHOST === 'true' &&
    ['localhost', '127.0.0.1', '::1'].includes(parsedUrl.hostname)
  if (parsedUrl.protocol !== 'https:' && !allowInsecureLocalhost) {
    throw new GatewayConfigError('OPENVIDEO_LLM_BASE_URL must use HTTPS.')
  }
  if (parsedUrl.username || parsedUrl.password || parsedUrl.search || parsedUrl.hash) {
    throw new GatewayConfigError('OPENVIDEO_LLM_BASE_URL must not include credentials, query parameters, or fragments.')
  }

  return {
    provider: environment.OPENVIDEO_LLM_PROVIDER?.trim() ?? '',
    baseUrl,
    credential: environment.OPENVIDEO_LLM_API_KEY?.trim() ?? '',
    models: {
      text: environment.OPENVIDEO_LLM_TEXT_MODEL?.trim() ?? '',
      vision: environment.OPENVIDEO_LLM_VISION_MODEL?.trim() ?? '',
      json: environment.OPENVIDEO_LLM_JSON_MODEL?.trim() ?? '',
    },
    allowedImageHosts: parseAllowedImageHosts(environment.OPENVIDEO_LLM_IMAGE_HOST_ALLOWLIST),
    maxAttempts: parsePositiveInteger(
      environment.OPENVIDEO_LLM_MAX_ATTEMPTS,
      3,
      'OPENVIDEO_LLM_MAX_ATTEMPTS',
      limits.maxAttempts,
    ),
    maxConcurrentRequests: parsePositiveInteger(
      environment.OPENVIDEO_LLM_MAX_CONCURRENCY,
      2,
      'OPENVIDEO_LLM_MAX_CONCURRENCY',
      limits.maxConcurrentRequests,
    ),
    retryBaseDelayMs: parsePositiveInteger(
      environment.OPENVIDEO_LLM_RETRY_BASE_DELAY_MS,
      250,
      'OPENVIDEO_LLM_RETRY_BASE_DELAY_MS',
      limits.maxRetryBaseDelayMs,
    ),
    requestTimeoutMs: parsePositiveInteger(
      environment.OPENVIDEO_LLM_REQUEST_TIMEOUT_MS,
      120_000,
      'OPENVIDEO_LLM_REQUEST_TIMEOUT_MS',
      limits.maxRequestTimeoutMs,
    ),
  }
}

/** @param {NodeJS.ProcessEnv | Record<string, string | undefined>} [environment] */
export const loadOptionalGatewayConfig = (environment = process.env) => {
  const configuredVariables = requiredVariables.filter((name) => environment[name]?.trim())
  if (configuredVariables.length === 0) return null
  return loadGatewayConfig(environment)
}

/** @param {GatewayConfig} config @param {GatewayCapability} capability */
export const routeModel = (config, capability) => {
  const model = config.models[capability]
  if (!model) {
    throw new GatewayConfigError(`No model route is configured for capability: ${capability}`)
  }
  return model
}

/** @param {string | undefined} value */
export const parseGatewayPort = (value) => {
  const raw = value ?? '8787'
  if (!/^[1-9]\d{0,4}$/.test(raw)) {
    throw new GatewayConfigError('OPENVIDEO_GATEWAY_PORT must be an integer from 1 to 65535.')
  }
  const port = Number(raw)
  if (port > 65_535) {
    throw new GatewayConfigError('OPENVIDEO_GATEWAY_PORT must be an integer from 1 to 65535.')
  }
  return port
}

/** @param {unknown} text @param {string[]} [secrets] */
export const redactSensitiveText = (text, secrets = []) => {
  let redacted = String(text)
  for (const secret of secrets) {
    if (secret) {
      redacted = redacted.replaceAll(secret, '[REDACTED]')
    }
  }
  return redacted
    .replace(/Bearer\s+[^\s,;]+/gi, 'Bearer [REDACTED]')
    .replace(/(api[_-]?key\s*[=:]\s*)[^\s,;]+/gi, '$1[REDACTED]')
    .replace(/(authorization\s*[=:]\s*)[^\s,;]+/gi, '$1[REDACTED]')
}
