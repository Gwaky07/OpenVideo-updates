import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { mkdir, writeFile } from 'node:fs/promises'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { fingerprintCanonical } from '../apps/gateway/src/editor-agent-contracts.mjs'
import { parseJianyingTextAnimationCatalog } from '../apps/gateway/src/jianying-text-animation-catalog.mjs'
import { promisify } from 'node:util'
import path from 'node:path'

const execFileAsync = promisify(execFile)
const pinnedUpstreamCommit = 'c3318066d964744e2bfc66f75c71745fe8cea52a'
const main = async () => {
  const moduleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (!moduleRoot || !path.isAbsolute(moduleRoot)) throw new Error('JY083_UPSTREAM_ROOT_REQUIRED')
  const [{ stdout: upstreamRoot }, { stdout: commit }, { stdout: status }] = await Promise.all([
    execFileAsync('git', ['-C', moduleRoot, 'rev-parse', '--show-toplevel'], { windowsHide: true }),
    execFileAsync('git', ['-C', moduleRoot, 'rev-parse', 'HEAD'], { windowsHide: true }),
    execFileAsync('git', ['-C', moduleRoot, 'status', '--porcelain', '--untracked-files=all'], { windowsHide: true }),
  ])
  if (path.resolve(upstreamRoot.trim()) !== path.resolve(moduleRoot) || commit.trim() !== pinnedUpstreamCommit || status.trim()) throw new Error('JY083_UPSTREAM_INTEGRITY_INVALID')
  const { stdout } = await execFileAsync('python', ['-c', "import pyJianYingDraft as d, json; x=next((item for item in d.TextIntro if item.name == '\\u6536\\u62e2'), None); print(json.dumps(None if x is None else {'resource_id':x.value.resource_id,'duration_us':x.value.duration}))"], { env: { ...process.env, PYTHONPATH: moduleRoot }, windowsHide: true })
  const raw = JSON.parse(stdout)
  if (typeof raw.resource_id !== 'string' || !Number.isSafeInteger(raw.duration_us) || raw.duration_us <= 0) throw new Error('JY083_TEXT_ANIMATION_UNAVAILABLE')
  const entry = { capability_id: 'animation.text.named', animation_token: `ovjtxtanim_v1_${createHash('sha256').update(raw.resource_id).digest('hex')}`, resource_id: raw.resource_id, duration_us: raw.duration_us }
  const body = { schema_version: 1, kind: 'jy083_text_animation_catalog', entries: [entry] }
  const catalog = { ...body, fingerprint: fingerprintCanonical(body) }
  if (!parseJianyingTextAnimationCatalog(catalog)) throw new Error('JY083_TEXT_ANIMATION_CATALOG_INVALID')
  const root = loadLocalRuntimeConfig().dataRoot
  await mkdir(path.join(root, 'catalogs'), { recursive: true })
  await writeFile(path.join(root, 'catalogs', 'jy083-text-animation-catalog.json'), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(JSON.stringify({ ok: true, capability: 'animation.text.named', animation_name: '收拢', binding_count: 1, initial_duration_seconds: entry.duration_us / 1_000_000 }) + '\n')
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY083_CATALOG_FAILED' }) + '\n'); process.exitCode = 1 })
