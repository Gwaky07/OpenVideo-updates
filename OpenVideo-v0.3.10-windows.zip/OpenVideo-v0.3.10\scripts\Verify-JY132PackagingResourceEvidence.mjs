import { createHash } from 'node:crypto'
import { access, mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import {
  createPackagingResourceEvidenceRegistry,
  diagnosePackagingResourceDraftBindings,
  loadPackagingResourceEvidenceIntegrityKey,
  publishPackagingResourceEvidenceRegistry,
  signPackagingResourceEvidenceRegistry,
  verifyPackagingResourceEvidenceRegistry,
} from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { computePackagingEntryBindingFingerprint, parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const directIdEvidenceMode = '--catalog-direct-id-evidence'
const directIdEvidenceRootName = 'packaging-catalog-001-direct-id'
const directIdCatalogFileName = 'packaging-catalog-001-direct-id-catalog.json'
const evidenceRootName = process.argv.includes(directIdEvidenceMode)
  ? directIdEvidenceRootName
  : 'jy132-packaging-resources'
const attestation = '--manual-attestation=opened-edited-saved-reopened'
const fingerprintPattern = /^[a-f0-9]{64}$/u
const draftIdPattern = /^OpenVideo-JY(?:132-packaging|138-private-batch)-[0-9]{10,20}$/u
const safeFailureCodePattern = /^JY[0-9A-Z_]+$/u

export const publicFailureCode = (error) => {
  const message = typeof error?.message === 'string' ? error.message : ''
  return safeFailureCodePattern.test(message) ? message : 'JY132_EVIDENCE_FAILED'
}

export const publicFailureDiagnostic = (error) => {
  const name = typeof error?.name === 'string' && /^[A-Za-z]{1,40}(?:Error)?$/u.test(error.name)
    ? error.name
    : 'Error'
  const code = typeof error?.code === 'string' && /^[A-Z0-9_]{2,80}$/u.test(error.code)
    ? error.code
    : null
  const message = typeof error?.message === 'string'
    ? error.message
        .replace(/[A-Za-z]:[\\/][^\r\n"']+/gu, '<private-path>')
        .replace(/\b(api[_-]?key|token|secret|password|cookie|authorization|account|device[_-]?id)\s*[:=]\s*[^\s,;]+/giu, '$1=<redacted>')
        .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu, '<private-account>')
        .replace(/[A-Za-z0-9_-]{24,}/gu, '<private-id>')
        .slice(0, 240)
    : ''
  return Object.freeze({ name, code, message })
}

/**
 * A published receipt is an idempotent terminal state for this verifier. It
 * is only a shape gate; the caller still performs the full signature, catalog,
 * encrypted-draft and content verification before accepting it.
 * @param {unknown} value
 */
export const isPublishedJY132Receipt = (value) => {
  const candidate = /** @type {any} */ (value)
  return Boolean(candidate && typeof candidate === 'object' && !Array.isArray(candidate) &&
    candidate.schema_version === 1 && candidate.kind === 'jy132_packaging_resource_evidence_registry' &&
    candidate.manual_evidence_verified === true && candidate.manual_attestation === 'opened-edited-saved-reopened' &&
    candidate.opened === true && candidate.edited === true && candidate.saved === true &&
    candidate.reopened === true && candidate.same_draft === true &&
    Array.isArray(candidate.admitted_bindings) && candidate.admitted_bindings.length > 0)
}

/** @param {unknown} error */
export const isMissingJY132PendingLease = (error) => error?.code === 'ENOENT'

/**
 * Resolve the pending lease without conflating a missing file with a corrupt
 * or unreadable file. The injected seams keep the state machine directly
 * testable without exposing runtime paths or evidence content.
 * @param {{pendingPath: string, accessImpl?: typeof access, readImpl?: typeof readFileNoReparse, rootPath?: string}}
 */
export const readJY132PendingLease = async ({ pendingPath, accessImpl = access, readImpl = readFileNoReparse, rootPath }) => {
  try {
    await accessImpl(pendingPath)
  } catch (error) {
    if (isMissingJY132PendingLease(error)) return Object.freeze({ state: 'missing' })
    throw error
  }
  const pending = JSON.parse(await readImpl(pendingPath, rootPath ?? path.dirname(pendingPath)))
  return Object.freeze({ state: 'present', pending })
}

/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) => Boolean(value) && typeof value === 'object' && !Array.isArray(value) &&
  Object.keys(value).length === keys.length && Object.keys(value).every((key) => keys.includes(key))

/** @param {unknown} value */
export const isSafePrivateTempRoot = (value) => {
  if (typeof value !== 'string' || !path.isAbsolute(value)) return false
  const resolved = path.resolve(value)
  const relative = path.relative(path.resolve(tmpdir()), resolved)
  const basename = path.basename(resolved)
  return relative.length > 0 && !relative.startsWith('..') && !path.isAbsolute(relative) &&
    (basename.startsWith('openvideo-jy132-packaging-') ||
      basename.startsWith('openvideo-jy138-private-batch-') ||
      basename.startsWith('openvideo-packaging-catalog-direct-id-'))
}

/** @param {unknown} pending @param {any} desktop @param {any} index */
const assertPending = (pending, desktop, index) => {
  const keys = [
    'schema_version', 'draft_id', 'draft_root', 'profile_id', 'app_version',
    'catalog_fingerprint', 'bundle_fingerprint', 'admitted_bindings', 'pre_open_fingerprint', 'media_root',
  ]
  if (!exactKeys(pending, keys) || pending.schema_version !== 1 ||
      typeof pending.draft_id !== 'string' || !draftIdPattern.test(pending.draft_id) ||
      typeof pending.draft_root !== 'string' || path.resolve(pending.draft_root) !== path.resolve(desktop.draftRoot) ||
      pending.profile_id !== desktop.profileId || pending.app_version !== desktop.version ||
      pending.catalog_fingerprint !== index.catalogFingerprint || !fingerprintPattern.test(pending.bundle_fingerprint ?? '') || !fingerprintPattern.test(pending.pre_open_fingerprint ?? '') ||
      !Array.isArray(pending.admitted_bindings) || pending.admitted_bindings.length === 0 ||
      pending.admitted_bindings.length > 24 || !isSafePrivateTempRoot(pending.media_root)) {
    throw new Error('JY132_EVIDENCE_LEASE_INVALID')
  }
}

/**
 * Normalize the one legacy JY-138 animation fingerprint shape emitted before
 * `kind` was removed from private bindings. Only an exact catalog-derived
 * legacy fingerprint is accepted; all other mismatches remain fail-closed.
 * @param {unknown} bindings
 * @param {any} index
 */
export const normalizePendingEvidenceBindings = (bindings, index) => {
  if (!Array.isArray(bindings)) return bindings
  return bindings.map((binding) => {
    if (!binding || typeof binding !== 'object' || Array.isArray(binding)) return binding
    const entry = index?.entries?.find((candidate) => candidate?.packaging_token === binding.packaging_token)
    if (!entry || entry.family !== 'video_animation' || !entry.private_binding) return binding
    const canonicalFingerprint = computePackagingEntryBindingFingerprint({
      family: entry.family,
      privateBinding: entry.private_binding,
    })
    if (binding.binding_fingerprint === canonicalFingerprint) return binding
    const legacyFingerprint = computePackagingEntryBindingFingerprint({
      family: entry.family,
      privateBinding: { ...entry.private_binding, kind: 'animation' },
    })
    return binding.binding_fingerprint === legacyFingerprint
      ? { ...binding, binding_fingerprint: canonicalFingerprint }
      : binding
  })
}

const run = async () => {
  if (!process.argv.slice(2).includes(attestation)) {
    throw new Error('JY132_MANUAL_ATTESTATION_REQUIRED')
  }
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (!desktop) throw new Error('JY132_DESKTOP_UNAVAILABLE')
  const { dataRoot } = await loadLauncherRuntimeConfig()
  const evidenceRoot = path.join(dataRoot, 'evidence', evidenceRootName)
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const loadIndexForFingerprint = async (catalogFingerprint) => {
    const catalogFileNames = process.argv.includes(directIdEvidenceMode)
      ? [directIdCatalogFileName]
      : ['native018-private-draft-catalog.json', 'jy172-private-packaging-catalog.json', 'jy132-packaging-resource-catalog.json']
    for (const fileName of catalogFileNames) {
      try {
        const catalogRaw = JSON.parse(await readFileNoReparse(path.join(dataRoot, 'catalogs', fileName), dataRoot))
        const parsed = parsePrivatePackagingResourceIndex(catalogRaw, { profileId: desktop.profileId, appVersion: desktop.version })
        if (parsed.catalogFingerprint === catalogFingerprint) return parsed
      } catch { /* try the next private catalog */ }
    }
    return null
  }
  const pendingLease = await readJY132PendingLease({ pendingPath, rootPath: dataRoot })
  if (pendingLease.state === 'missing') {
    // Once a receipt is published, retrying the command must be idempotent;
    // do not reinterpret the missing lease as a native catalog read failure.
    try {
      const postSavePath = path.join(evidenceRoot, 'post-save.json')
      await access(postSavePath)
      const published = JSON.parse(await readFileNoReparse(postSavePath, evidenceRoot))
      if (isPublishedJY132Receipt(published)) {
        const publishedIndex = await loadIndexForFingerprint(published.catalog_fingerprint)
        if (!publishedIndex) throw new Error('JY132_EVIDENCE_CATALOG_MISSING')
        const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({ evidenceRoot })
        const verified = await verifyPackagingResourceEvidenceRegistry({ evidence: published, index: publishedIndex, desktop, integrityKey })
        if (verified) {
          process.stdout.write(JSON.stringify({ ok: true, already_published: true, admitted_bindings: verified.admitted_bindings.length, profile: desktop.profileId, version: desktop.version }) + '\n')
          return
        }
      }
    } catch { /* fall through to a stable missing-lease code */ }
    throw new Error('JY132_EVIDENCE_PENDING_MISSING')
  }
  const pending = pendingLease.pending
  const index = await loadIndexForFingerprint(pending.catalog_fingerprint)
  if (!index) throw new Error('JY132_EVIDENCE_CATALOG_MISSING')
  assertPending(pending, desktop, index)
  const admittedBindings = normalizePendingEvidenceBindings(pending.admitted_bindings, index)

  const encryptedPath = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json')
  const owner = JSON.parse(await readFileNoReparse(path.join(desktop.draftRoot, pending.draft_id, '.openvideo-owner.json'), desktop.draftRoot))
  if (owner?.bundle_fingerprint !== pending.bundle_fingerprint) throw new Error('QA010_CANONICAL_BUNDLE_METADATA_MISMATCH')
  const encrypted = await readFileNoReparseBuffer(encryptedPath, desktop.draftRoot)
  const postSaveFingerprint = createHash('sha256').update(encrypted).digest('hex')
  if (postSaveFingerprint === pending.pre_open_fingerprint) throw new Error('JY132_MANUAL_EDIT_NOT_PERSISTED')

  const inspectionRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy132-evidence-'))
  let plaintext
  try {
    const plaintextPath = path.join(inspectionRoot, 'draft_content.json')
    const decryptor = await createJianyingDraftDecryptor({
      installRoot: desktop.installRoot,
      appVersion: desktop.version,
      // The decoder is bound to the exact executable/DLL selected by the
      // current desktop probe. Omitting this private fingerprint makes a
      // valid installed profile look like a DLL mismatch.
      expectedDllFingerprint: desktop.dllFingerprint,
    })
    const result = await decryptor.ensurePlaintextFile(encryptedPath, plaintextPath)
    if (result?.scheme !== 'encrypt_v2' && result?.decryptedFrom !== 'encrypt_v2') throw new Error('JY132_DRAFT_SCHEME_INVALID')
    plaintext = await readFileNoReparse(plaintextPath, inspectionRoot)
  } finally {
    await rm(inspectionRoot, { recursive: true, force: true })
  }

  await rm(path.resolve(pending.media_root), { recursive: true, force: true })
  const unsigned = createPackagingResourceEvidenceRegistry({
    index,
    desktop,
    draftId: pending.draft_id,
    bundleFingerprint: pending.bundle_fingerprint,
    preOpenFingerprint: pending.pre_open_fingerprint,
    postSaveFingerprint,
    contentFingerprint: createHash('sha256').update(plaintext).digest('hex'),
    admittedBindings,
  })
  const bindingDiagnostic = diagnosePackagingResourceDraftBindings({
    content: JSON.parse(plaintext),
    index,
    admittedBindings,
  })
  if (!bindingDiagnostic.ok) {
    const failed = bindingDiagnostic.failed_constraints
      .map((constraint) => constraint.toUpperCase().replaceAll(/[^A-Z0-9]+/gu, '_'))
      .join('_')
    throw new Error(`JY132_POST_SAVE_BINDING_INVALID_${failed || 'UNKNOWN'}`)
  }
  await securePrivateRuntimeRoot(evidenceRoot)
  const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({ evidenceRoot, create: true })
  const evidence = { ...unsigned, integrity_signature: signPackagingResourceEvidenceRegistry(unsigned, integrityKey) }
  const verified = await verifyPackagingResourceEvidenceRegistry({ evidence, index, desktop, integrityKey })
  if (!verified) throw new Error('JY132_POST_SAVE_BINDING_INVALID')
  await publishPackagingResourceEvidenceRegistry({ evidenceRoot, evidence })
  await rm(pendingPath, { force: true })
  process.stdout.write(JSON.stringify({ ok: true, admitted_bindings: verified.admitted_bindings.length, profile: desktop.profileId, version: desktop.version }) + '\n')
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  run().catch((error) => {
    process.stdout.write(JSON.stringify({
      ok: false,
      code: publicFailureCode(error),
      diagnostic: publicFailureDiagnostic(error),
    }) + '\n')
    process.exitCode = 1
  })
}
