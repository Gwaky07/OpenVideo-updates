const providerStatusKeys = new Set(['available', 'state', 'code'])
const providerStatusVersionKeys = new Set([...providerStatusKeys, 'analyzerVersion'])
const analyzedSceneBaseKeys = new Set(['id', 'start', 'end', 'summary'])
const baseSceneCardKeys = [
  'visualObservations',
  'ocrText',
  'ocrSource',
  'asrTranscript',
  'asrSummary',
  'domainTags',
  'visualTags',
  'actionTags',
  'shotPurpose',
  'recommendedUse',
  'confidence',
  'evidenceReferences',
  'needsReview',
]
// Structured fields are derived from the same frame/OCR/ASR evidence as the
// presentation card. They make the card useful to search, storyboarding and
// timeline decisions without introducing a second timeline contract.
const structuredSceneCardKeys = [
  'contentSummary',
  'entities',
  'actions',
  'screenState',
  'sceneChanges',
  'educationContext',
  'editingValue',
  'qualityReasons',
]
const sceneCardKeys = [...baseSceneCardKeys, ...structuredSceneCardKeys]
const legacyPresentationKeys = ['contentType', 'qualityFlags', 'isHighlight', 'narrativeRole', 'hasSpeaker', 'speechStyle']
const analyzedSceneKeys = new Set([...analyzedSceneBaseKeys, 'tags'])
const analyzedSceneCardKeys = new Set([...analyzedSceneBaseKeys, ...sceneCardKeys])
const analyzedSceneCardTagKeys = new Set([...analyzedSceneBaseKeys, 'tags', ...sceneCardKeys])
const legacySceneCardKeys = new Set([...baseSceneCardKeys].filter((key) => key !== 'visualObservations'))
const legacyAnalyzedSceneCardKeys = new Set([...analyzedSceneBaseKeys, ...legacySceneCardKeys])
const legacyAnalyzedSceneCardTagKeys = new Set([...analyzedSceneBaseKeys, 'tags', ...legacySceneCardKeys])
const structuredLegacySceneCardKeys = new Set([
  ...analyzedSceneBaseKeys,
  ...baseSceneCardKeys.filter((key) => key !== 'visualObservations'),
  ...structuredSceneCardKeys,
])
const structuredLegacySceneCardTagKeys = new Set([
  ...analyzedSceneBaseKeys,
  'tags',
  ...baseSceneCardKeys.filter((key) => key !== 'visualObservations'),
  ...structuredSceneCardKeys,
])
const extendedAnalyzedSceneCardKeys = new Set([...analyzedSceneBaseKeys, ...legacyPresentationKeys, ...legacySceneCardKeys])
const extendedAnalyzedSceneCardTagKeys = new Set([...analyzedSceneBaseKeys, 'tags', ...legacyPresentationKeys, ...legacySceneCardKeys])
const analyzedFolderKeys = new Set(['id', 'label', 'parentId'])
const analyzedAssetBaseKeys = new Set([
  'id',
  'label',
  'status',
  'analyzedPercent',
  'durationSeconds',
  'sceneCount',
])
const analyzedAssetFolderKeys = new Set([
  ...analyzedAssetBaseKeys,
  'folderTrail',
])
const analyzedAssetDetailKeys = new Set([
  ...analyzedAssetBaseKeys,
  'scenes',
])
const legacyAssetDetailKeys = new Set([
  ...analyzedAssetBaseKeys,
  'assetOverview',
  'contentStructure',
  'recommendedFor',
  'emotionalTone',
  'scenes',
])
const analyzedAssetFolderDetailKeys = new Set([
  ...analyzedAssetBaseKeys,
  'folderTrail',
  'scenes',
])
const analyzedMaterialsKeys = new Set([
  'authorizationId',
  'authorized',
  'readOnlyConfirmed',
  'folderLabel',
  'total',
  'analyzed',
  'queued',
  'failed',
  'analysisStatus',
  'lastScanAt',
  'assets',
])
const analyzedMaterialsVersionKeys = new Set([...analyzedMaterialsKeys, 'analyzerVersion'])
const analyzedMaterialsReferenceKeys = new Set([...analyzedMaterialsKeys, 'referencedAssetCount'])
const analyzedMaterialsReferenceVersionKeys = new Set([...analyzedMaterialsVersionKeys, 'referencedAssetCount'])
const searchCandidateBaseKeys = new Set(['id', 'assetId', 'assetLabel', 'start', 'end', 'summary', 'matchScore', 'reason'])
const searchCandidateKeys = new Set([...searchCandidateBaseKeys, 'tags'])
// Compact creator-facing decision fields. This projection explains how a
// scene can be used without repeating private or technical OCR/ASR evidence.
const searchCandidateDecisionKeys = new Set([
  ...searchCandidateKeys,
  'shotPurpose',
  'recommendedUse',
  'confidence',
  'needsReview',
  'entities',
  'actions',
  'screenState',
  'sceneChanges',
  'educationContext',
  'editingValue',
  'qualityReasons',
])
const searchCandidateDecisionFallbackKeys = new Set([...searchCandidateDecisionKeys, 'semanticFallback'])
const searchCandidateCardKeys = new Set([...searchCandidateBaseKeys, ...sceneCardKeys])
const searchCandidateCardTagKeys = new Set([...searchCandidateBaseKeys, 'tags', ...sceneCardKeys])
const searchCandidateCardFallbackKeys = new Set([...searchCandidateCardKeys, 'semanticFallback'])
const searchCandidateCardTagFallbackKeys = new Set([...searchCandidateCardTagKeys, 'semanticFallback'])
const legacySearchCandidateCardKeys = new Set([...searchCandidateBaseKeys, ...legacySceneCardKeys])
const legacySearchCandidateCardTagKeys = new Set([...searchCandidateBaseKeys, 'tags', ...legacySceneCardKeys])
const legacySearchCandidateCardFallbackKeys = new Set([...legacySearchCandidateCardKeys, 'semanticFallback'])
const legacySearchCandidateCardTagFallbackKeys = new Set([...legacySearchCandidateCardTagKeys, 'semanticFallback'])

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {number} maximum */
const safeText = (value, maximum) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maximum &&
  !value.includes('\u0000')
/** @param {unknown} value @param {number} maximum */
const safeLabel = (value, maximum) =>
  safeText(value, maximum) &&
  !/** @type {string} */ (value).includes('\\') &&
  !/** @type {string} */ (value).includes('/') &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(/** @type {string} */ (value))
/** @param {unknown} value @param {number} maximum */
const safePublicLabel = (value, maximum) =>
  safeLabel(value, maximum) &&
  !/(?:%2f|%5c|%3a|\b[a-f0-9]{64}\b|\b(?:access[_ -]?token|api[_ -]?key|fingerprint)\b)/iu
    .test(/** @type {string} */ (value))
/** @param {unknown} value @param {number} maximum */
const safePublicText = (value, maximum) =>
  safeText(value, maximum) &&
  !/** @type {string} */ (value).includes('\\') &&
  // A slash can be ordinary OCR punctuation (for example, "版本 A / 版本 B").
  // Reject only absolute/UNC path shapes here; URLs and media extensions stay
  // covered by the checks below.
  !/(?:[A-Za-z]:[\\/]|\\\\|(?:^|[\s"'(])\/(?:[^\s/]+\/)+)/u.test(/** @type {string} */ (value)) &&
  !/(?:file:|https?:|%2f|%5c|%3a|\b[a-f0-9]{64}\b|\b(?:access[_ -]?token|api[_ -]?key|fingerprint)\b|\.(?:mp4|mov|mkv|avi|webm|wmv|mp3|wav|aac|m4a)(?:\b|$))/iu
    .test(/** @type {string} */ (value))
/** @param {Record<string, unknown>} value @param {Set<string>} keys */
const hasExactKeys = (value, keys) =>
  Object.keys(value).length === keys.size &&
  Object.keys(value).every((key) => keys.has(key))

/** @param {unknown} value @param {number} maximumItems @param {number} maximumText */
const safeLabelArray = (value, maximumItems, maximumText) =>
  Array.isArray(value) &&
  value.length <= maximumItems &&
  value.every((item) => safeLabel(item, maximumText))

/** @param {unknown} value @param {number} maximumItems @param {number} maximumText */
const safePublicLabelArray = (value, maximumItems, maximumText) =>
  Array.isArray(value) &&
  value.length <= maximumItems &&
  value.every((item) => safePublicLabel(item, maximumText))

/** @param {unknown} value @param {number} maximumItems @param {number} maximumText */
const safePublicTextArray = (value, maximumItems, maximumText) =>
  Array.isArray(value) &&
  value.length <= maximumItems &&
  value.every((item) => safePublicText(item, maximumText))

/** @param {Record<string, unknown>} scene */
const validSceneCardFields = (scene) =>
  (!('contentType' in scene) || safePublicLabel(scene.contentType, 120)) &&
  (!('qualityFlags' in scene) || safePublicLabelArray(scene.qualityFlags, 12, 80)) &&
  (!('isHighlight' in scene) || typeof scene.isHighlight === 'boolean') &&
  (!('narrativeRole' in scene) || safePublicLabel(scene.narrativeRole, 120)) &&
  (!('hasSpeaker' in scene) || typeof scene.hasSpeaker === 'boolean') &&
  (!('speechStyle' in scene) || safePublicLabel(scene.speechStyle, 120) || scene.speechStyle === '') &&
  (!('visualObservations' in scene) || safePublicTextArray(scene.visualObservations, 6, 500)) &&
  safePublicText(scene.ocrText, 500) &&
  typeof scene.ocrSource === 'string' &&
  ['ocr_engine', 'llm_vision', 'taxonomy_fallback'].includes(scene.ocrSource) &&
  safePublicText(scene.asrTranscript, 500) &&
  safePublicText(scene.asrSummary, 500) &&
  scene.asrTranscript === scene.asrSummary &&
  safePublicLabelArray(scene.domainTags, 12, 80) &&
  safePublicLabelArray(scene.visualTags, 12, 80) &&
  safePublicLabelArray(scene.actionTags, 12, 80) &&
  safePublicLabel(scene.shotPurpose, 120) &&
  safePublicText(scene.recommendedUse, 500) &&
  typeof scene.confidence === 'number' &&
  Number.isFinite(scene.confidence) &&
  scene.confidence >= 0 &&
  scene.confidence <= 1 &&
  safePublicLabelArray(scene.evidenceReferences, 12, 120) &&
  typeof scene.needsReview === 'boolean' &&
  (!('contentSummary' in scene) || safePublicText(scene.contentSummary, 500)) &&
  (!('entities' in scene) || safePublicLabelArray(scene.entities, 12, 80)) &&
  (!('actions' in scene) || safePublicLabelArray(scene.actions, 8, 80)) &&
  (!('screenState' in scene) || safePublicLabel(scene.screenState, 160)) &&
  (!('sceneChanges' in scene) || safePublicLabelArray(scene.sceneChanges, 8, 120)) &&
  (!('educationContext' in scene) || safePublicLabelArray(scene.educationContext, 8, 80)) &&
  (!('editingValue' in scene) || safePublicText(scene.editingValue, 500)) &&
  (!('qualityReasons' in scene) || safePublicLabelArray(scene.qualityReasons, 8, 120))

export const materialAnalysisProviderErrorCodes = Object.freeze({
  unavailable: 'MATERIAL_ANALYSIS_PROVIDER_UNAVAILABLE',
  analysisUnavailable: 'WORKBENCH_MATERIAL_ANALYSIS_UNAVAILABLE',
  searchUnavailable: 'WORKBENCH_MATERIAL_SEARCH_UNAVAILABLE',
  analysisFailed: 'MATERIAL_ANALYSIS_FAILED',
  cancelled: 'MATERIAL_ANALYSIS_CANCELLED',
})

/** @param {unknown} value */
export const validMaterialAnalysisProviderStatus = (value) => {
  if (!isRecord(value) ||
    !(hasExactKeys(value, providerStatusKeys) || hasExactKeys(value, providerStatusVersionKeys))) return false
  return typeof value.available === 'boolean' &&
    (value.state === 'ready' || value.state === 'blocked') &&
    (value.code === null || safeLabel(value.code, 160)) &&
    (!('analyzerVersion' in value) || safeLabel(value.analyzerVersion, 160))
}

/** @param {unknown} value */
export const validAnalyzedAsset = (value) => {
  if (!isRecord(value)) return false
  const hasBase = hasExactKeys(value, analyzedAssetBaseKeys) || hasExactKeys(value, analyzedAssetFolderKeys)
  const hasDetail = hasExactKeys(value, analyzedAssetDetailKeys) || hasExactKeys(value, analyzedAssetFolderDetailKeys) ||
    hasExactKeys(value, legacyAssetDetailKeys) || hasExactKeys(value, new Set([...legacyAssetDetailKeys, 'folderTrail']))
  if (!hasBase && !hasDetail) return false
  if (
    !safeLabel(value.id, 160) ||
    !safePublicLabel(value.label, 160) ||
    value.status !== 'ready' ||
    value.analyzedPercent !== 100 ||
    typeof value.durationSeconds !== 'number' ||
    !Number.isFinite(value.durationSeconds) ||
    value.durationSeconds < 0 ||
    !Number.isInteger(value.sceneCount) ||
    /** @type {number} */ (value.sceneCount) <= 0
  ) return false
  if ('folderTrail' in value) {
    if (
      !Array.isArray(value.folderTrail) ||
      value.folderTrail.length > 32 ||
      value.folderTrail.some((folder, index) =>
        !isRecord(folder) ||
        !hasExactKeys(folder, analyzedFolderKeys) ||
        !safeLabel(folder.id, 160) ||
        !safePublicLabel(folder.label, 80) ||
        (index === 0
          ? folder.parentId !== null
          : folder.parentId !== /** @type {Record<string, unknown>[]} */ (value.folderTrail)[index - 1].id))
    ) return false
    const folderIds = value.folderTrail.map((folder) => folder.id)
    if (new Set(folderIds).size !== folderIds.length) return false
  }
  if (hasBase) return true
  if (!Array.isArray(value.scenes) || value.scenes.length !== value.sceneCount) return false
  return value.scenes.every((scene, index) =>
    isRecord(scene) &&
    (
      hasExactKeys(scene, analyzedSceneBaseKeys) ||
      hasExactKeys(scene, analyzedSceneKeys) ||
      hasExactKeys(scene, analyzedSceneCardKeys) ||
      hasExactKeys(scene, analyzedSceneCardTagKeys) ||
      hasExactKeys(scene, legacyAnalyzedSceneCardKeys) ||
      hasExactKeys(scene, legacyAnalyzedSceneCardTagKeys) ||
      hasExactKeys(scene, structuredLegacySceneCardKeys) ||
      hasExactKeys(scene, structuredLegacySceneCardTagKeys) ||
      hasExactKeys(scene, extendedAnalyzedSceneCardKeys) ||
      hasExactKeys(scene, extendedAnalyzedSceneCardTagKeys)
    ) &&
    safeLabel(scene.id, 160) &&
    typeof scene.start === 'number' &&
    Number.isFinite(scene.start) &&
    scene.start >= 0 &&
    typeof scene.end === 'number' &&
    Number.isFinite(scene.end) &&
    scene.end > scene.start &&
    scene.end <= /** @type {number} */ (value.durationSeconds) + 0.001 &&
    (index === 0 || scene.start >= /** @type {Record<string, number>[]} */ (value.scenes)[index - 1].end) &&
    safePublicText(scene.summary, 500) &&
    (
      !('tags' in scene) ||
      (Array.isArray(scene.tags) &&
        scene.tags.length <= 8 &&
        scene.tags.every((tag) => safePublicLabel(tag, 80)))
    ) &&
    (
      !('ocrText' in scene) ||
      validSceneCardFields(scene)
    )
  )
}

/** @param {unknown} value @param {string} authorizationId */
export const validAnalyzedMaterials = (value, authorizationId) => {
  if (!isRecord(value) ||
    !(hasExactKeys(value, analyzedMaterialsKeys) || hasExactKeys(value, analyzedMaterialsVersionKeys))) return false
  return value.authorizationId === authorizationId &&
    value.authorized === true &&
    value.readOnlyConfirmed === true &&
    safePublicLabel(value.folderLabel, 100) &&
    Number.isInteger(value.total) &&
    /** @type {number} */ (value.total) > 0 &&
    value.analyzed === value.total &&
    value.queued === 0 &&
    value.failed === 0 &&
    value.analysisStatus === 'ready' &&
    (!('analyzerVersion' in value) || safeLabel(value.analyzerVersion, 160)) &&
    typeof value.lastScanAt === 'string' &&
    Number.isFinite(Date.parse(value.lastScanAt)) &&
    Array.isArray(value.assets) &&
    value.assets.length === value.total &&
    value.assets.every(validAnalyzedAsset)
}

/**
 * Storyboard may consume a complete local index plus opaque library
 * references. The public/persisted totals can include those references;
 * the analyzer output contract itself stays exact and local-only.
 * @param {unknown} value
 * @param {string} authorizationId
 */
export const validStoryboardMaterialIndex = (value, authorizationId) => {
  if (validAnalyzedMaterials(value, authorizationId)) return true
  if (!isRecord(value) ||
    !(hasExactKeys(value, analyzedMaterialsReferenceKeys) ||
      hasExactKeys(value, analyzedMaterialsReferenceVersionKeys))) return false
  const referenced = value.referencedAssetCount
  if (!Number.isInteger(referenced) || referenced < 0) return false
  const assets = Array.isArray(value.assets) ? value.assets : []
  if (value.total !== assets.length + referenced) return false
  const local = {
    ...value,
    total: assets.length,
    analyzed: assets.length,
  }
  delete local.referencedAssetCount
  return validAnalyzedMaterials(local, authorizationId)
}

/**
 * Keep the provider-neutral boundary from exposing verbatim speech while the
 * legacy browser DTO still carries the asrTranscript key.
 * @param {unknown} value
 * @param {string} authorizationId
 */
export const projectAnalyzedMaterialsForPublic = (value, authorizationId) => {
  if (!isRecord(value) || !Array.isArray(value.assets)) return null
  const projected = structuredClone(value)
  for (const asset of /** @type {unknown[]} */ (projected.assets)) {
    if (!isRecord(asset) || !Array.isArray(asset.scenes)) continue
    for (const scene of asset.scenes) {
      if (!isRecord(scene) || !('asrSummary' in scene) || !('asrTranscript' in scene)) continue
      scene.asrTranscript = scene.asrSummary
    }
  }
  return validAnalyzedMaterials(projected, authorizationId) ? projected : null
}

/** @param {unknown} value */
export const validSearchCandidate = (value) => {
  if (
    !isRecord(value) ||
    !(
      hasExactKeys(value, searchCandidateBaseKeys) ||
      hasExactKeys(value, searchCandidateKeys) ||
      hasExactKeys(value, searchCandidateDecisionKeys) ||
      hasExactKeys(value, searchCandidateDecisionFallbackKeys) ||
      hasExactKeys(value, searchCandidateCardKeys) ||
      hasExactKeys(value, searchCandidateCardTagKeys) ||
      hasExactKeys(value, searchCandidateCardFallbackKeys) ||
      hasExactKeys(value, searchCandidateCardTagFallbackKeys) ||
      hasExactKeys(value, legacySearchCandidateCardKeys) ||
      hasExactKeys(value, legacySearchCandidateCardTagKeys) ||
      hasExactKeys(value, legacySearchCandidateCardFallbackKeys) ||
      hasExactKeys(value, legacySearchCandidateCardTagFallbackKeys)
    )
  ) return false
  return safeLabel(value.id, 160) &&
    safeLabel(value.assetId, 160) &&
    safePublicLabel(value.assetLabel, 160) &&
    typeof value.start === 'number' &&
    Number.isFinite(value.start) &&
    value.start >= 0 &&
    typeof value.end === 'number' &&
    Number.isFinite(value.end) &&
    value.end > value.start &&
    safePublicText(value.summary, 500) &&
    (
      !('tags' in value) ||
      (Array.isArray(value.tags) &&
        value.tags.length <= 8 &&
        value.tags.every((tag) => safePublicLabel(tag, 80)))
    ) &&
    typeof value.matchScore === 'number' &&
    Number.isFinite(value.matchScore) &&
    value.matchScore >= 0 &&
    value.matchScore <= 1 &&
    safePublicText(value.reason, 500) &&
    (
      !('ocrText' in value) ||
      validSceneCardFields(value)
    ) &&
    (
      !('shotPurpose' in value) ||
      (
        safePublicLabel(value.shotPurpose, 120) &&
        safePublicText(value.recommendedUse, 500) &&
        typeof value.confidence === 'number' &&
        Number.isFinite(value.confidence) &&
        value.confidence >= 0 &&
        value.confidence <= 1 &&
        typeof value.needsReview === 'boolean' &&
        safePublicLabelArray(value.entities, 12, 80) &&
        safePublicLabelArray(value.actions, 8, 80) &&
        safePublicLabel(value.screenState, 160) &&
        safePublicLabelArray(value.sceneChanges, 8, 120) &&
        safePublicLabelArray(value.educationContext, 8, 80) &&
        safePublicText(value.editingValue, 500) &&
        safePublicLabelArray(value.qualityReasons, 8, 120)
      )
    )
    && (!('semanticFallback' in value) || typeof value.semanticFallback === 'boolean')
}

/**
 * @typedef {object} MaterialAnalysisProvider
 * @property {() => {available: boolean, state: 'ready'|'blocked', code: string|null}} getStatus
 * @property {(input: {authorizationId: string, projectId: string, force?: boolean, signal?: AbortSignal, onProgress?: (progress: {analyzed: number, total: number, label: string|null, overallPercent: number, assets: Array<{id: string, label: string, status: 'queued'|'analyzing'|'ready'|'failed', progressPercent: number, stage: string, detail: string}>, completedMaterials?: Record<string, unknown>}) => unknown}) => Promise<Record<string, unknown>>} analyzeMaterials
 * @property {(input: {authorizationId: string, projectId: string, signal?: AbortSignal}) => Promise<Record<string, unknown>>} restoreAnalysis
 * @property {(input: {authorizationId: string, projectId: string, query: string, signal?: AbortSignal}) => Promise<Record<string, unknown>[]>} searchCandidates
 */

