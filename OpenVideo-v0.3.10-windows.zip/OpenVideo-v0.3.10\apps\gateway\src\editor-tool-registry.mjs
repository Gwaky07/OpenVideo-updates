import {
  EDITOR_BUDGETS,
  EDITOR_TOOL_NAMES,
  EditorAgentContractError,
  assertTimelinePatchOperations,
  containsPrivateReference,
  fingerprintCanonical,
  toEditorResumeCommittedExecutions,
  validEditorCommittedExecutionResult,
} from './editor-agent-contracts.mjs'
import { applyRichTimelinePatch } from './rich-timeline-patch.mjs'
import {
  computeCapabilityRequirements,
  sealRichTimeline,
  toPublicTimelineSummary,
} from './rich-timeline-contracts.mjs'
import { readTimelinePackagingSelections } from './jianying-timeline-packaging-selections.mjs'
import { createTemplateGuidance } from './template-binding-consumption.mjs'
import { projectRecommendationToRichTimeline } from './jianying-packaging-recommender.mjs'
import { isOpaquePackagingToken } from './jianying-packaging-resource-index.mjs'
import {
  PackagingTextLayoutError,
  derivePackagingEmphasisText,
  solvePackagingTextLayouts,
} from './packaging-text-layout.mjs'
import {
  applyPackagingPlanToTimelineTemplateConstraints,
  createTimelineTemplateConstraints,
} from './timeline-template-constraints.mjs'
import {
  buildPackagingIntent,
  buildPackagingPlan,
  normalizePackaging,
  redactBriefText,
} from './brief-packaging.mjs'

const PACKAGING_RECOMMENDATION_TTL_MS = 5 * 60 * 1000
const EFFECT_TRACK_PACKAGING_FAMILIES = new Set([
  'flower',
  'bubble',
  'video_effect',
  'filter',
  'sticker',
  'video_animation',
  'mask',
  'blend',
])

export class EditorToolRegistryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'EditorToolRegistryError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  throw new EditorToolRegistryError(code, status)
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
const opaqueId = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {Record<string, any>} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} value */
const safeText = (value) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= 1_000 &&
  !containsPrivateReference(value)
/** @param {unknown} value */
const nonNegativeUs = (value) =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0
/** @param {unknown} value */
const positiveRevision = (value) =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 1
/** @param {unknown} value */
const fingerprint = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value)

const packagingRecommendationFamilies = new Set([
  'flower',
  'bubble',
  'sticker',
  'filter',
  'video_effect',
  'video_animation',
  'mask',
  'blend',
  'transition',
  'audio_effect',
  'text_animation',
])
const packagingRecommendationItemKeys = [
  'packagingToken',
  'family',
  'label',
  'tags',
  'targetSegmentId',
  'targetRange',
  'parameters',
  'reason',
]

/**
 * @typedef {{
 *   packagingToken: string,
 *   family: string,
 *   label: string,
 *   tags: string[],
 *   targetSegmentId: string,
 *   targetRange: {startUs: number, durationUs: number},
 *   parameters: Record<string, any>,
 *   reason: string,
 * }} IssuedPackagingSelection
 */

/**
 * @typedef {{
 *   catalogRevisionToken: string,
 *   catalogFingerprint: string | null,
 *   issuedAt: number,
 *   projectedPatches: Record<string, any>[],
 *   selections: IssuedPackagingSelection[],
 * }} IssuedPackagingRecommendation
 */
/** @param {string} family */
const recommendationTokenField = (family) =>
  family === 'flower' || family === 'bubble'
    ? 'templateToken'
    : family === 'video_animation' || family === 'text_animation'
      ? 'animationToken'
      : family === 'mask'
        ? 'maskToken'
        : family === 'blend'
          ? 'blendToken'
          : family === 'audio_effect'
            ? 'effectToken'
            : 'packagingToken'

/** @param {unknown} value @param {number} [max] */
const safeRecommendationText = (value, max = 240) =>
  typeof value === 'string' && value.length > 0 && value.length <= max && !containsPrivateReference(value)

/** @param {unknown} value */
const safeRecommendationRange = (value) =>
  isRecord(value) &&
  exactKeys(value, ['startUs', 'durationUs']) &&
  Number.isSafeInteger(value.startUs) &&
  value.startUs >= 0 &&
  Number.isSafeInteger(value.durationUs) &&
  value.durationUs > 0

/** @param {unknown} value */
const safePackagingRecommendationResult = (value) =>
  value === null || (isRecord(value) && !containsPrivateReference(value))

/** @param {string} tool @param {Record<string, any>} args */
const assertToolArguments = (tool, args) => {
  const projectOnly = ['get_project_brief', 'get_template_constraints', 'get_capability_matrix', 'recommend_packaging']
  if (projectOnly.includes(tool) && exactKeys(args, ['projectId'])) return
  if (
    tool === 'search_materials' &&
    exactKeys(args, ['projectId', 'query', 'desiredDurationUs', 'limit']) &&
    safeText(args.query) &&
    nonNegativeUs(args.desiredDurationUs) &&
    Number.isSafeInteger(args.limit) &&
    args.limit >= 1 &&
    args.limit <= 10
  ) return
  if (
    tool === 'inspect_candidate' &&
    exactKeys(args, ['projectId', 'candidateId']) &&
    opaqueId(args.candidateId)
  ) return
  if (
    tool === 'get_timeline_summary' &&
    exactKeys(args, ['projectId', 'timelineId', 'revision']) &&
    opaqueId(args.timelineId) &&
    positiveRevision(args.revision)
  ) return
  if (
    tool === 'preflight_timeline' &&
    exactKeys(args, ['projectId', 'timelineId', 'revision', 'revisionFingerprint']) &&
    opaqueId(args.timelineId) &&
    positiveRevision(args.revision) &&
    fingerprint(args.revisionFingerprint)
  ) return
  if (
    tool === 'propose_timeline_patch' &&
    exactKeys(args, [
      'projectId',
      'baseRevision',
      'baseRevisionFingerprint',
      'operations',
      'rationale',
      'idempotencyKey',
    ]) &&
    (
      (args.baseRevision === null && args.baseRevisionFingerprint === null) ||
      (positiveRevision(args.baseRevision) && fingerprint(args.baseRevisionFingerprint))
    ) &&
    Array.isArray(args.operations) &&
    safeText(args.rationale) &&
    opaqueId(args.idempotencyKey)
  ) return
  if (
    tool === 'apply_packaging_recommendation' &&
    exactKeys(args, [
      'projectId',
      'timelineId',
      'revision',
      'revisionFingerprint',
      'recommendationId',
      'catalogRevisionToken',
      'idempotencyKey',
    ]) &&
    opaqueId(args.timelineId) &&
    positiveRevision(args.revision) &&
    fingerprint(args.revisionFingerprint) &&
    opaqueId(args.recommendationId) &&
    opaqueId(args.catalogRevisionToken) &&
    opaqueId(args.idempotencyKey)
  ) return
  if (
    ['finalize_timeline', 'request_preview', 'request_jianying_export'].includes(tool) &&
    exactKeys(args, [
      'projectId',
      'timelineId',
      'revision',
      'revisionFingerprint',
      'idempotencyKey',
    ]) &&
    opaqueId(args.timelineId) &&
    positiveRevision(args.revision) &&
    fingerprint(args.revisionFingerprint) &&
    opaqueId(args.idempotencyKey)
  ) return
  fail('EDITOR_TOOL_ARGUMENTS_INVALID', 400)
}

/**
 * @param {{
 *   projectId: string,
 *   handlers: Record<string, Function>,
 *   toolRegistryFingerprint?: string,
 *   capabilityRegistryFingerprint?: string,
 *   validateResumeExecution?: (execution: {
 *     tool: string,
 *     idempotencyKey: string,
 *     requestHash: string,
 *     resultFingerprint: string,
 *     result: unknown,
 *     request: Record<string, any> | null,
 *   }) => Promise<unknown>,
 *   authorizeAudioToken?: (input: {
 *     projectId: string,
 *     segmentId: string,
 *     audioToken: string,
 *     volume: number,
 *   }) => Promise<boolean>,
 *   requiredSemanticSegmentIds?: string[],
 *   protectedSegmentIds?: string[],
 *   resumeExecutions?: Array<{
 *     tool: string,
 *     idempotencyKey: string,
 *     requestHash: string,
 *     result: unknown,
 *   }>,
 * }} options
 */
export const createEditorToolRegistry = (options) => {
  if (!opaqueId(options?.projectId)) fail('EDITOR_TOOL_PROJECT_INVALID', 400)
  if (!isRecord(options.handlers)) fail('EDITOR_TOOL_HANDLERS_INVALID', 500)

  for (const name of EDITOR_TOOL_NAMES) {
    if (typeof options.handlers[name] !== 'function') {
      fail('EDITOR_TOOL_HANDLER_MISSING', 500)
    }
  }
  for (const name of Object.keys(options.handlers)) {
    if (!EDITOR_TOOL_NAMES.includes(name)) fail('EDITOR_TOOL_HANDLER_UNKNOWN', 500)
  }

  const toolRegistryFingerprint = options.toolRegistryFingerprint ??
    fingerprintCanonical({ tools: EDITOR_TOOL_NAMES, budgets: EDITOR_BUDGETS })
  const capabilityRegistryFingerprint = options.capabilityRegistryFingerprint ??
    fingerprintCanonical({ registry: 'stub', version: 1 })

  let toolCalls = 0
  let searchCalls = 0
  /** @type {Set<string>} */
  const inspectedCandidates = new Set()
  /** @type {Map<string, Record<string, any>>} */
  const authorizedCandidates = new Map()
  let jobOperationsUsed = 0
  const sideEffectTools = new Set([
    'propose_timeline_patch',
    'apply_packaging_recommendation',
    'finalize_timeline',
    'request_preview',
    'request_jianying_export',
  ])
  const requiredSemanticSegmentIds = new Set(options.requiredSemanticSegmentIds ?? [])
  if (
    requiredSemanticSegmentIds.size !== (options.requiredSemanticSegmentIds ?? []).length ||
    requiredSemanticSegmentIds.size > EDITOR_BUDGETS.maxSearchMaterials ||
    [...requiredSemanticSegmentIds].some((segmentId) => !opaqueId(segmentId))
  ) {
    fail('EDITOR_TOOL_SEMANTIC_REQUIREMENTS_INVALID', 500)
  }
  const protectedSegmentIds = new Set(options.protectedSegmentIds ?? [])
  if (
    protectedSegmentIds.size !== (options.protectedSegmentIds ?? []).length ||
    [...protectedSegmentIds].some((segmentId) => !opaqueId(segmentId))
  ) {
    fail('EDITOR_TOOL_CONFIGURATION_INVALID', 500)
  }
  const semanticReplacedSegmentIds = new Set()
  let semanticTimelineSummaryRead = false
  /** @type {Map<string, {tool: string, idempotencyKey: string, requestHash: string, resultFingerprint?: string, result: unknown, resumeStateValidated?: boolean, resumeRequestValidated?: boolean}>} */
  const idempotentResults = new Map()
  let resumeExecutions = []
  try {
    resumeExecutions = toEditorResumeCommittedExecutions(options.resumeExecutions ?? [])
  } catch (error) {
    if (error instanceof EditorAgentContractError) {
      fail('EDITOR_TOOL_RESUME_STATE_INVALID', 500)
    }
    throw error
  }
  for (const execution of resumeExecutions) {
    const key = `${options.projectId}\u0000${execution.tool}\u0000${execution.idempotencyKey}`
    idempotentResults.set(key, {
      tool: execution.tool,
      idempotencyKey: execution.idempotencyKey,
      requestHash: execution.requestHash,
      resultFingerprint: execution.resultFingerprint,
      result: structuredClone(execution.result),
      resumeStateValidated: false,
      resumeRequestValidated: false,
    })
  }

  /** @param {Record<string, any>} execution @param {Record<string, any> | null} request */
  const validateRecoveredExecution = async (execution, request) => {
    if (typeof execution.resultFingerprint !== 'string') return
    if (request === null && execution.resumeStateValidated) return
    if (request !== null && execution.resumeRequestValidated) return
    if (typeof options.validateResumeExecution !== 'function') {
      fail('EDITOR_TOOL_RESUME_VALIDATOR_MISSING', 500)
    }
    let verifiedResult
    try {
      verifiedResult = await options.validateResumeExecution({
        tool: execution.tool,
        idempotencyKey: execution.idempotencyKey,
        requestHash: execution.requestHash,
        resultFingerprint: execution.resultFingerprint,
        result: structuredClone(execution.result),
        request: request === null ? null : structuredClone(request),
      })
    } catch (error) {
      if (
        error instanceof EditorAgentContractError ||
        error instanceof EditorToolRegistryError
      ) {
        fail('EDITOR_TOOL_RESUME_STATE_INVALID', 409)
      }
      throw error
    }
    if (
      !validEditorCommittedExecutionResult(execution.tool, verifiedResult) ||
      fingerprintCanonical(verifiedResult) !== execution.resultFingerprint
    ) {
      fail('EDITOR_TOOL_RESUME_RESULT_MISMATCH', 409)
    }
    execution.result = structuredClone(verifiedResult)
    if (request === null) execution.resumeStateValidated = true
    else execution.resumeRequestValidated = true
  }

  const validateResumeExecutions = async () => {
    for (const execution of idempotentResults.values()) {
      await validateRecoveredExecution(execution, null)
    }
    return true
  }

  /**
   * Register a candidate that the coordinator has just re-verified through the
   * project-scoped inspection boundary. This is intentionally not an Agent tool:
   * callers still need an independent search or inspection result before a
   * replacement can refer to the candidate.
   * @param {unknown} candidate
   */
  const registerVerifiedCandidate = (candidate) => {
    if (
      !isRecord(candidate) ||
      !opaqueId(candidate.candidateId) ||
      !opaqueId(candidate.assetId) ||
      !opaqueId(candidate.sceneId) ||
      !isRecord(candidate.availableSourceRange) ||
      !nonNegativeUs(candidate.availableSourceRange.startUs) ||
      !nonNegativeUs(candidate.availableSourceRange.durationUs) ||
      candidate.availableSourceRange.durationUs < 1 ||
      (candidate.authorizationId != null && !opaqueId(candidate.authorizationId))
    ) {
      fail('EDITOR_TOOL_VERIFIED_CANDIDATE_INVALID', 500)
    }
    authorizedCandidates.set(candidate.candidateId, structuredClone(candidate))
  }

  /** @param {Record<string, any>} input */
  const assertProjectScoped = (input) => {
    if (!isRecord(input) || input.projectId !== options.projectId) {
      fail('EDITOR_TOOL_PROJECT_SCOPE_INVALID', 403)
    }
  }

  /**
   * @param {string} tool
   * @param {Record<string, any>} args
   * @param {{signal?: AbortSignal}} [context]
   */
  const invoke = async (tool, args, context = {}) => {
    if (typeof tool !== 'string' || !EDITOR_TOOL_NAMES.includes(tool)) {
      fail('EDITOR_TOOL_UNKNOWN', 400)
    }
    if (toolCalls >= EDITOR_BUDGETS.maxToolCallsPerTurn) {
      fail('EDITOR_TOOL_TURN_BUDGET', 409)
    }
    toolCalls += 1
    assertProjectScoped(args)
    assertToolArguments(tool, args)

    if (tool === 'search_materials') {
      if (searchCalls >= EDITOR_BUDGETS.maxSearchMaterials) {
        fail('EDITOR_TOOL_SEARCH_BUDGET', 409)
      }
      searchCalls += 1
    }
    if (tool === 'inspect_candidate') {
      if (!opaqueId(args.candidateId)) fail('EDITOR_TOOL_CANDIDATE_INVALID', 400)
      const next = new Set(inspectedCandidates)
      next.add(args.candidateId)
      if (next.size > EDITOR_BUDGETS.maxDistinctInspectCandidates) {
        fail('EDITOR_TOOL_INSPECT_BUDGET', 409)
      }
      inspectedCandidates.add(args.candidateId)
    }

    let normalizedArgs = args
    /** @type {string[]} */
    let semanticSegmentsInRequest = []
    if (tool === 'propose_timeline_patch') {
      const operations = assertTimelinePatchOperations(args.operations, { jobOperationsUsed })
      /** @type {Record<string, any>} */
      const candidateReferences = {}
      for (const operation of operations) {
        if (
          protectedSegmentIds.has(operation.segmentId) &&
          (
            operation.op === 'remove_segment' ||
            (operation.op === 'set_effect' && operation.binding === null)
          )
        ) {
          fail('EDITOR_PROTECTED_SEGMENT_MUTATION_DENIED', 409)
        }
        if (operation.op === 'set_audio') {
          if (typeof options.authorizeAudioToken !== 'function') {
            fail('EDITOR_AUDIO_ASSET_NOT_AUTHORIZED', 403)
          }
          let authorized = false
          try {
            authorized = await options.authorizeAudioToken({
              projectId: options.projectId,
              segmentId: operation.segmentId,
              audioToken: operation.audioToken,
              volume: Number(operation.volume),
            }) === true
          } catch {
            authorized = false
          }
          if (!authorized) fail('EDITOR_AUDIO_ASSET_NOT_AUTHORIZED', 403)
        }
        if (operation.op === 'insert_segment') {
          const segment = /** @type {Record<string, any>} */ (operation.segment)
          if (
            ['voiceover', 'bgm', 'sfx'].includes(segment.kind)
          ) {
            fail('EDITOR_AUDIO_ASSET_NOT_AUTHORIZED', 403)
          }
          if (
            segment.kind === 'video' ||
            (
              ['caption', 'title', 'rich_text'].includes(segment.kind) &&
              (
                segment.animationIn !== null ||
                segment.animationOut !== null ||
                segment.templateToken !== null
              )
            )
          ) {
            fail('EDITOR_PATCH_INSERT_RESOURCE_UNRESOLVED', 409)
          }
        }
        if (operation.op !== 'replace_candidate') continue
        const candidate = authorizedCandidates.get(operation.candidateId)
        if (!candidate) fail('EDITOR_TOOL_CANDIDATE_NOT_AUTHORIZED', 403)
        const sourceRange =
          /** @type {{startUs: number, durationUs: number}} */ (operation.sourceRange)
        const requestedEnd = sourceRange.startUs + sourceRange.durationUs
        const availableEnd =
          candidate.availableSourceRange.startUs +
          candidate.availableSourceRange.durationUs
        if (
          sourceRange.startUs < candidate.availableSourceRange.startUs ||
          requestedEnd > availableEnd
        ) {
          fail('EDITOR_TOOL_CANDIDATE_RANGE_INVALID', 400)
        }
        candidateReferences[operation.candidateId] = {
          assetId: candidate.assetId,
          sceneId: candidate.sceneId,
          ...(opaqueId(candidate.authorizationId)
            ? { authorizationId: candidate.authorizationId }
            : {}),
        }
        if (requiredSemanticSegmentIds.has(operation.segmentId)) {
          semanticSegmentsInRequest.push(operation.segmentId)
        }
      }
      normalizedArgs = {
        ...args,
        operations,
        jobOperationsUsed,
        candidateReferences,
      }
    }

    if (
      tool === 'finalize_timeline' &&
      requiredSemanticSegmentIds.size > 0 &&
      (
        !semanticTimelineSummaryRead ||
        [...requiredSemanticSegmentIds].some((segmentId) =>
          !semanticReplacedSegmentIds.has(segmentId))
      )
    ) {
      fail('EDITOR_SEMANTIC_MATCHING_REQUIRED', 409)
    }

    let storeKey = null
    let requestHash = null
    let idempotencyKey = null
    if (sideEffectTools.has(tool)) {
      idempotencyKey = normalizedArgs.idempotencyKey
      if (!opaqueId(idempotencyKey)) fail('EDITOR_TOOL_IDEMPOTENCY_INVALID', 400)
      requestHash = fingerprintCanonical(tool === 'propose_timeline_patch'
        ? {
            projectId: normalizedArgs.projectId,
            baseRevision: normalizedArgs.baseRevision ?? null,
            baseRevisionFingerprint: normalizedArgs.baseRevisionFingerprint ?? null,
            operations: normalizedArgs.operations,
          }
        : normalizedArgs)
      storeKey = `${options.projectId}\u0000${tool}\u0000${idempotencyKey}`
      const existing = idempotentResults.get(storeKey)
      if (existing) {
        if (existing.requestHash !== requestHash) fail('EDITOR_IDEMPOTENCY_CONFLICT', 409)
        await validateRecoveredExecution(existing, normalizedArgs)
        return structuredClone(existing.result)
      }
    }

    try {
      const result = await options.handlers[tool]({
        ...normalizedArgs,
        signal: context.signal,
      })
      if (tool === 'propose_timeline_patch') {
        jobOperationsUsed += normalizedArgs.operations.length
        if (result.validation === 'accepted' && result.errorCode === null) {
          for (const segmentId of semanticSegmentsInRequest) {
            semanticReplacedSegmentIds.add(segmentId)
          }
        }
      }
      if (tool === 'get_timeline_summary') {
        semanticTimelineSummaryRead = true
      }
      if (tool === 'search_materials' && Array.isArray(result?.candidates)) {
        for (const candidate of result.candidates) {
          if (
            isRecord(candidate) &&
            opaqueId(candidate.candidateId) &&
            opaqueId(candidate.assetId) &&
            opaqueId(candidate.sceneId) &&
            isRecord(candidate.availableSourceRange)
          ) {
            authorizedCandidates.set(candidate.candidateId, structuredClone(candidate))
          }
        }
      }
      if (sideEffectTools.has(tool) && !validEditorCommittedExecutionResult(tool, result)) {
        fail('EDITOR_TOOL_RESULT_INVALID', 502)
      }
      if (storeKey && requestHash && idempotencyKey) {
        idempotentResults.set(storeKey, {
          tool,
          idempotencyKey,
          requestHash,
          result: structuredClone(result),
        })
      }
      return result
    } catch (error) {
      if (error instanceof EditorToolRegistryError || error instanceof EditorAgentContractError) {
        throw error
      }
      const code = isRecord(error) && typeof error.code === 'string'
        ? error.code
        : 'EDITOR_TOOL_EXECUTION_FAILED'
      fail(
        code.startsWith('EDITOR_') || code.startsWith('PACKAGING_')
          ? code
          : 'EDITOR_TOOL_EXECUTION_FAILED',
        502,
      )
    }
  }

  return {
    projectId: options.projectId,
    toolRegistryFingerprint,
    capabilityRegistryFingerprint,
    listTools: () => [...EDITOR_TOOL_NAMES],
    committedExecutions: () => [...idempotentResults.values()].map((entry) => ({
      tool: entry.tool,
      idempotencyKey: entry.idempotencyKey,
      requestHash: entry.requestHash,
      result: structuredClone(entry.result),
    })),
    budgets: () => ({
      toolCalls,
      searchCalls,
      distinctInspectCandidates: inspectedCandidates.size,
      jobOperationsUsed,
      limits: { ...EDITOR_BUDGETS },
    }),
    registerVerifiedCandidate,
    validateResumeExecutions,
    invoke,
  }
}

/**
 * Build default handlers that wrap EM-006 tools and timeline helpers.
 * @param {{
 *   projectId: string,
 *   projectRepository: {get: Function},
 *   materialTools: {searchMaterials: Function, inspectCandidate: Function},
 *   richTimelineRepository: {
 *     getCurrent: Function,
 *     getRevision: Function,
 *     saveDraftAndSetCurrent: Function,
 *     finalize: Function,
 *   },
 *   capabilityRegistry: {
 *     registryFingerprint: string,
 *     list: Function,
 *     requireAllowed: Function,
 *     assertAllowedParameters: Function,
 *     assertTimelineCapabilities: Function,
 *   },
 *   getTemplateConstraints?: Function,
 *   getCapabilityMatrix?: Function,
 *   instructionFingerprint?: string,
 *   now?: () => number,
 *   assertExecutionFence?: Function,
 *   withExecutionFence?: Function,
 *   enqueuePreview?: Function,
 *   enqueueJianyingExport?: Function,
 *   authorizeAudioToken?: Function,
 *   recommendPackaging?: Function,
 *   batchTextCatalog?: {entries: readonly any[], profile_id: string, evidence_profile: Record<string, unknown>} | null,
 *   packagingResourceIndex?: Record<string, any> | null,
 * }} deps
 */
export const createDefaultEditorToolHandlers = (deps) => {
  /** @type {Map<string, IssuedPackagingRecommendation>} */
  const issuedPackagingRecommendations = new Map()
  const now = typeof deps.now === 'function' ? deps.now : Date.now
  const requireProject = async () => {
    const project = await deps.projectRepository.get(deps.projectId)
    if (!isRecord(project) || project.id !== deps.projectId) {
      fail('EDITOR_TOOL_PROJECT_SCOPE_INVALID', 403)
    }
    return project
  }
  /** @param {() => Promise<unknown>} operation */
  const fenced = async (operation) => {
    if (typeof deps.withExecutionFence === 'function') {
      return deps.withExecutionFence(operation)
    }
    await deps.assertExecutionFence?.()
    return operation()
  }

  /** @param {Record<string, any>} timeline @param {Record<string, any>} requirement */
  const isTrustedTemplatePackagingRequirement = (timeline, requirement) =>
    (isRecord(timeline.source?.templateIdentity) || timeline.source?.automaticPackaging === true) &&
    (timeline.source?.automaticPackaging === true
      ? ['implemented', 'degraded'].includes(requirement.acceptance)
      : ['implemented', 'degraded'].includes(requirement.acceptance)) &&
    [
      'effect.video.named',
      'sticker.named',
      'audio.sfx.local',
      'text.rich',
      'text.flower.private',
      'text.bubble.private',
    ].includes(requirement.capabilityId)

  /** @param {Record<string, any>} requirement */
  const isWriterStructuralRequirement = (requirement) =>
    requirement.capabilityId === 'track.insert' || requirement.capabilityId === 'track.insert_many'

  /**
   * Template-bound packaging tokens are immutable Agent inputs. They may be unavailable in the
   * OpenVideo preview while remaining executable by the Jianying writer. Agent-authored packaging
   * stays denied and every non-template requirement still uses the canonical capability registry.
   * @param {Record<string, any>} timeline
   */
  const assertDeliveryTimelineCapabilities = (timeline) => {
    if (!Array.isArray(timeline.capabilityRequirements)) {
      return deps.capabilityRegistry.assertTimelineCapabilities(timeline)
    }
    const requirements = timeline.capabilityRequirements
    const capabilities = deps.capabilityRegistry.list().capabilities
    for (const requirement of requirements) {
      if (!isTrustedTemplatePackagingRequirement(timeline, requirement)) continue
      const capability = capabilities.find(
        (/** @type {Record<string, any>} */ entry) =>
          entry.capabilityId === requirement.capabilityId,
      )
      if (capability?.targets?.jianying?.status !== 'implemented') {
        fail('EDITOR_CAPABILITY_UNAUTHORIZED', 409)
      }
    }
    return deps.capabilityRegistry.assertTimelineCapabilities({
      ...timeline,
      capabilityRequirements: requirements.filter(
        (/** @type {Record<string, any>} */ requirement) =>
          !isTrustedTemplatePackagingRequirement(timeline, requirement) &&
          !isWriterStructuralRequirement(requirement),
      ),
    })
  }

  /** @param {Record<string, any>} input */
  const runPreflight = async (input) => {
    const revision = await deps.richTimelineRepository.getRevision({
      projectId: input.projectId,
      timelineId: input.timelineId,
      revision: input.revision,
    })
    if (!revision || revision.revisionFingerprint !== input.revisionFingerprint) {
      fail('EDITOR_TOOL_TIMELINE_NOT_FOUND', 404)
    }
    const errors = []
    const degradations = []
    if (!Array.isArray(revision.tracks) || revision.tracks.length === 0) {
      errors.push({ code: 'EDITOR_PREFLIGHT_EMPTY_TRACKS', segmentId: null })
    }
    const primaryTrack = revision.tracks?.find(
      (/** @type {Record<string, any>} */ track) =>
        track?.enabled !== false && track?.kind === 'video' && track?.role === 'primary',
    )
    const primarySegments = Array.isArray(primaryTrack?.segments) ? primaryTrack.segments : []
    const captions = revision.tracks
      ?.filter((/** @type {Record<string, any>} */ track) =>
        track?.enabled !== false && track?.kind === 'caption')
      .flatMap((/** @type {Record<string, any>} */ track) =>
        Array.isArray(track.segments) ? track.segments : []) ?? []
    const voiceovers = revision.tracks
      ?.filter((/** @type {Record<string, any>} */ track) =>
        track?.enabled !== false && track?.kind === 'audio' && track?.role === 'voiceover')
      .flatMap((/** @type {Record<string, any>} */ track) =>
        Array.isArray(track.segments) ? track.segments : []) ?? []
    /** @param {{startUs?: number, durationUs?: number}|null|undefined} range */
    const rangeEndUs = (range) =>
      Number.isSafeInteger(range?.startUs) && Number.isSafeInteger(range?.durationUs)
        ? range.startUs + range.durationUs
        : null
    /** @param {{startUs: number, durationUs: number}} range */
    const containingShot = (range) => primarySegments.find((/** @type {Record<string, any>} */ shot) =>
      range.startUs >= shot.targetRange.startUs &&
      range.startUs + range.durationUs <= shot.targetRange.startUs + shot.targetRange.durationUs)
    /** @param {{startUs?: number, durationUs?: number}|null|undefined} left @param {{startUs?: number, durationUs?: number}|null|undefined} right */
    const sameRange = (left, right) =>
      left?.startUs === right?.startUs && left?.durationUs === right?.durationUs
    /**
     * Template karaoke captions may tile a shot instead of matching it 1:1.
     * They still fail closed when their union leaves a gap in the required range.
     * @param {Array<{startUs?: number, durationUs?: number}|null|undefined>} ranges
     * @param {{startUs: number, durationUs: number}} target
     */
    const unionCoversRange = (ranges, target) => {
      const targetEnd = rangeEndUs(target)
      if (targetEnd === null) return false
      const intervals = ranges
        .map((range) => {
          const end = rangeEndUs(range)
          if (end === null) return null
          const start = Math.max(range.startUs, target.startUs)
          const clippedEnd = Math.min(end, targetEnd)
          return clippedEnd > start ? { start, end: clippedEnd } : null
        })
        .filter(Boolean)
        .sort((left, right) => left.start - right.start || left.end - right.end)
      let cursor = target.startUs
      for (const interval of intervals) {
        if (interval.start > cursor) return false
        cursor = Math.max(cursor, interval.end)
      }
      return cursor >= targetEnd
    }
    const duplicateCaptionKeys = new Set()
    for (const caption of /** @type {Array<Record<string, any>>} */ (captions)) {
      const durationUs = caption.targetRange?.durationUs
      if (!Number.isSafeInteger(durationUs) || durationUs < 100_000) {
        errors.push({
          code: 'EDITOR_PREFLIGHT_CAPTION_TOO_SHORT',
          segmentId: caption.segmentId ?? null,
          durationUs,
        })
      }
      const shot = containingShot(caption.targetRange)
      if (!shot) {
        errors.push({
          code: 'EDITOR_PREFLIGHT_CAPTION_RANGE_NOT_ALIGNED',
          segmentId: caption.segmentId ?? null,
        })
        continue
      }
      const key = `${shot.segmentId}\u0000${caption.text.trim()}`
      if (duplicateCaptionKeys.has(key)) {
        errors.push({
          code: 'EDITOR_PREFLIGHT_DUPLICATE_CAPTION',
          segmentId: caption.segmentId ?? null,
        })
      }
      duplicateCaptionKeys.add(key)
    }
    for (const shot of primarySegments) {
      const contained = /** @type {Array<Record<string, any>>} */ (captions).filter((caption) =>
        containingShot(caption.targetRange) === shot)
      if (contained.length === 0) continue
      if (unionCoversRange(contained.map((caption) => caption.targetRange), shot.targetRange)) continue
      for (const caption of contained) {
        if (sameRange(caption.targetRange, shot.targetRange)) continue
        errors.push({
          code: 'EDITOR_PREFLIGHT_CAPTION_RANGE_NOT_ALIGNED',
          segmentId: caption.segmentId ?? null,
        })
      }
    }
    if (captions.length > 0 && voiceovers.length > 0) {
      for (const voiceover of voiceovers) {
        const overlapping = /** @type {Array<Record<string, any>>} */ (captions).filter((caption) => {
          const captionEnd = rangeEndUs(caption.targetRange)
          const voiceoverEnd = rangeEndUs(voiceover.targetRange)
          return captionEnd !== null &&
            voiceoverEnd !== null &&
            caption.targetRange.startUs < voiceoverEnd &&
            voiceover.targetRange.startUs < captionEnd
        })
        if (
          unionCoversRange(overlapping.map((caption) => caption.targetRange), voiceover.targetRange) ||
          captions.some((/** @type {Record<string, any>} */ caption) =>
            sameRange(caption.targetRange, voiceover.targetRange))
        ) continue
        errors.push({
          code: 'EDITOR_PREFLIGHT_CAPTION_MISSING',
          segmentId: voiceover.segmentId ?? null,
        })
      }
    }
    // Automatic packaging must not report success after collapsing an
    // authored template decoration set. The expected count is persisted on
    // the canonical timeline; compare it with executable private title
    // segments before any writer/export mutation is allowed.
    const expectedCoverage = revision.source?.templatePackagingCoverage
    if (revision.source?.automaticPackaging === true && isRecord(expectedCoverage)) {
      const titleSegments = revision.tracks
        .filter((/** @type {Record<string, any>} */ track) => track?.kind === 'title')
        .flatMap((/** @type {Record<string, any>} */ track) => Array.isArray(track.segments) ? track.segments : [])
      for (const [family, capabilityId] of [
        ['flower', 'text.flower.private'],
        ['bubble', 'text.bubble.private'],
      ]) {
        const expected = expectedCoverage[family]
        if (!Number.isSafeInteger(expected) || expected < 0) continue
        const actual = titleSegments.filter((/** @type {Record<string, any>} */ segment) =>
          segment?.capabilityId === capabilityId ||
          (family === 'flower' &&
            expectedCoverage.bubble === 0 &&
            segment?.capabilityId === 'text.rich')).length
        if (actual < expected) {
          errors.push({
            code: 'EDITOR_TEMPLATE_PACKAGING_COVERAGE_INCOMPLETE',
            segmentId: null,
            family,
            expected,
            actual,
          })
        }
      }
    }
    for (const requirement of revision.capabilityRequirements ?? []) {
      if (isWriterStructuralRequirement(requirement)) continue
      try {
        const trustedTemplatePackaging = isTrustedTemplatePackagingRequirement(
          revision,
          requirement,
        )
        if (trustedTemplatePackaging) {
          const capability = deps.capabilityRegistry.list().capabilities.find(
            (/** @type {Record<string, any>} */ entry) =>
              entry.capabilityId === requirement.capabilityId,
          )
          if (capability?.targets?.jianying?.status !== 'implemented') {
            throw new Error('template_packaging_writer_unavailable')
          }
          if (
            requirement.acceptance === 'degraded' ||
            capability?.targets?.preview?.status !== 'implemented'
          ) {
            degradations.push({
              code: requirement.degradationCode ??
                capability?.targets?.preview?.degradationCode ??
                'EDITOR_CAPABILITY_DEGRADED',
              segmentId: null,
            })
          }
          continue
        }
        const capability = deps.capabilityRegistry.requireAllowed(requirement.capabilityId)
        if (capability.effectiveStatus === 'degraded') {
          degradations.push({
            code:
              capability.targets.preview.degradationCode ??
              capability.targets.jianying.degradationCode ??
              'EDITOR_CAPABILITY_DEGRADED',
            segmentId: null,
          })
        }
      } catch {
        errors.push({
          code: 'EDITOR_CAPABILITY_UNAUTHORIZED',
          segmentId: null,
        })
      }
    }
    return {
      ready: errors.length === 0,
      errors,
      degradations,
    }
  }

  /** @param {unknown} raw */
  const toPublicPackagingRecommendation = (raw) => {
    if (raw == null) {
      return {
        recommendation: null,
        projectedPatches: [],
      }
    }
    if (!isRecord(raw) || !isRecord(raw.recommendation) || !isRecord(raw.catalog)) {
      fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
    }
    const recommendation = raw.recommendation
    const allowedTargetSegmentIds = raw.allowedTargetSegmentIds
    if (
      !exactKeys(recommendation, ['recommendationId', 'catalogRevisionToken', 'source', 'selected']) ||
      !/^ovjrec_v1_[a-f0-9]{24}$/u.test(recommendation.recommendationId) ||
      !/^ovjcatalog_v1_[a-f0-9]{24}$/u.test(recommendation.catalogRevisionToken) ||
      !['deterministic', 'llm_gateway_ranked'].includes(recommendation.source) ||
      !Array.isArray(recommendation.selected) ||
      recommendation.selected.length < 1 ||
      recommendation.selected.length > 24 ||
      !Array.isArray(allowedTargetSegmentIds) ||
      allowedTargetSegmentIds.length === 0 ||
      new Set(allowedTargetSegmentIds).size !== allowedTargetSegmentIds.length ||
      allowedTargetSegmentIds.some((segmentId) => !opaqueId(segmentId))
    ) {
      fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
    }
    /** @type {Record<string, any>[]} */
    let projectedPatches
    try {
      projectedPatches = projectRecommendationToRichTimeline(recommendation, {
        index: raw.catalog,
        allowedTargetSegmentIds: new Set(allowedTargetSegmentIds),
      })
    } catch {
      fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
    }
    const seenTokens = new Set()
    const selected = recommendation.selected.map((item, index) => {
      if (
        !isRecord(item) ||
        !exactKeys(item, packagingRecommendationItemKeys) ||
        !isOpaquePackagingToken(item.packagingToken) ||
        !packagingRecommendationFamilies.has(item.family) ||
        !safeRecommendationText(item.label, 160) ||
        !Array.isArray(item.tags) ||
        item.tags.length > 16 ||
        item.tags.some((tag) => !safeRecommendationText(tag, 80)) ||
        !opaqueId(item.targetSegmentId) ||
        !safeRecommendationRange(item.targetRange) ||
        !isRecord(item.parameters) ||
        !safeRecommendationText(item.reason, 240) ||
        seenTokens.has(item.packagingToken)
      ) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
      }
      seenTokens.add(item.packagingToken)
      const patch = projectedPatches[index]
      const tokenField = recommendationTokenField(item.family)
      const parameters = Object.fromEntries(
        Object.entries(patch.parameters).filter(([key]) => key !== tokenField),
      )
      if (containsPrivateReference(parameters)) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
      }
      return /** @type {IssuedPackagingSelection} */ ({
        packagingToken: item.packagingToken,
        family: item.family,
        label: item.label,
        tags: [...item.tags],
        targetSegmentId: item.targetSegmentId,
        targetRange: { ...item.targetRange },
        parameters,
        reason: item.reason,
      })
    })
    const result = {
      recommendation: {
        recommendationId: recommendation.recommendationId,
        catalogRevisionToken: recommendation.catalogRevisionToken,
        source: recommendation.source,
        selected,
      },
      projectedPatches: structuredClone(projectedPatches),
    }
    if (!safePackagingRecommendationResult(result)) {
      fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
    }
    issuedPackagingRecommendations.set(result.recommendation.recommendationId, {
      catalogRevisionToken: result.recommendation.catalogRevisionToken,
      catalogFingerprint: fingerprint(raw.catalog.catalogFingerprint) ? raw.catalog.catalogFingerprint : null,
      issuedAt: now(),
      projectedPatches: structuredClone(result.projectedPatches),
      selections: structuredClone(result.recommendation.selected),
    })
    return result
  }

  /** @param {Record<string, any>} timeline @param {Record<string, any>[]} patches @param {IssuedPackagingSelection[]} selections */
  const applyIssuedPackagingRecommendation = (timeline, patches, selections) => {
    const next = structuredClone(timeline)
    /** @type {Record<string, any>[]} */
    const effectSegments = []
    /** @type {Record<string, any>[]} */
    const titleSegments = []
    const selectionByToken = new Map(selections.map((/** @type {IssuedPackagingSelection} */ selection) => [selection.packagingToken, selection]))
    const declaredPriorTokens = new Set(
      (Array.isArray(next.source?.packagingSelections) ? next.source.packagingSelections : [])
        .map((/** @type {Record<string, any>} */ selection) => selection?.packagingToken)
        .filter((/** @type {unknown} */ token) => typeof token === 'string'),
    )
    // Segment-level token discovery also sees template-authored resources.
    // Only declarations in source.packagingSelections are owned by a prior
    // automatic recommendation and may be replaced here. A legacy automatic
    // revision without declarations keeps the old fallback behavior only
    // when it is not bound to an authored template.
    const legacyUndeclaredAutomaticPackaging =
      next.source?.automaticPackaging === true &&
      declaredPriorTokens.size === 0 &&
      !isRecord(next.source?.templateIdentity)
    const priorSelections = readTimelinePackagingSelections(next).filter((selection) =>
      declaredPriorTokens.has(selection.packagingToken) ||
      legacyUndeclaredAutomaticPackaging,
    )
    const priorTokens = new Set(priorSelections.map((selection) => selection.packagingToken))
    const templateFamilies = new Set()
    if (isRecord(next.source?.templateIdentity)) {
      for (const track of /** @type {Record<string, any>[]} */ (next.tracks)) {
        for (const segment of Array.isArray(track.segments) ? track.segments : []) {
          const family = segment.capabilityId === 'text.flower.private'
            ? 'flower'
            : segment.capabilityId === 'text.bubble.private'
              ? 'bubble'
              : segment.capabilityId === 'sticker.named'
                ? 'sticker'
                : segment.capabilityId === 'effect.video.named'
                  ? 'video_effect'
                  : null
          const token = family === 'flower' || family === 'bubble'
            ? segment.templateToken
            : segment.parameters?.packagingToken
          if (family && typeof token === 'string' && !priorTokens.has(token)) {
            templateFamilies.add(family)
          }
        }
      }
    }
    for (const track of /** @type {Record<string, any>[]} */ (next.tracks)) {
      if (track.kind === 'effect') {
        track.segments = track.segments.filter((/** @type {Record<string, any>} */ segment) => {
          const token = segment.parameters?.packagingToken ?? segment.parameters?.templateToken ??
            segment.parameters?.animationToken ?? segment.parameters?.maskToken ?? segment.parameters?.blendToken ??
            segment.parameters?.effectToken
          return !priorTokens.has(token)
        })
      } else if (track.kind === 'title') {
        track.segments = track.segments.filter((/** @type {Record<string, any>} */ segment) => !priorTokens.has(segment.templateToken))
      }
    }
    const appliedSelectionByToken = new Map()
    for (const patch of patches) {
      if (
        !isRecord(patch) ||
        !opaqueId(patch.targetSegmentId) ||
        typeof patch.capabilityId !== 'string' ||
        !isRecord(patch.targetRange) ||
        !nonNegativeUs(patch.targetRange.startUs) ||
        !nonNegativeUs(patch.targetRange.durationUs) ||
        patch.targetRange.durationUs < 1 ||
        !isRecord(patch.parameters) ||
        containsPrivateReference(patch.parameters)
      ) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
      }
      if (!EFFECT_TRACK_PACKAGING_FAMILIES.has(patch.family)) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_FAMILY_UNSUPPORTED', 409)
      }
      // A selected template owns its authored family and cadence. Automatic
      // recommendations fill only absent families; they never replace or
      // duplicate a template flower, bubble, sticker, or video effect.
      if (templateFamilies.has(patch.family)) continue
      const primaryCandidates = timeline.tracks?.flatMap((/** @type {Record<string, any>} */ track) =>
        Array.isArray(track.segments)
          ? track.segments.map((/** @type {Record<string, any>} */ segment) => ({ track, segment }))
        : [],
      ).filter((/** @type {{track: Record<string, any>, segment: Record<string, any>}} */ entry) =>
        entry.track?.kind === 'video' && entry.track?.role === 'primary' &&
        isRecord(entry.segment?.targetRange)) ?? []
      /** @param {{track: Record<string, any>, segment: Record<string, any>}} entry */
      const matchesSegmentId = (entry) => entry.segment?.segmentId === patch.targetSegmentId
      /** @param {{track: Record<string, any>, segment: Record<string, any>}} entry */
      const matchesTargetRange = (entry) =>
        entry.segment?.targetRange?.startUs === patch.targetRange.startUs &&
        entry.segment?.targetRange?.durationUs === patch.targetRange.durationUs
      const directMatches = primaryCandidates.filter(matchesSegmentId)
      const rangeMatches = primaryCandidates.filter(matchesTargetRange)
      const located = directMatches.length === 1
        ? directMatches[0]
        : directMatches.length === 0 && rangeMatches.length === 1
          ? rangeMatches[0]
          : null
      if (
        !located ||
        !isRecord(located.segment?.targetRange) ||
        !nonNegativeUs(located.segment.targetRange.startUs) ||
        !nonNegativeUs(located.segment.targetRange.durationUs)
      ) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_TARGET_INVALID', 409)
      }
      if (
        patch.targetRange.startUs < located.segment.targetRange.startUs ||
        patch.targetRange.startUs + patch.targetRange.durationUs >
          located.segment.targetRange.startUs + located.segment.targetRange.durationUs
      ) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_RANGE_INVALID', 409)
      }
      try {
        deps.capabilityRegistry.assertAllowedParameters(patch.capabilityId, patch.parameters, {
          writerTarget: 'jianying',
        })
      } catch {
        fail('EDITOR_CAPABILITY_UNAUTHORIZED', 409)
      }
      const intensity = typeof patch.parameters.intensity === 'number'
        ? patch.parameters.intensity
        : 1
      if (!Number.isFinite(intensity) || intensity < 0 || intensity > 1) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
      }
      const packagingToken = patch.parameters.packagingToken ??
        patch.parameters.templateToken ??
        patch.parameters.animationToken ??
        patch.parameters.maskToken ??
        patch.parameters.blendToken ??
        patch.parameters.effectToken
      if (!opaqueId(packagingToken)) fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
      const appliedSelection = selectionByToken.get(packagingToken)
      if (!appliedSelection) fail('EDITOR_PACKAGING_RECOMMENDATION_INVALID', 409)
      appliedSelectionByToken.set(packagingToken, appliedSelection)
      if (patch.family === 'flower' || patch.family === 'bubble') {
        const caption = next.tracks
          .filter((/** @type {Record<string, any>} */ track) => track.kind === 'caption')
          .flatMap((/** @type {Record<string, any>} */ track) => track.segments)
          .find((/** @type {Record<string, any>} */ segment) => segment.targetRange?.startUs < patch.targetRange.startUs + patch.targetRange.durationUs &&
            patch.targetRange.startUs < segment.targetRange?.startUs + segment.targetRange?.durationUs)
        const material = {
          kind: 'rich_text',
          capabilityId: patch.capabilityId,
          targetRange: structuredClone(patch.targetRange),
          text: derivePackagingEmphasisText(caption?.text, patch.family === 'flower' ? '重点' : '提示'),
          styleToken: 'rich_emphasis',
          templateToken: packagingToken,
        }
        titleSegments.push({
          segmentId: `pkg-${fingerprintCanonical(material).slice(0, 24)}`,
          ...material,
          animationIn: null,
          animationOut: null,
          keyframes: [],
        })
        continue
      }
      effectSegments.push({
        segmentId: `pkg-${fingerprintCanonical({
          capabilityId: patch.capabilityId,
          targetSegmentId: patch.targetSegmentId,
          targetRange: patch.targetRange,
          parameters: patch.parameters,
        }).slice(0, 24)}`,
        kind: 'effect',
        targetRange: structuredClone(patch.targetRange),
        capabilityId: patch.capabilityId,
        intensity,
        parameters: {
          ...structuredClone(patch.parameters),
          packagingToken,
        },
      })
    }
    if (
      effectSegments.length === 0 &&
      titleSegments.length === 0 &&
      templateFamilies.size === 0
    ) fail('EDITOR_PACKAGING_RECOMMENDATION_NOT_ISSUED', 409)
    if (effectSegments.length > 0) {
      let effectTrack = next.tracks.find((/** @type {Record<string, any>} */ track) => track.kind === 'effect')
      if (!effectTrack) {
        effectTrack = {
          trackId: `pkgtrack-${next.timelineId}`,
          order: next.tracks.length,
          enabled: true,
          locked: false,
          kind: 'effect',
          segments: [],
        }
        next.tracks.push(effectTrack)
      }
      const occupied = new Set(effectTrack.segments.map((/** @type {Record<string, any>} */ segment) => segment.segmentId))
      if (effectSegments.some((segment) => occupied.has(segment.segmentId))) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_ALREADY_APPLIED', 409)
      }
      effectTrack.segments.push(...effectSegments)
    }
    if (titleSegments.length > 0) {
      let titleTrack = next.tracks.find((/** @type {Record<string, any>} */ track) => track.kind === 'title')
      if (!titleTrack) {
        titleTrack = {
          trackId: `pkgtitle-${next.timelineId}`,
          order: next.tracks.length,
          enabled: true,
          locked: false,
          kind: 'title',
          segments: [],
        }
        next.tracks.push(titleTrack)
      }
      const occupiedTitles = new Set(titleTrack.segments.map((/** @type {Record<string, any>} */ segment) => segment.segmentId))
      if (titleSegments.some((segment) => occupiedTitles.has(segment.segmentId))) {
        fail('EDITOR_PACKAGING_RECOMMENDATION_ALREADY_APPLIED', 409)
      }
      titleTrack.segments.push(...titleSegments)
    }
    const canonicalTitleTrack = next.tracks.find((/** @type {Record<string, any>} */ track) => track.kind === 'title')
    if (canonicalTitleTrack?.segments?.length > 0) {
      try {
        canonicalTitleTrack.segments = solvePackagingTextLayouts({
          orientation: next.orientation,
          segments: canonicalTitleTrack.segments,
        })
      } catch (error) {
        if (error instanceof PackagingTextLayoutError) fail(error.code, 409)
        throw error
      }
    }
    next.revision = timeline.revision + 1
    next.parentRevision = timeline.revision
    next.parentRevisionFingerprint = timeline.revisionFingerprint
    next.status = 'draft'
    next.createdAt = new Date().toISOString()
    const appliedSelections = [...appliedSelectionByToken.values()]
    next.source = {
      ...next.source,
      kind: 'agent',
      instructionFingerprint: deps.instructionFingerprint ?? next.source.instructionFingerprint,
    }
    // A template can already satisfy every recommended family. That is a
    // successful no-op, not an automatic packaging application with an empty
    // selection list (which the canonical source contract correctly rejects).
    // Remove any stale recommendation metadata after its prior segments were
    // replaced. An authored template coverage marker remains automatic even
    // when all recommended families were legitimate no-ops; its retained
    // opaque bindings still require catalog provenance during Writer resolution.
    const preservesTemplateCoverage = isRecord(next.source.templatePackagingCoverage)
    delete next.source.automaticPackaging
    delete next.source.packagingCatalogFingerprint
    delete next.source.packagingSelections
    if (appliedSelections.length > 0) {
      next.source.automaticPackaging = true
      next.source.packagingCatalogFingerprint = timeline.source.packagingCatalogFingerprint
      next.source.packagingSelections = appliedSelections.map((/** @type {IssuedPackagingSelection} */ selection) => ({
        packagingToken: selection.packagingToken,
        family: selection.family,
        label: selection.label,
        targetSegmentId: selection.targetSegmentId,
      }))
    } else if (preservesTemplateCoverage) {
      next.source.automaticPackaging = true
      if (fingerprint(timeline.source.packagingCatalogFingerprint)) {
        next.source.packagingCatalogFingerprint = timeline.source.packagingCatalogFingerprint
      }
    }
    next.capabilityRequirements = computeCapabilityRequirements(next.tracks)
    delete next.contentFingerprint
    delete next.revisionFingerprint
    return sealRichTimeline(next)
  }

  return {
    /** @param {Record<string, any>} input */
    async get_project_brief(input) {
      const project = await requireProject()
      if (input.projectId !== project.id) fail('EDITOR_TOOL_PROJECT_SCOPE_INVALID', 403)
      const brief = isRecord(project.brief) ? project.brief : {}
      const packaging = normalizePackaging(brief.packaging)
      return {
        theme: typeof brief.theme === 'string' ? redactBriefText(brief.theme) : '',
        title: typeof brief.title === 'string' ? redactBriefText(brief.title) : '',
        sellingPoints: Array.isArray(brief.sellingPoints)
          ? brief.sellingPoints
              .filter((item) => typeof item === 'string')
              .map(redactBriefText)
          : [],
        script: typeof brief.script === 'string' ? redactBriefText(brief.script) : '',
        style: typeof brief.style === 'string' ? redactBriefText(brief.style) : '',
        durationUs: Number.isSafeInteger(brief.durationSeconds)
          ? brief.durationSeconds * 1_000_000
          : 0,
        orientation: brief.orientation === 'landscape' || brief.orientation === 'square'
          ? brief.orientation
          : 'portrait',
        packagingPlan: buildPackagingPlan(packaging),
        packagingIntent: buildPackagingIntent(packaging),
      }
    },
    /** @param {Record<string, any>} input */
    async search_materials(input) {
      return deps.materialTools.searchMaterials(input)
    },
    /** @param {Record<string, any>} input */
    async inspect_candidate(input) {
      return deps.materialTools.inspectCandidate(input)
    },
    /** @param {Record<string, any>} input */
    async get_template_constraints(input) {
      if (typeof deps.getTemplateConstraints === 'function') {
        return deps.getTemplateConstraints(input)
      }
      const project = await requireProject()
      if (input.projectId !== project.id) fail('EDITOR_TOOL_PROJECT_SCOPE_INVALID', 403)
      const guidance = createTemplateGuidance(project.templateBinding ?? null)
      if (!guidance) {
        return { binding: null, slots: [], capabilityRequirements: [] }
      }
      const constraints = applyPackagingPlanToTimelineTemplateConstraints(
        createTimelineTemplateConstraints(guidance),
        project.brief?.packaging,
        project.brief,
        deps.batchTextCatalog ?? null,
        deps.packagingResourceIndex ?? null,
      )
      return {
        binding: {
          libraryTemplateId: constraints.identity.libraryTemplateId,
          revision: constraints.identity.revision,
          fingerprint: constraints.identity.fingerprint,
        },
        slots: constraints.slots.map((/** @type {Record<string, any>} */ slot) => ({
          order: slot.order,
          role: slot.role,
          recommendedDurationUs: slot.durationUs,
          transitionCapabilityId: slot.transitionOut.capabilityId,
        })),
        capabilityRequirements: constraints.capabilityRequirements
          .map((/** @type {Record<string, any>} */ requirement) => requirement.capabilityId),
      }
    },
    /** @param {Record<string, any>} input */
    async get_capability_matrix(input) {
      if (typeof deps.getCapabilityMatrix === 'function') {
        return deps.getCapabilityMatrix(input)
      }
      await requireProject()
      if (input.projectId !== deps.projectId) fail('EDITOR_TOOL_PROJECT_SCOPE_INVALID', 403)
      return deps.capabilityRegistry.list()
    },
    /** @param {Record<string, any>} input */
    async recommend_packaging(input) {
      await requireProject()
      if (input.projectId !== deps.projectId) fail('EDITOR_TOOL_PROJECT_SCOPE_INVALID', 403)
      if (typeof deps.recommendPackaging !== 'function') {
        fail('EDITOR_PACKAGING_RECOMMENDATION_UNAVAILABLE', 503)
      }
      const recommendation = await deps.recommendPackaging(input)
      return toPublicPackagingRecommendation(recommendation)
    },
    /** @param {Record<string, any>} input */
    async apply_packaging_recommendation(input) {
      await requireProject()
      return fenced(async () => {
        const issued = issuedPackagingRecommendations.get(input.recommendationId)
        if (
          !issued ||
          issued.catalogRevisionToken !== input.catalogRevisionToken ||
          now() - issued.issuedAt > PACKAGING_RECOMMENDATION_TTL_MS
        ) {
          issuedPackagingRecommendations.delete(input.recommendationId)
          fail('EDITOR_PACKAGING_RECOMMENDATION_NOT_ISSUED', 409)
        }
        const pointer = await deps.richTimelineRepository.getCurrent({ projectId: input.projectId })
        if (
          !pointer ||
          pointer.timelineId !== input.timelineId ||
          pointer.revision !== input.revision
        ) {
          fail('EDITOR_TOOL_TIMELINE_CAS_CONFLICT', 409)
        }
        const current = await deps.richTimelineRepository.getRevision({
          projectId: input.projectId,
          timelineId: input.timelineId,
          revision: input.revision,
        })
        if (
          !current ||
          current.status !== 'draft' ||
          current.revisionFingerprint !== input.revisionFingerprint
        ) {
          fail('EDITOR_TOOL_TIMELINE_CAS_CONFLICT', 409)
        }
        const patched = applyIssuedPackagingRecommendation({
          ...current,
          source: {
            ...current.source,
            packagingCatalogFingerprint: issued.catalogFingerprint,
          },
        }, issued.projectedPatches, issued.selections)
        assertDeliveryTimelineCapabilities(patched)
        const saved = await deps.richTimelineRepository.saveDraftAndSetCurrent({
          timeline: patched,
          expectedCurrent: {
            timelineId: current.timelineId,
            revision: current.revision,
          },
        })
        return {
          patchId: `packaging-${saved.revisionFingerprint.slice(0, 16)}`,
          validation: 'accepted',
          errorCode: null,
          timelineId: saved.timelineId,
          proposedRevision: saved.revision,
          proposedContentFingerprint: saved.contentFingerprint,
          proposedRevisionFingerprint: saved.revisionFingerprint,
        }
      })
    },
    /** @param {Record<string, any>} input */
    async get_timeline_summary(input) {
      await requireProject()
      const revision = await deps.richTimelineRepository.getRevision({
        projectId: input.projectId,
        timelineId: input.timelineId,
        revision: input.revision,
      })
      if (!revision) {
        fail('EDITOR_TOOL_TIMELINE_NOT_FOUND', 404)
      }
      const summary = toPublicTimelineSummary(revision)
      return {
        contentFingerprint: summary.contentFingerprint,
        revisionFingerprint: summary.revisionFingerprint,
        durationUs: summary.durationUs,
        tracks: revision.tracks.map((/** @type {Record<string, any>} */ track) => ({
          trackId: track.trackId,
          kind: track.kind,
          segmentCount: track.segments.length,
        })),
        segments: revision.tracks.flatMap((/** @type {Record<string, any>} */ track) =>
          track.segments.map((/** @type {Record<string, any>} */ segment) => ({
            segmentId: segment.segmentId,
            trackId: track.trackId,
            kind: segment.kind,
            sourceRange: isRecord(segment.sourceRange)
              ? {
                  startUs: segment.sourceRange.startUs,
                  durationUs: segment.sourceRange.durationUs,
                }
              : null,
            targetRange: {
              startUs: segment.targetRange.startUs,
              durationUs: segment.targetRange.durationUs,
            },
            candidateId: segment.audit?.candidateId ?? null,
            capabilityIds: [...new Set([
              typeof segment.capabilityId === 'string' ? segment.capabilityId : null,
              ...(Array.isArray(segment.effects)
                ? segment.effects.map((/** @type {Record<string, any>} */ effect) => effect.capabilityId)
                : []),
            ].filter(Boolean))],
          }))),
      }
    },
    /** @param {Record<string, any>} input */
    async propose_timeline_patch(input) {
      await requireProject()
      return fenced(async () => {
      const pointer = await deps.richTimelineRepository.getCurrent({
        projectId: input.projectId,
      })
      if (!pointer) fail('EDITOR_TOOL_TIMELINE_NOT_FOUND', 404)
      const current = await deps.richTimelineRepository.getRevision({
        projectId: input.projectId,
        timelineId: pointer.timelineId,
        revision: pointer.revision,
      })
      if (!current) fail('EDITOR_TOOL_TIMELINE_NOT_FOUND', 404)
      if (
        input.baseRevision !== null &&
        current.parentRevision === input.baseRevision &&
        current.parentRevisionFingerprint === input.baseRevisionFingerprint
      ) {
        const base = await deps.richTimelineRepository.getRevision({
          projectId: input.projectId,
          timelineId: pointer.timelineId,
          revision: input.baseRevision,
        })
        if (base) {
          const expected = applyRichTimelinePatch({
            base,
            operations: input.operations,
            instructionFingerprint: deps.instructionFingerprint,
            jobOperationsUsed: input.jobOperationsUsed,
            candidateReferences: input.candidateReferences,
          })
          if (expected.contentFingerprint === current.contentFingerprint) {
            return {
              patchId: `patch-${current.revisionFingerprint.slice(0, 16)}`,
              validation: 'accepted',
              errorCode: null,
              proposedRevision: current.revision,
              proposedContentFingerprint: current.contentFingerprint,
              proposedRevisionFingerprint: current.revisionFingerprint,
            }
          }
        }
      }
      if (
        input.baseRevision !== null &&
        (
          current.revision !== input.baseRevision ||
          current.revisionFingerprint !== input.baseRevisionFingerprint
        )
      ) {
        fail('EDITOR_TOOL_TIMELINE_CAS_CONFLICT', 409)
      }
      for (const operation of input.operations) {
        if (operation.op === 'set_transition') {
          deps.capabilityRegistry.assertAllowedParameters(
            operation.capabilityId ?? 'transition.none',
            { durationUs: operation.durationUs ?? 0 },
          )
        }
        if (operation.op === 'set_audio') {
          const locatedTrack = current.tracks.find((/** @type {Record<string, any>} */ track) =>
            Array.isArray(track.segments) &&
            track.segments.some((/** @type {Record<string, any>} */ segment) =>
              segment.segmentId === operation.segmentId))
          const locatedSegment = locatedTrack?.segments?.find(
            (/** @type {Record<string, any>} */ segment) =>
              segment.segmentId === operation.segmentId,
          )
          const capabilityId = typeof locatedSegment?.capabilityId === 'string'
            ? locatedSegment.capabilityId
            : locatedTrack?.role === 'bgm'
              ? 'audio.bgm.local'
              : 'audio.voiceover.edge_tts'
          if (
            capabilityId !== 'audio.bgm.local' ||
            locatedTrack?.role !== 'bgm' ||
            typeof deps.authorizeAudioToken !== 'function' ||
            await deps.authorizeAudioToken({
              projectId: input.projectId,
              segmentId: operation.segmentId,
              audioToken: operation.audioToken,
              volume: operation.volume,
            }) !== true
          ) fail('EDITOR_AUDIO_ASSET_NOT_AUTHORIZED', 403)
          deps.capabilityRegistry.assertAllowedParameters(capabilityId, {
            audioToken: operation.audioToken,
            volume: operation.volume,
          })
        }
        if (operation.op === 'set_text') {
          const locatedTrack = current.tracks.find((/** @type {Record<string, any>} */ track) =>
            Array.isArray(track.segments) &&
            track.segments.some((/** @type {Record<string, any>} */ segment) =>
              segment.segmentId === operation.segmentId))
          const locatedSegment = locatedTrack?.segments?.find(
            (/** @type {Record<string, any>} */ segment) =>
              segment.segmentId === operation.segmentId,
          )
          const capabilityId = typeof locatedSegment?.capabilityId === 'string'
            ? locatedSegment.capabilityId
            : locatedTrack?.kind === 'title'
              ? 'title.card'
              : 'caption.basic'
          deps.capabilityRegistry.assertAllowedParameters(capabilityId, {
            styleToken: operation.styleToken,
          })
        }
        if (operation.op === 'set_keyframes' || operation.op === 'set_effect') {
          fail('EDITOR_CAPABILITY_UNAUTHORIZED', 409)
        }
      }
      const patched = applyRichTimelinePatch({
        base: current,
        operations: input.operations,
        instructionFingerprint: deps.instructionFingerprint,
        jobOperationsUsed: input.jobOperationsUsed,
        candidateReferences: input.candidateReferences,
      })
      assertDeliveryTimelineCapabilities(patched)
      const saved = await deps.richTimelineRepository.saveDraftAndSetCurrent({
        timeline: patched,
        expectedCurrent: {
          timelineId: current.timelineId,
          revision: current.revision,
        },
      })
      return {
        patchId: `patch-${saved.revisionFingerprint.slice(0, 16)}`,
        validation: 'accepted',
        errorCode: null,
        proposedRevision: saved.revision,
        proposedContentFingerprint: saved.contentFingerprint,
        proposedRevisionFingerprint: saved.revisionFingerprint,
      }
      })
    },
    /** @param {Record<string, any>} input */
    async preflight_timeline(input) {
      await requireProject()
      return runPreflight(input)
    },
    /** @param {Record<string, any>} input */
    async finalize_timeline(input) {
      await requireProject()
      return fenced(async () => {
      const pointer = await deps.richTimelineRepository.getCurrent({
        projectId: input.projectId,
      })
      if (
        pointer &&
        pointer.timelineId === input.timelineId &&
        pointer.revision === input.revision + 1
      ) {
        const existing = await deps.richTimelineRepository.getRevision({
          projectId: input.projectId,
          timelineId: input.timelineId,
          revision: pointer.revision,
        })
        if (
          existing?.status === 'finalized' &&
          existing.parentRevision === input.revision &&
          existing.parentRevisionFingerprint === input.revisionFingerprint &&
          (
            typeof deps.instructionFingerprint !== 'string' ||
            (
              existing.source?.kind === 'agent' &&
              existing.source?.instructionFingerprint === deps.instructionFingerprint
            )
          )
        ) {
          return {
            status: 'finalized',
            revision: existing.revision,
            contentFingerprint: existing.contentFingerprint,
            revisionFingerprint: existing.revisionFingerprint,
          }
        }
      }
      if (
        !pointer ||
        pointer.timelineId !== input.timelineId ||
        pointer.revision !== input.revision
      ) {
        fail('EDITOR_TOOL_TIMELINE_CAS_CONFLICT', 409)
      }
      const draft = await deps.richTimelineRepository.getRevision({
        projectId: input.projectId,
        timelineId: input.timelineId,
        revision: input.revision,
      })
      if (!draft || draft.revisionFingerprint !== input.revisionFingerprint) {
        fail('EDITOR_TOOL_TIMELINE_CAS_CONFLICT', 409)
      }
      const preflight = await runPreflight({
        projectId: input.projectId,
        timelineId: input.timelineId,
        revision: input.revision,
        revisionFingerprint: input.revisionFingerprint,
      })
      if (!preflight.ready) {
        fail('EDITOR_FINALIZE_PREFLIGHT_FAILED', 409)
      }
      assertDeliveryTimelineCapabilities(draft)
      const finalized = await deps.richTimelineRepository.finalize({
        projectId: input.projectId,
        timelineId: input.timelineId,
        revision: input.revision,
        revisionFingerprint: input.revisionFingerprint,
        instructionFingerprint: deps.instructionFingerprint,
        expectedCurrent: {
          timelineId: input.timelineId,
          revision: input.revision,
        },
      })
      return {
        status: 'finalized',
        revision: finalized.revision,
        contentFingerprint: finalized.contentFingerprint,
        revisionFingerprint: finalized.revisionFingerprint,
      }
      })
    },
    /** @param {Record<string, any>} input */
    async request_preview(input) {
      if (typeof deps.enqueuePreview !== 'function') fail('EDITOR_TOOL_PREVIEW_UNAVAILABLE', 503)
      const job = await /** @type {Function} */ (deps.enqueuePreview)(input)
      return {
        jobId: job.jobId,
        status: 'queued',
      }
    },
    /** @param {Record<string, any>} input */
    async request_jianying_export(input) {
      if (typeof deps.enqueueJianyingExport !== 'function') {
        fail('EDITOR_TOOL_EXPORT_UNAVAILABLE', 503)
      }
      const job = await /** @type {Function} */ (deps.enqueueJianyingExport)(input)
      return {
        jobId: job.jobId,
        status: 'queued',
      }
    },
  }
}
