import { createHash } from 'node:crypto'

import { isEditPlan } from './director-contracts.mjs'
import { isJianyingDraftExportRequest } from './jianying-draft-contracts.mjs'
import {
  isJianyingTemplateAdapterEnvelope,
  isJianyingTemplateAdapterEnvelopeAuthentic,
} from './reference-template-contracts.mjs'

const maxIdentifierLength = 180
const maxBindings = 100
const maxRegistryEntries = 100
const maxJobEntries = 200
export const jianyingDraftJobStates = Object.freeze([
  'preflight',
  'resolving_materials',
  'building_draft',
  'verifying_output',
  'ready_to_open',
  'failed',
  'cancelled',
])
export const jianyingDraftTemplateCapabilityErrorCodes = Object.freeze([
  'TPL002_UNSUPPORTED_ORIENTATION',
  'TPL002_UNSUPPORTED_TRANSITION',
  'TPL002_UNSUPPORTED_CAPTION_CADENCE',
  'TPL002_UNSUPPORTED_AUDIO_EMPHASIS',
  'TPL002_DURATION_MISMATCH',
  'TPL002_SLOT_COUNT_MISMATCH',
])
export const jianyingDraftCapabilityMatrix = Object.freeze({
  orientation: Object.freeze(['portrait', 'landscape', 'square']),
  transitions: Object.freeze(['cut', 'none', 'dissolve']),
  caption_cadence: Object.freeze(['none', 'steady', 'burst']),
  audio_emphasis: Object.freeze(['none']),
  duration: 'exact_match',
  slot_count: 'exact_match',
})
const adapterErrorDefinitions = {
  JY002_ADAPTER_REQUEST_INVALID: {
    message: 'Jianying export request needs to be rebuilt.',
    action: 'rerun_preflight',
  },
  JY002_REQUEST_NOT_FOUND: {
    message: 'Jianying export request is no longer available.',
    action: 'rerun_preflight',
  },
  JY002_TEMPLATE_ENVELOPE_INVALID: {
    message: 'Template approval is stale or invalid.',
    action: 'review_template',
  },
  JY002_TEMPLATE_CAPABILITY_UNSUPPORTED: {
    message: 'Template capabilities are not supported by this adapter.',
    action: 'adjust_template',
  },
  JY002_MATERIAL_AUTHORIZATION_EXPIRED: {
    message: 'Material authorization needs renewal.',
    action: 'reauthorize_materials',
  },
  JY002_MATERIAL_BINDING_MISSING: {
    message: 'A selected material is no longer available.',
    action: 'replace_shot',
  },
  JY002_VOICEOVER_AUDIO_MISSING: {
    message: 'Voiceover audio is required before export.',
    action: 'generate_voiceover',
  },
  JY002_PATH_PERMISSION_DENIED: {
    message: 'The local export permission needs renewal.',
    action: 'reauthorize_output',
  },
  JY002_DESKTOP_VERSION_UNSUPPORTED: {
    message: 'The installed Jianying environment could not be verified for draft writing.',
    action: 'retry_export',
  },
  JY002_OUTPUT_CONFLICT: {
    message: 'The draft target already exists.',
    action: 'choose_new_output',
  },
  JY002_DRAFT_WRITE_FAILED: {
    message: 'The draft could not be created.',
    action: 'retry_export',
  },
  JY002_DRAFT_STRUCTURE_INVALID: {
    message: 'Generated draft structure needs a retry.',
    action: 'retry_export',
  },
  JY092_TRACK_INSERTION_REQUIREMENT_MISSING: {
    message: 'Track insertion requirements need to be rebuilt.',
    action: 'rerun_preflight',
  },
  JY002_CANCELLED: {
    message: 'The Jianying export was cancelled.',
    action: 'retry_export',
  },
  JY002_INTERNAL_FAILURE: {
    message: 'The Jianying export could not be completed.',
    action: 'retry_export',
  },
}
export const jianyingDraftJobErrorCodes = Object.freeze(Object.keys(adapterErrorDefinitions))

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {Record<string, any>} value @param {string[]} keys */
const hasExactKeys = (value, keys) =>
  Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key))

/** @param {string} value @param {boolean} [rejectColon] */
const hasPathOrControlCharacter = (value, rejectColon = false) =>
  Array.from(value).some((character) => {
    const codePoint = character.codePointAt(0) ?? 0
    return codePoint <= 31 || codePoint === 47 || codePoint === 92 || (rejectColon && codePoint === 58)
  })

/** @param {unknown} value */
const isSafeIdentifier = (value) => {
  if (typeof value !== 'string' || value.length === 0 || value.length > maxIdentifierLength) return false
  if (value !== value.trim() || hasPathOrControlCharacter(value)) return false
  const normalized = value.toLowerCase()
  return (
    !/^[a-z]:/iu.test(value) &&
    !normalized.startsWith('file:') &&
    !normalized.startsWith('http:') &&
    !normalized.startsWith('https:') &&
    !/%(?:2f|5c|3a)/iu.test(value) &&
    !/\.(?:mp4|mov|mkv|avi|mp3|wav|aac|m4a)$/iu.test(value)
  )
}

/** @param {unknown} value */
const isSafePublicText = (value) => {
  if (typeof value !== 'string' || value.length === 0 || value.length > 240) return false
  if (hasPathOrControlCharacter(value)) return false
  const normalized = value.toLowerCase()
  return (
    !/[a-z]:/iu.test(value) &&
    !normalized.includes('file:') &&
    !normalized.includes('http:') &&
    !normalized.includes('https:') &&
    !/%(?:2f|5c|3a)/iu.test(value) &&
    !/\.(?:mp4|mov|mkv|avi|mp3|wav|aac|m4a)/iu.test(value)
  )
}

/** @param {unknown} value */
const isDenseArray = (value) => Array.isArray(value) && Object.keys(value).length === value.length

/** @param {unknown} value */
const isMaterialBinding = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['asset_id', 'scene_id', 'candidate_id', 'authorization_id']) &&
  isSafeIdentifier(value.asset_id) &&
  isSafeIdentifier(value.scene_id) &&
  isSafeIdentifier(value.candidate_id) &&
  isSafeIdentifier(value.authorization_id)

/** @param {unknown} value */
const isVoiceoverBinding = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['sentence_id', 'audio_id', 'authorization_id']) &&
  isSafeIdentifier(value.sentence_id) &&
  isSafeIdentifier(value.audio_id) &&
  isSafeIdentifier(value.authorization_id)

/** @param {unknown} value */
const isOutputPolicy = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['draft_id', 'desktop_open']) &&
  isSafeIdentifier(value.draft_id) &&
  value.desktop_open === false

/** @param {unknown[]} values @param {(value: unknown) => string} keyOf */
const hasUniqueKeys = (values, keyOf) => new Set(values.map(keyOf)).size === values.length

/** @param {unknown} value */
const isZeroCaptionCadence = (value) =>
  isRecord(value) &&
  value.mode === 'none' &&
  value.max_chars_per_card === 0 &&
  value.cards_per_minute === 0
/** @param {unknown} value */
const isSupportedCaptionCadence = (value) =>
  isZeroCaptionCadence(value) ||
  (isRecord(value) &&
    ['steady', 'burst'].includes(value.mode) &&
    Number.isInteger(value.max_chars_per_card) &&
    value.max_chars_per_card > 0 &&
    value.max_chars_per_card <= 60 &&
    Number.isInteger(value.cards_per_minute) &&
    value.cards_per_minute > 0 &&
    value.cards_per_minute <= 120)

/** @param {unknown} value */
const isHexDigest = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value)

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {unknown} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || ['string', 'number', 'boolean'].includes(typeof value)) return JSON.stringify(value)
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`
  if (!isRecord(value)) return JSON.stringify(null)
  return `{${Object.keys(value)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
    .join(',')}}`
}

/** @param {unknown} value */
const sha256 = (value) => createHash('sha256').update(stableStringify(value)).digest('hex')

/** @param {Record<string, any>} request */
const getTimelineSummary = (request) => {
  const preparation = /** @type {Record<string, any>} */ (request.export_request.preparation)
  const timeline = /** @type {Record<string, any>} */ (preparation.timeline)
  const tracks = /** @type {Record<string, any>[]} */ (timeline.tracks)
  return {
    videoSegments: /** @type {Record<string, any>[]} */ (tracks[0].segments),
    voiceoverSegments: /** @type {Record<string, any>[]} */ (tracks[1].segments),
    durationUs: Number(timeline.duration),
  }
}

/** @param {Record<string, any>} envelope @param {Record<string, any>} request */
const deriveAdapterCapabilityErrors = (envelope, request) => {
  const errors = []
  const observationOnly = /** @type {Record<string, any>} */ (envelope.observation_only)
  const transitions = /** @type {unknown[]} */ (observationOnly.transitions)
  const executable = /** @type {Record<string, any>} */ (envelope.executable)
  const slotTiming = /** @type {Record<string, any>} */ (executable.slot_timing)
  const slots = /** @type {Record<string, any>[]} */ (slotTiming.slots)
  const { videoSegments, durationUs } = getTimelineSummary(request)
  if (!jianyingDraftCapabilityMatrix.orientation.includes(observationOnly.orientation)) {
    errors.push('TPL002_UNSUPPORTED_ORIENTATION')
  }
  if (transitions.some((transition) => !['cut', 'none', 'dissolve'].includes(String(transition)))) {
    errors.push('TPL002_UNSUPPORTED_TRANSITION')
  }
  if (!isSupportedCaptionCadence(observationOnly.caption_cadence)) {
    errors.push('TPL002_UNSUPPORTED_CAPTION_CADENCE')
  }
  if (!Array.isArray(observationOnly.audio_emphasis) || observationOnly.audio_emphasis.length > 0) {
    errors.push('TPL002_UNSUPPORTED_AUDIO_EMPHASIS')
  }
  if (Number(slotTiming.target_duration_ms) * 1_000 !== durationUs) {
    errors.push('TPL002_DURATION_MISMATCH')
  }
  if (
    slots.length === videoSegments.length &&
    slots.some(
      (slot, index) =>
        Number(slot.recommended_duration_ms) * 1_000 !== Number(videoSegments[index].target_range.duration),
    )
  ) {
    errors.push('TPL002_DURATION_MISMATCH')
  }
  if (slots.length !== videoSegments.length) {
    errors.push('TPL002_SLOT_COUNT_MISMATCH')
  }
  return Array.from(new Set(errors))
}

/** @param {unknown} value @returns {value is Record<string, any>} */
export const isJianyingDraftAdapterRequest = (value) => {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, [
      'schema_version',
      'kind',
      'request_id',
      'edit_plan',
      'export_request',
      'template_draft',
      'confirmed_template',
      'review_decision',
      'template_envelope',
      'material_bindings',
      'voiceover_bindings',
      'output_policy',
    ]) ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_draft_adapter_request' ||
    !isSafeIdentifier(value.request_id) ||
    !isEditPlan(value.edit_plan) ||
    !isJianyingDraftExportRequest(value.edit_plan, value.export_request) ||
    !isRecord(value.template_draft) ||
    !isRecord(value.confirmed_template) ||
    !isRecord(value.review_decision) ||
    !isJianyingTemplateAdapterEnvelope(value.template_envelope) ||
    !isDenseArray(value.material_bindings) ||
    value.material_bindings.length > maxBindings ||
    !value.material_bindings.every(isMaterialBinding) ||
    !hasUniqueKeys(
      value.material_bindings,
      (binding) => {
        const item = /** @type {Record<string, any>} */ (binding)
        return `${item.asset_id}:${item.scene_id}:${item.candidate_id}`
      },
    ) ||
    !isDenseArray(value.voiceover_bindings) ||
    value.voiceover_bindings.length > maxBindings ||
    !value.voiceover_bindings.every(isVoiceoverBinding) ||
    !hasUniqueKeys(value.voiceover_bindings, (binding) => String(/** @type {Record<string, any>} */ (binding).sentence_id)) ||
    !isOutputPolicy(value.output_policy)
  ) {
    return false
  }
  return true
}

export class JianyingDraftAdapterError extends Error {
  /** @param {keyof typeof adapterErrorDefinitions} code @param {string[]} [affectedIds] */
  constructor(code, affectedIds = []) {
    super(adapterErrorDefinitions[code].message)
    this.name = 'JianyingDraftAdapterError'
    this.code = code
    this.affectedIds = affectedIds.filter(isSafeIdentifier)
  }
}

/** @param {unknown} source @returns {Record<string, any>} */
export const createJianyingDraftAdapterRequest = (source) => {
  if (!isJianyingDraftAdapterRequest(source)) {
    throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
  }
  return clone(source)
}

/** @param {unknown} value @returns {value is Record<string, any>} */
export const isJianyingDraftJobCommand = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['schema_version', 'kind', 'request_id']) &&
  value.schema_version === 1 &&
  value.kind === 'jianying_draft_job_command' &&
  isSafeIdentifier(value.request_id)

export const createJianyingDraftRequestRegistry = () => {
  /** @type {Map<string, Record<string, any>>} */
  const requests = new Map()
  return {
    /** @param {unknown} request */
    register(request) {
      const canonical = createJianyingDraftAdapterRequest(request)
      const requestId = String(canonical.request_id)
      if (!requests.has(requestId) && requests.size >= maxRegistryEntries) {
        throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
      }
      requests.set(requestId, canonical)
      return requestId
    },
    /** @param {string} requestId */
    get(requestId) {
      if (!isSafeIdentifier(requestId)) return null
      const request = requests.get(requestId)
      return request ? clone(request) : null
    },
    /** @param {string} requestId */
    remove(requestId) {
      if (!isSafeIdentifier(requestId)) return false
      return requests.delete(requestId)
    },
  }
}

/** @param {string} code @param {string[]} [affectedIds] */
const createPublicError = (code, affectedIds = []) => {
  if (jianyingDraftTemplateCapabilityErrorCodes.includes(code)) {
    return {
      code,
      message: 'A template capability is not supported by this adapter.',
      recoverable: true,
      action: 'adjust_template',
      affected_ids: affectedIds.filter(isSafeIdentifier),
    }
  }
  const definition = adapterErrorDefinitions[/** @type {keyof typeof adapterErrorDefinitions} */ (code)]
  if (!definition) return createPublicError('JY002_INTERNAL_FAILURE')
  return {
    code,
    message: definition.message,
    recoverable: true,
    action: definition.action,
    affected_ids: affectedIds.filter(isSafeIdentifier),
  }
}

/** @param {unknown} value */
const isPublicError = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['code', 'message', 'recoverable', 'action', 'affected_ids']) &&
  (Object.hasOwn(adapterErrorDefinitions, value.code) || jianyingDraftTemplateCapabilityErrorCodes.includes(value.code)) &&
  isSafePublicText(value.message) &&
  value.recoverable === true &&
  isSafeIdentifier(value.action) &&
  isDenseArray(value.affected_ids) &&
  value.affected_ids.every(isSafeIdentifier)

const preflightCheckCodes = [
  'canonical_export_request',
  'approved_template_envelope',
  'template_capabilities',
  'material_bindings',
  'voiceover_audio',
  'output_policy',
]

/** @param {unknown} value */
const isPreflightCheck = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['code', 'status']) &&
  preflightCheckCodes.includes(value.code) &&
  ['pass', 'fail'].includes(value.status)

/** @param {unknown} value */
export const isJianyingDraftAdapterPreflightReport = (value) => {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ['schema_version', 'kind', 'request_id', 'ready', 'checks', 'errors', 'summary']) ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_draft_adapter_preflight_report' ||
    !isSafeIdentifier(value.request_id) ||
    typeof value.ready !== 'boolean' ||
    !isDenseArray(value.checks) ||
    value.checks.length !== preflightCheckCodes.length ||
    !value.checks.every(isPreflightCheck) ||
    !isDenseArray(value.errors) ||
    !value.errors.every(isPublicError) ||
    !isRecord(value.summary) ||
    !hasExactKeys(value.summary, ['video_segments', 'voiceover_segments', 'duration_us']) ||
    !Number.isSafeInteger(value.summary.video_segments) ||
    !Number.isSafeInteger(value.summary.voiceover_segments) ||
    !Number.isSafeInteger(value.summary.duration_us) ||
    value.summary.video_segments < 0 ||
    value.summary.voiceover_segments < 0 ||
    value.summary.duration_us < 0
  ) {
    return false
  }
  const checks = /** @type {Record<string, any>[]} */ (value.checks)
  if (!checks.every((check, index) => check.code === preflightCheckCodes[index])) return false
  return value.ready === (value.errors.length === 0)
}

/** @param {Record<string, any>[]} bindings */
const materialBindingKey = (bindings) =>
  new Set(bindings.map((binding) => `${binding.asset_id}:${binding.scene_id}:${binding.candidate_id}`))

/** @param {Record<string, any>[]} bindings */
const voiceoverBindingKey = (bindings) => new Set(bindings.map((binding) => binding.sentence_id))

/** @param {unknown} request */
export const preflightJianyingDraftAdapterRequest = (request) => {
  if (!isJianyingDraftAdapterRequest(request)) {
    throw new JianyingDraftAdapterError('JY002_ADAPTER_REQUEST_INVALID')
  }
  const source = /** @type {Record<string, any>} */ (request)
  const errors = []
  const { videoSegments, voiceoverSegments, durationUs } = getTimelineSummary(source)
  const envelopeAuthentic = isJianyingTemplateAdapterEnvelopeAuthentic(
    source.template_envelope,
    source.edit_plan,
    source.export_request,
    source.template_draft,
    source.confirmed_template,
    source.review_decision,
  )
  const capabilityErrors = envelopeAuthentic
    ? deriveAdapterCapabilityErrors(source.template_envelope, source)
    : []
  const envelopeReady = envelopeAuthentic && capabilityErrors.length === 0
  if (!envelopeAuthentic) {
    errors.push(createPublicError('JY002_TEMPLATE_ENVELOPE_INVALID'))
  } else if (!envelopeReady) {
    for (const code of capabilityErrors) errors.push(createPublicError(code))
  }

  const materialKeys = materialBindingKey(/** @type {Record<string, any>[]} */ (source.material_bindings))
  const missingMaterials = videoSegments
    .filter((segment) => {
      const ref = /** @type {Record<string, any>} */ (segment.material_ref)
      return !materialKeys.has(`${ref.asset_id}:${ref.scene_id}:${ref.candidate_id}`)
    })
    .map((segment) => String(segment.sentence_id))
  if (missingMaterials.length > 0) {
    errors.push(createPublicError('JY002_MATERIAL_BINDING_MISSING', missingMaterials))
  }

  const packagingVoiceoverTokens = Array.isArray(source.export_request.packaging?.voiceover_audio_tokens)
    ? source.export_request.packaging.voiceover_audio_tokens
    : null
  const expectedVoiceoverSegments = packagingVoiceoverTokens?.length === 0 ? [] : voiceoverSegments
  const voiceoverKeys = voiceoverBindingKey(/** @type {Record<string, any>[]} */ (source.voiceover_bindings))
  const missingVoiceover = expectedVoiceoverSegments
    .filter((segment) => !voiceoverKeys.has(segment.sentence_id))
    .map((segment) => String(segment.sentence_id))
  if (
    packagingVoiceoverTokens !== null &&
    (
      ![0, voiceoverSegments.length].includes(packagingVoiceoverTokens.length) ||
      source.voiceover_bindings.length !== packagingVoiceoverTokens.length
    )
  ) {
    missingVoiceover.push(...voiceoverSegments.map((segment) => String(segment.sentence_id)))
  }
  if (missingVoiceover.length > 0) {
    errors.push(createPublicError('JY002_VOICEOVER_AUDIO_MISSING', missingVoiceover))
  }

  const checks = [
    { code: 'canonical_export_request', status: 'pass' },
    { code: 'approved_template_envelope', status: envelopeAuthentic ? 'pass' : 'fail' },
    { code: 'template_capabilities', status: envelopeReady ? 'pass' : 'fail' },
    { code: 'material_bindings', status: missingMaterials.length === 0 ? 'pass' : 'fail' },
    { code: 'voiceover_audio', status: missingVoiceover.length === 0 ? 'pass' : 'fail' },
    { code: 'output_policy', status: 'pass' },
  ]
  const report = {
    schema_version: 1,
    kind: 'jianying_draft_adapter_preflight_report',
    request_id: source.request_id,
    ready: errors.length === 0,
    checks,
    errors,
    summary: {
      video_segments: videoSegments.length,
      voiceover_segments: source.voiceover_bindings.length,
      duration_us: durationUs,
    },
  }
  if (!isJianyingDraftAdapterPreflightReport(report)) {
    throw new JianyingDraftAdapterError('JY002_INTERNAL_FAILURE')
  }
  return report
}

/** @param {unknown} value */
const isJobResult = (value) =>
  isRecord(value) &&
  hasExactKeys(value, [
    'draft_id',
    'video_segments',
    'voiceover_segments',
    'duration_us',
    'output_fingerprint',
  ]) &&
  isSafeIdentifier(value.draft_id) &&
  Number.isSafeInteger(value.video_segments) &&
  value.video_segments >= 0 &&
  Number.isSafeInteger(value.voiceover_segments) &&
  value.voiceover_segments >= 0 &&
  Number.isSafeInteger(value.duration_us) &&
  value.duration_us >= 0 &&
  isHexDigest(value.output_fingerprint)

/** @param {unknown} value @returns {value is Record<string, any>} */
export const isJianyingDraftJobStatus = (value) => {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, [
      'schema_version',
      'kind',
      'job_id',
      'state',
      'progress_percent',
      'recoverable',
      'error',
      'result',
    ]) ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_draft_job_status' ||
    !isSafeIdentifier(value.job_id) ||
    !jianyingDraftJobStates.includes(value.state) ||
    !Number.isInteger(value.progress_percent) ||
    value.progress_percent < 0 ||
    value.progress_percent > 100 ||
    typeof value.recoverable !== 'boolean' ||
    (value.error !== null && !isPublicError(value.error)) ||
    (value.result !== null && !isJobResult(value.result))
  ) {
    return false
  }
  if (value.state === 'ready_to_open') return value.error === null && isJobResult(value.result)
  if (value.state === 'failed') return isPublicError(value.error) && value.result === null
  return value.result === null
}

/** @param {string} jobId @param {string} state @param {number} progress @param {Record<string, any> | null} error @param {Record<string, any> | null} result */
const createStatus = (jobId, state, progress, error = null, result = null) => {
  const status = {
    schema_version: 1,
    kind: 'jianying_draft_job_status',
    job_id: jobId,
    state,
    progress_percent: progress,
    recoverable: state !== 'ready_to_open',
    error,
    result,
  }
  if (!isJianyingDraftJobStatus(status)) {
    throw new JianyingDraftAdapterError('JY002_INTERNAL_FAILURE')
  }
  return status
}

/** @param {Record<string, any>[]} errors */
const primaryPreflightError = (errors) => {
  if (errors.some((error) => jianyingDraftTemplateCapabilityErrorCodes.includes(error.code))) {
    return createPublicError('JY002_TEMPLATE_CAPABILITY_UNSUPPORTED')
  }
  return errors[0] ?? createPublicError('JY002_INTERNAL_FAILURE')
}

/** @param {unknown} error */
const publicExecutionError = (error) => {
  if (error instanceof JianyingDraftAdapterError) {
    return createPublicError(error.code, error.affectedIds)
  }
  if (isRecord(error) && Object.hasOwn(adapterErrorDefinitions, error.code)) {
    const affectedIds = Array.isArray(error.affected_ids) ? error.affected_ids.filter(isSafeIdentifier) : []
    return createPublicError(String(error.code), affectedIds)
  }
  return createPublicError('JY002_INTERNAL_FAILURE')
}

/**
 * @param {{
 * resolveMaterial?: (binding: Record<string, any>) => Promise<unknown>,
 * resolveVoiceover?: (binding: Record<string, any>) => Promise<unknown>,
 * writeDraft?: (input: Record<string, any>) => Promise<unknown>,
 * verifyDraft?: (input: Record<string, any>) => Promise<boolean>,
 * cleanupDraft?: (input: Record<string, any>) => Promise<void>,
 * releaseDraft?: (input: Record<string, any>) => Promise<boolean>,
 * cleanupOwnedDraft?: (input: {requestId: string, draftId: string}) => Promise<boolean>,
 * releaseOwnedDraft?: (input: {requestId: string, draftId: string}) => Promise<boolean>,
 * }} dependencies
 */
export const createJianyingDraftJobService = ({
  resolveMaterial = async () => {
    throw new JianyingDraftAdapterError('JY002_MATERIAL_AUTHORIZATION_EXPIRED')
  },
  resolveVoiceover = async () => {
    throw new JianyingDraftAdapterError('JY002_VOICEOVER_AUDIO_MISSING')
  },
  writeDraft = async () => {
    throw new JianyingDraftAdapterError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  },
  verifyDraft = async () => false,
  cleanupDraft = async () => {},
  releaseDraft = async () => false,
  cleanupOwnedDraft = async () => false,
  releaseOwnedDraft = async () => false,
} = {}) => {
  /** @type {Map<string, { status: Record<string, any>, cancelled: boolean, settled: boolean, controller: AbortController, execution: Promise<void> | null }>} */
  const jobs = new Map()
  /** @type {Map<string, string>} */
  const currentJobs = new Map()
  /** @type {Map<string, number>} */
  const attempts = new Map()

  const pruneTerminalJobs = () => {
    if (jobs.size < maxJobEntries) return
    for (const [jobId, entry] of jobs) {
      if (!entry.settled || !['ready_to_open', 'failed', 'cancelled'].includes(entry.status.state)) continue
      jobs.delete(jobId)
      for (const [jobKey, currentJobId] of currentJobs) {
        if (currentJobId === jobId) currentJobs.delete(jobKey)
      }
      if (jobs.size < maxJobEntries) return
    }
  }

  /** @param {string} jobId @param {Record<string, any>} canonical @param {{ status: Record<string, any>, cancelled: boolean, settled: boolean, controller: AbortController, execution: Promise<void> | null }} entry */
  const execute = async (jobId, canonical, entry) => {
    if (entry.cancelled) {
      entry.status = createStatus(jobId, 'cancelled', 100, createPublicError('JY002_CANCELLED'))
      return
    }
    const preflight = preflightJianyingDraftAdapterRequest(canonical)
    if (!preflight.ready) {
      if (entry.cancelled) {
        entry.status = createStatus(jobId, 'cancelled', 100, createPublicError('JY002_CANCELLED'))
        return
      }
      entry.status = createStatus(jobId, 'failed', 100, primaryPreflightError(preflight.errors))
      return
    }

    let writeResult = null
    try {
      entry.status = createStatus(jobId, 'resolving_materials', 25)
      const materialBindings = /** @type {Record<string, any>[]} */ (canonical.material_bindings)
      const voiceoverBindings = /** @type {Record<string, any>[]} */ (canonical.voiceover_bindings)
      const materials = []
      for (const binding of materialBindings) {
        if (entry.cancelled) throw new JianyingDraftAdapterError('JY002_CANCELLED')
        materials.push(await resolveMaterial({ ...clone(binding), request_id: canonical.request_id }))
      }
      const voiceovers = []
      for (const binding of voiceoverBindings) {
        if (entry.cancelled) throw new JianyingDraftAdapterError('JY002_CANCELLED')
        voiceovers.push(await resolveVoiceover({ ...clone(binding), request_id: canonical.request_id }))
      }

      if (entry.cancelled) throw new JianyingDraftAdapterError('JY002_CANCELLED')
      entry.status = createStatus(jobId, 'building_draft', 55)
      writeResult = await writeDraft({
        job_id: jobId,
        request_id: canonical.request_id,
        output_policy: clone(canonical.output_policy),
        export_request: clone(canonical.export_request),
        orientation: canonical.template_envelope.observation_only.orientation,
        slot_timing: clone(canonical.template_envelope.executable.slot_timing),
        materials,
        voiceovers,
        signal: entry.controller.signal,
      })
      if (entry.cancelled) throw new JianyingDraftAdapterError('JY002_CANCELLED')
      if (
        !isRecord(writeResult) ||
        !hasExactKeys(writeResult, ['draft_id', 'output_fingerprint']) ||
        !isSafeIdentifier(writeResult.draft_id) ||
        !isHexDigest(writeResult.output_fingerprint)
      ) {
        throw new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED')
      }

      if (entry.cancelled) throw new JianyingDraftAdapterError('JY002_CANCELLED')
      entry.status = createStatus(jobId, 'verifying_output', 80)
      const verified = await verifyDraft({
        job_id: jobId,
        request: canonical,
        write_result: clone(writeResult),
      })
      if (entry.cancelled) throw new JianyingDraftAdapterError('JY002_CANCELLED')
      if (verified !== true) {
        throw new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID', [String(writeResult.draft_id)])
      }
      const { videoSegments, durationUs } = getTimelineSummary(canonical)
      const result = {
        draft_id: writeResult.draft_id,
        video_segments: videoSegments.length,
        voiceover_segments: canonical.voiceover_bindings.length,
        duration_us: durationUs,
        output_fingerprint: writeResult.output_fingerprint,
      }
      entry.status = createStatus(jobId, 'ready_to_open', 100, null, result)
    } catch (error) {
      console.warn(JSON.stringify({
        event: 'jianying_adapter_execution_rejected',
        state: typeof entry.status?.state === 'string' ? entry.status.state : 'unknown',
        code: error instanceof JianyingDraftAdapterError ? error.code : 'JY002_DRAFT_WRITE_FAILED',
        stage: error instanceof Error && typeof /** @type {any} */ (error).stage === 'string'
          ? /** @type {any} */ (error).stage
          : null,
      }))
      let cleanupFailed = false
      if (writeResult !== null) {
        try {
          await cleanupDraft({ job_id: jobId, write_result: clone(writeResult) })
        } catch {
          cleanupFailed = true
        }
      }
      const publicError = cleanupFailed
        ? createPublicError('JY002_DRAFT_WRITE_FAILED')
        : publicExecutionError(error)
      entry.status = createStatus(
        jobId,
        publicError.code === 'JY002_CANCELLED' ? 'cancelled' : 'failed',
        100,
        publicError,
      )
    }
  }

  /** @param {Record<string, any>} request */
  const start = (request) => {
    const canonical = createJianyingDraftAdapterRequest(request)
    pruneTerminalJobs()
    if (jobs.size >= maxJobEntries) {
      throw new JianyingDraftAdapterError('JY002_INTERNAL_FAILURE')
    }
    const jobKey = sha256({ request_id: canonical.request_id, envelope_id: canonical.template_envelope.envelope_id }).slice(0, 24)
    const currentJobId = currentJobs.get(jobKey)
    const existing = currentJobId ? jobs.get(currentJobId) : null
    if (existing && (!existing.settled || !['failed', 'cancelled'].includes(existing.status.state))) {
      return clone(existing.status)
    }

    const attempt = (attempts.get(jobKey) ?? 0) + 1
    attempts.set(jobKey, attempt)
    const jobId = `jy002-job-${jobKey}${attempt === 1 ? '' : `-retry-${attempt}`}`

    const entry = /** @type {{ status: Record<string, any>, cancelled: boolean, settled: boolean, controller: AbortController, execution: Promise<void> | null }} */ ({
      status: createStatus(jobId, 'preflight', 5),
      cancelled: false,
      settled: false,
      controller: new AbortController(),
      execution: null,
    })
    jobs.set(jobId, entry)
    currentJobs.set(jobKey, jobId)
    entry.execution = Promise.resolve()
      .then(() => execute(jobId, canonical, entry))
      .finally(() => {
        entry.settled = true
      })
    return clone(entry.status)
  }

  return {
    start,
    /** @param {string} jobId */
    getStatus(jobId) {
      if (!isSafeIdentifier(jobId)) return null
      const entry = jobs.get(jobId)
      return entry ? clone(entry.status) : null
    },
    /** @param {string} jobId */
    async cancel(jobId) {
      const entry = jobs.get(jobId)
      if (!entry) return null
      if (['ready_to_open', 'failed', 'cancelled'].includes(entry.status.state)) return clone(entry.status)
      entry.cancelled = true
      entry.controller.abort()
      await entry.execution
      return clone(entry.status)
    },
    /** @param {string} jobId */
    async waitForCompletion(jobId) {
      const entry = jobs.get(jobId)
      if (!entry) return null
      await entry.execution
      return clone(entry.status)
    },
    /** @param {string} jobId */
    async cleanupPublished(jobId) {
      const entry = jobs.get(jobId)
      const result = entry?.status?.result
      if (!entry || entry.status.state !== 'ready_to_open' || !result) return false
      await cleanupDraft({ job_id: jobId, write_result: clone(result) })
      jobs.delete(jobId)
      for (const [jobKey, currentJobId] of currentJobs) {
        if (currentJobId === jobId) currentJobs.delete(jobKey)
      }
      return true
    },
    /** @param {string} jobId */
    async releasePublished(jobId) {
      const entry = jobs.get(jobId)
      const result = entry?.status?.result
      if (!entry || entry.status.state !== 'ready_to_open' || !result) return false
      return await releaseDraft({ job_id: jobId, write_result: clone(result) }) === true
    },
    /** @param {{requestId: string, draftId: string}} input */
    async cleanupOwned(input) {
      return cleanupOwnedDraft(input)
    },
    /** @param {{requestId: string, draftId: string}} input */
    async releaseOwned(input) {
      return releaseOwnedDraft(input)
    },
  }
}
