import { createReferenceTemplateAdapter } from './reference-template-adapter.mjs'

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Build a reusable template artifact from a public ReplicationRecipe.
 * Uses the existing reference adapter scene → slots compiler so fingerprint
 * and draft contracts stay compatible.
 * @param {{
 *   projectId: string,
 *   recipe: Record<string, any>,
 *   orientation: 'portrait' | 'landscape' | 'square',
 *   pacing: 'calm' | 'balanced' | 'dynamic',
 *   targetDurationSeconds: number,
 * }} input
 */
export const createReusableTemplateArtifactFromRecipe = async (input) => {
  if (
    !record(input?.recipe) ||
    !Array.isArray(input.recipe.videoSlots) ||
    input.recipe.videoSlots.length < 1
  ) {
    throw new Error('REPLICATION_RECIPE_SLOTS_MISSING')
  }
  const durationMs = Math.max(
    1_000,
    Math.round(Number(input.recipe.durationUs) / 1_000) || input.targetDurationSeconds * 1_000,
  )
  let previousEndMs = 0
  const scenes = input.recipe.videoSlots.map((slot, index) => {
    // Round the first boundary only. Reusing the previous end for each later
    // start keeps the reference-analysis shot list contiguous after converting
    // microseconds to milliseconds (independent rounding can create 1ms gaps).
    const startMs = index === 0 ? 0 : previousEndMs
    const nextStart = index + 1 < input.recipe.videoSlots.length
      ? Math.max(startMs + 1, Math.round(Number(input.recipe.videoSlots[index + 1].startUs) / 1_000))
      : durationMs
    // Preserve real sub-500ms intro/outro slots; never invent overlap with the next cue.
    const rawEnd = startMs + Math.max(1, Math.round(Number(slot.durationUs) / 1_000))
    const roundedEndMs = Math.min(durationMs, Math.max(startMs + 1, Math.min(rawEnd, nextStart)))
    // The contract requires the final shot to reach the full rounded duration;
    // accumulated per-slot rounding can otherwise leave a 1ms tail uncovered.
    const endMs = index === input.recipe.videoSlots.length - 1 ? durationMs : roundedEndMs
    previousEndMs = endMs
    return {
      sceneId: `recipe-slot-${index + 1}`,
      startMs,
      endMs,
    }
  })
  const contentGoal = input.pacing === 'dynamic'
    ? 'montage'
    : input.targetDurationSeconds > 60
      ? (input.orientation === 'square' ? 'tutorial' : 'narrative')
      : 'product_showcase'
  const captionsRequired = Array.isArray(input.recipe.textSegments)
    ? input.recipe.textSegments.some((entry) => entry?.role === 'caption' || entry?.role === 'rich_text')
    : true
  const adapter = createReferenceTemplateAdapter({
    materialAnalysisProvider: {
      inspectAuthorizedReferenceFile: async () => ({
        referenceId: `recipe-${String(input.recipe.source?.fingerprint || 'unknown').slice(0, 24)}`,
        durationMs,
        orientation: input.orientation,
        transcript: captionsRequired ? '模板字幕占位' : '',
        scenes,
      }),
      inspectReferenceAsset: async () => ({
        referenceId: `recipe-${String(input.recipe.source?.fingerprint || 'unknown').slice(0, 24)}`,
        durationMs,
        orientation: input.orientation,
        transcript: captionsRequired ? '模板字幕占位' : '',
        scenes,
      }),
    },
  })
  return adapter.generate({
    projectId: input.projectId,
    authorizationId: 'unused',
    referenceAuthorizationId: 'authorization-recipe',
    templateSelectionRequest: {
      schema_version: 1,
      kind: 'template_selection_request',
      project_id: input.projectId,
      content_goal: contentGoal,
      orientation: input.orientation,
      pacing: input.pacing,
      target_duration_seconds: input.targetDurationSeconds,
      voiceover_required: Array.isArray(input.recipe.audioCues)
        ? input.recipe.audioCues.some((entry) => entry?.role === 'voiceover')
        : false,
      captions_required: captionsRequired,
    },
  })
}
