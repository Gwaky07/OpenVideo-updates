import { createJY200DuoPublicationAuthority } from './jianying-duo-staging-publisher.mjs'
import { createJY200DuoWorkbenchAdapter } from './jianying-duo-workbench-adapter.mjs'
import { createTrustedExternalWriterAdmissionAuthority } from './jianying-external-writer-admission-registry.mjs'
import { createExternalWriterProvider } from './jianying-external-writer-provider.mjs'
import { createGatewayOwnedStagingLeaseManager } from './jianying-external-writer-staging-lease.mjs'
import { createJianyingWriterOwnerCapability } from './jianying-writer-owner-capability.mjs'
import { createEditorCapabilityRegistry } from './editor-capability-registry.mjs'
import { readTimelinePackagingSelections } from './jianying-timeline-packaging-selections.mjs'

const DUO_PROVIDER_ID = 'duo-video'

/** @typedef {{provider: 'duo-video', identity: unknown}} CurrentAdmission */

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {CurrentAdmission | null} */
const normalizeCurrentAdmission = (value) => {
  if (value == null) return null
  const record = isRecord(value) ? /** @type {Record<string, unknown>} */ (value) : null
  if (!record || record.provider !== DUO_PROVIDER_ID || !Object.hasOwn(record, 'identity')) {
    throw new TypeError('JY200_DUO_CURRENT_ADMISSION_INVALID')
  }
  return /** @type {CurrentAdmission} */ (Object.freeze({
    provider: DUO_PROVIDER_ID,
    identity: record.identity,
  }))
}

/** @param {unknown} identity @param {unknown} richTimeline */
const assertRequestWithinAdmission = (identity, richTimeline) => {
  const capabilities = /** @type {Record<string, any>} */ (identity)?.capability_snapshot?.capabilities
  const requirements = /** @type {Record<string, any>} */ (richTimeline)?.capabilityRequirements
  if (!Array.isArray(capabilities) || !Array.isArray(requirements)) {
    throw new Error('JY200_DUO_CURRENT_ADMISSION_INVALID')
  }
  const admitted = new Set(capabilities)
  const required = requirements
    .filter((entry) => entry?.acceptance === 'implemented')
    .map((entry) => entry?.capabilityId)
  if (required.some((capabilityId) => typeof capabilityId !== 'string' || !admitted.has(capabilityId))) {
    throw new Error('JY200_DUO_ADMISSION_CAPABILITY_UNSUPPORTED')
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const failProbationaryInput = (code, status = 400) => {
  throw Object.assign(new Error(code), { code, status })
}

/**
 * Derive the private material request from the finalized timeline. The
 * probationary caller may name the project/job, but cannot substitute an
 * authorization independently of the canonical video segments.
 * @param {{projectId: unknown, richTimeline: unknown}} input
 */
export const resolveJY200DuoProbationaryMaterialRequest = ({ projectId, richTimeline }) => {
  if (typeof projectId !== 'string' || projectId.length === 0 || !isRecord(richTimeline) ||
      richTimeline.projectId !== projectId || richTimeline.status !== 'finalized') {
    failProbationaryInput('JY200_DUO_PROBATIONARY_INPUT_INVALID')
  }
  const selections = []
  const authorizationIds = new Set()
  for (const track of Array.isArray(richTimeline.tracks) ? richTimeline.tracks : []) {
    if (track?.kind !== 'video' || track?.role !== 'primary' || track?.enabled === false) continue
    for (const segment of Array.isArray(track.segments) ? track.segments : []) {
      const range = segment?.sourceRange
      const target = segment?.targetRange
      if (!segment?.asset || typeof segment.asset.authorizationId !== 'string' ||
          typeof segment.asset.assetId !== 'string' || typeof segment.asset.sceneId !== 'string' ||
          typeof segment.audit?.candidateId !== 'string' || !range || !target ||
          !Number.isSafeInteger(range.startUs) || !Number.isSafeInteger(range.durationUs) ||
          !Number.isSafeInteger(target.startUs) || !Number.isSafeInteger(target.durationUs)) {
        failProbationaryInput('JY200_DUO_PROBATIONARY_INPUT_INVALID')
      }
      authorizationIds.add(segment.asset.authorizationId)
      selections.push(Object.freeze({
        candidateId: segment.audit.candidateId,
        start: range.startUs / 1_000_000,
        end: (range.startUs + range.durationUs) / 1_000_000,
      }))
    }
  }
  if (selections.length === 0 || authorizationIds.size !== 1) {
    failProbationaryInput('JY200_DUO_PROBATIONARY_MATERIALS_UNAVAILABLE', 409)
  }
  return Object.freeze({
    projectId,
    authorizationId: [...authorizationIds][0],
    selections: Object.freeze(selections),
  })
}

/**
 * Create one Gateway-private Duo Writer seam. The external provider is only
 * attached when the current admission callback returns a real current identity.
 * Deferred or missing admission keeps the existing Native path unchanged.
 * @template {Record<string, any>} T
 * @param {{
 *   nativeCapability: T,
 *   ownerRepository?: {claim: Function, get: Function, complete: Function} | null,
 *   publicationRepository?: Record<string, any> | null,
 *   resolveCurrentAdmission: () => Promise<unknown> | unknown,
 *   runtimeRoot?: string | null,
 *   liveDraftRoot?: string | null,
 *   repositoryRoot?: string | null,
 *   resolveCurrentBindings?: ((input: Record<string, any>) => Promise<unknown> | unknown) | null,
 *   run?: ((input: {lease: Record<string, unknown>, writePlan: Record<string, unknown>, resolveLeaseRoot: () => Promise<string>}) => Promise<unknown>) | null,
 *   inspectReadback?: ((input: {stagingRoot: string, providerResult: Record<string, unknown>, writePlan: Record<string, unknown>, trustedBindings: readonly Record<string, unknown>[]}) => Promise<unknown>) | null,
 *   preferredProvider?: string | null,
 *   now?: () => Date,
 * }} input
 * @returns {Promise<T>}
 */
export const createJY200DuoServerPrivateWriterCapability = async ({
  nativeCapability,
  ownerRepository = null,
  publicationRepository = null,
  resolveCurrentAdmission,
  runtimeRoot = null,
  liveDraftRoot = null,
  repositoryRoot = null,
  resolveCurrentBindings = null,
  run = null,
  inspectReadback = null,
  preferredProvider = null,
  now = () => new Date(),
}) => {
  if (typeof resolveCurrentAdmission !== 'function') {
    throw new TypeError('JY200_DUO_CURRENT_ADMISSION_READER_REQUIRED')
  }
  const initialAdmission = normalizeCurrentAdmission(await resolveCurrentAdmission())
  if (!initialAdmission) {
    return createJianyingWriterOwnerCapability({
      nativeCapability,
      ownerRepository,
    })
  }
  if (typeof resolveCurrentBindings !== 'function' || typeof run !== 'function' || typeof inspectReadback !== 'function') {
    throw new TypeError('JY200_DUO_SERVER_PRIVATE_RUNNER_REQUIRED')
  }
  if (!publicationRepository || typeof publicationRepository.preparePublication !== 'function') {
    throw new TypeError('JY200_DUO_PUBLICATION_REPOSITORY_REQUIRED')
  }
  const admissionAuthority = createTrustedExternalWriterAdmissionAuthority({
    resolveCurrentIdentity: async (provider) => {
      const current = normalizeCurrentAdmission(await resolveCurrentAdmission())
      if (!current || current.provider !== provider) throw new Error('JY200_PROVIDER_ADMISSION_STALE')
      return current.identity
    },
  })
  const admissionHandle = admissionAuthority.issue(initialAdmission)
  const leaseManager = await createGatewayOwnedStagingLeaseManager({
    runtimeRoot: /** @type {string} */ (runtimeRoot),
    liveDraftRoot: /** @type {string} */ (liveDraftRoot),
    repositoryRoot: /** @type {string} */ (repositoryRoot),
  })
  const adapter = createJY200DuoWorkbenchAdapter({
    resolveCurrentBindings,
    runner: ({ lease, writePlan }) => run({
      lease,
      writePlan,
      resolveLeaseRoot: () => leaseManager.resolve(lease),
    }),
    inspectReadback,
    now,
  })
  const publicationAuthority = createJY200DuoPublicationAuthority({
    publicationRepository,
    runtimeRoot: /** @type {string} */ (runtimeRoot),
    liveDraftRoot: /** @type {string} */ (liveDraftRoot),
    repositoryRoot: /** @type {string} */ (repositoryRoot),
    providerId: DUO_PROVIDER_ID,
  })
  const duoProvider = createExternalWriterProvider({
    manifest: { provider: DUO_PROVIDER_ID },
    admissionHandle,
    admissionRegistry: admissionAuthority.registry,
    leaseManager,
    run: async (input, lease) => {
      const current = normalizeCurrentAdmission(await resolveCurrentAdmission())
      if (!current) throw new Error('JY200_PROVIDER_ADMISSION_STALE')
      assertRequestWithinAdmission(current.identity, input?.richTimeline)
      return adapter.run(/** @type {any} */ (input), lease)
    },
    readback: (input) => adapter.readback(input),
    canExportPackagingSelections: async (richTimeline) => {
      const selections = readTimelinePackagingSelections(richTimeline)
      if (selections.length < 1) return false
      const currentBindings = await resolveCurrentBindings({ richTimeline })
      if (!Array.isArray(currentBindings) || currentBindings.length !== 3) return false
      const admitted = new Map(currentBindings.map((binding) => [binding?.packaging_token, binding?.family]))
      return selections.every((selection) => admitted.get(selection?.packagingToken) === selection?.family)
    },
    publish: publicationAuthority.publish,
    rollbackPublish: (input) => publicationAuthority.rollback({
      jobId: typeof /** @type {{jobId?: unknown}} */ (input)?.jobId === 'string'
        ? /** @type {{jobId: string}} */ (input).jobId
        : '',
    }),
    commitPublish: (input) => publicationAuthority.commit({
      jobId: typeof /** @type {{jobId?: unknown}} */ (input)?.jobId === 'string'
        ? /** @type {{jobId: string}} */ (input).jobId
        : '',
    }),
  })
  const nativeCapabilities = createEditorCapabilityRegistry({
    jianyingProfileId: nativeCapability.desktopProfile?.profileId ?? null,
    privateCatalogCapabilities: nativeCapability.privateCatalogCapabilities ?? [],
    evidencedCapabilities: nativeCapability.evidencedCapabilities ?? [],
    promotionReceipts: nativeCapability.promotionReceipts ?? [],
  }).list().capabilities
    .filter((entry) => entry.targets.jianying.status === 'implemented')
    .map((entry) => entry.capabilityId)
  return createJianyingWriterOwnerCapability({
    nativeCapability,
    nativeCapabilities,
    externalProviders: [duoProvider],
    admissionRegistry: admissionAuthority.registry,
    preferredProvider,
    ownerRepository,
  })
}

/**
 * Bounded Gate-A route for exercising the real Workbench adapter without
 * issuing a production admission handle or attaching Duo to the normal
 * Writer router. The caller cannot choose a filesystem path or provider.
 * @param {{
 *   ownerRepository: {claim: Function, get: Function, getTerminal?: Function, complete: Function},
 *   publicationRepository: Record<string, any>,
 *   resolveCurrentFeasibility: () => Promise<unknown> | unknown,
 *   runtimeRoot: string, liveDraftRoot: string, repositoryRoot: string,
 *   resolveCurrentBindings: (input: Record<string, any>) => Promise<unknown> | unknown,
 *   run: (input: {lease: Record<string, unknown>, writePlan: Record<string, unknown>, resolveLeaseRoot: () => Promise<string>}) => Promise<unknown>,
 *   inspectReadback: (input: Record<string, any>) => Promise<unknown>,
 *   now?: () => Date,
 * }} input
 */
export const createJY200DuoProbationaryWorkbenchCapability = async ({
  ownerRepository,
  publicationRepository,
  resolveCurrentFeasibility,
  runtimeRoot,
  liveDraftRoot,
  repositoryRoot,
  resolveCurrentBindings,
  run,
  inspectReadback,
  now = () => new Date(),
}) => {
  if (!ownerRepository || typeof ownerRepository.claim !== 'function' ||
      typeof ownerRepository.complete !== 'function' || typeof resolveCurrentFeasibility !== 'function' ||
      typeof resolveCurrentBindings !== 'function' || typeof run !== 'function' || typeof inspectReadback !== 'function') {
    throw new TypeError('JY200_DUO_PROBATIONARY_INPUT_INVALID')
  }
  const leaseManager = await createGatewayOwnedStagingLeaseManager({ runtimeRoot, liveDraftRoot, repositoryRoot })
  const adapter = createJY200DuoWorkbenchAdapter({
    resolveCurrentBindings,
    runner: ({ lease, writePlan }) => run({
      lease,
      writePlan,
      resolveLeaseRoot: () => leaseManager.resolve(lease),
    }),
    inspectReadback,
    now,
  })
  const publicationAuthority = createJY200DuoPublicationAuthority({
    publicationRepository,
    runtimeRoot,
    liveDraftRoot,
    repositoryRoot,
    providerId: DUO_PROVIDER_ID,
  })
  const readFeasibility = async () => {
    const current = normalizeCurrentAdmission(await resolveCurrentFeasibility())
    if (!current) throw new Error('JY200_DUO_PROBATIONARY_EVIDENCE_STALE')
    return current
  }

  return Object.freeze({
    /** @param {Record<string, any>} input */
    async exportDraft(input) {
      const jobId = typeof input?.jobId === 'string' ? input.jobId : null
      const timelineFingerprint = input?.richTimeline?.revisionFingerprint
      if (!jobId || typeof timelineFingerprint !== 'string') throw new Error('JY200_DUO_PROBATIONARY_INPUT_INVALID')
      const current = await readFeasibility()
      const identity = /** @type {Record<string, any>} */ (current.identity)
      const requiredCapabilities = Array.isArray(input.richTimeline?.capabilityRequirements)
        ? input.richTimeline.capabilityRequirements
          .filter((/** @type {Record<string, any>} */ entry) => entry?.acceptance === 'implemented')
          .map((/** @type {Record<string, any>} */ entry) => entry.capabilityId)
          .sort()
        : []
      const ownerId = DUO_PROVIDER_ID
      const claimed = await ownerRepository.claim(Object.freeze({
        jobId,
        requestId: jobId,
        ownerId,
        providerCommit: identity.provider_commit,
        buildDigest: identity.build_digest,
        adapterRevision: identity.adapter_revision,
        evidenceFingerprint: identity.evidence_fingerprint,
        timelineFingerprint,
      }))
      if (!claimed) throw new Error('JY200_DUO_PROBATIONARY_OWNER_CLAIM_FAILED')
      const lease = await leaseManager.create({ providerId: DUO_PROVIDER_ID })
      let published = false
      try {
        const providerResult = await adapter.run(/** @type {any} */ (Object.freeze({
          ...input,
          provider_id: DUO_PROVIDER_ID,
          provider_commit: identity.provider_commit,
          timeline_fingerprint: timelineFingerprint,
          required_capabilities: requiredCapabilities,
        })), lease)
        const stagingRoot = await leaseManager.seal(lease)
        const readbackReceipt = await adapter.readback(Object.freeze({
          stagingRoot,
          providerResult,
          timelineFingerprint,
          providerId: DUO_PROVIDER_ID,
          providerCommit: identity.provider_commit,
          requiredCapabilities,
        }))
        const latest = await readFeasibility()
        if (JSON.stringify(latest.identity) !== JSON.stringify(current.identity)) {
          throw new Error('JY200_DUO_PROBATIONARY_EVIDENCE_STALE')
        }
        const publication = await publicationAuthority.publish(Object.freeze({
          jobId,
          stagingRoot: await leaseManager.resolve(lease),
          providerResult,
          readbackReceipt,
          timelineFingerprint,
          providerId: DUO_PROVIDER_ID,
          providerCommit: identity.provider_commit,
        }))
        published = true
        await leaseManager.release(lease)
        if (await publicationAuthority.commit({ jobId }) !== true ||
            await ownerRepository.complete({ jobId, ownerId: DUO_PROVIDER_ID, action: 'commit' }) !== true) {
          throw new Error('JY200_DUO_PROBATIONARY_COMMIT_FAILED')
        }
        return Object.freeze({
          probationary: true,
          admission: 'deferred',
          writer_eligible: false,
          ...adapter.projectWorkbenchResult({ readback_receipt: readbackReceipt }),
          published: publication.published === true,
          atomic: publication.atomic === true,
          committed: true,
        })
      } catch (error) {
        if (published) await publicationAuthority.rollback({ jobId }).catch(() => false)
        else await publicationAuthority.rollback({ jobId }).catch(() => false)
        await leaseManager.release(lease).catch(() => false)
        await ownerRepository.complete({ jobId, ownerId, action: 'cleanup' }).catch(() => false)
        throw error
      }
    },
    /** @param {{jobId?: unknown}} input */
    async commitDraft({ jobId }) {
      if (typeof jobId !== 'string' || await publicationAuthority.commit({ jobId }) !== true) return false
      return ownerRepository.complete({ jobId, ownerId: DUO_PROVIDER_ID, action: 'commit' })
    },
    /** @param {{jobId?: unknown}} input */
    async cleanupDraft({ jobId }) {
      if (typeof jobId !== 'string' || await publicationAuthority.rollback({ jobId }) !== true) return false
      return ownerRepository.complete({ jobId, ownerId: DUO_PROVIDER_ID, action: 'cleanup' })
    },
  })
}
