import { rename, rm, writeFile } from 'node:fs/promises'

/**
 * Publish evidence before its admitted catalog so an interruption can always
 * be retried from the original catalog. Canonical files are only replaced by
 * same-directory atomic renames; direct writes never touch them.
 * @param {{catalogPath: string, evidencePath: string, pendingPath: string, catalog: unknown, evidence: unknown}} input
 * @param {{write?: typeof writeFile, rename?: typeof rename, remove?: typeof rm}} [operations]
 */
export const publishJianyingBatchTextEvidence = async (input, operations = {}) => {
  const write = operations.write ?? writeFile
  const renameFile = operations.rename ?? rename
  const remove = operations.remove ?? rm
  const stagedCatalogPath = `${input.catalogPath}.pending`
  const stagedEvidencePath = `${input.evidencePath}.pending`

  await write(stagedCatalogPath, `${JSON.stringify(input.catalog)}\n`, { encoding: 'utf8', mode: 0o600 })
  await write(stagedEvidencePath, `${JSON.stringify(input.evidence)}\n`, { encoding: 'utf8', mode: 0o600 })
  await renameFile(stagedEvidencePath, input.evidencePath)
  await renameFile(stagedCatalogPath, input.catalogPath)
  await remove(input.pendingPath, { force: true })
}
