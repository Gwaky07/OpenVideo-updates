import { validSearchCandidate } from './material-analysis-contracts.mjs'
import { containsPrivateReference } from './editor-agent-contracts.mjs'
import { secondsToMicroseconds } from './rich-timeline-contracts.mjs'

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const opaqueId = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {unknown} value @param {number} maximum */
const safeQuery = (value, maximum) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maximum &&
  !value.includes('\u0000') &&
  !value.includes('\\') &&
  !value.includes('/') &&
  !/^(?:[a-z]:|file:|https?:)/iu.test(value)

export class EditorMaterialToolsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'EditorMaterialToolsError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  throw new EditorMaterialToolsError(code, status)
}

/** @param {unknown} value */
const assertPublicToolPayload = (value) => {
  if (containsPrivateReference(value)) {
    fail('EDITOR_MATERIAL_PROVIDER_RESPONSE_INVALID', 502)
  }
}

/** @param {unknown} error */
const errorCode = (error) =>
  isRecord(error) && typeof error.code === 'string' ? error.code : ''

/** @param {unknown} error */
const isMissingCandidateError = (error) => {
  const code = errorCode(error)
  return code === 'MATERIAL_ANALYSIS_CANDIDATE_NOT_FOUND' ||
    code === 'EDITOR_MATERIAL_CANDIDATE_NOT_FOUND' ||
    code === 'MATERIAL_ANALYSIS_AUTHORIZATION_INVALID' ||
    code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED'
}

/**
 * @param {{
 *   projectRepository: {get: Function},
 *   materialAnalysisProvider: {
 *     searchCandidates: Function,
 *     inspectCandidate: Function,
 *   },
 *   listSearchScopes?: ((projectId: string) => Promise<Array<{projectId: string, authorizationId: string}>> | Array<{projectId: string, authorizationId: string}>) | null,
 *   resolveInspectScope?: ((projectId: string, candidateId: string) => Promise<{projectId: string, authorizationId: string} | null>) | null,
 * }} options
 */
export const createEditorMaterialTools = (options) => {
  if (
    !options?.projectRepository ||
    typeof options.projectRepository.get !== 'function' ||
    !options.materialAnalysisProvider ||
    typeof options.materialAnalysisProvider.searchCandidates !== 'function' ||
    typeof options.materialAnalysisProvider.inspectCandidate !== 'function'
  ) {
    fail('EDITOR_MATERIAL_TOOLS_DEPENDENCY_MISSING', 500)
  }
  const listSearchScopes = typeof options.listSearchScopes === 'function'
    ? options.listSearchScopes
    : null
  const resolveInspectScope = typeof options.resolveInspectScope === 'function'
    ? options.resolveInspectScope
    : null

  /** @param {unknown} materials */
  const hasUsableEditorMaterials = (materials) => {
    if (!isRecord(materials)) return false
    if (
      materials.authorized === true &&
      materials.analysisStatus === 'ready' &&
      opaqueId(materials.authorizationId)
    ) return true
    return Number.isSafeInteger(materials.referencedAssetCount) &&
      Number(materials.referencedAssetCount) > 0
  }

  /** @param {string} projectId */
  const requireAuthorizedProject = async (projectId) => {
    if (!opaqueId(projectId)) fail('EDITOR_MATERIAL_PROJECT_SCOPE_INVALID', 400)
    const project = await options.projectRepository.get(projectId)
    if (
      !isRecord(project) ||
      project.id !== projectId ||
      !hasUsableEditorMaterials(project.materials)
    ) {
      fail('EDITOR_MATERIAL_PROJECT_SCOPE_INVALID', 409)
    }
    return project
  }

  /**
   * Storyboard already searches later library imports under their own
   * authorization. Editor tools must use the same scopes; the current project
   * folder is never treated as global access.
   * @param {Record<string, any>} project
   */
  const collectSearchScopes = async (project) => {
    /** @type {Array<{projectId: string, authorizationId: string}>} */
    const scopes = []
    if (opaqueId(project.materials.authorizationId)) {
      scopes.push({
        projectId: project.id,
        authorizationId: project.materials.authorizationId,
      })
    }
    if (!listSearchScopes) {
      if (scopes.length === 0) fail('EDITOR_MATERIAL_PROJECT_SCOPE_INVALID', 409)
      return scopes
    }
    try {
      const extra = await listSearchScopes(project.id)
      if (Array.isArray(extra)) {
        for (const scope of extra.slice(0, 12)) {
          if (!opaqueId(scope?.projectId) || !opaqueId(scope?.authorizationId)) continue
          if (scopes.some((existing) =>
            existing.projectId === scope.projectId &&
            existing.authorizationId === scope.authorizationId)) continue
          scopes.push({
            projectId: scope.projectId,
            authorizationId: scope.authorizationId,
          })
        }
      }
    } catch {
      // Optional library scopes must not block the project's own search.
    }
    if (scopes.length === 0) fail('EDITOR_MATERIAL_PROJECT_SCOPE_INVALID', 409)
    return scopes
  }

  /**
   * @param {{
   *   projectId: string,
   *   query: string,
   *   desiredDurationUs: number,
   *   limit: number,
   *   signal?: AbortSignal,
   * }} input
   */
  const searchMaterials = async (input) => {
    if (!isRecord(input)) fail('EDITOR_MATERIAL_INPUT_INVALID', 400)
    const project = await requireAuthorizedProject(input.projectId)
    // Align with analyzer safeText(query, 1000); longer queries are rejected at the tool boundary.
    if (!safeQuery(input.query, 1_000)) fail('EDITOR_MATERIAL_QUERY_INVALID', 400)
    if (
      !Number.isSafeInteger(input.desiredDurationUs) ||
      input.desiredDurationUs < 1
    ) {
      fail('EDITOR_MATERIAL_DURATION_INVALID', 400)
    }
    if (!Number.isSafeInteger(input.limit) || input.limit < 1 || input.limit > 10) {
      fail('EDITOR_MATERIAL_LIMIT_INVALID', 400)
    }

    const scopes = await collectSearchScopes(project)
    /** @type {Array<{candidate: Record<string, any>, rank: number, authorizationId: string}>} */
    const scoped = []
    /** @type {unknown} */
    let primarySearchError = null
    for (const [scopeIndex, scope] of scopes.entries()) {
      let candidates
      try {
        candidates = await options.materialAnalysisProvider.searchCandidates({
          authorizationId: scope.authorizationId,
          projectId: scope.projectId,
          query: input.query.trim(),
          limit: input.limit,
          // Agent search may continue with lexical/evidence ranking when the
          // optional local embedding model is unavailable; such candidates stay
          // explicitly review-required when no strong evidence exists.
          allowSemanticFallback: true,
          signal: input.signal,
        })
      } catch (error) {
        if (error instanceof EditorMaterialToolsError) throw error
        if (scopeIndex === 0 && !primarySearchError) primarySearchError = error
        continue
      }
      if (!Array.isArray(candidates) || candidates.some((entry) => !validSearchCandidate(entry))) {
        if (scopeIndex === 0) fail('EDITOR_MATERIAL_PROVIDER_RESPONSE_INVALID', 502)
        continue
      }
      for (const [rank, candidate] of candidates.entries()) {
        scoped.push({
          candidate,
          rank,
          authorizationId: scope.authorizationId,
        })
      }
    }
    if (scoped.length === 0 && primarySearchError) {
      const code = errorCode(primarySearchError) || 'EDITOR_MATERIAL_SEARCH_FAILED'
      if (code === 'MATERIAL_ANALYSIS_QUERY_INVALID') {
        fail('EDITOR_MATERIAL_QUERY_INVALID', 400)
      }
      fail(code.startsWith('EDITOR_') ? code : 'EDITOR_MATERIAL_SEARCH_FAILED', 502)
    }

    const merged = new Map()
    for (const entry of scoped) {
      const existing = merged.get(entry.candidate.id)
      if (
        !existing ||
        entry.rank < existing.rank ||
        (entry.rank === existing.rank && entry.candidate.matchScore > existing.candidate.matchScore)
      ) {
        merged.set(entry.candidate.id, entry)
      }
    }

    let ranked
    try {
      ranked = [...merged.values()]
        .map((entry) => {
          const startUs = secondsToMicroseconds(entry.candidate.start)
          const endUs = secondsToMicroseconds(entry.candidate.end)
          const durationUs = endUs - startUs
          if (startUs < 0 || durationUs < 1) {
            fail('EDITOR_MATERIAL_PROVIDER_RESPONSE_INVALID', 502)
          }
          return {
            ...entry,
            startUs,
            durationUs,
            durationFit: durationUs >= input.desiredDurationUs ? 1 : 0,
          }
        })
        .filter((entry) => entry.durationUs > 0)
        .sort((left, right) =>
          right.durationFit - left.durationFit ||
          right.candidate.matchScore - left.candidate.matchScore ||
          left.candidate.id.localeCompare(right.candidate.id))
        .slice(0, input.limit)
    } catch (error) {
      if (error instanceof EditorMaterialToolsError) throw error
      fail('EDITOR_MATERIAL_PROVIDER_RESPONSE_INVALID', 502)
    }

    const result = {
      candidates: ranked.map(({ candidate, startUs, durationUs, authorizationId }) => ({
        candidateId: candidate.id,
        assetId: candidate.assetId,
        sceneId: candidate.id,
        authorizationId,
        label: candidate.assetLabel,
        availableSourceRange: { startUs, durationUs },
        summary: candidate.summary,
        matchScore: candidate.matchScore,
      })),
    }
    assertPublicToolPayload(result)
    return result
  }

  /**
   * @param {Record<string, any>} inspected
   * @param {string} candidateId
   * @param {string} authorizationId
   */
  const publicInspectResult = (inspected, candidateId, authorizationId) => {
    if (
      !isRecord(inspected) ||
      inspected.candidateId !== candidateId ||
      typeof inspected.visualSummary !== 'string' ||
      typeof inspected.transcriptExcerpt !== 'string' ||
      !isRecord(inspected.availableSourceRange) ||
      !Number.isSafeInteger(inspected.availableSourceRange.startUs) ||
      inspected.availableSourceRange.startUs < 0 ||
      !Number.isSafeInteger(inspected.availableSourceRange.durationUs) ||
      inspected.availableSourceRange.durationUs < 1 ||
      !Array.isArray(inspected.shotAttributes) ||
      inspected.shotAttributes.some((entry) => !opaqueId(entry))
    ) {
      fail('EDITOR_MATERIAL_PROVIDER_RESPONSE_INVALID', 502)
    }
    const result = {
      candidateId: inspected.candidateId,
      authorizationId,
      visualSummary: inspected.visualSummary,
      transcriptExcerpt: inspected.transcriptExcerpt,
      availableSourceRange: {
        startUs: inspected.availableSourceRange.startUs,
        durationUs: inspected.availableSourceRange.durationUs,
      },
      shotAttributes: [...inspected.shotAttributes],
    }
    assertPublicToolPayload(result)
    return clone(result)
  }

  /**
   * @param {{
   *   projectId: string,
   *   candidateId: string,
   *   signal?: AbortSignal,
   * }} input
   */
  const inspectCandidate = async (input) => {
    if (!isRecord(input)) fail('EDITOR_MATERIAL_INPUT_INVALID', 400)
    const project = await requireAuthorizedProject(input.projectId)
    if (!opaqueId(input.candidateId)) fail('EDITOR_MATERIAL_CANDIDATE_INVALID', 400)

    /** @type {Array<{projectId: string, authorizationId: string}>} */
    const scopes = []
    const seen = new Set()
    /** @param {unknown} scope */
    const addScope = (scope) => {
      if (!isRecord(scope) || !opaqueId(scope.projectId) || !opaqueId(scope.authorizationId)) return
      const projectId = /** @type {string} */ (scope.projectId)
      const authorizationId = /** @type {string} */ (scope.authorizationId)
      const key = `${projectId}\u0000${authorizationId}`
      if (seen.has(key)) return
      seen.add(key)
      scopes.push({ projectId, authorizationId })
    }
    if (resolveInspectScope) {
      try {
        addScope(await resolveInspectScope(project.id, input.candidateId))
      } catch {
        // Binding is only a hint; remaining scopes still revalidate.
      }
    }
    for (const scope of await collectSearchScopes(project)) addScope(scope)

    /** @type {unknown} */
    let lastError = null
    for (const scope of scopes) {
      try {
        const inspected = await options.materialAnalysisProvider.inspectCandidate({
          authorizationId: scope.authorizationId,
          projectId: scope.projectId,
          candidateId: input.candidateId,
          signal: input.signal,
        })
        return publicInspectResult(inspected, input.candidateId, scope.authorizationId)
      } catch (error) {
        if (error instanceof EditorMaterialToolsError) throw error
        lastError = error
        if (isMissingCandidateError(error)) continue
        fail('EDITOR_MATERIAL_INSPECT_FAILED', 502)
      }
    }
    if (lastError instanceof EditorMaterialToolsError) throw lastError
    const code = errorCode(lastError)
    if (
      code === 'MATERIAL_ANALYSIS_CANDIDATE_NOT_FOUND' ||
      code === 'EDITOR_MATERIAL_CANDIDATE_NOT_FOUND'
    ) {
      fail('EDITOR_MATERIAL_CANDIDATE_NOT_FOUND', 404)
    }
    fail('EDITOR_MATERIAL_CANDIDATE_NOT_FOUND', 404)
  }

  return {
    searchMaterials,
    inspectCandidate,
  }
}
