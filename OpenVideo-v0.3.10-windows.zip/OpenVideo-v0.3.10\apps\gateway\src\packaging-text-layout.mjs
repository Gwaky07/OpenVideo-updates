import { createJianyingPackagingResolver } from './jianying-packaging-resolver.mjs'

const canvasByOrientation = Object.freeze({
  portrait: Object.freeze({ width: 1080, height: 1920 }),
  landscape: Object.freeze({ width: 1920, height: 1080 }),
  square: Object.freeze({ width: 1080, height: 1080 }),
})

const titleSafeAreaByOrientation = Object.freeze({
  portrait: Object.freeze({ left: 0.08, top: 0.07, right: 0.92, bottom: 0.70 }),
  landscape: Object.freeze({ left: 0.06, top: 0.08, right: 0.94, bottom: 0.76 }),
  square: Object.freeze({ left: 0.08, top: 0.08, right: 0.92, bottom: 0.76 }),
})

const layoutKeys = Object.freeze([
  'schemaVersion',
  'strategy',
  'safeArea',
  'bounds',
  'fontScale',
  'transformX',
  'transformY',
  'maxLineWidth',
  'lineCount',
])
const rectKeys = Object.freeze(['left', 'top', 'right', 'bottom'])
const styleResolver = createJianyingPackagingResolver()
const maxEmphasisCharacters = 36
// Jianying's text size is a compact, percentage-like value. A decorative
// flower/bubble using the ordinary rich-emphasis size (9) is only marginally
// larger than a caption in the real editor. Keep a separate visual budget for
// decorated text; the solver may still scale it down for long copy.
// Calibrated against a real portrait Jianying draft: 12 is visible but reads
// as a caption-sized treatment. Keep decorative emphasis visibly distinct
// while leaving the solver room to wrap or scale long copy inside its bounds.
export const DECORATED_TEXT_MINIMUM_SIZE = 16

export class PackagingTextLayoutError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'PackagingTextLayoutError'
    this.code = code
  }
}

/** @param {number} value @param {number} [places] */
const rounded = (value, places = 6) => Number(value.toFixed(places))

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Derive concise display copy for an automatically generated flower/bubble.
 * This never mutates the source caption or narration; it only creates the
 * separate emphasis overlay that will be laid out below.
 * @param {unknown} value
 * @param {string} fallback
 */
export const derivePackagingEmphasisText = (value, fallback) => {
  const normalizedFallback = typeof fallback === 'string' && fallback.trim()
    ? fallback.trim()
    : '重点'
  if (typeof value !== 'string' || !value.trim()) return normalizedFallback
  const normalized = value.replace(/\s+/gu, ' ').trim()
  const firstClause = normalized.split(/[。！？!?；;\n]/u).find((part) => part.trim())?.trim() ?? normalized
  const characters = Array.from(firstClause)
  if (characters.length <= maxEmphasisCharacters) return firstClause
  const bounded = characters.slice(0, maxEmphasisCharacters)
  const lastSpace = bounded.lastIndexOf(' ')
  if (lastSpace >= Math.floor(maxEmphasisCharacters / 2)) bounded.splice(lastSpace)
  return bounded.join('').trim() || normalizedFallback
}

/** @param {unknown} orientation */
export const packagingCanvasForOrientation = (orientation) => {
  const canvas = canvasByOrientation[/** @type {keyof typeof canvasByOrientation} */ (orientation)]
  if (!canvas) throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_ORIENTATION_INVALID')
  return canvas
}

/** @param {unknown} value */
const finiteUnit = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1

/** @param {unknown} value */
const isRect = (value) => isRecord(value) &&
  Object.keys(value).sort().join('|') === [...rectKeys].sort().join('|') &&
  rectKeys.every((key) => finiteUnit(value[key])) &&
  value.left < value.right && value.top < value.bottom

/** Strictly validate canonical text geometry before either target consumes it. @param {unknown} value */
export const assertPackagingTextLayout = (value) => {
  if (!isRecord(value) || Object.keys(value).sort().join('|') !== [...layoutKeys].sort().join('|')) {
    throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_INVALID')
  }
  if (
    value.schemaVersion !== 1 || value.strategy !== 'safe_area_v1' ||
    !isRect(value.safeArea) || !isRect(value.bounds) ||
    typeof value.fontScale !== 'number' || !Number.isFinite(value.fontScale) || value.fontScale < 0.45 || value.fontScale > 1 ||
    typeof value.transformX !== 'number' || !Number.isFinite(value.transformX) || value.transformX < -1 || value.transformX > 1 ||
    typeof value.transformY !== 'number' || !Number.isFinite(value.transformY) || value.transformY < -1 || value.transformY > 1 ||
    typeof value.maxLineWidth !== 'number' || !Number.isFinite(value.maxLineWidth) || value.maxLineWidth <= 0 || value.maxLineWidth > 1 ||
    !Number.isSafeInteger(value.lineCount) || value.lineCount < 1 || value.lineCount > 3 ||
    value.bounds.left < value.safeArea.left || value.bounds.right > value.safeArea.right ||
    value.bounds.top < value.safeArea.top || value.bounds.bottom > value.safeArea.bottom
  ) {
    throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_INVALID')
  }
  return value
}

/** Conservative glyph width in em. @param {string} character */
const glyphWidth = (character) => {
  if (/\s/u.test(character)) return 0.34
  if (/^[\u0000-\u007f]$/u.test(character)) {
    if (/[ilI1.,'`:;|!]/u.test(character)) return 0.32
    if (/[MW@#%&]/u.test(character)) return 0.92
    return 0.62
  }
  return 1
}

/** @param {string} text */
const textWidth = (text) => Array.from(text).reduce((sum, character) => sum + glyphWidth(character), 0)

/**
 * Move a bounded suffix into a sparse final line. This preserves the exact
 * copy while avoiding a visually weak one-character Chinese emphasis line.
 * @param {string[]} lines
 * @param {number} maxWidthEm
 */
const balanceFinalLine = (lines, maxWidthEm) => {
  if (lines.length < 2) return lines
  const balanced = [...lines]
  let previous = balanced.at(-2) ?? ''
  let last = balanced.at(-1) ?? ''
  while (
    Array.from(previous).length > 1 &&
    textWidth(last) < textWidth(previous) &&
    textWidth(last) < maxWidthEm * 0.5
  ) {
    const characters = Array.from(previous)
    const moved = characters.pop()
    if (!moved || textWidth(moved + last) > maxWidthEm) break
    previous = characters.join('').trimEnd()
    last = `${moved}${last}`.trimStart()
  }
  balanced.splice(-2, 2, previous, last)
  return balanced
}

/**
 * Wrap without deleting or rewriting user/model text. Explicit newlines are preserved.
 * @param {string} text
 * @param {number} maxWidthEm
 * @param {number} maxLines
 */
const wrapText = (text, maxWidthEm, maxLines) => {
  const lines = []
  for (const paragraph of text.replace(/\r\n?/gu, '\n').split('\n')) {
    if (paragraph.length === 0) {
      lines.push('')
      continue
    }
    let line = ''
    let width = 0
    for (const character of Array.from(paragraph)) {
      const nextWidth = glyphWidth(character)
      if (line && width + nextWidth > maxWidthEm) {
        lines.push(line.trimEnd())
        line = character.trimStart()
        width = line ? nextWidth : 0
      } else {
        line += character
        width += nextWidth
      }
    }
    if (line) lines.push(line.trimEnd())
    const paragraphStart = lines.lastIndexOf('', lines.length - 2) + 1
    const paragraphLines = balanceFinalLine(lines.slice(paragraphStart), maxWidthEm)
    lines.splice(paragraphStart, lines.length - paragraphStart, ...paragraphLines)
  }
  return lines.length > maxLines ? null : lines
}

/** @param {Record<string, any>} left @param {Record<string, any>} right */
const overlaps = (left, right) =>
  left.left < right.right && left.right > right.left && left.top < right.bottom && left.bottom > right.top

/** @param {Record<string, any>} left @param {Record<string, any>} right */
const rangesOverlap = (left, right) =>
  left.targetRange.startUs < right.targetRange.startUs + right.targetRange.durationUs &&
  right.targetRange.startUs < left.targetRange.startUs + left.targetRange.durationUs

/** @param {Record<string, any>} segment @param {number} baseSize @param {{width:number,height:number}} canvas @param {Record<string, number>} safeArea */
const fitSegment = (segment, baseSize, canvas, safeArea) => {
  const decorated = segment.capabilityId === 'text.flower.private' || segment.capabilityId === 'text.bubble.private'
  // The old 1.32x decorative expansion plus one-em side padding was visibly
  // much larger than the real Jianying flower frame. Keep the effect budget
  // conservative, but calibrate it so normal six-character emphasis remains
  // a real primary treatment instead of shrinking into a caption.
  const expansion = decorated ? 1.15 : segment.kind === 'title' ? 1.14 : 1.12
  const maxWidthPx = (safeArea.right - safeArea.left) * canvas.width
  const maxHeightPx = Math.min((safeArea.bottom - safeArea.top) * canvas.height, canvas.height * 0.34)
  const maxLines = 3
  const peakKeyframeScale = Math.max(1, ...(segment.keyframes ?? []).map((/** @type {Record<string, any>} */ keyframe) =>
    typeof keyframe.value === 'number' && Number.isFinite(keyframe.value) ? keyframe.value : 1))
  // Decorative text is a primary visual treatment, not a tiny annotation.
  // Keep a readable lower bound while still allowing long copy to wrap.
  const preferredMinimumStep = decorated ? 60 : 45
  const steps = [
    ...Array.from({ length: Math.floor((100 - preferredMinimumStep) / 5) + 1 }, (_, index) => 100 - index * 5),
    ...(decorated ? [55, 50, 45] : []),
  ]
  for (const step of steps) {
    const fontScale = step / 100
    // Jianying's TextStyle size is percentage-like rather than a pixel point
    // size. This conservative conversion keeps the solver aligned with the
    // visibly readable Writer styles without overestimating every glyph box.
    // The writer's size unit is not a CSS pixel size. Keep the geometry
    // estimate conservative enough for a larger decorated budget to wrap
    // long copy into at most three lines; the actual writer still receives
    // the canonical size below.
    const fontPx = canvas.height * baseSize * 0.0035 * fontScale * peakKeyframeScale
    const horizontalPaddingPx = fontPx * (decorated ? 0.4 : 0.45)
    const verticalPaddingPx = fontPx * (decorated ? 0.40 : 0.40)
    const availableTextPx = (maxWidthPx - horizontalPaddingPx * 2) / expansion
    if (availableTextPx <= fontPx) continue
    const lines = wrapText(segment.text.trim(), availableTextPx / fontPx, maxLines)
    if (!lines) continue
    const measuredTextWidthPx = Math.max(...lines.map(textWidth)) * fontPx
    const widthPx = Math.min(maxWidthPx, measuredTextWidthPx * expansion + horizontalPaddingPx * 2)
    const heightPx = lines.length * fontPx * 1.24 + verticalPaddingPx * 2
    if (widthPx > maxWidthPx + 0.01 || heightPx > maxHeightPx + 0.01) continue
    return {
      text: lines.join('\n'),
      fontScale,
      widthFraction: widthPx / canvas.width,
      heightFraction: heightPx / canvas.height,
      maxLineWidth: availableTextPx / canvas.width,
      lineCount: lines.length,
    }
  }
  throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_UNFIT')
}

/**
 * Apply deterministic, target-neutral geometry to canonical title/rich-text segments.
 * @param {{orientation: 'portrait'|'landscape'|'square', segments: Array<Record<string, any>>}} input
 */
export const solvePackagingTextLayouts = ({ orientation, segments }) => {
  const canvas = packagingCanvasForOrientation(orientation)
  if (!Array.isArray(segments)) throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_SEGMENTS_INVALID')
  const safeArea = titleSafeAreaByOrientation[orientation]
  /** @type {Array<{segment: Record<string, any>, bounds: Record<string, number>}>} */
  const placed = []
  return segments.map((segment) => {
    if (!isRecord(segment) || typeof segment.text !== 'string' || !segment.text.trim() || !isRecord(segment.targetRange)) {
      throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_SEGMENT_INVALID')
    }
    let baseSize
    try {
      baseSize = styleResolver.resolveTextStyle(segment.styleToken, segment.kind === 'title' ? 'title_card' : 'rich_emphasis').style.size
      if (segment.capabilityId === 'text.flower.private' || segment.capabilityId === 'text.bubble.private') {
        baseSize = Math.max(baseSize, DECORATED_TEXT_MINIMUM_SIZE)
      }
    } catch {
      throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_STYLE_INVALID')
    }
    const fit = fitSegment(segment, baseSize, canvas, safeArea)
    const centerFractions = segment.kind === 'title'
      ? [0.42, 0.25, 0.59]
      // Keep a top/bottom pair available for simultaneous multi-line
      // decorations; the previous list could reject two valid blocks whose
      // combined heights fit the safe area.
      : [0.20, 0.52, 0.30, 0.48, 0.18, 0.60]
    let selected = null
    for (const centerY of centerFractions) {
      const top = centerY - fit.heightFraction / 2
      const bottom = centerY + fit.heightFraction / 2
      const bounds = {
        left: rounded(0.5 - fit.widthFraction / 2),
        top: rounded(top),
        right: rounded(0.5 + fit.widthFraction / 2),
        bottom: rounded(bottom),
      }
      if (
        bounds.left < safeArea.left || bounds.right > safeArea.right ||
        bounds.top < safeArea.top || bounds.bottom > safeArea.bottom ||
        placed.some((item) => rangesOverlap(item.segment, segment) && overlaps(item.bounds, bounds))
      ) continue
      selected = bounds
      break
    }
    if (!selected) throw new PackagingTextLayoutError('PACKAGING_TEXT_LAYOUT_COLLISION')
    const centerX = (selected.left + selected.right) / 2
    const centerY = (selected.top + selected.bottom) / 2
    const layout = assertPackagingTextLayout({
      schemaVersion: 1,
      strategy: 'safe_area_v1',
      safeArea: structuredClone(safeArea),
      bounds: selected,
      fontScale: rounded(fit.fontScale, 2),
      transformX: rounded(centerX * 2 - 1),
      transformY: rounded(1 - centerY * 2),
      maxLineWidth: rounded(fit.maxLineWidth),
      lineCount: fit.lineCount,
    })
    placed.push({ segment, bounds: selected })
    return { ...segment, text: fit.text, layout }
  })
}
