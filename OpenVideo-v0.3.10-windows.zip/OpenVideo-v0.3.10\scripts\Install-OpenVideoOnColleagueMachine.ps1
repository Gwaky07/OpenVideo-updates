[CmdletBinding()]
param(
    [string]$OpenVideoZip,
    [string]$InstallRoot,
    [int]$GatewayPort = 8787
)

# REL-017 / colleague first-install wizard.  This script is what a Windows
# colleague runs once after downloading the v0.3.10+ full ZIP.  It is also
# what we hand to internal testers as the canonical "smoke this before you
# give it to anyone" recipe.  Each step writes a single line to stdout so the
# curator can grep the output and the CLI summary stays terse.

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-Step {
    param([string]$Message)
    Write-Host $Message
}

if ([string]::IsNullOrWhiteSpace($OpenVideoZip)) {
    $OpenVideoZip = Join-Path $PSScriptRoot '..\release\OpenVideo-v0.3.10-windows.zip'
}
$resolvedZip = [IO.Path]::GetFullPath($OpenVideoZip)
if (-not (Test-Path -LiteralPath $resolvedZip -PathType Leaf)) {
    throw "OPENVIDEO_INSTALL_ZIP_MISSING: $resolvedZip"
}

if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
    $InstallRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo\program'
}
$resolvedInstallRoot = [IO.Path]::GetFullPath($InstallRoot)
if ($resolvedInstallRoot -notmatch '\\OpenVideo\\program$') {
    throw "OPENVIDEO_INSTALL_ROOT_FORBIDDEN: $resolvedInstallRoot (must end in OpenVideo\program)"
}

Write-Step "OPENVIDEO_INSTALL_BEGIN zip=$resolvedZip installRoot=$resolvedInstallRoot port=$GatewayPort"

# --- 1. Stage zip and verify SHA-256 against the public manifest -----------
$stage = Join-Path $env:TEMP ('openvideo-install-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage -Force | Out-Null
try {
    Write-Step "OPENVIDEO_INSTALL_STEP1: verifying SHA-256 against public manifest"
    $manifestUrl = 'https://raw.githubusercontent.com/Gwaky07/OpenVideo-updates/main/latest.json'
    $manifest = Invoke-RestMethod -Uri $manifestUrl -TimeoutSec 15
    if ($manifest.version -notlike 'v0.3.10*') {
        Write-Step "OPENVIDEO_INSTALL_VERSION_MISMATCH: expected v0.3.10+, got $($manifest.version)"
    }
    $expectedSha = [string]$manifest.package.sha256
    $actualSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $resolvedZip).Hash.ToLowerInvariant()
    if ($expectedSha -ne $actualSha) {
        throw "OPENVIDEO_INSTALL_SHA256_MISMATCH expected=$expectedSha actual=$actualSha"
    }
    Write-Step "OPENVIDEO_INSTALL_SHA256_OK sha256=$actualSha"

    # --- 2. Unzip to a sibling staging directory and swap into install root --
    Write-Step "OPENVIDEO_INSTALL_STEP2: extracting zip to staging"
    $nextRoot = "$resolvedInstallRoot.__next"
    $backupRoot = "$resolvedInstallRoot.__backup"
    Remove-Item -LiteralPath $nextRoot -Recurse -Force -ErrorAction SilentlyContinue
    Expand-Archive -LiteralPath $resolvedZip -DestinationPath $nextRoot -Force
    if (-not (Test-Path -LiteralPath (Join-Path $nextRoot 'OpenVideo.cmd'))) {
        throw 'OPENVIDEO_INSTALL_PAYLOAD_INVALID: OpenVideo.cmd missing after extract'
    }
    Write-Step "OPENVIDEO_INSTALL_EXTRACT_OK entries=$((Get-ChildItem -LiteralPath $nextRoot -Recurse -File).Count)"

    # --- 3. Atomic swap: program → backup, next → program -------------------
    Write-Step "OPENVIDEO_INSTALL_STEP3: atomically swapping program tree"
    if (Test-Path -LiteralPath $backupRoot) {
        Remove-Item -LiteralPath $backupRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path -LiteralPath $resolvedInstallRoot) {
        Move-Item -LiteralPath $resolvedInstallRoot -Destination $backupRoot -Force
    }
    Move-Item -LiteralPath $nextRoot -Destination $resolvedInstallRoot -Force

    # --- 4. Bootstrap-OpenVideo rebuilds node_modules + dependencies --------
    Write-Step "OPENVIDEO_INSTALL_STEP4: running Bootstrap-OpenVideo (pnpm install + setup)"
    $bootstrapScript = Join-Path $resolvedInstallRoot 'scripts\Bootstrap-OpenVideo.ps1'
    if (-not (Test-Path -LiteralPath $bootstrapScript -PathType Leaf)) {
        throw 'OPENVIDEO_INSTALL_BOOTSTRAP_MISSING'
    }
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $bootstrapScript -RepositoryRoot $resolvedInstallRoot
    if ($LASTEXITCODE -ne 0) { throw "OPENVIDEO_INSTALL_BOOTSTRAP_FAILED exit=$LASTEXITCODE" }
    Write-Step "OPENVIDEO_INSTALL_BOOTSTRAP_OK"

    # --- 5. Cold-start health check ----------------------------------------
    Write-Step "OPENVIDEO_INSTALL_STEP5: cold-start health check on port $GatewayPort"
    $startScript = Join-Path $resolvedInstallRoot 'scripts\Start-OpenVideo.ps1'
    $configPath = Join-Path $env:LOCALAPPDATA 'OpenVideo\config.json'
    $launcher = Start-Process -FilePath 'powershell.exe' -ArgumentList @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $startScript,
        '-RepositoryRoot', $resolvedInstallRoot,
        '-ConfigPath', $configPath,
        '-NoBrowser'
    ) -PassThru -WindowStyle Hidden
    $healthy = $false
    $deadline = [DateTime]::UtcNow.AddSeconds(180)
    while ([DateTime]::UtcNow -lt $deadline) {
        if ($launcher.HasExited -and $launcher.ExitCode -ne 0) { break }
        try {
            $probe = Invoke-RestMethod -Uri "http://127.0.0.1:$GatewayPort/api/live" -TimeoutSec 2
            if ($probe.live -eq $true) { $healthy = $true; break }
        } catch {}
        Start-Sleep -Seconds 2
    }
    if (-not $healthy) {
        Write-Step "OPENVIDEO_INSTALL_HEALTH_FAILED — restoring backup"
        if (Test-Path -LiteralPath $backupRoot) {
            Stop-Process -Id $launcher.Id -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
            Remove-Item -LiteralPath $resolvedInstallRoot -Recurse -Force -ErrorAction SilentlyContinue
            Move-Item -LiteralPath $backupRoot -Destination $resolvedInstallRoot -Force
        }
        throw 'OPENVIDEO_INSTALL_HEALTH_TIMEOUT'
    }
    Write-Step "OPENVIDEO_INSTALL_HEALTH_OK live=true port=$GatewayPort"

    # --- 6. Sidebar update smoke check --------------------------------------
    Write-Step "OPENVIDEO_INSTALL_STEP6: smoke check sidebar update channel"
    $token = $null
    if (Test-Path -LiteralPath $configPath -PathType Leaf) {
        try {
            $cfg = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
            $token = $cfg.local_api_token
        } catch {}
    }
    if (-not $token) {
        Write-Step "OPENVIDEO_INSTALL_SMOKE_SKIPPED: no local_api_token in $configPath"
    } else {
        $checkUrl = "http://127.0.0.1:$GatewayPort/api/product-update/check"
        $checkResp = Invoke-WebRequest -Uri $checkUrl -Method POST -UseBasicParsing -Headers @{
            'x-openvideo-local-token' = $token
            'Origin' = "http://127.0.0.1:$GatewayPort"
        } -TimeoutSec 30
        $checkBody = $checkResp.Content | ConvertFrom-Json
        Write-Step "OPENVIDEO_INSTALL_SMOKE_OK status=$($checkBody.status) latestVersion=$($checkBody.latestVersion) canApply=$($checkBody.canApply) scope=$($checkBody.scope)"
    }

    # --- Cleanup backup ----------------------------------------------------
    if (Test-Path -LiteralPath $backupRoot) {
        Remove-Item -LiteralPath $backupRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-Step "OPENVIDEO_INSTALL_COMPLETE"
}
finally {
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
}
