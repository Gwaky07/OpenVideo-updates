[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [switch]$SkipBuild,
    [switch]$InstallBrowsers
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)

if (-not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'package.json') -PathType Leaf)) {
    throw 'INVALID_OPENVIDEO_REPOSITORY_ROOT'
}

Write-Host 'Preparing OpenVideo developer prerequisites...' -ForegroundColor Cyan
$bootstrapPath = Join-Path $resolvedRoot 'scripts\Bootstrap-OpenVideo.ps1'
& $bootstrapPath -RepositoryRoot $resolvedRoot -PrerequisitesOnly
if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_DEVELOPER_PREREQUISITES_FAILED' }

Write-Host 'Installing pinned workspace dependencies with Corepack/pnpm...' -ForegroundColor Cyan
& corepack pnpm --dir $resolvedRoot install --frozen-lockfile
if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_DEVELOPER_PNPM_INSTALL_FAILED' }

Write-Host 'Installing governed upstream provider checkouts if missing...' -ForegroundColor Cyan
$upstreamInstallerPath = Join-Path $resolvedRoot 'scripts\Install-OpenVideoUpstreams.ps1'
& $upstreamInstallerPath -RepositoryRoot $resolvedRoot
if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_DEVELOPER_UPSTREAM_INSTALL_FAILED' }

if ($InstallBrowsers) {
    Write-Host 'Installing Chromium for Playwright e2e tests...' -ForegroundColor Cyan
    & corepack pnpm --dir $resolvedRoot --filter '@openvideo/web' exec playwright install chromium
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_DEVELOPER_PLAYWRIGHT_INSTALL_FAILED' }
}

if (-not $SkipBuild) {
    Write-Host 'Building OpenVideo to verify the developer checkout...' -ForegroundColor Cyan
    & corepack pnpm --dir $resolvedRoot build
    if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_DEVELOPER_BUILD_FAILED' }
}

Write-Host 'OPENVIDEO_DEVELOPER_READY' -ForegroundColor Green
Write-Host 'Next commands:' -ForegroundColor Green
Write-Host '  pnpm dev                 # Web-only Vite development'
Write-Host '  pnpm start:local         # Full local Gateway-hosted workbench'
Write-Host '  pnpm test                # Gateway + Web tests'
Write-Host '  pnpm test:e2e            # Browser e2e tests; rerun setup with -InstallBrowsers if needed'
