import path from 'node:path'

import { JianyingDraftAdapterError } from './jianying-draft-adapter.mjs'
import { createJianyingDraftRuntime } from './jianying-draft-runtime.mjs'

const unavailableWriter = Object.freeze({
  async writeDraft() {
    throw new JianyingDraftAdapterError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  },
  async verifyDraft() {
    return false
  },
  async cleanupDraft() {},
})

/** @param {NodeJS.ProcessEnv} [environment] */
export const createConfiguredJianyingDraftRuntime = (environment = process.env) => {
  const draftRoot = environment.OPENVIDEO_JIANYING_DRAFT_ROOT?.trim()
  const pythonModuleRoot = environment.OPENVIDEO_JY002_PYTHON_MODULE_ROOT?.trim()
  const pythonExecutable = environment.OPENVIDEO_JY002_PYTHON_EXECUTABLE?.trim() || 'python'
  if (!draftRoot && !pythonModuleRoot) {
    return createJianyingDraftRuntime({ writer: unavailableWriter })
  }
  if (!draftRoot || !pythonModuleRoot || !path.isAbsolute(draftRoot) || !path.isAbsolute(pythonModuleRoot)) {
    throw new JianyingDraftAdapterError('JY002_PATH_PERMISSION_DENIED')
  }
  return createJianyingDraftRuntime({ draftRoot, pythonModuleRoot, pythonExecutable })
}

export const jianyingDraftRuntime = createConfiguredJianyingDraftRuntime()

/**
 * Process-local registration boundary for the trusted folder-authorizer/runtime.
 * HTTP commands continue to carry only the opaque request id.
 * @param {unknown} registration
 */
export const registerJianyingDraftRequest = (registration) => jianyingDraftRuntime.register(registration)
