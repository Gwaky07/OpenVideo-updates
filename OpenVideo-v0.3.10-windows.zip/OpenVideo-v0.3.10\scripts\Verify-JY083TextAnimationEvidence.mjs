import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rename, rm, rmdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { parseJianyingTextAnimationCatalog } from '../apps/gateway/src/jianying-text-animation-catalog.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY083_MANUAL_ATTESTATION_REQUIRED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const root = path.join(dataRoot, 'evidence', 'jy083-text-animation')
  const pendingPath = path.join(root, 'pending.json')
  const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  const requiredPendingKeys = ['schema_version', 'draft_id', 'draft_root', 'media_root', 'media_owner', 'profile_id', 'app_version', 'catalog_fingerprint', 'resource_id', 'pre_open_fingerprint']
  if (Object.keys(pending).sort().join('\0') !== requiredPendingKeys.sort().join('\0') || pending.schema_version !== 1 || pending.profile_id !== 'jianying-11-1-provisional' || pending.app_version !== '11.1.0.14287' || !/^[a-f0-9]{64}$/u.test(pending.pre_open_fingerprint)) throw new Error('JY083_EVIDENCE_BINDING_INVALID')
  const { profile_id: profileId, draft_root: draftRoot, draft_id: draftId, media_root: mediaRoot, catalog_fingerprint: catalogFingerprint } = pending
  if (desktop?.profileId !== profileId || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(draftRoot)) throw new Error('JY083_EVIDENCE_BINDING_INVALID')
  const catalog = parseJianyingTextAnimationCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy083-text-animation-catalog.json'), 'utf8')))
  if (!catalog || catalog.fingerprint !== catalogFingerprint) throw new Error('JY083_CATALOG_BINDING_INVALID')
  const canonicalTemp = await realpath(tmpdir()); const canonicalMedia = await realpath(mediaRoot); const relative = path.relative(canonicalTemp, canonicalMedia); const metadata = await lstat(mediaRoot)
  const ownerPath = path.join(mediaRoot, '.openvideo-jy083-owner')
  const owner = await readFile(ownerPath, 'utf8')
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative) || !path.basename(canonicalMedia).startsWith('openvideo-jy083-text-animation-') || !metadata.isDirectory() || metadata.isSymbolicLink() || owner !== pending.media_owner) throw new Error('JY083_TEMP_OWNERSHIP_INVALID')
  const encryptedPath = path.join(desktop.draftRoot, draftId, 'draft_content.json'); const encrypted = await readFile(encryptedPath); const postSaveFingerprint = createHash('sha256').update(encrypted).digest('hex')
  if (postSaveFingerprint === pending.pre_open_fingerprint) throw new Error('JY083_MANUAL_EDIT_NOT_PERSISTED')
  const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy083-verify-'))
  try {
    const plain = path.join(tempRoot, 'draft_content.json'); const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(encryptedPath, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY083_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8')); const animations = content?.materials?.material_animations ?? []; const titles = content?.tracks?.filter((track) => track?.name === 'title-primary').flatMap((track) => track.segments ?? []) ?? []
    const matching = animations.filter((material) => Array.isArray(material?.animations) && material.animations.some((animation) => catalog.entries.some((entry) => String(entry.resourceId) === String(animation?.resource_id)) && animation?.duration === 1_000_000 && ['in', 'out', 'loop'].includes(animation?.type)))
    const matchingIds = new Set(matching.map((material) => material.id)); const attached = titles.filter((segment) => (segment?.extra_material_refs ?? []).filter((reference) => matchingIds.has(reference)).length === 1)
    if (animations.length !== 1 || matching.length !== 1 || attached.length !== 1) {
      const error = new Error('JY083_TEXT_ANIMATION_PERSISTENCE_INVALID')
      error.diagnostic = {
        materialAnimationCount: animations.length,
        matchingAnimationCount: matching.length,
        attachedTitleCount: attached.length,
        animationShapes: animations.flatMap((material) => (material?.animations ?? []).map((animation) => ({ hasResourceId: typeof animation?.resource_id === 'string', duration: animation?.duration ?? null, type: animation?.type ?? null }))),
        titleReferenceCounts: titles.map((segment) => Array.isArray(segment?.extra_material_refs) ? segment.extra_material_refs.length : 0),
        resourceMatchesCatalog: animations.some((material) => (material?.animations ?? []).some((animation) => catalog.entries.some((entry) => String(entry.resourceId) === String(animation?.resource_id)))),
        materialIsReferenced: animations.some((material) => titles.some((segment) => (segment?.extra_material_refs ?? []).includes(material?.id))),
      }
      throw error
    }
    const record = { schema_version: 1, manual_evidence_verified: true, manual_attestation: 'opened-edited-saved-reopened', profile_id: profileId, app_version: desktop.version, catalog_fingerprint: catalog.fingerprint, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, matching_animation_count: 1, attached: true, temporary_media_cleaned: true }
    await securePrivateRuntimeRoot(root); const staged = path.join(root, 'post-save.pending.json'); await writeFile(staged, `${JSON.stringify(record)}\n`, { encoding: 'utf8', mode: 0o600 })
    await rm(path.join(mediaRoot, 'video.mp4'), { force: true }); await rm(path.join(mediaRoot, 'voice.wav'), { force: true }); await rm(ownerPath, { force: true }); await rmdir(mediaRoot)
    await rename(staged, path.join(root, 'post-save.json')); await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, capability: 'animation.text.named', scheme: 'encrypt_v2', matchingAnimationCount: 1, attached: true, temporaryMediaCleaned: true, contentChanged: true })}\n`)
  } finally { await rm(tempRoot, { recursive: true, force: true }) }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY083_VERIFY_FAILED', ...(error?.diagnostic ? { diagnostic: error.diagnostic } : {}) })}\n`); process.exitCode = 1 })
