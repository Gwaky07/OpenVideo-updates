[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [string]$RuntimeDataRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT,
    [string]$ReferenceRoot = $env:OPENVIDEO_TPL003_REFERENCE_ROOT,
    [switch]$Real
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [scriptblock]$Command,
        [Parameter(Mandatory = $true)]
        [string]$Failure
    )
    $global:LASTEXITCODE = 0
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Failure (exit $LASTEXITCODE)"
    }
}

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
Push-Location $resolvedRoot
try {
    Invoke-Checked {
        node --test `
            'apps/gateway/test/reference-template-production.test.mjs' `
            'apps/gateway/test/tpl003-real-acceptance-script.test.mjs'
    } 'TPL-003 focused tests failed'

    Invoke-Checked {
        corepack pnpm --filter '@openvideo/gateway' typecheck
    } 'TPL-003 Gateway typecheck failed'

    Invoke-Checked {
        git diff --check
    } 'TPL-003 git diff check failed'

    if ($Real) {
        if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
            throw 'OPENVIDEO_RUNTIME_DATA_ROOT is required for TPL-003 real acceptance.'
        }
        if ([string]::IsNullOrWhiteSpace($ReferenceRoot)) {
            throw 'OPENVIDEO_TPL003_REFERENCE_ROOT is required for TPL-003 real acceptance.'
        }
        $arguments = @(
            (Join-Path $PSScriptRoot 'run-tpl003-real-acceptance.mjs'),
            ([IO.Path]::GetFullPath($RuntimeDataRoot)),
            '--reference-root',
            ([IO.Path]::GetFullPath($ReferenceRoot))
        )
        Invoke-Checked {
            & node @arguments
        } 'TPL-003 real acceptance failed'
    }

    Write-Output 'TPL-003 verification passed.'
}
finally {
    Pop-Location
}
