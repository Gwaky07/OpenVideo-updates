/** Compact CJK/Latin copy so punctuation does not hide a spoken cue. */
export const compactSpokenText = (value) =>
  typeof value === 'string' ? value.toLocaleLowerCase().replace(/[\s\p{P}\p{S}]+/gu, '') : ''

const CAPTION_MAX_CHARS = 12
const MIN_SPOKEN_HOLD_US = 700_000
export const MIN_READABLE_FLOWER_US = 800_000
export const PREFERRED_READABLE_FLOWER_US = 1_200_000

/**
 * Stretch a spoken window forward to a readable hold. Never start before the
 * cue is said — leftover time before this caption stays empty.
 * @param {{ startUs: number, durationUs: number }} window
 * @param {{ startUs: number, durationUs: number }} range
 * @param {number} minUs
 */
const holdToReadable = (window, range, minUs) => {
  const rangeEndUs = range.startUs + range.durationUs
  const startUs = Math.max(range.startUs, window.startUs)
  let endUs = Math.min(rangeEndUs, startUs + Math.max(1, window.durationUs))
  if (endUs - startUs < minUs) {
    endUs = Math.min(rangeEndUs, startUs + minUs)
  }
  return { startUs, durationUs: Math.max(1, endUs - startUs) }
}

/**
 * Keep a spoken highlight on screen long enough to read, without leaving the
 * voiceover window or starting before the cue is said.
 * @param {{ startUs: number, durationUs: number }} window
 * @param {{ startUs: number, durationUs: number }} range
 */
const holdSpokenWindow = (window, range) =>
  holdToReadable(window, range, MIN_SPOKEN_HOLD_US)

/**
 * Split voiceover into short, single-line caption cards.
 * Strong stops always break. Commas break when the clause is already long.
 * Oversized clauses are cut at the max line length so Jianying does not wrap.
 * @param {unknown} text
 * @param {{ maxChars?: number }} [options]
 * @returns {string[]}
 */
export const splitVoiceoverCaptionCards = (text, options = {}) => {
  const source = typeof text === 'string' ? text.trim() : ''
  if (!source) return []
  const maxChars = Number.isSafeInteger(options.maxChars) && options.maxChars > 0
    ? Math.max(6, Math.min(16, options.maxChars))
    : CAPTION_MAX_CHARS
  /** @type {string[]} */
  const cards = []
  let buffer = ''
  const flush = () => {
    const next = buffer.trim()
    buffer = ''
    if (!next) return
    if (next.length < 2 && cards.length > 0) {
      cards[cards.length - 1] += next
      return
    }
    cards.push(next)
  }
  const characters = [...source]
  for (let index = 0; index < characters.length; index += 1) {
    const character = characters[index]
    buffer += character
    const length = [...buffer].length
    const strongStop = /[。！？；…!?]/u.test(character)
    const commaStop = /[，、,：:]/u.test(character)
    if (strongStop || commaStop) {
      flush()
      continue
    }
    if (length >= maxChars && !/[0-9A-Za-z]/u.test(character)) {
      const ahead = characters.slice(index + 1).join('')
      const untilPunct = ahead.match(/^[^。！？；…!?，、,：:]*/u)?.[0] ?? ''
      if ([...untilPunct].length > 0 && [...untilPunct].length <= 4) continue
      const phraseBreak = /还是|就是|以及|并且|然后|所以/.exec(buffer)
      if (phraseBreak && phraseBreak.index >= 2) {
        const cut = phraseBreak.index + phraseBreak[0].length
        const tail = buffer.slice(cut)
        buffer = buffer.slice(0, cut)
        flush()
        buffer = tail
        continue
      }
      flush()
    }
  }
  flush()
  return cards
}

/**
 * Map text cards onto a shot/voiceover window by spoken character weight.
 * @param {readonly string[]} texts
 * @param {{ startUs: number, durationUs: number }} range
 * @returns {Array<{ text: string, startUs: number, durationUs: number }>}
 */
export const timeAlignTextSpans = (texts, range) => {
  const cards = texts.filter((value) => typeof value === 'string' && value.trim())
  if (
    cards.length === 0 ||
    !Number.isSafeInteger(range?.startUs) ||
    range.startUs < 0 ||
    !Number.isSafeInteger(range?.durationUs) ||
    range.durationUs <= 0
  ) return []
  const weights = cards.map((card) => Math.max(1, [...card].length))
  const total = weights.reduce((sum, weight) => sum + weight, 0)
  let cursor = range.startUs
  const endUs = range.startUs + range.durationUs
  return cards.map((text, index) => {
    const remaining = endUs - cursor
    const durationUs = index === cards.length - 1
      ? remaining
      : Math.max(1, Math.floor(range.durationUs * weights[index] / total))
    const startUs = cursor
    cursor += durationUs
    return { text, startUs, durationUs: Math.max(1, durationUs) }
  })
}

/**
 * Locate a highlight inside spoken copy using compact text, then map back to
 * the original character index so timing follows the voiceover, not the shot.
 * @param {string} haystack
 * @param {string} cue
 */
const compactCueIndex = (haystack, cue) => {
  const compactHay = compactSpokenText(haystack)
  const compactCue = compactSpokenText(cue)
  if (!compactHay || !compactCue || compactCue.length < 2) return -1
  const compactIndex = compactHay.indexOf(compactCue)
  if (compactIndex >= 0) return mapCompactIndexToOriginal(haystack, compactIndex)
  if (compactCue.length < 4 || compactCue.length > compactHay.length) return -1
  let searchFrom = 0
  let first = -1
  for (const character of compactCue) {
    const next = compactHay.indexOf(character, searchFrom)
    if (next < 0) return -1
    if (first < 0) first = next
    searchFrom = next + 1
  }
  return mapCompactIndexToOriginal(haystack, first)
}

/** @param {string} original @param {number} compactIndex */
const mapCompactIndexToOriginal = (original, compactIndex) => {
  if (compactIndex < 0) return -1
  let compact = 0
  const characters = [...original]
  for (let index = 0; index < characters.length; index += 1) {
    if (/[\s\p{P}\p{S}]/u.test(characters[index])) continue
    if (compact === compactIndex) return index
    compact += 1
  }
  return -1
}

const HIGHLIGHT_TRAILING_CORE = /(?:识别|追踪|提升|练习|安排|定位|看清|报告|环节)$/u

const longestCompactRun = (left, right) => {
  let best = 0
  for (let leftIndex = 0; leftIndex < left.length; leftIndex += 1) {
    for (let rightIndex = 0; rightIndex < right.length; rightIndex += 1) {
      let run = 0
      while (
        leftIndex + run < left.length &&
        rightIndex + run < right.length &&
        left[leftIndex + run] === right[rightIndex + run]
      ) {
        run += 1
      }
      if (run > best) best = run
    }
  }
  return best
}

const highlightMatchCores = (cue) => {
  const compact = compactSpokenText(cue)
  if (!compact) return []
  const cores = [compact]
  const stripped = compact.replace(HIGHLIGHT_TRAILING_CORE, '')
  if (stripped.length >= 2 && stripped !== compact) cores.push(stripped)
  return cores
}

export const scoreSpokenCue = (spoken, cue) => {
  const hay = compactSpokenText(spoken)
  if (!hay) return 0
  let best = 0
  for (const needle of highlightMatchCores(cue)) {
    if (hay.includes(needle) || needle.includes(hay)) {
      best = Math.max(best, 100 + needle.length)
      continue
    }
    const run = longestCompactRun(hay, needle)
    if (run >= 3 || (run >= 2 && run * 2 >= needle.length)) {
      best = Math.max(best, run)
    }
  }
  if (best > 0) return best
  const needle = compactSpokenText(cue)
  if (!needle || needle.length < 4) return 0
  let searchFrom = 0
  for (const character of needle) {
    const next = hay.indexOf(character, searchFrom)
    if (next < 0) return 0
    searchFrom = next + 1
  }
  return 1
}

/** @param {unknown} spoken @param {unknown} cue */
const spokenCueMatches = (spoken, cue) => scoreSpokenCue(spoken, cue) > 0

/**
 * Spoken window for a flower/sticker cue. Caption cards win when they already
 * carry the same words; otherwise the highlight is timed inside the voiceover.
 * @param {{
 *   cue: unknown,
 *   voiceoverText: unknown,
 *   range: { startUs: number, durationUs: number },
 *   captionSpans?: Array<{ text?: string, startUs: number, durationUs: number }>,
 * }} input
 * @returns {{ startUs: number, durationUs: number } | null}
 */
export const spokenWindowForCue = ({ cue, voiceoverText, range, captionSpans = [] }) => {
  const needle = compactSpokenText(cue)
  if (!needle || needle.length < 2) return null
  const cards = Array.isArray(captionSpans) ? captionSpans : []
  const matchingCard = cards
    .map((card) => ({ card, score: scoreSpokenCue(card?.text, cue) }))
    .filter((entry) => entry.score > 0)
    .sort((left, right) =>
      right.score - left.score ||
      (left.card.startUs ?? 0) - (right.card.startUs ?? 0))[0]?.card
  if (
    matchingCard &&
    Number.isSafeInteger(matchingCard.startUs) &&
    Number.isSafeInteger(matchingCard.durationUs) &&
    matchingCard.durationUs > 0
  ) {
    return holdSpokenWindow(
      { startUs: matchingCard.startUs, durationUs: matchingCard.durationUs },
      range,
    )
  }
  if (typeof voiceoverText !== 'string' || !voiceoverText.trim()) return null
  if (
    !Number.isSafeInteger(range?.startUs) ||
    !Number.isSafeInteger(range?.durationUs) ||
    range.durationUs <= 0
  ) return null
  const originalIndex = highlightMatchCores(cue)
    .map((core) => compactCueIndex(voiceoverText, core))
    .find((index) => index >= 0)
  if (!Number.isSafeInteger(originalIndex) || originalIndex < 0) return null
  const characters = [...voiceoverText]
  const charCount = Math.max(1, characters.length)
  const cueChars = Math.max(1, [...String(cue).replace(/[\s\p{P}\p{S}]+/gu, '')].length)
  const startRatio = originalIndex / charCount
  const endRatio = Math.min(1, (originalIndex + cueChars) / charCount)
  const startUs = range.startUs + Math.floor(range.durationUs * startRatio)
  const durationUs = Math.max(1, Math.floor(range.durationUs * Math.max(endRatio - startRatio, 1 / charCount)))
  return holdSpokenWindow({ startUs, durationUs }, range)
}

/**
 * When several flowers land on the same spoken card, slice that window into
 * sequential non-overlapping hits. Jianying FlowerText slots share one screen
 * position, so overlapping times cover each other.
 * @param {Array<{ startUs: number, durationUs: number }>} windows
 * @returns {Array<{ startUs: number, durationUs: number }>}
 */
export const serializeOverlappingWindows = (windows) => {
  if (!Array.isArray(windows) || windows.length === 0) return []
  const items = windows.map((window, index) => ({
    index,
    startUs: Number(window?.startUs),
    durationUs: Number(window?.durationUs),
  })).filter((item) =>
    Number.isSafeInteger(item.startUs) &&
    Number.isSafeInteger(item.durationUs) &&
    item.durationUs > 0)
    .sort((left, right) => left.startUs - right.startUs || left.index - right.index)
  /** @type {Array<{ startUs: number, durationUs: number }>} */
  const result = windows.map((window) => ({
    startUs: Number(window?.startUs) || 0,
    durationUs: Math.max(1, Number(window?.durationUs) || 1),
  }))
  let cursor = 0
  while (cursor < items.length) {
    let endUs = items[cursor].startUs + items[cursor].durationUs
    let next = cursor + 1
    while (next < items.length && items[next].startUs < endUs) {
      endUs = Math.max(endUs, items[next].startUs + items[next].durationUs)
      next += 1
    }
    const group = items.slice(cursor, next)
    const startUs = group[0].startUs
    const spanUs = Math.max(group.length, endUs - startUs)
    const sliceUs = Math.max(1, Math.floor(spanUs / group.length))
    group.forEach((item, offset) => {
      const sliceStartUs = startUs + offset * sliceUs
      result[item.index] = {
        startUs: sliceStartUs,
        durationUs: offset === group.length - 1
          ? Math.max(1, endUs - sliceStartUs)
          : sliceUs,
      }
    })
    cursor = next
  }
  return result
}

/**
 * Hold each flower until the next card (or the range end) so later shots are
 * not left empty after a short spoken hit. Leading time before the first
 * cue stays empty unless fillLeading is set.
 * @param {Array<{ startUs: number, durationUs: number }>} windows
 * @param {{ startUs: number, durationUs: number }} range
 * @param {{ fillLeading?: boolean }} [options]
 * @returns {Array<{ startUs: number, durationUs: number }>}
 */
export const extendWindowsToCoverRange = (windows, range, options = {}) => {
  if (!Array.isArray(windows) || windows.length === 0) return []
  if (
    !Number.isSafeInteger(range?.startUs) ||
    !Number.isSafeInteger(range?.durationUs) ||
    range.durationUs <= 0
  ) {
    return windows.map((window) => ({
      startUs: Number(window?.startUs) || 0,
      durationUs: Math.max(1, Number(window?.durationUs) || 1),
    }))
  }
  const rangeEndUs = range.startUs + range.durationUs
  const items = windows.map((window, index) => ({
    index,
    startUs: Number(window?.startUs),
  })).filter((item) => Number.isSafeInteger(item.startUs))
    .sort((left, right) => left.startUs - right.startUs || left.index - right.index)
  const result = windows.map((window) => ({
    startUs: Number(window?.startUs) || 0,
    durationUs: Math.max(1, Number(window?.durationUs) || 1),
  }))
  items.forEach((item, offset) => {
    const startUs = offset === 0 && options.fillLeading === true
      ? range.startUs
      : Math.max(range.startUs, Math.min(rangeEndUs - 1, item.startUs))
    const nextStartUs = offset + 1 < items.length
      ? Math.max(range.startUs, Math.min(rangeEndUs, items[offset + 1].startUs))
      : rangeEndUs
    const endUs = Math.max(startUs + 1, nextStartUs)
    result[item.index] = {
      startUs,
      durationUs: Math.max(1, endUs - startUs),
    }
  })
  return result
}

/**
 * Keep every creation highlight, but give same-shot flowers a readable share
 * of that shot. Overlaps stay sequential. Words are never dropped.
 * @param {Array<{ startUs: number, durationUs: number }>} windows
 * @param {{
 *   range?: { startUs: number, durationUs: number },
 *   minUs?: number,
 *   preferredUs?: number,
 *   preserveAlignedStarts?: boolean,
 * }} [options]
 * @returns {Array<{ startUs: number, durationUs: number }>}
 */
const redistributeShortCluster = (windows, range, minUs, preferredUs) => {
  const serialized = serializeOverlappingWindows(windows)
  if (serialized.length === 0) return []
  if (serialized.length === 1) {
    const only = serialized[0]
    const limit = range ?? {
      startUs: only.startUs,
      durationUs: Math.max(only.durationUs, preferredUs),
    }
    return [holdToReadable(only, limit, Math.min(preferredUs, limit.durationUs))]
  }
  if (serialized.every((window) => window.durationUs >= minUs)) return serialized

  const ordered = serialized
    .map((window, index) => ({
      index,
      startUs: window.startUs,
      durationUs: window.durationUs,
      endUs: window.startUs + window.durationUs,
    }))
    .sort((left, right) => left.startUs - right.startUs || left.index - right.index)
  let unionStart = ordered[0].startUs
  let unionEnd = ordered.reduce((end, item) => Math.max(end, item.endUs), ordered[0].endUs)
  const rangeStart = range ? range.startUs : unionStart
  const rangeEnd = range ? range.startUs + range.durationUs : unionEnd
  unionStart = Math.max(rangeStart, unionStart)
  unionEnd = Math.min(rangeEnd, Math.max(unionEnd, unionStart + 1))

  const count = ordered.length
  const available = Math.max(1, rangeEnd - rangeStart)
  const targetEach = available >= count * preferredUs
    ? preferredUs
    : Math.max(1, Math.floor(available / count))
  const needed = count * targetEach
  let span = unionEnd - unionStart
  if (span < needed) {
    const growAfter = Math.min(needed - span, Math.max(0, rangeEnd - unionEnd))
    unionEnd += growAfter
    span = unionEnd - unionStart
    if (span < needed) {
      const growBefore = Math.min(needed - span, Math.max(0, unionStart - rangeStart))
      unionStart -= growBefore
    }
  }

  const sliceUs = Math.max(1, Math.floor((unionEnd - unionStart) / count))
  const result = serialized.map((window) => ({
    startUs: window.startUs,
    durationUs: window.durationUs,
  }))
  ordered.forEach((item, offset) => {
    const startUs = unionStart + offset * sliceUs
    result[item.index] = {
      startUs,
      durationUs: offset === count - 1
        ? Math.max(1, unionEnd - startUs)
        : sliceUs,
    }
  })
  return result
}

export const selectReadableFlowerWindows = (windows, options = {}) => {
  if (!Array.isArray(windows) || windows.length === 0) return []
  const minUs = Number.isSafeInteger(options.minUs) && options.minUs > 0
    ? options.minUs
    : MIN_READABLE_FLOWER_US
  const preferredUs = Number.isSafeInteger(options.preferredUs) && options.preferredUs > 0
    ? Math.max(minUs, options.preferredUs)
    : PREFERRED_READABLE_FLOWER_US
  const range = options.range &&
    Number.isSafeInteger(options.range.startUs) &&
    Number.isSafeInteger(options.range.durationUs) &&
    options.range.durationUs > 0
    ? options.range
    : null

  const items = windows.map((window, index) => ({
    index,
    startUs: Number(window?.startUs),
    durationUs: Number(window?.durationUs),
    aligned: window?.aligned !== false,
  })).filter((item) =>
    Number.isSafeInteger(item.startUs) &&
    Number.isSafeInteger(item.durationUs) &&
    item.durationUs > 0)
  if (items.length === 0) return []

  const result = windows.map((window) => ({
    startUs: Number(window?.startUs) || 0,
    durationUs: Math.max(1, Number(window?.durationUs) || 1),
  }))
  const aligned = items.filter((item) => item.aligned)
  const fillers = items.filter((item) => !item.aligned)
  const alignedRange = fillers.length === 0
    ? range
    : aligned.length > 0
      ? {
        startUs: Math.min(...aligned.map((item) => item.startUs)),
        durationUs: Math.max(...aligned.map((item) => item.startUs + item.durationUs))
          - Math.min(...aligned.map((item) => item.startUs)),
      }
      : range

  if (aligned.length > 0 && options.preserveAlignedStarts === true) {
    aligned.forEach((item) => {
      result[item.index] = {
        startUs: item.startUs,
        durationUs: item.durationUs,
      }
    })
  } else if (aligned.length > 0) {
    const readable = redistributeShortCluster(
      aligned.map((item) => ({ startUs: item.startUs, durationUs: item.durationUs })),
      alignedRange,
      minUs,
      preferredUs,
    )
    aligned.forEach((item, offset) => {
      result[item.index] = readable[offset]
    })
  }
  return result
}

/**
 * Place an unmatched highlight into the first leftover gap of a shot so it
 * cannot steal time from a spoken-aligned flower.
 * @param {{ startUs: number, durationUs: number }} shot
 * @param {Array<{ startUs: number, durationUs: number }>} occupied
 * @param {number} wantUs
 * @param {number} [minUs]
 * @returns {{ startUs: number, durationUs: number } | null}
 */
export const placeWindowInGaps = (shot, occupied, wantUs, minUs = 400_000) => {
  if (
    !Number.isSafeInteger(shot?.startUs) ||
    !Number.isSafeInteger(shot?.durationUs) ||
    shot.durationUs <= 0 ||
    !Number.isSafeInteger(wantUs) ||
    wantUs <= 0
  ) return null
  const shotEndUs = shot.startUs + shot.durationUs
  const blocks = occupied
    .filter((window) =>
      Number.isSafeInteger(window.startUs) &&
      Number.isSafeInteger(window.durationUs) &&
      window.durationUs > 0 &&
      window.startUs < shotEndUs &&
      window.startUs + window.durationUs > shot.startUs)
    .map((window) => ({
      startUs: Math.max(shot.startUs, window.startUs),
      endUs: Math.min(shotEndUs, window.startUs + window.durationUs),
    }))
    .sort((left, right) => left.startUs - right.startUs)
  let cursor = shot.startUs
  const needed = Math.max(minUs, Math.min(wantUs, shot.durationUs))
  for (const block of blocks) {
    const gap = block.startUs - cursor
    if (gap >= minUs) {
      return { startUs: cursor, durationUs: Math.min(wantUs, gap) }
    }
    cursor = Math.max(cursor, block.endUs)
  }
  const tail = shotEndUs - cursor
  if (tail >= minUs) return { startUs: cursor, durationUs: Math.min(wantUs, tail) }
  if (tail > 0 && needed > tail) return { startUs: cursor, durationUs: tail }
  return null
}

export const clampSpokenWindows = (windows, limit) => {
  const ordered = windows
    .filter((window) => Number.isSafeInteger(window.startUs) && Number.isSafeInteger(window.durationUs) && window.durationUs > 0)
    .sort((left, right) => left.startUs - right.startUs)
  const endLimit = limit
    ? limit.startUs + limit.durationUs
    : Number.POSITIVE_INFINITY
  return ordered.map((window, index, values) => {
    const next = values[index + 1]
    const maxEnd = Math.min(endLimit, next ? next.startUs : endLimit)
    const startUs = Math.max(limit?.startUs ?? 0, window.startUs)
    return {
      startUs,
      durationUs: Math.max(1, Math.min(window.durationUs, maxEnd - startUs)),
    }
  })
}
