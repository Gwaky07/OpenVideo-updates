import { execFile, spawn } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { copyFile, lstat, mkdir, open, readFile, realpath, rename, rm, stat, writeFile } from 'node:fs/promises'
import { extname, isAbsolute, relative, resolve } from 'node:path'
import { promisify } from 'node:util'

import { securePrivateRuntimeRoot } from './local-runtime.mjs'
import { isRunningHubVoiceId } from './tts-studio.mjs'
import { isJianyingPresetVoiceId } from './jianying-tts-presets.mjs'

/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' &&
  /^[A-Za-z0-9][A-Za-z0-9_-]{0,179}$/u.test(value)
/** @param {unknown} value @returns {value is {sentence_id: string, text: string, target_range?: {start: number, duration: number}}} */
const validSegment = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const segment = /** @type {Record<string, any>} */ (value)
  return identifier(segment.sentence_id) &&
    typeof segment.text === 'string' &&
    segment.text.trim().length > 0 &&
    segment.text.length <= 20_000
}
/** @param {string} value */
const digest = (value) => createHash('sha256').update(value).digest('hex')
const execFileAsync = promisify(execFile)
const jianyingAudioExtensions = new Set(['.aac', '.flac', '.m4a', '.mp3', '.ogg', '.wav'])

/** @param {string} path */
const detectAudioExtension = async (path) => {
  const handle = await open(path, 'r').catch(() => null)
  if (!handle) return null
  try {
    const header = Buffer.alloc(16)
    const { bytesRead } = await handle.read(header, 0, header.length, 0)
    if (bytesRead >= 12 && header.subarray(0, 4).toString('ascii') === 'RIFF' &&
        header.subarray(8, 12).toString('ascii') === 'WAVE') return '.wav'
    if (bytesRead >= 4 && header.subarray(0, 4).toString('ascii') === 'OggS') return '.ogg'
    if (bytesRead >= 4 && header.subarray(0, 4).toString('ascii') === 'fLaC') return '.flac'
    if (bytesRead >= 3 && header.subarray(0, 3).toString('ascii') === 'ID3') return '.mp3'
    if (bytesRead >= 2 && header[0] === 0xff && [0xfb, 0xf3, 0xf2].includes(header[1] & 0xff)) return '.mp3'
    if (bytesRead >= 2 && header[0] === 0xff && [0xf1, 0xf9].includes(header[1] & 0xf9)) return '.aac'
    if (bytesRead >= 12 && header.subarray(4, 8).toString('ascii') === 'ftyp') return '.m4a'
    const declared = extname(path).toLowerCase()
    return jianyingAudioExtensions.has(declared) ? declared : null
  } finally {
    await handle.close()
  }
}

/**
 * Normalize a legacy private asset whose filename ended in `.audio` before it
 * reaches Jianying. The callback path is an internal Gateway boundary, but we
 * still require a real absolute file and never pass the opaque suffix through.
 * @param {string} path
 * @returns {Promise<string | null>}
 */
const migrateLegacyAudioPath = async (path) => {
  if (extname(path).toLowerCase() !== '.audio') return path
  if (!isAbsolute(path)) return null
  const metadata = await lstat(path).catch(() => null)
  if (!metadata?.isFile() || metadata.isSymbolicLink() || metadata.size <= 0) return null
  const extension = await detectAudioExtension(path)
  if (!extension) return null
  const targetPath = path.slice(0, -'.audio'.length) + extension
  const existing = await lstat(targetPath).catch(() => null)
  if (!existing?.isFile() || existing.isSymbolicLink() || existing.size <= 0) {
    const temporaryPath = `${targetPath}.${randomUUID()}.tmp`
    try {
      await copyFile(path, temporaryPath)
      await rename(temporaryPath, targetPath)
    } finally {
      await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }
  return targetPath
}

export class JianyingVoiceoverError extends Error {
  /** @param {string} code */
  constructor(code = 'JY002_VOICEOVER_AUDIO_MISSING') {
    super(code)
    this.name = 'JianyingVoiceoverError'
    this.code = code
    this.status = 503
  }
}

/** @param {{text: string, outputPath: string, voice?: string | null, signal?: AbortSignal}} input */
const synthesizeWindowsSpeech = ({ text, outputPath, voice = null, signal }) =>
  /** @type {Promise<void>} */
  new Promise((resolvePromise, reject) => {
    const script = [
      "$ErrorActionPreference='Stop'",
      '$inputBase64=[Console]::In.ReadToEnd()',
      '$inputJson=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($inputBase64)) | ConvertFrom-Json',
      'Add-Type -AssemblyName System.Speech',
      '$speaker=New-Object System.Speech.Synthesis.SpeechSynthesizer',
      "if(-not [string]::IsNullOrWhiteSpace([string]$inputJson.voice)){$speaker.SelectVoice([string]$inputJson.voice)}",
      '$speaker.SetOutputToWaveFile([string]$inputJson.outputPath)',
      '$speaker.Speak([string]$inputJson.text)',
      '$speaker.Dispose()',
    ].join(';')
    const child = spawn(
      'powershell.exe',
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
      { stdio: ['pipe', 'ignore', 'ignore'], windowsHide: true },
    )
    let settled = false
    let abortRequested = false
    /** @param {Error | null} error */
    const finish = (error) => {
      if (settled) return
      settled = true
      signal?.removeEventListener('abort', onAbort)
      error ? reject(error) : resolvePromise(undefined)
    }
    const onAbort = () => {
      abortRequested = true
      child.kill('SIGKILL')
    }
    signal?.addEventListener('abort', onAbort, { once: true })
    child.once('error', () => finish(new JianyingVoiceoverError(
      abortRequested ? 'JY002_CANCELLED' : 'JY002_VOICEOVER_AUDIO_MISSING',
    )))
    child.once('close', (code) => finish(
      abortRequested
        ? new JianyingVoiceoverError('JY002_CANCELLED')
        : code === 0 ? null : new JianyingVoiceoverError(),
    ))
    if (signal?.aborted) {
      onAbort()
      return
    }
    child.stdin.end(Buffer.from(JSON.stringify({ text, outputPath, voice }), 'utf8').toString('base64'))
  })

/** @param {{text: string, outputPath: string, voice: string, rate?: number, signal?: AbortSignal}} input */
const synthesizeEdgeSpeech = ({ text, outputPath, voice, rate = 0, signal }) =>
  /** @type {Promise<void>} */
  new Promise((resolvePromise, reject) => {
    const signedRate = `${rate >= 0 ? '+' : ''}${rate}%`
    const child = spawn(
      'edge-tts',
      ['--text', text, '--voice', voice, '--rate', signedRate, '--write-media', outputPath],
      { stdio: 'ignore', windowsHide: true },
    )
    let settled = false
    let abortRequested = false
    /** @param {Error | null} error */
    const finish = (error) => {
      if (settled) return
      settled = true
      signal?.removeEventListener('abort', onAbort)
      error ? reject(error) : resolvePromise(undefined)
    }
    const onAbort = () => {
      abortRequested = true
      child.kill('SIGKILL')
    }
    signal?.addEventListener('abort', onAbort, { once: true })
    child.once('error', () => finish(new JianyingVoiceoverError(
      abortRequested ? 'JY002_CANCELLED' : 'JY002_VOICEOVER_AUDIO_MISSING',
    )))
    child.once('close', (code) => finish(
      abortRequested
        ? new JianyingVoiceoverError('JY002_CANCELLED')
        : code === 0 ? null : new JianyingVoiceoverError(),
    ))
    if (signal?.aborted) onAbort()
  })

/**
 * @param {{
 *   dataRoot: string,
 *   voice?: string | null,
 *   synthesize?: (input: {text: string, outputPath: string, voice?: string | null, signal?: AbortSignal}) => Promise<void>,
 *   synthesizeEdge?: (input: {text: string, outputPath: string, voice: string, rate?: number, signal?: AbortSignal}) => Promise<void>,
 *   securePrivateRoot?: (path: string) => Promise<void>,
 *   probeDurationUs?: ((path: string) => Promise<number>) | null,
 *   ffprobePath?: string,
 *   ttsStudio?: {
 *     resolveBundle: Function,
 *     resolveAudioToken?: (input: {audioToken: string, projectId?: string}) => Promise<string | null>,
 *   },
 *   jianyingPresetNarration?: {
 *     isVoiceId: (value: unknown) => boolean,
 *     resolveSegments: Function,
 *   },
 * }} options
 */
export const createJianyingVoiceoverProvider = async ({
  dataRoot,
  voice = null,
  synthesize = synthesizeWindowsSpeech,
  synthesizeEdge = synthesizeEdgeSpeech,
  securePrivateRoot = securePrivateRuntimeRoot,
  probeDurationUs = null,
  ffprobePath = 'ffprobe',
  ttsStudio,
  jianyingPresetNarration,
}) => {
  if (
    !isAbsolute(dataRoot) ||
    (voice !== null && !identifier(voice)) ||
    typeof synthesize !== 'function' ||
    typeof synthesizeEdge !== 'function' ||
    typeof securePrivateRoot !== 'function' ||
    (probeDurationUs !== null && typeof probeDurationUs !== 'function') ||
    (ttsStudio !== undefined && typeof ttsStudio?.resolveBundle !== 'function') ||
    (
      jianyingPresetNarration !== undefined &&
      (
        typeof jianyingPresetNarration?.isVoiceId !== 'function' ||
        typeof jianyingPresetNarration?.resolveSegments !== 'function'
      )
    )
  ) throw new JianyingVoiceoverError()
  const root = resolve(dataRoot, 'jianying-drafts', 'voiceovers')
  const narrationRoot = resolve(dataRoot, 'narration-assets')
  await mkdir(root, { recursive: true, mode: 0o700 })
  await mkdir(narrationRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(root)
  await securePrivateRoot(narrationRoot)
  const canonicalNarrationRoot = await realpath(narrationRoot)

  /** @param {unknown} storedRelativePath */
  const safeNarrationAssetPath = async (storedRelativePath) => {
    if (typeof storedRelativePath !== 'string' || storedRelativePath.length === 0) return null
    const candidate = resolve(narrationRoot, storedRelativePath)
    const lexicalRelative = relative(narrationRoot, candidate)
    if (lexicalRelative === '' || lexicalRelative.startsWith('..') || isAbsolute(lexicalRelative)) return null
    const linkMetadata = await lstat(candidate).catch(() => null)
    if (!linkMetadata?.isFile() || linkMetadata.isSymbolicLink() || linkMetadata.size <= 0) return null
    const canonical = await realpath(candidate).catch(() => null)
    if (!canonical) return null
    const canonicalRelative = relative(canonicalNarrationRoot, canonical)
    return canonicalRelative !== '' && !canonicalRelative.startsWith('..') && !isAbsolute(canonicalRelative)
      ? canonical
      : null
  }

  const measureDurationUs = probeDurationUs ?? (async (path) => {
    const { stdout } = await execFileAsync(ffprobePath, [
      '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', path,
    ], { windowsHide: true, timeout: 30_000 })
    const value = Math.round(Number(String(stdout).trim()) * 1_000_000)
    if (!Number.isSafeInteger(value) || value <= 0) throw new JianyingVoiceoverError()
    return value
  })

  const narrationManifestPath = resolve(narrationRoot, 'manifest.json')
  const readManifest = async () => {
    try {
      const parsed = JSON.parse(await readFile(narrationManifestPath, 'utf8'))
      return parsed && typeof parsed === 'object' && parsed.schemaVersion === 1 && parsed.assets
        ? parsed
        : { schemaVersion: 1, assets: {} }
    } catch (error) {
      if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
        return { schemaVersion: 1, assets: {} }
      }
      throw new JianyingVoiceoverError('JY002_NARRATION_MANIFEST_INVALID')
    }
  }
  const writeManifest = async (/** @type {Record<string, any>} */ manifest) => {
    const temporary = `${narrationManifestPath}.${randomUUID()}.tmp`
    await writeFile(temporary, `${JSON.stringify(manifest)}\n`, { encoding: 'utf8', mode: 0o600 })
    await rename(temporary, narrationManifestPath)
  }
  /** Serialize read-modify-write so concurrent bundles cannot erase each other's tokens. */
  let manifestQueue = Promise.resolve()
  const mergeManifestAssets = async (/** @type {Record<string, any>} */ assets) => {
    const update = manifestQueue.then(async () => {
      const latest = await readManifest()
      latest.assets = { ...latest.assets, ...assets }
      await writeManifest(latest)
    })
    manifestQueue = update.catch(() => {})
    await update
  }
  /** @type {Map<string, Promise<string | null>>} */
  const narrationMigrationInflight = new Map()
  /**
   * @param {string} audioToken
   * @param {{projectId: string, relativePath: string, durationUs: number}} entry
   */
  const resolveJianyingNarrationPath = async (audioToken, entry) => {
    const currentPath = await safeNarrationAssetPath(entry?.relativePath)
    if (!currentPath) return null
    if (jianyingAudioExtensions.has(extname(currentPath).toLowerCase())) return currentPath
    if (extname(currentPath).toLowerCase() !== '.audio') return null
    const pending = narrationMigrationInflight.get(audioToken)
    if (pending) return await pending
    const operation = (async () => {
      const extension = await detectAudioExtension(currentPath)
      if (!extension) return null
      const targetPath = currentPath.slice(0, -'.audio'.length) + extension
      const existing = await stat(targetPath).catch(() => null)
      if (!existing?.isFile() || existing.size <= 0) {
        const temporaryPath = `${targetPath}.${randomUUID()}.tmp`
        try {
          await copyFile(currentPath, temporaryPath)
          await rename(temporaryPath, targetPath)
        } finally {
          await rm(temporaryPath, { force: true }).catch(() => {})
        }
      }
      const targetRelative = relative(narrationRoot, targetPath).replaceAll('\\', '/')
      await mergeManifestAssets({
        [audioToken]: { ...entry, relativePath: targetRelative },
      })
      await rm(currentPath, { force: true }).catch(() => {})
      return await safeNarrationAssetPath(targetRelative)
    })()
    narrationMigrationInflight.set(audioToken, operation)
    try {
      return await operation
    } finally {
      if (narrationMigrationInflight.get(audioToken) === operation) narrationMigrationInflight.delete(audioToken)
    }
  }

  /** @param {{projectId: string, voiceId?: string | null, rate?: number, segments: Array<{sentence_id: string, text: string}>}} input */
  const narrationKey = (input) => digest(JSON.stringify({
    projectId: input.projectId,
    voiceId: input.voiceId ?? null,
    rate: input.rate ?? 0,
    segments: input.segments.map((segment) => [segment.sentence_id, digest(segment.text)]),
  }))

  /** Cache-only lookup used while creating output jobs; it never starts TTS. */
  const getNarrationBundle = async (/** @type {{projectId: string, voiceId?: string | null, rate?: number, segments: Array<{sentence_id: string, text: string}>}} */ input) => {
    if (
      !identifier(input?.projectId) ||
      !Array.isArray(input?.segments) ||
      input.segments.length === 0 ||
      input.segments.length > 100 ||
      input.segments.some((segment) => !validSegment(segment)) ||
      (input.voiceId !== undefined && input.voiceId !== null && !identifier(input.voiceId)) ||
      (input.rate !== undefined && (!Number.isInteger(input.rate) || input.rate < -100 || input.rate > 100))
    ) throw new JianyingVoiceoverError()
    const key = narrationKey(input)
    const manifest = await readManifest()
    const segments = []
    for (const [index, segment] of input.segments.entries()) {
      const audioToken = `narration_${key.slice(0, 24)}_${String(index + 1).padStart(3, '0')}`
      const entry = manifest.assets[audioToken]
      const durationUs = Number(entry?.durationUs)
      if (!entry || !Number.isSafeInteger(durationUs) || durationUs <= 0) return null
      if (!await safeNarrationAssetPath(entry.relativePath)) return null
      segments.push({ sentenceId: segment.sentence_id, audioToken, durationUs })
    }
    return { bundleId: `narration_${key.slice(0, 32)}`, segments }
  }
  /** @type {Map<string, Promise<Record<string, any>>>} */
  const narrationInflight = new Map()

  return {
    getNarrationBundle,
    /**
     * Resolve every sentence once into a durable opaque audio asset. The bundle
     * fingerprint intentionally excludes jobId so Preview and Jianying share it.
     */
    async resolveNarrationBundle(/** @type {{projectId: string, jobId: string, voiceId?: string | null, rate?: number, segments: Array<{sentence_id: string, text: string}>, signal?: AbortSignal}} */ input) {
      const key = narrationKey(input)
      const pending = narrationInflight.get(key)
      if (pending) return await pending
      const provider = this
      const operation = (async () => {
        const cachedBundle = await getNarrationBundle(input)
        if (cachedBundle) return cachedBundle
        const directory = resolve(narrationRoot, key)
        await mkdir(directory, { recursive: true, mode: 0o700 })
        const manifest = await readManifest()
        const resolved = await provider.resolveVoiceovers(input)
        const output = []
        /** @type {Record<string, any>} */
        const manifestAssets = {}
        for (const [index, segment] of resolved.entries()) {
          const audioToken = `narration_${key.slice(0, 24)}_${String(index + 1).padStart(3, '0')}`
          const existing = manifest.assets[audioToken]
          let durationUs = Number(existing?.durationUs)
          const existingPath = existing ? await safeNarrationAssetPath(existing.relativePath) : null
          const extension = existingPath
            ? extname(existingPath).toLowerCase()
            : await detectAudioExtension(segment.path)
          if (!extension || (!jianyingAudioExtensions.has(extension) && extension !== '.audio')) {
            throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_FORMAT_UNSUPPORTED')
          }
          const targetPath = existingPath ?? resolve(directory, `${String(index + 1).padStart(3, '0')}${extension}`)
          const existingStat = await stat(targetPath).catch(() => null)
          if (!existingStat?.isFile() || existingStat.size <= 0) {
            const temporaryPath = `${targetPath}.${randomUUID()}.tmp`
            try {
              await copyFile(segment.path, temporaryPath)
              durationUs = await measureDurationUs(temporaryPath)
              await rename(temporaryPath, targetPath)
            } finally {
              await rm(temporaryPath, { force: true }).catch(() => {})
            }
          } else if (!Number.isSafeInteger(durationUs) || durationUs <= 0) {
            durationUs = await measureDurationUs(targetPath)
          }
          manifestAssets[audioToken] = {
            projectId: input.projectId,
            relativePath: relative(narrationRoot, targetPath).replaceAll('\\', '/'),
            durationUs,
          }
          output.push({ sentenceId: segment.sentenceId, audioToken, durationUs })
        }
        await mergeManifestAssets(manifestAssets)
        return { bundleId: `narration_${key.slice(0, 32)}`, segments: output }
      })()
      narrationInflight.set(key, operation)
      try {
        return await operation
      } finally {
        if (narrationInflight.get(key) === operation) narrationInflight.delete(key)
      }
    },
    async resolveAudioToken(/** @type {string | {audioToken: string, projectId?: string}} */ input) {
      const audioToken = typeof input === 'string' ? input : input?.audioToken
      const projectId = typeof input === 'string' ? null : input?.projectId ?? null
      if (!identifier(audioToken) || !audioToken.startsWith('narration_')) return null
      const entry = (await readManifest()).assets[audioToken]
      if (!entry || (projectId && entry.projectId !== projectId)) return null
      return await resolveJianyingNarrationPath(audioToken, entry)
    },
    /**
     * Prefer opaque timeline audio tokens (VID-003 assets); never re-synthesize from brief.
     * @param {{projectId: string, jobId: string, audioTokens: string[], segments: unknown[], signal?: AbortSignal, resolveAudioPath?: (input: {audioToken: string}) => Promise<string | null>}} input
     */
    async resolveFromAudioTokens(input) {
      if (
        !identifier(input?.projectId) ||
        !identifier(input?.jobId) ||
        !Array.isArray(input?.audioTokens) ||
        !Array.isArray(input?.segments) ||
        input.audioTokens.length === 0 ||
        input.audioTokens.length !== input.segments.length ||
        input.segments.some((segment) => !validSegment(segment)) ||
        input.audioTokens.some((token) => !identifier(token))
      ) {
        throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_MISSING')
      }
      const segments = /** @type {{sentence_id: string, text: string}[]} */ (input.segments)
      const studioResolveAudioToken = ttsStudio?.resolveAudioToken
      const resolveAudioPath =
        typeof input.resolveAudioPath === 'function'
          ? input.resolveAudioPath
          : typeof studioResolveAudioToken === 'function'
            ? (/** @type {{audioToken: string}} */ payload) => studioResolveAudioToken({
                audioToken: payload.audioToken,
                projectId: input.projectId,
              })
            : null
      if (!resolveAudioPath) throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_MISSING')
      const output = []
      for (const [index, token] of input.audioTokens.entries()) {
        input.signal?.throwIfAborted()
        const path = await resolveAudioPath({ audioToken: token })
        if (typeof path !== 'string' || path.length === 0) {
          throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_MISSING')
        }
        const normalizedPath = await migrateLegacyAudioPath(path)
        if (!normalizedPath) {
          throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_FORMAT_UNSUPPORTED')
        }
        const extension = extname(normalizedPath).toLowerCase()
        if (!jianyingAudioExtensions.has(extension)) {
          throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_FORMAT_UNSUPPORTED')
        }
        output.push({
          sentenceId: segments[index].sentence_id,
          audioId: token,
          path: normalizedPath,
        })
      }
      return output
    },
    /** @param {{projectId: string, jobId: string, voiceId?: string | null, rate?: number, segments: unknown[], signal?: AbortSignal}} input */
    async resolveVoiceovers(input) {
      if (
        !identifier(input?.projectId) ||
        !identifier(input?.jobId) ||
        !Array.isArray(input?.segments) ||
        input.segments.length === 0 ||
        input.segments.length > 100 ||
        input.segments.some((segment) => !validSegment(segment)) ||
        (input.voiceId !== undefined && input.voiceId !== null && !identifier(input.voiceId)) ||
        (input.rate !== undefined && (!Number.isInteger(input.rate) || input.rate < -100 || input.rate > 100))
      ) throw new JianyingVoiceoverError()
      const segments = /** @type {{sentence_id: string, text: string}[]} */ (input.segments)
      if (isRunningHubVoiceId(input.voiceId)) {
        if (!ttsStudio) throw new JianyingVoiceoverError()
        try {
          const bundle = await ttsStudio.resolveBundle({
            projectId: input.projectId,
            voiceId: input.voiceId,
            rate: input.rate ?? 0,
            segments: segments.map((segment) => ({
              sentenceId: segment.sentence_id,
              text: segment.text,
            })),
            signal: input.signal,
          })
          return bundle.segments
        } catch (error) {
          if (input.signal?.aborted) throw new JianyingVoiceoverError('JY002_CANCELLED')
          throw new JianyingVoiceoverError(
            error && typeof error === 'object' && 'code' in error
              ? String(error.code)
              : 'JY002_VOICEOVER_AUDIO_MISSING',
          )
        }
      }
      if (isJianyingPresetVoiceId(input.voiceId)) {
        if (!jianyingPresetNarration) throw new JianyingVoiceoverError('JY002_VOICEOVER_AUDIO_MISSING')
        try {
          const jobRoot = resolve(root, input.projectId, input.jobId)
          return await jianyingPresetNarration.resolveSegments({
            projectId: input.projectId,
            jobId: input.jobId,
            voiceId: input.voiceId,
            segments,
            jobRoot,
            signal: input.signal,
          })
        } catch (error) {
          if (input.signal?.aborted) throw new JianyingVoiceoverError('JY002_CANCELLED')
          throw new JianyingVoiceoverError(
            error && typeof error === 'object' && 'code' in error
              ? String(error.code)
              : 'JY002_VOICEOVER_AUDIO_MISSING',
          )
        }
      }
      const jobRoot = resolve(root, input.projectId, input.jobId)
      await mkdir(jobRoot, { recursive: true, mode: 0o700 })
      const output = []
      try {
        for (const [index, segment] of segments.entries()) {
          input.signal?.throwIfAborted()
          const audioId = `audio-${digest(`${segment.sentence_id}\u0000${segment.text}`).slice(0, 24)}`
          const outputPath = resolve(jobRoot, `${index + 1}-${audioId}.wav`)
          let reusable = false
          try {
            const metadata = await stat(outputPath)
            reusable = metadata.isFile() && metadata.size > 0
          } catch {
            reusable = false
          }
          if (!reusable) {
            const temporaryPath = `${outputPath}.${randomUUID()}.tmp`
            try {
              if (typeof input.voiceId === 'string') {
                await synthesizeEdge({
                  text: segment.text,
                  outputPath: temporaryPath,
                  voice: input.voiceId,
                  rate: input.rate ?? 0,
                  signal: input.signal,
                })
              } else {
                await synthesize({
                  text: segment.text,
                  outputPath: temporaryPath,
                  voice,
                  signal: input.signal,
                })
              }
              const metadata = await stat(temporaryPath)
              if (!metadata.isFile() || metadata.size === 0) throw new JianyingVoiceoverError()
              await rename(temporaryPath, outputPath)
            } finally {
              await rm(temporaryPath, { force: true }).catch(() => {})
            }
          }
          output.push({
            sentenceId: segment.sentence_id,
            audioId,
            path: outputPath,
          })
        }
        return output
      } catch (error) {
        await rm(jobRoot, { recursive: true, force: true }).catch(() => {})
        if (error instanceof JianyingVoiceoverError) throw error
        if (input.signal?.aborted) throw new JianyingVoiceoverError('JY002_CANCELLED')
        throw new JianyingVoiceoverError()
      }
    },
    /** @param {{projectId: string, jobId: string}} input */
    async cleanup(input) {
      if (!identifier(input?.projectId) || !identifier(input?.jobId)) return false
      await rm(resolve(root, input.projectId, input.jobId), { recursive: true, force: true })
      return true
    },
  }
}
