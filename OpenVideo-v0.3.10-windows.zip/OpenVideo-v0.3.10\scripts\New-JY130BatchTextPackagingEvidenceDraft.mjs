import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import {
  parseJianyingBatchTextPackagingCatalog,
  selectJianyingBatchTextEvidenceEntries,
} from '../apps/gateway/src/jianying-batch-text-packaging-catalog.mjs'
import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const run = promisify(execFile)
const segmentDurationUs = 2_000_000
const evidenceText = (entry, index) => entry.kind === 'flower'
  ? `OpenVideo 花字候选 ${index + 1}`
  : entry.kind === 'bubble'
    ? `OpenVideo 气泡候选 ${index + 1}`
    : `OpenVideo 贴纸候选 ${index + 1}`

export const buildJianyingBatchEvidenceTimeline = (entries) => {
  const durationUs = entries.length * segmentDurationUs
  const indexed = entries.map((entry, index) => ({
    entry,
    index,
    startUs: index * segmentDurationUs,
  }))
  const titleSegments = indexed.filter(({ entry }) => entry.kind !== 'sticker').map(({ entry, index, startUs }) => ({
    segmentId: `jy130-rich-${index + 1}`,
    kind: 'rich_text',
    capabilityId: entry.capability_id,
    targetRange: { startUs, durationUs: segmentDurationUs },
    text: evidenceText(entry, index),
    styleToken: 'rich-emphasis',
    keyframes: [],
    animationIn: null,
    animationOut: null,
    templateToken: entry.packaging_token,
  }))
  const stickerSegments = indexed.filter(({ entry }) => entry.kind === 'sticker').map(({ entry, index, startUs }) => ({
    segmentId: `jy130-sticker-${index + 1}`,
    kind: 'effect',
    targetRange: { startUs, durationUs: segmentDurationUs },
    capabilityId: entry.capability_id,
    intensity: 1,
    parameters: { packagingToken: entry.packaging_token },
    keyframes: [],
  }))
  const tracks = [
    {
      trackId: 'video-primary',
      order: 0,
      enabled: true,
      locked: false,
      kind: 'video',
      role: 'primary',
      segments: [{
        segmentId: 'jy130-video',
        kind: 'video',
        asset: { authorizationId: 'jy130-auth', assetId: 'jy130-asset', sceneId: 'jy130-scene' },
        sourceRange: { startUs: 0, durationUs },
        targetRange: { startUs: 0, durationUs },
        fit: 'cover',
        volume: 1,
        speed: { numerator: 1, denominator: 1 },
        keyframes: [],
        effects: [],
        audit: { origin: 'editor', candidateId: 'jy130-candidate', instructionFingerprint: null },
        transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
      }],
    },
    {
      trackId: 'voiceover-guide',
      order: 1,
      enabled: true,
      locked: false,
      kind: 'audio',
      role: 'voiceover',
      segments: [],
    },
    {
      trackId: 'title-primary',
      order: 2,
      enabled: true,
      locked: false,
      kind: 'title',
      segments: titleSegments,
    },
    ...(stickerSegments.length > 0 ? [{
      trackId: 'sticker-evidence',
      order: 3,
      enabled: true,
      locked: false,
      kind: 'effect',
      segments: stickerSegments,
    }] : []),
  ]
  const draft = {
    schemaVersion: 1,
    timelineId: 'jy130-batch-text-evidence',
    projectId: 'jy130-batch-text-evidence',
    revision: 1,
    parentRevision: null,
    parentRevisionFingerprint: null,
    status: 'draft',
    createdAt: '2026-08-15T00:00:00.000Z',
    durationUs,
    orientation: 'portrait',
    fps: { numerator: 30, denominator: 1 },
    source: {
      kind: 'editor',
      editPlanFingerprint: 'a'.repeat(64),
      templateFingerprint: null,
      instructionFingerprint: null,
    },
    tracks,
    markers: [],
    capabilityRequirements: computeCapabilityRequirements(tracks),
  }
  return finalizeRichTimeline(sealRichTimeline(draft))
}

const main = async () => {
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const catalogFileName = process.argv.includes('--candidate-catalog')
    ? 'jy131-batch-sticker-bubble-candidate.json'
    : 'jy130-batch-text-packaging-catalog.json'
  const catalog = parseJianyingBatchTextPackagingCatalog(
    JSON.parse(await readFileNoReparse(path.join(dataRoot, 'catalogs', catalogFileName), dataRoot)),
  )
  const evidenceEntries = selectJianyingBatchTextEvidenceEntries(catalog)
  const durationUs = evidenceEntries.length * segmentDurationUs
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true) throw new Error('JY130_PROFILE_UNAVAILABLE')
  const productionRegistry = createEditorCapabilityRegistry({ jianyingProfileId: desktop.profileId })
  const evidenceCapabilities = new Set(evidenceEntries.map((entry) => entry.capability_id))
  const evidenceRegistry = {
    assertWriterCapability: (capabilityId, target) => {
      if (target === 'jianying' && evidenceCapabilities.has(capabilityId)) return {}
      return productionRegistry.assertWriterCapability(capabilityId, target)
    },
    assertAllowedParameters: (...args) => productionRegistry.assertAllowedParameters(...args),
  }
  const pythonModuleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (!pythonModuleRoot || !path.isAbsolute(pythonModuleRoot)) throw new Error('JY002_PATH_PERMISSION_DENIED')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy130-evidence-'))
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const draftId = `OpenVideo-JY130-batch-text-${Date.now()}`
  let writer
  let result
  let released = false
  try {
    await run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', String(durationUs / 1_000_000), '-pix_fmt', 'yuv420p', videoPath])
    const projected = projectRichTimelineToJianyingExport(
      buildJianyingBatchEvidenceTimeline(evidenceEntries),
      {
        jianyingProfileId: desktop.profileId,
        allowAppendTrackFallback: true,
        capabilityRegistry: evidenceRegistry,
      },
    )
    const selectedEntries = evidenceEntries.map((entry) => {
      const selected = catalog.entries.find((candidate) => candidate.packaging_token === entry.packaging_token)
      if (!selected) throw new Error('JY130_SELECTED_TOKEN_NOT_IN_CATALOG')
      return selected
    })
    const titleSegments = projected.packaging.rich_text_segments.map((segment) => {
      const entry = selectedEntries.find((candidate) => candidate.packaging_token === segment.template_token)
      if (!entry) throw new Error('JY130_SELECTED_TOKEN_NOT_IN_CATALOG')
      return {
        text: segment.text,
        target_start_us: segment.target_start_us,
        target_duration_us: segment.target_duration_us,
        ...(entry.kind === 'flower'
          ? { flower_effect_id: entry.effect_id, flower_resource_id: entry.resource_id }
          : { bubble_effect_id: entry.effect_id, bubble_resource_id: entry.resource_id }),
      }
    })
    const stickerSegments = projected.packaging.sticker_segments.map((segment) => {
      const entry = selectedEntries.find((candidate) => candidate.packaging_token === segment.packaging_token)
      if (!entry || entry.kind !== 'sticker') throw new Error('JY130_SELECTED_TOKEN_NOT_IN_CATALOG')
      return {
        resource_id: entry.resource_id,
        target_start_us: segment.target_start_us,
        target_duration_us: segment.target_duration_us,
      }
    })
    const selectedBindings = [
      ...projected.packaging.rich_text_segments.map((segment) => ({
        packaging_token: segment.template_token,
        kind: segment.capability_id === 'text.flower.private' ? 'flower' : 'bubble',
        text: segment.text,
        target_start_us: segment.target_start_us,
        target_duration_us: segment.target_duration_us,
      })),
      ...projected.packaging.sticker_segments.map((segment) => {
        const entryIndex = evidenceEntries.findIndex((entry) => entry.packaging_token === segment.packaging_token)
        if (entryIndex < 0) throw new Error('JY130_SELECTED_TOKEN_NOT_IN_CATALOG')
        return {
          packaging_token: segment.packaging_token,
          kind: 'sticker',
          text: evidenceText(evidenceEntries[entryIndex], entryIndex),
          target_start_us: segment.target_start_us,
          target_duration_us: segment.target_duration_us,
        }
      }),
    ].sort((left, right) => left.target_start_us - right.target_start_us)
    writer = createPyJianyingDraftWriter({
      draftRoot: desktop.draftRoot,
      pythonModuleRoot,
      getRenderOptions: () => ({
        captions: false,
        bgmPath: null,
        subtitleStyle: 'default',
        titleSegments,
        keywordHighlights: [],
        captionSegments: [],
        timelinePackaging: {
          ...projected.packaging,
          sfx_segments: [],
          effect_segments: [],
          sticker_segments: stickerSegments,
          filter_segments: [],
          animation_segments: [],
          mask_segments: [],
          blend_segments: [],
          voiceover_segments: [],
          bgm: { fade_in_us: 0, fade_out_us: 0 },
        },
      }),
    })
    const request = {
      job_id: `job-${draftId}`,
      request_id: `request-${draftId}`,
      output_policy: { draft_id: draftId },
      export_request: { preparation: projected.preparation },
      orientation: 'portrait',
      materials: [{ path: videoPath }],
      voiceovers: [],
    }
    result = await writer.writeDraft(request)
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) {
      throw new Error('JY130_DRAFT_VERIFY_FAILED')
    }
    const encrypted = await readFileNoReparseBuffer(
      path.join(desktop.draftRoot, draftId, 'draft_content.json'),
      desktop.draftRoot,
    )
    const evidenceRoot = path.join(dataRoot, 'evidence', 'jy130-batch-text')
    await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
    await securePrivateRuntimeRoot(evidenceRoot)
    await writeFile(
      path.join(evidenceRoot, 'pending.json'),
      `${JSON.stringify({
        schema_version: 1,
        draft_id: draftId,
        draft_root: desktop.draftRoot,
        profile_id: desktop.profileId,
        app_version: desktop.version,
        catalog_fingerprint: catalog.catalog_fingerprint,
        catalog_file_name: catalogFileName,
        selected_bindings: selectedBindings,
        draft_content_fingerprint_before_manual: createHash('sha256').update(encrypted).digest('hex'),
        required_manual_actions: ['opened', 'edited', 'saved', 'reopened'],
        manual_evidence_verified: false,
      })}\n`,
      { encoding: 'utf8', mode: 0o600 },
    )
    await writer.releaseDraft({ job_id: request.job_id, write_result: result })
    released = true
    process.stdout.write(`${JSON.stringify({
      ok: true,
      manual_open_required: true,
      draft_prefix: 'OpenVideo-JY130-batch-text-',
      candidate_count: catalog.entries.length,
      profile: desktop.profileId,
      version: desktop.version,
    })}\n`)
  } finally {
    if (!released && writer && result) await writer.cleanupDraft({ job_id: `job-${draftId}` }).catch(() => {})
    await rm(mediaRoot, { recursive: true, force: true })
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch((error) => {
    process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY130_EVIDENCE_DRAFT_FAILED' })}\n`)
    process.exitCode = 1
  })
}
