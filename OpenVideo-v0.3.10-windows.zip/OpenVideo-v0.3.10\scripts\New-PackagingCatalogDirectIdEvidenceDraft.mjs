import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { lstat, mkdir, mkdtemp, rename, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { createCapCutCatalogService } from '../apps/gateway/src/jianying-capcut-catalog-service.mjs'
import { projectDirectIdBinding } from '../apps/gateway/src/jianying-capcut-packaging-provider.mjs'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import {
  computePackagingCatalogFingerprint,
  computePackagingResourceToken,
  parsePrivatePackagingResourceIndex,
  serializePrivatePackagingResourceIndex,
} from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import {
  planPrivatePackagingBatch,
  projectPrivatePackagingBatchForWriter,
} from '../apps/gateway/src/jianying-private-batch-packaging.mjs'
import { securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { deriveRenderBundleIdentity } from '../apps/gateway/src/jianying-workbench-bridge.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import {
  acquireJY138GeneratorLock,
  buildJY138EvidenceBindings,
  buildJY138FlowerEvidencePlan,
  buildJY138PrivateBatchEvidenceTimeline,
  buildPrivateBatchEvidenceCandidateIndex,
  createPrivateBatchEvidenceTokenResolver,
} from './New-JY138PrivateBatchEvidenceDraft.mjs'
import compatibilityManifest from '../config/jianying-compatibility.json' with { type: 'json' }

const run = promisify(execFile)
const evidenceRootName = 'packaging-catalog-001-direct-id'
const catalogFileName = 'packaging-catalog-001-direct-id-catalog.json'
const families = Object.freeze(['sticker', 'video_effect', 'flower'])
const segmentDurationUs = 2_000_000

/** @param {unknown} error */
export const publicFailureCode = (error) => {
  const message = typeof error?.message === 'string' ? error.message : ''
  return /^PACKAGING_CATALOG_DIRECT_ID_[A-Z0-9_]+$/u.test(message)
    ? message
    : 'PACKAGING_CATALOG_DIRECT_ID_EVIDENCE_FAILED'
}

/**
 * Resolve one structurally complete private Direct-ID binding per family.
 * Selection is bounded and deterministic within the current signed release.
 * @param {{search: Function, resolvePrivateCandidate: Function}} service
 */
export const selectDirectIdEvidenceCandidates = async (service) => {
  const selected = []
  for (const family of families) {
    let cursor = null
    let found = null
    for (let page = 0; page < 10 && !found; page += 1) {
      const result = await service.search({ family, limit: 100, cursor })
      for (const candidate of result.candidates ?? []) {
        const sourceEntry = await service.resolvePrivateCandidate(candidate.packagingToken)
        const privateBinding = projectDirectIdBinding(sourceEntry)
        if (privateBinding) {
          found = { family, label: candidate.label, tags: candidate.tags, privateBinding }
          break
        }
      }
      cursor = result.next_cursor ?? null
      if (!cursor) break
    }
    if (!found) throw new Error(`PACKAGING_CATALOG_DIRECT_ID_${family.toUpperCase()}_UNAVAILABLE`)
    selected.push(found)
  }
  return Object.freeze(selected)
}

/** @param {ReadonlyArray<Record<string, any>>} selected @param {{profileId: string, version: string}} desktop */
export const buildDirectIdEvidenceIndex = (selected, desktop) => {
  const entries = selected.map(({ family, label, tags, privateBinding }) => Object.freeze({
    packaging_token: computePackagingResourceToken({
      family,
      profileId: desktop.profileId,
      appVersion: desktop.version,
      privateBinding,
    }),
    family,
    label,
    tags,
    state: 'discoverable',
    writer_eligible: false,
    private_binding: privateBinding,
  }))
  return parsePrivatePackagingResourceIndex({
    schema_version: 1,
    profile_id: desktop.profileId,
    app_version: desktop.version,
    entries,
    catalog_fingerprint: computePackagingCatalogFingerprint({
      profileId: desktop.profileId,
      appVersion: desktop.version,
      entries,
    }),
  }, { profileId: desktop.profileId, appVersion: desktop.version })
}

/** @param {string} filePath @param {string} rootPath @param {string} value */
const writePrivateAtomic = async (filePath, rootPath, value) => {
  await mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(path.dirname(filePath))
  const temporary = `${filePath}.${process.pid}.tmp`
  try {
    await writeFile(temporary, value, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await rename(temporary, filePath)
  } finally {
    await rm(temporary, { force: true })
  }
  if (!path.resolve(filePath).startsWith(`${path.resolve(rootPath)}${path.sep}`)) {
    throw new Error('PACKAGING_CATALOG_DIRECT_ID_PRIVATE_ROOT_INVALID')
  }
}

const main = async () => {
  const launcherConfig = await loadLauncherRuntimeConfig()
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  if (desktop?.available !== true) throw new Error('PACKAGING_CATALOG_DIRECT_ID_PROFILE_UNAVAILABLE')
  const { dataRoot } = launcherConfig
  const service = createCapCutCatalogService({ dataRoot })
  const selected = await selectDirectIdEvidenceCandidates(service)
  const discoveryIndex = buildDirectIdEvidenceIndex(selected, desktop)
  const candidateIndex = buildPrivateBatchEvidenceCandidateIndex(discoveryIndex)

  const genericEntries = candidateIndex.entries.filter((entry) =>
    entry.state === 'writer_eligible' && (entry.family === 'sticker' || entry.family === 'video_effect'))
  const requests = genericEntries.map((entry, index) => ({
    packagingToken: entry.packaging_token,
    targetStartUs: index * segmentDurationUs,
    targetDurationUs: segmentDurationUs,
  }))
  const batch = planPrivatePackagingBatch(candidateIndex, requests)
  if (batch.writerPlan.length !== 2 || batch.summary.some((entry) => entry.status !== 'accepted')) {
    throw new Error('PACKAGING_CATALOG_DIRECT_ID_BATCH_UNWRITABLE')
  }
  const flowerPlan = buildJY138FlowerEvidencePlan(candidateIndex, {
    startIndex: batch.writerPlan.length,
    max: 1,
  })
  const evidencePlan = Object.freeze([...batch.writerPlan, ...flowerPlan])
  if (evidencePlan.length !== 3) throw new Error('PACKAGING_CATALOG_DIRECT_ID_BATCH_UNWRITABLE')

  const writerProjection = projectPrivatePackagingBatchForWriter(batch.writerPlan)
  const timeline = buildJY138PrivateBatchEvidenceTimeline(evidencePlan)
  const evidenceCapabilities = new Set(['sticker.named', 'effect.video.named', 'text.flower.private'])
  const productionRegistry = createEditorCapabilityRegistry({ jianyingProfileId: desktop.profileId })
  const evidenceRegistry = {
    assertWriterCapability: (capabilityId, target) => {
      if (target === 'jianying' && (evidenceCapabilities.has(capabilityId) ||
          capabilityId === 'track.insert' || capabilityId === 'track.insert_many')) return {}
      return productionRegistry.assertWriterCapability(capabilityId, target)
    },
    assertAllowedParameters: (...args) => productionRegistry.assertAllowedParameters(...args),
  }
  const projected = projectRichTimelineToJianyingExport(timeline, {
    jianyingProfileId: desktop.profileId,
    capabilityRegistry: evidenceRegistry,
    allowAppendTrackFallback: true,
  })
  const titleSegments = projected.packaging.rich_text_segments.map((segment) => {
    const entry = evidencePlan.find((candidate) =>
      candidate.family === 'flower' && candidate.packagingToken === segment.template_token)
    if (!entry) throw new Error('PACKAGING_CATALOG_DIRECT_ID_FLOWER_UNAVAILABLE')
    return {
      text: segment.text,
      target_start_us: segment.target_start_us,
      target_duration_us: segment.target_duration_us,
      flower_effect_id: entry.privateBinding.effectId,
      flower_resource_id: entry.privateBinding.resourceId,
    }
  })

  const pythonModuleRoot = launcherConfig.pyJianyingDraftRoot
  if (!pythonModuleRoot || !path.isAbsolute(pythonModuleRoot)) {
    throw new Error('PACKAGING_CATALOG_DIRECT_ID_WRITER_UNAVAILABLE')
  }
  const evidenceRoot = path.join(dataRoot, 'evidence', evidenceRootName)
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const generatorLock = path.join(evidenceRoot, '.generator-lock')
  const catalogPath = path.join(dataRoot, 'catalogs', catalogFileName)
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(evidenceRoot)
  await acquireJY138GeneratorLock(generatorLock)
  try {
    try {
      await lstat(pendingPath)
      throw new Error('PACKAGING_CATALOG_DIRECT_ID_PENDING_EXISTS')
    } catch (error) {
      if (error?.message === 'PACKAGING_CATALOG_DIRECT_ID_PENDING_EXISTS') throw error
      if (error?.code !== 'ENOENT') throw error
    }
    await writePrivateAtomic(
      catalogPath,
      dataRoot,
      `${JSON.stringify(serializePrivatePackagingResourceIndex(discoveryIndex))}\n`,
    )

    const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-packaging-catalog-direct-id-'))
    const videoPath = path.join(mediaRoot, 'video.mp4')
    const draftId = `OpenVideo-JY138-private-batch-${Date.now()}`
    const request = {
      job_id: `job-${draftId}`,
      request_id: `request-${draftId}`,
      output_policy: { draft_id: draftId },
      export_request: { preparation: projected.preparation },
      orientation: 'portrait',
      materials: evidencePlan.map(() => ({ path: videoPath })),
      voiceovers: [],
    }
    const timelinePackaging = {
      ...writerProjection,
      private_batch_plan: batch.writerPlan,
      video: [],
      voiceover_segments: [],
      sfx_segments: [],
      audio_effect_segments: [],
      bgm: { fade_in_us: 0, fade_out_us: 0 },
      filter_segments: [],
      chroma_segments: [],
      text_animation_segments: [],
      background_segments: [],
    }
    const writer = createPyJianyingDraftWriter({
      draftRoot: desktop.draftRoot,
      pythonModuleRoot,
      resolvePrivatePackagingToken: createPrivateBatchEvidenceTokenResolver(candidateIndex),
      getRenderOptions: () => ({
        captions: false,
        bgmPath: null,
        subtitleStyle: 'default',
        captionSegments: [],
        titleSegments,
        keywordHighlights: [],
        renderBundleIdentity: deriveRenderBundleIdentity({
          timeline,
          preparation: projected.preparation,
          timelinePackaging,
          desktopProfile: desktop,
          packagingResourceIndex: candidateIndex,
        }),
        timelinePackaging,
      }),
    })
    try {
      await run('ffmpeg', [
        '-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i',
        'color=c=blue:s=360x640:r=30', '-t', String(timeline.durationUs / 1_000_000),
        '-pix_fmt', 'yuv420p', videoPath,
      ])
      const result = await writer.writeDraft(request)
      if (await writer.verifyDraft({
        job_id: request.job_id,
        request: { export_request: request.export_request },
        write_result: result,
      }) !== true) throw new Error('PACKAGING_CATALOG_DIRECT_ID_DRAFT_VERIFY_FAILED')
      if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) {
        throw new Error('PACKAGING_CATALOG_DIRECT_ID_DRAFT_RELEASE_FAILED')
      }
      const owner = JSON.parse(await readFileNoReparse(
        path.join(desktop.draftRoot, draftId, '.openvideo-owner.json'),
        desktop.draftRoot,
      ))
      const encrypted = await readFileNoReparseBuffer(
        path.join(desktop.draftRoot, draftId, 'draft_content.json'),
        desktop.draftRoot,
      )
      await writePrivateAtomic(pendingPath, dataRoot, `${JSON.stringify({
        schema_version: 1,
        draft_id: draftId,
        draft_root: desktop.draftRoot,
        profile_id: desktop.profileId,
        app_version: desktop.version,
        catalog_fingerprint: discoveryIndex.catalogFingerprint,
        bundle_fingerprint: owner.bundle_fingerprint,
        admitted_bindings: buildJY138EvidenceBindings(evidencePlan),
        pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex'),
        media_root: mediaRoot,
      })}\n`)
      process.stdout.write(`${JSON.stringify({
        ok: true,
        draft_name: draftId,
        families: evidencePlan.map((entry) => entry.family),
        placements: evidencePlan.length,
        profile: desktop.profileId,
        version: desktop.version,
        next: 'Open, inspect all three ranges, edit, save, close, reopen, then verify with --catalog-direct-id-evidence and the manual attestation.',
      })}\n`)
    } catch (error) {
      await writer.cleanupDraft({ job_id: request.job_id }).catch(() => {})
      await rm(mediaRoot, { recursive: true, force: true })
      throw error
    }
  } finally {
    await rm(generatorLock, { recursive: true, force: true })
  }
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  main().catch((error) => {
    process.stdout.write(`${JSON.stringify({ ok: false, code: publicFailureCode(error) })}\n`)
    process.exitCode = 1
  })
}
