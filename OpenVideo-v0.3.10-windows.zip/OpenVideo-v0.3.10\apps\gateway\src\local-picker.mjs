import { randomBytes, randomUUID } from 'node:crypto'
import { existsSync, readdirSync, realpathSync, statSync } from 'node:fs'
import { homedir } from 'node:os'
import { basename, dirname, extname, isAbsolute, join, relative, resolve } from 'node:path'

const sessionTtlMs = 15 * 60 * 1000
const maxNodesPerSession = 12_000
const maxChildren = 500
const audioExtensions = new Set(['.aac', '.flac', '.m4a', '.mp3', '.wav'])
const videoExtensions = new Set(['.avi', '.m4v', '.mkv', '.mov', '.mp4', '.webm', '.wmv'])

const blockedNamePattern = /^(?:\$recycle\.bin|system volume information|recovery|windows|program files(?: \(x86\))?|programdata|perflogs)$/iu

export class LocalPickerError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'LocalPickerError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {string} value */
const opaqueId = (value) => typeof value === 'string' && /^[a-z0-9][a-z0-9._:-]{0,159}$/iu.test(value)

/** @param {string} parent @param {string} candidate */
const isInside = (parent, candidate) => {
  const child = relative(resolve(parent), resolve(candidate))
  return child === '' || (!child.startsWith('..') && !isAbsolute(child))
}

/** @param {string} absolutePath */
const isBlockedPath = (absolutePath) => {
  const normalized = resolve(absolutePath)
  const parts = normalized.split(/[\\/]/u).filter(Boolean)
  return parts.some((part) => blockedNamePattern.test(part))
}

/** @param {string} absolutePath */
const safeStat = (absolutePath) => {
  try {
    return statSync(absolutePath)
  } catch {
    return null
  }
}

/** @returns {string[]} */
const listDriveRoots = () => {
  /** @type {string[]} */
  const roots = []
  for (const letter of 'CDEFGHIJKLMNOPQRSTUVWXYZ') {
    const root = `${letter}:\\`
    if (existsSync(root)) roots.push(root)
  }
  return roots
}

/**
 * @param {string} mode
 * @param {string} name
 * @param {import('node:fs').Stats} entryStat
 */
const matchesMode = (mode, name, entryStat) => {
  if (entryStat.isDirectory()) return true
  if (!entryStat.isFile()) return false
  const extension = extname(name).toLowerCase()
  if (mode === 'audio') return audioExtensions.has(extension)
  if (mode === 'video') return videoExtensions.has(extension)
  return false
}

/**
 * @param {{
 *   now?: () => number,
 *   homeDir?: () => string,
 *   listDrives?: () => string[],
 * }} [options]
 */
export const createLocalPickerService = ({
  now = () => Date.now(),
  homeDir = homedir,
  listDrives = listDriveRoots,
} = {}) => {
  /** @type {Map<string, {
   *   createdAt: number,
   *   expiresAt: number,
   *   mode: 'folder' | 'audio' | 'video',
   *   nodes: Map<string, string>,
   * }>} */
  const sessions = new Map()

  const purgeExpired = () => {
    const stamp = now()
    for (const [sessionId, session] of sessions) {
      if (session.expiresAt <= stamp) sessions.delete(sessionId)
    }
  }

  /** @param {string} sessionId */
  const requireSession = (sessionId) => {
    purgeExpired()
    if (!opaqueId(sessionId)) throw new LocalPickerError('LOCAL_PICKER_SESSION_INVALID', 400)
    const session = sessions.get(sessionId)
    if (!session) throw new LocalPickerError('LOCAL_PICKER_SESSION_EXPIRED', 409)
    session.expiresAt = now() + sessionTtlMs
    return session
  }

  /**
   * @param {{mode: 'folder' | 'audio' | 'video', nodes: Map<string, string>}} session
   * @param {string} absolutePath
   */
  const rememberNode = (session, absolutePath) => {
    const resolved = resolve(absolutePath)
    for (const [nodeId, mapped] of session.nodes) {
      if (mapped === resolved) return nodeId
    }
    if (session.nodes.size >= maxNodesPerSession) {
      throw new LocalPickerError('LOCAL_PICKER_SESSION_FULL', 429)
    }
    const nodeId = `node_${randomBytes(12).toString('hex')}`
    session.nodes.set(nodeId, resolved)
    return nodeId
  }

  /**
   * @param {string} absolutePath
   * @param {'folder' | 'audio' | 'video'} mode
   * @param {Map<string, string>} nodes
   * @returns {{nodeId: string, label: string, kind: 'directory' | 'file', selectable: boolean} | null}
   */
  const publicEntry = (absolutePath, mode, nodes) => {
    const stats = safeStat(absolutePath)
    if (!stats) return null
    if (stats.isSymbolicLink?.() || (stats.isFile() === false && stats.isDirectory() === false)) return null
    try {
      if (realpathSync.native(absolutePath) !== resolve(absolutePath) && !stats.isDirectory()) {
        // Keep directories even when junctioned; skip unexpected file link escapes later.
      }
    } catch {
      return null
    }
    const name = basename(absolutePath) || absolutePath
    if (!matchesMode(mode, name, stats)) return null
    if (stats.isDirectory() && isBlockedPath(absolutePath) && !/^[a-z]:\\$/iu.test(absolutePath)) {
      return null
    }
    const nodeId = (() => {
      for (const [id, mapped] of nodes) if (mapped === resolve(absolutePath)) return id
      if (nodes.size >= maxNodesPerSession) throw new LocalPickerError('LOCAL_PICKER_SESSION_FULL', 429)
      const id = `node_${randomBytes(12).toString('hex')}`
      nodes.set(id, resolve(absolutePath))
      return id
    })()
    return {
      nodeId,
      label: /^[a-z]:\\$/iu.test(absolutePath) ? absolutePath.slice(0, 2) : name,
      kind: /** @type {'directory' | 'file'} */ (stats.isDirectory() ? 'directory' : 'file'),
      selectable: mode === 'folder' ? stats.isDirectory() : stats.isFile(),
    }
  }

  return {
    /**
     * @param {{mode?: 'folder' | 'audio' | 'video'}} [input]
     */
    createSession(input = {}) {
      purgeExpired()
      const mode = input.mode === 'audio' || input.mode === 'video' ? input.mode : 'folder'
      const sessionId = `lps_${randomUUID().replace(/-/gu, '')}`
      /** @type {Map<string, string>} */
      const nodes = new Map()
      /** @type {{createdAt: number, expiresAt: number, mode: 'folder' | 'audio' | 'video', nodes: Map<string, string>}} */
      const session = {
        createdAt: now(),
        expiresAt: now() + sessionTtlMs,
        mode,
        nodes,
      }
      const home = resolve(homeDir())
      /** @type {{nodeId: string, label: string, kind: 'directory' | 'file', selectable: boolean}[]} */
      const roots = []
      /** @param {string} absolutePath @param {string} label */
      const pushRoot = (absolutePath, label) => {
        const stats = safeStat(absolutePath)
        if (!stats?.isDirectory()) return
        const nodeId = rememberNode(session, absolutePath)
        roots.push({ nodeId, label, kind: 'directory', selectable: mode === 'folder' })
      }
      pushRoot(join(home, 'Desktop'), '桌面')
      pushRoot(join(home, 'Videos'), '视频')
      pushRoot(join(home, 'Documents'), '文档')
      pushRoot(join(home, 'Downloads'), '下载')
      pushRoot(home, '用户主目录')
      for (const drive of listDrives()) {
        pushRoot(drive, `${drive.slice(0, 2)} 盘`)
      }
      if (roots.length === 0) throw new LocalPickerError('LOCAL_PICKER_ROOTS_UNAVAILABLE', 503)
      sessions.set(sessionId, session)
      return {
        schema_version: 1,
        sessionId,
        mode,
        roots,
      }
    },

    /**
     * @param {{sessionId: string, nodeId: string}} input
     */
    browse(input) {
      if (!isRecord(input) || !opaqueId(input.sessionId) || !opaqueId(input.nodeId)) {
        throw new LocalPickerError('LOCAL_PICKER_INPUT_INVALID', 400)
      }
      const session = requireSession(input.sessionId)
      const absolutePath = session.nodes.get(input.nodeId)
      if (!absolutePath) throw new LocalPickerError('LOCAL_PICKER_NODE_UNKNOWN', 404)
      const stats = safeStat(absolutePath)
      if (!stats?.isDirectory()) throw new LocalPickerError('LOCAL_PICKER_NODE_NOT_DIRECTORY', 400)
      if (isBlockedPath(absolutePath) && !/^[a-z]:\\$/iu.test(absolutePath)) {
        throw new LocalPickerError('LOCAL_PICKER_PATH_BLOCKED', 403)
      }
      /** @type {{nodeId: string, label: string, kind: 'directory' | 'file', selectable: boolean}[]} */
      const entries = []
      let names
      try {
        names = readdirSync(absolutePath, { withFileTypes: true })
      } catch {
        throw new LocalPickerError('LOCAL_PICKER_PERMISSION_DENIED', 403)
      }
      for (const dirent of names) {
        if (entries.length >= maxChildren) break
        if (dirent.isSymbolicLink()) continue
        const childPath = resolve(absolutePath, dirent.name)
        if (!isInside(absolutePath, childPath)) continue
        if (dirent.isDirectory() && blockedNamePattern.test(dirent.name)) continue
        const entry = publicEntry(childPath, session.mode, session.nodes)
        if (entry) entries.push(entry)
      }
      entries.sort((left, right) => {
        if (left.kind !== right.kind) return left.kind === 'directory' ? -1 : 1
        return left.label.localeCompare(right.label, 'zh-CN')
      })
      const parentPath = dirname(absolutePath)
      const parentNodeId = parentPath && parentPath !== absolutePath && existsSync(parentPath)
        ? rememberNode(session, parentPath)
        : null
      return {
        schema_version: 1,
        sessionId: input.sessionId,
        current: {
          nodeId: input.nodeId,
          label: /^[a-z]:\\$/iu.test(absolutePath) ? absolutePath.slice(0, 2) : basename(absolutePath),
          kind: 'directory',
          selectable: session.mode === 'folder',
        },
        parentNodeId,
        entries,
      }
    },

    /**
     * @param {{sessionId: string, nodeId: string, expect: 'directory' | 'file' | 'audio' | 'video' | 'media'}} input
     */
    resolveAbsolutePath(input) {
      if (!isRecord(input) || !opaqueId(input.sessionId) || !opaqueId(input.nodeId)) {
        throw new LocalPickerError('LOCAL_PICKER_INPUT_INVALID', 400)
      }
      const session = requireSession(input.sessionId)
      const absolutePath = session.nodes.get(input.nodeId)
      if (!absolutePath) throw new LocalPickerError('LOCAL_PICKER_NODE_UNKNOWN', 404)
      const stats = safeStat(absolutePath)
      if (!stats) throw new LocalPickerError('LOCAL_PICKER_PATH_MISSING', 404)
      if (input.expect === 'media') {
        if (stats.isDirectory()) {
          // Combined import can accept a folder or a single video.
        } else if (!stats.isFile() || !videoExtensions.has(extname(absolutePath).toLowerCase())) {
          throw new LocalPickerError('LOCAL_PICKER_SELECTION_INVALID', 400)
        }
      } else if (input.expect === 'directory') {
        if (!stats.isDirectory()) throw new LocalPickerError('LOCAL_PICKER_SELECTION_INVALID', 400)
      } else if (!stats.isFile()) {
        throw new LocalPickerError('LOCAL_PICKER_SELECTION_INVALID', 400)
      }
      if (input.expect === 'audio' && !audioExtensions.has(extname(absolutePath).toLowerCase())) {
        throw new LocalPickerError('LOCAL_PICKER_SELECTION_INVALID', 400)
      }
      if (input.expect === 'video' && !videoExtensions.has(extname(absolutePath).toLowerCase())) {
        throw new LocalPickerError('LOCAL_PICKER_SELECTION_INVALID', 400)
      }
      if (isBlockedPath(absolutePath) && input.expect === 'directory' && !/^[a-z]:\\$/iu.test(absolutePath)) {
        throw new LocalPickerError('LOCAL_PICKER_PATH_BLOCKED', 403)
      }
      return resolve(absolutePath)
    },
  }
}

/**
 * @param {{service: ReturnType<typeof createLocalPickerService>}} options
 */
export const createLocalPickerHandler = ({ service }) => async (/** @type {Request} */ request) => {
  const jsonResponse = (/** @type {unknown} */ body, status = 200) => new Response(JSON.stringify(body), {
    status,
    headers: {
      'cache-control': 'no-store',
      'content-type': 'application/json; charset=utf-8',
      'x-content-type-options': 'nosniff',
    },
  })
  const pathname = new URL(request.url).pathname
  try {
    if (pathname === '/api/local-picker/session' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}))
      const mode = isRecord(body) && (body.mode === 'audio' || body.mode === 'video' || body.mode === 'folder')
        ? body.mode
        : 'folder'
      return jsonResponse(service.createSession({ mode }), 201)
    }
    if (pathname === '/api/local-picker/browse' && request.method === 'POST') {
      if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
        return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
      }
      return jsonResponse(service.browse(await request.json()))
    }
    return jsonResponse({ error: { code: 'NOT_FOUND', message: 'Not found.' } }, 404)
  } catch (error) {
    const status = error instanceof LocalPickerError ? error.status : 500
    const code = error instanceof LocalPickerError ? error.code : 'LOCAL_PICKER_UNAVAILABLE'
    return jsonResponse({ error: { code, message: 'Local picker operation failed safely.' } }, status)
  }
}
