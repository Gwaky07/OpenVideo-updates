@echo off
setlocal
rem Switch the console code page to UTF-8 so that paths containing non-ASCII characters
rem are passed through to Bootstrap intact.
chcp 65001 >NUL
cd /d "%~dp0"
set "OPENVIDEO_ROOT=%~dp0"
rem UI-HOTFIX-112:
rem   Double-click opens the product splash immediately. 开屏动画打开后隐藏控制台,
rem   and show it again only when startup fails so the user can read the error.
rem
rem   Resolve the Bootstrap path in cmd.exe, where %~dp0 is defined. PowerShell
rem   -Command does not provide the script-root automatic variable, so relying on it
rem   makes the launcher fail before Bootstrap starts.
rem
rem   OPENVIDEO_LAUNCHER_INTERACTIVE=1 lets Bootstrap hide the console after the
rem   splash opens, and show it again on failure. Script/CI callers can clear
rem   this variable to keep the detached behaviour.
set "OPENVIDEO_LAUNCHER_INTERACTIVE=1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%OPENVIDEO_ROOT%scripts\Bootstrap-OpenVideo.ps1" %*
endlocal
