import { execFile } from 'node:child_process'
import { createRequire } from 'node:module'
import { mkdir, mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { createScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'

const execFileAsync = promisify(execFile)
const require = createRequire(import.meta.url)
const compatibilityManifest = require('../config/jianying-compatibility.json')
const profileId = 'jianying-11-1-provisional'
const prefix = 'openvideo-jy032-audio-volume-'
const leasePath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy032-audio-volume', 'pending.json')

const volumeBinding = (content, expectedValue) => {
  const tracks = (content.tracks ?? []).filter((track) => track?.name === 'voiceover-primary')
  const track = tracks[0]
  const segments = track?.segments ?? []
  const segment = segments[0]
  const collections = (segment?.common_keyframes ?? []).filter((item) => item?.property_type === 'KFTypeVolume')
  const keyframes = collections[0]?.keyframe_list ?? []
  const target = keyframes.filter((item) => item?.time_offset === 1_000_000)
  if (tracks.length !== 1 || segments.length !== 1 || collections.length !== 1 || keyframes.length !== 1 || target.length !== 1 || typeof track?.id !== 'string' || typeof segment?.id !== 'string' || !Array.isArray(target[0]?.values) || target[0].values.length !== 1 || typeof target[0].values[0] !== 'number' || Math.abs(target[0].values[0] - expectedValue) > 0.002) return null
  return { trackId: track.id, segmentId: segment.id }
}

const boundLease = async (desktop) => {
  const lease = JSON.parse(await readFile(leasePath(), 'utf8'))
  if (lease.profileId !== profileId || path.resolve(lease.draftRoot) !== path.resolve(desktop.draftRoot) || !/^OpenVideo-JY032-audio-volume-[0-9]+$/u.test(lease.draftId) || typeof lease.trackId !== 'string' || typeof lease.segmentId !== 'string') throw new Error('JY032_EVIDENCE_BINDING_REQUIRED')
  const resolvedRoot = await realpath(desktop.draftRoot)
  const resolvedDraft = await realpath(path.join(desktop.draftRoot, lease.draftId))
  if (path.dirname(resolvedDraft) !== resolvedRoot) throw new Error('JY032_DRAFT_REPARSE_REJECTED')
  return lease
}

const verifyManual = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  const lease = await boundLease(desktop)
  const temp = await mkdtemp(path.join(tmpdir(), 'jy032-volume-verify-'))
  try {
    const plain = path.join(temp, 'draft.json')
    const source = path.join(desktop.draftRoot, lease.draftId, 'draft_content.json')
    if (path.dirname(await realpath(source)) !== await realpath(path.join(desktop.draftRoot, lease.draftId))) throw new Error('JY032_DRAFT_REPARSE_REJECTED')
    const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(source, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY032_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8'))
    const binding = volumeBinding(content, Math.pow(10, -10.5 / 20))
    if (!binding || binding.trackId !== lease.trackId || binding.segmentId !== lease.segmentId) throw new Error('JY032_VOLUME_MISMATCH')
    const value = Math.pow(10, -10.5 / 20)
    return value
  } finally { await rm(temp, { recursive: true, force: true }) }
}

const cleanup = async () => {
  const lease = JSON.parse(await readFile(leasePath(), 'utf8'))
  if (path.dirname(lease.mediaRoot) !== tmpdir() || !path.basename(lease.mediaRoot).startsWith(prefix)) throw new Error('JY032_MEDIA_ROOT_INVALID')
  await rm(lease.mediaRoot, { recursive: true, force: true }); await rm(leasePath(), { force: true })
}

const createTimeline = () => {
  const timeline = structuredClone(createScaleEvidenceTimeline())
  timeline.tracks.find((track) => track.role === 'primary').segments[0].keyframes = []
  const voiceover = timeline.tracks.find((track) => track.role === 'voiceover').segments[0]
  voiceover.fadeInUs = 0
  voiceover.fadeOutUs = 0
  voiceover.keyframes = [{ capabilityId: 'audio.volume.keyframe', offsetUs: 1_000_000, value: 0.6, interpolation: 'linear' }]
  timeline.status = 'draft'
  delete timeline.contentFingerprint
  delete timeline.revisionFingerprint
  timeline.capabilityRequirements = computeCapabilityRequirements(timeline.tracks)
  return finalizeRichTimeline(sealRichTimeline(timeline))
}

const main = async () => {
  if (process.argv.includes('--verify-manual')) { process.stdout.write(`${JSON.stringify({ ok: true, value: await verifyManual() })}\n`); return }
  if (process.argv.includes('--cleanup')) { await cleanup(); process.stdout.write('{"ok":true,"cleanup_completed":true}\n'); return }
  const desktop = await detectJianyingDesktop({ compatibilityManifest })
  if (desktop?.available !== true || desktop.profileId !== profileId) throw new Error('JY032_PROFILE_UNSUPPORTED')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), prefix))
  let retain = false
  try {
    const videoPath = path.join(mediaRoot, 'video.mp4')
    const audioPath = path.join(mediaRoot, 'voice.wav')
    await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath])
    await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audioPath])
    const projected = projectRichTimelineToJianyingExport(createTimeline(), { jianyingProfileId: profileId })
    const draftId = `OpenVideo-JY032-audio-volume-${Date.now()}`
    const writer = createPyJianyingDraftWriter({
      draftRoot: desktop.draftRoot,
      pythonExecutable: process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE ?? 'python',
      pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT,
      getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments: [], timelinePackaging: { ...projected.packaging, sfx_segments: [], effect_segments: [], sticker_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }),
    })
    const input = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: videoPath }], voiceovers: [{ path: audioPath }] }
    const result = await writer.writeDraft(input)
    if (await writer.verifyDraft({ job_id: input.job_id, request: { export_request: input.export_request }, write_result: result }) !== true) throw new Error('JY032_DRAFT_WRITE_FAILED')
    const content = JSON.parse(await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'), 'utf8'))
    const volume = content.tracks?.find((track) => track.name === 'voiceover-primary')?.segments?.[0]?.common_keyframes?.find((item) => item.property_type === 'KFTypeVolume')
    if (!volume?.keyframe_list?.some((item) => item.time_offset === 1_000_000 && item.values?.[0] === 0.6)) throw new Error('JY032_KEYFRAME_MISSING')
    const leaseRoot = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy032-audio-volume')
    await mkdir(leaseRoot, { recursive: true, mode: 0o700 }); await securePrivateRuntimeRoot(leaseRoot)
    const binding = volumeBinding(content, 0.6)
    if (!binding) throw new Error('JY032_KEYFRAME_BINDING_MISSING')
    await writeFile(leasePath(), `${JSON.stringify({ mediaRoot, draftId, draftRoot: desktop.draftRoot, profileId, ...binding, createdAt: new Date().toISOString() })}\n`, { mode: 0o600 })
    retain = true
    process.stdout.write(`${JSON.stringify({ ok: true, manual_open_required: true, desktop_version: desktop.version, initial_volume: 0.6, keyframe_offset_us: 1_000_000 })}\n`)
  } finally { if (!retain) await rm(mediaRoot, { recursive: true, force: true }) }
}

main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error.message })}\n`); process.exitCode = 1 })
