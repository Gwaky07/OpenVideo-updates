const maximumPromptLength = 100_000

/**
 * @typedef {{
 *   capability: 'text',
 *   messages: {role: 'user', parts: {type: 'text', text: string}[]}[],
 * }} BridgeGatewayRequest
 * @typedef {{
 *   outputText: string,
 *   usage?: {inputTokens: number, outputTokens: number, totalTokens: number},
 * }} BridgeGatewayResult
 */

/** @param {number} status @param {Record<string, unknown>} body */
const json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json' },
})

/** @param {Request} request @returns {Promise<Record<string, any> | null>} */
const readBody = async (request) => {
  try {
    const body = await request.json()
    return body && typeof body === 'object' && !Array.isArray(body) ? body : null
  } catch {
    return null
  }
}

/**
 * @param {{
 *   modelAlias: string,
 *   gateway: {generate: (request: BridgeGatewayRequest) => Promise<BridgeGatewayResult>},
 * }} dependencies
 */
export const createOllamaBridgeHandler = ({ modelAlias, gateway }) => {
  if (!/^[A-Za-z0-9._+-]{16,200}$/u.test(modelAlias)) {
    throw new Error('OPENVIDEO_OLLAMA_MODEL_ALIAS_INVALID')
  }

  /** @param {Request} request @returns {Promise<Response>} */
  return async (request) => {
    if (request.method !== 'POST') return json(404, { error: 'not_found' })
    const body = await readBody(request)
    if (!body || body.model !== modelAlias) return json(404, { error: 'model_not_found' })

    const path = new URL(request.url).pathname
    if (path === '/api/pull') {
      return new Response('{"status":"success"}\n', {
        status: 200,
        headers: { 'content-type': 'application/x-ndjson' },
      })
    }
    if (
      path !== '/api/generate' ||
      body.stream !== false ||
      typeof body.prompt !== 'string' ||
      body.prompt.length === 0 ||
      body.prompt.length > maximumPromptLength
    ) {
      return json(400, { error: 'invalid_request' })
    }

    try {
      const result = await gateway.generate({
        capability: 'text',
        messages: [{ role: 'user', parts: [{ type: 'text', text: body.prompt }] }],
      })
      return json(200, {
        model: modelAlias,
        response: result.outputText,
        done: true,
        prompt_eval_count: result.usage?.inputTokens ?? 0,
        eval_count: result.usage?.outputTokens ?? 0,
      })
    } catch {
      return json(502, { error: 'gateway_unavailable' })
    }
  }
}
