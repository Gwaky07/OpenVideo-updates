import {
  computePackagingCatalogRevisionToken,
  parsePrivatePackagingResourceIndex,
  serializePrivatePackagingResourceIndex,
} from './jianying-packaging-resource-index.mjs'

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 400) => { const error = /** @type {Error & {code?: string, status?: number}} */ (new Error(code)); error.code = code; error.status = status; throw error }
const safeProfile = /^jianying-[a-z0-9-]{1,80}$/u
const safeVersion = /^\d{1,3}(?:\.\d{1,8}){1,4}$/u
const allowedProviders = new Set(['user_draft', 'duo_video_probe', 'capcut_mate_snapshot'])
const allowedIntakeErrors = new Set([
  'NATIVE014_DESKTOP_BINDING_UNAVAILABLE',
  'NATIVE014_PROVIDER_INGEST_FAILED',
  'NATIVE014_PROVIDER_RESULT_INVALID',
  'NATIVE014_EVIDENCE_VERIFICATION_REQUIRED',
  'NATIVE014_CATALOG_FINGERPRINT_MISMATCH',
  'NATIVE017_DRAFT_AUTHORIZATION_INVALID',
  'NATIVE017_DRAFT_AUTHORIZATION_REQUIRED',
  'NATIVE017_DRAFT_AUTHORIZATION_UNAVAILABLE',
  'NATIVE017_DRAFT_SOURCE_INVALID',
  'NATIVE017_DRAFT_SOURCE_UNAVAILABLE',
  'NATIVE017_DRAFT_EXTRACTION_UNAVAILABLE',
  'NATIVE017_DRAFT_DECODER_UNAVAILABLE',
  'NATIVE017_DRAFT_DESKTOP_BINDING_UNAVAILABLE',
  'NATIVE017_DRAFT_CATALOG_INVALID',
  'NATIVE017_DRAFT_CATALOG_FINGERPRINT_MISMATCH',
  'NATIVE017_DRAFT_SOURCE_FINGERPRINT_INVALID',
  'NATIVE017_DRAFT_SOURCE_CHANGED',
  'NATIVE017_DRAFT_CHANGED',
  'NATIVE017_DRAFT_DECODER_UNSUPPORTED_VERSION',
  'NATIVE017_DRAFT_DESKTOP_BINDING_INVALID',
  'NATIVE017_DRAFT_SOURCE_TOO_LARGE',
  'NATIVE017_DRAFT_SOURCE_REPARSE_REJECTED',
])

/**
 * Persist a provider-assisted discovery catalog inside the private runtime
 * root. This service deliberately accepts only discovery-only intake output;
 * evidence admission remains owned by the signed same-draft registry path.
 */
/**
 * @param {{intake: {ingest: (payload: unknown) => Promise<Record<string, any>>}, persist: (input: {catalog: Record<string, any>}) => Promise<unknown>}} dependencies
 */
export const createProviderAssistedCatalogService = ({ intake, persist }) => {
  if (!isRecord(intake) || typeof intake.ingest !== 'function' || typeof persist !== 'function') {
    fail('NATIVE015_DEPENDENCIES_INVALID')
  }
  return Object.freeze({
    /** @param {unknown} payload */
    ingest: async (payload) => {
      /** @type {Record<string, any> | undefined} */
      let result
      try { result = await intake.ingest(payload) } catch (error) {
        const code = isRecord(error) && typeof error.code === 'string' ? error.code : ''
        const status = isRecord(error) && typeof error.status === 'number' ? error.status : 503
        if (allowedIntakeErrors.has(code)) fail(code, status)
        fail('NATIVE015_INTAKE_FAILED')
      }
      if (!isRecord(result) || typeof result.provider_id !== 'string' || !allowedProviders.has(result.provider_id) || result.state !== 'discovery_only' ||
          typeof result.profile_id !== 'string' || !safeProfile.test(result.profile_id) ||
          typeof result.app_version !== 'string' || !safeVersion.test(result.app_version) ||
          typeof result.catalog_fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(result.catalog_fingerprint) ||
          (result.provider_id !== 'capcut_mate_snapshot' && !result.index)) {
        fail('NATIVE015_DISCOVERY_RESULT_INVALID')
      }
      if (result.provider_id === 'capcut_mate_snapshot') {
        if (!Number.isSafeInteger(result.entries) || result.entries < 1 || !Number.isSafeInteger(result.shards) || result.shards < 1 ||
            !Array.isArray(result.families) || result.families.some((family) => typeof family !== 'string') || result.index !== undefined) {
          fail('NATIVE015_DISCOVERY_RESULT_INVALID')
        }
        return Object.freeze({
          schema_version: 1,
          status: 'discovery_only',
          provider_id: result.provider_id,
          profile_id: result.profile_id,
          app_version: result.app_version,
          catalog_revision_token: computePackagingCatalogRevisionToken(result.catalog_fingerprint),
          entries: result.entries,
          families: Object.freeze([...new Set(result.families)].sort()),
          shards: result.shards,
        })
      }
      /** @type {Record<string, any> | null} */
      let serialized = null
      try { serialized = serializePrivatePackagingResourceIndex(result.index) } catch { fail('NATIVE015_DISCOVERY_RESULT_INVALID') }
      if (!serialized) fail('NATIVE015_DISCOVERY_RESULT_INVALID')
      if (serialized.profile_id !== result.profile_id || serialized.app_version !== result.app_version ||
          serialized.catalog_fingerprint !== result.catalog_fingerprint) {
        fail('NATIVE015_DISCOVERY_RESULT_INVALID')
      }
      try {
        const reparsed = parsePrivatePackagingResourceIndex(serialized, {
          profileId: result.profile_id,
          appVersion: result.app_version,
        })
        if (reparsed.catalogFingerprint !== result.catalog_fingerprint ||
            JSON.stringify(serializePrivatePackagingResourceIndex(reparsed)) !== JSON.stringify(serialized)) {
          fail('NATIVE015_DISCOVERY_RESULT_INVALID')
        }
      } catch (error) {
        if (isRecord(error) && error.code === 'NATIVE015_DISCOVERY_RESULT_INVALID') throw error
        fail('NATIVE015_DISCOVERY_RESULT_INVALID')
      }
      const entries = /** @type {Record<string, any>[]} */ (serialized.entries)
      if (entries.some((entry) => entry?.writer_eligible === true || entry?.state === 'writer_eligible')) {
        fail('NATIVE015_DISCOVERY_ONLY_REQUIRED')
      }
      try {
        await persist({ catalog: serialized })
      } catch {
        fail('NATIVE015_PERSIST_FAILED')
      }
      return Object.freeze({
        schema_version: 1,
        status: 'discovery_only',
        provider_id: result.provider_id,
        profile_id: serialized.profile_id,
        app_version: serialized.app_version,
        catalog_revision_token: computePackagingCatalogRevisionToken(serialized.catalog_fingerprint),
        entries: entries.length,
        families: Object.freeze([...new Set(entries.map((entry) => entry.family))].sort()),
      })
    },
  })
}
