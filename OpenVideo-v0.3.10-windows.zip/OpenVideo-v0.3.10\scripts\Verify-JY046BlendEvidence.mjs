import { readFile, mkdtemp, mkdir, rm, unlink, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import path from 'node:path'
import os from 'node:os'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { parseJianyingBlendCatalog } from '../apps/gateway/src/jianying-blend-catalog.mjs'

const manifest = (await import('../config/jianying-compatibility.json', { with: { type: 'json' } })).default
const main = async () => {
  const root = loadLocalRuntimeConfig().dataRoot
  const evidenceRoot = path.join(root, 'evidence', 'jy046-blend')
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  const lease = JSON.parse(await readFile(pendingPath, 'utf8'))
  if (lease?.schema_version !== 3 || process.env.OPENVIDEO_JY046_MANUAL_ATTESTATION !== 'opened-edited-saved-reopened') {
    throw new Error('JY046_MANUAL_EVIDENCE_REQUIRED')
  }
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== lease.profileId) throw new Error('JY046_PROFILE_MISMATCH')
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), 'openvideo-jy046-verify-'))
  try {
    const plain = path.join(tempRoot, 'draft_content.json')
    const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
      .ensurePlaintextFile(path.join(lease.draftRoot, lease.draftId, 'draft_content.json'), plain)
    const encryptedBytes = await readFile(path.join(lease.draftRoot, lease.draftId, 'draft_content.json'))
    const postOpenFingerprint = createHash('sha256').update(encryptedBytes).digest('hex')
    const content = JSON.parse(await readFile(plain, 'utf8'))
    const blends = Array.isArray(content?.materials?.effects)
      ? content.materials.effects.filter((effect) => effect?.type === 'mix_mode')
      : []
    const catalog = parseJianyingBlendCatalog(JSON.parse(await readFile(path.join(root, 'catalogs', 'jy046-blend-catalog.json'), 'utf8')))
    const expected = catalog?.entries.find((entry) => entry.blend_token === lease.expectedPostBlendToken)
    const blend = blends[0]
    const attached = (content?.tracks ?? []).filter((track) => track?.type === 'video')
      .flatMap((track) => track?.segments ?? [])
      .some((segment) => (segment?.target_timerange?.start ?? 0) === lease.targetStartUs && segment?.target_timerange?.duration === lease.targetDurationUs && Array.isArray(segment?.extra_material_refs) && segment.extra_material_refs.includes(blend?.id))
    const encryptedDraft = (meta.scheme ?? meta.decryptedFrom) === 'encrypt_v2'
    const ok = encryptedDraft && blends.length === 1 && expected?.resource_id === blend?.resource_id && expected.resource_id !== lease.expectedResourceId && attached && postOpenFingerprint !== lease.preOpenFingerprint
    if (ok) {
      await mkdir(evidenceRoot, { recursive: true })
      await writeFile(path.join(evidenceRoot, 'verified.json'), JSON.stringify({ schema_version: 1, capability_id: 'blend.video.named', profile_id: lease.profileId, manual_attestation: 'opened-edited-saved-reopened', post_open_changed: true, mix_mode_count: 1, attached: true }), { encoding: 'utf8', mode: 0o600 })
      await rm(lease.mediaRoot, { recursive: true, force: true })
      await unlink(pendingPath)
    }
    process.stdout.write(JSON.stringify(ok
      ? { ok: true, scheme: 'encrypt_v2', mixModeCount: 1, attached: true, temporaryMediaCleaned: true }
      : { ok: false, code: 'JY046_BLEND_EVIDENCE_INVALID', mixModeCount: blends.length, attached: Boolean(attached) }) + '\n')
  } finally {
    await rm(tempRoot, { recursive: true, force: true })
  }
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY046_VERIFY_FAILED' }) + '\n'); process.exitCode = 1 })
