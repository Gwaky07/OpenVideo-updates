import { hasSensitiveDirectorText, isEditPlan } from './director-contracts.mjs'
import { assertPackagingTextLayout } from './packaging-text-layout.mjs'

const microsecondsPerSecond = 1_000_000
const maxIdentifierLength = 180
const maxTimelineSegments = 100
const unresolvedItemsMessage = 'Draft preparation contains unresolved storyboard items.'
const emptyTimelineMessage = 'Draft preparation contains no selected video segments.'

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {Record<string, unknown>} value @param {string[]} allowed */
const hasExactKeys = (value, allowed) =>
  Object.keys(value).length === allowed.length &&
  Object.keys(value).every((key) => allowed.includes(key)) &&
  allowed.every((key) => Object.hasOwn(value, key))

/** @param {string} value */
const hasDriveLetterPrefix = (value) =>
  value.length > 1 && value.charCodeAt(1) === 58 && /^[a-z]$/iu.test(value.charAt(0))

/** @param {string} value */
const hasUnsafeIdentifierCharacter = (value) =>
  Array.from(value).some((character) => {
    const code = character.charCodeAt(0)
    return character === String.fromCharCode(92) || character === '/' || code <= 31
  })

/** @param {unknown} value */
const isSafeIdentifier = (value) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= maxIdentifierLength &&
  value === value.trim() &&
  !hasUnsafeIdentifierCharacter(value) &&
  !hasDriveLetterPrefix(value) &&
  !/^file:/iu.test(value) &&
  !hasSensitiveDirectorText(value)

/** @param {unknown} value */
const isSafeVoiceoverText = (value) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= 20_000 &&
  value === value.trim() &&
  !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(value) &&
  !hasSensitiveDirectorText(value)

/** @param {unknown} value */
const isSafeTimelineInteger = (value) =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0

/** @param {unknown} value */
const isPositiveTimelineInteger = (value) =>
  typeof value === 'number' && isSafeTimelineInteger(value) && value > 0

/** @param {unknown} value */
const isUnitInterval = (value) =>
  typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1

/** @param {unknown} value */
const isPackagingVoiceoverFade = (value) =>
  isRecord(value) &&
  (hasExactKeys(value, ['segment_id', 'fade_in_us', 'fade_out_us']) ||
    hasExactKeys(value, ['segment_id', 'fade_in_us', 'fade_out_us', 'keyframes'])) &&
  isSafeIdentifier(value.segment_id) &&
  isSafeTimelineInteger(value.fade_in_us) &&
  isSafeTimelineInteger(value.fade_out_us) &&
  (value.keyframes === undefined || (Array.isArray(value.keyframes) && value.keyframes.every((keyframe) =>
    isRecord(keyframe) &&
    hasExactKeys(keyframe, ['capability_id', 'offset_us', 'value', 'interpolation']) &&
    keyframe.capability_id === 'audio.volume.keyframe' &&
    isSafeTimelineInteger(keyframe.offset_us) &&
    isUnitInterval(keyframe.value) &&
    keyframe.interpolation === 'linear',
  )))

/** @param {unknown} value */
const isPackagingBgm = (value) =>
  isRecord(value) &&
  hasExactKeys(value, [
    'segment_id', 'audio_token', 'capability_id', 'volume',
    'target_start_us', 'target_duration_us', 'fade_in_us', 'fade_out_us',
  ]) &&
  isSafeIdentifier(value.segment_id) &&
  isSafeIdentifier(value.audio_token) &&
  value.capability_id === 'audio.bgm.local' &&
  isUnitInterval(value.volume) &&
  isSafeTimelineInteger(value.target_start_us) &&
  isPositiveTimelineInteger(value.target_duration_us) &&
  isSafeTimelineInteger(value.fade_in_us) &&
  isSafeTimelineInteger(value.fade_out_us) &&
  typeof value.fade_in_us === 'number' &&
  typeof value.fade_out_us === 'number' &&
  typeof value.target_duration_us === 'number' &&
  value.fade_in_us <= value.target_duration_us &&
  value.fade_out_us <= value.target_duration_us

/** @param {unknown} value */
const isRange = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, ['start', 'duration'])) return false
  if (typeof value.start !== 'number' || typeof value.duration !== 'number') return false
  return (
    isSafeTimelineInteger(value.start) &&
    isPositiveTimelineInteger(value.duration) &&
    Number.isSafeInteger(value.start + value.duration)
  )
}

/** @param {unknown} value */
const isMaterialReference = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['asset_id', 'scene_id', 'candidate_id']) &&
  isSafeIdentifier(value.asset_id) &&
  isSafeIdentifier(value.scene_id) &&
  isSafeIdentifier(value.candidate_id)

/** @param {unknown} value */
const isVideoSegment = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['segment_id', 'sentence_id', 'order', 'material_ref', 'source_range', 'target_range']) &&
  isSafeIdentifier(value.segment_id) &&
  isSafeIdentifier(value.sentence_id) &&
  typeof value.order === 'number' &&
  Number.isInteger(value.order) &&
  value.order > 0 &&
  value.order <= maxTimelineSegments &&
  isMaterialReference(value.material_ref) &&
  isRange(value.source_range) &&
  isRange(value.target_range)

/** @param {unknown} value */
const isVoiceoverSegment = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['segment_id', 'sentence_id', 'order', 'text', 'target_range']) &&
  isSafeIdentifier(value.segment_id) &&
  isSafeIdentifier(value.sentence_id) &&
  typeof value.order === 'number' &&
  Number.isInteger(value.order) &&
  value.order > 0 &&
  value.order <= maxTimelineSegments &&
  isSafeVoiceoverText(value.text) &&
  isRange(value.target_range)

/** @param {unknown} value */
const isBlockedItem = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['sentence_id', 'order', 'code']) &&
  isSafeIdentifier(value.sentence_id) &&
  typeof value.order === 'number' &&
  Number.isInteger(value.order) &&
  value.order > 0 &&
  value.order <= maxTimelineSegments &&
  value.code === 'NEEDS_CAPTURE'

/** @param {unknown} left @param {unknown} right */
const rangesEqual = (left, right) =>
  isRecord(left) &&
  isRecord(right) &&
  left.start === right.start &&
  left.duration === right.duration

/** @param {unknown} left @param {unknown} right @returns {boolean} */
const valuesEqual = (left, right) => {
  if (left === right) return true
  if (Array.isArray(left) || Array.isArray(right)) {
    return (
      Array.isArray(left) &&
      Array.isArray(right) &&
      left.length === right.length &&
      left.every((entry, index) => valuesEqual(entry, right[index]))
    )
  }
  if (!isRecord(left) || !isRecord(right)) return false
  const leftKeys = Object.keys(left)
  const rightKeys = Object.keys(right)
  return (
    leftKeys.length === rightKeys.length &&
    leftKeys.every((key) => Object.hasOwn(right, key) && valuesEqual(left[key], right[key]))
  )
}

/** @param {unknown} value */
export const isJianyingDraftPreparation = (value) => {
  if (!isRecord(value)) return false
  if (
    !hasExactKeys(value, [
      'schema_version',
      'kind',
      'preparation_id',
      'source_plan_id',
      'project_id',
      'timeline',
      'blocked_items',
    ]) ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_draft_preparation' ||
    !isSafeIdentifier(value.preparation_id) ||
    !isSafeIdentifier(value.source_plan_id) ||
    !isSafeIdentifier(value.project_id) ||
    !Array.isArray(value.blocked_items) ||
    value.blocked_items.length > maxTimelineSegments ||
    !isRecord(value.timeline) ||
    !hasExactKeys(value.timeline, ['timebase', 'duration', 'tracks']) ||
    value.timeline.timebase !== 'microseconds' ||
    !isSafeTimelineInteger(value.timeline.duration) ||
    !Array.isArray(value.timeline.tracks) ||
    value.timeline.tracks.length !== 2
  ) {
    return false
  }

  const [videoTrack, voiceoverTrack] = value.timeline.tracks
  if (
    !isRecord(videoTrack) ||
    !hasExactKeys(videoTrack, ['track_id', 'type', 'segments']) ||
    videoTrack.track_id !== 'video-primary' ||
    videoTrack.type !== 'video' ||
    !Array.isArray(videoTrack.segments) ||
    videoTrack.segments.length > maxTimelineSegments ||
    !isRecord(voiceoverTrack) ||
    !hasExactKeys(voiceoverTrack, ['track_id', 'type', 'segments']) ||
    voiceoverTrack.track_id !== 'voiceover-guide' ||
    voiceoverTrack.type !== 'voiceover_guide' ||
    !Array.isArray(voiceoverTrack.segments) ||
    voiceoverTrack.segments.length !== videoTrack.segments.length
  ) {
    return false
  }

  const selectedSentenceIds = new Set()
  const sourceOrders = new Set()
  const materialKeys = new Set()
  let cursor = 0
  let previousSelectedOrder = 0
  for (let index = 0; index < videoTrack.segments.length; index += 1) {
    const videoSegment = videoTrack.segments[index]
    const voiceoverSegment = voiceoverTrack.segments[index]
    if (!isVideoSegment(videoSegment) || !isVoiceoverSegment(voiceoverSegment)) return false
    const video = /** @type {Record<string, unknown>} */ (videoSegment)
    const voiceover = /** @type {Record<string, unknown>} */ (voiceoverSegment)
    const videoOrder = /** @type {number} */ (video.order)
    const targetRange = /** @type {Record<string, unknown>} */ (video.target_range)
    const material = /** @type {Record<string, unknown>} */ (video.material_ref)
    const materialKey = `${material.asset_id}\u0000${material.scene_id}`
    if (
       video.sentence_id !== voiceover.sentence_id ||
       video.order !== voiceover.order ||
       videoOrder <= previousSelectedOrder ||
       selectedSentenceIds.has(video.sentence_id) ||
       sourceOrders.has(videoOrder) ||
      materialKeys.has(materialKey) ||
      !rangesEqual(video.target_range, voiceover.target_range) ||
      targetRange.start !== cursor
    ) {
      return false
    }
    selectedSentenceIds.add(video.sentence_id)
    sourceOrders.add(videoOrder)
    materialKeys.add(materialKey)
    previousSelectedOrder = videoOrder
    cursor += /** @type {number} */ (targetRange.duration)
    if (!Number.isSafeInteger(cursor)) return false
  }
  if (cursor !== value.timeline.duration) return false

  let previousOrder = 0
  const blockedSentenceIds = new Set()
  for (const blockedItem of value.blocked_items) {
    if (!isBlockedItem(blockedItem)) return false
    const blocked = /** @type {Record<string, unknown>} */ (blockedItem)
    if (
      /** @type {number} */ (blocked.order) <= previousOrder ||
      selectedSentenceIds.has(blocked.sentence_id) ||
      blockedSentenceIds.has(blocked.sentence_id) ||
      sourceOrders.has(blocked.order)
    ) {
      return false
    }
    previousOrder = /** @type {number} */ (blocked.order)
    blockedSentenceIds.add(blocked.sentence_id)
    sourceOrders.add(blocked.order)
  }
  const totalItems = selectedSentenceIds.size + blockedSentenceIds.size
  return (
    sourceOrders.size === totalItems &&
    Array.from({ length: totalItems }, (_, index) => index + 1).every((order) => sourceOrders.has(order))
  )
}

/** @param {number} seconds */
const toTimelineInteger = (seconds) => {
  const value = Math.round(seconds * microsecondsPerSecond)
  if (!isSafeTimelineInteger(value)) throw new JianyingDraftContractError('draft_time_out_of_range')
  return value
}

export class JianyingDraftContractError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingDraftContractError'
    this.code = code
  }
}

/** @param {unknown} editPlan */
export const buildJianyingDraftPreparation = (editPlan) => {
  if (!isEditPlan(editPlan)) throw new JianyingDraftContractError('invalid_edit_plan')
  const plan = /** @type {Record<string, unknown>} */ (editPlan)
  const videoSegments = []
  const voiceoverSegments = []
  const blockedItems = []
  let cursor = 0

  for (const entry of /** @type {Record<string, unknown>[]} */ (plan.items)) {
    if (entry.status === 'needs_capture') {
      blockedItems.push({ sentence_id: entry.sentence_id, order: entry.order, code: 'NEEDS_CAPTURE' })
      continue
    }
    const candidate = /** @type {Record<string, unknown>} */ (
      /** @type {Record<string, unknown>[]} */ (entry.candidates)[0]
    )
    const sourceStart = toTimelineInteger(/** @type {number} */ (candidate.start))
    const sourceEnd = toTimelineInteger(/** @type {number} */ (candidate.end))
    const duration = sourceEnd - sourceStart
    if (!isPositiveTimelineInteger(duration)) {
      throw new JianyingDraftContractError('draft_time_precision_exceeded')
    }
    const targetRange = { start: cursor, duration }
    videoSegments.push({
      segment_id: `video-${entry.sentence_id}`,
      sentence_id: entry.sentence_id,
      order: entry.order,
      material_ref: {
        asset_id: candidate.asset_id,
        scene_id: candidate.scene_id,
        candidate_id: candidate.candidate_id,
      },
      source_range: { start: sourceStart, duration },
      target_range: targetRange,
    })
    voiceoverSegments.push({
      segment_id: `voiceover-${entry.sentence_id}`,
      sentence_id: entry.sentence_id,
      order: entry.order,
      text: entry.voiceover_text,
      target_range: { ...targetRange },
    })
    cursor += duration
    if (!Number.isSafeInteger(cursor)) throw new JianyingDraftContractError('draft_time_out_of_range')
  }

  const preparation = {
    schema_version: 1,
    kind: 'jianying_draft_preparation',
    preparation_id: `jianying-${plan.plan_id}`,
    source_plan_id: plan.plan_id,
    project_id: plan.project_id,
    timeline: {
      timebase: 'microseconds',
      duration: cursor,
      tracks: [
        { track_id: 'video-primary', type: 'video', segments: videoSegments },
        { track_id: 'voiceover-guide', type: 'voiceover_guide', segments: voiceoverSegments },
      ],
    },
    blocked_items: blockedItems,
  }
  if (!isJianyingDraftPreparation(preparation)) {
    throw new JianyingDraftContractError('invalid_draft_preparation')
  }
  return preparation
}

/** @param {unknown} editPlan @param {unknown} preparation */
const matchesCanonicalPreparation = (editPlan, preparation) => {
  if (!isEditPlan(editPlan) || !isJianyingDraftPreparation(preparation)) return false
  try {
    return valuesEqual(buildJianyingDraftPreparation(editPlan), preparation)
  } catch {
    return false
  }
}

/** @param {unknown} value */
const isPreflightError = (value) => {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ['code', 'message', 'sentence_ids']) ||
    !Array.isArray(value.sentence_ids) ||
    value.sentence_ids.some((sentenceId) => !isSafeIdentifier(sentenceId))
  ) {
    return false
  }
  const sentenceIds = /** @type {string[]} */ (value.sentence_ids)
  if (new Set(sentenceIds).size !== sentenceIds.length) return false
  if (value.code === 'UNRESOLVED_ITEMS') {
    return value.message === unresolvedItemsMessage && sentenceIds.length > 0
  }
  return value.code === 'EMPTY_TIMELINE' && value.message === emptyTimelineMessage && sentenceIds.length === 0
}

/** @param {unknown} value */
const isPreflightSummary = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['video_segments', 'voiceover_segments', 'duration']) &&
  typeof value.video_segments === 'number' &&
  Number.isInteger(value.video_segments) &&
  value.video_segments >= 0 &&
  value.video_segments <= maxTimelineSegments &&
  typeof value.voiceover_segments === 'number' &&
  Number.isInteger(value.voiceover_segments) &&
  value.voiceover_segments === value.video_segments &&
  isSafeTimelineInteger(value.duration)

/** @param {unknown} value */
export const isJianyingDraftPreflightReport = (value) => {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, [
      'schema_version',
      'kind',
      'preparation_id',
      'ready',
      'errors',
      'warnings',
      'summary',
    ]) ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_draft_preflight_report' ||
    !isSafeIdentifier(value.preparation_id) ||
    typeof value.ready !== 'boolean' ||
    !Array.isArray(value.errors) ||
    value.errors.length > 2 ||
    value.errors.some((error) => !isPreflightError(error)) ||
    !Array.isArray(value.warnings) ||
    value.warnings.length !== 0 ||
    !isPreflightSummary(value.summary)
  ) {
    return false
  }
  const errorCodes = value.errors.map((error) => /** @type {Record<string, unknown>} */ (error).code)
  return new Set(errorCodes).size === errorCodes.length && value.ready === (value.errors.length === 0)
}

/** @param {unknown} editPlan @param {unknown} preparation */
export const preflightJianyingDraftPreparation = (editPlan, preparation) => {
  if (!isEditPlan(editPlan)) {
    throw new JianyingDraftContractError('invalid_edit_plan')
  }
  if (!isJianyingDraftPreparation(preparation)) {
    throw new JianyingDraftContractError('invalid_draft_preparation')
  }
  if (!matchesCanonicalPreparation(editPlan, preparation)) {
    throw new JianyingDraftContractError('draft_preparation_mismatch')
  }
  const draft = /** @type {Record<string, unknown>} */ (preparation)
  const timeline = /** @type {Record<string, unknown>} */ (draft.timeline)
  const tracks = /** @type {Record<string, unknown>[]} */ (timeline.tracks)
  const videoSegments = /** @type {unknown[]} */ (tracks[0].segments)
  const voiceoverSegments = /** @type {unknown[]} */ (tracks[1].segments)
  const blockedItems = /** @type {Record<string, unknown>[]} */ (draft.blocked_items)
  const errors = []
  if (blockedItems.length > 0) {
    errors.push({
      code: 'UNRESOLVED_ITEMS',
      message: unresolvedItemsMessage,
      sentence_ids: blockedItems.map((item) => item.sentence_id),
    })
  }
  if (videoSegments.length === 0) {
    errors.push({ code: 'EMPTY_TIMELINE', message: emptyTimelineMessage, sentence_ids: [] })
  }
  const report = {
    schema_version: 1,
    kind: 'jianying_draft_preflight_report',
    preparation_id: draft.preparation_id,
    ready: errors.length === 0,
    errors,
    warnings: [],
    summary: {
      video_segments: videoSegments.length,
      voiceover_segments: voiceoverSegments.length,
      duration: timeline.duration,
    },
  }
  if (!isJianyingDraftPreflightReport(report)) {
    throw new JianyingDraftContractError('invalid_draft_preflight_report')
  }
  return report
}

/** @param {unknown} editPlan @param {unknown} preparation @param {unknown} report */
const matchesCanonicalPreflight = (editPlan, preparation, report) => {
  if (!matchesCanonicalPreparation(editPlan, preparation) || !isJianyingDraftPreflightReport(report)) {
    return false
  }
  const canonical = preflightJianyingDraftPreparation(editPlan, preparation)
  const candidate = /** @type {Record<string, unknown>} */ (report)
  const canonicalSummary = /** @type {Record<string, unknown>} */ (canonical.summary)
  const candidateSummary = /** @type {Record<string, unknown>} */ (candidate.summary)
  const canonicalErrors = /** @type {Record<string, unknown>[]} */ (canonical.errors)
  const candidateErrors = /** @type {Record<string, unknown>[]} */ (candidate.errors)
  return (
    candidate.preparation_id === canonical.preparation_id &&
    candidate.ready === canonical.ready &&
    candidateSummary.video_segments === canonicalSummary.video_segments &&
    candidateSummary.voiceover_segments === canonicalSummary.voiceover_segments &&
    candidateSummary.duration === canonicalSummary.duration &&
    candidateErrors.length === canonicalErrors.length &&
    candidateErrors.every((error, index) => {
      const expected = canonicalErrors[index]
      const sentenceIds = /** @type {string[]} */ (error.sentence_ids)
      const expectedSentenceIds = /** @type {string[]} */ (expected.sentence_ids)
      return (
        error.code === expected.code &&
        error.message === expected.message &&
        sentenceIds.length === expectedSentenceIds.length &&
        sentenceIds.every((sentenceId, sentenceIndex) => sentenceId === expectedSentenceIds[sentenceIndex])
      )
    })
  )
}

/** @param {unknown} value */
const isPackagingMask = (value) => isRecord(value) &&
  hasExactKeys(value, ['segment_id', 'mask_token', 'capability_id', 'target_start_us', 'target_duration_us', 'size']) &&
  typeof value.segment_id === 'string' &&
  typeof value.mask_token === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.mask_token) &&
  value.capability_id === 'mask.video.named' &&
  typeof value.target_start_us === 'number' &&
  typeof value.target_duration_us === 'number' &&
  Number.isSafeInteger(value.target_start_us) && value.target_start_us >= 0 &&
  Number.isSafeInteger(value.target_duration_us) && value.target_duration_us > 0 &&
  typeof value.size === 'number' && Number.isFinite(value.size) && value.size > 0 && value.size <= 1

/** @param {unknown} value */
const isPackagingBlend = (value) => isRecord(value) &&
  hasExactKeys(value, ['segment_id', 'blend_token', 'capability_id', 'target_start_us', 'target_duration_us']) &&
  typeof value.segment_id === 'string' &&
  typeof value.blend_token === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.blend_token) &&
  value.capability_id === 'blend.video.named' &&
  typeof value.target_start_us === 'number' &&
  typeof value.target_duration_us === 'number' &&
  Number.isSafeInteger(value.target_start_us) && value.target_start_us >= 0 &&
  Number.isSafeInteger(value.target_duration_us) && value.target_duration_us > 0

/** @param {unknown} value */
const isPackagingFilter = (value) => isRecord(value) &&
  hasExactKeys(value, ['segment_id', 'filter_token', 'capability_id', 'target_start_us', 'target_duration_us', 'intensity']) &&
  typeof value.segment_id === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.segment_id) &&
  typeof value.filter_token === 'string' && /^ovjflt_v1_(?:segment|track)_[A-Za-z0-9_-]{32,160}$/u.test(value.filter_token) &&
  (value.capability_id === 'filter.video.named' || value.capability_id === 'filter.video.track_named') &&
  typeof value.target_start_us === 'number' && Number.isSafeInteger(value.target_start_us) && value.target_start_us >= 0 &&
  typeof value.target_duration_us === 'number' && Number.isSafeInteger(value.target_duration_us) && value.target_duration_us > 0 &&
  typeof value.intensity === 'number' && Number.isFinite(value.intensity) && value.intensity >= 0 && value.intensity <= 100

/** @param {unknown} value */
const isPackagingChroma = (value) => isRecord(value) &&
  hasExactKeys(value, ['color', 'intensity', 'shadow', 'edge_smooth', 'spill', 'target_start_us', 'target_duration_us']) &&
  typeof value.color === 'string' && /^#[0-9A-Fa-f]{8}$/u.test(value.color) &&
  ['intensity', 'shadow', 'edge_smooth', 'spill'].every((key) =>
    typeof value[key] === 'number' && Number.isFinite(value[key]) && value[key] >= 0 && value[key] <= 100) &&
  typeof value.target_start_us === 'number' && Number.isSafeInteger(value.target_start_us) && value.target_start_us >= 0 &&
  typeof value.target_duration_us === 'number' && Number.isSafeInteger(value.target_duration_us) && value.target_duration_us > 0

/** @param {unknown} value */
const isPackagingTextAnimation = (value) => isRecord(value) &&
  hasExactKeys(value, ['target_segment_id', 'animation_token']) &&
  typeof value.target_segment_id === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.target_segment_id) &&
  typeof value.animation_token === 'string' && /^ovjtxtanim_v1_[A-Za-z0-9_-]{12,160}$/u.test(value.animation_token)

/** @param {unknown} value */
const isPackagingTextSegment = (value) => {
  if (!isRecord(value)) return false
  const baseKeys = ['segment_id', 'text', 'style_token', 'target_start_us', 'target_duration_us', 'capability_id', 'template_token', 'keyframes']
  const withSlotId = [...baseKeys, 'template_slot_id']
  const withLayout = [...baseKeys, 'layout']
  const withSlotIdAndLayout = [...withSlotId, 'layout']
  if (!(hasExactKeys(value, baseKeys) || hasExactKeys(value, withSlotId) || hasExactKeys(value, withLayout) || hasExactKeys(value, withSlotIdAndLayout))) return false
  if (
    typeof value.segment_id !== 'string' || !isSafeIdentifier(value.segment_id) ||
    typeof value.text !== 'string' || value.text.length === 0 ||
    typeof value.style_token !== 'string' || !isSafeIdentifier(value.style_token) ||
    typeof value.target_start_us !== 'number' || !isSafeTimelineInteger(value.target_start_us) ||
    typeof value.target_duration_us !== 'number' || !isPositiveTimelineInteger(value.target_duration_us) ||
    typeof value.capability_id !== 'string' || !isSafeIdentifier(value.capability_id) ||
    !(value.template_token === null || isSafeIdentifier(value.template_token)) ||
    !Array.isArray(value.keyframes) ||
    (value.template_slot_id !== undefined && !isSafeIdentifier(value.template_slot_id))
  ) return false
  if (value.layout !== undefined) {
    try {
      assertPackagingTextLayout(value.layout)
    } catch {
      return false
    }
  }
  return value.keyframes.every((keyframe) => isRecord(keyframe))
}

/** @param {unknown} value */
const isPackagingStickerKeyframe = (value) => isRecord(value) &&
  hasExactKeys(value, ['capability_id', 'offset_us', 'value', 'interpolation']) &&
  value.capability_id === 'transform.sticker.keyframe' &&
  typeof value.offset_us === 'number' && Number.isSafeInteger(value.offset_us) && value.offset_us >= 0 &&
  typeof value.value === 'number' && Number.isFinite(value.value) && value.value >= 0.1 && value.value <= 10 &&
  value.interpolation === 'linear'

/** @param {unknown} value */
const isPackagingSticker = (value) => {
  if (!isRecord(value)) return false
  const baseKeys = ['segment_id', 'packaging_token', 'capability_id', 'target_start_us', 'target_duration_us', 'intensity']
  const keyedKeys = [...baseKeys, 'keyframes']
  if (!(hasExactKeys(value, baseKeys) || hasExactKeys(value, keyedKeys))) return false
  if (
    typeof value.segment_id !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.segment_id) ||
    typeof value.packaging_token !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.packaging_token) ||
    value.capability_id !== 'sticker.named' ||
    typeof value.target_start_us !== 'number' || !Number.isSafeInteger(value.target_start_us) || value.target_start_us < 0 ||
    typeof value.target_duration_us !== 'number' || !Number.isSafeInteger(value.target_duration_us) || value.target_duration_us <= 0 ||
    typeof value.intensity !== 'number' || !Number.isFinite(value.intensity) || value.intensity < 0 || value.intensity > 1
  ) return false
  if (!Object.hasOwn(value, 'keyframes')) return true
  if (!Array.isArray(value.keyframes) || !value.keyframes.every(isPackagingStickerKeyframe)) return false
  let previousOffset = -1
  for (const keyframe of value.keyframes) {
    if (keyframe.offset_us <= previousOffset || keyframe.offset_us > value.target_duration_us) return false
    previousOffset = keyframe.offset_us
  }
  return true
}

/** @param {unknown} value */
const isPackagingVideoAnimation = (value) => isRecord(value) &&
  hasExactKeys(value, ['segment_id', 'animation_token', 'capability_id', 'target_start_us', 'target_duration_us']) &&
  typeof value.segment_id === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value.segment_id) &&
  typeof value.animation_token === 'string' && /^(?:ovjanim_v1_[a-f0-9]{64}|ovjvideo_animation_v1_[a-f0-9]{24})$/u.test(value.animation_token) &&
  value.capability_id === 'animation.video.named' &&
  typeof value.target_start_us === 'number' && Number.isSafeInteger(value.target_start_us) && value.target_start_us >= 0 &&
  typeof value.target_duration_us === 'number' && Number.isSafeInteger(value.target_duration_us) && value.target_duration_us > 0

/** @param {unknown} value */
const isTimelinePackaging = (value) => {
  if (!isRecord(value)) return false
  const packagingKeys = [
    'schema_version',
    'kind',
    'timeline_content_fingerprint',
    'timeline_revision_fingerprint',
    'subtitle_style',
    'video',
    'voiceover_segments',
    'caption_segments',
    'title_segments',
    'rich_text_segments',
    'sfx_segments',
    'audio_effect_segments',
    'effect_segments',
    'sticker_segments',
    'animation_segments',
    'mask_segments',
    'blend_segments',
    'filter_segments',
    'chroma_segments',
    'text_animation_segments',
    'bgm',
    'voiceover_audio_tokens',
  ]
  const legacyPackagingKeys = packagingKeys.filter((key) => !['audio_effect_segments', 'chroma_segments', 'text_animation_segments', 'animation_segments'].includes(key))
  const audioEffectPackagingKeys = packagingKeys.filter((key) => !['chroma_segments', 'text_animation_segments', 'animation_segments'].includes(key))
  const chromaPackagingKeys = packagingKeys.filter((key) => !['text_animation_segments', 'animation_segments'].includes(key))
  const animationPackagingKeys = packagingKeys.filter((key) => !['audio_effect_segments', 'chroma_segments', 'text_animation_segments'].includes(key))
  /** @param {string[]} keys */
  const filterlessKeys = (keys) => keys.filter((key) => key !== 'filter_segments')
  /** @param {string[]} keys */
  const exactWithOptionalFilter = (keys) => hasExactKeys(value, keys) || hasExactKeys(value, [...keys, 'filter_segments'])
  if (
    (!exactWithOptionalFilter(filterlessKeys(packagingKeys)) && !exactWithOptionalFilter(filterlessKeys(animationPackagingKeys)) && !exactWithOptionalFilter(filterlessKeys(chromaPackagingKeys)) && !exactWithOptionalFilter(filterlessKeys(audioEffectPackagingKeys)) && !exactWithOptionalFilter(filterlessKeys(legacyPackagingKeys))) ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_timeline_packaging' ||
    typeof value.timeline_content_fingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.timeline_content_fingerprint) ||
    typeof value.timeline_revision_fingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.timeline_revision_fingerprint) ||
    (value.subtitle_style !== 'default' && value.subtitle_style !== 'bottom_safe') ||
    !Array.isArray(value.video) ||
    !Array.isArray(value.voiceover_segments) ||
    !Array.isArray(value.voiceover_audio_tokens) ||
    value.voiceover_segments.length !== value.voiceover_audio_tokens.length ||
    !value.voiceover_segments.every(isPackagingVoiceoverFade) ||
    !Array.isArray(value.caption_segments) ||
    !Array.isArray(value.title_segments) ||
    !Array.isArray(value.rich_text_segments) ||
    !value.title_segments.every(isPackagingTextSegment) ||
    !value.rich_text_segments.every(isPackagingTextSegment) ||
    !Array.isArray(value.sfx_segments) ||
    (Object.hasOwn(value, 'audio_effect_segments') && !Array.isArray(value.audio_effect_segments)) ||
    !Array.isArray(value.effect_segments) ||
    !Array.isArray(value.sticker_segments) || !value.sticker_segments.every(isPackagingSticker) ||
    (Object.hasOwn(value, 'animation_segments') && (!Array.isArray(value.animation_segments) || !value.animation_segments.every(isPackagingVideoAnimation))) ||
    !Array.isArray(value.mask_segments) ||
    !value.mask_segments.every(isPackagingMask) ||
    !Array.isArray(value.blend_segments) ||
    !value.blend_segments.every(isPackagingBlend) ||
    (Object.hasOwn(value, 'filter_segments') && (!Array.isArray(value.filter_segments) || !value.filter_segments.every(isPackagingFilter))) ||
    (Object.hasOwn(value, 'chroma_segments') && (!Array.isArray(value.chroma_segments) || !value.chroma_segments.every(isPackagingChroma))) ||
    (Object.hasOwn(value, 'text_animation_segments') && (!Array.isArray(value.text_animation_segments) || !value.text_animation_segments.every(isPackagingTextAnimation))) ||
    (value.bgm !== null && !isPackagingBgm(value.bgm))
  ) {
    return false
  }
  const serialized = JSON.stringify(value)
  if (
    /resource[_-]?id|effect[_-]?id/iu.test(serialized) ||
    /[A-Za-z]:[\\/]/u.test(serialized) ||
    /(?:^|["'])file:/iu.test(serialized) ||
    /\/(?:Users|home|opt)\//u.test(serialized)
  ) return false
  return true
}

/** @param {unknown} editPlan @param {unknown} value */
export const isJianyingDraftExportRequest = (editPlan, value) => {
  if (!isEditPlan(editPlan) || !isRecord(value)) return false
  const keys = Object.keys(value).sort()
  const baseKeys = ['kind', 'preflight', 'preparation', 'schema_version']
  const withPackaging = [...baseKeys, 'packaging'].sort()
  const keyOk =
    keys.join('\u0000') === baseKeys.join('\u0000') ||
    keys.join('\u0000') === withPackaging.join('\u0000')
  if (
    !keyOk ||
    value.schema_version !== 1 ||
    value.kind !== 'jianying_draft_export_request' ||
    !isJianyingDraftPreparation(value.preparation) ||
    !matchesCanonicalPreflight(editPlan, value.preparation, value.preflight) ||
    (Object.hasOwn(value, 'packaging') && !isTimelinePackaging(value.packaging))
  ) {
    return false
  }
  const preparation = /** @type {Record<string, unknown>} */ (value.preparation)
  const preflight = /** @type {Record<string, unknown>} */ (value.preflight)
  const timeline = /** @type {Record<string, unknown>} */ (preparation.timeline)
  const tracks = /** @type {Record<string, unknown>[]} */ (timeline.tracks)
  const summary = /** @type {Record<string, unknown>} */ (preflight.summary)
  const packaging = /** @type {Record<string, unknown> | undefined} */ (value.packaging)
  const voiceoverSegments = /** @type {Record<string, unknown>[]} */ (tracks[1].segments)
  const packagingVoiceovers = /** @type {Record<string, unknown>[]} */ (packaging?.voiceover_segments ?? [])
  const packagingVoiceoversBound = packagingVoiceovers.every(
    (segment, index) => segment.segment_id === voiceoverSegments[index]?.segment_id,
  )
  return (
    preflight.preparation_id === preparation.preparation_id &&
    preflight.ready === true &&
    /** @type {unknown[]} */ (preflight.errors).length === 0 &&
    summary.video_segments === /** @type {unknown[]} */ (tracks[0].segments).length &&
    summary.voiceover_segments === /** @type {unknown[]} */ (tracks[1].segments).length &&
    summary.duration === timeline.duration &&
    packagingVoiceoversBound
  )
}

/** @param {unknown} editPlan @param {unknown} value */
export const assertJianyingDraftExportRequest = (editPlan, value) => {
  if (!isJianyingDraftExportRequest(editPlan, value)) {
    throw new JianyingDraftContractError('invalid_draft_export_request')
  }
}

/** @param {unknown} editPlan @param {unknown} preparation @param {unknown} preflight @param {unknown} [packaging] */
export const createJianyingDraftExportRequest = (editPlan, preparation, preflight, packaging = undefined) => {
  if (!isEditPlan(editPlan)) {
    throw new JianyingDraftContractError('invalid_edit_plan')
  }
  if (!isJianyingDraftPreparation(preparation)) {
    throw new JianyingDraftContractError('invalid_draft_preparation')
  }
  if (!isJianyingDraftPreflightReport(preflight)) {
    throw new JianyingDraftContractError('invalid_draft_preflight_report')
  }
  const draft = /** @type {Record<string, unknown>} */ (preparation)
  const report = /** @type {Record<string, unknown>} */ (preflight)
  if (!matchesCanonicalPreparation(editPlan, preparation)) {
    throw new JianyingDraftContractError('draft_preparation_mismatch')
  }
  if (report.preparation_id !== draft.preparation_id) {
    throw new JianyingDraftContractError('preflight_preparation_mismatch')
  }
  if (!matchesCanonicalPreflight(editPlan, preparation, preflight)) {
    throw new JianyingDraftContractError('draft_preflight_mismatch')
  }
  if (report.ready !== true) {
    throw new JianyingDraftContractError('draft_preflight_not_ready')
  }
  if (packaging !== undefined && !isTimelinePackaging(packaging)) {
    throw new JianyingDraftContractError('invalid_timeline_packaging')
  }
  if (packaging !== undefined) {
    const packagingRecord = /** @type {Record<string, unknown>} */ (packaging)
    const packagingVoiceovers = /** @type {Record<string, unknown>[]} */ (packagingRecord.voiceover_segments)
    const preparationRecord = /** @type {Record<string, unknown>} */ (preparation)
    const timeline = /** @type {Record<string, unknown>} */ (preparationRecord.timeline)
    const tracks = /** @type {Record<string, unknown>[]} */ (timeline.tracks)
    const voiceovers = /** @type {Record<string, unknown>[]} */ (tracks[1].segments)
    if (!packagingVoiceovers.every(
      (segment, index) => segment.segment_id === voiceovers[index]?.segment_id,
    )) {
      throw new JianyingDraftContractError('invalid_timeline_packaging')
    }
  }
  const request = packaging === undefined
    ? {
        schema_version: 1,
        kind: 'jianying_draft_export_request',
        preparation,
        preflight,
      }
    : {
        schema_version: 1,
        kind: 'jianying_draft_export_request',
        preparation,
        preflight,
        packaging,
      }
  assertJianyingDraftExportRequest(editPlan, request)
  return request
}
