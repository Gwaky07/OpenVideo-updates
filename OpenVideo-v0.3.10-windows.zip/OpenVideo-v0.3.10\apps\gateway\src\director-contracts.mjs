import { validateJsonSchema } from './json-schema.mjs'

const maxScriptLength = 20_000
const maxCandidates = 90
const maxSentenceCount = 30
const maxCandidateTextLength = 500
const maxTags = 12
const maxCandidateDurationSeconds = 86_400
const maxRequestBytes = 1_048_576
const sensitiveConfigurationPattern =
  /(?:https?:\/\/|file:|\b(?:provider|model)\s*[:=]|\b(?:api[_ -]?key|base[_ -]?url|authorization|bearer|credential|client[_ -]?secret|access[_ -]?token|refresh[_ -]?token)\b|\b(?:sk|rk|pk)-(?:live|test)?-?[a-z0-9_-]{6,}\b|\b(?:ghp|github_pat|xox[baprs])[_-][a-z0-9_-]{6,}\b|\b(?:[a-z0-9-]+\.)+(?:com|net|org|io|ai|cn|test)\b)/iu

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {Record<string, unknown>} value @param {string[]} allowed */
const hasExactKeys = (value, allowed) =>
  Object.keys(value).length === allowed.length &&
  Object.keys(value).every((key) => allowed.includes(key)) &&
  allowed.every((key) => Object.hasOwn(value, key))

/** @param {string} value */
const hasSensitiveConfigurationText = (value) => {
  let current = value
  for (let depth = 0; depth < 6; depth += 1) {
    if (sensitiveConfigurationPattern.test(current)) return true
    if (!/%[0-9a-f]{2}/iu.test(current)) return false
    try {
      const decoded = decodeURIComponent(current)
      if (decoded === current) return false
      current = decoded
    } catch {
      return true
    }
  }
  return sensitiveConfigurationPattern.test(current)
}

/** @param {unknown} value */
export const hasSensitiveDirectorText = (value) =>
  typeof value === 'string' && hasSensitiveConfigurationText(value)

/** @param {unknown} value @param {number} [maximumLength] @returns {value is string} */
const isSafeString = (value, maximumLength = maxCandidateTextLength) => {
  if (typeof value !== 'string') return false
  return (
    value.length > 0 &&
    value.length <= maximumLength &&
    value === value.trim() &&
    !/[\u0000-\u001f]/u.test(value) &&
    !hasSensitiveConfigurationText(value)
  )
}

/** @param {unknown} value @returns {value is string} */
const isSafeIdentifier = (value) => {
  if (typeof value !== 'string') return false
  return isSafeString(value, 120) && !/[\\/]/u.test(value) && !/^[a-z]:/iu.test(value) && !/^file:/iu.test(value)
}

/** @param {unknown} value */
const isUnitInterval = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1

/** @param {unknown} value */
const isTimestamp = (value) => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(value)) {
    return false
  }
  const timestamp = Date.parse(value)
  return Number.isFinite(timestamp) && new Date(timestamp).toISOString() === value
}

/** @param {unknown} value */
const isSource = (value) => {
  if (!isSafeString(value, 1_000)) return false
  let current = value
  for (let depth = 0; depth < 6 && /%[0-9a-f]{2}/iu.test(current); depth += 1) {
    try {
      const decoded = decodeURIComponent(current)
      if (decoded === current) break
      current = decoded
    } catch {
      return false
    }
  }
  const reverseSeparator = String.fromCharCode(92)
  const hasDriveRoot =
    current.length >= 3 &&
    /^[a-z]$/iu.test(current[0]) &&
    current[1] === ':' &&
    (current[2] === '/' || current[2] === reverseSeparator)
  return (
    !hasDriveRoot &&
    !current.startsWith('/') &&
    !current.startsWith(reverseSeparator + reverseSeparator) &&
    !/^file:/iu.test(current) &&
    !/^https?:/iu.test(current) &&
    !current.includes(reverseSeparator) &&
    !/(?:^|\/)\.\.(?:\/|$)/u.test(current)
  )
}

/** @param {unknown} value */
const isVoiceoverText = (value) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maxScriptLength &&
  !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(value) &&
  !hasSensitiveConfigurationText(value)

/** @param {unknown} value */
const isWithinRequestSizeLimit = (value) => {
  try {
    return Buffer.byteLength(JSON.stringify(value), 'utf8') <= maxRequestBytes
  } catch {
    return false
  }
}

/** @param {unknown} value */
export const isDirectorCandidate = (value) => {
  if (!isRecord(value)) return false
  const candidate = /** @type {Record<string, unknown>} */ (value)
  return (
    hasExactKeys(candidate, [
      'candidate_id',
      'asset_id',
      'scene_id',
      'source',
      'start',
      'end',
      'summary',
      'tags',
      'search_score',
    ]) &&
    isSafeIdentifier(candidate.candidate_id) &&
    isSafeIdentifier(candidate.asset_id) &&
    isSafeIdentifier(candidate.scene_id) &&
    isSource(candidate.source) &&
    typeof candidate.start === 'number' &&
    Number.isFinite(candidate.start) &&
    candidate.start >= 0 &&
    typeof candidate.end === 'number' &&
    Number.isFinite(candidate.end) &&
    candidate.end > candidate.start &&
    candidate.end <= maxCandidateDurationSeconds &&
    isSafeString(candidate.summary) &&
    Array.isArray(candidate.tags) &&
    candidate.tags.length <= maxTags &&
    candidate.tags.every((tag) => isSafeString(tag, 80)) &&
    isUnitInterval(candidate.search_score)
  )
}

/** @param {unknown} value */
export const isDirectorRequest = (value) => {
  if (!isRecord(value)) return false
  const request = /** @type {Record<string, unknown>} */ (value)
  return (
    hasExactKeys(request, ['schema_version', 'project_id', 'script', 'candidates']) &&
    request.schema_version === 1 &&
    isSafeIdentifier(request.project_id) &&
    typeof request.script === 'string' &&
    request.script.trim().length > 0 &&
    request.script.length <= maxScriptLength &&
    !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(request.script) &&
    !hasSensitiveConfigurationText(request.script) &&
    Array.isArray(request.candidates) &&
    request.candidates.length <= maxCandidates &&
    request.candidates.every(isDirectorCandidate) &&
    new Set(request.candidates.map((candidate) => /** @type {Record<string, unknown>} */ (candidate).candidate_id)).size ===
      request.candidates.length &&
    isWithinRequestSizeLimit(request)
  )
}

const sentenceSchema = {
  type: 'object',
  properties: { text: { type: 'string' } },
  required: ['text'],
  additionalProperties: false,
}

export const createSegmentationSchema = () => ({
  name: 'openvideo_sentence_segmentation',
  schema: {
    type: 'object',
    properties: { sentences: { type: 'array', items: sentenceSchema } },
    required: ['sentences'],
    additionalProperties: false,
  },
})

const rankingCandidateSchema = {
  type: 'object',
  properties: {
    candidate_id: { type: 'string' },
    score: { type: 'number' },
    reason: { type: 'string' },
  },
  // Some OpenAI-compatible providers ignore strict response schemas for
  // explanatory fields. Candidate identity and score remain mandatory; the
  // Director supplies a bounded public explanation when reason is omitted.
  required: ['candidate_id', 'score'],
  additionalProperties: false,
}

const rejectedRankingCandidateSchema = {
  type: 'object',
  properties: {
    candidate_id: { type: 'string' },
    reason: { type: 'string' },
  },
  required: ['candidate_id'],
  additionalProperties: false,
}

const rankingSchema = {
  type: 'object',
  properties: {
    sentence_id: { type: 'string' },
    candidates: { type: 'array', items: rankingCandidateSchema },
    rejected_candidates: { type: 'array', items: rejectedRankingCandidateSchema },
  },
  required: ['sentence_id', 'candidates', 'rejected_candidates'],
  additionalProperties: false,
}

export const createRankingSchema = () => ({
  name: 'openvideo_candidate_ranking',
  schema: {
    type: 'object',
    properties: { rankings: { type: 'array', items: rankingSchema } },
    required: ['rankings'],
    additionalProperties: false,
  },
})

const planCandidateSchema = {
  type: 'object',
  properties: {
    candidate_id: { type: 'string' },
    asset_id: { type: 'string' },
    scene_id: { type: 'string' },
    source: { type: 'string' },
    start: { type: 'number' },
    end: { type: 'number' },
    summary: { type: 'string' },
    tags: { type: 'array', items: { type: 'string' } },
    search_score: { type: 'number' },
    director_score: { type: 'number' },
    reason: { type: 'string' },
  },
  required: [
    'candidate_id',
    'asset_id',
    'scene_id',
    'source',
    'start',
    'end',
    'summary',
    'tags',
    'search_score',
    'director_score',
    'reason',
  ],
}

const planItemSchema = {
  type: 'object',
  properties: {
    sentence_id: { type: 'string' },
    order: { type: 'integer' },
    voiceover_text: { type: 'string' },
    status: { enum: ['selected', 'needs_capture'] },
    selected_candidate_id: { type: ['string', 'null'] },
    candidates: { type: 'array', items: planCandidateSchema },
    rejectReasons: { type: 'array' },
  },
  required: ['sentence_id', 'order', 'voiceover_text', 'status', 'selected_candidate_id', 'candidates'],
}

export const createEditPlanSchema = () => ({
  type: 'object',
  properties: {
    schema_version: { const: 1 },
    plan_id: { type: 'string' },
    project_id: { type: 'string' },
    created_at: { type: 'string' },
    items: { type: 'array', items: planItemSchema },
  },
  required: ['schema_version', 'plan_id', 'project_id', 'created_at', 'items'],
})

/** @param {unknown} value */
export const isEditPlan = (value) => {
  if (!validateJsonSchema(createEditPlanSchema(), value) || !isRecord(value)) return false
  const plan = /** @type {Record<string, unknown>} */ (value)
  if (
    !isSafeIdentifier(plan.plan_id) ||
    !isSafeIdentifier(plan.project_id) ||
    !isTimestamp(plan.created_at) ||
    !Array.isArray(plan.items) ||
    plan.items.length === 0 ||
    plan.items.length > maxSentenceCount
  ) {
    return false
  }

  const sentenceIds = new Set()
  const selectedSceneKeys = new Set()
  for (const [index, entry] of plan.items.entries()) {
    const item = /** @type {Record<string, unknown>} */ (entry)
    if (
      !isSafeIdentifier(item.sentence_id) ||
      sentenceIds.has(item.sentence_id) ||
      item.order !== index + 1 ||
      !isVoiceoverText(item.voiceover_text) ||
      !Array.isArray(item.candidates) ||
      item.candidates.length > 3
    ) {
      return false
    }
    sentenceIds.add(item.sentence_id)

    const candidateIds = new Set()
    for (const candidateValue of item.candidates) {
      if (!isRecord(candidateValue)) return false
      const candidate = /** @type {Record<string, unknown>} */ (candidateValue)
      if (
        !isDirectorCandidate({
          candidate_id: candidate.candidate_id,
          asset_id: candidate.asset_id,
          scene_id: candidate.scene_id,
          source: candidate.source,
          start: candidate.start,
          end: candidate.end,
          summary: candidate.summary,
          tags: candidate.tags,
          search_score: candidate.search_score,
        }) ||
        !isUnitInterval(candidate.director_score) ||
        !isSafeString(candidate.reason) ||
        candidateIds.has(candidate.candidate_id)
      ) {
        return false
      }
      candidateIds.add(candidate.candidate_id)
    }

    if (item.status === 'selected') {
      if (!isSafeIdentifier(item.selected_candidate_id) || item.candidates.length === 0) {
        return false
      }
      const selectedCandidate = /** @type {Record<string, unknown>} */ (item.candidates[0])
      const selectedSceneKey = `${selectedCandidate.asset_id}\u0000${selectedCandidate.scene_id}`
      if (
        item.selected_candidate_id !== selectedCandidate.candidate_id ||
        selectedSceneKeys.has(selectedSceneKey)
      ) {
        return false
      }
      selectedSceneKeys.add(selectedSceneKey)
      // A review-required semantic fallback may be shown for manual selection
      // without pretending that it has already become an approved edit choice.
    } else if (
      item.status !== 'needs_capture' ||
      item.selected_candidate_id !== null
    ) {
      return false
    }
  }
  return true
}

export const directorLimits = { maxCandidates, maxRequestBytes, maxSentenceCount, maxScriptLength }

/**
 * White-listed categories for rejection reasons.
 * @type {string[]}
 */
export const REJECTION_CATEGORIES = [
  'insufficient_asr_match',
  'weak_embedding_similarity',
  'scene_too_short',
  'low_scene_confidence',
  'no_relevant_ocr',
  'query_contradicts_content',
  'duplicated_by_top_candidate',
  'other',
]

/** Max length for a rejection reason string. */
export const maxRejectionReasonLength = 100

/** @param {unknown} value @returns {value is {candidateId: string, reason: string, category: string}} */
export const isDirectorRejection = (value) =>
  isRecord(value) &&
  hasExactKeys(value, ['candidateId', 'reason', 'category']) &&
  isSafeIdentifier(value.candidateId) &&
  typeof value.reason === 'string' &&
  value.reason.length > 0 &&
  value.reason.length <= maxRejectionReasonLength &&
  typeof value.category === 'string' &&
  REJECTION_CATEGORIES.includes(value.category)
