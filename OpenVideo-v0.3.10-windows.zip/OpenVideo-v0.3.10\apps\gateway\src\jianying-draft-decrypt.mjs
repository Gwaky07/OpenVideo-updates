import { execFile } from 'node:child_process'
import { access, constants, mkdir, mkdtemp, open, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, isAbsolute, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { MAX_NATIVE_FILE_BYTES, readFileNoReparseBuffer } from './jianying-native-safe-file.mjs'
import { promisify } from 'node:util'
import { existsSync } from 'node:fs'
import { createHash } from 'node:crypto'

const execFileAsync = promisify(execFile)

/**
 * Candidate decoder scheme. Version is intentionally open-ended: the exact
 * install directory and DLL fingerprint are bound below, and the helper's
 * plaintext output is the compatibility probe. A version range here would
 * turn a product upgrade into a hard-coded release loop.
 */
export const DRAFT_DECRYPT_SCHEMES = Object.freeze([
  {
    id: 'encrypt_v2',
    minimumVersion: '10.3.0.0',
    maximumVersionExclusive: null,
  },
])

const defaultHelperPath = fileURLToPath(
  new URL('../native/jianying-draft-decrypt/openvideo-jy-draft-decrypt.exe', import.meta.url),
)
export const MAX_DRAFT_DECRYPT_OUTPUT_BYTES = 256 * 1024 * 1024
const DRAFT_DECRYPT_READ_CHUNK_BYTES = 64 * 1024

export class JianyingDraftDecryptError extends Error {
  /** @param {string} code @param {number} [status] @param {Record<string, unknown>} [diagnostic] */
  constructor(code, status = 409, diagnostic = undefined) {
    super(code)
    this.name = 'JianyingDraftDecryptError'
    this.code = code
    this.status = status
    this.diagnostic = diagnostic
  }
}

/**
 * Read helper output without allowing a compressed/encrypted draft to expand
 * beyond the decoder's source budget before it is validated.
 * @param {string} filePath
 * @param {number} maxBytes
 * @returns {Promise<Buffer>}
 */
const readBoundedDecryptOutput = async (filePath, maxBytes) => {
  const handle = await open(filePath, constants.O_RDONLY)
  try {
    const initial = await handle.stat()
    if (!initial.isFile() || initial.size > maxBytes) {
      throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_OUTPUT_TOO_LARGE', 413, { maxBytes })
    }
    const chunks = []
    const buffer = Buffer.allocUnsafe(Math.min(DRAFT_DECRYPT_READ_CHUNK_BYTES, maxBytes))
    let total = 0
    while (true) {
      const remaining = maxBytes - total
      if (remaining === 0) {
        const probe = Buffer.allocUnsafe(1)
        const result = await handle.read(probe, 0, 1, null)
        if (result.bytesRead > 0) {
          throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_OUTPUT_TOO_LARGE', 413, { maxBytes })
        }
        break
      }
      const result = await handle.read(buffer, 0, Math.min(buffer.length, remaining), null)
      if (result.bytesRead <= 0) break
      chunks.push(Buffer.from(buffer.subarray(0, result.bytesRead)))
      total += result.bytesRead
    }
    const final = await handle.stat()
    if (final.size > maxBytes) {
      throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_OUTPUT_TOO_LARGE', 413, { maxBytes })
    }
    return Buffer.concat(chunks, total)
  } finally {
    await handle.close()
  }
}

/** @param {unknown} value */
const parseVersion = (value) => {
  if (typeof value !== 'string' || !/^[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u.test(value)) return null
  const parts = value.split('.').map(Number)
  if (parts.some((part) => !Number.isSafeInteger(part) || part < 0)) return null
  while (parts.length < 4) parts.push(0)
  return parts
}

/** @param {number[]} left @param {number[]} right */
const compareVersion = (left, right) => {
  for (let index = 0; index < 4; index += 1) {
    if (left[index] !== right[index]) return left[index] - right[index]
  }
  return 0
}

/**
 * @param {Buffer | string} raw
 * @returns {boolean}
 */
export const isEncryptedDraftContent = (raw) => {
  const buffer = Buffer.isBuffer(raw) ? raw : Buffer.from(String(raw), 'utf8')
  let offset = 0
  if (
    buffer.length >= 3 &&
    buffer[0] === 0xef &&
    buffer[1] === 0xbb &&
    buffer[2] === 0xbf
  ) {
    offset = 3
  }
  while (offset < buffer.length) {
    const byte = buffer[offset]
    if (byte === 0x20 || byte === 0x09 || byte === 0x0a || byte === 0x0d) {
      offset += 1
      continue
    }
    return byte !== 0x7b // '{'
  }
  return true
}

/**
 * @param {unknown} appVersion
 * @returns {{ id: string } | null}
 */
export const resolveDraftDecryptScheme = (appVersion) => {
  const parsed = parseVersion(typeof appVersion === 'string' ? appVersion : '')
  if (!parsed) return null
  for (const scheme of DRAFT_DECRYPT_SCHEMES) {
    const minimum = parseVersion(scheme.minimumVersion)
    const maximum = scheme.maximumVersionExclusive === null
      ? null
      : parseVersion(scheme.maximumVersionExclusive)
    if (
      minimum &&
      compareVersion(parsed, minimum) >= 0 &&
      (maximum === null || compareVersion(parsed, maximum) < 0)
    ) {
      return { id: scheme.id }
    }
  }
  return null
}

/**
 * @param {string} installRoot
 * @param {string} version
 * @returns {string | null}
 */
export const resolveVideoEditorInstallDir = (installRoot, version) => {
  if (!isAbsolute(installRoot) || typeof version !== 'string' || !version.trim()) return null
  const root = resolve(installRoot)
  const exact = basename(root).toLowerCase() === version.toLowerCase()
    ? root
    : join(root, version)
  return existsSync(join(exact, 'videoeditor.dll')) ? exact : null
}

/**
 * Binds decrypt execution to the exact selected version directory and DLL.
 * @param {{installDir: string, appVersion: string, expectedDllFingerprint?: string}} input
 */
const verifyExactInstallBinding = async ({ installDir, appVersion, expectedDllFingerprint }) => {
  const exactInstallDir = resolve(installDir)
  if (basename(exactInstallDir).toLowerCase() !== appVersion.toLowerCase()) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_DLL_MISMATCH', 409, {
      reason: 'exact_version_directory_required',
      appVersion,
    })
  }
  const dllPath = join(exactInstallDir, 'videoeditor.dll')
  if (!existsSync(dllPath)) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_INSTALL_MISSING', 503)
  }
  if (typeof expectedDllFingerprint !== 'string' || !/^[a-f0-9]{64}$/iu.test(expectedDllFingerprint)) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_DLL_MISMATCH', 409, {
      reason: 'expected_dll_fingerprint_required',
      appVersion,
    })
  }
  let dllBytes
  try {
    dllBytes = await readFileNoReparseBuffer(dllPath, exactInstallDir, MAX_NATIVE_FILE_BYTES)
  } catch (error) {
    const code = error instanceof Error ? error.message : ''
    if (code === 'JY018_NATIVE_FILE_TOO_LARGE') {
      throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_DLL_MISMATCH', 409, {
        reason: 'dll_too_large',
        appVersion,
      })
    }
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_INSTALL_MISSING', 503, { appVersion })
  }
  const actualDllFingerprint = createHash('sha256').update(dllBytes).digest('hex')
  if (actualDllFingerprint.toLowerCase() !== expectedDllFingerprint.toLowerCase()) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_DLL_MISMATCH', 409, {
      reason: 'dll_fingerprint_mismatch',
      appVersion,
    })
  }
  return { installDir: exactInstallDir, dllFingerprint: actualDllFingerprint }
}

/**
 * @param {{
 *   helperPath?: string,
 *   installDir: string,
 *   appVersion: string,
 *   inputPath: string,
 *   outputPath?: string,
 *   allowInPlace?: boolean,
 *   expectedDllFingerprint?: string,
 *   timeoutMs?: number,
 *   maxOutputBytes?: number,
 * }} input
 */
export const decryptDraftContentFile = async ({
  helperPath = process.env.OPENVIDEO_JY_DECRYPT_HELPER || defaultHelperPath,
  installDir,
  appVersion,
  inputPath,
  outputPath,
  allowInPlace = false,
  expectedDllFingerprint,
  timeoutMs = 60_000,
  maxOutputBytes = MAX_DRAFT_DECRYPT_OUTPUT_BYTES,
}) => {
  if (!isAbsolute(installDir) || !isAbsolute(inputPath)) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_INSTALL_MISSING', 503)
  }
  if (!outputPath || !isAbsolute(outputPath)) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_FAILED', 502, {
      reason: 'output_path_required',
    })
  }
  const destination = resolve(outputPath)
  const source = resolve(inputPath)
  if (destination === source && allowInPlace !== true) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_FAILED', 502, {
      reason: 'in_place_overwrite_forbidden',
    })
  }
  const scheme = resolveDraftDecryptScheme(appVersion)
  if (!scheme) {
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION', 409, {
      appVersion,
      hint: 'update_openvideo',
      })
  }
  const boundedOutputBytes = Number.isSafeInteger(maxOutputBytes) && maxOutputBytes > 0
    ? Math.min(maxOutputBytes, MAX_DRAFT_DECRYPT_OUTPUT_BYTES)
    : MAX_DRAFT_DECRYPT_OUTPUT_BYTES
  const raw = await readFile(source)
  if (!isEncryptedDraftContent(raw)) {
    if (destination !== source) {
      await mkdir(dirname(destination), { recursive: true })
      await writeFile(destination, raw)
    }
    return {
      scheme: 'plaintext',
      appVersion,
      inputBytes: raw.length,
      outputBytes: raw.length,
      contentEncoding: 'plaintext',
    }
  }
  const exactBinding = await verifyExactInstallBinding({
    installDir,
    appVersion,
    expectedDllFingerprint,
  })
  try {
    await access(helperPath, constants.X_OK)
  } catch {
    try {
      await access(helperPath, constants.R_OK)
    } catch {
      throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_HELPER_MISSING', 503)
    }
  }
  const temporaryRoot = await mkdtemp(join(tmpdir(), 'openvideo-jy-decrypt-'))
  const temporaryOutput = join(temporaryRoot, 'draft_content.plain.json')
  try {
    const invokeNodeHelper = /\.(mjs|cjs|js)$/iu.test(helperPath)
    const command = invokeNodeHelper ? process.execPath : helperPath
    const args = invokeNodeHelper
      ? [helperPath, '--install-dir', installDir, '--decrypt', source, temporaryOutput]
      : ['--install-dir', installDir, '--decrypt', source, temporaryOutput]
    const { stdout } = await execFileAsync(
      command,
      args,
      {
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 1024 * 1024,
      },
    )
    let parsed = null
    for (const line of String(stdout).split(/\r?\n/u)) {
      const trimmed = line.trim()
      if (!trimmed.startsWith('{')) continue
      try {
        const candidate = JSON.parse(trimmed)
        if (candidate && candidate.ok === true) {
          parsed = candidate
          break
        }
      } catch {
        // DLL may emit non-JSON noise on stdout; keep scanning.
      }
    }
    if (!parsed || parsed.ok !== true) {
      throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_FAILED', 502)
    }
    const plaintext = await readBoundedDecryptOutput(temporaryOutput, boundedOutputBytes)
    if (isEncryptedDraftContent(plaintext)) {
      throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_FAILED', 502)
    }
    await mkdir(dirname(destination), { recursive: true })
    if (destination === source) {
      const replaceTemp = `${destination}.${process.pid}.tmp`
      await writeFile(replaceTemp, plaintext)
      await rename(replaceTemp, destination)
    } else {
      await writeFile(destination, plaintext)
    }
    return {
      scheme: scheme.id,
      appVersion,
      inputBytes: raw.length,
      outputBytes: plaintext.length,
      contentEncoding: 'plaintext',
      decryptedFrom: 'encrypt_v2',
    }
  } catch (error) {
    if (error instanceof JianyingDraftDecryptError) throw error
    throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_FAILED', 502, {
      appVersion,
      scheme: scheme.id,
      hint: 'update_openvideo',
      dllFingerprint: exactBinding.dllFingerprint,
    })
  } finally {
    await rm(temporaryRoot, { recursive: true, force: true })
  }
}

/**
 * @param {{
 *   installRoot?: string,
 *   installDir?: string | null,
 *   appVersion?: string,
 *   helperPath?: string,
 *   expectedDllFingerprint?: string,
 * }} [options]
 */
export const createJianyingDraftDecryptor = (options = {}) => {
  const helperPath = options.helperPath || process.env.OPENVIDEO_JY_DECRYPT_HELPER || defaultHelperPath
  const installRoot = options.installRoot || process.env.OPENVIDEO_JY_INSTALL_ROOT || ''
  const appVersion = options.appVersion || process.env.OPENVIDEO_JY_APP_VERSION || ''
  const expectedDllFingerprint = options.expectedDllFingerprint || process.env.OPENVIDEO_JY_DLL_FINGERPRINT || ''
  const installDir = options.installDir ||
    (installRoot && appVersion
      ? resolveVideoEditorInstallDir(installRoot, appVersion)
      : (process.env.OPENVIDEO_JY_INSTALL_DIR || null))

  return {
    helperPath,
    installDir,
    appVersion,
    expectedDllFingerprint,
    isEncryptedDraftContent,
    resolveDraftDecryptScheme,
    /**
     * @param {string} inputPath
     * @param {string} [outputPath]
     * @param {{ allowInPlace?: boolean }} [options]
     */
    async ensurePlaintextFile(inputPath, outputPath, options = {}) {
      if (!installDir || !appVersion) {
        const raw = await readFile(inputPath)
        if (!isEncryptedDraftContent(raw)) {
          return {
            scheme: 'plaintext',
            appVersion: appVersion || null,
            contentEncoding: 'plaintext',
            inputBytes: raw.length,
            outputBytes: raw.length,
          }
        }
        if (!appVersion || !resolveDraftDecryptScheme(appVersion)) {
          throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION', 409, {
            appVersion: appVersion || null,
            hint: 'update_openvideo',
          })
        }
        throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_INSTALL_MISSING', 503)
      }
      if (!outputPath && options.allowInPlace !== true) {
        throw new JianyingDraftDecryptError('JY_TEMPLATE_DECRYPT_FAILED', 502, {
          reason: 'output_path_or_allow_in_place_required',
        })
      }
      const destination = outputPath || inputPath
      return decryptDraftContentFile({
        helperPath,
        installDir,
        appVersion,
        expectedDllFingerprint,
        inputPath,
        outputPath: destination,
        allowInPlace: options.allowInPlace === true,
      })
    },
  }
}

/** @param {string} parent @param {string} child */
export const pathInside = (parent, child) => {
  const fragment = relative(resolve(parent), resolve(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}

export const defaultDecryptHelperBasename = () => basename(defaultHelperPath)
