import { createHash } from 'node:crypto'

const states = new Set([
  'created',
  'draft_staged',
  'render_started',
  'render_verified',
  'bundle_ready',
  'promoted',
  'stale',
  'failed',
  'cancelled',
])
const terminalStates = new Set(['promoted', 'stale', 'failed', 'cancelled'])
const sha256 = /^[a-f0-9]{64}$/u
const opaqueIdentifier = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$/u

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' && opaqueIdentifier.test(value)
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  record(value) && Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')

export class JianyingRenderContractError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'JianyingRenderContractError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value */
export const assertRenderBundleIdentity = (value) => {
  const keys = [
    'catalogFingerprint',
    'exportParametersFingerprint',
    'jianyingSignatureFingerprint',
    'jianyingVersion',
    'packagingProjectionFingerprint',
    'projectionVersion',
    'resourceManifestFingerprint',
    'sourceMediaFingerprint',
    'timelineId',
    'timelineRevision',
    'timelineRevisionFingerprint',
    'writerSchemaVersion',
    'writerVersion',
  ]
  if (!exactKeys(value, keys)) {
    throw new JianyingRenderContractError('JY005_RENDER_BUNDLE_IDENTITY_INVALID')
  }
  const candidate = /** @type {Record<string, any>} */ (value)
  if (
    !identifier(candidate.timelineId) ||
    !Number.isSafeInteger(candidate.timelineRevision) || candidate.timelineRevision < 1 ||
    !identifier(candidate.jianyingVersion) ||
    !identifier(candidate.writerVersion) ||
    !Number.isSafeInteger(candidate.writerSchemaVersion) || candidate.writerSchemaVersion < 1 ||
    !identifier(candidate.projectionVersion) ||
    ![
      candidate.timelineRevisionFingerprint,
      candidate.sourceMediaFingerprint,
      candidate.catalogFingerprint,
      candidate.resourceManifestFingerprint,
      candidate.jianyingSignatureFingerprint,
      candidate.exportParametersFingerprint,
      candidate.packagingProjectionFingerprint,
    ].every((entry) => typeof entry === 'string' && sha256.test(entry))
  ) throw new JianyingRenderContractError('JY005_RENDER_BUNDLE_IDENTITY_INVALID')
  return structuredClone(candidate)
}

/** @param {unknown} value */
export const fingerprintRenderBundleIdentity = (value) => {
  const identity = assertRenderBundleIdentity(value)
  return createHash('sha256')
    .update(JSON.stringify(identity, Object.keys(identity).sort()))
    .digest('hex')
}

/** @param {unknown} value */
export const assertJianyingRenderJob = (value) => {
  const keys = [
    'bundleFingerprint', 'bundleIdentity', 'createdAt', 'error', 'jobId', 'progress',
    'projectId', 'state', 'updatedAt',
  ]
  if (!exactKeys(value, keys)) throw new JianyingRenderContractError('JY005_RENDER_JOB_INVALID')
  const job = /** @type {Record<string, any>} */ (value)
  const identity = assertRenderBundleIdentity(job.bundleIdentity)
  const createdAt = Date.parse(job.createdAt)
  const updatedAt = Date.parse(job.updatedAt)
  const hasError = job.error !== null
  const stateInvariant =
    (job.state === 'created' && job.progress === 0 && !hasError) ||
    (job.state === 'promoted' && job.progress === 100 && !hasError) ||
    (job.state === 'failed' && job.progress < 100 && hasError) ||
    (['cancelled', 'stale'].includes(job.state) && job.progress < 100) ||
    (!terminalStates.has(job.state) && job.state !== 'created' && job.progress < 100 && !hasError)
  if (
    !identifier(job.projectId) || !identifier(job.jobId) ||
    !states.has(job.state) ||
    !Number.isInteger(job.progress) || job.progress < 0 || job.progress > 100 ||
    typeof job.createdAt !== 'string' || !Number.isFinite(createdAt) ||
    typeof job.updatedAt !== 'string' || !Number.isFinite(updatedAt) || updatedAt < createdAt ||
    job.bundleFingerprint !== fingerprintRenderBundleIdentity(identity) ||
    (job.error !== null && !exactKeys(job.error, ['code', 'recoverable'])) ||
    (job.error !== null && (!identifier(job.error.code) || typeof job.error.recoverable !== 'boolean')) ||
    !stateInvariant
  ) throw new JianyingRenderContractError('JY005_RENDER_JOB_INVALID')
  return structuredClone(job)
}

/** @param {unknown} value */
export const assertJianyingRenderArtifact = (value) => {
  const keys = ['artifactId', 'bundleFingerprint', 'byteLength', 'durationMs', 'sha256', 'videoCodec']
  if (!exactKeys(value, keys)) throw new JianyingRenderContractError('JY005_RENDER_ARTIFACT_INVALID')
  const artifact = /** @type {Record<string, any>} */ (value)
  if (
    !identifier(artifact.artifactId) ||
    typeof artifact.bundleFingerprint !== 'string' || !sha256.test(artifact.bundleFingerprint) ||
    !Number.isSafeInteger(artifact.byteLength) || artifact.byteLength <= 0 ||
    !Number.isFinite(artifact.durationMs) || artifact.durationMs <= 0 ||
    typeof artifact.sha256 !== 'string' || !sha256.test(artifact.sha256) ||
    !identifier(artifact.videoCodec)
  ) throw new JianyingRenderContractError('JY005_RENDER_ARTIFACT_INVALID')
  return structuredClone(artifact)
}

/** @param {unknown} value */
export const assertSameRenderBundleDelivery = (value) => {
  if (!exactKeys(value, ['bundleIdentity', 'draftArtifact', 'renderArtifact'])) {
    throw new JianyingRenderContractError('QA010_RENDER_DELIVERY_INVALID')
  }
  const delivery = /** @type {Record<string, any>} */ (value)
  const bundleIdentity = assertRenderBundleIdentity(delivery.bundleIdentity)
  const bundleFingerprint = fingerprintRenderBundleIdentity(bundleIdentity)
  const draftArtifact = /** @type {Record<string, any>} */ (delivery.draftArtifact)
  const renderArtifact = assertJianyingRenderArtifact(delivery.renderArtifact)
  if (
    !exactKeys(draftArtifact, ['artifactId', 'bundleFingerprint', 'fingerprint']) ||
    !identifier(draftArtifact.artifactId) ||
    typeof draftArtifact.bundleFingerprint !== 'string' || !sha256.test(draftArtifact.bundleFingerprint) ||
    typeof draftArtifact.fingerprint !== 'string' || !sha256.test(draftArtifact.fingerprint) ||
    draftArtifact.bundleFingerprint !== bundleFingerprint ||
    renderArtifact.bundleFingerprint !== bundleFingerprint
  ) throw new JianyingRenderContractError('QA010_RENDER_DELIVERY_BUNDLE_MISMATCH')
  return structuredClone({ bundleIdentity, draftArtifact, renderArtifact })
}

/** @param {string} state */
export const isJianyingRenderTerminalState = (state) => terminalStates.has(state)
