import { fingerprintCanonical } from './editor-agent-contracts.mjs'
import { createEditorCapabilityRegistry } from './editor-capability-registry.mjs'
import { createCreativeTechniquePolicy } from './creative-technique-policy.mjs'
import { adaptEditPlanToTimeline } from './edit-plan-timeline-adapter.mjs'
import { finalizeRichTimeline } from './rich-timeline-contracts.mjs'
import { projectRichTimelineToJianyingExport } from './rich-timeline-jianying-projection.mjs'
import { projectRichTimelineToPreviewExport } from './rich-timeline-preview-projection.mjs'
import { isCreativeBeatIntent } from './creative-retrieval.mjs'

export const CREATIVE_TECHNIQUE_STABLE_RUN_COUNT = 3
const adapterRevision = 'creative-technique-timeline-v1'
const safeIdPattern = /^[A-Za-z0-9._:-]{1,200}$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {Record<string, any>} value @param {readonly string[]} keys */
const exactKeys = (value, keys) => Object.keys(value).length === keys.length &&
  keys.every((key) => Object.hasOwn(value, key))
/** @param {unknown} value */
const isSafeId = (value) => typeof value === 'string' && safeIdPattern.test(value)
/** @param {unknown} value */
const isUnitScore = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1
/** @param {unknown} value */
const isPositiveUs = (value) => Number.isSafeInteger(value) && Number(value) > 0 && Number(value) <= 24 * 60 * 60 * 1_000_000

const gateKeys = Object.freeze([
  'semantic_not_lower', 'readability_improved', 'rhythm_improved', 'source_ranges_valid',
  'flag_off_unchanged', 'preview_jianying_match', 'automatic_selection',
])
const metricKeys = Object.freeze([
  'baseline_semantic_score', 'active_semantic_score', 'baseline_readability_score',
  'active_readability_score', 'baseline_rhythm_score', 'active_rhythm_score',
  'flag_off_output_difference_count',
])

/** @param {unknown} value @returns {value is Record<string, any>} */
export const isCreativeTechniqueEvaluation = (value) => {
  if (!isRecord(value) || !exactKeys(value, [
    'schema_version', 'benchmark_id', 'benchmark_fingerprint', 'knowledge_fingerprint',
    'capability_registry_fingerprint', 'adapter_revision', 'verdict', 'gates', 'metrics',
    'timeline_fingerprints', 'projection_fingerprints',
  ]) || value.schema_version !== 1 || !isSafeId(value.benchmark_id) ||
      ![value.benchmark_fingerprint, value.knowledge_fingerprint, value.capability_registry_fingerprint]
        .every((entry) => fingerprintPattern.test(entry ?? '')) ||
      value.adapter_revision !== adapterRevision || !['PASS', 'HOLD'].includes(value.verdict) ||
      !isRecord(value.gates) || !exactKeys(value.gates, gateKeys) ||
      !gateKeys.every((key) => typeof value.gates[key] === 'boolean') ||
      !isRecord(value.metrics) || !exactKeys(value.metrics, metricKeys) ||
      !metricKeys.slice(0, -1).every((key) => isUnitScore(value.metrics[key])) ||
      !Number.isSafeInteger(value.metrics.flag_off_output_difference_count) ||
      value.metrics.flag_off_output_difference_count < 0 ||
      !isRecord(value.timeline_fingerprints) ||
      !exactKeys(value.timeline_fingerprints, ['baseline', 'active']) ||
      ![value.timeline_fingerprints.baseline, value.timeline_fingerprints.active]
        .every((entry) => fingerprintPattern.test(entry ?? '')) ||
      !isRecord(value.projection_fingerprints) ||
      !exactKeys(value.projection_fingerprints, ['preview', 'jianying']) ||
      ![value.projection_fingerprints.preview, value.projection_fingerprints.jianying]
        .every((entry) => fingerprintPattern.test(entry ?? ''))) return false
  return value.gates.flag_off_unchanged === (value.metrics.flag_off_output_difference_count === 0) &&
    value.gates.semantic_not_lower ===
      (value.metrics.active_semantic_score >= value.metrics.baseline_semantic_score) &&
    value.gates.readability_improved ===
      (value.metrics.active_readability_score > value.metrics.baseline_readability_score) &&
    value.gates.rhythm_improved ===
      (value.metrics.active_rhythm_score > value.metrics.baseline_rhythm_score) &&
    value.verdict === (gateKeys.every((key) => value.gates[key]) ? 'PASS' : 'HOLD')
}

/** @param {unknown} value */
export const validateCreativeTechniqueBenchmark = (value) => {
  if (!isRecord(value) || !exactKeys(value, [
    'schema_version', 'benchmark_id', 'jianying_profile_id', 'allowed_capability_ids',
    'timeline', 'beats', 'edit_plan', 'scene_bounds', 'thresholds',
  ]) || value.schema_version !== 1 || !isSafeId(value.benchmark_id) ||
      !isSafeId(value.jianying_profile_id) || !Array.isArray(value.allowed_capability_ids) ||
      value.allowed_capability_ids.length < 1 || value.allowed_capability_ids.length > 4 ||
      new Set(value.allowed_capability_ids).size !== value.allowed_capability_ids.length ||
      !value.allowed_capability_ids.every((entry) => ['transition.cut', 'transition.none'].includes(entry)) ||
      !isRecord(value.timeline) || !exactKeys(value.timeline, [
        'authorization_id', 'project_id', 'timeline_id', 'created_at',
      ]) || ![value.timeline.authorization_id, value.timeline.project_id, value.timeline.timeline_id].every(isSafeId) ||
      typeof value.timeline.created_at !== 'string' || !Number.isFinite(Date.parse(value.timeline.created_at)) ||
      !Array.isArray(value.beats) || value.beats.length < 3 || value.beats.length > 30 ||
      !value.beats.every((beat) => isRecord(beat) && exactKeys(beat, ['sentence_id', 'beat_intent']) &&
        isSafeId(beat.sentence_id) && isCreativeBeatIntent(beat.beat_intent)) ||
      !isRecord(value.edit_plan) || !Array.isArray(value.edit_plan.items) ||
      value.edit_plan.items.length !== value.beats.length || !Array.isArray(value.scene_bounds) ||
      value.scene_bounds.length !== value.beats.length || !isRecord(value.thresholds) ||
      !exactKeys(value.thresholds, [
        'minimum_semantic_score', 'minimum_readability_score', 'minimum_rhythm_score', 'stable_run_count',
      ]) || !isUnitScore(value.thresholds.minimum_semantic_score) ||
      !isUnitScore(value.thresholds.minimum_readability_score) ||
      !isUnitScore(value.thresholds.minimum_rhythm_score) ||
      value.thresholds.stable_run_count !== CREATIVE_TECHNIQUE_STABLE_RUN_COUNT) {
    throw new Error('CREATIVE_TECHNIQUE_BENCHMARK_INVALID')
  }
  const sentenceIds = value.beats.map((beat) => beat.sentence_id)
  if (new Set(sentenceIds).size !== sentenceIds.length || value.edit_plan.items.some((item, index) =>
    !isRecord(item) || item.sentence_id !== sentenceIds[index] || item.status !== 'selected' ||
    !isSafeId(item.selected_candidate_id) || !Array.isArray(item.candidates) || item.candidates.length !== 1 ||
    item.candidates[0]?.candidate_id !== item.selected_candidate_id ||
    !isSafeId(item.candidates[0]?.asset_id) || !isSafeId(item.candidates[0]?.scene_id) ||
    typeof item.candidates[0]?.start !== 'number' || typeof item.candidates[0]?.end !== 'number' ||
    item.candidates[0].start < 0 || item.candidates[0].end <= item.candidates[0].start)) {
    throw new Error('CREATIVE_TECHNIQUE_BENCHMARK_INVALID')
  }
  const bounds = new Map()
  for (const bound of value.scene_bounds) {
    if (!isRecord(bound) || !exactKeys(bound, ['asset_id', 'scene_id', 'start_us', 'duration_us']) ||
        !isSafeId(bound.asset_id) || !isSafeId(bound.scene_id) ||
        !Number.isSafeInteger(bound.start_us) || bound.start_us < 0 || !isPositiveUs(bound.duration_us)) {
      throw new Error('CREATIVE_TECHNIQUE_BENCHMARK_INVALID')
    }
    const key = `${bound.asset_id}\u0000${bound.scene_id}`
    if (bounds.has(key)) throw new Error('CREATIVE_TECHNIQUE_BENCHMARK_INVALID')
    bounds.set(key, bound)
  }
  for (const item of value.edit_plan.items) {
    const candidate = item.candidates[0]
    const bound = bounds.get(`${candidate.asset_id}\u0000${candidate.scene_id}`)
    const startUs = Math.round(candidate.start * 1_000_000)
    const endUs = Math.round(candidate.end * 1_000_000)
    if (!bound || startUs < bound.start_us || endUs > bound.start_us + bound.duration_us) {
      throw new Error('CREATIVE_TECHNIQUE_BENCHMARK_INVALID')
    }
  }
  return structuredClone(value)
}

/** @param {Record<string, any>} timeline @returns {Record<string, any>[]} */
const primarySegments = (timeline) => /** @type {Record<string, any>[]} */ (
  timeline.tracks.find((/** @type {Record<string, any>} */ track) =>
    track.kind === 'video' && track.role === 'primary')?.segments ?? []
)

/** @param {Record<string, any>} left @param {Record<string, any>} right */
const semanticIdentityScore = (left, right) => {
  const baseline = primarySegments(left)
  const active = primarySegments(right)
  if (baseline.length === 0 || baseline.length !== active.length) return 0
  const matches = baseline.filter((segment, index) => {
    const candidate = active[index]
    return candidate?.asset?.assetId === segment.asset.assetId &&
      candidate?.asset?.sceneId === segment.asset.sceneId &&
      candidate?.candidateId === segment.candidateId &&
      candidate?.sourceRange?.startUs === segment.sourceRange.startUs
  }).length
  return Number((matches / baseline.length).toFixed(6))
}

/** @param {Record<string, any>} timeline @param {Map<string, Record<string, any>>} bounds */
const sourceRangesValid = (timeline, bounds) => primarySegments(timeline).every((segment) => {
  const bound = bounds.get(`${segment.asset.assetId}\u0000${segment.asset.sceneId}`)
  return bound && segment.sourceRange.startUs >= bound.start_us &&
    segment.sourceRange.startUs + segment.sourceRange.durationUs <= bound.start_us + bound.duration_us
})

/** @param {Record<string, any>} preview @param {Record<string, any>} jianying */
const projectionsMatch = (preview, jianying) => {
  const video = /** @type {Record<string, any>[]} */ (jianying.preparation?.timeline?.tracks?.find(
    (/** @type {Record<string, any>} */ track) => track.type === 'video',
  )?.segments ?? [])
  const selections = /** @type {Record<string, any>[]} */ (preview.selections)
  return selections.length === video.length && selections.every((selection, index) =>
    selection.candidateId === video[index]?.material_ref?.candidate_id &&
    selection.startUs === video[index]?.source_range?.start &&
    selection.durationUs === video[index]?.source_range?.duration &&
    selection.targetStartUs === video[index]?.target_range?.start &&
    selection.targetDurationUs === video[index]?.target_range?.duration)
}

/** @param {{benchmark: unknown, knowledge: Record<string, any>}} input */
export const evaluateCreativeTechniqueBenchmark = ({ benchmark: inputBenchmark, knowledge }) => {
  const benchmark = validateCreativeTechniqueBenchmark(inputBenchmark)
  if (knowledge?.summary?.schemaVersion !== 2 || !fingerprintPattern.test(knowledge?.summary?.fingerprint ?? '')) {
    throw new Error('CREATIVE_TECHNIQUE_KNOWLEDGE_INVALID')
  }
  const policy = createCreativeTechniquePolicy({ knowledge })
  const decisions = policy.plan({
    beats: benchmark.beats,
    allowedCapabilityIds: benchmark.allowed_capability_ids,
  })
  const sceneBounds = Object.fromEntries(benchmark.scene_bounds.map((/** @type {Record<string, any>} */ bound) => [
    `${bound.asset_id}\u0000${bound.scene_id}`,
    { startUs: bound.start_us, durationUs: bound.duration_us },
  ]))
  const common = {
    editPlan: benchmark.edit_plan,
    authorizationId: benchmark.timeline.authorization_id,
    projectId: benchmark.timeline.project_id,
    timelineId: benchmark.timeline.timeline_id,
    createdAt: benchmark.timeline.created_at,
    sceneBounds,
  }
  const baseline = finalizeRichTimeline(adaptEditPlanToTimeline(common))
  const explicitOff = finalizeRichTimeline(adaptEditPlanToTimeline({ ...common, techniqueDecisions: null }))
  const active = finalizeRichTimeline(adaptEditPlanToTimeline({ ...common, techniqueDecisions: decisions }))
  const registry = createEditorCapabilityRegistry({ jianyingProfileId: benchmark.jianying_profile_id })
  const projectionOptions = { capabilityRegistry: registry }
  const baselinePreview = projectRichTimelineToPreviewExport(baseline, projectionOptions)
  const offPreview = projectRichTimelineToPreviewExport(explicitOff, projectionOptions)
  const activePreview = projectRichTimelineToPreviewExport(active, projectionOptions)
  const jianyingOptions = { ...projectionOptions, jianyingProfileId: benchmark.jianying_profile_id }
  const baselineJianying = projectRichTimelineToJianyingExport(baseline, jianyingOptions)
  const offJianying = projectRichTimelineToJianyingExport(explicitOff, jianyingOptions)
  const activeJianying = projectRichTimelineToJianyingExport(active, jianyingOptions)
  const flagOffDifferenceCount = [
    benchmark.edit_plan,
    baseline,
    baselinePreview,
    baselineJianying,
  ].reduce((count, value, index) => count + Number(fingerprintCanonical(value) !== fingerprintCanonical([
    benchmark.edit_plan,
    explicitOff,
    offPreview,
    offJianying,
  ][index])), 0)
  const baselineSegments = primarySegments(baseline)
  const activeSegments = primarySegments(active)
  const holdIndexes = decisions.map((decision, index) => decision.hold_budget_us > 0 ? index : -1).filter((index) => index >= 0)
  const readabilityScore = holdIndexes.length === 0 ? 0 : Number((holdIndexes.filter((index) =>
    activeSegments[index]?.targetRange?.durationUs > baselineSegments[index]?.targetRange?.durationUs).length /
    holdIndexes.length).toFixed(6))
  const rhythmScore = Number((decisions.filter((decision, index) => {
    const marker = active.markers[index]
    return marker?.offsetUs === activeSegments[index]?.targetRange?.startUs &&
      marker?.label === `semantic_cadence:${decision.rhythm_class}`
  }).length / decisions.length).toFixed(6))
  const semanticScore = semanticIdentityScore(baseline, active)
  const gates = Object.freeze({
    semantic_not_lower: semanticScore >= benchmark.thresholds.minimum_semantic_score,
    readability_improved: readabilityScore >= benchmark.thresholds.minimum_readability_score,
    rhythm_improved: rhythmScore >= benchmark.thresholds.minimum_rhythm_score,
    source_ranges_valid: sourceRangesValid(active, new Map(benchmark.scene_bounds.map((/** @type {Record<string, any>} */ bound) => [
      `${bound.asset_id}\u0000${bound.scene_id}`, bound,
    ]))),
    flag_off_unchanged: flagOffDifferenceCount === 0,
    preview_jianying_match: projectionsMatch(activePreview, activeJianying),
    automatic_selection: decisions.length === benchmark.beats.length,
  })
  const evaluation = {
    schema_version: 1,
    benchmark_id: benchmark.benchmark_id,
    benchmark_fingerprint: fingerprintCanonical(benchmark),
    knowledge_fingerprint: knowledge.summary.fingerprint,
    capability_registry_fingerprint: registry.registryFingerprint,
    adapter_revision: adapterRevision,
    verdict: Object.values(gates).every(Boolean) ? 'PASS' : 'HOLD',
    gates,
    metrics: {
      baseline_semantic_score: 1,
      active_semantic_score: semanticScore,
      baseline_readability_score: 0,
      active_readability_score: readabilityScore,
      baseline_rhythm_score: 0,
      active_rhythm_score: rhythmScore,
      flag_off_output_difference_count: flagOffDifferenceCount,
    },
    timeline_fingerprints: {
      baseline: baseline.revisionFingerprint,
      active: active.revisionFingerprint,
    },
    projection_fingerprints: {
      preview: fingerprintCanonical(activePreview),
      jianying: fingerprintCanonical(activeJianying),
    },
  }
  if (!isCreativeTechniqueEvaluation(evaluation)) {
    throw new Error('CREATIVE_TECHNIQUE_EVALUATION_INVALID')
  }
  return Object.freeze(structuredClone(evaluation))
}

export const creativeTechniqueBenchmarkContract = Object.freeze({
  adapterRevision,
  stableRunCount: CREATIVE_TECHNIQUE_STABLE_RUN_COUNT,
})
