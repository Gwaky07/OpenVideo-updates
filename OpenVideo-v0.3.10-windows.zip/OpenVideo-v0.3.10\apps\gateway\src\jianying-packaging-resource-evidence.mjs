import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { lstat, mkdir, mkdtemp, rename, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { protectSecretWithDpapi, unprotectSecretWithDpapi } from './llm-settings.mjs'
import { createJianyingDraftDecryptor } from './jianying-draft-decrypt.mjs'
import { readFileNoReparse, readFileNoReparseBuffer, readFilesNoReparse } from './jianying-native-safe-file.mjs'
import { createPrivateBatchWriterCompatibilityHarness } from './jianying-private-batch-packaging.mjs'
import {
  assertPackagingWriterBinding,
  computePackagingEntryBindingFingerprint,
  isOpaquePackagingToken,
  isPackagingCatalogBoundToDesktop,
  parsePrivatePackagingResourceIndex,
} from './jianying-packaging-resource-index.mjs'

const integrityRevision = 'jy132-packaging-resource-evidence-v1'
const integrityKeyFilename = 'integrity-key.json'
const signaturePattern = /^[A-Za-z0-9_-]{43}$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const evidenceIdPattern = /^ovjevidence_v1_[a-z0-9_-]{8,160}$/iu
// JY-132 owns the signed registry schema. JY-138 adds a distinct, bounded
// evidence-draft producer; keep both names explicit rather than accepting an
// arbitrary OpenVideo draft label.
const draftIdPattern = /^OpenVideo-JY(?:132-packaging|138-private-batch)-[0-9]{10,20}$/u
const verifiedRegistries = new WeakSet()
const admittedRegistries = new WeakSet()
const productionAdmissionCache = new Map()
const productionAdmissionDraftHints = new Map()
const maxProductionAdmissionCacheEntries = 8
export const PACKAGING_DISCOVERY_CATALOG_FILENAMES = Object.freeze([
  'native018-private-draft-catalog.json',
  'jy172-private-packaging-catalog.json',
  'jy132-packaging-resource-catalog.json',
])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @param {string[]} keys */
const hasExactKeys = (value, keys) => isRecord(value) &&
  Object.keys(value).length === keys.length && Object.keys(value).every((key) => keys.includes(key))

/** @param {unknown} value @returns {string} */
const canonical = (value) => {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`
  if (!isRecord(value)) return JSON.stringify(value)
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`
}

/** @param {Record<string, any>} evidence */
const unsignedEvidence = (evidence) => {
  const { integrity_revision: _revision, integrity_signature: _signature, ...unsigned } = evidence
  return unsigned
}

/** @param {Record<string, any>} evidence @param {string} key */
export const signPackagingResourceEvidenceRegistry = (evidence, key) =>
  createHmac('sha256', key).update(canonical(unsignedEvidence(evidence))).digest('base64url')

/** @param {Record<string, any>} evidence @param {string} key */
export const verifyPackagingResourceEvidenceSignature = (evidence, key) => {
  if (!/^[a-f0-9]{64}$/u.test(key) || !signaturePattern.test(evidence?.integrity_signature ?? '')) return false
  const expected = signPackagingResourceEvidenceRegistry(evidence, key)
  return timingSafeEqual(Buffer.from(expected), Buffer.from(evidence.integrity_signature))
}

/**
 * Create the owner-private registry body only after a real evidence draft has
 * been opened, edited, saved and reopened. Signing and publication are kept
 * separate so callers can verify the live draft before replacing admission.
 * @param {{index: any, desktop: {profileId: string, version: string}, draftId: string, bundleFingerprint: string, preOpenFingerprint: string, postSaveFingerprint: string, contentFingerprint: string, admittedBindings: unknown, evidenceId?: string}} input
 */
export const createPackagingResourceEvidenceRegistry = ({ index, desktop, draftId, bundleFingerprint, preOpenFingerprint, postSaveFingerprint, contentFingerprint, admittedBindings, evidenceId = `ovjevidence_v1_${Date.now()}_${randomBytes(6).toString('hex')}` }) => {
  if (!index || index.profileId !== desktop?.profileId || index.appVersion !== desktop?.version ||
      typeof draftId !== 'string' || !draftIdPattern.test(draftId) || !fingerprintPattern.test(bundleFingerprint ?? '') ||
      !fingerprintPattern.test(preOpenFingerprint ?? '') || !fingerprintPattern.test(postSaveFingerprint ?? '') ||
      preOpenFingerprint === postSaveFingerprint || !fingerprintPattern.test(contentFingerprint ?? '') ||
      !Array.isArray(admittedBindings) || admittedBindings.length === 0 || admittedBindings.length > 24 ||
      typeof evidenceId !== 'string' || !evidenceIdPattern.test(evidenceId)) {
    throw new Error('JY132_EVIDENCE_PUBLICATION_INPUT_INVALID')
  }
  return Object.freeze({
    schema_version: 1,
    kind: 'jy132_packaging_resource_evidence_registry',
    evidence_id: evidenceId,
    manual_evidence_verified: true,
    manual_attestation: 'opened-edited-saved-reopened',
    profile_id: index.profileId,
    app_version: index.appVersion,
    catalog_fingerprint: index.catalogFingerprint,
    scheme: 'encrypt_v2',
    opened: true,
    edited: true,
    saved: true,
    reopened: true,
    same_draft: true,
    draft_id: draftId,
    bundle_fingerprint: bundleFingerprint,
    pre_open_fingerprint: preOpenFingerprint,
    post_save_fingerprint: postSaveFingerprint,
    content_fingerprint: contentFingerprint,
    admitted_bindings: structuredClone(admittedBindings),
    temporary_media_cleaned: true,
    integrity_revision: integrityRevision,
  })
}

/**
 * Atomically publish an already verified, signed private registry. This is
 * intentionally unavailable to discovery intake and writes only outside Git.
 * @param {{evidenceRoot: string, evidence: Record<string, any>, write?: typeof writeFile, renameFile?: typeof rename}} input
 */
export const publishPackagingResourceEvidenceRegistry = async ({ evidenceRoot, evidence, write = writeFile, renameFile = rename }) => {
  if (!isRecord(evidence) || evidence.integrity_revision !== integrityRevision ||
      !signaturePattern.test(evidence.integrity_signature ?? '')) {
    throw new Error('JY132_EVIDENCE_PUBLICATION_INVALID')
  }
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const outputPath = path.join(evidenceRoot, 'post-save.json')
  const temporary = `${outputPath}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
  try {
    await write(temporary, `${JSON.stringify(evidence)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await renameFile(temporary, outputPath)
  } finally {
    await rm(temporary, { force: true })
  }
  return Object.freeze({ ...evidence })
}

/**
 * Admission never creates a key. Only the future evidence generator may opt in
 * to key creation after it has verified a real same-draft edit.
 * @param {{evidenceRoot: string, create?: boolean, protect?: typeof protectSecretWithDpapi, unprotect?: typeof unprotectSecretWithDpapi, readProtected?: (file: string, root: string) => Promise<string>}} input
 */
export const loadPackagingResourceEvidenceIntegrityKey = async ({ evidenceRoot, create = false, protect = protectSecretWithDpapi, unprotect = unprotectSecretWithDpapi, readProtected = readFileNoReparse }) => {
  const keyPath = path.resolve(evidenceRoot, integrityKeyFilename)
  let record
  try {
    record = JSON.parse(await readProtected(keyPath, evidenceRoot))
  } catch (error) {
    if (!create) throw new Error('JY132_EVIDENCE_INTEGRITY_KEY_REQUIRED')
    try {
      await lstat(keyPath)
      throw new Error('JY132_EVIDENCE_INTEGRITY_KEY_REQUIRED')
    } catch (statError) {
      if (/** @type {{code?: string}} */ (statError)?.code !== 'ENOENT') throw statError
    }
    const key = randomBytes(32).toString('hex')
    const protectedKey = await protect({ secret: key, revision: integrityRevision })
    if (typeof protectedKey !== 'string' || protectedKey.length === 0) throw new Error('JY132_EVIDENCE_INTEGRITY_KEY_PROTECT_FAILED')
    await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
    const temporary = `${keyPath}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
    try {
      await writeFile(temporary, `${JSON.stringify({ schema_version: 1, kind: 'jy132_packaging_integrity_key', revision: integrityRevision, protected_key: protectedKey })}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
      await rename(temporary, keyPath)
    } finally {
      await rm(temporary, { force: true })
    }
    return key
  }
  if (!hasExactKeys(record, ['schema_version', 'kind', 'revision', 'protected_key']) ||
      record.schema_version !== 1 || record.kind !== 'jy132_packaging_integrity_key' ||
      record.revision !== integrityRevision || typeof record.protected_key !== 'string') {
    throw new Error('JY132_EVIDENCE_INTEGRITY_KEY_INVALID')
  }
  const key = await unprotect({ protectedSecret: record.protected_key, revision: integrityRevision })
  if (typeof key !== 'string' || !/^[a-f0-9]{64}$/u.test(key)) throw new Error('JY132_EVIDENCE_INTEGRITY_KEY_INVALID')
  return key
}

const evidenceKeys = Object.freeze([
  'schema_version', 'kind', 'evidence_id', 'manual_evidence_verified', 'manual_attestation',
  'profile_id', 'app_version', 'catalog_fingerprint', 'scheme', 'opened', 'edited', 'saved',
  'reopened', 'same_draft', 'draft_id', 'bundle_fingerprint', 'pre_open_fingerprint', 'post_save_fingerprint',
  'content_fingerprint', 'admitted_bindings', 'temporary_media_cleaned',
  'integrity_revision', 'integrity_signature',
])

/** @param {unknown} value @param {any} index @param {{profileId: string, version: string}} desktop */
export const parsePackagingResourceEvidenceRegistry = (value, index, desktop) => {
  const candidate = /** @type {any} */ (value)
  if (!hasExactKeys(candidate, [...evidenceKeys]) || candidate.schema_version !== 1 ||
      candidate.kind !== 'jy132_packaging_resource_evidence_registry' ||
      typeof candidate.evidence_id !== 'string' || !evidenceIdPattern.test(candidate.evidence_id) ||
      candidate.manual_evidence_verified !== true || candidate.manual_attestation !== 'opened-edited-saved-reopened' ||
      candidate.profile_id !== desktop?.profileId || candidate.app_version !== desktop?.version ||
      candidate.profile_id !== index?.profileId || candidate.app_version !== index?.appVersion ||
      candidate.catalog_fingerprint !== index?.catalogFingerprint || !fingerprintPattern.test(candidate.catalog_fingerprint) ||
      candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true ||
      candidate.saved !== true || candidate.reopened !== true || candidate.same_draft !== true ||
      typeof candidate.draft_id !== 'string' || !draftIdPattern.test(candidate.draft_id) || !fingerprintPattern.test(candidate.bundle_fingerprint ?? '') ||
      !fingerprintPattern.test(candidate.pre_open_fingerprint ?? '') ||
      !fingerprintPattern.test(candidate.post_save_fingerprint ?? '') ||
      candidate.pre_open_fingerprint === candidate.post_save_fingerprint ||
      !fingerprintPattern.test(candidate.content_fingerprint ?? '') ||
      candidate.temporary_media_cleaned !== true || candidate.integrity_revision !== integrityRevision ||
      !signaturePattern.test(candidate.integrity_signature ?? '') ||
      !Array.isArray(candidate.admitted_bindings) || candidate.admitted_bindings.length === 0 ||
      candidate.admitted_bindings.length > 24) return null

  /** @type {Array<Record<string, any>>} */
  const admittedBindings = []
  /** @type {Set<string>} */
  const tokens = new Set()
  for (const binding of candidate.admitted_bindings) {
    if (!hasExactKeys(binding, ['packaging_token', 'family', 'binding_fingerprint', 'target_start_us', 'target_duration_us']) ||
        !isOpaquePackagingToken(binding.packaging_token) ||
        typeof binding.family !== 'string' || !fingerprintPattern.test(binding.binding_fingerprint ?? '') ||
        !Number.isSafeInteger(binding.target_start_us) || binding.target_start_us < 0 ||
        !Number.isSafeInteger(binding.target_duration_us) || binding.target_duration_us <= 0 ||
        tokens.has(binding.packaging_token)) return null
    const catalogEntry = index.entries.find((/** @type {Record<string, any>} */ entry) => entry.packaging_token === binding.packaging_token)
    if (!catalogEntry || catalogEntry.state !== 'discoverable' || catalogEntry.family !== binding.family ||
        binding.binding_fingerprint !== computePackagingEntryBindingFingerprint({ family: catalogEntry.family, privateBinding: catalogEntry.private_binding })) return null
    try { assertPackagingWriterBinding(catalogEntry.family, catalogEntry.private_binding) } catch { return null }
    tokens.add(binding.packaging_token)
    admittedBindings.push(Object.freeze({ ...binding }))
  }
  return Object.freeze({ ...candidate, admitted_bindings: Object.freeze(admittedBindings) })
}

/** @param {unknown} range @param {Record<string, any>} admitted */
const rangeMatches = (range, admitted) => isRecord(range) &&
  (range.start === undefined ? 0 : range.start) === admitted.target_start_us &&
  range.duration === admitted.target_duration_us

/** @param {Record<string, any>} content @param {Record<string, any>} entry @param {Record<string, any>} admitted */
const draftContainsBinding = (content, entry, admitted) => {
  const binding = entry.private_binding
  const materials = isRecord(content.materials) ? content.materials : {}
  /** @type {Array<Record<string, any>>} */
  const tracks = Array.isArray(content.tracks) ? content.tracks : []
  /** @param {Record<string, any>} track */
  const matchingSegments = (track) => Array.isArray(track?.segments)
    ? track.segments.filter((/** @type {Record<string, any>} */ segment) => rangeMatches(segment?.target_timerange, admitted))
    : []
  if (entry.family === 'flower' || entry.family === 'bubble') {
    const effects = Array.isArray(materials.effects) ? materials.effects : []
    const matching = effects.filter((effect) => effect?.type === (entry.family === 'flower' ? 'text_effect' : 'text_shape') &&
      effect.resource_id === binding.resourceId && effect.effect_id === binding.effectId)
    const titleTracks = tracks.filter((track) => track?.name === 'title-primary' && track?.type === 'text')
    const matchingIds = new Set(matching.map((effect) => effect?.id).filter((/** @type {unknown} */ id) => typeof id === 'string'))
    const ranged = titleTracks.flatMap(matchingSegments)
    const matchedSegments = ranged.filter((/** @type {Record<string, any>} */ segment) => Array.isArray(segment.extra_material_refs) &&
      segment.extra_material_refs.some((/** @type {unknown} */ id) => typeof id === 'string' && matchingIds.has(id)))
    const targetRefs = matchedSegments.flatMap((/** @type {Record<string, any>} */ segment) =>
      segment.extra_material_refs.filter((/** @type {unknown} */ id) => typeof id === 'string' && matchingIds.has(id)))
    const allMatchingRefs = titleTracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
      .flatMap((/** @type {Record<string, any>} */ segment) => Array.isArray(segment?.extra_material_refs)
        ? segment.extra_material_refs.filter((/** @type {unknown} */ id) => typeof id === 'string' && matchingIds.has(id))
        : [])
    return matchingIds.size > 0 && titleTracks.length === 1 && matchedSegments.length === 1 &&
      targetRefs.length >= 1 && targetRefs.length <= 2 && new Set(targetRefs).size === 1 &&
      allMatchingRefs.length === targetRefs.length
  }
  if (entry.family === 'sticker' || entry.family === 'video_effect') {
    const bucket = entry.family === 'sticker' ? materials.stickers : materials.video_effects
    const matching = Array.isArray(bucket) ? bucket.filter((material) =>
      material?.resource_id === binding.resourceId &&
      (entry.family !== 'video_effect' || material?.effect_id === binding.effectId)) : []
    const expectedType = entry.family === 'sticker' ? 'sticker' : 'effect'
    const segments = matching.length === 1
      ? tracks.filter((track) => track?.type === expectedType).flatMap(matchingSegments).filter((segment) => segment.material_id === matching[0].id)
      : []
    return matching.length === 1 && segments.length === 1
  }
  const videoTracks = tracks.filter((track) => track?.name === 'video-primary' && track?.type === 'video')
  const videoSegments = videoTracks.flatMap(matchingSegments)
  if (videoTracks.length !== 1 || videoSegments.length !== 1 || !Array.isArray(videoSegments[0].extra_material_refs)) return false
  const refs = videoSegments[0].extra_material_refs
  if (entry.family === 'video_animation') {
    const animations = Array.isArray(materials.material_animations) ? materials.material_animations : []
    const matching = animations.filter((material) => refs.includes(material?.id) && Array.isArray(material.animations) &&
      material.animations.some((/** @type {Record<string, any>} */ animation) => animation?.resource_id === binding.resourceId &&
        Number.isSafeInteger(animation.duration) && animation.duration > 0 && animation.duration <= admitted.target_duration_us))
    return matching.length === 1
  }
  if (entry.family === 'mask') {
    const useCommon = isRecord(binding.commonMaskTemplate) && typeof binding.commonMaskTemplate.resource_id === 'string'
    const bucket = useCommon ? materials.common_mask : materials.masks
    const resourceId = useCommon ? binding.commonMaskTemplate.resource_id : binding.resourceId
    const matching = Array.isArray(bucket) ? bucket.filter((material) => refs.includes(material?.id) && material.resource_id === resourceId) : []
    return matching.length === 1
  }
  if (entry.family === 'blend') {
    const effects = Array.isArray(materials.effects) ? materials.effects : []
    return effects.filter((effect) => refs.includes(effect?.id) && effect.type === 'mix_mode' && effect.resource_id === binding.resourceId).length === 1
  }
  return false
}

/** @param {Record<string, any>} content @param {Record<string, any>} entry @param {Record<string, any>} admitted */
const diagnoseTextDraftBinding = (content, entry, admitted) => {
  const materials = isRecord(content.materials) ? content.materials : {}
  const effects = Array.isArray(materials.effects) ? materials.effects : []
  const expectedType = entry.family === 'flower' ? 'text_effect' : 'text_shape'
  const typed = effects.filter((effect) => effect?.type === expectedType)
  if (typed.length === 0) return 'material_type_missing'
  const resourceMatched = typed.filter((effect) => effect.resource_id === entry.private_binding.resourceId)
  if (resourceMatched.length === 0) return 'material_resource_mismatch'
  const identityMatched = resourceMatched.filter((effect) => effect.effect_id === entry.private_binding.effectId)
  if (identityMatched.length === 0) return 'material_effect_mismatch'
  const tracks = Array.isArray(content.tracks) ? content.tracks : []
  const titleTracks = tracks.filter((track) => track?.name === 'title-primary' && track?.type === 'text')
  if (titleTracks.length !== 1) return 'title_track_cardinality'
  const ranged = Array.isArray(titleTracks[0].segments)
    ? titleTracks[0].segments.filter((/** @type {Record<string, any>} */ segment) => rangeMatches(segment?.target_timerange, admitted))
    : []
  if (ranged.length === 0) return 'title_range_missing'
  const matchingIds = new Set(identityMatched.map((effect) => effect?.id).filter((/** @type {unknown} */ id) => typeof id === 'string'))
  const matchedSegments = ranged.filter((/** @type {Record<string, any>} */ segment) => Array.isArray(segment.extra_material_refs) &&
    segment.extra_material_refs.some((/** @type {unknown} */ id) => typeof id === 'string' && matchingIds.has(id)))
  if (matchedSegments.length !== 1) return matchedSegments.length === 0 ? 'title_reference_missing' : 'title_reference_ambiguous'
  const targetRefs = matchedSegments[0].extra_material_refs.filter((/** @type {unknown} */ id) =>
    typeof id === 'string' && matchingIds.has(id))
  if (targetRefs.length < 1 || targetRefs.length > 2 || new Set(targetRefs).size !== 1) {
    return `title_reference_cardinality_${Math.min(targetRefs.length, 9)}_unique_${Math.min(new Set(targetRefs).size, 9)}`
  }
  const allMatchingRefs = titleTracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
    .flatMap((/** @type {Record<string, any>} */ segment) => Array.isArray(segment?.extra_material_refs)
      ? segment.extra_material_refs.filter((/** @type {unknown} */ id) => typeof id === 'string' && matchingIds.has(id))
      : [])
  return allMatchingRefs.length === targetRefs.length
    ? null
    : `title_reference_cross_range_${Math.min(allMatchingRefs.length, 9)}`
}

/**
 * Diagnose live-draft binding compatibility without returning tokens, IDs,
 * paths, or material payloads. The family-only result is safe for a local
 * verifier error while the formal signed-registry verifier remains the
 * admission authority.
 * @param {{content: unknown, index: any, admittedBindings: unknown}} input
 */
export const diagnosePackagingResourceDraftBindings = ({ content, index, admittedBindings }) => {
  if (!isRecord(content) || !index || !Array.isArray(index.entries) || !Array.isArray(admittedBindings)) {
    return Object.freeze({
      ok: false,
      verified_binding_count: 0,
      failed_families: Object.freeze(['invalid']),
      failed_constraints: Object.freeze(['invalid:input']),
    })
  }
  const entriesByToken = new Map(index.entries.map((/** @type {Record<string, any>} */ entry) => [entry.packaging_token, entry]))
  const failedFamilies = new Set()
  const failedConstraints = new Set()
  let verifiedBindingCount = 0
  for (const binding of admittedBindings) {
    const family = typeof binding?.family === 'string' ? binding.family : 'invalid'
    const entry = entriesByToken.get(binding?.packaging_token)
    let valid = false
    if (entry && entry.family === family) {
      if (family === 'flower' || family === 'bubble') {
        valid = draftContainsBinding(/** @type {Record<string, any>} */ (content), entry, binding)
      } else {
        const compatibility = createPrivateBatchWriterCompatibilityHarness(index, [binding])
        valid = Boolean(compatibility?.verifyDraftContent(content))
      }
    }
    if (valid) verifiedBindingCount += 1
    else {
      failedFamilies.add(family)
      failedConstraints.add((family === 'flower' || family === 'bubble') && entry
        ? `${family}:${diagnoseTextDraftBinding(/** @type {Record<string, any>} */ (content), entry, binding)}`
        : `${family}:writer_structure`)
    }
  }
  if (failedFamilies.size === 0 && admittedBindings.length > 0) {
    const genericBindings = admittedBindings.filter((binding) =>
      binding.family !== 'flower' && binding.family !== 'bubble')
    if (genericBindings.length > 0) {
      const compatibility = createPrivateBatchWriterCompatibilityHarness(index, genericBindings)
      if (!compatibility?.verifyDraftContent(content)) {
        failedFamilies.add('cross_binding_structure')
        failedConstraints.add('cross_binding_structure:writer_structure')
      }
    }
  }
  return Object.freeze({
    ok: admittedBindings.length > 0 && failedFamilies.size === 0,
    verified_binding_count: verifiedBindingCount,
    failed_families: Object.freeze([...failedFamilies].sort()),
    failed_constraints: Object.freeze([...failedConstraints].sort()),
  })
}

/**
 * Verify the signed registry against the current encrypted draft and its
 * decrypted content. A signed record without the live draft is insufficient.
 * @param {{evidence: unknown, index: any, desktop: {profileId: string, version: string, draftRoot: string, installRoot: string, dllFingerprint?: string}, integrityKey: string, encryptedSnapshot?: Buffer, readEncrypted?: (file: string) => Promise<Buffer>, decrypt?: (input: {encryptedPath: string, plaintextPath: string}) => Promise<{scheme?: string, decryptedFrom?: string}>, readPlaintext?: (file: string) => Promise<string>}} input
 */
export const verifyPackagingResourceEvidenceRegistry = async ({ evidence, index, desktop, integrityKey, encryptedSnapshot, readEncrypted, decrypt, readPlaintext }) => {
  const parsed = parsePackagingResourceEvidenceRegistry(evidence, index, desktop)
  if (!parsed || !verifyPackagingResourceEvidenceSignature(parsed, integrityKey)) return null
  const draftFolder = path.resolve(desktop.draftRoot, parsed.draft_id)
  if (path.dirname(draftFolder) !== path.resolve(desktop.draftRoot)) return null
  const encryptedPath = path.join(draftFolder, 'draft_content.json')
  let encrypted
  try {
    encrypted = encryptedSnapshot ?? (readEncrypted ? await readEncrypted(encryptedPath) : await readFileNoReparseBuffer(encryptedPath, desktop.draftRoot))
  } catch { return null }
  if (createHash('sha256').update(encrypted).digest('hex') !== parsed.post_save_fingerprint) return null
  const inspectRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy132-runtime-verify-'))
  try {
    const encryptedSnapshotPath = path.join(inspectRoot, 'draft_content.encrypt_v2')
    const plaintextPath = path.join(inspectRoot, 'draft_content.json')
    await writeFile(encryptedSnapshotPath, encrypted, { flag: 'wx', mode: 0o600 })
    const rawResult = decrypt
      ? await decrypt({ encryptedPath: encryptedSnapshotPath, plaintextPath })
      : await createJianyingDraftDecryptor({
        installRoot: desktop.installRoot,
        appVersion: desktop.version,
        expectedDllFingerprint: desktop.dllFingerprint,
      }).ensurePlaintextFile(encryptedSnapshotPath, plaintextPath)
    const result = /** @type {{scheme?: string, decryptedFrom?: string}} */ (rawResult)
    if (result?.scheme !== 'encrypt_v2' && result?.decryptedFrom !== 'encrypt_v2') return null
    const plaintext = readPlaintext ? await readPlaintext(plaintextPath) : await readFileNoReparse(plaintextPath, inspectRoot)
    if (createHash('sha256').update(plaintext).digest('hex') !== parsed.content_fingerprint) return null
    const content = JSON.parse(plaintext)
    // Flower and bubble are title-track rich text effects and intentionally do
    // not cross the generic writer boundary. Verify them with the family-aware
    // live-draft contract, while generic families retain the JY-150 writer
    // compatibility gate (which also models bounded Jianying normalizations).
    const bindingDiagnostic = diagnosePackagingResourceDraftBindings({
      content,
      index,
      admittedBindings: parsed.admitted_bindings,
    })
    if (!bindingDiagnostic.ok) return null
    const latestEncrypted = readEncrypted
      ? await readEncrypted(encryptedPath)
      : await readFileNoReparseBuffer(encryptedPath, desktop.draftRoot)
    if (createHash('sha256').update(latestEncrypted).digest('hex') !== parsed.post_save_fingerprint) return null
    verifiedRegistries.add(parsed)
    return parsed
  } catch { return null } finally {
    await rm(inspectRoot, { recursive: true, force: true })
  }
}

/** @param {any} index @param {any} evidence */
export const admitPackagingResourceIndex = (index, evidence) => {
  if (!verifiedRegistries.has(evidence) || evidence.catalog_fingerprint !== index?.catalogFingerprint) return null
  const admittedTokens = new Set(evidence.admitted_bindings.map((/** @type {Record<string, any>} */ binding) => binding.packaging_token))
  const entries = index.entries.map((/** @type {Record<string, any>} */ entry) => Object.freeze(admittedTokens.has(entry.packaging_token) && entry.state === 'discoverable'
    ? { ...entry, state: 'writer_eligible', writer_eligible: true }
    : { ...entry }))
  if (entries.filter((/** @type {Record<string, any>} */ entry) => entry.state === 'writer_eligible').length !== admittedTokens.size) return null
  const admitted = Object.freeze({ ...index, evidenceId: evidence.evidence_id, entries: Object.freeze(entries) })
  admittedRegistries.add(admitted)
  return admitted
}

/** @type {Readonly<Record<string, string>>} */
const promotionCapabilityByFamily = Object.freeze({
  flower: 'text.flower.private',
  bubble: 'text.bubble.private',
  sticker: 'sticker.named',
  video_effect: 'effect.video.named',
  video_animation: 'animation.video.named',
  mask: 'mask.video.named',
  blend: 'blend.video.named',
})

/**
 * Convert only a server-verified admitted registry into path-free promotion
 * receipts. A discovery index, a cloned object, or an evidence-shaped object
 * cannot mint a receipt because admission is tracked by object identity.
 * @param {{index: any, desktop: {profileId: string, version: string}}} input
 */
export const createCapabilityPromotionReceiptsFromAdmittedPackagingIndex = ({ index, desktop }) => {
  if (!admittedRegistries.has(index) || index.profileId !== desktop?.profileId || index.appVersion !== desktop?.version ||
      typeof index.evidenceId !== 'string' || !evidenceIdPattern.test(index.evidenceId)) return Object.freeze([])
  const capabilities = new Set()
  for (const entry of index.entries ?? []) {
    if (entry?.state !== 'writer_eligible' || entry.writer_eligible !== true) continue
    if (typeof entry.family !== 'string' || !(entry.family in promotionCapabilityByFamily)) continue
    const capabilityId = promotionCapabilityByFamily[/** @type {keyof typeof promotionCapabilityByFamily} */ (entry.family)]
    if (typeof capabilityId === 'string') capabilities.add(capabilityId)
  }
  return Object.freeze([...capabilities].sort().map((capabilityId) => Object.freeze({
    receiptId: `ovjypromotion_v1_${index.evidenceId.slice('ovjevidence_v1_'.length)}_${capabilityId.replaceAll('.', '-')}`,
    capabilityId,
    profileId: index.profileId,
    exactProfileMatch: true,
    writerReady: true,
    catalogReady: true,
    openEvidence: true,
    editEvidence: true,
    saveEvidence: true,
    reopenEvidence: true,
  })))
}

/**
 * Production bootstrap reads discovery and evidence as independent private
 * artifacts, then verifies the live encrypted draft before admission.
 * @param {{dataRoot: string, desktop: {profileId: string, version: string, executablePath?: string, installRoot: string, dllFingerprint?: string, draftRoot: string}, candidateCatalogFingerprint?: string, readPrivate?: (file: string, root: string) => Promise<string>, loadIntegrityKey?: typeof loadPackagingResourceEvidenceIntegrityKey, readEncrypted?: (file: string, root?: string) => Promise<Buffer>, decrypt?: (input: {encryptedPath: string, plaintextPath: string}) => Promise<{scheme?: string, decryptedFrom?: string}>, readPlaintext?: (file: string, root?: string) => Promise<string>, captureEvidence?: (evidence: Record<string, any>) => void, captureCatalogCandidates?: (candidates: readonly {fileName: string, catalogFingerprint: string, catalogRawFingerprint: string, privateSourceBinding: Record<string, any>|null}[]) => void|Promise<void>, verificationCache?: Map<string, {evidence: Record<string, any>, admitted: any}> | null}} input
 */
export const loadPackagingResourceIndexForProduction = async ({ dataRoot, desktop, candidateCatalogFingerprint = undefined, readPrivate = readFileNoReparse, loadIntegrityKey = loadPackagingResourceEvidenceIntegrityKey, readEncrypted, decrypt, readPlaintext, captureEvidence, captureCatalogCandidates, verificationCache = undefined }) => {
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy132-packaging-resources')
  const defaultPrivateReaders = readPrivate === readFileNoReparse && loadIntegrityKey === loadPackagingResourceEvidenceIntegrityKey
  const productionHintKey = createHash('sha256').update(canonical({
    data_root: path.resolve(dataRoot),
    profile_id: desktop.profileId,
    app_version: desktop.version,
    executable_path: desktop.executablePath ?? null,
    install_root: desktop.installRoot,
    draft_root: desktop.draftRoot,
    dll_fingerprint: desktop.dllFingerprint ?? null,
  })).digest('hex')
  const hintedDraftId = defaultPrivateReaders ? productionAdmissionDraftHints.get(productionHintKey) : null
  /** @type {Map<string, Buffer>|null} */
  let prefetchedPrivate = null
  if (defaultPrivateReaders) {
    const candidates = [
      ...PACKAGING_DISCOVERY_CATALOG_FILENAMES.map((fileName) => ({ path: path.join(dataRoot, 'catalogs', fileName), rootPath: dataRoot })),
      { path: path.join(evidenceRoot, 'post-save.json'), rootPath: dataRoot },
      { path: path.join(evidenceRoot, integrityKeyFilename), rootPath: dataRoot },
      ...(typeof hintedDraftId === 'string' && draftIdPattern.test(hintedDraftId)
        ? [{ path: path.join(path.resolve(desktop.draftRoot, hintedDraftId), 'draft_content.json'), rootPath: desktop.draftRoot }]
        : []),
    ]
    const present = []
    for (const candidate of candidates) {
      try { await lstat(candidate.path); present.push(candidate) } catch { /* optional discovery artifacts may be absent */ }
    }
    try {
      const values = await readFilesNoReparse(
        present,
        { maxFileBytes: 32 * 1024 * 1024, maxTotalBytes: 64 * 1024 * 1024, asBuffer: true },
      )
      prefetchedPrivate = new Map(present.map((candidate, index) => [candidate.path, /** @type {Buffer} */ (values[index])]))
    } catch { return null }
  }
  /** @param {string} filePath @param {string} rootPath @returns {Promise<string>} */
  const readProductionPrivate = async (filePath, rootPath) => {
    if (!prefetchedPrivate) return await readPrivate(filePath, rootPath)
    const value = prefetchedPrivate.get(path.resolve(filePath))
    if (!Buffer.isBuffer(value)) throw new Error('JY132_PRIVATE_EVIDENCE_INVALID')
    return value.toString('utf8')
  }
  const discoveryIndexes = []
  for (const fileName of PACKAGING_DISCOVERY_CATALOG_FILENAMES) {
    try {
      const discoveryRawBytes = await readProductionPrivate(path.join(dataRoot, 'catalogs', fileName), dataRoot)
      const discoveryRaw = JSON.parse(discoveryRawBytes)
      discoveryIndexes.push({
        fileName,
        index: parsePrivatePackagingResourceIndex(discoveryRaw, {
          profileId: desktop.profileId,
          appVersion: desktop.version,
        }),
        rawFingerprint: createHash('sha256').update(discoveryRawBytes).digest('hex'),
      })
    } catch { /* missing or malformed candidate falls through to the next private catalog */ }
  }
  if (discoveryIndexes.length === 0) return null
  if (typeof captureCatalogCandidates === 'function') {
    await captureCatalogCandidates(Object.freeze(discoveryIndexes.map(({ fileName, index, rawFingerprint }) => Object.freeze({
      fileName,
      catalogFingerprint: index.catalogFingerprint,
      catalogRawFingerprint: rawFingerprint,
      privateSourceBinding: index.privateSourceBinding ? Object.freeze({ ...index.privateSourceBinding }) : null,
    }))))
  }
  const matchingDiscoveryIndexes = typeof candidateCatalogFingerprint === 'string'
    ? discoveryIndexes.filter(({ index }) => index.catalogFingerprint === candidateCatalogFingerprint)
    : discoveryIndexes
  if (matchingDiscoveryIndexes.length === 0) return null
  let evidence
  let evidenceRaw
  try {
    evidenceRaw = await readProductionPrivate(path.join(evidenceRoot, 'post-save.json'), dataRoot)
    evidence = JSON.parse(evidenceRaw)
  } catch { return null }
  const protectedKeyRaw = prefetchedPrivate?.get(path.join(evidenceRoot, integrityKeyFilename)) ?? null
  let integrityKey = null
  const cache = verificationCache === undefined && readPrivate === readFileNoReparse && loadIntegrityKey === loadPackagingResourceEvidenceIntegrityKey &&
    !readEncrypted && !decrypt && !readPlaintext
    ? productionAdmissionCache
    : verificationCache
  for (const { index: discoveryIndex, rawFingerprint: catalogRawFingerprint } of matchingDiscoveryIndexes) {
    if (!isPackagingCatalogBoundToDesktop(discoveryIndex, desktop)) continue
    const parsed = parsePackagingResourceEvidenceRegistry(evidence, discoveryIndex, desktop)
    if (!parsed) continue
    const encryptedPath = path.join(path.resolve(desktop.draftRoot, parsed.draft_id), 'draft_content.json')
    let encrypted
    try {
      const prefetchedEncrypted = prefetchedPrivate?.get(encryptedPath)
      encrypted = Buffer.isBuffer(prefetchedEncrypted)
        ? prefetchedEncrypted
        : readEncrypted
        ? await readEncrypted(encryptedPath, desktop.draftRoot)
        : await readFileNoReparseBuffer(encryptedPath, desktop.draftRoot)
    } catch { continue }
    const encryptedFingerprint = createHash('sha256').update(encrypted).digest('hex')
    if (encryptedFingerprint !== parsed.post_save_fingerprint) continue
    const cacheIdentity = {
      profile_id: desktop.profileId,
      app_version: desktop.version,
      executable_path: desktop.executablePath ?? null,
      install_root: desktop.installRoot,
      draft_root: desktop.draftRoot,
      dll_fingerprint: desktop.dllFingerprint ?? null,
      catalog_fingerprint: discoveryIndex.catalogFingerprint,
      catalog_raw_fingerprint: catalogRawFingerprint,
      evidence_fingerprint: createHash('sha256').update(evidenceRaw).digest('hex'),
      encrypted_fingerprint: encryptedFingerprint,
      integrity_key_identity: protectedKeyRaw
        ? createHash('sha256').update(protectedKeyRaw).digest('hex')
        : null,
    }
    let cacheKey = cacheIdentity.integrity_key_identity
      ? createHash('sha256').update(canonical(cacheIdentity)).digest('hex')
      : null
    let cached = cacheKey ? cache?.get(cacheKey) : null
    if (cached) {
      if (typeof captureEvidence === 'function') captureEvidence(cached.evidence)
      return cached.admitted
    }
    integrityKey ??= await loadIntegrityKey({
      evidenceRoot,
      ...(prefetchedPrivate ? { readProtected: (filePath) => readProductionPrivate(filePath, evidenceRoot) } : {}),
    })
    if (!cacheKey) {
      cacheKey = createHash('sha256').update(canonical({
        ...cacheIdentity,
        integrity_key_identity: createHash('sha256').update(integrityKey).digest('hex'),
      })).digest('hex')
      cached = cache?.get(cacheKey)
      if (cached) {
        if (typeof captureEvidence === 'function') captureEvidence(cached.evidence)
        return cached.admitted
      }
    }
    if (!verifyPackagingResourceEvidenceSignature(parsed, integrityKey)) continue
    const verified = await verifyPackagingResourceEvidenceRegistry({
      evidence,
      index: discoveryIndex,
      desktop,
      integrityKey,
      encryptedSnapshot: encrypted,
      readEncrypted,
      decrypt,
      readPlaintext,
    })
    if (verified && typeof captureEvidence === 'function') captureEvidence(verified)
    const admitted = admitPackagingResourceIndex(discoveryIndex, verified)
    if (admitted) {
      if (cache && cacheKey) {
        cache.set(cacheKey, { evidence: verified, admitted })
        while (cache.size > maxProductionAdmissionCacheEntries) cache.delete(cache.keys().next().value)
      }
      if (defaultPrivateReaders) {
        productionAdmissionDraftHints.set(productionHintKey, parsed.draft_id)
        while (productionAdmissionDraftHints.size > maxProductionAdmissionCacheEntries) {
          productionAdmissionDraftHints.delete(productionAdmissionDraftHints.keys().next().value)
        }
      }
      return admitted
    }
  }
  return null
}

export { integrityRevision }
