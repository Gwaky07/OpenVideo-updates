import {
  EDITOR_BUDGETS,
  EDITOR_MODEL_PATCH_OPERATION_CONTRACTS,
  EDITOR_TOOL_ARGUMENT_CONTRACTS,
  EditorAgentContractError,
  assertAgentTurnDecision,
  assertEditorInstruction,
  createEditorAgentTurnSchema,
  createFrozenEditorJobInput,
  fingerprintCanonical,
  toEditorAgentCheckpointData,
} from './editor-agent-contracts.mjs'
import { createEditorToolRegistry } from './editor-tool-registry.mjs'
import { withProductLlmCharter } from './product-llm-charter.mjs'

export class EditorAgentError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 502) {
    super(code)
    this.name = 'EditorAgentError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 502) => {
  throw new EditorAgentError(code, status)
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} error */
const isRecoverableTurnError = (error) => {
  if (!isRecord(error) || typeof error.code !== 'string') return false
  return [
    'EDITOR_AGENT_TURN_INVALID',
    'EDITOR_AGENT_TOOL_CALL_INVALID',
    'EDITOR_AGENT_FINISH_INVALID',
    'INVALID_UPSTREAM_RESPONSE',
  ].includes(error.code)
}

/**
 * @param {{
 *   gateway: {generate: Function},
 *   registry: ReturnType<typeof createEditorToolRegistry>,
 *   executionFence: {attemptGeneration: number, fencingToken: string},
 *   onCheckpoint?: (stage: 'intent' | 'committed', data: Record<string, any>) => Promise<void> | void,
 *   onToolResult?: (event: {tool: string, ok: boolean, errorCode: string | null}) => void,
 *   timeoutMs?: number,
 *   requireDelivery?: boolean,
 *   automaticPackaging?: boolean,
 *   automaticOutputs?: boolean,
 *   requiredSemanticSegmentCount?: number,
 *   recoveredTimelineIdentity?: {timelineId: string, revision: number, revisionFingerprint: string} | null,
 * }} options
 */
export const createEditorAgent = (options) => {
  if (!options?.gateway || typeof options.gateway.generate !== 'function') {
    fail('EDITOR_AGENT_GATEWAY_MISSING', 500)
  }
  if (!options.registry || typeof options.registry.invoke !== 'function') {
    fail('EDITOR_AGENT_REGISTRY_MISSING', 500)
  }
  if (
    !options.executionFence ||
    !Number.isSafeInteger(options.executionFence.attemptGeneration) ||
    options.executionFence.attemptGeneration < 1 ||
    typeof options.executionFence.fencingToken !== 'string' ||
    options.executionFence.fencingToken.length === 0
  ) {
    fail('EDITOR_AGENT_FENCE_MISSING', 500)
  }
  const requiredSemanticSegmentCount = options.requiredSemanticSegmentCount ?? 0
  const automaticPackaging = options.automaticPackaging === true
  const automaticOutputs = options.automaticOutputs === true
  if (
    !Number.isSafeInteger(requiredSemanticSegmentCount) ||
    requiredSemanticSegmentCount < 0 ||
    requiredSemanticSegmentCount > EDITOR_BUDGETS.maxSearchMaterials
  ) {
    fail('EDITOR_AGENT_SEMANTIC_REQUIREMENTS_INVALID', 500)
  }
  const recoveredTimelineIdentity = options.recoveredTimelineIdentity ?? null
  if (
    recoveredTimelineIdentity !== null &&
    (
      !isRecord(recoveredTimelineIdentity) ||
      typeof recoveredTimelineIdentity.timelineId !== 'string' ||
      !/^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(recoveredTimelineIdentity.timelineId) ||
      !Number.isSafeInteger(recoveredTimelineIdentity.revision) ||
      recoveredTimelineIdentity.revision < 1 ||
      typeof recoveredTimelineIdentity.revisionFingerprint !== 'string' ||
      !/^[a-f0-9]{64}$/u.test(recoveredTimelineIdentity.revisionFingerprint)
    )
  ) {
    fail('EDITOR_AGENT_RECOVERED_TIMELINE_INVALID', 500)
  }
  const modelPatchOperationContracts = requiredSemanticSegmentCount > 0
    ? EDITOR_MODEL_PATCH_OPERATION_CONTRACTS.filter((contract) => contract.op === 'replace_candidate')
    : EDITOR_MODEL_PATCH_OPERATION_CONTRACTS

  /**
   * @param {{
   *   instruction: unknown,
   *   signal?: AbortSignal,
   * }} input
   */
  const run = async (input) => {
    const instruction = assertEditorInstruction(input.instruction)
    if (instruction.projectId !== options.registry.projectId) {
      fail('EDITOR_AGENT_PROJECT_SCOPE_INVALID', 403)
    }

    const instructionFingerprint = fingerprintCanonical({
      instruction: instruction.instruction,
      mode: instruction.mode,
      baseTimeline: instruction.baseTimeline,
    })
    const frozen = createFrozenEditorJobInput({
      instructionFingerprint,
      baseTimelineFingerprint: instruction.baseTimeline
        ? instruction.baseTimeline.revisionFingerprint
        : null,
      toolRegistryFingerprint: options.registry.toolRegistryFingerprint,
      capabilityRegistryFingerprint: options.registry.capabilityRegistryFingerprint,
      attemptGeneration: options.executionFence.attemptGeneration,
      fencingToken: options.executionFence.fencingToken,
    })
    const packagingRevision = automaticPackaging && instruction.mode === 'revise'
    const requiredWorkflowTools = [
      'get_project_brief',
      ...(packagingRevision ? ['recommend_packaging', 'apply_packaging_recommendation'] : []),
      'finalize_timeline',
      ...(!automaticOutputs ? ['request_preview'] : []),
    ]
    const workflowCompletionHint = automaticOutputs
      ? '请按 requiredArgumentKeys 继续调用工具；时间线定稿前禁止 finish，定稿后由服务器统一创建 Preview 和剪映子任务。'
      : '请按 requiredArgumentKeys 继续调用工具；时间线定稿且预览任务排队前禁止 finish。'

    /** @type {{role: 'system' | 'user' | 'assistant', parts: {type: 'text', text: string}[]}[]} */
    const messages = [
      {
        role: 'system',
        parts: [{
          type: 'text',
          text: withProductLlmCharter([
            '你是 OpenVideo AI Editor。只能通过 JSON 决策调用白名单工具。',
            '禁止 shell、路径、URL、下载或直接写文件。',
            ...(automaticOutputs
              ? ['本次目标：生成完整 timeline 草稿并定稿；Preview 与剪映输出由服务器在定稿后统一创建。']
              : ['默认目标：生成完整 timeline 草稿并在合适时 request_preview。']),
            'decision 字段必须是一个 JSON 编码字符串。',
            '解码后的 tool_call 必须精确形如 {"type":"tool_call","tool":"白名单工具名","arguments":{}}。',
            '解码后的 finish 必须精确形如 {"type":"finish","summary":"非空摘要"}。',
            '不得省略 type，不得增加字段，不得使用 Markdown。',
            '示例输出：{"decision":"{\\"type\\":\\"tool_call\\",\\"tool\\":\\"get_timeline_summary\\",\\"arguments\\":{\\"projectId\\":\\"project-a\\",\\"timelineId\\":\\"timeline-a\\",\\"revision\\":1}}"}',
            '必须读取 get_project_brief 返回的 packagingPlan，并只在 capability matrix 允许时把受控包装写入时间线；禁止把偏好冒充已实现能力。',
            'capability matrix 的 Agent denied 只禁止新增或改写该能力；base timeline 中已由受信任产品链写入的音频和包装段必须原样保留，不得用 remove_segment 或空 effect 删除。',
            '如需私有包装推荐，必须调用 recommend_packaging，并且只能使用该工具返回的 opaque token 与 canonical patch 信息；不得自造 token、资源名或私有参数。',
             '如需将推荐写入草稿，必须调用 apply_packaging_recommendation，并只提交 recommend_packaging 返回的 recommendationId、catalogRevisionToken 与当前 timeline revision；不得回传或自造 patch、token 或资源参数。',
            ...(automaticPackaging
              ? [
                  ...(packagingRevision
                    ? ['本次是包装 revision：必须按 recommend_packaging → apply_packaging_recommendation → finalize_timeline 执行；保留主镜头和旁白结构，不得自造资源或 token。']
                    : ['本次是一键自动包装：若项目已选上传草稿，只从该库存按当前文案分配，禁止按模板顺序照抄或用 Catalog 另造效果；无模板时才按创作要求和镜头证据自动规划。']),
                  '不要重复调用 request_jianying_export。定稿后服务器会为同一 finalized RichTimeline 创建唯一剪映 Writer 子任务。',
                ]
              : []),
            ...(automaticOutputs
              ? [
                  '必须先成功调用 get_project_brief 和 finalize_timeline，然后才能 finish。',
                  'revise 时优先：get_project_brief → get_timeline_summary → propose_timeline_patch → preflight_timeline → finalize_timeline → finish。',
                ]
              : [
                  '必须先成功调用 get_project_brief、finalize_timeline 并将 request_preview 排队，然后才能 finish。',
                  '必须先成功调用 finalize_timeline 并将 request_preview 排队，然后才能 finish；同时必须先成功读取 get_project_brief。',
                  'revise 时优先：get_project_brief → get_timeline_summary → propose_timeline_patch → preflight_timeline → finalize_timeline → request_preview → finish。',
                ]),
            ...(requiredSemanticSegmentCount > 0
              ? [
                  `本次是自动建线：必须先读取时间线摘要，并针对 ${requiredSemanticSegmentCount} 个主视频镜头分别按其字幕/文案调用 search_materials。`,
                  '每个主视频镜头都必须通过 replace_candidate 使用对应语义搜索授权的候选和真实 sourceRange；不得直接定稿迁移草稿，不得默认截取素材开头。',
                  '本次 propose_timeline_patch 只能包含 replace_candidate；不得修改或删除字幕、配音、BGM、SFX、Sticker、Flower、Video Effect 或其他既有产品段。',
                ]
              : []),
            '工具参数必须包含 requiredArgumentKeys 列出的全部字段，不得省略。',
          ].join('\n')),
        }],
      },
      {
        role: 'user',
        parts: [{
          type: 'text',
          text: JSON.stringify({
            projectId: instruction.projectId,
            mode: instruction.mode,
            instruction: instruction.instruction,
            baseTimeline: instruction.baseTimeline,
            ...(recoveredTimelineIdentity ? { recoveredTimeline: recoveredTimelineIdentity } : {}),
            ...(automaticPackaging ? { automaticPackaging: true } : {}),
            ...(automaticOutputs ? { automaticOutputs: true } : {}),
            availableTools: options.registry.listTools(),
            toolContracts: EDITOR_TOOL_ARGUMENT_CONTRACTS,
            patchOperationContracts: modelPatchOperationContracts,
            workflowCommitRequirements: [
              'get_project_brief',
              ...(requiredSemanticSegmentCount > 0
                ? [`semantic_replace_all_primary_segments:${requiredSemanticSegmentCount}`]
                : []),
              ...requiredWorkflowTools.slice(1),
            ],
          }),
        }],
      },
    ]

    const deadline = Date.now() + (options.timeoutMs ?? EDITOR_BUDGETS.defaultTimeoutMs)
    /** @type {any[]} */
    const toolTrace = []
    let summary = ''
    let prematureFinishCorrections = 0
    let activeTimelineIdentity = recoveredTimelineIdentity
      ? { ...recoveredTimelineIdentity }
      : instruction.baseTimeline
        ? { ...instruction.baseTimeline }
        : null

    const succeededTools = () => new Set(
      toolTrace.filter((entry) => entry.ok).map((entry) => entry.tool),
    )

    const requiredWorkflowCommitted = () => {
      if (options.requireDelivery === false) return true
      const succeeded = succeededTools()
      return requiredWorkflowTools.every((tool) => succeeded.has(tool))
    }

    const deliveryWorkflowCommitted = () => {
      const succeeded = succeededTools()
      return succeeded.has('finalize_timeline') &&
        (automaticOutputs || succeeded.has('request_preview'))
    }

    const completedWorkflowSummary = () => options.requireDelivery === false
      ? '时间线工具已完成。'
      : automaticOutputs
        ? '时间线已定稿，等待服务器创建 Preview 和剪映输出任务。'
        : '时间线已定稿，预览任务已排队，等待渲染结果。'

    /** @param {unknown} error */
    const recoverCompletedWorkflow = (error) => {
      const code = isRecord(error) && typeof error.code === 'string' ? error.code : ''
      return deliveryWorkflowCommitted() &&
        ['EDITOR_AGENT_TIMEOUT', 'EDITOR_AGENT_CANCELLED'].includes(code)
    }

    /** @param {string} code @param {Record<string, unknown>} [details] */
    const pushCorrection = (code, details = {}) => {
      messages.push({
        role: 'user',
        parts: [{
          type: 'text',
          text: JSON.stringify({
            error: {
              code,
              ...details,
              requiredWorkflowCommit: requiredWorkflowTools,
              hint: workflowCompletionHint,
            },
            budgets: options.registry.budgets(),
          }),
        }],
      })
    }

    const generateDecision = async () => {
      let lastError = /** @type {Error | null} */ (null)
      for (
        let repairAttempt = 1;
        repairAttempt <= EDITOR_BUDGETS.maxTurnRepairAttempts;
        repairAttempt += 1
      ) {
        if (input.signal?.aborted) fail('EDITOR_AGENT_CANCELLED', 499)
        if (Date.now() > deadline) fail('EDITOR_AGENT_TIMEOUT', 504)
        try {
          const requestDeadline = new AbortController()
          const timeoutError = new EditorAgentError('EDITOR_AGENT_TIMEOUT', 504)
          const remainingMs = Math.max(1, deadline - Date.now())
          /** @type {ReturnType<typeof setTimeout> | undefined} */
          let timeout
          /** @type {(() => void) | undefined} */
          let detachAbort
          const externalSignal = input.signal
          const requestSignal = externalSignal
            ? AbortSignal.any([externalSignal, requestDeadline.signal])
            : requestDeadline.signal
          const timeoutPromise = new Promise((_, reject) => {
            timeout = setTimeout(() => {
              requestDeadline.abort(timeoutError)
              reject(timeoutError)
            }, remainingMs)
          })
          const externalAbortPromise = externalSignal
            ? new Promise((_, reject) => {
                const abort = () => reject(externalSignal.reason ?? new EditorAgentError('EDITOR_AGENT_CANCELLED', 499))
                externalSignal.addEventListener('abort', abort, { once: true })
                detachAbort = () => externalSignal.removeEventListener('abort', abort)
              })
            : null
          let generated
          try {
            const upstream = options.gateway.generate({
              capability: 'json',
              messages,
              jsonSchema: createEditorAgentTurnSchema(),
            }, { signal: requestSignal })
            generated = await Promise.race([
              upstream,
              timeoutPromise,
              ...(externalAbortPromise ? [externalAbortPromise] : []),
            ])
          } finally {
            if (timeout) clearTimeout(timeout)
            detachAbort?.()
          }
          return assertAgentTurnDecision(generated?.outputJson ?? generated)
        } catch (error) {
          if (error instanceof EditorAgentContractError) {
            lastError = error
            if (
              repairAttempt >= EDITOR_BUDGETS.maxTurnRepairAttempts ||
              !isRecoverableTurnError(error)
            ) {
              fail(error.code, error.status)
            }
            pushCorrection(error.code)
            continue
          }
          if (isRecoverableTurnError(error)) {
            lastError = /** @type {Error} */ (error)
            if (repairAttempt >= EDITOR_BUDGETS.maxTurnRepairAttempts) {
              fail('EDITOR_AGENT_TURN_INVALID', 502)
            }
            pushCorrection(
              typeof error === 'object' && error && 'code' in error && typeof error.code === 'string'
                ? error.code
                : 'EDITOR_AGENT_TURN_INVALID',
            )
            continue
          }
          throw error
        }
      }
      fail(
        lastError instanceof EditorAgentContractError
          ? lastError.code
          : 'EDITOR_AGENT_TURN_INVALID',
        502,
      )
    }

    for (let turn = 0; turn < EDITOR_BUDGETS.maxToolCallsPerTurn + 1; turn += 1) {
      if (input.signal?.aborted) {
        if (deliveryWorkflowCommitted()) {
          summary = completedWorkflowSummary()
          break
        }
        fail('EDITOR_AGENT_CANCELLED', 499)
      }
      if (Date.now() > deadline) {
        if (deliveryWorkflowCommitted()) {
          summary = completedWorkflowSummary()
          break
        }
        fail('EDITOR_AGENT_TIMEOUT', 504)
      }

      let decision
      try {
        decision = await generateDecision()
      } catch (error) {
        if (recoverCompletedWorkflow(error)) {
          summary = completedWorkflowSummary()
          break
        }
        throw error
      }

      if (decision.type === 'finish') {
        if (!requiredWorkflowCommitted()) {
          prematureFinishCorrections += 1
          if (prematureFinishCorrections > EDITOR_BUDGETS.maxPrematureFinishCorrections) {
            fail('EDITOR_AGENT_INCOMPLETE_WORKFLOW', 409)
          }
          messages.push({
            role: 'assistant',
            parts: [{ type: 'text', text: JSON.stringify(decision) }],
          })
          pushCorrection('EDITOR_AGENT_INCOMPLETE_WORKFLOW', {
            missingTools: requiredWorkflowTools.filter((tool) =>
              !toolTrace.some((entry) => entry.ok && entry.tool === tool)),
          })
          continue
        }
        summary = options.requireDelivery === false
          ? /** @type {string} */ (decision.summary)
          : automaticOutputs
            ? '时间线已定稿，等待服务器创建 Preview 和剪映输出任务。'
            : '时间线已定稿，预览任务已排队，等待渲染结果。'
        break
      }

      if (decision.type !== 'tool_call') fail('EDITOR_AGENT_TURN_INVALID', 502)
      const toolName = /** @type {string} */ (decision.tool)
      const modelArguments = /** @type {Record<string, any>} */ (decision.arguments)
      const modelTimelineMatchesActive = activeTimelineIdentity && (
        !Object.hasOwn(modelArguments, 'timelineId') ||
        modelArguments.timelineId === activeTimelineIdentity.timelineId
      )
      const toolArguments = {
        ...modelArguments,
        ...(!Object.hasOwn(modelArguments, 'projectId')
          ? { projectId: instruction.projectId }
          : {}),
        ...(toolName === 'get_timeline_summary' && activeTimelineIdentity && modelTimelineMatchesActive
          ? {
              ...(!Object.hasOwn(modelArguments, 'timelineId')
                ? { timelineId: activeTimelineIdentity.timelineId }
                : {}),
              revision: activeTimelineIdentity.revision,
            }
          : {}),
        ...(toolName === 'propose_timeline_patch' && activeTimelineIdentity
          ? {
              baseRevision: activeTimelineIdentity.revision,
              baseRevisionFingerprint: activeTimelineIdentity.revisionFingerprint,
            }
          : {}),
        ...(
          [
            'preflight_timeline',
            'finalize_timeline',
            'request_preview',
            'request_jianying_export',
          ].includes(toolName) &&
          activeTimelineIdentity &&
          modelTimelineMatchesActive
            ? {
                ...(!Object.hasOwn(modelArguments, 'timelineId')
                  ? { timelineId: activeTimelineIdentity.timelineId }
                  : {}),
                revision: activeTimelineIdentity.revision,
                revisionFingerprint: activeTimelineIdentity.revisionFingerprint,
              }
            : {}
        ),
      }
      if (typeof options.onCheckpoint === 'function') {
        await options.onCheckpoint('intent', toEditorAgentCheckpointData({
          tool: toolName,
          argumentsFingerprint: fingerprintCanonical(toolArguments),
          frozen,
          committedExecutions: options.registry.committedExecutions(),
        }))
      }

      let toolResult
      try {
        toolResult = await options.registry.invoke(toolName, toolArguments, {
          signal: input.signal,
        })
      } catch (error) {
        const code = isRecord(error) && typeof error.code === 'string'
          ? error.code
          : 'EDITOR_TOOL_EXECUTION_FAILED'
        toolResult = { error: { code } }
      }

      const toolOk = !(isRecord(toolResult) && isRecord(toolResult.error))
      if (
        toolOk &&
        activeTimelineIdentity &&
        toolName === 'propose_timeline_patch' &&
        Number.isSafeInteger(toolResult.proposedRevision) &&
        typeof toolResult.proposedRevisionFingerprint === 'string'
      ) {
        activeTimelineIdentity = {
          timelineId: activeTimelineIdentity.timelineId,
          revision: toolResult.proposedRevision,
          revisionFingerprint: toolResult.proposedRevisionFingerprint,
        }
      }
      if (
        toolOk &&
        activeTimelineIdentity &&
        toolName === 'apply_packaging_recommendation' &&
        typeof toolResult.timelineId === 'string' &&
        Number.isSafeInteger(toolResult.proposedRevision) &&
        typeof toolResult.proposedRevisionFingerprint === 'string'
      ) {
        activeTimelineIdentity = {
          timelineId: toolResult.timelineId,
          revision: toolResult.proposedRevision,
          revisionFingerprint: toolResult.proposedRevisionFingerprint,
        }
      }
      if (
        toolOk &&
        activeTimelineIdentity &&
        toolName === 'finalize_timeline' &&
        Number.isSafeInteger(toolResult.revision) &&
        typeof toolResult.revisionFingerprint === 'string'
      ) {
        activeTimelineIdentity = {
          timelineId: activeTimelineIdentity.timelineId,
          revision: toolResult.revision,
          revisionFingerprint: toolResult.revisionFingerprint,
        }
      }
      options.onToolResult?.({
        tool: toolName,
        ok: toolOk,
        errorCode: toolOk
          ? null
          : typeof toolResult.error.code === 'string'
            ? toolResult.error.code
            : 'EDITOR_TOOL_EXECUTION_FAILED',
      })
      toolTrace.push({
        tool: toolName,
        ok: toolOk,
      })

      if (
        !toolOk &&
        requiredSemanticSegmentCount > 0 &&
        [
          'EDITOR_CAPABILITY_UNAUTHORIZED',
          'EDITOR_PROTECTED_SEGMENT_MUTATION_DENIED',
        ].includes(toolResult.error.code)
      ) {
        fail('EDITOR_AGENT_SEMANTIC_FALLBACK_REQUIRED', 409)
      }

      if (toolOk && typeof options.onCheckpoint === 'function') {
        await options.onCheckpoint('committed', toEditorAgentCheckpointData({
          tool: toolName,
          resultFingerprint: fingerprintCanonical(toolResult),
          frozen,
          committedExecutions: options.registry.committedExecutions(),
        }))
      }

      messages.push({
        role: 'assistant',
        parts: [{ type: 'text', text: JSON.stringify(decision) }],
      })
      messages.push({
        role: 'user',
        parts: [{
          type: 'text',
          text: JSON.stringify({
            toolResult,
            budgets: options.registry.budgets(),
            workflowCommitted: requiredWorkflowCommitted(),
          }),
        }],
      })
    }

    if (!summary) {
      fail('EDITOR_AGENT_INCOMPLETE_WORKFLOW', 409)
    }

    return {
      status: 'succeeded',
      summary,
      instructionFingerprint,
      frozen,
      riskFlags: instruction.riskFlags,
      toolTrace,
      budgets: options.registry.budgets(),
    }
  }

  return { run }
}

export { createEditorToolRegistry }
