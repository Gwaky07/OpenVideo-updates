import { randomUUID } from 'node:crypto'
import { existsSync, realpathSync } from 'node:fs'
import {
  chmod,
  copyFile,
  link,
  mkdir,
  open,
  readdir,
  readFile,
  rename,
  rm,
  stat,
} from 'node:fs/promises'
import { basename, dirname, extname, isAbsolute, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import { securePrivateRuntimeRoot } from './local-runtime.mjs'
import {
  isHistoricalReferenceTemplateAdapterRequest,
  isHistoricalReferenceTemplateAnalysis,
  isReferenceTemplateAdapterRequest,
  isReferenceTemplateAnalysis,
  isReferenceTemplateDraft,
  isReferenceTemplatePreflightReport,
  preflightHistoricalReferenceTemplateDraft,
  preflightReferenceTemplateDraft,
} from './reference-template-contracts.mjs'
import {
  deriveTemplateProfileFromSource,
  isReusableTemplateArtifact,
  isReusableTemplateCreateCommand,
  isReusableTemplateLabel,
  reusableTemplateFingerprint,
  sanitizeReusableTemplateSourceLabel,
  summarizeReusableTemplateArtifact,
  toReusableTemplatePublicDetail,
} from './reusable-template-contracts.mjs'
import { createReusableTemplateArtifactFromRecipe } from './replication-recipe-artifact.mjs'
import {
  addControlledLocalSfxCueToReplicationRecipe,
  bindLocalAudioToReplicationRecipe,
  bindVoiceProfileToReplicationRecipe,
  createReplicationRecipeFromJianyingDraft,
  createReplicationRecipeFromReferenceAnalysis,
  isReplicationRecipe,
  replicationRecipeFingerprint,
} from './replication-recipe.mjs'
import { applyBlueprintAssetsToRecipe } from './template-blueprint-asset-bind.mjs'
import { isTemplateSelectionRequest } from './template-library.mjs'

const schemaVersion = 3
const legacySchemaVersions = new Set([1, 2])
const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const transientWindowsCodes = new Set(['EPERM', 'EBUSY', 'EACCES'])
const activeOwnerTokens = new Set()
const activeReclaimerTokens = new Set()

/** @param {unknown} value */
const previewReadyForApproval = (value) =>
  record(value) &&
  value.referencePlayable === true &&
  value.demoPlayable === true &&
  value.demoAuthentic === true &&
  value.styleAnalysisComplete === true &&
  value.approveReady === true

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} error */
const errorCode = (error) =>
  error && typeof error === 'object' && 'code' in error
    ? /** @type {{code?: unknown}} */ (error).code
    : undefined
/** @param {number} milliseconds */
const delay = (milliseconds) => new Promise((resolveDelay) => setTimeout(resolveDelay, milliseconds))
/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {unknown} value */
const timestamp = (value) =>
  typeof value === 'string' &&
  Number.isFinite(Date.parse(value)) &&
  new Date(value).toISOString() === value
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  /** @param {string} value */
  const canonical = (value) => existsSync(value) ? realpathSync.native(value) : resolve(value)
  const fragment = relative(canonical(parent), canonical(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}
/** @param {unknown} value @returns {boolean} */
const containsPrivateData = (value) => {
  if (typeof value === 'string') {
    const backslash = String.fromCharCode(92)
    const lower = value.toLowerCase()
    const windowsDrive =
      value.length >= 3 &&
      /[a-z]/iu.test(value[0]) &&
      value[1] === ':' &&
      (value[2] === backslash || value[2] === '/')
    return windowsDrive ||
      lower.includes(`file:${'/'.repeat(2)}`) ||
      ['home', 'users', 'private', 'var', 'tmp', 'mnt', 'volumes'].some(
        (segment) => lower.includes(`/${segment}/`),
      )
  }
  if (Array.isArray(value)) return value.some(containsPrivateData)
  if (!record(value)) return false
  return Object.entries(value).some(([key, entry]) =>
    /(?:^|_)(?:path|transcript|media_content|thumbnail|provider|credential|secret|token)(?:_|$)/iu.test(key) ||
    containsPrivateData(entry))
}
/** @param {Record<string, any>} artifact @param {number} contractVersion */
const validReferenceArtifact = (artifact, contractVersion) => {
  const validateAdapter = contractVersion === 1
    ? isHistoricalReferenceTemplateAdapterRequest
    : isReferenceTemplateAdapterRequest
  const validateAnalysis = contractVersion === 1
    ? isHistoricalReferenceTemplateAnalysis
    : isReferenceTemplateAnalysis
  const preflight = contractVersion === 1
    ? preflightHistoricalReferenceTemplateDraft
    : preflightReferenceTemplateDraft
  if (
    !isReusableTemplateArtifact(artifact) ||
    !isTemplateSelectionRequest(artifact.templateSelectionRequest) ||
    !validateAdapter(
      artifact.templateSelectionRequest,
      artifact.adapterRequest,
    ) ||
    !validateAnalysis(artifact.adapterRequest, artifact.analysis) ||
    !isReferenceTemplateDraft(artifact.draft) ||
    !isReferenceTemplatePreflightReport(artifact.preflight)
  ) return false
  const canonicalPreflight = preflight(
    artifact.templateSelectionRequest,
    artifact.adapterRequest,
    artifact.analysis,
    artifact.draft,
  )
  return artifact.preflight.ready === true &&
    JSON.stringify(artifact.preflight) === JSON.stringify(canonicalPreflight)
}

export class ReusableTemplateRepositoryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'ReusableTemplateRepositoryError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value */
const validStoredRecord = (value) => {
  if (!record(value)) return false
  const publicValue = {
    libraryTemplateId: value.libraryTemplateId,
    bindable: value.contractVersion === 2 && value.status === 'approved',
    compatibility: value.contractVersion === 2 ? 'current' : 'legacy_read_only',
    label: value.label,
    status: value.status,
    revision: value.revision,
    fingerprint: value.fingerprint,
    orientation: value.orientation,
    targetDurationSeconds: value.targetDurationSeconds,
    pacing: value.pacing,
    draftSummary: value.draftSummary,
    rulesSummary: value.rulesSummary,
    createdAt: value.createdAt,
    updatedAt: value.updatedAt,
  }
  try {
    toReusableTemplatePublicDetail(publicValue)
  } catch {
    return false
  }
  const storedKeys = [
      'artifact',
      'contractVersion',
      'createdAt',
      'draftSummary',
      'fingerprint',
      'label',
      'libraryTemplateId',
      'orientation',
      'pacing',
      'revision',
      'rulesSummary',
      'source',
      'status',
      'targetDurationSeconds',
      'updatedAt',
    ]
  const exactStoredKeys = Object.keys(value).sort().join('\u0000') ===
    storedKeys.sort().join('\u0000')
  const exactSealedStoredKeys = Object.keys(value).sort().join('\u0000') ===
    [...storedKeys, 'approvedRecipeFingerprint'].sort().join('\u0000')
  return (
    (exactStoredKeys || exactSealedStoredKeys) &&
    (
      value.approvedRecipeFingerprint === undefined ||
      (
        value.status !== 'draft' &&
        typeof value.approvedRecipeFingerprint === 'string' &&
        /^[a-f0-9]{64}$/u.test(value.approvedRecipeFingerprint)
      )
    ) &&
    [1, 2].includes(value.contractVersion) &&
    ['created', 'editable_revision', 'migrated'].includes(value.source) &&
    validReferenceArtifact(value.artifact, value.contractVersion) &&
    value.fingerprint === reusableTemplateFingerprint(value.artifact) &&
    !containsPrivateData(value.artifact)
  )
}

/** @param {unknown} value @returns {unknown} */
const normalizeDocument = (value) => {
  if (!record(value)) return value
  if (value.schema_version === schemaVersion) return value
  if (!legacySchemaVersions.has(value.schema_version) || !Array.isArray(value.records)) return value
  const migrated = clone(value)
  migrated.schema_version = schemaVersion
  if (value.schema_version === 2) return migrated
  for (let index = 0; index < migrated.records.length; index += 1) {
    const stored = migrated.records[index]
    const current = { ...stored, contractVersion: 2 }
    if (validStoredRecord(current)) {
      migrated.records[index] = current
      continue
    }
    const historical = { ...stored, contractVersion: 1 }
    if (!validStoredRecord(historical)) return value
    migrated.records[index] = historical
  }
  return migrated
}

/** @param {unknown} value */
const validDocument = (value) => {
  if (!record(value)) return false
  if (
    value.schema_version !== schemaVersion ||
    typeof value.migration_completed !== 'boolean' ||
    !Array.isArray(value.records) ||
    !value.records.every(validStoredRecord)
  ) return false
  const revisions = new Set(value.records.map((entry) =>
    `${entry.libraryTemplateId}\u0000${entry.revision}`))
  if (revisions.size !== value.records.length) return false
  const byTemplate = new Map()
  for (const entry of value.records) {
    const prior = byTemplate.get(entry.libraryTemplateId)
    if (prior && (
      prior.fingerprint !== entry.fingerprint ||
      prior.createdAt !== entry.createdAt ||
      prior.revision + 1 !== entry.revision ||
      (
        prior.approvedRecipeFingerprint !== undefined &&
        prior.approvedRecipeFingerprint !== entry.approvedRecipeFingerprint
      )
    )) return false
    byTemplate.set(entry.libraryTemplateId, entry)
  }
  return true
}

/** @param {string} source @param {string} destination @param {typeof rename} renameFile */
const renameWithRetries = async (source, destination, renameFile) => {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    try {
      await renameFile(source, destination)
      return
    } catch (error) {
      if (
        !transientWindowsCodes.has(String(errorCode(error))) ||
        attempt === 19
      ) throw error
      await delay(10)
    }
  }
}

/** @param {string} path @param {boolean} [force] @param {number} [maximumAttempts] @param {typeof rm} [removeFile] */
const removeWithTransientRetries = async (
  path,
  force = false,
  maximumAttempts = 20,
  removeFile = rm,
) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    try {
      await removeFile(path, { force })
      return true
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return true
      if (
        !transientWindowsCodes.has(String(errorCode(error))) ||
        attempt + 1 >= maximumAttempts
      ) throw error
      await delay(10)
    }
  }
  return false
}

/** @param {string} path @param {unknown} document @param {boolean} preservePrimary @param {{renameFile?: typeof rename}} operations */
const writeAtomic = async (path, document, preservePrimary, operations) => {
  const temporary = `${path}.${randomUUID()}.tmp`
  let handle = null
  try {
    handle = await open(temporary, 'wx', 0o600)
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
    await handle.close()
    handle = null
    if (preservePrimary) {
      await copyFile(path, `${path}.bak`).catch((error) => {
        if (errorCode(error) !== 'ENOENT') throw error
      })
      await chmod(`${path}.bak`, 0o600).catch(() => {})
    }
    await renameWithRetries(temporary, path, operations.renameFile ?? rename)
    await chmod(path, 0o600).catch(() => {})
  } catch (error) {
    await handle?.close().catch(() => {})
    await rm(temporary, { force: true }).catch(() => {})
    throw error
  }
}

/** @param {string} path @param {boolean} allowCreate @param {{renameFile?: typeof rename}} operations */
const readDocument = async (path, allowCreate, operations) => {
  let primaryError
  try {
    const primary = normalizeDocument(JSON.parse(await readFile(path, 'utf8')))
    if (!validDocument(primary)) throw new Error('invalid_primary')
    return primary
  } catch (error) {
    primaryError = error
  }
  let backupError
  try {
    const backup = normalizeDocument(JSON.parse(await readFile(`${path}.bak`, 'utf8')))
    if (!validDocument(backup)) throw new Error('invalid_backup')
    await writeAtomic(path, backup, false, operations)
    return backup
  } catch (error) {
    backupError = error
  }
  if (
    allowCreate &&
    errorCode(primaryError) === 'ENOENT' &&
    errorCode(backupError) === 'ENOENT'
  ) {
    return { schema_version: schemaVersion, migration_completed: false, records: [] }
  }
  throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_STORAGE_CORRUPT')
}

/**
 * Reads only a fully current primary document. Atomic replacement makes this a
 * safe snapshot while another process owns the writer lock. Recovery, creation
 * and schema migration still take the exclusive lock through readDocument.
 * @param {string} path
 * @returns {Promise<Record<string, any>>}
 */
const readCurrentPrimary = async (path) => {
  const raw = JSON.parse(await readFile(path, 'utf8'))
  const primary = /** @type {Record<string, any>} */ (normalizeDocument(raw))
  if (!validDocument(primary) || JSON.stringify(raw) !== JSON.stringify(primary)) {
    throw new Error('primary_requires_exclusive_recovery')
  }
  return primary
}

/** @param {string} lockPath */
const reclaimMarkerPrefix = (lockPath) => `${basename(lockPath)}.reclaim.`

/** @param {string} lockPath */
const listReclaimMarkers = async (lockPath) => {
  const prefix = reclaimMarkerPrefix(lockPath)
  return (await readdir(dirname(lockPath)))
    .filter((entry) => entry.startsWith(prefix))
    .map((entry) => resolve(dirname(lockPath), entry))
}

/**
 * Reclaim markers are unique and never recreated, so an orphan can be removed
 * without the pathname-reuse race that applies to the canonical lock.
 * @param {string} lockPath
 * @param {typeof rm} [removeFile]
 */
const activeReclaimMarkers = async (lockPath, removeFile = rm) => {
  const prefix = reclaimMarkerPrefix(lockPath)
  const markers = await listReclaimMarkers(lockPath)
  for (const markerPath of markers) {
    const suffix = basename(markerPath).slice(prefix.length)
    const match = suffix.match(/^(\d+)\.([A-Za-z0-9-]+)$/u)
    const metadata = await stat(markerPath).catch(() => null)
    if (!metadata) continue
    const parsedPid = match ? Number(match[1]) : null
    const parsedToken = match?.[2] ?? null
    let processAlive = true
    if (typeof parsedPid === 'number' && Number.isSafeInteger(parsedPid) && parsedPid > 0) {
      try {
        process.kill(parsedPid, 0)
      } catch (error) {
        processAlive = errorCode(error) !== 'ESRCH'
      }
    }
    const orphanedCurrentProcess =
      parsedPid === process.pid &&
      parsedToken !== null &&
      !activeReclaimerTokens.has(parsedToken)
    const malformed = parsedPid === null || parsedToken === null
    if (
      orphanedCurrentProcess ||
      !processAlive ||
      (malformed && Date.now() - metadata.mtimeMs > 5 * 60_000)
    ) {
      await removeWithTransientRetries(markerPath, true, 20, removeFile)
        .catch(() => false)
    }
  }
  return listReclaimMarkers(lockPath)
}

/**
 * Captures an expected lock object through a unique hard link before removing
 * the canonical name. Every canonical lock deletion uses this path so that a
 * later owner must observe the marker and revalidate before entering a mutation.
 * @param {string} lockPath
 * @param {string} expectedOwner
 * @param {{linkLockFile?: typeof link, removeFile?: typeof rm}} [operations]
 */
const removeCapturedLock = async (lockPath, expectedOwner, operations = {}) => {
  const token = randomUUID()
  const markerPath = `${lockPath}.reclaim.${process.pid}.${token}`
  activeReclaimerTokens.add(token)
  try {
    try {
      await (operations.linkLockFile ?? link)(lockPath, markerPath)
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return false
      throw error
    }
    const capturedOwner = await readFile(markerPath, 'utf8').catch(() => null)
    if (capturedOwner !== expectedOwner) return false
    const currentOwner = await readFile(lockPath, 'utf8').catch(() => null)
    if (currentOwner !== expectedOwner) return false
    return await removeWithTransientRetries(
      lockPath,
      false,
      20,
      operations.removeFile,
    )
  } finally {
    await removeWithTransientRetries(markerPath, true, 20, operations.removeFile)
      .catch(() => false)
    activeReclaimerTokens.delete(token)
  }
}

/**
 * A newly linked owner cannot enter its critical section until every active
 * stale-lock reclaimer has finished and the canonical name still identifies
 * that owner.
 * @param {string} lockPath
 * @param {string} owner
 * @param {typeof rm} [removeFile]
 */
const waitForStableOwnership = async (lockPath, owner, removeFile = rm) => {
  for (let attempt = 0; attempt < 500; attempt += 1) {
    const markers = await activeReclaimMarkers(lockPath, removeFile)
    const observedOwner = await readFile(lockPath, 'utf8').catch(() => null)
    if (markers.length === 0 && observedOwner === owner) return true
    if (observedOwner !== owner) return false
    await delay(10)
  }
  return false
}

/** @param {string} lockPath @param {{openLockFile?: typeof open, linkLockFile?: typeof link, removeFile?: typeof rm}} [operations] */
const acquireLock = async (lockPath, operations = {}) => {
  const token = randomUUID()
  const owner = `${JSON.stringify({ token, pid: process.pid })}\n`
  for (let attempt = 0; attempt < 500; attempt += 1) {
    const temporaryLockPath = `${lockPath}.${token}.${attempt}.claim`
    let claimed = false
    /** @type {import('node:fs/promises').FileHandle | null} */
    let handle = null
    try {
      handle = await (operations.openLockFile ?? open)(temporaryLockPath, 'wx', 0o600)
      await handle.writeFile(owner, 'utf8')
      await handle.sync()
      await handle.close()
      handle = null
      // Publish the in-process owner token before the hard-link attempt. A
      // second repository in this process must never mistake the just-linked
      // owner for an orphan in the await continuation window.
      activeOwnerTokens.add(token)
      await (operations.linkLockFile ?? link)(temporaryLockPath, lockPath)
      claimed = true
      await removeWithTransientRetries(
        temporaryLockPath,
        true,
        20,
        operations.removeFile,
      )
      if (!await waitForStableOwnership(lockPath, owner, operations.removeFile)) {
        await removeCapturedLock(lockPath, owner, operations).catch(() => false)
        activeOwnerTokens.delete(token)
        claimed = false
        await delay(10)
        continue
      }
      return { owner, token }
    } catch (error) {
      await handle?.close().catch(() => {})
      await removeWithTransientRetries(
        temporaryLockPath,
        true,
        20,
        operations.removeFile,
      ).catch(() => false)
      if (claimed) {
        await removeCapturedLock(lockPath, owner, operations).catch(() => false)
      }
      activeOwnerTokens.delete(token)
      if (errorCode(error) !== 'EEXIST') throw error
      const observedOwner = await readFile(lockPath, 'utf8').catch(() => null)
      const metadata = await stat(lockPath).catch(() => null)
      let parsedPid = null
      let parsedToken = null
      let malformed = false
      let processAlive = true
      try {
        const parsed = JSON.parse(observedOwner ?? '')
        if (
          !Number.isSafeInteger(parsed?.pid) ||
          parsed.pid < 1 ||
          typeof parsed.token !== 'string' ||
          parsed.token.length === 0
        ) throw new Error('invalid_lock')
        parsedPid = parsed.pid
        parsedToken = parsed.token
        process.kill(parsed.pid, 0)
      } catch (ownerError) {
        malformed = parsedPid === null || parsedToken === null
        processAlive = errorCode(ownerError) !== 'ESRCH'
      }
      const orphanedCurrentProcess =
        parsedPid === process.pid &&
        parsedToken !== null &&
        !activeOwnerTokens.has(parsedToken)
      if (
        observedOwner !== null &&
        metadata &&
        (
          orphanedCurrentProcess ||
          (
            (!processAlive || malformed) &&
            Date.now() - metadata.mtimeMs > 5 * 60_000
          )
        ) &&
        await readFile(lockPath, 'utf8').catch(() => null) === observedOwner
      ) {
        if (
          await removeCapturedLock(lockPath, observedOwner, operations)
            .catch(() => false)
        ) continue
      }
      await delay(10)
    }
  }
  throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_STORAGE_LOCKED', 503)
}

/** @param {string} lockPath @param {{owner: string, token: string}} lock @param {{linkLockFile?: typeof link, removeFile?: typeof rm}} [operations] */
const releaseLock = async (lockPath, lock, operations = {}) => {
  try {
    await removeCapturedLock(lockPath, lock.owner, operations).catch(() => false)
  } finally {
    activeOwnerTokens.delete(lock.token)
  }
}

/** @param {Record<string, any>} generated @param {string} label @param {string} libraryTemplateId @param {string} status @param {number} revision @param {string} at @param {'created'|'editable_revision'|'migrated'} source @param {string} [createdAt] */
const storedRecord = (
  generated,
  label,
  libraryTemplateId,
  status,
  revision,
  at,
  source,
  createdAt = at,
) => {
  if (!validReferenceArtifact(generated, 2) || containsPrivateData(generated)) {
    throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_ARTIFACT_INVALID', 400)
  }
  const summaries = summarizeReusableTemplateArtifact(generated)
  return {
    libraryTemplateId,
    contractVersion: 2,
    label,
    status,
    revision,
    fingerprint: reusableTemplateFingerprint(generated),
    orientation: generated.templateSelectionRequest.orientation,
    targetDurationSeconds: generated.templateSelectionRequest.target_duration_seconds,
    pacing: generated.templateSelectionRequest.pacing,
    ...summaries,
    artifact: clone(generated),
    source,
    createdAt,
    updatedAt: at,
  }
}

/** @param {Record<string, any>[]} records */
const latestRecords = (records) => {
  const latest = new Map()
  for (const entry of records) {
    const prior = latest.get(entry.libraryTemplateId)
    if (!prior || prior.revision < entry.revision) latest.set(entry.libraryTemplateId, entry)
  }
  return [...latest.values()]
}

/** @type {Readonly<Record<string, number>>} */
const displayStatusPriority = {
  approved: 3,
  draft: 2,
  inactive: 1,
}

/** @param {Record<string, any>} value */
const displayPreviewPriority = (value) => {
  const preview = value.previewAvailability
  return (preview?.demoPlayable ? 4 : 0) +
    (preview?.referencePlayable ? 2 : 0) +
    (preview?.styleAnalysisComplete ? 1 : 0)
}

/**
 * Multiple library IDs can point to the same immutable artifact after a
 * repeated import or repair. Keep one canonical card for the artifact plus one
 * active editable-repair card, so the approved source and repair stay visible.
 * Repeated repair drafts with the same fingerprint still collapse to one card.
 * Preview state is resolved before this projection because media sidecars are
 * stored per library ID rather than per artifact fingerprint.
 * @param {Record<string, any>[]} records
 */
const deduplicateDisplayRecords = (records) => {
  const unique = new Map()
  for (const entry of records) {
    const editableRepair = entry.status === 'draft' && (
      entry.source === 'editable_revision' || entry.label.endsWith('（可编辑修订）')
    )
    const displayKey = editableRepair
      ? `${entry.fingerprint}:editable_revision`
      : entry.fingerprint
    const prior = unique.get(displayKey)
    if (!prior) {
      unique.set(displayKey, entry)
      continue
    }
    const priorPreviewPriority = displayPreviewPriority(prior)
    const entryPreviewPriority = displayPreviewPriority(entry)
    const priorPriority = displayStatusPriority[prior.status] ?? 0
    const entryPriority = displayStatusPriority[entry.status] ?? 0
    const preferEntry =
      entryPreviewPriority > priorPreviewPriority ||
      (entryPreviewPriority === priorPreviewPriority && entryPriority > priorPriority) ||
      (entryPreviewPriority === priorPreviewPriority &&
        entryPriority === priorPriority &&
        entry.updatedAt > prior.updatedAt)
    if (preferEntry) unique.set(displayKey, entry)
  }
  return [...unique.values()]
}

/**
 * @param {{
 *  dataRoot: string,
 *  securePrivateRoot?: (root: string) => Promise<void>,
 *  now?: () => Date,
 *  createId?: () => string,
 *  migrationSource?: () => Promise<Record<string, any>[]>,
 *  storageOperations?: {
 *    openLockFile?: typeof open,
 *    linkLockFile?: typeof link,
 *    renameFile?: typeof rename,
 *    removeFile?: typeof rm,
 *  },
 *  resolvePreviewAvailability?: (libraryTemplateId: string) => Promise<Record<string, any>>,
 *  resolveReplicationRecipe?: (libraryTemplateId: string) => Promise<Record<string, any> | null>,
 *  resolveStyleSummary?: (libraryTemplateId: string) => Promise<Record<string, any> | null>,
 * }} options
 */
export const createReusableTemplateRepository = async ({
  dataRoot,
  securePrivateRoot = securePrivateRuntimeRoot,
  now = () => new Date(),
  createId = () => `library-template-${randomUUID()}`,
  migrationSource,
  storageOperations = {},
  resolvePreviewAvailability,
  resolveReplicationRecipe,
  resolveStyleSummary,
}) => {
  if (!isAbsolute(dataRoot) || inside(repositoryRoot, dataRoot)) {
    throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DATA_ROOT_UNSAFE')
  }
  await mkdir(dataRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(dataRoot)
  const path = resolve(dataRoot, 'reusable-templates.json')
  const lockPath = `${path}.lock`
  /** @type {Promise<unknown>} */
  let queue = Promise.resolve()

  /** @template T @param {(document: Record<string, any>) => Promise<{document: Record<string, any>, result: T}>} operation */
  const mutate = (operation) => {
    const run = async () => {
      const lock = await acquireLock(lockPath, storageOperations)
      try {
        const document = /** @type {Record<string, any>} */ (
          await readDocument(path, true, storageOperations)
        )
        const output = await operation(clone(document))
        if (!validDocument(output.document)) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECORD_INVALID')
        }
        await writeAtomic(path, output.document, true, storageOperations)
        return clone(output.result)
      } finally {
        await releaseLock(lockPath, lock, storageOperations)
      }
    }
    const result = queue.then(run, run)
    queue = result.then(() => undefined, () => undefined)
    return result
  }
  const read = async () => {
    try {
      return clone(await readCurrentPrimary(path))
    } catch {
      // Missing, legacy or damaged primary data is recovered only under lock.
    }
    const lock = await acquireLock(lockPath, storageOperations)
    try {
      const document = /** @type {Record<string, any>} */ (
        await readDocument(path, true, storageOperations)
      )
      const persisted = await readFile(path, 'utf8').catch(() => null)
      if (
        persisted === null ||
        JSON.stringify(JSON.parse(persisted)) !== JSON.stringify(document)
      ) {
        await writeAtomic(path, document, true, storageOperations)
      }
      return clone(document)
    } finally {
      await releaseLock(lockPath, lock, storageOperations)
    }
  }

  /** @param {Record<string, any>} stored */
  const toPublic = async (stored) => {
    let recipeIdentityVerified = stored.status === 'draft'
    const [previewAvailability, styleSummary, replicationRecipe] = await Promise.all([
      typeof resolvePreviewAvailability === 'function'
        ? resolvePreviewAvailability(stored.libraryTemplateId).catch(() => ({
          referencePlayable: false,
          demoPlayable: false,
          demoStatus: 'unavailable',
          demoRenderer: null,
          demoAuthentic: false,
          styleAnalysisComplete: false,
          approveReady: false,
        }))
        : Promise.resolve(undefined),
      typeof resolveStyleSummary === 'function'
        ? resolveStyleSummary(stored.libraryTemplateId).catch(() => null)
        : Promise.resolve(undefined),
      typeof resolveReplicationRecipe === 'function'
        ? resolveReplicationRecipe(stored.libraryTemplateId).catch(() => null)
        : Promise.resolve(undefined),
    ])
    if (stored.status !== 'draft' && isReplicationRecipe(replicationRecipe)) {
      recipeIdentityVerified =
        typeof stored.approvedRecipeFingerprint === 'string' &&
        stored.approvedRecipeFingerprint === replicationRecipeFingerprint(replicationRecipe)
    }
    return toReusableTemplatePublicDetail(
      stored,
      {
        ...(previewAvailability ? { previewAvailability } : {}),
        ...(replicationRecipe ? { replicationRecipe } : {}),
        ...(styleSummary ? { styleSummary } : {}),
        recipeIdentityVerified,
        recipeIdentityVerificationAttempted: stored.status !== 'draft' && isReplicationRecipe(replicationRecipe),
      },
    )
  }

  /** @param {string} libraryTemplateId */
  const requireReplicationRecipe = async (libraryTemplateId) => {
    const recipe = typeof resolveReplicationRecipe === 'function'
      ? await resolveReplicationRecipe(libraryTemplateId).catch(() => null)
      : null
    if (!isReplicationRecipe(recipe)) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_REQUIRED', 409)
    }
    return recipe
  }

  /** @param {Record<string, any>} stored */
  const healMissingApprovedRecipeFingerprint = async (stored) => {
    if (
      stored.contractVersion !== 2 ||
      (stored.status !== 'approved' && stored.status !== 'inactive') ||
      typeof stored.approvedRecipeFingerprint === 'string'
    ) return stored
    const recipe = typeof resolveReplicationRecipe === 'function'
      ? await resolveReplicationRecipe(stored.libraryTemplateId).catch(() => null)
      : null
    if (!isReplicationRecipe(recipe)) return stored
    const fingerprint = replicationRecipeFingerprint(recipe)
    try {
      return await mutate(async (document) => {
        const latest = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === stored.libraryTemplateId)
        if (!latest || typeof latest.approvedRecipeFingerprint === 'string') {
          return { document, result: latest ?? stored }
        }
        const index = document.records.findLastIndex((/** @type {Record<string, any>} */ entry) =>
          entry.libraryTemplateId === latest.libraryTemplateId &&
          entry.revision === latest.revision)
        if (index < 0) return { document, result: latest }
        const next = {
          ...clone(latest),
          approvedRecipeFingerprint: fingerprint,
        }
        document.records[index] = next
        return { document, result: next }
      })
    } catch {
      return stored
    }
  }

  /** @param {Record<string, any>} stored */
  const requireApprovedReplicationRecipe = async (stored) => {
    const current = await healMissingApprovedRecipeFingerprint(stored)
    const recipe = await requireReplicationRecipe(current.libraryTemplateId)
    if (typeof current.approvedRecipeFingerprint !== 'string') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_REQUIRED', 409)
    }
    const observedFingerprint = replicationRecipeFingerprint(recipe)
    if (observedFingerprint !== current.approvedRecipeFingerprint) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_CHANGED', 409)
    }
    return {
      recipe,
      fingerprint: observedFingerprint,
    }
  }

  const initialDocument = await read()
  if (migrationSource && !initialDocument.migration_completed) {
    await mutate(async (document) => {
      if (document.migration_completed) return { document, result: 0 }
      const approved = await migrationSource()
      if (!Array.isArray(approved)) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_MIGRATION_INVALID')
      }
      const fingerprints = new Set(latestRecords(document.records).map((entry) => entry.fingerprint))
      let imported = 0
      for (const legacy of approved) {
        if (!record(legacy) || legacy.status !== 'approved') continue
        const artifact = {
          templateSelectionRequest: clone(legacy.templateSelectionRequest),
          adapterRequest: clone(legacy.adapterRequest),
          analysis: clone(legacy.analysis),
          draft: clone(legacy.draft),
          preflight: clone(legacy.preflight),
        }
        if (!validReferenceArtifact(artifact, 2) || containsPrivateData(artifact)) continue
        const fingerprint = reusableTemplateFingerprint(artifact)
        if (fingerprints.has(fingerprint)) continue
        const at = now().toISOString()
        document.records.push(storedRecord(
          artifact,
          '已迁移参考模板',
          createId(),
          'approved',
          1,
          at,
          'migrated',
        ))
        fingerprints.add(fingerprint)
        imported += 1
      }
      document.migration_completed = true
      return { document, result: imported }
    })
  }

  return {
    async probeAvailability() {
      await read()
      return { available: true, state: 'ready', code: null }
    },
    async list() {
      const document = await read()
      const latest = latestRecords(document.records)
      const healed = []
      for (const entry of latest) {
        healed.push(await healMissingApprovedRecipeFingerprint(entry))
      }
      const details = await Promise.all(healed.map((entry) => toPublic(entry)))
      return deduplicateDisplayRecords(details)
        .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))
    },
    /** @param {string} libraryTemplateId */
    async get(libraryTemplateId) {
      const document = await read()
      const found = latestRecords(document.records)
        .find((entry) => entry.libraryTemplateId === libraryTemplateId)
      return found ? toPublic(await healMissingApprovedRecipeFingerprint(found)) : null
    },
    /** Trusted internal record with artifact; never expose to browser. @param {string} libraryTemplateId */
    async getStored(libraryTemplateId) {
      if (!identifier(libraryTemplateId)) return null
      const document = await read()
      const found = latestRecords(document.records)
        .find((entry) => entry.libraryTemplateId === libraryTemplateId)
      return found ? clone(found) : null
    },
    /** @param {Record<string, any>} input */
    async create(input) {
      if (
        !record(input) ||
        !isReusableTemplateCreateCommand(input.sourceKind
          ? {
              label: input.label,
              orientation: input.orientation,
              pacing: input.pacing,
              targetDurationSeconds: input.targetDurationSeconds,
              sourceAuthorizationId: input.sourceAuthorizationId,
              sourceKind: input.sourceKind,
            }
          : {
              label: input.label,
              orientation: input.orientation,
              pacing: input.pacing,
              targetDurationSeconds: input.targetDurationSeconds,
              referenceAuthorizationId: input.referenceAuthorizationId,
            }) ||
        !validReferenceArtifact(input.generated, 2)
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_INPUT_INVALID', 400)
      return mutate(async (document) => {
        const candidate = storedRecord(
          input.generated,
          input.label,
          createId(),
          'draft',
          1,
          now().toISOString(),
          'created',
        )
        const duplicate = latestRecords(document.records)
          .find((entry) => entry.fingerprint === candidate.fingerprint)
        if (duplicate && duplicate.status !== 'inactive') {
          return { document, result: await toPublic(duplicate) }
        }
        document.records.push(candidate)
        return { document, result: await toPublic(candidate) }
      })
    },
    /** @param {{libraryTemplateId: string, expectedRevision: number, label: string}} input Create a new editable record without mutating the approved source. */
    async forkApprovedToDraft(input) {
      if (!identifier(input?.libraryTemplateId) || !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1 || typeof input?.label !== 'string' || input.label.trim().length < 1 || input.label.trim().length > 120) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_INVALID', 400)
      }
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (!current) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        if (current.contractVersion !== 2 || current.status !== 'approved' || current.revision !== input.expectedRevision) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        const existingDraft = latestRecords(document.records)
          .filter((entry) =>
            entry.contractVersion === 2 &&
            entry.status === 'draft' &&
            (
              entry.source === 'editable_revision' ||
              entry.label.endsWith('（可编辑修订）')
            ) &&
            entry.fingerprint === current.fingerprint)
          .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))[0]
        if (existingDraft) {
          return {
            document,
            result: { template: await toPublic(existingDraft), created: false },
          }
        }
        const at = now().toISOString()
        const candidate = storedRecord(
          current.artifact,
          input.label.trim(),
          createId(),
          'draft',
          1,
          at,
          'editable_revision',
        )
        document.records.push(candidate)
        return {
          document,
          result: { template: await toPublic(candidate), created: true },
        }
      })
    },
    /**
     * Remove a newly-created repair draft when its private preparation fails.
     * @param {{libraryTemplateId: string, expectedRevision: number, fingerprint: string}} input
     */
    async discardDraft(input) {
      if (
        !identifier(input?.libraryTemplateId) ||
        !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1 ||
        typeof input?.fingerprint !== 'string' ||
        !/^[a-f0-9]{64}$/u.test(input.fingerprint)
      ) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_INVALID', 400)
      }
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (
          !current ||
          current.status !== 'draft' ||
          current.revision !== input.expectedRevision ||
          current.fingerprint !== input.fingerprint
        ) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        document.records = document.records.filter(
          (/** @type {Record<string, any>} */ entry) =>
            entry.libraryTemplateId !== input.libraryTemplateId,
        )
        return { document, result: true }
      })
    },
    /** @param {{libraryTemplateId: string, expectedRevision: number, decision: string}} input */
    async review(input) {
      if (
        !identifier(input?.libraryTemplateId) ||
        !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1 ||
        input.decision !== 'approve'
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVIEW_INVALID', 400)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (!current) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        if (current.contractVersion === 1) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (current.revision !== input.expectedRevision || current.status !== 'draft') {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        const previewAvailability = typeof resolvePreviewAvailability === 'function'
          ? await resolvePreviewAvailability(current.libraryTemplateId)
          : null
        if (!previewReadyForApproval(previewAvailability)) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
        }
        const recipe = await requireReplicationRecipe(current.libraryTemplateId)
        const next = {
          ...clone(current),
          status: 'approved',
          revision: current.revision + 1,
          approvedRecipeFingerprint: replicationRecipeFingerprint(recipe),
          updatedAt: now().toISOString(),
        }
        document.records.push(next)
        return { document, result: await toPublic(next) }
      })
    },
    /** @param {{libraryTemplateId: string, expectedRevision: number}} input */
    async deactivate(input) {
      if (
        !identifier(input?.libraryTemplateId) ||
        !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEACTIVATE_INVALID', 400)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (!current) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        if (current.contractVersion === 1) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (current.revision !== input.expectedRevision || current.status !== 'approved') {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        const next = {
          ...clone(current),
          status: 'inactive',
          revision: current.revision + 1,
          updatedAt: now().toISOString(),
        }
        document.records.push(next)
        return { document, result: await toPublic(next) }
      })
    },
    /** @param {{libraryTemplateId: string, expectedRevision: number}} input */
    async remove(input) {
      if (
        !identifier(input?.libraryTemplateId) ||
        !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REMOVE_INVALID', 400)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (!current) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        if (current.revision !== input.expectedRevision) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        document.records = document.records.filter(
          (/** @type {Record<string, any>} */ entry) => entry.libraryTemplateId !== input.libraryTemplateId,
        )
        return {
          document,
          result: {
            libraryTemplateId: input.libraryTemplateId,
            removed: true,
          },
        }
      })
    },
    /** @param {{libraryTemplateId: string, expectedRevision: number, label: string}} input */
    async relabel(input) {
      const label = typeof input?.label === 'string' ? input.label.trim() : ''
      if (
        !identifier(input?.libraryTemplateId) ||
        !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1 ||
        !isReusableTemplateLabel(label)
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RELABEL_INVALID', 400)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (!current) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        if (current.contractVersion === 1) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (current.revision !== input.expectedRevision) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        if (current.label === label) return { document, result: await toPublic(current) }
        const next = {
          ...clone(current),
          label,
          revision: current.revision + 1,
          updatedAt: now().toISOString(),
        }
        document.records.push(next)
        return { document, result: await toPublic(next) }
      })
    },
    /** Restore a soft-deactivated template back to approved / usable shelf. */
    /** @param {{libraryTemplateId: string, expectedRevision: number}} input */
    async reactivate(input) {
      if (
        !identifier(input?.libraryTemplateId) ||
        !Number.isSafeInteger(input?.expectedRevision) ||
        input.expectedRevision < 1
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REACTIVATE_INVALID', 400)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === input.libraryTemplateId)
        if (!current) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        if (current.contractVersion === 1) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (current.revision !== input.expectedRevision || current.status !== 'inactive') {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        const previewAvailability = typeof resolvePreviewAvailability === 'function'
          ? await resolvePreviewAvailability(current.libraryTemplateId)
          : null
        if (!previewReadyForApproval(previewAvailability)) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
        }
        const recipe = await requireReplicationRecipe(current.libraryTemplateId)
        const recipeFingerprint = replicationRecipeFingerprint(recipe)
        if (
          typeof current.approvedRecipeFingerprint === 'string' &&
          current.approvedRecipeFingerprint !== recipeFingerprint
        ) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_CHANGED', 409)
        }
        const next = {
          ...clone(current),
          status: 'approved',
          revision: current.revision + 1,
          approvedRecipeFingerprint: recipeFingerprint,
          updatedAt: now().toISOString(),
        }
        document.records.push(next)
        return { document, result: await toPublic(next) }
      })
    },
    /** Trusted server-only immutable binding boundary. */
    async getApprovedForUse(
      /** @type {string} */ libraryTemplateId,
      /** @type {number} */ revision,
    ) {
      if (
        !identifier(libraryTemplateId) ||
        !Number.isSafeInteger(revision) ||
        revision < 1
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
      const document = await read()
      const current = latestRecords(document.records)
        .find((entry) => entry.libraryTemplateId === libraryTemplateId)
      if (current?.contractVersion === 1) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
      }
      if (current?.status !== 'approved' || current.revision !== revision) return null
      const previewAvailability = typeof resolvePreviewAvailability === 'function'
        ? await resolvePreviewAvailability(libraryTemplateId)
        : null
      if (!previewReadyForApproval(previewAvailability)) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
      }
      const verified = await requireApprovedReplicationRecipe(current)
      return clone({
        ...current,
        replicationRecipe: verified.recipe,
      })
    },
    /**
     * Holds the repository lock while a draft recipe sidecar is read and rewritten.
     * Approval therefore linearizes after the complete sidecar mutation.
     * @template T
     * @param {string} libraryTemplateId
     * @param {number} expectedRevision
     * @param {(current: Record<string, any>) => Promise<T>} callback
     */
    async withDraftRecipeMutation(libraryTemplateId, expectedRevision, callback) {
      if (
        !identifier(libraryTemplateId) ||
        !Number.isSafeInteger(expectedRevision) ||
        expectedRevision < 1 ||
        typeof callback !== 'function'
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === libraryTemplateId)
        if (!current) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        }
        if (current.contractVersion !== 2) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (current.revision !== expectedRevision) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        if (current.status !== 'draft') {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_IMMUTABLE', 409)
        }
        const result = await callback(clone(current))
        return { document, result }
      })
    },
    /**
     * Holds the repository mutation lock while the caller commits a binding.
     * Deactivation therefore linearizes either before this validation or after
     * the project mutation, never between the two.
     * @template T
     * @param {string} libraryTemplateId
     * @param {number} revision
     * @param {(approved: Record<string, any>) => Promise<T>} callback
     */
    async withApprovedForUse(libraryTemplateId, revision, callback) {
      if (
        !identifier(libraryTemplateId) ||
        !Number.isSafeInteger(revision) ||
        revision < 1 ||
        typeof callback !== 'function'
      ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
      return mutate(async (document) => {
        const current = latestRecords(document.records)
          .find((entry) => entry.libraryTemplateId === libraryTemplateId)
        if (!current) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
        }
        if (current.revision !== revision) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        if (current.contractVersion !== 2) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (current.status !== 'approved') {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_APPROVED', 409)
        }
        if (typeof resolvePreviewAvailability === 'function') {
          const previewAvailability = await resolvePreviewAvailability(libraryTemplateId)
          if (!previewReadyForApproval(previewAvailability)) {
            throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
          }
        } else {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
        }
        let enriched = clone(current)
        if (typeof resolveStyleSummary === 'function') {
          const styleSummary = await resolveStyleSummary(libraryTemplateId)
          if (styleSummary) enriched = { ...enriched, styleSummary }
        }
        const verified = await requireApprovedReplicationRecipe(current)
        enriched = {
          ...enriched,
          replicationRecipe: verified.recipe,
        }
        const result = await callback(enriched)
        return { document, result }
      })
    },
  }
}

/**
 * @param {{
 *  repository: Record<string, Function>,
 *  authorizationRepository: {get: (id: string) => any, remove?: (id: string) => any},
 *  referenceTemplateAdapter: {generate: (input: any) => Promise<any>},
 *  uploadReferenceVideo?: (input: {projectId: string} & (
 *    {sessionId: string, nodeId: string, readOnlyConfirmed: true} |
 *    {absolutePath: string} |
 *    {file: any}
 *  )) => Promise<any>,
 *  authorizeJianyingDraft?: (input: {projectId: string, sessionId?: string, nodeId?: string, readOnlyConfirmed?: boolean, absolutePath?: string}) => Promise<any>,
 *  cleanupReferenceUpload?: (input: {projectId: string, authorizationId: string}) => Promise<boolean>,
 *  templateMediaStore?: {
 *    ingestReference: Function,
 *    generateDemo: Function,
 *    previewAvailability: Function,
 *    resolveResource: Function,
 *    readMeta?: Function,
 *    ingestAudio?: Function,
 *    ingestReferenceAudio?: Function,
 *    writeReplicationRecipe?: Function,
 *    readReplicationRecipe?: Function,
 *    writePackagingMap?: Function,
 *    cloneAssetsToTemplate?: Function,
 *    removeTemplateAssets?: Function,
 *  },
 *  templateBlueprintStore?: {ingest: Function, resolvePrivateFolder: Function},
 *  jianyingTemplateReader?: {inspect: Function},
 *  isVoiceProfileReady?: (voiceProfileId: string) => Promise<boolean>,
 *  createScopeId?: () => string,
 * }} dependencies
 */
/** @param {string} absolutePath @param {string | null} fallback */
const labelFromAuthorizedSourcePath = async (absolutePath, fallback) => {
  if (typeof absolutePath === 'string' && isAbsolute(absolutePath)) {
    try {
      const meta = JSON.parse(await readFile(resolve(absolutePath, 'draft_meta_info.json'), 'utf8'))
      const fromMeta = sanitizeReusableTemplateSourceLabel(meta?.draft_name)
      if (fromMeta) return fromMeta
    } catch {
      // Live draft folders are optional; basename is the Jianying homepage name.
    }
    const folderName = sanitizeReusableTemplateSourceLabel(basename(absolutePath))
    if (folderName) return folderName
    const fileStem = sanitizeReusableTemplateSourceLabel(basename(absolutePath, extname(absolutePath)))
    if (fileStem) return fileStem
  }
  return fallback
}

export const createReusableTemplateLibraryService = (/** @type {any} */ {
  repository,
  authorizationRepository,
  referenceTemplateAdapter,
  uploadReferenceVideo,
  authorizeJianyingDraft,
  cleanupReferenceUpload,
  templateMediaStore,
  templateBlueprintStore,
  jianyingTemplateReader,
  isVoiceProfileReady,
  createScopeId = () => `library-upload-${randomUUID()}`,
}) => ({
  async probeAvailability() {
    return repository.probeAvailability()
  },
  /** @param {{file?: any, sessionId?: string, nodeId?: string, readOnlyConfirmed?: boolean, absolutePath?: string}} input */
  async upload(input) {
    if (typeof uploadReferenceVideo !== 'function') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_UPLOAD_INVALID', 400)
    }
    const projectId = createScopeId()
    if (!identifier(projectId)) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_SCOPE_INVALID')
    }
    const uploaded = input?.sessionId && input?.nodeId
      ? await uploadReferenceVideo({
          projectId,
          sessionId: input.sessionId,
          nodeId: input.nodeId,
          readOnlyConfirmed: true,
        })
      : input?.absolutePath
        ? await uploadReferenceVideo({ projectId, absolutePath: input.absolutePath })
          : input?.file
            ? await uploadReferenceVideo({ projectId, file: input.file })
            : input?.readOnlyConfirmed === true
            ? await uploadReferenceVideo(/** @type {any} */ ({ projectId, readOnlyConfirmed: true }))
            : null
    if (
      !record(uploaded) ||
      !identifier(uploaded.authorizationId) ||
      uploaded.label !== '已上传参考视频'
    ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_UPLOAD_INVALID', 502)
    return {
      authorizationId: uploaded.authorizationId,
      label: uploaded.label,
    }
  },
  /** @param {{sessionId?: string, nodeId?: string, readOnlyConfirmed?: boolean, absolutePath?: string}} input */
  async authorizeDraft(input) {
    if (typeof authorizeJianyingDraft !== 'function') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DRAFT_UNAUTHORIZED', 503)
    }
    const projectId = createScopeId()
    if (!identifier(projectId)) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_SCOPE_INVALID')
    }
    const authorized = input?.sessionId && input?.nodeId
      ? await authorizeJianyingDraft({
          projectId,
          sessionId: input.sessionId,
          nodeId: input.nodeId,
          readOnlyConfirmed: true,
        })
      : input?.absolutePath
        ? await authorizeJianyingDraft({
            projectId,
            absolutePath: input.absolutePath,
            readOnlyConfirmed: true,
          })
        : input?.readOnlyConfirmed === true
          ? await authorizeJianyingDraft({
              projectId,
              readOnlyConfirmed: true,
            })
          : null
    if (
      !record(authorized) ||
      !identifier(authorized.authorizationId) ||
      authorized.label !== '已授权剪映草稿'
    ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DRAFT_UNAUTHORIZED', 502)
    return {
      authorizationId: authorized.authorizationId,
      label: authorized.label,
    }
  },
  async list() { return repository.list() },
  /** @param {string} libraryTemplateId */
  async get(libraryTemplateId) { return repository.get(libraryTemplateId) },
  /**
   * Attach a local reference video to a draft that learned from a Jianying draft
   * without an available media path, then generate authentic demo + style analysis.
   * @param {string} libraryTemplateId
   * @param {{ sourceAuthorizationId: string, expectedRevision: number }} input
   */
  async attachReference(libraryTemplateId, input) {
    if (
      !identifier(libraryTemplateId) ||
      !record(input) ||
      !identifier(input.sourceAuthorizationId) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_ATTACH_INVALID', 400)
    }
    if (
      !templateMediaStore ||
      typeof templateMediaStore.ingestReference !== 'function' ||
      typeof templateMediaStore.generateDemo !== 'function' ||
      typeof templateMediaStore.readMeta !== 'function'
    ) {
      throw new ReusableTemplateRepositoryError('TEMPLATE_MEDIA_UNAVAILABLE', 503)
    }
    if (typeof repository.getStored !== 'function') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE', 503)
    }
    const stored = await repository.getStored(libraryTemplateId)
    if (!stored) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
    if (stored.contractVersion !== 2) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEGACY_READ_ONLY', 409)
    }
    if (stored.status !== 'draft') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_ATTACH_DRAFT_ONLY', 409)
    }
    if (stored.revision !== input.expectedRevision) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
    }
    const existingMeta = await templateMediaStore.readMeta(libraryTemplateId)
    if (existingMeta?.reference?.fileName) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REFERENCE_EXISTS', 409)
    }
    const authorization = await authorizationRepository.get(input.sourceAuthorizationId)
    if (
      !record(authorization) ||
      authorization.id !== input.sourceAuthorizationId ||
      authorization.status !== 'authorized' ||
      typeof authorization.absolutePath !== 'string'
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_AUTHORIZATION_INVALID', 409)
    }
    try {
      await templateMediaStore.ingestReference(libraryTemplateId, authorization.absolutePath)
      await templateMediaStore.generateDemo(libraryTemplateId, {
        durationSeconds: Math.min(15, Math.max(8, stored.targetDurationSeconds)),
        label: stored.label,
        storedTemplate: {
          libraryTemplateId: stored.libraryTemplateId,
          revision: stored.revision,
          fingerprint: stored.fingerprint,
          label: stored.label,
          orientation: stored.orientation,
          targetDurationSeconds: stored.targetDurationSeconds,
          pacing: stored.pacing,
          status: 'draft',
          artifact: stored.artifact,
        },
      })
    } finally {
      if (typeof cleanupReferenceUpload === 'function') {
        await cleanupReferenceUpload({
          projectId: authorization.projectId,
          authorizationId: input.sourceAuthorizationId,
        })
      }
    }
    return repository.get(libraryTemplateId)
  },
  /**
   * Trusted server-only immutable binding boundary.
   * @param {string} libraryTemplateId
   * @param {number} revision
   */
  async getApprovedForUse(libraryTemplateId, revision) {
    const approved = await repository.getApprovedForUse(libraryTemplateId, revision)
    if (!approved) return null
    if (templateMediaStore) {
      const availability = await templateMediaStore.previewAvailability(libraryTemplateId)
      if (!previewReadyForApproval(availability)) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
      }
    }
    return approved
  },
  /**
   * @template T
   * @param {string} libraryTemplateId
   * @param {number} revision
   * @param {(approved: Record<string, any>) => Promise<T>} callback
   */
  async withApprovedForUse(libraryTemplateId, revision, callback) {
    return repository.withApprovedForUse(libraryTemplateId, revision, async (/** @type {Record<string, any>} */ approved) => {
      if (templateMediaStore) {
        const availability = await templateMediaStore.previewAvailability(libraryTemplateId)
        if (!previewReadyForApproval(availability)) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DEMO_REQUIRED', 409)
        }
      }
      return callback(approved)
    })
  },
  /** @param {any} input */
  async create(input) {
    if (!isReusableTemplateCreateCommand(input)) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_INPUT_INVALID', 400)
    }
    const sourceKind = input.sourceKind === 'jianying_draft'
      ? 'jianying_draft'
      : 'video_analysis'
    const authorizationId = sourceKind === 'jianying_draft'
      ? input.sourceAuthorizationId
      : (input.sourceAuthorizationId || input.referenceAuthorizationId)
    const authorization = await authorizationRepository.get(authorizationId)
    if (
      !record(authorization) ||
      authorization.id !== authorizationId ||
      !identifier(authorization.projectId) ||
      authorization.status !== 'authorized' ||
      typeof authorization.absolutePath !== 'string'
    ) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_AUTHORIZATION_INVALID', 409)
    /** @type {Record<string, any> | null} */
    let replicationRecipe = null
    /** @type {Record<string, any> | null} */
    let blueprint = null
    /** @type {Record<string, any> | undefined} */
    let generated
    try {
      if (sourceKind === 'jianying_draft') {
        if (
          !templateBlueprintStore ||
          typeof templateBlueprintStore.ingest !== 'function' ||
          !jianyingTemplateReader ||
          typeof jianyingTemplateReader.inspect !== 'function'
        ) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DRAFT_READER_UNAVAILABLE', 503)
        }
        blueprint = await templateBlueprintStore.ingest(authorization.absolutePath)
        if (!blueprint) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_DRAFT_READER_UNAVAILABLE', 503)
        }
        // Recipe must be derived from the immutable private blueprint snapshot,
        // not the live authorization path which can change after ingest.
        const blueprintFolder = await templateBlueprintStore.resolvePrivateFolder(
          blueprint.blueprintId,
          blueprint.fingerprint,
        )
        const inspected = await jianyingTemplateReader.inspect({
          draftFolder: blueprintFolder,
          blueprintId: blueprint.blueprintId,
          fingerprint: blueprint.fingerprint,
        })
        replicationRecipe = inspected.recipe
        if (!replicationRecipe) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_INPUT_INVALID', 400)
        }
        const derived = deriveTemplateProfileFromSource({
          canvas: replicationRecipe.canvas,
          durationUs: replicationRecipe.durationUs,
          slotCount: Array.isArray(replicationRecipe.videoSlots)
            ? replicationRecipe.videoSlots.length
            : 0,
        })
        input = {
          ...input,
          label: input.label ?? await labelFromAuthorizedSourcePath(authorization.absolutePath, '可复刻模板'),
          orientation: input.orientation ?? derived.orientation,
          pacing: input.pacing ?? derived.pacing,
          targetDurationSeconds: input.targetDurationSeconds ?? derived.targetDurationSeconds,
        }
        generated = await createReusableTemplateArtifactFromRecipe({
          projectId: authorization.projectId,
          recipe: replicationRecipe,
          orientation: input.orientation,
          pacing: input.pacing,
          targetDurationSeconds: input.targetDurationSeconds,
        })
      } else {
        const derivedFallback = deriveTemplateProfileFromSource({
          canvas: null,
          durationUs: Number.isSafeInteger(input.targetDurationSeconds)
            ? input.targetDurationSeconds * 1_000_000
            : 30_000_000,
          slotCount: 0,
        })
        const orientation = input.orientation ?? derivedFallback.orientation
        const pacing = input.pacing ?? 'balanced'
        const targetDurationSeconds = input.targetDurationSeconds ?? derivedFallback.targetDurationSeconds
        const contentGoal = pacing === 'dynamic'
          ? 'montage'
          : targetDurationSeconds > 60
            ? (orientation === 'square' ? 'tutorial' : 'narrative')
            : 'product_showcase'
        generated = await referenceTemplateAdapter.generate({
          projectId: authorization.projectId,
          authorizationId: 'unused',
          referenceAuthorizationId: authorizationId,
          templateSelectionRequest: {
            schema_version: 1,
            kind: 'template_selection_request',
            project_id: authorization.projectId,
            content_goal: contentGoal,
            orientation,
            pacing,
            target_duration_seconds: targetDurationSeconds,
            voiceover_required: false,
            captions_required: true,
          },
        })
        if (!generated) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_INPUT_INVALID', 400)
        }
        const learned = deriveTemplateProfileFromSource({
          canvas: generated.analysis?.orientation === 'landscape'
            ? { width: 1920, height: 1080 }
            : generated.analysis?.orientation === 'square'
              ? { width: 1080, height: 1080 }
              : { width: 1080, height: 1920 },
          durationUs: Number.isSafeInteger(generated.analysis?.duration_ms)
            ? generated.analysis.duration_ms * 1_000
            : targetDurationSeconds * 1_000_000,
          slotCount: Array.isArray(generated.analysis?.shots)
            ? generated.analysis.shots.length
            : 0,
        })
        input = {
          ...input,
          label: input.label ?? await labelFromAuthorizedSourcePath(authorization.absolutePath, '参考成片模板'),
          orientation: input.orientation ?? generated.analysis?.orientation ?? learned.orientation,
          pacing: input.pacing ?? learned.pacing,
          targetDurationSeconds: input.targetDurationSeconds ?? learned.targetDurationSeconds,
        }
        replicationRecipe = createReplicationRecipeFromReferenceAnalysis({
          fingerprint: reusableTemplateFingerprint(generated),
          orientation: generated.templateSelectionRequest.orientation,
          targetDurationSeconds: input.targetDurationSeconds,
          analysis: generated.analysis,
        })
      }
      if (!generated) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_INPUT_INVALID', 400)
      }
      const created = await repository.create({
        label: input.label,
        orientation: input.orientation,
        pacing: input.pacing,
        targetDurationSeconds: input.targetDurationSeconds,
        referenceAuthorizationId: authorizationId,
        generated,
      })
      if (
        templateMediaStore &&
        created?.libraryTemplateId &&
        created.status === 'draft'
      ) {
        const existingMeta = typeof templateMediaStore.readMeta === 'function'
          ? await templateMediaStore.readMeta(created.libraryTemplateId)
          : null
        if (!existingMeta?.reference?.fileName) {
          try {
            let referencePath = null
            if (sourceKind === 'video_analysis') {
              referencePath = authorization.absolutePath
            } else if (blueprint && templateBlueprintStore) {
              const privateFolder = await templateBlueprintStore.resolvePrivateFolder(
                blueprint.blueprintId,
                blueprint.fingerprint,
              )
              const content = JSON.parse(
                await readFile(resolve(privateFolder, 'draft_content.json'), 'utf8'),
              )
              const videos = Array.isArray(content?.materials?.videos)
                ? content.materials.videos
                : []
              const allowedVideoExtensions = new Set([
                '.mp4', '.mov', '.webm', '.mkv', '.m4v',
              ])
              for (const video of videos) {
                if (typeof video?.path !== 'string' || !isAbsolute(video.path)) continue
                const extension = extname(video.path).toLowerCase()
                if (!allowedVideoExtensions.has(extension)) continue
                if (!existsSync(video.path)) continue
                // Only ingest media that lives inside the authorized draft folder tree.
                // Outside paths require an explicit attach-reference flow.
                const draftRoot = resolve(authorization.absolutePath)
                const candidate = resolve(video.path)
                if (
                  candidate === draftRoot ||
                  candidate.startsWith(`${draftRoot}\\`) ||
                  candidate.startsWith(`${draftRoot}/`)
                ) {
                  referencePath = candidate
                  break
                }
              }
            }
            if (referencePath) {
              await templateMediaStore.ingestReference(
                created.libraryTemplateId,
                referencePath,
              )
              await templateMediaStore.generateDemo(created.libraryTemplateId, {
                durationSeconds: Math.min(15, Math.max(8, input.targetDurationSeconds)),
                label: input.label,
                storedTemplate: {
                  libraryTemplateId: created.libraryTemplateId,
                  revision: created.revision,
                  fingerprint: created.fingerprint,
                  label: created.label,
                  orientation: created.orientation,
                  targetDurationSeconds: created.targetDurationSeconds,
                  pacing: created.pacing,
                  status: 'draft',
                  artifact: generated,
                },
              })
            }
          } catch {
            // Demo failure stays visible via previewAvailability.
          }
        }
        if (
          replicationRecipe &&
          typeof templateMediaStore.writeReplicationRecipe === 'function'
        ) {
          let recipeToPersist = replicationRecipe
          if (
            sourceKind === 'jianying_draft' &&
            blueprint &&
            typeof templateBlueprintStore?.resolvePrivateFolder === 'function' &&
            typeof templateMediaStore.ingestAudio === 'function' &&
            typeof templateMediaStore.writePackagingMap === 'function'
          ) {
            try {
              const privateFolder = await templateBlueprintStore.resolvePrivateFolder(
                blueprint.blueprintId,
                blueprint.fingerprint,
              )
              const applied = await applyBlueprintAssetsToRecipe({
                recipe: recipeToPersist,
                draftFolder: privateFolder,
                libraryTemplateId: created.libraryTemplateId,
                templateMediaStore: {
                  ingestAudio: templateMediaStore.ingestAudio,
                  writePackagingMap: templateMediaStore.writePackagingMap,
                },
              })
              recipeToPersist = applied.recipe
            } catch (error) {
              // A Jianying draft is only usable when its authored assets were
              // bound into the private store. Keeping the structural recipe
              // here would make the template appear available while silently
              // dropping the original flower text, packaging, or audio.
              await Promise.allSettled([
                typeof templateMediaStore.removeTemplateAssets === 'function'
                  ? templateMediaStore.removeTemplateAssets(created.libraryTemplateId)
                  : Promise.resolve(),
                repository.discardDraft({
                  libraryTemplateId: created.libraryTemplateId,
                  expectedRevision: created.revision,
                  fingerprint: created.fingerprint,
                }),
              ])
              if (error instanceof ReusableTemplateRepositoryError) throw error
              throw new ReusableTemplateRepositoryError(
                'REUSABLE_TEMPLATE_ASSET_BIND_FAILED',
                409,
              )
            }
          }
          if (
            sourceKind === 'video_analysis' &&
            input.audioPolicy === 'reuse_as_bgm' &&
            typeof templateMediaStore.ingestReferenceAudio === 'function'
          ) {
            try {
              const ingested = await templateMediaStore.ingestReferenceAudio(
                created.libraryTemplateId,
                { role: 'bgm' },
              )
              if (ingested?.audioToken) {
                if (!recipeToPersist.audioCues.some((/** @type {Record<string, any>} */ cue) => cue.role === 'bgm')) {
                  recipeToPersist = {
                    ...recipeToPersist,
                    audioCues: [
                      ...recipeToPersist.audioCues,
                      {
                        role: 'bgm',
                        startUs: 0,
                        durationUs: recipeToPersist.durationUs,
                        volume: 0.2,
                        audioToken: null,
                      },
                    ],
                  }
                }
                recipeToPersist = bindLocalAudioToReplicationRecipe(recipeToPersist, {
                  bgmAudioToken: ingested.audioToken,
                })
              }
            } catch {
              // Reference audio is optional. Keep the template usable, but leave BGM unbound.
            }
          }
          await templateMediaStore.writeReplicationRecipe(
            created.libraryTemplateId,
            recipeToPersist,
          )
        }
        return repository.get(created.libraryTemplateId)
      }
      return created
    } finally {
      if (sourceKind === 'video_analysis' && typeof cleanupReferenceUpload === 'function') {
        await cleanupReferenceUpload({
          projectId: authorization.projectId,
          authorizationId,
        })
      } else if (sourceKind === 'jianying_draft') {
        authorizationRepository.remove?.(authorizationId)
      }
    }
  },
  /**
   * @param {string} libraryTemplateId
   * @param {'reference' | 'demo'} kind
   */
  async resolveMedia(libraryTemplateId, kind) {
    if (!templateMediaStore) {
      throw new ReusableTemplateRepositoryError('TEMPLATE_MEDIA_UNAVAILABLE', 503)
    }
    const detail = await repository.get(libraryTemplateId)
    if (!detail) throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_NOT_FOUND', 404)
    return templateMediaStore.resolveResource(libraryTemplateId, kind)
  },
  /** @param {string} libraryTemplateId @param {Record<string, any>} input */
  async review(libraryTemplateId, input) {
    if (input?.decision === 'approve') {
      const detail = await repository.get(libraryTemplateId)
      if (!detail?.previewAvailability?.approveReady) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_LEARNING_INCOMPLETE', 409)
      }
    }
    return repository.review({ libraryTemplateId, ...clone(input) })
  },
  /**
   * Attach an authorized RunningHub voice profile to the private recipe sidecar.
   * @param {string} libraryTemplateId
   * @param {{ voiceProfileId: string | null, expectedRevision: number }} input
   */
  async bindVoice(libraryTemplateId, input) {
    if (
      !identifier(libraryTemplateId) ||
      !record(input) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1 ||
      !(input.voiceProfileId === null || identifier(input.voiceProfileId))
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_VOICE_INVALID', 400)
    }
    if (input.voiceProfileId !== null) {
      if (typeof isVoiceProfileReady !== 'function') {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_VOICE_UNAVAILABLE', 503)
      }
      const ready = await isVoiceProfileReady(input.voiceProfileId)
      if (ready !== true) {
        throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_VOICE_NOT_READY', 409)
      }
    }
    if (
      !templateMediaStore ||
      typeof templateMediaStore.readReplicationRecipe !== 'function' ||
      typeof templateMediaStore.writeReplicationRecipe !== 'function'
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_UNAVAILABLE', 503)
    }
    const readRecipe = templateMediaStore.readReplicationRecipe
    const writeRecipe = templateMediaStore.writeReplicationRecipe
    await repository.withDraftRecipeMutation(
      libraryTemplateId,
      input.expectedRevision,
      async () => {
        const currentRecipe = await readRecipe(libraryTemplateId)
        if (!currentRecipe) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_REQUIRED', 409)
        }
        const nextRecipe = bindVoiceProfileToReplicationRecipe(
          currentRecipe,
          input.voiceProfileId,
        )
        await writeRecipe(libraryTemplateId, nextRecipe)
      },
    )
    return repository.get(libraryTemplateId)
  },
  /**
   * Approved records are immutable because projects may already be bound to
   * them. Create a separate draft, including its private media assets, for
   * resource repair and a fresh approval pass.
   * @param {string} libraryTemplateId
   * @param {{ expectedRevision: number }} input
   */
  async createEditableRevision(libraryTemplateId, input) {
    if (!identifier(libraryTemplateId) || !record(input) || !Number.isSafeInteger(input.expectedRevision) || input.expectedRevision < 1) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_INVALID', 400)
    }
    if (!templateMediaStore || typeof templateMediaStore.cloneAssetsToTemplate !== 'function' ||
      typeof templateMediaStore.generateDemo !== 'function') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_UNAVAILABLE', 503)
    }
    const source = await repository.getStored(libraryTemplateId)
    if (!source || source.status !== 'approved' || source.revision !== input.expectedRevision) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REVISION_CONFLICT', 409)
    }
    const suffix = '（可编辑修订）'
    const editableLabel = source.label.endsWith(suffix)
      ? source.label
      : `${source.label.slice(0, 120 - suffix.length)}${suffix}`
    const fork = await repository.forkApprovedToDraft({
      libraryTemplateId,
      expectedRevision: input.expectedRevision,
      label: editableLabel,
    })
    const created = fork.template
    if (
      !fork.created &&
      created.replicationRecipe &&
      created.previewAvailability?.referencePlayable &&
      created.previewAvailability?.demoPlayable &&
      created.previewAvailability?.styleAnalysisComplete
    ) {
      return created
    }
    try {
      await templateMediaStore.cloneAssetsToTemplate(libraryTemplateId, created.libraryTemplateId)
      // Re-run the current asset binder against the immutable blueprint. This
      // upgrades older templates that were learned before draft-local SFX or
      // packaging discovery improved, without mutating the approved revision.
      if (
        typeof templateMediaStore.readReplicationRecipe === 'function' &&
        typeof templateMediaStore.writeReplicationRecipe === 'function' &&
        typeof templateMediaStore.ingestAudio === 'function' &&
        typeof templateMediaStore.writePackagingMap === 'function' &&
        typeof templateBlueprintStore?.resolvePrivateFolder === 'function'
      ) {
        const recipe = await templateMediaStore.readReplicationRecipe(created.libraryTemplateId)
        if (recipe?.source?.kind === 'jianying_draft' &&
          typeof recipe.source.blueprintId === 'string' &&
          typeof recipe.source.fingerprint === 'string') {
          const draftFolder = await templateBlueprintStore.resolvePrivateFolder(
            recipe.source.blueprintId,
            recipe.source.fingerprint,
          )
          const applied = await applyBlueprintAssetsToRecipe({
            recipe,
            draftFolder,
            libraryTemplateId: created.libraryTemplateId,
            templateMediaStore: {
              ingestAudio: templateMediaStore.ingestAudio,
              writePackagingMap: templateMediaStore.writePackagingMap,
            },
          })
          await templateMediaStore.writeReplicationRecipe(created.libraryTemplateId, applied.recipe)
        }
      }
      await templateMediaStore.generateDemo(created.libraryTemplateId, {
        durationSeconds: Math.min(15, Math.max(8, source.targetDurationSeconds)),
        label: created.label,
        storedTemplate: {
          libraryTemplateId: created.libraryTemplateId,
          revision: created.revision,
          fingerprint: created.fingerprint,
          label: created.label,
          orientation: created.orientation,
          targetDurationSeconds: created.targetDurationSeconds,
          pacing: created.pacing,
          status: 'draft',
          artifact: source.artifact,
        },
      })
    } catch {
      if (fork.created) {
        const rollback = await Promise.allSettled([
          repository.discardDraft({
            libraryTemplateId: created.libraryTemplateId,
            expectedRevision: created.revision,
            fingerprint: created.fingerprint,
          }),
          typeof templateMediaStore.removeTemplateAssets === 'function'
            ? templateMediaStore.removeTemplateAssets(created.libraryTemplateId)
            : Promise.reject(new Error('template-media-rollback-unavailable')),
        ])
        if (rollback.some((result) => result.status === 'rejected')) {
          throw new ReusableTemplateRepositoryError(
            'REUSABLE_TEMPLATE_REVISION_ROLLBACK_FAILED',
            500,
          )
        }
      }
      throw new ReusableTemplateRepositoryError(
        'REUSABLE_TEMPLATE_REVISION_PREPARE_FAILED',
        409,
      )
    }
    return repository.get(created.libraryTemplateId)
  },
  /**
   * One-time local BGM/SFX补挂 when draft had library-only audio with no file.
   * @param {string} libraryTemplateId
   * @param {{ role: 'bgm' | 'sfx', sourceAuthorizationId: string, expectedRevision: number }} input
   */
  async bindAudio(libraryTemplateId, input) {
    if (
      !identifier(libraryTemplateId) ||
      !record(input) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1 ||
      (input.role !== 'bgm' && input.role !== 'sfx') ||
      !identifier(input.sourceAuthorizationId)
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_AUDIO_INVALID', 400)
    }
    if (
      !templateMediaStore ||
      typeof templateMediaStore.ingestAudio !== 'function' ||
      typeof templateMediaStore.readReplicationRecipe !== 'function' ||
      typeof templateMediaStore.writeReplicationRecipe !== 'function' ||
      typeof authorizationRepository.remove !== 'function'
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_UNAVAILABLE', 503)
    }
    const ingestAudio = templateMediaStore.ingestAudio
    const readRecipe = templateMediaStore.readReplicationRecipe
    const writeRecipe = templateMediaStore.writeReplicationRecipe
    const removeAuthorization = authorizationRepository.remove
    await repository.withDraftRecipeMutation(
      libraryTemplateId,
      input.expectedRevision,
      async () => {
        const authorization = await authorizationRepository.get(input.sourceAuthorizationId)
        if (
          !record(authorization) ||
          authorization.status !== 'authorized' ||
          authorization.projectId !== libraryTemplateId ||
          typeof authorization.absolutePath !== 'string' ||
          !isAbsolute(authorization.absolutePath)
        ) {
          throw new ReusableTemplateRepositoryError(
            'REUSABLE_TEMPLATE_AUDIO_AUTHORIZATION_INVALID',
            409,
          )
        }
        const currentRecipe = await readRecipe(libraryTemplateId)
        if (!currentRecipe) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_REQUIRED', 409)
        }
        const ingested = await ingestAudio(libraryTemplateId, {
          sourcePath: authorization.absolutePath,
          role: input.role,
        })
        const recipeWithCue = input.role === 'sfx'
          ? addControlledLocalSfxCueToReplicationRecipe(currentRecipe)
          : currentRecipe
        const nextRecipe = bindLocalAudioToReplicationRecipe(
          recipeWithCue,
          input.role === 'bgm'
            ? { bgmAudioToken: ingested.audioToken }
            : { sfxAudioToken: ingested.audioToken },
        )
        await removeAuthorization(input.sourceAuthorizationId)
        const remainingAuthorization = await authorizationRepository.get(
          input.sourceAuthorizationId,
        )
        if (remainingAuthorization !== null) {
          throw new ReusableTemplateRepositoryError(
            'REUSABLE_TEMPLATE_AUDIO_AUTHORIZATION_INVALID',
            409,
          )
        }
        await writeRecipe(libraryTemplateId, nextRecipe)
      },
    )
    return repository.get(libraryTemplateId)
  },
  /**
   * Re-run the current private asset extractor for an editable Jianying draft.
   * Existing user-selected voice/audio bindings stay on the recipe; only
   * assets present in the immutable blueprint are refreshed.
   * @param {string} libraryTemplateId
   * @param {{ expectedRevision: number }} input
   */
  async refreshAssets(libraryTemplateId, input) {
    if (
      !identifier(libraryTemplateId) ||
      !record(input) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REFRESH_INVALID', 400)
    }
    const readRecipe = templateMediaStore?.readReplicationRecipe
    const writeRecipe = templateMediaStore?.writeReplicationRecipe
    const ingestAudio = templateMediaStore?.ingestAudio
    const writePackagingMap = templateMediaStore?.writePackagingMap
    const resolvePrivateFolder = templateBlueprintStore?.resolvePrivateFolder
    if (
      typeof readRecipe !== 'function' ||
      typeof writeRecipe !== 'function' ||
      typeof ingestAudio !== 'function' ||
      typeof writePackagingMap !== 'function' ||
      typeof resolvePrivateFolder !== 'function'
    ) {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RECIPE_UNAVAILABLE', 503)
    }
    await repository.withDraftRecipeMutation(
      libraryTemplateId,
      input.expectedRevision,
      async () => {
        const recipe = await readRecipe(libraryTemplateId)
        if (
          recipe?.source?.kind !== 'jianying_draft' ||
          typeof recipe.source.blueprintId !== 'string' ||
          typeof recipe.source.fingerprint !== 'string'
        ) {
          throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REFRESH_UNAVAILABLE', 409)
        }
        const draftFolder = await resolvePrivateFolder(
          recipe.source.blueprintId,
          recipe.source.fingerprint,
        )
        const applied = await applyBlueprintAssetsToRecipe({
          recipe,
          draftFolder,
          libraryTemplateId,
          templateMediaStore: {
            ingestAudio,
            writePackagingMap,
          },
        })
        await writeRecipe(libraryTemplateId, applied.recipe)
      },
    )
    return repository.get(libraryTemplateId)
  },
  /** @param {string} libraryTemplateId @param {Record<string, any>} input */
  async deactivate(libraryTemplateId, input) {
    return repository.deactivate({ libraryTemplateId, ...clone(input) })
  },
  /** @param {string} libraryTemplateId @param {Record<string, any>} input */
  async remove(libraryTemplateId, input) {
    if (typeof repository.remove !== 'function') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_REMOVE_UNAVAILABLE', 503)
    }
    const removed = await repository.remove({ libraryTemplateId, ...clone(input) })
    if (templateMediaStore && typeof templateMediaStore.removeTemplateAssets === 'function') {
      await templateMediaStore.removeTemplateAssets(libraryTemplateId).catch(() => false)
    }
    return removed
  },
  /** @param {string} libraryTemplateId @param {Record<string, any>} input */
  async relabel(libraryTemplateId, input) {
    if (typeof repository.relabel !== 'function') {
      throw new ReusableTemplateRepositoryError('REUSABLE_TEMPLATE_RELABEL_UNAVAILABLE', 503)
    }
    return repository.relabel({ libraryTemplateId, ...clone(input) })
  },
  /** @param {string} libraryTemplateId @param {Record<string, any>} input */
  async reactivate(libraryTemplateId, input) {
    return repository.reactivate({ libraryTemplateId, ...clone(input) })
  },
})
