[CmdletBinding()]
param(
    [string]$RuntimeDataRoot,
    [string]$UpstreamRoot,
    [string]$Voice = 'zh-CN-XiaoxiaoNeural',
    [switch]$RealAcceptance
)

$ErrorActionPreference = 'Stop'
$repositoryRoot = Split-Path -Parent $PSScriptRoot

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [scriptblock]$Command,
        [Parameter(Mandatory = $true)]
        [string]$Failure
    )
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Failure (exit $LASTEXITCODE)"
    }
}

Push-Location $repositoryRoot
try {
    Push-Location 'apps/gateway'
    try {
        Invoke-Checked {
            node --test `
                'test/short-video-factory-contracts.test.mjs' `
                'test/short-video-factory-provider.test.mjs' `
                'test/short-video-factory-electron-bridge.test.mjs' `
                'test/permissive-material-analyzer.test.mjs' `
                'test/workbench-job-contracts.test.mjs' `
                'test/workbench-job-repository.test.mjs' `
                'test/workbench-job-coordinator.test.mjs' `
                'test/workbench.test.mjs' `
                'test/server.test.mjs'
        } 'VID-002 Gateway focused tests failed'
    }
    finally {
        Pop-Location
    }

    $env:NODE_ENV = 'test'
    Invoke-Checked { corepack pnpm --filter '@openvideo/web' test } 'VID-002 Web tests failed'
    Invoke-Checked { corepack pnpm typecheck } 'VID-002 typecheck failed'
    Invoke-Checked { corepack pnpm lint } 'VID-002 lint failed'
    Invoke-Checked { corepack pnpm build } 'VID-002 build failed'
    Invoke-Checked { & (Join-Path $PSScriptRoot 'Test-Governance.ps1') } 'Governance validation failed'
    Invoke-Checked { & (Join-Path $PSScriptRoot 'Test-Governance-Negative.ps1') } 'Governance negative validation failed'
    Invoke-Checked { git diff --check } 'Git diff validation failed'

    if ($RealAcceptance) {
        if ([string]::IsNullOrWhiteSpace($RuntimeDataRoot)) {
            throw 'RuntimeDataRoot is required for real acceptance.'
        }
        if ([string]::IsNullOrWhiteSpace($UpstreamRoot)) {
            throw 'UpstreamRoot is required for real acceptance.'
        }
        & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') -RuntimeDataRoot $RuntimeDataRoot -Stage before
        try {
            Invoke-Checked {
                node (Join-Path $PSScriptRoot 'run-vid002-real-acceptance.mjs') `
                    $RuntimeDataRoot `
                    $UpstreamRoot `
                    $Voice
            } 'VID-002 real acceptance failed'
        }
        finally {
            & (Join-Path $PSScriptRoot 'Protect-EM005RealMaterials.ps1') -RuntimeDataRoot $RuntimeDataRoot -Stage after
        }
    }

    Write-Output 'VID-002 verification passed.'
}
finally {
    Pop-Location
}
