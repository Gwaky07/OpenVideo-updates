import { readFile, readdir } from 'node:fs/promises'
import path from 'node:path'
import { verifyArtistEffectStickerReceiptSignature } from './jianying-artist-effect-probe.mjs'
import { canonicalJY200DuoJson, fingerprintJY200DuoValue } from './jianying-duo-direct-probe-evidence.mjs'
import { parseJY200DuoProductAdmissionReceipt } from './jianying-duo-product-admission.mjs'
import { readFileNoReparse } from './jianying-native-safe-file.mjs'
import {
  computePackagingCatalogRevisionToken,
  isPackagingWriterReadyEntry,
} from './jianying-packaging-resource-index.mjs'

const FINGERPRINT = /^[a-f0-9]{64}$/u
const COMMIT = /^[a-f0-9]{40}$/u
const PROFILE = /^[A-Za-z0-9][A-Za-z0-9._-]{2,95}$/u
const ADMITTED_FAMILIES = Object.freeze(['flower', 'sticker', 'video_effect'])
const FAMILY_LABELS = Object.freeze({
  flower: 'Current flower title',
  sticker: 'Current sticker',
  video_effect: 'Current video effect',
})

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
const clone = (value) => structuredClone(value)

/** @param {string} root @param {string} candidate */
const inside = (root, candidate) => {
  const relative = path.relative(path.resolve(root), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

/** @param {unknown} value @param {Record<string, any>} snapshot */
const normalizeBinding = (value, snapshot) => {
  const candidate = /** @type {any} */ (value)
  if (!isRecord(candidate) || !ADMITTED_FAMILIES.includes(candidate.family) ||
      candidate.schema_version !== 1 || candidate.kind !== 'jy200_duo_local_resource_probe_candidate' ||
      typeof candidate.packaging_token !== 'string' ||
      !['binding_fingerprint', 'source_material_fingerprint', 'payload_fingerprint', 'source_fingerprint',
        'catalog_fingerprint', 'desktop_binding_fingerprint'].every((key) => FINGERPRINT.test(candidate[key] ?? '')) ||
      candidate.resource_mode !== 'jianying_managed' || candidate.admission !== 'deferred' ||
      candidate.writer_eligible !== false || candidate.probe_candidate !== true ||
      !isRecord(candidate.private_binding) || typeof candidate.private_binding.resourceId !== 'string') return null
  if (candidate.catalog_fingerprint !== snapshot.catalogFingerprint ||
      candidate.desktop_binding_fingerprint !== snapshot.desktopBindingFingerprint) return null
  return clone(candidate)
}

/** @param {unknown} value @param {unknown} bindingEvidence */
const normalizeSnapshot = (value, bindingEvidence = null) => {
  const candidate = /** @type {any} */ (value)
  const desktopBindingFingerprint = candidate?.desktopBindingFingerprint ?? candidate?.packagingIndex?.desktopBinding?.binding_fingerprint
  if (!isRecord(candidate) || typeof candidate.catalogFingerprint !== 'string' || !FINGERPRINT.test(candidate.catalogFingerprint) ||
      typeof candidate.profileId !== 'string' || !PROFILE.test(candidate.profileId) ||
      typeof candidate.appVersion !== 'string' || candidate.appVersion.length === 0 ||
      typeof desktopBindingFingerprint !== 'string' || !FINGERPRINT.test(desktopBindingFingerprint) ||
      !Array.isArray(candidate.packagingIndex?.entries)) return null
  const snapshotForBindings = { ...candidate, desktopBindingFingerprint }
  const evidenceByToken = new Map(Array.isArray(bindingEvidence)
    ? bindingEvidence.map((/** @type {any} */ entry) => [entry?.packaging_token, entry])
    : [])
  const bindings = candidate.packagingIndex.entries
    .map((/** @type {any} */ entry) => evidenceByToken.size > 0 && evidenceByToken.has(entry?.packaging_token)
      ? { ...evidenceByToken.get(entry.packaging_token), private_binding: entry.private_binding }
      : entry)
    .map((/** @type {any} */ entry) => normalizeBinding(entry, snapshotForBindings))
    .filter(Boolean)
  if (bindings.length !== ADMITTED_FAMILIES.length ||
      new Set(bindings.map((/** @type {any} */ entry) => entry.family)).size !== ADMITTED_FAMILIES.length) return null
  return Object.freeze({
    profileId: candidate.profileId,
    appVersion: candidate.appVersion,
    catalogFingerprint: candidate.catalogFingerprint,
    desktopBindingFingerprint,
    bindings: Object.freeze(bindings.sort((/** @type {any} */ left, /** @type {any} */ right) => left.family.localeCompare(right.family))),
  })
}

/** @param {unknown} value @param {Record<string, any>} snapshot */
/** @param {unknown} value @param {Record<string, any>} snapshot @param {string|null} integrityKey */
const normalizeReceipt = (value, snapshot, integrityKey = null, allowTechnical = false) => {
  const rawCandidate = /** @type {any} */ (value)
  const admittedShape = rawCandidate?.status === 'admitted' && rawCandidate?.admission === 'admitted' &&
    rawCandidate?.writer_eligible === true
  const candidate = admittedShape
    ? parseJY200DuoProductAdmissionReceipt(rawCandidate, integrityKey ?? '')
    : rawCandidate
  if (!candidate) return null
  const capabilities = Array.isArray(candidate?.capability_snapshot)
    ? candidate.capability_snapshot
    : candidate?.capability_snapshot?.capabilities
  const technical = candidate?.status === 'technical_go' && candidate?.admission === 'deferred' && candidate?.writer_eligible === false
  const admitted = candidate?.status === 'admitted' && candidate?.admission === 'admitted' && candidate?.writer_eligible === true
  const execution = candidate?.execution_receipt
  const executionMatches = !execution || (
    execution.provider === candidate.provider &&
    execution.provider_commit === candidate.provider_commit &&
    execution.build_digest === candidate.build_digest &&
    execution.profile_id === candidate.profile_id &&
    execution.app_version === candidate.app_version &&
    execution.desktop_binding_fingerprint === candidate.desktop_binding_fingerprint &&
    execution.current_catalog_fingerprint === candidate.current_catalog_fingerprint &&
    execution.binding_set_fingerprint === candidate.binding_set_fingerprint &&
    fingerprintJY200DuoValue(canonicalJY200DuoJson(execution)) === candidate.execution_receipt_fingerprint &&
    (!integrityKey || verifyArtistEffectStickerReceiptSignature(execution, integrityKey))
  )
  if (!isRecord(candidate) || candidate.provider !== 'duo-video' || (!admitted && !(allowTechnical && technical)) || candidate.catalog_bound !== true ||
      !COMMIT.test(candidate.provider_commit ?? '') || !FINGERPRINT.test(candidate.build_digest ?? '') ||
      candidate.profile_id !== snapshot.profileId || candidate.app_version !== snapshot.appVersion ||
      candidate.desktop_binding_fingerprint !== snapshot.desktopBindingFingerprint ||
      candidate.current_catalog_fingerprint !== snapshot.catalogFingerprint ||
      !FINGERPRINT.test(candidate.evidence_fingerprint ?? candidate.current_evidence_fingerprint ?? '') ||
      !FINGERPRINT.test(candidate.binding_set_fingerprint ?? '') ||
      !Array.isArray(capabilities) || capabilities.length < ADMITTED_FAMILIES.length ||
      !executionMatches ||
      (integrityKey && (!/^[a-f0-9]{64}$/u.test(integrityKey) || !verifyArtistEffectStickerReceiptSignature(candidate, integrityKey)))) return null
  return Object.freeze(clone(candidate))
}

/**
 * Resolve current private Duo admission. This boundary intentionally requires
 * an explicit product admission receipt; technical-only lifecycle receipts
 * remain deferred and therefore keep the Native path active.
 *
 * @param {{snapshotResolver: () => Promise<unknown> | unknown, runtimeResolver: () => Promise<unknown> | unknown, receiptResolver: () => Promise<unknown> | unknown, integrityKey?: string | null}} input
 */
export const createJY200DuoCurrentAdmissionResolver = ({ snapshotResolver, runtimeResolver, receiptResolver, integrityKey = null }) => {
  if (typeof snapshotResolver !== 'function' || typeof runtimeResolver !== 'function' || typeof receiptResolver !== 'function') {
    throw new TypeError('JY200_DUO_CURRENT_ADMISSION_RESOLVER_INVALID')
  }
  /** @type {any} */
  let last = null
  // A malformed/stale receipt can be expensive to parse because it includes
  // signed lifecycle evidence. Avoid repeating that same negative parse on
  // every bounded startup retry; positive admissions are never cached here,
  // so revocation and identity drift still fail closed on the next call.
  let negativeUntilStrict = 0
  let negativeUntilTechnical = 0
  const resolve = async (allowTechnical = false) => {
    const negativeUntil = allowTechnical ? negativeUntilTechnical : negativeUntilStrict
    if (!last && Date.now() < negativeUntil) return null
    try {
      const [snapshotValue, runtime, receiptValue] = /** @type {[unknown, any, any]} */ (await Promise.all([
        snapshotResolver(), runtimeResolver(), receiptResolver(),
      ]))
      const snapshot = normalizeSnapshot(snapshotValue, receiptValue?.execution_receipt?.binding_evidence)
      if (!snapshot || !runtime?.available) {
        last = null
        if (allowTechnical) negativeUntilTechnical = Date.now() + 1_000
        else negativeUntilStrict = Date.now() + 1_000
        return null
      }
      const receipt = /** @type {any} */ (normalizeReceipt(receiptValue, snapshot, integrityKey, allowTechnical))
      if (!receipt || receipt.build_digest !== runtime.buildDigest) {
        last = null
        if (allowTechnical) negativeUntilTechnical = Date.now() + 1_000
        else negativeUntilStrict = Date.now() + 1_000
        return null
      }
      const identity = Object.freeze({
        provider_commit: receipt.provider_commit,
        build_digest: receipt.build_digest,
        desktop_binding_fingerprint: snapshot.desktopBindingFingerprint,
        catalog_fingerprint: snapshot.catalogFingerprint,
        evidence_fingerprint: receipt.evidence_fingerprint ?? receipt.current_evidence_fingerprint,
        profile_id: snapshot.profileId,
        adapter_revision: typeof receipt.adapter_revision === 'string' ? receipt.adapter_revision : 'jy200-duo-workbench-v1',
        capability_snapshot: Object.freeze({
          capabilities: Object.freeze([...(Array.isArray(receipt.capability_snapshot)
            ? receipt.capability_snapshot
            : receipt.capability_snapshot.capabilities)].sort()),
        }),
      })
      last = Object.freeze({ identity, bindings: snapshot.bindings, receipt })
      negativeUntilStrict = 0
      negativeUntilTechnical = 0
      return last
    } catch {
      last = null
      if (allowTechnical) negativeUntilTechnical = Date.now() + 1_000
      else negativeUntilStrict = Date.now() + 1_000
      return null
    }
  }
  return Object.freeze({
    resolveCurrentAdmission: async () => {
      const current = await resolve()
      return current ? Object.freeze({ provider: 'duo-video', identity: current.identity }) : null
    },
    resolveCurrentFeasibility: async () => {
      const current = await resolve(true)
      return current ? Object.freeze({ provider: 'duo-video', identity: current.identity }) : null
    },
    resolveCurrentBindings: async () => {
      const current = await resolve()
      return current?.bindings ?? null
    },
    resolveCurrentPackagingSnapshot: async () => {
      const current = await resolve()
      if (!current) return null
      const entries = current.bindings.map((/** @type {any} */ binding) => Object.freeze({
        packaging_token: binding.packaging_token,
        family: binding.family,
        label: FAMILY_LABELS[/** @type {keyof typeof FAMILY_LABELS} */ (binding.family)],
        tags: Object.freeze([binding.family]),
        state: 'writer_eligible',
        writer_eligible: true,
        private_binding: Object.freeze(clone(binding.private_binding)),
        parameter_schema: Object.freeze({}),
      }))
      if (entries.length !== ADMITTED_FAMILIES.length || entries.some((/** @type {any} */ entry) => !isPackagingWriterReadyEntry(entry))) {
        return null
      }
      const catalogFingerprint = current.identity.catalog_fingerprint
      const packagingIndex = Object.freeze({
        schemaVersion: 1,
        profileId: current.identity.profile_id,
        appVersion: current.receipt.app_version,
        catalogFingerprint,
        catalogRevisionToken: computePackagingCatalogRevisionToken(catalogFingerprint),
        entries: Object.freeze(entries),
      })
      return Object.freeze({
        ready: true,
        profileId: packagingIndex.profileId,
        appVersion: packagingIndex.appVersion,
        catalogFingerprint,
        packagingIndex,
      })
    },
    resolveCurrentFeasibilityBindings: async () => {
      const current = await resolve(true)
      return current?.bindings ?? null
    },
    describe: () => last,
  })
}

/** @param {string} dataRoot */
export const readLatestJY200DuoTechnicalLifecycleReceipt = async (dataRoot) => {
  if (typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot)) return null
  /** @type {Array<{name: string, receipt: Record<string, any>, verifiedAt: number}>} */
  const lifecycles = []
  try {
    const root = path.join(dataRoot, 'evidence', 'jy200-duo-local')
    const names = (await readdir(root)).filter((name) => /^[a-f0-9]{64}\.json$/u.test(name))
    for (const name of names) {
      try {
        const candidate = JSON.parse(await readFileNoReparse(path.join(root, name), root, 8 * 1024 * 1024))
        const verifiedAt = Date.parse(candidate?.verified_at)
        if (isRecord(candidate) && candidate.kind === 'jy200_duo_local_catalog_lifecycle' && Number.isFinite(verifiedAt)) {
          lifecycles.push({ name, receipt: candidate, verifiedAt })
        }
      } catch { /* ignore unreadable candidates; selected evidence is still signature-verified by the caller */ }
    }
  } catch { /* unavailable lifecycle evidence remains fail-closed */ }
  lifecycles.sort((left, right) => right.verifiedAt - left.verifiedAt || right.name.localeCompare(left.name))
  const lifecycle = lifecycles[0]?.receipt ?? null
  if (!lifecycle) return null
  for (const directory of ['jy200-duo-execution']) {
    try {
      const root = path.join(dataRoot, 'evidence', directory)
      const names = (await readdir(root)).filter((name) => /^[a-f0-9]{64}\.json$/u.test(name)).sort().reverse()
      for (const name of names) {
        try {
          const candidate = JSON.parse(await readFileNoReparse(path.join(root, name), root, 8 * 1024 * 1024))
          if (isRecord(candidate) && candidate.kind === 'jy200_duo_local_probe_execution' &&
              fingerprintJY200DuoValue(canonicalJY200DuoJson(candidate)) === lifecycle.execution_receipt_fingerprint) {
            Object.defineProperty(lifecycle, 'execution_receipt', { value: candidate, enumerable: false })
            return lifecycle
          }
        } catch { /* continue to the next immutable receipt */ }
      }
    } catch { /* unavailable evidence remains fail-closed */ }
  }
  return null
}

/** @param {string} filePath @param {string|null} [dataRoot] */
export const readJY200DuoAdmissionReceipt = async (filePath, dataRoot = null) => {
  if (typeof filePath !== 'string' || !path.isAbsolute(filePath)) return null
  const privateEvidenceRoot = typeof dataRoot === 'string' && path.isAbsolute(dataRoot)
    ? path.join(path.resolve(dataRoot), 'evidence')
    : null
  if (privateEvidenceRoot && !inside(privateEvidenceRoot, filePath)) return null
  try {
    const direct = JSON.parse(privateEvidenceRoot
      ? await readFileNoReparse(filePath, privateEvidenceRoot, 8 * 1024 * 1024)
      : await readFile(filePath, 'utf8'))
    if (isRecord(direct)) {
      // A pre-audio-evidence admitted receipt is no longer a valid product
      // admission. Let the caller recover the newer signed technical
      // lifecycle instead of repeatedly treating the stale file as current.
      if (direct.status !== 'admitted' || Array.isArray(direct.execution_receipt?.audio_evidence)) return direct
    }
  } catch { /* probe receipt may be stored in the task evidence directory */ }
  return typeof dataRoot === 'string'
    ? readLatestJY200DuoTechnicalLifecycleReceipt(dataRoot)
    : null
}
