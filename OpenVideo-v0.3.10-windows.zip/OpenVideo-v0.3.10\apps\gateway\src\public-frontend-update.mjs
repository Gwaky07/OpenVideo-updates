const COMMIT_SHA = /^[a-f0-9]{40}$/u
const SHA256_HEX = /^[a-f0-9]{64}$/u
const ALLOWED_HOSTS = new Set(['raw.githubusercontent.com', 'github.com'])
const ALLOWED_REPO_PREFIX = '/Gwaky07/OpenVideo-updates/'

export class PublicFrontendUpdateError extends Error {
  /** @param {string} code @param {string} [reason] */
  constructor(code, reason) {
    super(code)
    this.name = 'PublicFrontendUpdateError'
    this.code = code
    this.reason = reason
  }
}

const asText = (value) => typeof value === 'string' ? value.trim() : ''

export const isAllowedPublicUpdateUrl = (value, manifestUrl = '') => {
  let parsed
  try {
    parsed = new URL(asText(value))
  } catch {
    return false
  }
  if (parsed.protocol !== 'https:') return false
  if (!ALLOWED_HOSTS.has(parsed.hostname)) return false
  if (!parsed.pathname.startsWith(ALLOWED_REPO_PREFIX)) return false
  if (parsed.pathname.includes('..')) return false
  const manifest = asText(manifestUrl)
  if (manifest) {
    try {
      const parent = new URL(manifest)
      if (parent.hostname !== parsed.hostname) return false
    } catch {
      return false
    }
  }
  return true
}

export const parsePublicFrontendManifest = (value, manifestUrl = '') => {
  const record = value && typeof value === 'object' ? value : {}
  const commit = asText(record.commit).toLowerCase()
  const scope = asText(record.scope)
  const pack = record.package && typeof record.package === 'object' ? record.package : {}
  const url = asText(pack.url)
  const sha256 = asText(pack.sha256).toLowerCase()
  if (record.schema_version !== 1 || (scope !== 'frontend' && scope !== 'full')) {
    throw new PublicFrontendUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
  }
  if (!COMMIT_SHA.test(commit) || !SHA256_HEX.test(sha256) || !isAllowedPublicUpdateUrl(url, manifestUrl)) {
    throw new PublicFrontendUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
  }
  const notes = Array.isArray(record.notes) ? record.notes.filter((note) => typeof note === 'string') : []
  const publishedRaw = asText(record.publishedAt)
  const publishedTime = Date.parse(publishedRaw)
  return {
    scope,
    commit,
    version: asText(record.version).slice(0, 32) || null,
    publishedAt: Number.isNaN(publishedTime) ? null : new Date(publishedTime).toISOString(),
    summary: asText(record.summary).slice(0, 80) || (scope === 'frontend' ? '有新的界面更新' : '有新的产品更新'),
    notes,
    packageUrl: url,
    sha256,
    bytes: Number.isFinite(pack.bytes) ? Number(pack.bytes) : null,
  }
}

export const installFrontendZipBuffer = async ({ buffer, destDir }) => {
  const { execFile } = await import('node:child_process')
  const { promisify } = await import('node:util')
  const { mkdir, mkdtemp, rename, rm, writeFile } = await import('node:fs/promises')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const execFileAsync = promisify(execFile)
  const stage = await mkdtemp(join(tmpdir(), 'ov-fe-'))
  const nextDir = `${destDir}.next`
  const prevDir = `${destDir}.prev`
  await rm(nextDir, { recursive: true, force: true })
  await rm(prevDir, { recursive: true, force: true })
  try {
    const zipPath = join(stage, 'frontend.zip')
    const unpacked = join(stage, 'unpacked')
    await writeFile(zipPath, buffer)
    await mkdir(unpacked, { recursive: true })
    await execFileAsync('powershell.exe', [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-Command',
      `Expand-Archive -LiteralPath '${zipPath.replaceAll("'", "''")}' -DestinationPath '${unpacked.replaceAll("'", "''")}' -Force`,
    ], { windowsHide: true, timeout: 60_000 })
    const root = await resolveFrontendRoot(unpacked)
    await mkdir(nextDir, { recursive: true })
    await copySafeTree(root, nextDir)
    const { access } = await import('node:fs/promises')
    await access(join(nextDir, 'index.html'))
    try {
      await rename(destDir, prevDir)
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
    try {
      await rename(nextDir, destDir)
    } catch (error) {
      try {
        await rm(destDir, { recursive: true, force: true })
        await rename(prevDir, destDir)
      } catch {
        // Keep prevDir if dest could not be restored.
      }
      throw error
    }
    await rm(prevDir, { recursive: true, force: true })
  } catch (error) {
    await rm(nextDir, { recursive: true, force: true })
    throw error
  } finally {
    await rm(stage, { recursive: true, force: true })
  }
}

const resolveFrontendRoot = async (unpacked) => {
  const { readdir, readFile } = await import('node:fs/promises')
  const { join } = await import('node:path')
  const entries = await readdir(unpacked, { withFileTypes: true })
  const names = new Set(entries.map((entry) => entry.name))
  if (names.has('index.html')) return unpacked
  const onlyDir = entries.filter((entry) => entry.isDirectory())
  if (onlyDir.length === 1) {
    const nested = join(unpacked, onlyDir[0].name)
    const nestedNames = await readdir(nested)
    if (nestedNames.includes('index.html')) return nested
  }
  throw new PublicFrontendUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
}

const copySafeTree = async (fromDir, toDir) => {
  const { readdir, mkdir, cp, stat } = await import('node:fs/promises')
  const { join, relative } = await import('node:path')
  const walk = async (current) => {
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const source = join(current, entry.name)
      const rel = safeZipEntryName(relative(fromDir, source))
      if (!rel) continue
      const dest = join(toDir, rel)
      if (entry.isDirectory()) {
        await mkdir(dest, { recursive: true })
        await walk(source)
        continue
      }
      if (!entry.isFile()) continue
      await mkdir(join(dest, '..'), { recursive: true })
      await cp(source, dest)
    }
  }
  await walk(fromDir)
}

export const safeZipEntryName = (value) => {
  const name = asText(value).replaceAll('\\', '/')
  if (!name || name.startsWith('/') || name.includes('..')) return null
  if (name.split('/').some((part) => part === '' || part === '.' || part === '..')) return null
  return name
}
