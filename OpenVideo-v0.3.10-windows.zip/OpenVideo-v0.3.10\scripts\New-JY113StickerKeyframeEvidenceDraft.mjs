import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { createEditorCapabilityRegistry } from '../apps/gateway/src/editor-capability-registry.mjs'
import { parseJianyingTextPackagingCatalog } from '../apps/gateway/src/jianying-text-packaging-catalog.mjs'
import { loadJianyingStickerKeyframeIntegrityKey } from '../apps/gateway/src/jianying-sticker-keyframe-evidence.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { createJianyingPackagingResolver } from '../apps/gateway/src/jianying-packaging-resolver.mjs'

const execFileAsync = promisify(execFile)
const manifestUrl = new URL('../config/jianying-compatibility.json', import.meta.url)

const createBaselineTimeline = (packagingToken) => {
  const tracks = [
    { trackId: 'video-jy113', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary', segments: [{ segmentId: 'video-jy113', kind: 'video', asset: { authorizationId: 'jy113-auth', assetId: 'jy113-video', sceneId: 'jy113-scene' }, sourceRange: { startUs: 0, durationUs: 4_000_000 }, targetRange: { startUs: 0, durationUs: 4_000_000 }, fit: 'cover', volume: 1, speed: { numerator: 1, denominator: 1 }, keyframes: [], effects: [], audit: { origin: 'editor', candidateId: 'jy113-candidate', instructionFingerprint: null }, transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} } }] },
    { trackId: 'sticker-jy113', order: 1, enabled: true, locked: false, kind: 'effect', segments: [{ segmentId: 'sticker-jy113', kind: 'effect', targetRange: { startUs: 0, durationUs: 4_000_000 }, capabilityId: 'sticker.named', intensity: 1, parameters: { packagingToken }, keyframes: [{ capabilityId: 'transform.sticker.keyframe', offsetUs: 500_000, value: 1, interpolation: 'linear' }, { capabilityId: 'transform.sticker.keyframe', offsetUs: 1_000_000, value: 1.2, interpolation: 'linear' }] }], },
  ]
  return finalizeRichTimeline(sealRichTimeline({ schemaVersion: 1, timelineId: 'jy113-sticker-keyframe-evidence', projectId: 'jy113-evidence', revision: 1, parentRevision: null, parentRevisionFingerprint: null, status: 'draft', createdAt: '2026-08-14T00:00:00.000Z', durationUs: 4_000_000, orientation: 'portrait', fps: { numerator: 30, denominator: 1 }, source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null }, tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks) }))
}

const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(manifestUrl, 'utf8')) })
  if (!desktop || desktop.profileId !== 'jianying-11-2-provisional' || desktop.version !== '11.2.0.14339') throw new Error('JY113_PROFILE_UNSUPPORTED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  const catalog = parseJianyingTextPackagingCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy063-text-packaging-catalog.json'), 'utf8')) )
  const sticker = catalog?.entries.find((entry) => entry.kind === 'sticker')
  if (!sticker) throw new Error('JY113_PRIVATE_STICKER_CATALOG_REQUIRED')
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy113-sticker-keyframe')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 }); await securePrivateRuntimeRoot(evidenceRoot)
  try { await readFile(path.join(evidenceRoot, 'pending.json'), 'utf8'); throw new Error('JY113_PENDING_EVIDENCE_CLEANUP_REQUIRED') } catch (error) { if (error?.code !== 'ENOENT') throw error }
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy113-sticker-keyframe-')); const mediaOwner = randomUUID()
  let pythonModuleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (!pythonModuleRoot && process.env.LOCALAPPDATA) {
    try {
      const localConfig = JSON.parse(await readFile(path.join(process.env.LOCALAPPDATA, 'OpenVideo', 'config.json'), 'utf8'))
      if (typeof localConfig.pyjianyingdraft_root === 'string' && path.isAbsolute(localConfig.pyjianyingdraft_root)) pythonModuleRoot = localConfig.pyjianyingdraft_root
    } catch { /* the writer fails closed below when the governed upstream root is absent */ }
  }
  let writer; let request; let released = false
  try {
    await writeFile(path.join(mediaRoot, '.openvideo-jy113-owner'), mediaOwner, { encoding: 'utf8', mode: 0o600 })
    const video = path.join(mediaRoot, 'video.mp4'); const audio = path.join(mediaRoot, 'voice.wav')
    await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', video], { windowsHide: true })
    await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audio], { windowsHide: true })
    const draftId = `OpenVideo-JY113-sticker-keyframe-${Date.now()}`
    const capabilityRegistry = createEditorCapabilityRegistry({ jianyingProfileId: desktop.profileId, privateCatalogCapabilities: ['sticker.named', 'transform.sticker.keyframe'], evidencedCapabilities: ['transform.sticker.keyframe'] })
    const projected = projectRichTimelineToJianyingExport(createBaselineTimeline(sticker.packaging_token), { capabilityRegistry, jianyingProfileId: desktop.profileId })
    const resolver = createJianyingPackagingResolver({ resolvePackagingToken: ({ packagingToken }) => {
      const entry = catalog.entries.find((candidate) => candidate.packaging_token === packagingToken && candidate.kind === 'sticker')
      return entry ? { kind: 'sticker', resourceId: entry.resource_id } : null
    } })
    const resolvedStickers = await Promise.all(projected.packaging.sticker_segments.map(async (segment) => {
      const resolved = await resolver.resolvePackagingToken(segment.packaging_token)
      if (!resolved || resolved.kind !== 'sticker') throw new Error('JY113_PRIVATE_STICKER_RESOLUTION_FAILED')
      return { ...segment, resource_id: resolved.resourceId }
    }))
    const writerPackaging = { ...projected.packaging, sticker_segments: resolvedStickers }
    writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments: [], timelinePackaging: writerPackaging }) })
    request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: video }], voiceovers: [{ path: audio }] }
    const result = await writer.writeDraft(request)
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY113_WRITE_VERIFY_FAILED')
    const encrypted = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
    const inspectRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy113-inspect-'))
    let keyframeIds
    try {
      const plain = path.join(inspectRoot, 'draft_content.json')
      await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'), plain)
      const content = JSON.parse(await readFile(plain, 'utf8')); const segment = content?.tracks?.find((track) => track?.name === 'sticker-1')?.segments?.[0]
      const points = segment?.common_keyframes?.find((list) => list?.property_type === 'KFTypeScaleX')?.keyframe_list
      if (!Array.isArray(points) || points.length !== 2 || points.some((point) => typeof point?.id !== 'string' || !/^[a-f0-9]{32}$/u.test(point.id))) throw new Error('JY113_GENERATED_KEYFRAME_IDS_INVALID')
      keyframeIds = points.map((point, index) => ({ id: point.id, offset_us: index === 0 ? 500_000 : 1_000_000, initial_value: index === 0 ? 1 : 1.2 }))
    } finally { await rm(inspectRoot, { recursive: true, force: true }) }
    const integrityKey = await loadJianyingStickerKeyframeIntegrityKey({ evidenceRoot, create: true })
    await writeFile(path.join(evidenceRoot, 'pending.json'), `${JSON.stringify({ schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot, media_owner: mediaOwner, profile_id: desktop.profileId, app_version: desktop.version, catalog_fingerprint: catalog.fingerprint, target_start_us: 0, target_duration_us: 4_000_000, keyframe_ids: keyframeIds, pre_open_fingerprint: createHash('sha256').update(encrypted).digest('hex') })}\n`, { encoding: 'utf8', mode: 0o600 })
    if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY113_RELEASE_FAILED')
    released = true
    process.stdout.write(`${JSON.stringify({ ok: true, manual_open_required: true, draft_prefix: 'OpenVideo-JY113-sticker-keyframe-', initial: [{ time_seconds: 0.5, scale_percent: 100 }, { time_seconds: 1, scale_percent: 120 }], change: { time_seconds: 1, scale_percent: 140 }, profile: desktop.profileId, version: desktop.version })}\n`)
  } catch (error) {
    if (!released && writer && request) try { await writer.cleanupDraft({ job_id: request.job_id }) } catch {}
    if (!released) await rm(mediaRoot, { recursive: true, force: true })
    throw error
  }
}
main().catch((error) => { const code = typeof error?.message === 'string' && /^JY113_[A-Z_]+$/u.test(error.message) ? error.message : 'JY113_GENERATE_FAILED'; process.stdout.write(`${JSON.stringify({ ok: false, code })}\n`); process.exitCode = 1 })
