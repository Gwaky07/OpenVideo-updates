import { createHash, randomUUID } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { isAbsolute, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const terminalStatuses = new Set(['succeeded', 'failed', 'cancelled', 'timed_out'])
const fingerprintPattern = /^[a-f0-9]{64}$/u
const unsafePublicPattern =
  /(?:[A-Za-z]:\\|file:\/\/|\/Users\/|privateInput|api_key|source_path|absolutePath)/iu

const sha256 = (value) => createHash('sha256').update(String(value)).digest('hex')
const delay = (milliseconds) =>
  new Promise((resolveDelay) => setTimeout(resolveDelay, milliseconds))

const validTimeline = (value) =>
  value &&
  typeof value === 'object' &&
  typeof value.timelineId === 'string' &&
  Number.isSafeInteger(value.revision) &&
  value.revision > 0 &&
  fingerprintPattern.test(value.revisionFingerprint) &&
  fingerprintPattern.test(value.contentFingerprint) &&
  ['draft', 'finalized'].includes(value.status)

const validFinalizedTimeline = (value) =>
  validTimeline(value) && value.status === 'finalized'

const validJob = (value, projectId, expectedType) =>
  value &&
  typeof value === 'object' &&
  typeof value.jobId === 'string' &&
  value.projectId === projectId &&
  value.type === expectedType &&
  typeof value.status === 'string'

const timelineReference = (timeline) => ({
  timelineId: timeline.timelineId,
  revision: timeline.revision,
  revisionFingerprint: timeline.revisionFingerprint,
})

/**
 * Runs the public HTTP boundary for one real Editor revision and both outputs.
 * The returned evidence is intentionally sanitized for task logs.
 *
 * @param {{
 *   projectId: string,
 *   instruction: string,
 *   request: (method: string, path: string, body?: unknown, headers?: Record<string, string>) => Promise<any>,
 *   idempotencyKey?: () => string,
 *   wait?: (milliseconds: number) => Promise<void>,
 *   pollIntervalMs?: number,
 *   timeoutMs?: number,
 * }} input
 */
export const runQa007EditorAcceptance = async ({
  projectId,
  instruction,
  request,
  idempotencyKey = randomUUID,
  wait = delay,
  pollIntervalMs = 1_500,
  timeoutMs = 30 * 60_000,
}) => {
  if (
    typeof projectId !== 'string' ||
    projectId.length === 0 ||
    typeof instruction !== 'string' ||
    instruction.trim().length === 0 ||
    instruction.length > 4_000 ||
    typeof request !== 'function'
  ) throw new Error('QA007_INPUT_INVALID')

  const projectPath = `/api/workbench/projects/${encodeURIComponent(projectId)}`
  const publicPayloads = []
  const trackedRequest = async (method, path, body, headers) => {
    const value = await request(method, path, body, headers)
    publicPayloads.push(value)
    return value
  }
  const waitForJob = async (jobId, expectedType, failureCode) => {
    const deadline = Date.now() + timeoutMs
    while (Date.now() < deadline) {
      const job = await trackedRequest('GET', `${projectPath}/jobs/${encodeURIComponent(jobId)}`)
      if (!validJob(job, projectId, expectedType)) {
        throw new Error('QA007_PUBLIC_JOB_INVALID')
      }
      if (terminalStatuses.has(job.status)) {
        if (job.status !== 'succeeded') {
          throw new Error(`${failureCode}:${job.error?.code ?? job.status}`)
        }
        return job
      }
      await wait(pollIntervalMs)
    }
    throw new Error('QA007_JOB_POLL_TIMEOUT')
  }

  const initialTimeline = await trackedRequest('GET', `${projectPath}/editor/timeline`)
  if (!validTimeline(initialTimeline)) throw new Error('QA007_INITIAL_TIMELINE_INVALID')

  const editorAccepted = await trackedRequest(
    'POST',
    `${projectPath}/editor/jobs`,
    {
      instruction: instruction.trim(),
      baseTimeline: timelineReference(initialTimeline),
      mode: 'revise',
    },
    { 'idempotency-key': idempotencyKey() },
  )
  if (!validJob(editorAccepted, projectId, 'editor_agent')) {
    throw new Error('QA007_EDITOR_JOB_INVALID')
  }
  const editorJob = await waitForJob(
    editorAccepted.jobId,
    'editor_agent',
    'QA007_EDITOR_JOB_FAILED',
  )

  const editedTimeline = await trackedRequest('GET', `${projectPath}/editor/timeline`)
  if (
    !validFinalizedTimeline(editedTimeline) ||
    editedTimeline.timelineId !== initialTimeline.timelineId ||
    editedTimeline.revision <= initialTimeline.revision ||
    editedTimeline.revisionFingerprint === initialTimeline.revisionFingerprint
  ) throw new Error('QA007_EDITOR_REVISION_NOT_ADVANCED')
  const outputRevision = timelineReference(editedTimeline)

  const previewAccepted = await trackedRequest(
    'POST',
    `${projectPath}/editor/preview/jobs`,
    outputRevision,
    { 'idempotency-key': idempotencyKey() },
  )
  if (!validJob(previewAccepted, projectId, 'preview_generation')) {
    throw new Error('QA007_PREVIEW_JOB_INVALID')
  }
  const previewJob = await waitForJob(
    previewAccepted.jobId,
    'preview_generation',
    'QA007_PREVIEW_JOB_FAILED',
  )

  const jianyingAccepted = await trackedRequest(
    'POST',
    `${projectPath}/editor/jianying/jobs`,
    outputRevision,
    { 'idempotency-key': idempotencyKey() },
  )
  if (!validJob(jianyingAccepted, projectId, 'jianying_draft_export')) {
    throw new Error('QA007_JIANYING_JOB_INVALID')
  }
  const jianyingJob = await waitForJob(
    jianyingAccepted.jobId,
    'jianying_draft_export',
    'QA007_JIANYING_JOB_FAILED',
  )

  const publicResponseLeakCount = publicPayloads.filter((value) =>
    unsafePublicPattern.test(JSON.stringify(value))).length
  if (publicResponseLeakCount > 0) throw new Error('QA007_PUBLIC_RESPONSE_LEAK')

  return {
    schema_version: 1,
    completed_at: new Date().toISOString(),
    project_id_hash: sha256(projectId),
    initial_revision: initialTimeline.revision,
    timeline_id_hash: sha256(editedTimeline.timelineId),
    timeline_revision: editedTimeline.revision,
    timeline_revision_fingerprint: editedTimeline.revisionFingerprint,
    editor_job_status: editorJob.status,
    preview_job_status: previewJob.status,
    preview_output_fingerprint: previewJob.result?.outputFingerprint ?? null,
    jianying_job_status: jianyingJob.status,
    jianying_output_fingerprint: jianyingJob.result?.outputFingerprint ?? null,
    same_revision: true,
    public_response_leak_count: publicResponseLeakCount,
  }
}

const requestFromOrigin = (origin, localApiToken) =>
  async (method, path, body, extraHeaders = {}) => {
  const response = await fetch(`${origin}${path}`, {
    method,
    headers: {
      Accept: 'application/json',
      Origin: origin,
      ...(body === undefined ? {} : { 'content-type': 'application/json; charset=utf-8' }),
      ...(['GET', 'HEAD', 'OPTIONS'].includes(method)
        ? {}
        : { 'x-openvideo-local-token': localApiToken }),
      ...extraHeaders,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const text = await response.text()
  const payload = text ? JSON.parse(text) : null
  if (!response.ok) {
    throw new Error(`QA007_HTTP_${response.status}:${payload?.error?.code ?? 'UNKNOWN'}`)
  }
  return payload
  }

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : null
if (invokedPath === import.meta.url) {
  const origin = process.env.OPENVIDEO_ORIGIN || 'http://127.0.0.1:8787'
  const projectId = process.env.OPENVIDEO_PROJECT_ID
  const instruction = process.env.OPENVIDEO_QA007_EDITOR_INSTRUCTION
  const dataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
  if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('QA007_RUNTIME_ROOT_INVALID')
  const localApiToken = JSON.parse(
    await readFile(resolve(dataRoot, 'local-api-token.json'), 'utf8'),
  ).token
  if (typeof localApiToken !== 'string' || !/^[a-f0-9]{64}$/u.test(localApiToken)) {
    throw new Error('QA007_LOCAL_API_TOKEN_INVALID')
  }
  const evidence = await runQa007EditorAcceptance({
    projectId,
    instruction,
    request: requestFromOrigin(origin, localApiToken),
  })
  const evidenceRoot = resolve(dataRoot, 'evidence/qa-007')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const evidencePath = resolve(evidenceRoot, `editor-e2e-${Date.now()}.json`)
  await writeFile(evidencePath, `${JSON.stringify(evidence, null, 2)}\n`, {
    encoding: 'utf8',
    mode: 0o600,
  })
  console.log(JSON.stringify({ ...evidence, evidence_file: 'private-runtime/qa-007' }))
}
