import { createHash } from 'node:crypto'
import { isAbsolute } from 'node:path'
import { createEditorCapabilityRegistry } from './editor-capability-registry.mjs'
import { normalizeBrief, normalizePackaging } from './brief-packaging.mjs'
import {
  createJianyingDraftExportRequest,
  buildJianyingDraftPreparation,
  preflightJianyingDraftPreparation,
} from './jianying-draft-contracts.mjs'
import {
  createJianyingDraftAdapterRequest,
  isJianyingDraftJobStatus,
  JianyingDraftAdapterError,
} from './jianying-draft-adapter.mjs'
import {
  createJianyingPackagingResolver,
  JianyingPackagingResolverError,
} from './jianying-packaging-resolver.mjs'
import { readTimelinePackagingSelections } from './jianying-timeline-packaging-selections.mjs'
import {
  assertCurrentPrivateCatalogTokenAdmitted,
  preparePrivateBatchWriterSmokeFromTimelinePackaging,
} from './jianying-batch-recommendation-writer-smoke.mjs'
import {
  JianyingFilterWriterBindingError,
  resolveJianyingFilterWriterBindings,
} from './jianying-filter-writer-binding.mjs'
import {
  projectRichTimelineToJianyingExport,
  RichTimelineJianyingProjectionError,
} from './rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, sealRichTimeline } from './rich-timeline-contracts.mjs'
import {
  createJianyingTemplateAdapterEnvelope,
} from './reference-template-contracts.mjs'
import {
  adaptTemplateGuidanceToCount,
  applyTemplateGuidanceToEditPlan,
  assertTemplateGuidanceExecutable,
  createTemplateGuidance,
} from './template-binding-consumption.mjs'
import { fingerprintRenderBundleIdentity } from './jianying-render-contracts.mjs'
import { isAdmittedPackagingEntry, resolvePrivatePackagingResourceToken } from './jianying-packaging-resource-index.mjs'
import { assertPackagingTextLayout, DECORATED_TEXT_MINIMUM_SIZE } from './packaging-text-layout.mjs'
import { usesUploadedDraftInventory } from './timeline-template-constraints.mjs'

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Older finalized timelines may predate authored template SFX inheritance.
 * Keep the canonical timeline immutable at rest, but materialize the learned
 * cues into the export projection so an existing project still receives the
 * real template sound effects.
 *
 * Uploaded-draft inventory and any already-placed SFX lane must keep current
 * flower times. Scaling recipe timestamps onto a shorter project is the old
 * template-order path and makes SFX land after the on-screen card.
 * @param {Record<string, any>} timeline
 * @param {Record<string, any> | null | undefined} guidance
 * @returns {Record<string, any>}
 */
const normalizedCueText = (value) => typeof value === 'string'
  ? value.toLocaleLowerCase().replace(/[\s\p{P}\p{S}]+/gu, '')
  : ''

const cueMatchesNarration = (cue, narration) => {
  if (cue.length < 2 || narration.length < 2) return false
  if (narration.includes(cue) || cue.includes(narration)) return true
  if (cue.length < 4 || cue.length > narration.length) return false
  let narrationIndex = 0
  for (const character of cue) {
    narrationIndex = narration.indexOf(character, narrationIndex)
    if (narrationIndex < 0) return false
    narrationIndex += character.length
  }
  return true
}

const captionCoversUs = (caption, startUs) => {
  const range = caption?.targetRange
  if (!isRecord(range) || !Number.isSafeInteger(range.startUs) || !Number.isSafeInteger(range.durationUs)) {
    return true
  }
  return startUs >= range.startUs && startUs < range.startUs + range.durationUs
}

const resealExportTimelineIfSealed = (timeline) => {
  if (
    timeline?.schemaVersion !== 1 ||
    typeof timeline.contentFingerprint !== 'string' ||
    typeof timeline.revisionFingerprint !== 'string'
  ) return timeline
  const next = structuredClone(timeline)
  next.capabilityRequirements = computeCapabilityRequirements(next.tracks)
  return sealRichTimeline(next)
}

/** Drop leftover-at-head SFX on already finalized inventory timelines. */
export const keepInventorySfxWithSpokenFlowers = (timeline) => {
  if (!isRecord(timeline) || !Array.isArray(timeline.tracks)) return timeline
  const captions = timeline.tracks
    .filter((track) => track?.kind === 'caption')
    .flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
    .map((segment) => ({
      text: normalizedCueText(segment?.text),
      targetRange: segment?.targetRange,
    }))
    .filter((caption) => caption.text.length >= 2)
  const flowers = timeline.tracks
    .filter((track) => track?.kind === 'title')
    .flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
    .filter((segment) => segment?.kind === 'rich_text' && isRecord(segment.targetRange))
  if (captions.length === 0 || flowers.length === 0) return timeline
  const firstSpokenUs = flowers.reduce((first, flower) => {
    const text = normalizedCueText(flower.text)
    const startUs = flower.targetRange.startUs
    if (!Number.isSafeInteger(startUs)) return first
    const spoken = captions.some((caption) =>
      cueMatchesNarration(text, caption.text) && captionCoversUs(caption, startUs))
    if (!spoken) return first
    return first < 0 ? startUs : Math.min(first, startUs)
  }, -1)
  if (firstSpokenUs < 0) return timeline
  const next = structuredClone(timeline)
  let changed = false
  for (const track of next.tracks) {
    if (track?.kind !== 'audio' || track?.role !== 'sfx' || !Array.isArray(track.segments)) continue
    const kept = track.segments.filter((segment) =>
      Number.isSafeInteger(segment?.targetRange?.startUs) &&
      segment.targetRange.startUs >= firstSpokenUs)
    if (kept.length !== track.segments.length) {
      track.segments = kept
      changed = true
    }
  }
  return changed ? resealExportTimelineIfSealed(next) : timeline
}

export const injectTemplateSfxForExport = (timeline, guidance) => {
  if (!isRecord(timeline) || !Array.isArray(timeline.tracks)) return timeline
  if (usesUploadedDraftInventory(guidance)) return keepInventorySfxWithSpokenFlowers(timeline)
  const hasPlacedSfx = timeline.tracks.some((/** @type {Record<string, any>} */ track) =>
    track?.kind === 'audio' && track?.role === 'sfx' && Array.isArray(track.segments) && track.segments.length > 0)
  if (hasPlacedSfx) return timeline
  /** @type {Record<string, any>[]} */
  const authoredCues = Array.isArray(guidance?.replicationRecipe?.audioCues)
    ? guidance.replicationRecipe.audioCues
    : []
  const cues = authoredCues.filter((cue) =>
      isRecord(cue) && cue.role === 'sfx' && typeof cue.audioToken === 'string' &&
      Number.isSafeInteger(cue.startUs) && Number.isSafeInteger(cue.durationUs) && cue.durationUs > 0)
  const authoredDuration = Number(guidance?.replicationRecipe?.durationUs)
  const durationUs = Number(timeline.durationUs)
  if (cues.length === 0 || !Number.isSafeInteger(durationUs) || durationUs <= 0) return timeline
  const scale = Number.isSafeInteger(authoredDuration) && authoredDuration > 0 ? durationUs / authoredDuration : 1
  const next = structuredClone(timeline)
  const sfxTracks = next.tracks.filter((/** @type {Record<string, any>} */ track) =>
    track?.kind === 'audio' && track?.role === 'sfx' && Array.isArray(track.segments))
  const segments = cues.flatMap((cue, index) => {
    const startUs = Math.floor(cue.startUs * scale)
    const requested = Math.max(1, Math.floor(cue.durationUs * scale))
    if (startUs >= durationUs) return []
    const segmentDurationUs = Math.min(requested, durationUs - startUs)
    return [{
      segmentId: `seg-${createHash('sha256').update(`template-sfx\0${index}\0${cue.audioToken}\0${startUs}\0${segmentDurationUs}`).digest('hex').slice(0, 24)}`,
      kind: 'sfx',
      capabilityId: 'audio.sfx.local',
      source: { kind: 'generated', generatedAudioId: cue.audioToken },
      sourceRange: { startUs: 0, durationUs: segmentDurationUs },
      targetRange: { startUs, durationUs: segmentDurationUs },
      volume: typeof cue.volume === 'number' && Number.isFinite(cue.volume) ? Math.max(0, Math.min(1, cue.volume)) : 1,
      fadeInUs: 0,
      fadeOutUs: 0,
      keyframes: [],
      ducking: 'none',
    }]
  })
  if (segments.length === 0) return timeline
  if (sfxTracks.length > 0) {
    const targetTrack = sfxTracks[0]
    // Rebuild the authored SFX lane from the template cue list. Older
    // finalized timelines can contain a partial six-cue projection; merging
    // those segments with the full template lane creates duplicate/overlap
    // ranges in Jianying's single audio track. The template recipe is the
    // authoritative placement and token source, so replace the lane once.
    targetTrack.segments = segments
    for (const extraTrack of sfxTracks.slice(1)) {
      const index = next.tracks.indexOf(extraTrack)
      if (index >= 0) next.tracks.splice(index, 1)
    }
  } else {
    next.tracks.push({
      trackId: `trk-${createHash('sha256').update(`template-sfx-track\0${timeline.timelineId}`).digest('hex').slice(0, 24)}`,
      order: next.tracks.length,
      enabled: true,
      locked: false,
      kind: 'audio',
      role: 'sfx',
      segments,
    })
  }
  next.capabilityRequirements = computeCapabilityRequirements(next.tracks)
  return sealRichTimeline(next)
}
/** @param {Record<string, any>} style @param {unknown} layout @param {number} [minimumSize] */
const applyCanonicalTextLayout = (style, layout, minimumSize = 0) => {
  if (layout === undefined) return style
  const resolved = assertPackagingTextLayout(layout)
  return {
    ...style,
    size: Math.max(Number(style.size), minimumSize) * resolved.fontScale,
    transformX: resolved.transformX,
    transformY: resolved.transformY,
    autoWrapping: true,
    maxLineWidth: resolved.maxLineWidth,
  }
}
/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' &&
  /^[A-Za-z0-9][A-Za-z0-9_-]{0,179}$/u.test(value)
/** @param {unknown} value */
const safeDraftLabel = (value) =>
  typeof value === 'string' &&
  value === value.trim() &&
  value.length > 0 &&
  value.length <= 100 &&
  !/[\\/\u0000-\u001f]/u.test(value) &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value)
/** @param {unknown} value */
const draftIdentifier = (value) => identifier(value) || safeDraftLabel(value)
const windowsUnsafeDraftName = /[<>:"/\\|?*\u0000-\u001f]/gu
const privateBatchBridgeErrorCodes = new Set([
  'JY176_BATCH_ADMISSION_REQUIRED',
  'JY176_BATCH_FAMILY_MISMATCH',
  'JY176_BATCH_FAMILY_UNSUPPORTED',
  'JY176_BATCH_INPUT_INVALID',
  'JY176_BATCH_RANGE_INVALID',
  'JY176_BATCH_TARGETS_REQUIRED',
  'JY176_BATCH_TOKEN_MISSING',
  'NATIVE_000B_BATCH_ADMISSION_REQUIRED',
  'NATIVE_000B_BATCH_ATOMIC_ADMISSION_REQUIRED',
  'NATIVE_000B_BATCH_CATALOG_REQUIRED',
  'NATIVE_000B_BATCH_EVIDENCE_REQUIRED',
])
/** @param {unknown} error */
export const projectPrivateBatchBridgeErrorCode = (error) =>
  error instanceof Error && privateBatchBridgeErrorCodes.has(error.message)
    ? error.message
    : null
/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {number} value */
const boundedProgress = (value) => Math.max(10, Math.min(95, Number.isInteger(value) ? value : 10))
/** @param {unknown} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean' || typeof value === 'number') {
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`
  if (isRecord(value)) {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`
  }
  throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
}
/** @param {unknown} value */
const sha256 = (value) =>
  createHash('sha256').update(stableStringify(value)).digest('hex')
/** @param {unknown} value */
const jsonSafe = (value) => JSON.parse(JSON.stringify(value))

/** @param {string} value @param {number} maxLength */
const truncateUtf16 = (value, maxLength) => {
  let output = ''
  for (const character of value) {
    if ((output + character).length > maxLength) break
    output += character
  }
  return output.replace(/[ .]+$/u, '').trim()
}

/**
 * Jianying 11.3 renders the draft folder basename on its home screen instead
 * of draft_meta_info.draft_name. Keep that basename recognizable and unique
 * without exposing the private Workbench job identity.
 * @param {{projectName?: string, projectId: string, jobId: string, richTimeline?: Record<string, any> | null}} input
 */
export const createJianyingVisibleDraftName = (input) => {
  const richTimeline = isRecord(input.richTimeline) ? input.richTimeline : null
  const revision = Number.isSafeInteger(richTimeline?.revision) && Number(richTimeline?.revision) > 0
    ? Number(richTimeline?.revision)
    : null
  const revisionFingerprint = typeof richTimeline?.revisionFingerprint === 'string' &&
    /^[a-f0-9]{64}$/u.test(richTimeline.revisionFingerprint)
    ? richTimeline.revisionFingerprint
    : null
  const identity = sha256({
    jobId: input.jobId,
    projectId: input.projectId,
    revision,
    revisionFingerprint,
  }).slice(0, 12)
  const suffix = ` · ${revision === null ? '导出' : `修订 ${revision}`} · ${identity}`
  const rawStem = (input.projectName ?? 'OpenVideo 草稿')
    .normalize('NFC')
    .replace(windowsUnsafeDraftName, ' ')
    .replace(/\s+/gu, ' ')
    .replace(/[ .]+$/u, '')
    .trim()
  const stem = truncateUtf16(rawStem || 'OpenVideo 草稿', 100 - suffix.length)
  const visibleName = `${stem || 'OpenVideo 草稿'}${suffix}`
  if (!safeDraftLabel(visibleName)) {
    throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
  }
  return visibleName
}

/**
 * Derive the private RenderBundle identity only from a finalized canonical
 * RichTimeline and the already-projected writer payload. Non-editor legacy
 * plans intentionally do not receive an identity and remain outside QA-010's
 * same-bundle acceptance path.
 * @param {{timeline: Record<string, any>, preparation: Record<string, any>, timelinePackaging: Record<string, any>, desktopProfile: Record<string, any>, packagingResourceIndex?: Record<string, any> | null}} input
 */
export const deriveRenderBundleIdentity = ({ timeline, preparation, timelinePackaging, desktopProfile, packagingResourceIndex }) => {
  if (!isRecord(timeline) || timeline.status !== 'finalized' ||
    typeof timeline.timelineId !== 'string' || !Number.isSafeInteger(timeline.revision) ||
    typeof timeline.revisionFingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(timeline.revisionFingerprint)) return null
  const safeTimelineMaterials = (timeline.tracks ?? []).map((/** @type {Record<string, any>} */ track) => ({
    kind: track?.kind ?? null,
    segments: (track?.segments ?? []).map((/** @type {Record<string, any>} */ segment) => ({
      segmentId: segment?.segmentId ?? null,
      asset: segment?.asset ? {
        authorizationId: segment.asset.authorizationId ?? null,
        assetId: segment.asset.assetId ?? null,
        sceneId: segment.asset.sceneId ?? null,
      } : null,
      sourceRange: segment?.sourceRange ?? null,
      targetRange: segment?.targetRange ?? null,
      capabilityId: segment?.capabilityId ?? null,
    })),
  }))
  return {
    catalogFingerprint: sha256({
      profileId: desktopProfile.profileId,
      catalogFingerprint: packagingResourceIndex?.fingerprint ?? null,
    }),
    exportParametersFingerprint: sha256({
      orientation: timeline.orientation,
      fps: timeline.fps,
      durationUs: timeline.durationUs,
      preparation: preparation.timeline,
    }),
    jianyingSignatureFingerprint: sha256({
      profileId: desktopProfile.profileId,
      version: desktopProfile.version,
      capabilities: desktopProfile.capabilities,
    }),
    jianyingVersion: String(desktopProfile.version).replace(/[^A-Za-z0-9._-]/gu, '-'),
    packagingProjectionFingerprint: sha256(jsonSafe(timelinePackaging)),
    projectionVersion: 'rich-timeline-jianying-v1',
    resourceManifestFingerprint: sha256(jsonSafe({
      profileId: desktopProfile.profileId,
      privatePlan: jsonSafe(timelinePackaging.private_batch_plan ?? []),
      materials: safeTimelineMaterials,
    })),
    sourceMediaFingerprint: sha256(jsonSafe(safeTimelineMaterials)),
    timelineId: timeline.timelineId,
    timelineRevision: timeline.revision,
    timelineRevisionFingerprint: timeline.revisionFingerprint,
    writerSchemaVersion: 1,
    writerVersion: 'pyjianying-draft-writer-v2',
  }
}

/** Keep automatic export source ranges on the millisecond grid used by template slots. */
const alignAutomaticPlanToMilliseconds = (/** @type {Record<string, any>} */ editPlan) => {
  const aligned = clone(editPlan)
  /** @type {Array<{selected: Record<string, any>, startMs: number, floorDurationMs: number, fraction: number, rawDurationMs: number}>} */
  const selectedEntries = aligned.items.map((/** @type {Record<string, any>} */ item) => {
    const selected = item.candidates.find(
      (/** @type {Record<string, any>} */ candidate) =>
        candidate.candidate_id === item.selected_candidate_id,
    )
    if (!selected) {
      throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
    }
    const rawDurationMs = (Number(selected.end) - Number(selected.start)) * 1_000
    if (!Number.isFinite(rawDurationMs) || rawDurationMs <= 0) {
      throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
    }
    return {
      selected,
      startMs: Math.round(Number(selected.start) * 1_000),
      floorDurationMs: Math.max(1, Math.floor(rawDurationMs)),
      fraction: rawDurationMs - Math.floor(rawDurationMs),
      rawDurationMs,
    }
  })
  const targetTotalMs = Math.max(
    selectedEntries.length,
    Math.round(selectedEntries.reduce(
      (/** @type {number} */ total, /** @type {{rawDurationMs: number}} */ entry) =>
        total + entry.rawDurationMs,
      0,
    )),
  )
  const durationsMs = selectedEntries.map((entry) => entry.floorDurationMs)
  let delta = targetTotalMs - durationsMs.reduce(
    (/** @type {number} */ total, /** @type {number} */ value) => total + value,
    0,
  )
  const byRemainder = selectedEntries
    .map((entry, index) => ({ index, fraction: entry.fraction }))
    .sort((a, b) => b.fraction - a.fraction || a.index - b.index)
  for (let cursor = 0; delta > 0; cursor = (cursor + 1) % byRemainder.length) {
    durationsMs[byRemainder[cursor].index] += 1
    delta -= 1
  }
  const bySmallestRemainder = [...byRemainder].reverse()
  for (let cursor = 0; delta < 0; cursor = (cursor + 1) % bySmallestRemainder.length) {
    const index = bySmallestRemainder[cursor].index
    if (durationsMs[index] <= 1) continue
    durationsMs[index] -= 1
    delta += 1
  }
  if (delta !== 0) {
    throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
  }
  for (let index = 0; index < selectedEntries.length; index += 1) {
    const entry = selectedEntries[index]
    const endMs = entry.startMs + durationsMs[index]
    entry.selected.start = entry.startMs / 1_000
    entry.selected.end = endMs / 1_000
  }
  return aligned
}

/** @param {number[]} weights */
const allocateDurationRatios = (weights) => {
  if (
    weights.length === 0 ||
    weights.length > 1_000_000 ||
    weights.some((weight) => !Number.isSafeInteger(weight) || weight <= 0)
  ) {
    throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
  }
  const total = weights.reduce((sum, weight) => sum + weight, 0)
  const distributable = 1_000_000 - weights.length
  const raw = weights.map((weight) => distributable * weight / total)
  const ratios = raw.map((value) => 1 + Math.floor(value))
  let remainder = 1_000_000 - ratios.reduce((sum, ratio) => sum + ratio, 0)
  const order = raw
    .map((value, index) => ({ index, fraction: value - Math.floor(value) }))
    .sort((left, right) => right.fraction - left.fraction || left.index - right.index)
  for (let index = 0; index < remainder; index += 1) {
    ratios[order[index].index] += 1
  }
  return ratios
}

/**
 * Build the Writer envelope from the current project's final preparation with
 * exact millisecond slot timing. Reference templates contribute style/resource
 * candidates upstream; they never own this envelope's duration, slot order or
 * transitions.
 * @param {Record<string, any>} editPlan
 * @param {Record<string, any>} preparation
 * @param {string} orientation
 */
const createCurrentTimelineTemplate = (editPlan, preparation, orientation = 'portrait') => {
  const videoSegments = /** @type {Record<string, any>[]} */ (
    preparation.timeline.tracks[0].segments
  )
  if (videoSegments.length === 0 || videoSegments.length !== editPlan.items.length) {
    throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
  }
  const originalDurationsUs = videoSegments.map((segment) =>
    Math.max(1_000, Number(segment.target_range.duration)),
  )
  const durationsMs = originalDurationsUs.map((durationUs) =>
    Math.max(1, Math.floor(durationUs / 1_000)),
  )
  const totalMs = durationsMs.reduce(
    (/** @type {number} */ total, /** @type {number} */ value) => total + value,
    0,
  )
  let cursorUs = 0
  for (let index = 0; index < videoSegments.length; index += 1) {
    const durationUs = durationsMs[index] * 1_000
    videoSegments[index].target_range = { start: cursorUs, duration: durationUs }
    preparation.timeline.tracks[1].segments[index].target_range = {
      start: cursorUs,
      duration: durationUs,
    }
    const item = editPlan.items[index]
    const selected = item.candidates.find(
      (/** @type {Record<string, any>} */ candidate) =>
        candidate.candidate_id === item.selected_candidate_id,
    ) ?? item.candidates[0]
    const sourceStartUs = Math.round(Number(selected.start) * 1_000_000)
    // Shorten source duration only so material selection stays inside the asset.
    selected.start = sourceStartUs / 1_000_000
    selected.end = (sourceStartUs + durationUs) / 1_000_000
    videoSegments[index].source_range = {
      start: sourceStartUs,
      duration: durationUs,
    }
    cursorUs += durationUs
  }
  preparation.timeline.duration = cursorUs

  const durationRatios = allocateDurationRatios(durationsMs)
  const slots = durationsMs.map((durationMs, index, all) => ({
    slot_id: `slot-${String(index + 1).padStart(3, '0')}`,
    order: index + 1,
    role: index === 0 ? 'hook' : index === all.length - 1 ? 'cta' : 'detail',
    duration_ratio_ppm: durationRatios[index],
    recommended_duration_ms: durationMs,
    transition_out: index === all.length - 1 ? 'none' : 'cut',
    evidence_shot_ids: [`editor-shot-${index + 1}`],
  }))

  const draftPayload = {
    schema_version: 1,
    kind: 'reference_template_draft',
    draft_id: `reference-template-editor-${sha256({
      plan_id: editPlan.plan_id,
      duration_ms: totalMs,
      slots,
    }).slice(0, 24)}`,
    project_id: editPlan.project_id,
    base_template_ref: { template_id: 'universal-adaptive', version: 1 },
    reference_evidence: {
      request_id: `editor-bound-${editPlan.plan_id}`,
      reference_id: `editor-bound-${editPlan.plan_id}`,
      duration_ms: totalMs,
      orientation,
      source_kind: 'external_reference',
      access_mode: 'external_read_only',
      privacy: 'sanitized_metadata_only',
      evidence_codes: [
        'shot_timing',
        'visual_role',
        'transition_pattern',
        'caption_cadence',
        'audio_emphasis',
      ],
    },
    revision: {
      number: 0,
      parent_draft_id: null,
      reason_codes: [],
      changes: null,
    },
    target_duration_ms: totalMs,
    slots,
    rules: {
      pacing: 'balanced',
      caption_cadence: {
        mode: 'steady',
        max_chars_per_card: 30,
        cards_per_minute: 20,
      },
      audio_emphasis: [],
    },
    confirmation: 'required',
  }
  const draft = { ...draftPayload, integrity_sha256: sha256(draftPayload) }
  const confirmedPayload = {
    schema_version: 1,
    kind: 'confirmed_reference_template',
    confirmed_template_id: `confirmed-${sha256({ draft_id: draft.draft_id }).slice(0, 24)}`,
    source_draft_id: draft.draft_id,
    project_id: draft.project_id,
    base_template_ref: clone(draft.base_template_ref),
    orientation,
    reference_provenance: {
      reference_id: draft.reference_evidence.reference_id,
      source_kind: draft.reference_evidence.source_kind,
      access_mode: draft.reference_evidence.access_mode,
      privacy: draft.reference_evidence.privacy,
    },
    target_duration_ms: draft.target_duration_ms,
    slots: clone(draft.slots),
    rules: clone(draft.rules),
    confirmation: 'approved',
  }
  const confirmedTemplate = {
    ...confirmedPayload,
    integrity_sha256: sha256(confirmedPayload),
  }
  const decisionPayload = {
    schema_version: 1,
    kind: 'reference_template_review_decision',
    draft_id: draft.draft_id,
    decision: 'approved',
    reason_codes: ['structure_verified'],
    confirmed_template: confirmedTemplate,
    revision_request: null,
  }
  const decision = { ...decisionPayload, integrity_sha256: sha256(decisionPayload) }
  return { draft, decision, confirmedTemplate }
}

/**
 * Return the private blueprint only for authored rich-text packaging.
 *
 * The blueprint is not allowed to own the edit envelope: video, timing,
 * captions, audio and transitions still come exclusively from RichTimeline.
 * It is used as a packaging overlay so a user-supplied FlowerText track keeps
 * its real Jianying styling/resource references. A current private catalog
 * binding may provide a writer projection for the same slot, but it cannot
 * replace source-authored material_animations and their nested resources.
 * @param {Record<string, any> | null | undefined} templateGuidance
 * @param {Record<string, any> | null | undefined} timelinePackaging
 */
export const selectCanonicalTemplateBlueprint = (templateGuidance, timelinePackaging) => {
  const source = templateGuidance?.replicationRecipe?.source
  if (
    !isRecord(source) ||
    source.kind !== 'jianying_draft' ||
    typeof source.blueprintId !== 'string' ||
    !/^jtb_[a-f0-9]{24}$/u.test(source.blueprintId) ||
    typeof source.fingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(source.fingerprint)
  ) return null
  const authoredPackagingSegments = Array.isArray(templateGuidance?.replicationRecipe?.packagingSegments)
    ? templateGuidance.replicationRecipe.packagingSegments
    : []
  const authoredRichCount = Number(templateGuidance?.replicationRecipe?.packaging?.flowerTextCount) || 0
  // The source blueprint remains authoritative for authored rich-text
  // decoration. The writer removes the generated title segment after the
  // replacement is applied, so retaining this overlay does not duplicate
  // copy while preserving template-owned animation materials.
  if (authoredRichCount < 1 && authoredPackagingSegments.length === 0) return null
  return Object.freeze({ blueprintId: source.blueprintId, fingerprint: source.fingerprint })
}

const packagingRangeKeys = Object.freeze([
  'video',
  'caption_segments',
  'title_segments',
  'rich_text_segments',
  'sfx_segments',
  'audio_effect_segments',
  'effect_segments',
  'sticker_segments',
  'animation_segments',
  'mask_segments',
  'blend_segments',
  'filter_segments',
  'chroma_segments',
])

/**
 * Remap packaging from canonical microsecond shot boundaries to the
 * millisecond-aligned writer boundaries. Starts retain their offset within a
 * shot; ends are bounded by the corresponding aligned shot end.
 * @param {Record<string, any>} packaging
 * @param {Array<{start: number, duration: number}>} sourceRanges
 * @param {Array<{start: number, duration: number}>} targetRanges
 */
const alignPackagingRangesToTimeline = (packaging, sourceRanges, targetRanges) => {
  if (
    !isRecord(packaging) ||
    sourceRanges.length === 0 ||
    sourceRanges.length !== targetRanges.length ||
    [...sourceRanges, ...targetRanges].some((range) =>
      !Number.isSafeInteger(range?.start) || !Number.isSafeInteger(range?.duration) ||
      range.start < 0 || range.duration <= 0)
  ) {
    throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
  }
  const mapPoint = (/** @type {number} */ value, /** @type {'start' | 'end'} */ edge) => {
    const index = sourceRanges.findIndex((range) => edge === 'start'
      ? value >= range.start && value < range.start + range.duration
      : value > range.start && value <= range.start + range.duration)
    if (index < 0) throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
    const source = sourceRanges[index]
    const target = targetRanges[index]
    return target.start + Math.min(value - source.start, target.duration)
  }
  const aligned = clone(packaging)
  for (const key of packagingRangeKeys) {
    if (!Array.isArray(aligned[key])) continue
    aligned[key] = aligned[key].map((segment) => {
      if (!isRecord(segment)) {
        throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
      }
      const startUs = segment.target_start_us
      const segmentDurationUs = segment.target_duration_us
      if (!Number.isSafeInteger(startUs) || !Number.isSafeInteger(segmentDurationUs) || startUs < 0 || segmentDurationUs <= 0) {
        throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
      }
      const mappedStartUs = mapPoint(startUs, 'start')
      const mappedEndUs = mapPoint(startUs + segmentDurationUs, 'end')
      if (mappedEndUs <= mappedStartUs) {
        // Millisecond writer quantization can collapse a sub-millisecond
        // caption fragment created around a rich-text boundary. It carries no
        // visible duration and is safe to omit; larger collapses remain errors.
        if (segmentDurationUs < 1_000) return null
        throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
      }
      return {
        ...segment,
        target_start_us: mappedStartUs,
        target_duration_us: mappedEndUs - mappedStartUs,
      }
    }).filter(Boolean)
  }
  return aligned
}

export class JianyingWorkbenchBridgeError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'JianyingWorkbenchBridgeError'
    this.code = code
    this.status = status
  }
}

/**
 * @param {{
 *   runtime: {register: Function, remove: Function, service: {start: Function, getStatus: Function, waitForCompletion: Function, cancel: Function, cleanupPublished: Function, releasePublished: Function, cleanupOwned?: Function, releaseOwned?: Function}},
 *   desktopProfile: {version: string, profileId: string, provisional: boolean, capabilities: {draft_generation: boolean, manual_open: boolean, desktop_ui_automation: boolean, template_read: boolean, background_render: boolean}},
 *   privateCatalogCapabilities?: string[],
 *   evidencedCapabilities?: string[],
 *   promotionReceipts?: readonly Record<string, unknown>[],
 *   batchTextCatalog?: {entries: readonly any[], profile_id: string, evidence_profile: Record<string, unknown>} | null,
 *   packagingResourceIndex?: Record<string, any> | null,
 *   packagingDesktopBinding?: {profileId: string, version: string, executablePath: string, installRoot: string, dllFingerprint: string} | null,
 *   packagingRecommendationFamilies?: string[] | null,
 *   materialAnalysisProvider: {resolvePreviewSources: Function},
 *   voiceoverProvider: {resolveVoiceovers: Function, cleanup: Function, resolveFromAudioTokens?: Function},
 *   setRenderOptions?: ((value: Record<string, any> | null, requestId?: string | null) => void) | null,
 *   acquireBgmLease?: ((input: {projectId: string, authorizationId: string}) => Promise<{extension: string, sha256: string, size: number, createStream: () => import('node:stream').Readable, release: () => Promise<void>} | null>) | null,
 *   resolveSfxAudio?: ((input: {audioToken: string, projectId: string, workId: string, signal: AbortSignal}) => Promise<{path: string, release: () => Promise<void>} | null>) | null,
 *   resolveAudioPath?: ((input: {audioToken: string, projectId?: string}) => Promise<string | null>) | null,
 *   resolveAudioEffectToken?: ((input: {effectToken: string, projectId?: string}) => Promise<{resourceId: string} | null>) | null,
 *   resolveTextAnimationToken?: ((input: {animationToken: string, projectId?: string}) => Promise<{resourceId: string, durationUs: number} | null>) | null,
 *   resolvePackagingToken?: ((input: {packagingToken: string, projectId?: string}) => Promise<{kind: string, resourceId: string, effectId?: string, durationUs?: number} | null>) | null,
 *   resolvePackagingSnapshot?: ((input?: {packagingTokens?: string[]}) => Promise<{ready: boolean, profileId?: string | null, appVersion?: string | null, catalogFingerprint?: string | null, packagingIndex?: Record<string, any> | null} | null>) | null,
 *   filterResolver?: {resolveFilterToken: (token: string, capabilityId: string) => Promise<{filterToken: string, capabilityId: string, resourceId: string}>} | null,
 *   packagingResolver?: ReturnType<typeof createJianyingPackagingResolver> | null,
 *   progressPollIntervalMs?: number,
 * }} dependencies
 */
export const createJianyingWorkbenchBridge = ({
  runtime,
  desktopProfile,
  privateCatalogCapabilities = [],
  evidencedCapabilities = [],
  promotionReceipts = [],
  batchTextCatalog = null,
  packagingResourceIndex = null,
  packagingDesktopBinding = null,
  packagingRecommendationFamilies = null,
  materialAnalysisProvider,
  voiceoverProvider,
  setRenderOptions = null,
  acquireBgmLease = null,
  resolveSfxAudio = null,
  resolveAudioPath = null,
  resolveAudioEffectToken = null,
  resolveTextAnimationToken = null,
  resolvePackagingToken = null,
  resolvePackagingSnapshot = null,
  filterResolver = null,
  packagingResolver = null,
  progressPollIntervalMs = 200,
}) => {
  const supportedVersion = typeof desktopProfile?.version === 'string' &&
    /^[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u.test(desktopProfile.version) &&
    desktopProfile.version.split('.').every((part) => Number.isSafeInteger(Number(part)))
  if (
    !runtime ||
    typeof runtime.register !== 'function' ||
    typeof runtime.remove !== 'function' ||
    !runtime.service ||
    typeof runtime.service.start !== 'function' ||
    typeof runtime.service.getStatus !== 'function' ||
    typeof runtime.service.waitForCompletion !== 'function' ||
    typeof runtime.service.cancel !== 'function' ||
    typeof runtime.service.cleanupPublished !== 'function' ||
    typeof runtime.service.releasePublished !== 'function' ||
    !desktopProfile ||
    !supportedVersion ||
    desktopProfile.provisional !== true ||
    !isRecord(desktopProfile.capabilities) ||
    Object.keys(desktopProfile.capabilities).sort().join(',') !==
      'background_render,desktop_ui_automation,draft_generation,manual_open,template_read' ||
    desktopProfile.capabilities.draft_generation !== true ||
    desktopProfile.capabilities.manual_open !== true ||
    desktopProfile.capabilities.desktop_ui_automation !== false ||
    desktopProfile.capabilities.template_read !== false ||
    // Desktop 11.1 remains manual-open only; accepting the explicit governed
    // flag must not accidentally enable background rendering.
    desktopProfile.capabilities.background_render !== false ||
    !materialAnalysisProvider ||
    typeof materialAnalysisProvider.resolvePreviewSources !== 'function' ||
    !voiceoverProvider ||
    typeof voiceoverProvider.resolveVoiceovers !== 'function' ||
    typeof voiceoverProvider.cleanup !== 'function' ||
    (resolveSfxAudio !== null && typeof resolveSfxAudio !== 'function') ||
    !Number.isSafeInteger(progressPollIntervalMs) ||
    progressPollIntervalMs < 1 ||
    progressPollIntervalMs > 5_000
  ) throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE')

  /** @type {Map<string, {requestId: string, privateJobId: string | null}>} */
  const active = new Map()
  /** @type {Map<string, {privateJobId: string, draftId: string}>} */
  const publications = new Map()

  /**
   * Resolve automatic packaging against the current admitted catalog first.
   * A template-owned token may remain valid even when the global catalog
   * snapshot is unavailable; in that case resolve every token through the
   * project-bound private template resolver and construct a scoped index.
   * @param {Record<string, any>} richTimeline
   * @param {string | undefined} projectId
   */
  const resolveTimelinePackagingIndex = async (richTimeline, projectId = undefined) => {
    if (richTimeline?.source?.automaticPackaging !== true || typeof resolvePackagingSnapshot !== 'function') return null
    const selections = readTimelinePackagingSelections(richTimeline)
    if (selections.length < 1) return null
    // Catalog snapshots are only for opaque Catalog tokens. Selected uploaded
    // drafts write from that draft's inventory and have no packagingSelections.
    const packagingTokens = selections.map((selection) => selection?.packagingToken)
    if (packagingTokens.some((token) => typeof token !== 'string') || new Set(packagingTokens).size !== packagingTokens.length) return null
    let snapshot
    try { snapshot = await resolvePackagingSnapshot({ packagingTokens }) } catch { snapshot = null }
    if (
      snapshot?.ready !== true ||
      !isRecord(snapshot.packagingIndex) ||
      snapshot.profileId !== desktopProfile.profileId ||
      snapshot.appVersion !== desktopProfile.version ||
      typeof snapshot.catalogFingerprint !== 'string' ||
      snapshot.packagingIndex.catalogFingerprint !== snapshot.catalogFingerprint ||
      typeof richTimeline.source.packagingCatalogFingerprint !== 'string' ||
      richTimeline.source.packagingCatalogFingerprint !== snapshot.catalogFingerprint
    ) {
      if (typeof resolvePackagingToken !== 'function' || typeof projectId !== 'string') return null
      const entries = []
      for (const selection of selections) {
        /** @type {Record<string, any> | null} */
        let resolved = null
        try {
          resolved = await resolvePackagingToken({ packagingToken: selection.packagingToken, projectId })
        } catch { resolved = null }
        const expectedKind = selection.family === 'flower'
          ? 'flower'
          : selection.family === 'bubble'
            ? 'bubble'
            : selection.family === 'sticker'
              ? 'sticker'
              : selection.family === 'video_effect'
                ? 'effect'
                : selection.family === 'video_animation'
                  ? 'animation'
                  : selection.family === 'mask'
                    ? 'mask'
                    : selection.family === 'blend'
                      ? 'blend'
                      : null
        if (!resolved || expectedKind === null || resolved.kind !== expectedKind || typeof resolved.resourceId !== 'string') return null
        entries.push({
          packaging_token: selection.packagingToken,
          family: selection.family,
          state: 'writer_eligible',
          writer_eligible: true,
          private_binding: {
            resourceId: resolved.resourceId,
            ...(typeof resolved.effectId === 'string' ? { effectId: resolved.effectId } : {}),
            ...(Number.isSafeInteger(resolved.durationUs) ? { durationUs: resolved.durationUs } : {}),
            ...(resolved.commonMaskTemplate ? { commonMaskTemplate: structuredClone(resolved.commonMaskTemplate) } : {}),
          },
        })
      }
      return {
        schema_version: 1,
        profileId: desktopProfile.profileId,
        appVersion: desktopProfile.version,
        catalogFingerprint: richTimeline.source.packagingCatalogFingerprint,
        entries,
      }
    }
    for (const selection of selections) {
      const known = snapshot.packagingIndex.entries.find(
        (/** @type {Record<string, any>} */ entry) => entry?.packaging_token === selection.packagingToken,
      )
      // Admission is enforced per placement below. Keeping a current-catalog
      // discovery entry here lets the Writer omit/degrade only that optional
      // decoration instead of rejecting the complete editable draft.
      if (!known || known.family !== selection.family) return null
    }
    return snapshot.packagingIndex
  }

  /** @param {Record<string, any>} richTimeline @param {string | undefined} projectId */
  const canExportRichTimeline = async (richTimeline, projectId = undefined) => {
    if (!isRecord(richTimeline) || !Array.isArray(richTimeline.capabilityRequirements)) return false
    let activePackagingResourceIndex = packagingResourceIndex
    if (richTimeline.source?.automaticPackaging === true) {
      const catalogSelections = readTimelinePackagingSelections(richTimeline)
      if (catalogSelections.length > 0) {
        activePackagingResourceIndex = await resolveTimelinePackagingIndex(richTimeline, projectId ?? richTimeline.projectId)
        if (!activePackagingResourceIndex) return false
      }
    }
    const dynamicPackagingCapabilities = new Map([
      ['flower', 'text.flower.private'],
      ['sticker', 'sticker.named'],
      ['video_effect', 'effect.video.named'],
      ['video_animation', 'animation.video.named'],
      ['mask', 'mask.video.named'],
      ['blend', 'blend.video.named'],
    ])
    const activePackagingCapabilities = (activePackagingResourceIndex?.entries ?? [])
      .filter(isAdmittedPackagingEntry)
      .map((/** @type {Record<string, any>} */ entry) => dynamicPackagingCapabilities.get(entry.family))
      .filter((/** @type {string | undefined} */ capabilityId) => typeof capabilityId === 'string')
    const knownPackagingCapabilities = new Set((activePackagingResourceIndex?.entries ?? [])
      .map((/** @type {Record<string, any>} */ entry) => dynamicPackagingCapabilities.get(entry.family))
      .filter((/** @type {string | undefined} */ capabilityId) => typeof capabilityId === 'string'))
    const requestPackagingCapabilities = new Set(activePackagingCapabilities)
    const capabilityEntries = createEditorCapabilityRegistry({
      jianyingProfileId: desktopProfile.profileId,
      privateCatalogCapabilities: [...new Set([...privateCatalogCapabilities, ...activePackagingCapabilities])],
      evidencedCapabilities,
      promotionReceipts,
    }).list().capabilities
    return richTimeline.capabilityRequirements.every((/** @type {Record<string, any>} */ requirement) => {
      if (typeof requirement?.capabilityId !== 'string') return false
      if (requestPackagingCapabilities.has(requirement.capabilityId)) return true
      if (richTimeline.source?.automaticPackaging === true && knownPackagingCapabilities.has(requirement.capabilityId)) return true
      if (requirement.capabilityId === 'track.insert' || requirement.capabilityId === 'track.insert_many') {
        // The Native bridge already emits these structures through its
        // append-track path when exact insert evidence is unavailable.
        return true
      }
      return capabilityEntries.find((/** @type {Record<string, any>} */ entry) => entry.capabilityId === requirement.capabilityId)
        ?.targets?.jianying?.status === 'implemented'
    })
  }

  /** @param {{projectId: string, authorizationId: string}} input */
  const acquireAuthorizedBgm = async (input) => {
    if (typeof acquireBgmLease !== 'function') return null
    const lease = await acquireBgmLease(input)
    if (!lease) return null
    if (
      typeof lease.extension !== 'string' || !/^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(lease.extension) ||
      typeof lease.sha256 !== 'string' || !/^[a-f0-9]{64}$/u.test(lease.sha256) ||
      !Number.isSafeInteger(lease.size) || lease.size <= 0 ||
      typeof lease.createStream !== 'function' || typeof lease.release !== 'function'
    ) {
      if (typeof lease.release === 'function') await lease.release().catch(() => {})
      return null
    }
    // Preview lease may expose fd helpers; Jianying runtime isBgmLease requires exact 5 keys.
    return {
      extension: lease.extension,
      sha256: lease.sha256,
      size: lease.size,
      createStream: lease.createStream,
      release: lease.release,
    }
  }

  /** @param {Record<string, any>} input */
  const exportDraft = async (input) => {
    /** @type {{extension: string, sha256: string, size: number, createStream: () => import('node:stream').Readable, release: () => Promise<void>} | null} */
    let bgmLease = null
    /** @type {Array<{path: string, release: () => Promise<void>}>} */
    const sfxResources = []
    const requestId = `jy003-${input?.jobId}`
    try {
      const editorBound = Boolean(input?.richTimeline) || input?.editorBound === true
      let bindingReady = false
      try {
        const canonicalGuidance = createTemplateGuidance(input?.templateBinding)
        const expectedGuidance = canonicalGuidance
          ? adaptTemplateGuidanceToCount(canonicalGuidance, input?.editPlan?.items?.length)
          : null
        bindingReady =
          JSON.stringify(input?.templateGuidance) === JSON.stringify(expectedGuidance) &&
          (
            canonicalGuidance === null ||
            canonicalGuidance.orientation === input?.brief?.orientation
          )
      } catch {
        bindingReady = false
      }
      if (
        !identifier(input?.projectId) ||
        !identifier(input?.jobId) ||
        ((!editorBound && !identifier(input?.authorizationId)) ||
          (editorBound && identifier(input?.authorizationId) === false &&
            input?.authorizationId != null) ||
          (editorBound && !identifier(input?.authorizationId) &&
            !Array.isArray(input?.resolvedMaterials))) ||
        typeof input?.checkpoint !== 'function' ||
        !(input?.signal instanceof AbortSignal) ||
        (input?.projectName !== undefined && !safeDraftLabel(input.projectName)) ||
        !bindingReady
      ) throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
      const draftLabel = createJianyingVisibleDraftName({
        projectName: input.projectName,
        projectId: input.projectId,
        jobId: input.jobId,
        richTimeline: isRecord(input.richTimeline) ? input.richTimeline : null,
      })
      if (typeof setRenderOptions === 'function') {
        setRenderOptions({ draftLabel }, requestId)
      }
      assertTemplateGuidanceExecutable(input.templateGuidance)
      input.signal.throwIfAborted()

      /** @type {import('./jianying-batch-recommendation-writer-smoke.mjs').PrivateBatchIndex | null} */
      let activePackagingResourceIndex = /** @type {import('./jianying-batch-recommendation-writer-smoke.mjs').PrivateBatchIndex | null} */ (packagingResourceIndex)
      const resolver = packagingResolver ?? createJianyingPackagingResolver({
        resolveAudioPath: resolveAudioPath
          ? (payload) => resolveAudioPath({ ...payload, projectId: input.projectId })
          : undefined,
        resolvePackagingToken: async (payload) => {
          const current = resolvePrivatePackagingResourceToken(activePackagingResourceIndex, payload.packagingToken)
          if (current) return current
          return resolvePackagingToken
            ? resolvePackagingToken({ ...payload, projectId: input.projectId })
            : null
        },
        resolveAudioEffectToken: resolveAudioEffectToken
          ? (payload) => resolveAudioEffectToken({ ...payload, projectId: input.projectId })
          : undefined,
      })
      /** @type {Record<string, any>} */
      let effectivePlan
      /** @type {Record<string, any>} */
      let preparation
      /** @type {Record<string, any>} */
      let exportRequest
      /** @type {Record<string, any> | null} */
      let timelinePackaging = null
      /** @type {string[] | null} */
      let voiceoverAudioTokens = null
      /** @type {{draft: Record<string, any>, decision: Record<string, any>, confirmedTemplate: Record<string, any>} | null} */
      let currentTimelineTemplate = null
      let useAppendTrackFallback = false
      /** @type {Array<{segmentId: string, from: string, to: string, reason: string}>} */
      let writerDegradations = []
      /** @type {Record<string, any> | null} */
      let writerIdentityTimeline = null
      /** @type {{accepted: number, skipped: ReadonlyArray<{reason: string, count: number}>} | null} */
      let privateBatchSummary = null
      // Keep the catalog snapshot scoped to this export request. Automatic
      // packaging may refresh it from the current runtime profile below;
      // legacy/editor-bound paths continue using the injected index.
      if (editorBound) {
        if (!isRecord(input.richTimeline)) {
          throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
        }
        if (input.richTimeline.source?.automaticPackaging === true) {
          const catalogSelections = readTimelinePackagingSelections(input.richTimeline)
          if (catalogSelections.length > 0) {
            const resolvedIndex = await resolveTimelinePackagingIndex(input.richTimeline, input.projectId)
            if (!resolvedIndex) {
              throw new JianyingWorkbenchBridgeError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
            }
            activePackagingResourceIndex = /** @type {import('./jianying-batch-recommendation-writer-smoke.mjs').PrivateBatchIndex} */ (resolvedIndex)
          }
        }
        const dynamicPackagingCapabilities = new Map([
          ['flower', 'text.flower.private'],
          ['sticker', 'sticker.named'],
          ['video_effect', 'effect.video.named'],
          ['video_animation', 'animation.video.named'],
          ['mask', 'mask.video.named'],
          ['blend', 'blend.video.named'],
        ])
        /** @type {string[]} */
        const activePackagingCapabilities = (activePackagingResourceIndex?.entries ?? [])
          .filter(isAdmittedPackagingEntry)
          .map((/** @type {Record<string, any>} */ entry) => dynamicPackagingCapabilities.get(entry.family))
          .filter((/** @type {string | undefined} */ capabilityId) => typeof capabilityId === 'string')
        const capabilityRegistry = createEditorCapabilityRegistry({
          jianyingProfileId: desktopProfile.profileId,
          privateCatalogCapabilities: [...new Set([...privateCatalogCapabilities, ...activePackagingCapabilities])],
          evidencedCapabilities,
          promotionReceipts,
        })
        const capabilityEntries = capabilityRegistry.list().capabilities
        const hasUnsupportedTrackInsertion = (input.richTimeline.capabilityRequirements ?? []).some(
          (/** @type {Record<string, any>} */ requirement) =>
            (requirement.capabilityId === 'track.insert' || requirement.capabilityId === 'track.insert_many') &&
            capabilityEntries.find((entry) => entry.capabilityId === requirement.capabilityId)?.targets?.jianying?.status !== 'implemented',
        )
        // The writer's append-track path is the safe structural fallback when
        // the active profile has no admitted insert operation. This is a
        // runtime capability decision, not a version allowlist.
        useAppendTrackFallback = hasUnsupportedTrackInsertion
        let effectiveRichTimeline = input.richTimeline
        const privateTextSupported = new Set(['text.flower.private', 'text.bubble.private'].filter((capabilityId) =>
          capabilityEntries.find((entry) => entry.capabilityId === capabilityId)?.targets?.jianying?.status === 'implemented',
        ))
        if ((input.richTimeline.tracks ?? []).some((/** @type {Record<string, any>} */ track) =>
          track.kind === 'title' && (track.segments ?? []).some((/** @type {Record<string, any>} */ segment) =>
            (segment.capabilityId === 'text.flower.private' || segment.capabilityId === 'text.bubble.private') &&
            !privateTextSupported.has(segment.capabilityId),
          ))) {
          const derived = structuredClone(input.richTimeline)
          for (const track of derived.tracks ?? []) {
            if (track.kind !== 'title') continue
            for (const segment of track.segments ?? []) {
              if (segment.capabilityId !== 'text.flower.private' && segment.capabilityId !== 'text.bubble.private') continue
              if (privateTextSupported.has(segment.capabilityId)) continue
              writerDegradations.push({
                segmentId: segment.segmentId,
                from: segment.capabilityId,
                to: 'text.rich',
                reason: 'PRIVATE_TEXT_CAPABILITY_UNAVAILABLE',
              })
              segment.capabilityId = 'text.rich'
              segment.templateToken = null
            }
          }
          derived.capabilityRequirements = computeCapabilityRequirements(derived.tracks)
          const resealed = sealRichTimeline(derived)
          effectiveRichTimeline = resealed
        }
        // Backfill SFX learned from the selected template for legacy finalized
        // timelines that were created before template audio inheritance.
        effectiveRichTimeline = injectTemplateSfxForExport(effectiveRichTimeline, input.templateGuidance)
        writerIdentityTimeline = effectiveRichTimeline
        let projected
        try {
          projected = projectRichTimelineToJianyingExport(effectiveRichTimeline, {
            capabilityRegistry,
            jianyingProfileId: desktopProfile.profileId,
            allowAppendTrackFallback: useAppendTrackFallback,
          })
        } catch (error) {
          if (error instanceof RichTimelineJianyingProjectionError) {
            throw new JianyingWorkbenchBridgeError(error.code, error.status)
          }
          throw error
        }
        effectivePlan = projected.editPlan
        preparation = projected.preparation
        timelinePackaging = projected.packaging
        voiceoverAudioTokens = projected.voiceoverAudioTokens
        const editorBoundOrientation = typeof input.richTimeline?.orientation === 'string'
          ? input.richTimeline.orientation
          : normalizeBrief(input.brief ?? {}).orientation
        const sourceVideoRanges = preparation.timeline.tracks[0].segments.map(
          (/** @type {Record<string, any>} */ segment) => clone(segment.target_range),
        )
        currentTimelineTemplate = createCurrentTimelineTemplate(
          effectivePlan,
          preparation,
          editorBoundOrientation,
        )
        const alignedVideoRanges = preparation.timeline.tracks[0].segments.map(
          (/** @type {Record<string, any>} */ segment) => clone(segment.target_range),
        )
        timelinePackaging = alignPackagingRangesToTimeline(
          timelinePackaging,
          sourceVideoRanges,
          alignedVideoRanges,
        )
        const preparationPreflight = preflightJianyingDraftPreparation(effectivePlan, preparation)
        exportRequest = createJianyingDraftExportRequest(
          effectivePlan,
          preparation,
          preparationPreflight,
          timelinePackaging,
        )
        // editorBound: never derive packaging from brief / setRenderOptions.
      } else {
        const brief = normalizeBrief(input.brief ?? {})
        const guidancePackaging = input.templateGuidance?.rules?.packaging
        const packaging = normalizePackaging({
          ...brief.packaging,
          ...(typeof guidancePackaging?.intro === 'string'
            ? { intro: guidancePackaging.intro }
            : {}),
          ...(typeof guidancePackaging?.outro === 'string'
            ? { outro: guidancePackaging.outro }
            : {}),
          ...(typeof guidancePackaging?.subtitleStyle === 'string'
            ? { subtitleStyle: guidancePackaging.subtitleStyle }
            : {}),
        })
        if (packaging.bgm === 'local_authorized') {
          if (!acquireBgmLease || !packaging.bgmAuthorizationId) {
            throw new JianyingWorkbenchBridgeError('WORKBENCH_BGM_AUTHORIZATION_REQUIRED', 409)
          }
          bgmLease = await acquireAuthorizedBgm({
            projectId: input.projectId,
            authorizationId: packaging.bgmAuthorizationId,
          })
          if (!bgmLease) {
            throw new JianyingWorkbenchBridgeError('WORKBENCH_BGM_AUTHORIZATION_REQUIRED', 409)
          }
        }
        const guidedPlan = applyTemplateGuidanceToEditPlan(
          input.editPlan,
          input.templateGuidance,
        )
        effectivePlan = alignAutomaticPlanToMilliseconds(guidedPlan)
        preparation = buildJianyingDraftPreparation(effectivePlan)
        currentTimelineTemplate = createCurrentTimelineTemplate(
          effectivePlan,
          preparation,
          brief.orientation,
        )
        const preparationPreflight = preflightJianyingDraftPreparation(effectivePlan, preparation)
        exportRequest = createJianyingDraftExportRequest(
          effectivePlan,
          preparation,
          preparationPreflight,
        )
        const timelineDuration = Number(/** @type {Record<string, any>} */ (preparation).timeline?.duration) || 0
        const titleText = typeof brief.title === 'string' && brief.title.trim()
          ? brief.title.trim().slice(0, 160)
          : 'OpenVideo'
        /** @type {Array<{text: string, target_start_us: number, target_duration_us: number, rich?: boolean}>} */
        const titleSegments = []
        if (packaging.intro === 'title_card' && timelineDuration > 0) {
          titleSegments.push({
            text: titleText,
            target_start_us: 0,
            target_duration_us: Math.min(1_500_000, timelineDuration),
            rich: false,
          })
        }
        if (packaging.outro === 'title_card' && timelineDuration > 0) {
          const duration = Math.min(1_500_000, timelineDuration)
          titleSegments.push({
            text: titleText,
            target_start_us: Math.max(0, timelineDuration - duration),
            target_duration_us: duration,
            rich: false,
          })
        }
        if (typeof setRenderOptions === 'function') {
          setRenderOptions({
            draftLabel,
            // Template cadence may style user-enabled captions only; it must
            // not bring captions back after the user selected “none”.
            captions: brief.captions === 'auto',
            bgmPath: null,
            bgmVolume: packaging.bgmVolume,
            subtitleStyle: packaging.subtitleStyle,
            titleSegments,
            keywordHighlights: packaging.keywordHighlights,
            overlayAssignments: isRecord(input.overlayAssignments)
              ? input.overlayAssignments
              : { effects: [], stickers: [] },
          }, requestId)
        }
      }

      const briefOrientation = editorBound
        ? (typeof input.richTimeline?.orientation === 'string'
            ? input.richTimeline.orientation
            : normalizeBrief(input.brief ?? {}).orientation)
        : normalizeBrief(input.brief ?? {}).orientation
      const template = currentTimelineTemplate ?? createCurrentTimelineTemplate(
        effectivePlan,
        exportRequest.preparation,
        briefOrientation,
      )
      if (!template) {
        throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_EXPORT_INPUT_INVALID', 409)
      }
      const confirmedTemplate = template.confirmedTemplate
      const templateEnvelope = createJianyingTemplateAdapterEnvelope(
        effectivePlan,
        exportRequest,
        template.draft,
        confirmedTemplate,
        template.decision,
      )
      const timeline = /** @type {Record<string, any>} */ (exportRequest.preparation).timeline
      const videoSegments = /** @type {Record<string, any>[]} */ (timeline.tracks[0].segments)
      const voiceoverSegments = /** @type {Record<string, any>[]} */ (timeline.tracks[1].segments)
      const selections = videoSegments.map((/** @type {Record<string, any>} */ segment) => ({
        candidateId: segment.material_ref.candidate_id,
        start: segment.source_range.start / 1_000_000,
        end: (segment.source_range.start + segment.source_range.duration) / 1_000_000,
      }))

      /** @type {any[]} */
      let materials
      /** @type {any[]} */
      let voiceovers
      if (editorBound) {
        if (!Array.isArray(voiceoverAudioTokens)) {
          throw new JianyingWorkbenchBridgeError('JY002_VOICEOVER_AUDIO_MISSING', 409)
        }
        // The coordinator resolves each editor segment against its current
        // source authorization. It is private process-only data and prevents
        // a reference-only target project from impersonating that source.
        materials = Array.isArray(input.resolvedMaterials)
          ? input.resolvedMaterials
          : !identifier(input.authorizationId)
            ? (() => { throw new JianyingWorkbenchBridgeError('WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE', 409) })()
            : await materialAnalysisProvider.resolvePreviewSources({
              projectId: input.projectId,
              authorizationId: input.authorizationId,
              selections,
              signal: input.signal,
            })
        if (voiceoverAudioTokens.length > 0) {
          if (typeof voiceoverProvider.resolveFromAudioTokens !== 'function') {
            throw new JianyingWorkbenchBridgeError('JY002_VOICEOVER_AUDIO_MISSING', 409)
          }
          voiceovers = await voiceoverProvider.resolveFromAudioTokens({
            projectId: input.projectId,
            jobId: input.jobId,
            audioTokens: voiceoverAudioTokens,
            segments: clone(voiceoverSegments),
            signal: input.signal,
            resolveAudioPath: resolveAudioPath
              ? (/** @type {{audioToken: string}} */ payload) =>
                resolveAudioPath({ ...payload, projectId: input.projectId })
              : undefined,
          })
        } else {
          voiceovers = []
        }
        // Resolve packaging audio tokens into private paths for the writer only.
        if (timelinePackaging && typeof setRenderOptions === 'function') {
          /** @type {Array<{text: string, path: string, volume: number, target_start_us: number, target_duration_us: number, fade_in_us: number, fade_out_us: number, effect_resource_id?: string}>} */
          const resolvedSfx = []
          for (const segment of timelinePackaging.sfx_segments ?? []) {
            let resolvedPath = null
            if (
              typeof resolveSfxAudio === 'function' &&
              typeof segment.audio_token === 'string' &&
              !segment.audio_token.startsWith('tma_')
            ) {
              const resource = await resolveSfxAudio({
                audioToken: segment.audio_token,
                projectId: input.projectId,
                workId: input.jobId,
                signal: input.signal,
              })
              if (
                !resource || typeof resource.path !== 'string' || !isAbsolute(resource.path) ||
                resource.path.includes('\u0000') || typeof resource.release !== 'function'
              ) {
                await resource?.release?.().catch(() => {})
                throw new JianyingWorkbenchBridgeError('JY004_SFX_AUDIO_MISSING', 409)
              }
              sfxResources.push(resource)
              resolvedPath = resource.path
            } else {
              const resolved = await resolver.resolveAudioToken(segment.audio_token)
              resolvedPath = resolved.path
            }
            resolvedSfx.push({
              text: '',
              path: resolvedPath,
              volume: segment.volume,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
              fade_in_us: segment.fade_in_us ?? 0,
              fade_out_us: segment.fade_out_us ?? 0,
            })
          }
          for (const segment of timelinePackaging.audio_effect_segments ?? []) {
            const resolved = await resolver.resolveAudioEffectToken(segment.effect_token)
            const target = resolvedSfx.find((item) => item.target_start_us === segment.target_start_us && item.target_duration_us === segment.target_duration_us)
            if (!target || target.effect_resource_id) throw new JianyingWorkbenchBridgeError('JY067_AUDIO_EFFECT_BINDING_INVALID', 409)
            target.effect_resource_id = resolved.resourceId
          }
          let resolvedBgmPath = null
          if (timelinePackaging.bgm?.audio_token) {
            if (timelinePackaging.bgm.capability_id === 'audio.bgm.local') {
              if (!acquireBgmLease) {
                throw new JianyingWorkbenchBridgeError('WORKBENCH_BGM_AUTHORIZATION_REQUIRED', 409)
              }
              bgmLease = await acquireAuthorizedBgm({
                projectId: input.projectId,
                authorizationId: timelinePackaging.bgm.audio_token,
              })
              if (!bgmLease) {
                throw new JianyingWorkbenchBridgeError('WORKBENCH_BGM_AUTHORIZATION_REQUIRED', 409)
              }
            } else {
              const resolved = await resolver.resolveAudioToken(timelinePackaging.bgm.audio_token)
              resolvedBgmPath = resolved.path
            }
          }
          const resolvedVideo = (timelinePackaging.video ?? []).map(
            (/** @type {Record<string, any>} */ segment) => {
            if (!segment.transition_out) {
              return { segment_id: segment.segment_id, target_start_us: segment.target_start_us, target_duration_us: segment.target_duration_us, keyframes: segment.keyframes ?? [], transition_out: null }
            }
            const transition = resolver.resolveTransition(segment.transition_out.capability_id)
            return {
              segment_id: segment.segment_id,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
              keyframes: segment.keyframes ?? [],
              transition_out: {
                capability_id: segment.transition_out.capability_id,
                duration_us: segment.transition_out.duration_us,
                transition_name: transition.transitionName,
              },
            }
          })
          const resolvedCaptions = (timelinePackaging.caption_segments ?? []).map(
            (/** @type {Record<string, any>} */ segment) => ({
            text: segment.text,
            target_start_us: segment.target_start_us,
            target_duration_us: segment.target_duration_us,
            style: resolver.resolveTextStyle(
              segment.style_token ||
                (segment.capability_id === 'caption.bottom_safe' ? 'bottom_safe' : 'default'),
            ).style,
          }))
          const admittedPrivateCatalogTokens = new Set((activePackagingResourceIndex?.entries ?? [])
            .filter(isAdmittedPackagingEntry)
            .map((/** @type {Record<string, any>} */ entry) => entry.packaging_token)
            .filter((/** @type {unknown} */ token) => typeof token === 'string'))
          /** @type {Array<Record<string, any>>} */
          const resolvedTitles = []
          for (const segment of timelinePackaging.title_segments ?? []) {
            /** @type {Record<string, any>} */
            const resolved = {
              segment_id: segment.segment_id,
              text: segment.text,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
              rich: false,
              keyframes: Array.isArray(segment.keyframes) ? structuredClone(segment.keyframes) : [],
              style: applyCanonicalTextLayout(
                resolver.resolveTextStyle(segment.style_token || 'title_card').style,
                segment.layout,
              ),
            }
            // Template flower/bubble slots can be projected as title segments.
            // Resolve their current admitted token here as well; otherwise the
            // Python writer receives a plain title and silently emits white text.
            if (segment.template_token && ['text.rich', 'text.flower.private', 'text.bubble.private'].includes(segment.capability_id)) {
              const currentCatalogEntry = activePackagingResourceIndex?.entries?.find(
                (/** @type {Record<string, any>} */ entry) => entry?.packaging_token === segment.template_token,
              )
              if (currentCatalogEntry && !admittedPrivateCatalogTokens.has(segment.template_token)) {
                writerDegradations.push({
                  segmentId: typeof segment.segment_id === 'string' ? segment.segment_id : 'title',
                  from: currentCatalogEntry.family === 'flower' ? 'text.flower.private' : 'text.bubble.private',
                  to: 'text.rich',
                  reason: 'JY176_BATCH_ADMISSION_REQUIRED',
                })
              } else {
                if (segment.capability_id === 'text.rich' && segment.template_token.startsWith('ovjpack_v1_')) {
                  throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
                }
                const decoration = /** @type {{kind: string, resourceId: string, effectId?: string}} */ (
                  await resolver.resolvePackagingToken(segment.template_token)
                )
                if ((segment.capability_id === 'text.rich' || segment.capability_id === 'text.flower.private') && decoration.kind === 'flower') {
                  resolved.flower_effect_id = decoration.effectId
                  resolved.flower_resource_id = decoration.resourceId
                } else if ((segment.capability_id === 'text.rich' || segment.capability_id === 'text.bubble.private') && decoration.kind === 'bubble') {
                  resolved.bubble_effect_id = decoration.effectId
                  resolved.bubble_resource_id = decoration.resourceId
                } else {
                  throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
                }
              }
            }
            resolvedTitles.push(resolved)
          }
          const requestedFilters = (timelinePackaging.filter_segments ?? []).map(
            (/** @type {Record<string, any>} */ segment) => ({
              filterToken: segment.filter_token,
              capabilityId: segment.capability_id,
              targetStartUs: segment.target_start_us,
              targetDurationUs: segment.target_duration_us,
              intensity: segment.intensity,
            }))
          /** @type {ReadonlyArray<Record<string, any>>} */
          let resolvedFilters = []
          if (requestedFilters.length > 0) {
            try {
              resolvedFilters = await resolveJianyingFilterWriterBindings(requestedFilters, {
                filterResolver: filterResolver ?? undefined,
              })
            } catch (error) {
              if (error instanceof JianyingFilterWriterBindingError) {
                throw new JianyingWorkbenchBridgeError(error.code, 409)
              }
              throw error
            }
          }
          /** @type {Array<Record<string, any>>} */
          const resolvedRich = []
          for (const segment of timelinePackaging.rich_text_segments ?? []) {
            /** @type {Record<string, any>} */
            const resolved = {
              segment_id: segment.segment_id,
              text: segment.text,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
              style: applyCanonicalTextLayout(
                resolver.resolveTextStyle(segment.style_token || 'rich_emphasis').style,
                typeof segment.template_slot_id === 'string' ? undefined : segment.layout,
                typeof segment.template_slot_id === 'string' ? 0 : DECORATED_TEXT_MINIMUM_SIZE,
              ),
              rich: true,
              ...(typeof segment.template_slot_id === 'string' ? { template_slot_id: segment.template_slot_id } : {}),
            }
            if (segment.template_token) {
              const currentCatalogEntry = activePackagingResourceIndex?.entries?.find(
                (/** @type {Record<string, any>} */ entry) => entry?.packaging_token === segment.template_token,
              )
              if (currentCatalogEntry && !admittedPrivateCatalogTokens.has(segment.template_token)) {
                writerDegradations.push({
                  segmentId: typeof segment.segment_id === 'string' ? segment.segment_id : 'rich-text',
                  from: currentCatalogEntry.family === 'flower' ? 'text.flower.private' : 'text.bubble.private',
                  to: 'text.rich',
                  reason: 'JY176_BATCH_ADMISSION_REQUIRED',
                })
                resolvedRich.push(resolved)
                continue
              }
              if (segment.capability_id === 'text.rich' && segment.template_token.startsWith('ovjpack_v1_')) {
                throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
              }
              const decoration = /** @type {{kind: string, resourceId: string, effectId?: string}} */ (
                await resolver.resolvePackagingToken(segment.template_token)
              )
              if (segment.capability_id === 'text.rich' && decoration.kind === 'flower') {
                resolved.flower_effect_id = decoration.effectId
                resolved.flower_resource_id = decoration.resourceId
              } else if (segment.capability_id === 'text.rich' && decoration.kind === 'bubble') {
                resolved.bubble_effect_id = decoration.effectId
                resolved.bubble_resource_id = decoration.resourceId
              } else if (segment.capability_id === 'text.flower.private' && decoration.kind === 'flower') {
                resolved.flower_effect_id = decoration.effectId
                resolved.flower_resource_id = decoration.resourceId
              } else if (segment.capability_id === 'text.bubble.private' && decoration.kind === 'bubble') {
                resolved.bubble_effect_id = decoration.effectId
                resolved.bubble_resource_id = decoration.resourceId
              } else {
                throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
              }
            }
            resolvedRich.push(resolved)
          }
          const resolvedTextAnimations = []
          for (const segment of timelinePackaging.text_animation_segments ?? []) {
            if (typeof resolveTextAnimationToken !== 'function') {
              throw new JianyingPackagingResolverError('JY083_TEXT_ANIMATION_UNRESOLVED')
            }
            const resolved = await resolveTextAnimationToken({ animationToken: segment.animation_token, projectId: input.projectId })
            if (!resolved || typeof resolved.resourceId !== 'string' || !Number.isSafeInteger(resolved.durationUs) || resolved.durationUs <= 0) {
              throw new JianyingPackagingResolverError('JY083_TEXT_ANIMATION_UNRESOLVED')
            }
            const target = [...resolvedTitles, ...resolvedRich].find((candidate) => candidate.segment_id === segment.target_segment_id)
            if (!target) throw new JianyingPackagingResolverError('JY083_TEXT_ANIMATION_TARGET_UNRESOLVED')
            resolvedTextAnimations.push({ target_segment_id: segment.target_segment_id, resource_id: resolved.resourceId, duration_us: resolved.durationUs, target_start_us: target.target_start_us, target_duration_us: target.target_duration_us })
          }
          /** @type {Array<{resource_id: string, target_start_us: number, target_duration_us: number}>} */
          const resolvedEffects = []
          /** @type {Array<{resource_id: string, target_start_us: number, target_duration_us: number}>} */
          /** @type {Array<{resource_id: string, target_start_us: number, target_duration_us: number, keyframes?: Array<Record<string, any>>}>} */
          const resolvedStickers = []
          /** @type {Array<{resource_id: string, target_start_us: number, target_duration_us: number, duration_us: number}>} */
          const resolvedAnimations = []
          /** @type {Record<string, any>[]} */
          const resolvedMasks = []
          /** @type {Array<{resource_id: string, target_start_us: number, target_duration_us: number}>} */
          const resolvedBlends = []
          /** @type {Record<string, any>[]} */
          const resolvedBackgrounds = []
          const genericEffects = /** @type {Record<string, any>[]} */ (timelinePackaging.effect_segments ?? [])
          const genericStickers = /** @type {Record<string, any>[]} */ (timelinePackaging.sticker_segments ?? [])
          const genericAnimations = /** @type {Record<string, any>[]} */ (timelinePackaging.animation_segments ?? [])
          const genericMasks = /** @type {Record<string, any>[]} */ (timelinePackaging.mask_segments ?? [])
          const genericBlends = /** @type {Record<string, any>[]} */ (timelinePackaging.blend_segments ?? [])
          let genericBatch = null
          try {
            if (!activePackagingResourceIndex) {
              genericBatch = null
            } else {
              genericBatch = preparePrivateBatchWriterSmokeFromTimelinePackaging({
                index: activePackagingResourceIndex,
                timelinePackaging,
              })
            }
          } catch (error) {
            const code = projectPrivateBatchBridgeErrorCode(error)
            if (code) {
              throw new JianyingWorkbenchBridgeError(code, 409)
            }
            throw error
          }
          privateBatchSummary = genericBatch?.summary ?? null
          const genericTokens = new Set(genericBatch?.writerPlan.map((entry) => entry.packagingToken) ?? [])
          // The generic catalog can coexist with older per-family resolvers.
          // Only a token actually present in this exact private index belongs
          // to JY-136; prefix matching would silently suppress legacy tokens.
          const privateCatalogTokens = new Set((activePackagingResourceIndex?.entries ?? [])
            .map((/** @type {Record<string, any>} */ entry) => entry.packaging_token)
            .filter((/** @type {unknown} */ token) => typeof token === 'string'))
          const genericProjection = genericBatch?.projected ?? null
          for (const segment of timelinePackaging.video ?? []) {
            if (typeof segment.background_fill_token !== 'string') continue
            const resolved = /** @type {Record<string, any>} */ (await resolver.resolvePackagingToken(segment.background_fill_token))
            if (resolved.kind !== 'background') {
              throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
            }
            resolvedBackgrounds.push({
              fill_type: resolved.fillType,
              blur: resolved.blur,
              color: resolved.color,
              target_start_us: resolvedVideo.find((/** @type {Record<string, any>} */ item) => item.segment_id === segment.segment_id)?.target_start_us ?? 0,
              target_duration_us: resolvedVideo.find((/** @type {Record<string, any>} */ item) => item.segment_id === segment.segment_id)?.target_duration_us ?? 0,
            })
          }
          for (const segment of timelinePackaging.effect_segments ?? []) {
            if (genericTokens.has(segment.packaging_token) || privateCatalogTokens.has(segment.packaging_token)) continue
            const resolved = await resolver.resolvePackagingToken(segment.packaging_token)
            if (resolved.kind !== 'effect') {
              throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
            }
            resolvedEffects.push({
              resource_id: resolved.resourceId,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
            })
          }
          for (const segment of timelinePackaging.sticker_segments ?? []) {
            // Keyframed stickers use the legacy writer shape, but a token that
            // belongs to the current private catalog must never escape its
            // writer-admission boundary through that legacy path.
            if (activePackagingResourceIndex) {
              try {
                assertCurrentPrivateCatalogTokenAdmitted({
                  index: activePackagingResourceIndex,
                  packagingToken: segment.packaging_token,
                  admittedTokens: admittedPrivateCatalogTokens,
                })
              } catch (error) {
                const code = projectPrivateBatchBridgeErrorCode(error)
                if (code) {
                  writerDegradations.push({
                    segmentId: typeof segment.segment_id === 'string' ? segment.segment_id : 'sticker',
                    from: 'sticker.named',
                    to: 'none',
                    reason: code,
                  })
                  continue
                }
                throw error
              }
            }
            if (genericTokens.has(segment.packaging_token) && (!Array.isArray(segment.keyframes) || segment.keyframes.length === 0)) continue
            const resolved = await resolver.resolvePackagingToken(segment.packaging_token)
            if (resolved.kind !== 'sticker') {
              throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
            }
            const resolvedSticker = /** @type {{resource_id: string, target_start_us: number, target_duration_us: number, keyframes?: Array<Record<string, any>>}} */ ({
              resource_id: resolved.resourceId,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
            })
            if (Array.isArray(segment.keyframes) && segment.keyframes.length > 0) {
              resolvedSticker.keyframes = segment.keyframes.map((/** @type {any} */ keyframe) => ({
                capability_id: keyframe.capability_id,
                offset_us: keyframe.offset_us,
                value: keyframe.value,
                interpolation: keyframe.interpolation,
              }))
            }
            resolvedStickers.push(resolvedSticker)
          }
          for (const segment of timelinePackaging.animation_segments ?? []) {
            if (genericTokens.has(segment.animation_token) || privateCatalogTokens.has(segment.animation_token)) continue
            const resolved = await resolver.resolvePackagingToken(segment.animation_token)
            const animationResolved = /** @type {{kind: string, resourceId: string, durationUs?: number}} */ (resolved)
            const durationUs = animationResolved.durationUs
            if (animationResolved.kind !== 'animation' || typeof durationUs !== 'number' || !Number.isSafeInteger(durationUs) || durationUs <= 0) {
              throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
            }
            resolvedAnimations.push({
              resource_id: animationResolved.resourceId,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
              duration_us: durationUs,
            })
          }
          for (const segment of timelinePackaging.mask_segments ?? []) {
            if (genericTokens.has(segment.mask_token) || privateCatalogTokens.has(segment.mask_token)) continue
            const resolved = await resolver.resolvePackagingToken(segment.mask_token)
            const maskResolved = /** @type {{kind: string, resourceId: string, commonMaskTemplate?: Record<string, any>}} */ (resolved)
            if (maskResolved.kind !== 'mask' || !maskResolved.commonMaskTemplate) {
              throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
            }
            resolvedMasks.push({
              resource_id: maskResolved.resourceId,
              common_mask_template: maskResolved.commonMaskTemplate,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
              center_x: 0,
              center_y: 0,
              size: segment.size ?? 0.5,
              rotation: 0,
              feather: 0,
              invert: false,
            })
          }
          for (const segment of timelinePackaging.blend_segments ?? []) {
            if (genericTokens.has(segment.blend_token) || privateCatalogTokens.has(segment.blend_token)) continue
            const resolved = await resolver.resolvePackagingToken(segment.blend_token)
            if (resolved.kind !== 'blend') {
              throw new JianyingPackagingResolverError('JY004_PACKAGING_TOKEN_UNRESOLVED')
            }
            resolvedBlends.push({
              resource_id: resolved.resourceId,
              target_start_us: segment.target_start_us,
              target_duration_us: segment.target_duration_us,
            })
          }
          if (genericProjection) {
            resolvedEffects.push(...genericProjection.effect_segments)
            resolvedStickers.push(...genericProjection.sticker_segments)
            resolvedAnimations.push(...genericProjection.animation_segments)
            resolvedMasks.push(...genericProjection.mask_segments)
            resolvedBlends.push(...genericProjection.blend_segments)
          }
          const projectedWriterPackaging = {
            video: resolvedVideo,
            voiceover_segments: timelinePackaging.voiceover_segments ?? [],
            sfx_segments: resolvedSfx,
            audio_effect_segments: timelinePackaging.audio_effect_segments ?? [],
            bgm: timelinePackaging.bgm
              ? {
                  fade_in_us: timelinePackaging.bgm.fade_in_us ?? 0,
                  fade_out_us: timelinePackaging.bgm.fade_out_us ?? 0,
                }
              : null,
            effect_segments: resolvedEffects,
            sticker_segments: resolvedStickers,
            animation_segments: resolvedAnimations,
            filter_segments: resolvedFilters,
            mask_segments: resolvedMasks,
            blend_segments: resolvedBlends,
            chroma_segments: timelinePackaging.chroma_segments ?? [],
            text_animation_segments: resolvedTextAnimations,
            background_segments: resolvedBackgrounds,
            private_batch_plan: genericBatch?.writerPlan ?? [],
          }
          if (!writerIdentityTimeline) {
            throw new JianyingWorkbenchBridgeError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
          }
          const renderBundleIdentity = deriveRenderBundleIdentity({
            timeline: writerIdentityTimeline,
            preparation,
            timelinePackaging: projectedWriterPackaging,
            desktopProfile,
            packagingResourceIndex: activePackagingResourceIndex,
          })
          // Validate before the mutable render-options closure receives it.
          if (renderBundleIdentity) fingerprintRenderBundleIdentity(renderBundleIdentity)
          const canonicalTemplateBlueprint = selectCanonicalTemplateBlueprint(
            input.templateGuidance,
            timelinePackaging,
          )
          const authoredRichTextCount = Number(input.templateGuidance?.replicationRecipe?.packaging?.flowerTextCount) || 0
          if (editorBound && authoredRichTextCount > 0 && (timelinePackaging.rich_text_segments ?? []).length > 0 && !canonicalTemplateBlueprint) {
            throw new JianyingWorkbenchBridgeError('WORKBENCH_TEMPLATE_BINDING_INVALID', 409)
          }
          const renderOptions = {
            draftLabel,
            captions: resolvedCaptions.length > 0,
            bgmPath: resolvedBgmPath,
            bgmVolume: timelinePackaging.bgm?.volume ?? 0.12,
            subtitleStyle: timelinePackaging.subtitle_style,
            titleSegments: [...resolvedTitles, ...resolvedRich],
            keywordHighlights: [],
            overlayAssignments: isRecord(input.overlayAssignments)
              ? input.overlayAssignments
              : { effects: [], stickers: [] },
            trackInsertionProfile: editorBound && !useAppendTrackFallback ? desktopProfile.profileId : null,
            trackInsertionCapability: editorBound && !useAppendTrackFallback
              ? writerIdentityTimeline?.capabilityRequirements?.find((/** @type {Record<string, any>} */ requirement) => ['track.insert', 'track.insert_many'].includes(requirement?.capabilityId))?.capabilityId ?? null
              : null,
            templateBlueprint: canonicalTemplateBlueprint,
            ...(renderBundleIdentity ? { renderBundleIdentity } : {}),
            captionSegments: resolvedCaptions,
            // This stays inside the server→writer payload. It is never
            // returned through the public RichTimeline or job DTO.
            timelinePackaging: projectedWriterPackaging,
          }
          // Keep the request-specific resolver available to the in-process
          // Writer without making it part of cloned/audited render options.
          if (activePackagingResourceIndex) {
            Object.defineProperty(renderOptions, 'resolvePrivatePackagingToken', {
              value: (/** @type {string} */ packagingToken) =>
                resolvePrivatePackagingResourceToken(activePackagingResourceIndex, packagingToken),
              enumerable: false,
              configurable: true,
            })
          }
          setRenderOptions(renderOptions, requestId)
        }
      } else {
        const brief = normalizeBrief(input.brief ?? {})
        ;[materials, voiceovers] = await Promise.all([
          materialAnalysisProvider.resolvePreviewSources({
            projectId: input.projectId,
            authorizationId: input.authorizationId,
            selections,
            signal: input.signal,
          }),
          voiceoverProvider.resolveVoiceovers({
            projectId: input.projectId,
            jobId: input.jobId,
            voiceId: typeof brief.voiceId === 'string' ? brief.voiceId : null,
            rate: Number.isInteger(brief.voiceRate) ? brief.voiceRate : 0,
            segments: clone(voiceoverSegments),
            signal: input.signal,
          }),
        ])
      }
      input.signal.throwIfAborted()
      const resolvedVoiceoverSegments =
        editorBound && voiceoverAudioTokens?.length === 0 ? [] : voiceoverSegments
      // The canonical projection keeps text-aligned voiceover placeholders so
      // Preview and editor semantics remain stable. When no audio tokens exist,
      // remove those placeholders from the private Writer payload; otherwise
      // the Writer sees voiceover segments with zero resolved audio bindings
      // and (correctly) rejects the draft structure.
      if (editorBound && resolvedVoiceoverSegments.length === 0) {
        const writerPreparation = exportRequest?.preparation
        const writerTracks = writerPreparation?.timeline?.tracks
        if (Array.isArray(writerTracks)) {
          for (const track of writerTracks) {
            if (track?.kind === 'audio' && track?.role === 'voiceover') {
              track.segments = []
            }
          }
        }
      }
      if (
        !Array.isArray(materials) ||
        materials.length !== videoSegments.length ||
        materials.some((entry) => !isRecord(entry) || typeof entry.sourcePath !== 'string') ||
        !Array.isArray(voiceovers) ||
        voiceovers.length !== resolvedVoiceoverSegments.length ||
        voiceovers.some((entry) =>
          !isRecord(entry) ||
          !identifier(entry.sentenceId) ||
          !identifier(entry.audioId) ||
          typeof entry.path !== 'string')
      ) throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_PRIVATE_RESOLUTION_INVALID', 500)
      const request = createJianyingDraftAdapterRequest({
        schema_version: 1,
        kind: 'jianying_draft_adapter_request',
        request_id: requestId,
        edit_plan: clone(effectivePlan),
        export_request: exportRequest,
        template_draft: clone(template.draft),
        confirmed_template: clone(confirmedTemplate),
        review_decision: clone(template.decision),
        template_envelope: templateEnvelope,
        material_bindings: videoSegments.map((/** @type {Record<string, any>} */ segment, index) => ({
          asset_id: segment.material_ref.asset_id,
          scene_id: segment.material_ref.scene_id,
          candidate_id: segment.material_ref.candidate_id,
          authorization_id: `material-${input.jobId}-${index + 1}`,
        })),
        voiceover_bindings: resolvedVoiceoverSegments.map((/** @type {Record<string, any>} */ segment, index) => ({
          sentence_id: segment.sentence_id,
          audio_id: voiceovers[index].audioId,
          authorization_id: `voiceover-${input.jobId}-${index + 1}`,
        })),
        output_policy: {
          draft_id: draftLabel,
          desktop_open: false,
        },
      })
      runtime.register({
        request,
        material_authorizations: materials.map((entry, index) => ({
          authorization_id: request.material_bindings[index].authorization_id,
          path: entry.sourcePath,
        })),
        voiceover_authorizations: voiceovers.map((entry, index) => ({
          authorization_id: request.voiceover_bindings[index].authorization_id,
          path: entry.path,
        })),
        ...(bgmLease ? { bgm_lease: bgmLease } : {}),
      })
      /** @type {string | null} */
      let privateJobId = null
      const onAbort = () => {
        if (privateJobId) void runtime.service.cancel(privateJobId).catch(() => {})
      }
      input.signal.addEventListener('abort', onAbort, { once: true })
      try {
        const started = runtime.service.start(request)
        privateJobId = String(started.job_id)
        active.set(input.jobId, { requestId, privateJobId })
        let completionSettled = false
        /** @type {unknown} */
        let completionResult
        /** @type {unknown} */
        let completionError
        const completion = Promise.resolve(runtime.service.waitForCompletion(privateJobId)).then(
          (value) => {
            completionResult = value
            completionSettled = true
          },
          (error) => {
            completionError = error
            completionSettled = true
          },
        )
        let lastCheckpoint = ''
        const checkpointStatus = async (/** @type {unknown} */ status) => {
          if (!isRecord(status) || typeof status.state !== 'string') return
          const progress = boundedProgress(status.progress_percent)
          const signature = `${status.state}:${progress}`
          if (signature === lastCheckpoint) return
          lastCheckpoint = signature
          await input.checkpoint(
            `jianying_${status.state}`,
            progress,
            { state: status.state },
          )
        }
        while (!completionSettled) {
          input.signal.throwIfAborted()
          await checkpointStatus(runtime.service.getStatus(privateJobId))
          if (!completionSettled) {
            await Promise.race([
              completion,
              new Promise((resolve) => setTimeout(resolve, progressPollIntervalMs)),
            ])
          }
        }
        await completion
        if (completionError) throw completionError
        // The completion promise can settle between polls. Observe the final
        // live status once so a short verifying phase is not lost from the
        // durable Workbench progress history.
        await checkpointStatus(runtime.service.getStatus(privateJobId))
        const completed = completionResult
        if (!isJianyingDraftJobStatus(completed)) {
          throw new JianyingWorkbenchBridgeError('WORKBENCH_JIANYING_STATUS_INVALID', 502)
        }
        await checkpointStatus(completed)
        if (completed.state !== 'ready_to_open' || !completed.result) {
          const code = completed.error?.code ?? 'JY002_DRAFT_WRITE_FAILED'
          throw new JianyingWorkbenchBridgeError(code, 409)
        }
        publications.set(input.jobId, {
          privateJobId,
          draftId: completed.result.draft_id,
        })
        return {
          draftId: completed.result.draft_id,
          outputFingerprint: completed.result.output_fingerprint,
          summary: '剪映草稿已生成并通过结构校验，等待用户手动打开',
          handoffMode: 'manual_open_required',
          desktopOpened: false,
          ...(privateBatchSummary ? { packagingBatch: privateBatchSummary } : {}),
          ...(writerIdentityTimeline ? { writerProjectionFingerprint: writerIdentityTimeline.revisionFingerprint } : {}),
          ...(writerDegradations.length > 0 ? { writerDegradations: structuredClone(writerDegradations) } : {}),
          draftLabel,
          manualOpenHint: writerDegradations.length > 0
            ? '草稿已生成；当前环境未支持的私有花字或气泡已降级为可编辑富文本，请打开后检查样式。'
            : '请在剪映专业版首页的本地草稿列表中打开该标签。',
        }
      } finally {
        input.signal.removeEventListener('abort', onAbort)
        active.delete(input.jobId)
        runtime.remove(requestId)
      }
    } finally {
      if (typeof setRenderOptions === 'function') setRenderOptions(null, requestId)
      await bgmLease?.release()
      for (const resource of sfxResources.reverse()) {
        await resource.release().catch(() => {})
      }
    }
  }

  return {
    // These are server-only admission inputs for the Workbench coordinator.
    // Do not project them through browser DTOs: the catalog itself remains private.
    desktopProfile: structuredClone(desktopProfile),
    privateCatalogCapabilities: [...new Set(privateCatalogCapabilities)],
    evidencedCapabilities: [...new Set(evidencedCapabilities)],
    promotionReceipts: structuredClone(promotionReceipts),
    batchTextCatalog,
    packagingResourceIndex,
    packagingDesktopBinding: packagingDesktopBinding ? structuredClone(packagingDesktopBinding) : null,
    packagingRecommendationFamilies,
    /** Server-private whole-export preflight used before a Writer owner is claimed. */
    canExportRichTimeline,
    /** Server-private Writer routing preflight; it never returns bindings. */
    async canExportPackagingSelections(/** @type {Record<string, any>} */ richTimeline, projectId = undefined) {
      if (richTimeline?.source?.automaticPackaging !== true) return false
      return Boolean(await resolveTimelinePackagingIndex(richTimeline, projectId ?? richTimeline?.projectId))
    },
    exportDraft,
    /** @param {{projectId: string, jobId: string, draftId?: string}} input */
    async cleanupDraft(input) {
      const entry = active.get(input.jobId)
      if (entry?.privateJobId) await runtime.service.cancel(entry.privateJobId).catch(() => {})
      const published = publications.get(input.jobId)
      let cleaned = false
      if (published?.privateJobId) {
        cleaned = await runtime.service.cleanupPublished(published.privateJobId)
      }
      const draftId = draftIdentifier(input.draftId)
        ? input.draftId
        : `openvideo-${input.jobId}`
      if (!cleaned && typeof runtime.service.cleanupOwned === 'function') {
        await runtime.service.cleanupOwned({
          requestId: `jy003-${input.jobId}`,
          draftId,
        })
      }
      runtime.remove(entry?.requestId ?? `jy003-${input.jobId}`)
      await voiceoverProvider.cleanup({
        projectId: input.projectId,
        jobId: input.jobId,
      })
      active.delete(input.jobId)
      publications.delete(input.jobId)
      return true
    },
    /** @param {{jobId: string, draftId?: string}} input */
    async commitDraft(input) {
      const published = publications.get(input.jobId)
      let released = published?.privateJobId
        ? await runtime.service.releasePublished(published.privateJobId)
        : false
      const draftId = draftIdentifier(input.draftId)
        ? input.draftId
        : `openvideo-${input.jobId}`
      if (!released && typeof runtime.service.releaseOwned === 'function') {
        released = await runtime.service.releaseOwned({
          requestId: `jy003-${input.jobId}`,
          draftId,
        })
      }
      if (released) publications.delete(input.jobId)
      return released
    },
  }
}
