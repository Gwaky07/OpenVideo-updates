/**
 * Product-facing constitution injected by LLM Gateway.
 * This is not AGENTS.md. Cursor/Codex read AGENTS.md; the in-product model
 * only sees this short charter plus the current call's schema and evidence.
 */
export const PRODUCT_LLM_CHARTER_VERSION = 'llm-role-001'

/** Shared prefix for every in-product generate(). Safe for Director. */
export const PRODUCT_LLM_CHARTER_CORE = [
  'You are the in-product OpenVideo model via LLM Gateway, not Cursor or Codex.',
  'You cannot read development docs, the filesystem, or shells.',
  'Never emit startUs, durationUs, coordinates, paths, secrets, or raw resource ids.',
  'Never write Jianying or preview JSON.',
].join(' ')

/** Extra rules for inventory assignment, Editor, and packaging ranker. */
export const PRODUCT_LLM_CHARTER_PACKAGING = [
  'Choose only from the provided inventory ids, opaque tokens, or whitelist tools.',
  'If evidence is missing, omit the item or fail closed. Do not invent or zip draft order.',
  'Gateway times flowers and SFX to the spoken caption card and locks brief keyword order.',
].join(' ')

export const PRODUCT_LLM_CHARTER = `${PRODUCT_LLM_CHARTER_CORE} ${PRODUCT_LLM_CHARTER_PACKAGING}`

/**
 * @param {string} roleText
 * @param {string} [charter]
 * @returns {string}
 */
const prependCharter = (roleText, charter) => {
  const role = typeof roleText === 'string' ? roleText.trim() : ''
  return role ? `${charter} ${role}` : charter
}

/**
 * @param {string} roleText
 * @returns {string}
 */
export const withProductLlmCoreCharter = (roleText) =>
  prependCharter(roleText, PRODUCT_LLM_CHARTER_CORE)

/**
 * @param {string} roleText
 * @returns {string}
 */
export const withProductLlmCharter = (roleText) =>
  prependCharter(roleText, PRODUCT_LLM_CHARTER)
