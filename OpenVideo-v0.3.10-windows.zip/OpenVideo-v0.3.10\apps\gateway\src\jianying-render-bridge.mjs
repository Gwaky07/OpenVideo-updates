import { assertRenderBundleIdentity } from './jianying-render-contracts.mjs'

const sha256 = /^[a-f0-9]{64}$/u
const opaqueIdentifier = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$/u
/** @param {unknown} value @returns {value is Record<string, unknown>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  record(value) && Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')

export class JianyingRenderBridgeError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'JianyingRenderBridgeError'
    this.code = code
    this.status = status
  }
}

/**
 * Converts private probe evidence into the only capability verdicts the product understands.
 * Raw endpoints and paths deliberately do not cross this boundary.
 * @param {unknown} value
 */
export const assessJianyingBackgroundRenderEvidence = (value) => {
  const keys = [
    'cancelObserved', 'collectObserved', 'deployable', 'focusStealObserved',
    'jianyingSignatureFingerprint', 'jianyingVersion', 'licenseReviewed',
    'outputVerified', 'probeArtifactFingerprint', 'profileId', 'progressObserved',
    'repeatSuccesses', 'requiresVisibleUi', 'restartRecoveryObserved',
    'termsReviewed', 'transportKind', 'versionPinned',
  ]
  if (!exactKeys(value, keys)) throw new JianyingRenderBridgeError('JY005_PROBE_EVIDENCE_INVALID', 409)
  const evidence = /** @type {Record<string, any>} */ (value)
  if (
    !['documented_cli', 'signed_local_service', 'version_pinned_ipc', 'desktop_ui_automation', 'none']
      .includes(evidence.transportKind) ||
    typeof evidence.jianyingVersion !== 'string' ||
    !/^[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u.test(evidence.jianyingVersion) ||
    typeof evidence.profileId !== 'string' || !opaqueIdentifier.test(evidence.profileId) ||
    typeof evidence.jianyingSignatureFingerprint !== 'string' ||
    !sha256.test(evidence.jianyingSignatureFingerprint) ||
    typeof evidence.probeArtifactFingerprint !== 'string' ||
    !sha256.test(evidence.probeArtifactFingerprint) ||
    !Number.isSafeInteger(evidence.repeatSuccesses) || evidence.repeatSuccesses < 0 || evidence.repeatSuccesses > 100 ||
    keys.filter((key) => ![
      'jianyingSignatureFingerprint', 'jianyingVersion', 'probeArtifactFingerprint',
      'profileId', 'repeatSuccesses', 'transportKind',
    ].includes(key))
      .some((key) => typeof evidence[key] !== 'boolean')
  ) throw new JianyingRenderBridgeError('JY005_PROBE_EVIDENCE_INVALID', 409)

  const common = {
    backgroundRender: false,
    evidence: structuredClone(evidence),
  }
  if (evidence.requiresVisibleUi || evidence.focusStealObserved || evidence.transportKind === 'desktop_ui_automation') {
    return { ...common, verdict: 'PARTIAL', reasonCode: 'JY005_VISIBLE_AUTOMATION_ONLY' }
  }
  const pass =
    evidence.transportKind !== 'none' &&
    evidence.versionPinned && evidence.deployable && evidence.licenseReviewed && evidence.termsReviewed &&
    evidence.progressObserved && evidence.cancelObserved && evidence.collectObserved &&
    evidence.outputVerified && evidence.restartRecoveryObserved && evidence.repeatSuccesses >= 10
  return pass
    ? { ...common, backgroundRender: true, verdict: 'PASS', reasonCode: null }
    : { ...common, verdict: 'FAIL', reasonCode: 'JY005_SAFE_BACKGROUND_TRANSPORT_UNPROVEN' }
}

/**
 * Creates a transport-neutral bridge. A caller cannot instantiate a live bridge from a
 * PARTIAL/FAIL probe, preventing UI automation from being relabelled as background render.
 * @param {{
 *   assessment: unknown,
 *   compatibility: {backgroundRender: boolean, jianyingSignatureFingerprint: string, jianyingVersion: string, profileId: string},
 *   transport?: Record<string, Function>
 * }} input
 */
export const createJianyingRenderBridge = ({ assessment, compatibility, transport }) => {
  const result = assessJianyingBackgroundRenderEvidence(assessment)
  const evidence = result.evidence
  if (
    result.verdict !== 'PASS' || !record(transport) ||
    compatibility?.backgroundRender !== true ||
    compatibility?.jianyingVersion !== evidence.jianyingVersion ||
    compatibility?.profileId !== evidence.profileId ||
    compatibility?.jianyingSignatureFingerprint !== evidence.jianyingSignatureFingerprint
  ) {
    throw new JianyingRenderBridgeError('JY005_BACKGROUND_RENDER_UNAVAILABLE')
  }
  const liveTransport = /** @type {Record<string, Function>} */ (transport)
  for (const method of ['start', 'status', 'cancel', 'collect', 'cleanup']) {
    if (typeof liveTransport[method] !== 'function') {
      throw new JianyingRenderBridgeError('JY005_RENDER_TRANSPORT_INVALID', 409)
    }
  }
  return Object.freeze({
    assessment: result,
    /** @param {{bundleIdentity: unknown, draftId: string}} input */
    async start(input) {
      const bundleIdentity = assertRenderBundleIdentity(input?.bundleIdentity)
      if (
        bundleIdentity.jianyingVersion !== evidence.jianyingVersion ||
        bundleIdentity.jianyingSignatureFingerprint !== evidence.jianyingSignatureFingerprint ||
        typeof input?.draftId !== 'string' || !opaqueIdentifier.test(input.draftId)
      ) {
        throw new JianyingRenderBridgeError('JY005_RENDER_REQUEST_INVALID', 409)
      }
      return liveTransport.start(structuredClone(input))
    },
    /** @param {string} jobId */
    status: (jobId) => opaqueIdentifier.test(jobId)
      ? liveTransport.status(jobId)
      : Promise.reject(new JianyingRenderBridgeError('JY005_RENDER_JOB_ID_INVALID', 409)),
    /** @param {string} jobId */
    cancel: (jobId) => opaqueIdentifier.test(jobId)
      ? liveTransport.cancel(jobId)
      : Promise.reject(new JianyingRenderBridgeError('JY005_RENDER_JOB_ID_INVALID', 409)),
    /** @param {string} jobId */
    collect: (jobId) => opaqueIdentifier.test(jobId)
      ? liveTransport.collect(jobId)
      : Promise.reject(new JianyingRenderBridgeError('JY005_RENDER_JOB_ID_INVALID', 409)),
    /** @param {string} jobId */
    cleanup: (jobId) => opaqueIdentifier.test(jobId)
      ? liveTransport.cleanup(jobId)
      : Promise.reject(new JianyingRenderBridgeError('JY005_RENDER_JOB_ID_INVALID', 409)),
  })
}
