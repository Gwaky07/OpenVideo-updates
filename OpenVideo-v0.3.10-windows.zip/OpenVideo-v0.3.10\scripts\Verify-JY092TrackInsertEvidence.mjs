import { createHash } from 'node:crypto'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { assertOwnedJY092MediaRoot } from '../apps/gateway/src/jianying-track-insert-evidence.mjs'

const requiredFlags = ['--opened', '--edited', '--saved', '--reopened']

const main = async () => {
  if (!requiredFlags.every((flag) => process.argv.includes(flag))) throw new Error('JY092_MANUAL_EVIDENCE_REQUIRED')
  const runtimeRoot = loadLocalRuntimeConfig().dataRoot
  const evidenceRoot = path.join(runtimeRoot, 'evidence', 'jy092-track-insert')
  const lease = JSON.parse(await readFile(path.join(evidenceRoot, 'pending.json'), 'utf8'))
  const manifest = JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (
    lease?.schema_version !== 1 || lease.profile_id !== 'jianying-11-2-provisional' ||
    desktop?.profileId !== lease.profile_id || desktop?.version !== lease.app_version ||
    path.resolve(desktop.draftRoot) !== path.resolve(lease.draft_root) ||
    !/^OpenVideo-JY092-track-insert-[0-9]+$/u.test(lease.draft_id) ||
    !Array.isArray(lease.expected_track_names) || lease.expected_track_names.join('|') !== 'video-primary|voiceover-primary'
  ) throw new Error('JY092_EVIDENCE_BINDING_REQUIRED')
  const draftContent = path.join(desktop.draftRoot, lease.draft_id, 'draft_content.json')
  const encrypted = await readFile(draftContent)
  const postFingerprint = createHash('sha256').update(encrypted).digest('hex')
  if (postFingerprint === lease.pre_open_fingerprint) throw new Error('JY092_DRAFT_UNCHANGED')
  const temporaryRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy092-verify-'))
  try {
    const plaintextPath = path.join(temporaryRoot, 'draft_content.json')
    const decryptMeta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
      .ensurePlaintextFile(draftContent, plaintextPath)
    if (decryptMeta.scheme !== 'encrypt_v2' && decryptMeta.decryptedFrom !== 'encrypt_v2') throw new Error('JY092_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plaintextPath, 'utf8'))
    const tracks = Array.isArray(content.tracks) ? content.tracks : []
    if (tracks.length !== 2 || tracks.map((track) => track?.name).join('|') !== lease.expected_track_names.join('|')) {
      throw new Error('JY092_TRACK_ORDER_MISMATCH')
    }
    if (tracks[0]?.type !== 'video' || tracks[1]?.type !== 'audio' || tracks[1]?.segments?.length !== 1) {
      throw new Error('JY092_TRACK_STRUCTURE_MISMATCH')
    }
    const volume = tracks[1].segments[0]?.volume
    if (typeof volume !== 'number' || !Number.isFinite(volume) || volume >= lease.expected_auxiliary_volume || volume < 0.45 || volume > 0.55) {
      throw new Error('JY092_AUXILIARY_EDIT_MISMATCH')
    }
    const ownedMediaRoot = await assertOwnedJY092MediaRoot(lease.media_root)
    await rm(ownedMediaRoot, { recursive: true, force: true })
    try {
      await readFile(path.join(lease.media_root, 'voiceover.wav'))
      throw new Error('JY092_TEMP_MEDIA_NOT_CLEANED')
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
    await securePrivateRuntimeRoot(evidenceRoot)
    await writeFile(path.join(evidenceRoot, 'post-save.json'), `${JSON.stringify({
      schema_version: 2, draft_id: lease.draft_id, manual_evidence_verified: true,
      evidence_binding: createHash('sha256').update(`${lease.draft_id}:${lease.pre_open_fingerprint}`).digest('hex'),
      profile_id: desktop.profileId, app_version: desktop.version,
      scheme: 'encrypt_v2', track_names: lease.expected_track_names, auxiliary_track_index: 1,
      auxiliary_segment_count: 1, auxiliary_volume: volume, pre_open_fingerprint: lease.pre_open_fingerprint,
      post_save_fingerprint: postFingerprint,
      observed: { track_order: true, auxiliary_edit: true, encrypted_persistence: true, temporary_media_cleaned: true },
      manual_attestation: { opened: true, edited: true, saved: true, reopened: true },
      verified_at: new Date().toISOString(),
    })}\n`, { encoding: 'utf8', mode: 0o600 })
    await rm(path.join(evidenceRoot, 'pending.json'), { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, profile: desktop.profileId, version: desktop.version, track_order_verified: true, auxiliary_volume: volume, scheme: 'encrypt_v2', temporary_media_cleaned: true })}\n`)
  } finally {
    await rm(temporaryRoot, { recursive: true, force: true })
  }
}

main().catch((error) => {
  process.stdout.write(`${JSON.stringify({ ok: false, code: error?.message ?? 'JY092_EVIDENCE_FAILED' })}\n`)
  process.exitCode = 1
})
