import {
  EditorCapabilityRegistryError,
  createEditorCapabilityRegistry,
} from './editor-capability-registry.mjs'
import { spanZeroStartBgmToTimeline } from './rich-timeline-bgm-span.mjs'
import { assertRichTimeline } from './rich-timeline-contracts.mjs'

export class RichTimelinePreviewProjectionError extends Error {
  /** @param {string} code @param {number} [status] @param {string | null} [capabilityId] */
  constructor(code, status = 409, capabilityId = null) {
    super(code)
    this.name = 'RichTimelinePreviewProjectionError'
    this.code = code
    this.status = status
    this.capabilityId = capabilityId
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

const previewDegradationCodes = Object.freeze({
  'transition.dissolve': 'DISSOLVE_PREVIEW_DEGRADED',
  'transform.scale': 'TRANSFORM_SCALE_PREVIEW_DEGRADED',
  'transform.position': 'TRANSFORM_POSITION_PREVIEW_DEGRADED',
  opacity: 'OPACITY_PREVIEW_DEGRADED',
})

const privateTextCapabilities = new Set([
  'text.flower.private',
  'text.bubble.private',
])

const jianyingOnlyPreviewCapabilities = Object.freeze({
  'sticker.named': 'STICKER_PREVIEW_UNSUPPORTED',
  'effect.video.named': 'EFFECT_PREVIEW_UNSUPPORTED',
  'text.flower.private': 'FLOWER_TEXT_PREVIEW_DEGRADED',
  'text.bubble.private': 'BUBBLE_TEXT_PREVIEW_DEGRADED',
  'audio.sfx.local': 'SFX_PREVIEW_DEGRADED',
})

/**
 * Project finalized RichTimeline into opaque Preview export DTO.
 * Preview writer may mark SVF-approximated packaging as degraded; never leaks paths.
 * @param {unknown} timeline
 * @param {{capabilityRegistry?: ReturnType<typeof createEditorCapabilityRegistry>}} [options]
 */
export const projectRichTimelineToPreviewExport = (timeline, options = {}) => {
  if (!isRecord(timeline) || timeline.status !== 'finalized') {
    throw new RichTimelinePreviewProjectionError('VID004_TIMELINE_NOT_FINALIZED')
  }
  assertRichTimeline(timeline)
  timeline = spanZeroStartBgmToTimeline(timeline)

  const registry = options.capabilityRegistry ?? createEditorCapabilityRegistry()
  /** @type {string[]} */
  const degradationCodes = []
  /** @param {string} capabilityId */
  const gate = (capabilityId) => {
    try {
      const entry = registry.assertWriterCapability(capabilityId, 'preview')
      const code = entry.targets.preview.degradationCode
      if (typeof code === 'string' && code.length > 0 && !degradationCodes.includes(code)) {
        degradationCodes.push(code)
      } else if (
        entry.targets.preview.status === 'degraded' &&
        Object.hasOwn(previewDegradationCodes, capabilityId)
      ) {
        const degradedCode =
          previewDegradationCodes[/** @type {keyof typeof previewDegradationCodes} */ (capabilityId)]
        if (!degradationCodes.includes(degradedCode)) {
          degradationCodes.push(degradedCode)
        }
      }
      return entry
    } catch (error) {
      if (error instanceof EditorCapabilityRegistryError) {
        throw new RichTimelinePreviewProjectionError(
          'VID004_CAPABILITY_UNSUPPORTED',
          error.status,
          error.capabilityId,
        )
      }
      throw error
    }
  }

  /** @param {string} capabilityId */
  const previewCapability = (capabilityId) =>
    privateTextCapabilities.has(capabilityId) ? 'text.rich' : capabilityId

  const previewIrrelevantRequirements = new Set(['track.insert', 'track.insert_many'])
  for (const requirement of timeline.capabilityRequirements ?? []) {
    const capabilityId = requirement.capabilityId
    if (previewIrrelevantRequirements.has(capabilityId)) continue
    if (Object.hasOwn(jianyingOnlyPreviewCapabilities, capabilityId)) {
      const code = jianyingOnlyPreviewCapabilities[
        /** @type {keyof typeof jianyingOnlyPreviewCapabilities} */ (capabilityId)
      ]
      if (!degradationCodes.includes(code)) degradationCodes.push(code)
      if (!privateTextCapabilities.has(capabilityId)) continue
    }
    gate(previewCapability(capabilityId))
  }

  const videoTrack = timeline.tracks.find(
    (/** @type {Record<string, any>} */ track) =>
      track.kind === 'video' && track.role === 'primary' && track.enabled !== false,
  )
  if (!videoTrack || !Array.isArray(videoTrack.segments) || videoTrack.segments.length === 0) {
    throw new RichTimelinePreviewProjectionError('VID004_PRIMARY_VIDEO_MISSING')
  }

  const voiceoverTrack = timeline.tracks.find(
    (/** @type {Record<string, any>} */ track) =>
      track.kind === 'audio' && track.role === 'voiceover' && track.enabled !== false,
  )
  const voiceoverSegments = Array.isArray(voiceoverTrack?.segments)
    ? [...voiceoverTrack.segments].sort(
        (left, right) => left.targetRange.startUs - right.targetRange.startUs,
      )
    : []
  /** @type {Record<string, any>[]} */
  const selections = []
  /** @type {string[]} */
  const voiceoverAudioTokens = []
  /** @type {Record<string, any>[]} */
  const voiceoverGuide = []
  /** @type {Record<string, any>[]} */
  const packagingVideo = []

  for (let index = 0; index < videoTrack.segments.length; index += 1) {
    const segment = videoTrack.segments[index]

    const transitionOut = segment.transitionOut
    if (
      transitionOut &&
      transitionOut.capabilityId !== 'transition.cut' &&
      transitionOut.capabilityId !== 'transition.none'
    ) {
      gate(transitionOut.capabilityId)
    }
    for (const keyframe of segment.keyframes ?? []) {
      gate(keyframe.capabilityId)
    }

    selections.push({
      candidateId: segment.audit?.candidateId ?? `candidate-${index + 1}`,
      startUs: segment.sourceRange.startUs,
      durationUs: segment.sourceRange.durationUs,
      targetStartUs: segment.targetRange.startUs,
      targetDurationUs: segment.targetRange.durationUs,
    })
    packagingVideo.push({
      segmentId: segment.segmentId,
      transitionOut:
        transitionOut &&
        transitionOut.capabilityId !== 'transition.cut' &&
        transitionOut.capabilityId !== 'transition.none'
          ? {
              capabilityId: transitionOut.capabilityId,
              durationUs: transitionOut.durationUs,
              parameters: structuredClone(transitionOut.parameters ?? {}),
            }
          : null,
      keyframes: (segment.keyframes ?? []).map((/** @type {Record<string, any>} */ keyframe) => ({
        capabilityId: keyframe.capabilityId,
        offsetUs: keyframe.offsetUs,
        value: structuredClone(keyframe.value),
        interpolation: keyframe.interpolation,
      })),
    })
  }
  for (let index = 0; index < voiceoverSegments.length; index += 1) {
    const voiceover = voiceoverSegments[index]
    const audioToken =
      voiceover.source?.kind === 'generated'
        ? voiceover.source.generatedAudioId
        : voiceover.source?.kind === 'asset'
          ? voiceover.source.reference?.assetId
          : null
    if (typeof audioToken !== 'string' || audioToken.length === 0) {
      throw new RichTimelinePreviewProjectionError('JY002_VOICEOVER_AUDIO_MISSING')
    }
    voiceoverAudioTokens.push(audioToken)
    voiceoverGuide.push({
      sentenceId: `editor-${index + 1}`,
      text: typeof voiceover.text === 'string' && voiceover.text.trim()
        ? voiceover.text.trim().slice(0, 500)
        : `旁白 ${index + 1}`,
      targetStartUs: voiceover.targetRange.startUs,
      targetDurationUs: voiceover.targetRange.durationUs,
    })
  }

  /** @type {string[]} */
  const captionLines = []
  /** @type {Record<string, any>[]} */
  const captionSegments = []
  /** @type {Record<string, any>[]} */
  const titleSegments = []
  /** @type {Record<string, any>[]} */
  const richTextSegments = []
  /** @type {Record<string, any>[]} */
  const sfxSegments = []
  /** @type {Record<string, any> | null} */
  let bgm = null
  /** @type {'default' | 'bottom_safe'} */
  let subtitleStyle = 'default'
  let captionsEnabled = false

  for (const track of timeline.tracks) {
    if (track.enabled === false) continue
    if (track.kind === 'caption') {
      for (const segment of track.segments ?? []) {
        gate(segment.capabilityId)
        captionsEnabled = true
        if (segment.capabilityId === 'caption.bottom_safe') subtitleStyle = 'bottom_safe'
        const text = typeof segment.text === 'string' ? segment.text.trim().slice(0, 500) : ''
        if (text) captionLines.push(text)
        captionSegments.push({
          segmentId: segment.segmentId,
          text: segment.text,
          styleToken: segment.styleToken,
          targetStartUs: segment.targetRange.startUs,
          targetDurationUs: segment.targetRange.durationUs,
          capabilityId: segment.capabilityId,
        })
      }
    }
    if (track.kind === 'title') {
      for (const segment of track.segments ?? []) {
        const capabilityId = previewCapability(segment.capabilityId)
        gate(capabilityId)
        const entry = {
          segmentId: segment.segmentId,
          text: segment.text,
          styleToken: segment.styleToken,
          ...(segment.layout ? { layout: structuredClone(segment.layout) } : {}),
          targetStartUs: segment.targetRange.startUs,
          targetDurationUs: segment.targetRange.durationUs,
          capabilityId,
        }
        if (segment.kind === 'rich_text') {
          richTextSegments.push(entry)
        } else {
          titleSegments.push(entry)
          if (typeof segment.text === 'string' && segment.text.trim()) {
            captionLines.unshift(`【片头】${segment.text.trim().slice(0, 160)}`)
          }
        }
      }
    }
    if (track.kind === 'audio' && track.role === 'sfx') {
      if (!degradationCodes.includes('SFX_PREVIEW_DEGRADED')) {
        degradationCodes.push('SFX_PREVIEW_DEGRADED')
      }
      continue
    }
    if (track.kind === 'audio' && track.role === 'bgm') {
      for (const segment of track.segments ?? []) {
        gate(segment.capabilityId)
        /** @type {'generated' | 'asset' | 'authorization' | null} */
        let sourceKind = null
        /** @type {string | null} */
        let audioToken = null
        if (segment.source?.kind === 'generated') {
          sourceKind = 'generated'
          audioToken = segment.source.generatedAudioId
        } else if (segment.source?.kind === 'asset') {
          if (typeof segment.source.reference?.assetId === 'string') {
            sourceKind = 'asset'
            audioToken = segment.source.reference.assetId
          } else if (typeof segment.source.reference?.authorizationId === 'string') {
            sourceKind = 'authorization'
            audioToken = segment.source.reference.authorizationId
          }
        }
        if (typeof audioToken !== 'string' || !sourceKind) {
          throw new RichTimelinePreviewProjectionError('VID004_BGM_AUDIO_MISSING')
        }
        if (bgm) throw new RichTimelinePreviewProjectionError('VID004_BGM_AMBIGUOUS')
        if (
          segment.targetRange.startUs !== 0 ||
          segment.targetRange.durationUs !== timeline.durationUs
        ) {
          throw new RichTimelinePreviewProjectionError(
            'VID004_BGM_RANGE_UNSUPPORTED',
            409,
            segment.capabilityId,
          )
        }
        bgm = {
          segmentId: segment.segmentId,
          audioToken,
          sourceKind,
          capabilityId: segment.capabilityId,
          volume: segment.volume,
          targetStartUs: segment.targetRange.startUs,
          targetDurationUs: segment.targetRange.durationUs,
        }
      }
    }
  }

  for (let index = 0; index < Math.min(captionSegments.length, voiceoverGuide.length); index += 1) {
    const text = typeof captionSegments[index].text === 'string'
      ? captionSegments[index].text.trim().slice(0, 500)
      : ''
    if (text) voiceoverGuide[index].text = text
  }

  const script = captionLines.length > 0
    ? captionLines.join('\n')
    : voiceoverGuide.map((segment) => segment.text).join('\n')

  const packaging = {
    schemaVersion: 1,
    kind: 'preview_timeline_packaging',
    timelineContentFingerprint: timeline.contentFingerprint,
    timelineRevisionFingerprint: timeline.revisionFingerprint,
    durationUs: timeline.durationUs,
    orientation: timeline.orientation,
    subtitleStyle,
    captionsEnabled,
    video: packagingVideo,
    captionSegments,
    titleSegments,
    richTextSegments,
    sfxSegments,
    bgm,
    voiceoverAudioTokens,
    voiceoverGuide,
    degradationCodes,
  }

  const leakProbe = JSON.stringify({
    selections,
    packaging: {
      ...packaging,
      captionSegments: packaging.captionSegments.map(({ text: _text, ...rest }) => rest),
      titleSegments: packaging.titleSegments.map(({ text: _text, ...rest }) => rest),
      richTextSegments: packaging.richTextSegments.map(({ text: _text, ...rest }) => rest),
      voiceoverGuide: packaging.voiceoverGuide.map(({ text: _text, ...rest }) => rest),
    },
  })
  if (
    /[A-Za-z]:[\\/]/u.test(leakProbe) ||
    leakProbe.includes('file:') ||
    /\/(?:Users|home|opt)\//u.test(leakProbe)
  ) {
    throw new RichTimelinePreviewProjectionError('VID004_PRIVATE_PATH_LEAK')
  }

  return {
    selections,
    packaging,
    script,
    voiceoverAudioTokens,
    durationSeconds: timeline.durationUs / 1_000_000,
    orientation: timeline.orientation,
    degradationCodes,
  }
}
