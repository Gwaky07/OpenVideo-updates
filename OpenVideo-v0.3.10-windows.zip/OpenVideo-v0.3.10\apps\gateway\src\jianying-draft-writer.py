import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from copy import deepcopy
from contextlib import contextmanager
from pathlib import Path

if os.name == "nt":
    import msvcrt
else:
    import fcntl

MAX_SEGMENTS = 100
MAX_TITLE_SEGMENTS = 96
MAX_SFX_SEGMENTS = 96
MAX_DURATION_US = 86_400_000_000
MAX_DIMENSION = 16_384
MAX_MANIFEST_BYTES = 1_048_576
MAX_BGM_BYTES = 512 * 1024 * 1024
BGM_EXTENSIONS = {".aac", ".flac", ".m4a", ".mp3", ".ogg", ".wav"}
MINIMAL_DRAFT_COVER_JPEG = bytes([
    0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
    0x01, 0x01, 0x00, 0x48, 0x00, 0x48, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
    0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
    0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
    0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
    0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
    0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
    0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
    0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14, 0x10, 0x01, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00,
    0x3F, 0x00, 0x2A, 0xFF, 0xD9,
])


def emit(payload):
    sys.stdout.buffer.write(
        json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    )


def fail(code, diagnostic=None):
    payload = {"ok": False, "code": code}
    if diagnostic is not None:
        payload["diagnostic"] = diagnostic
    emit(payload)
    raise SystemExit(0)


def create_optional_tracks(script, optional_track_specs, optional_track_names, profile, capability):
    """Create optional timeline tracks through the profile-bound insertion path."""
    if profile in {"jianying-11-1-provisional", "jianying-11-2-provisional"} and capability == "track.insert":
        if len(optional_track_specs) != 1 or len(optional_track_names) != 1:
            fail("JY092_TRACK_INSERTION_STRUCTURE_INVALID")
        return {optional_track_names[0]: script.insert_track(optional_track_specs[0], at_index=1)}
    if profile == "jianying-11-1-provisional" and capability == "track.insert_many":
        inserted_tracks = script.insert_tracks(optional_track_specs, at_index=1) if optional_track_specs else ()
        return dict(zip(optional_track_names, inserted_tracks))
    if profile is not None and capability is not None:
        fail("JY092_TRACK_INSERTION_PROFILE_INVALID")
    return {
        track_name: script.append_track(track_spec)
        for track_name, track_spec in zip(optional_track_names, optional_track_specs)
    }


def require_keys(value, keys):
    return isinstance(value, dict) and set(value.keys()) == set(keys)


def valid_owned_draft_payload(value, commit):
    if not isinstance(value, dict):
        return False
    required = {"action", "draft_root", "request_id", "draft_id"}
    allowed = required | ({"draft_label"} if commit else set())
    keys = set(value.keys())
    return required.issubset(keys) and keys.issubset(allowed)


def safe_name(value):
    return (
        isinstance(value, str)
        and 0 < len(value) <= 180
        and value == value.strip()
        and all(ord(character) >= 32 for character in value)
        and "/" not in value
        and "\\" not in value
        and ":" not in value
    )


def safe_draft_label(value):
    return (
        isinstance(value, str)
        and 0 < len(value) <= 100
        and value == value.strip()
        and all(ord(character) >= 32 for character in value)
        and "/" not in value
        and "\\" not in value
        and re.match(r"^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)", value, re.IGNORECASE) is None
    )


def resolve_audio_effect_meta(draft, resource_id):
    if not isinstance(resource_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", resource_id):
        fail("JY067_AUDIO_EFFECT_UNRESOLVED")
    for enum_name in ("AudioSceneEffectType", "ToneEffectType", "SpeechToSongType"):
        enum_type = getattr(draft, enum_name, None)
        if enum_type is None:
            continue
        for member in enum_type:
            if getattr(getattr(member, "value", None), "resource_id", None) == resource_id:
                return member
    fail("JY067_AUDIO_EFFECT_UNRESOLVED")


def resolve_child(root, name):
    unresolved = root / name
    try:
        attributes = getattr(os.lstat(unresolved), "st_file_attributes", 0)
        if attributes & 0x400:
            fail("JY002_PATH_PERMISSION_DENIED")
    except FileNotFoundError:
        pass
    candidate = (root / name).resolve()
    if candidate.parent != root.resolve():
        fail("JY002_PATH_PERMISSION_DENIED")
    return candidate


def reject_reparse(path):
    try:
        attributes = getattr(os.lstat(path), "st_file_attributes", 0)
    except OSError:
        fail("JY002_PATH_PERMISSION_DENIED")
    if attributes & 0x400:
        fail("JY002_PATH_PERMISSION_DENIED")


def write_json_atomic(owner_path, owner):
    temporary_path = owner_path.with_name(
        f"{owner_path.name}.{os.getpid()}.tmp"
    )
    temporary_path.write_text(
        json.dumps(owner, separators=(",", ":")),
        encoding="utf-8",
    )
    os.replace(temporary_path, owner_path)


def write_owner(path, owner):
    write_json_atomic(path / ".openvideo-owner.json", owner)


def build_jianying_media_bin_videos(content, now_s, now_us):
    materials = content.get("materials")
    videos = materials.get("videos", []) if isinstance(materials, dict) else []
    if not isinstance(videos, list):
        fail("JY002_DRAFT_STRUCTURE_INVALID")

    indexed = []
    for video in videos:
        if not isinstance(video, dict):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        material_id = video.get("id")
        path = video.get("path")
        duration = video.get("duration")
        width = video.get("width")
        height = video.get("height")
        material_type = video.get("type")
        if (
            not isinstance(material_id, str)
            or not material_id
            or not isinstance(path, str)
            or not path
            or not isinstance(duration, int)
            or duration <= 0
            or not isinstance(width, int)
            or width <= 0
            or not isinstance(height, int)
            or height <= 0
            or material_type not in {"video", "photo"}
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")

        local_material_id = video.get("local_material_id")
        if not isinstance(local_material_id, str) or not local_material_id:
            try:
                local_material_id = str(uuid.UUID(hex=material_id))
            except ValueError:
                local_material_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"openvideo-media:{material_id}"))
            video["local_material_id"] = local_material_id

        label = video.get("material_name")
        if not isinstance(label, str) or not label:
            label = Path(path).name
        indexed.append({
            "create_time": now_s,
            "duration": duration,
            "extra_info": label,
            "file_Path": path.replace("\\", "/"),
            "height": height,
            "id": local_material_id,
            "import_time": now_s,
            "import_time_ms": now_us,
            "md5": "",
            "metetype": material_type,
            "roughcut_time_range": {"duration": duration, "start": 0},
            "sub_time_range": {"duration": -1, "start": -1},
            "type": 0,
            "width": width,
        })
    return indexed


def validate_jianying_media_bin_metadata(draft_path, content):
    try:
        meta = json.loads((draft_path / "draft_meta_info.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    materials = content.get("materials")
    videos = materials.get("videos", []) if isinstance(materials, dict) else None
    draft_materials = meta.get("draft_materials") if isinstance(meta, dict) else None
    if not isinstance(videos, list) or not isinstance(draft_materials, list):
        return False
    video_groups = [group for group in draft_materials if isinstance(group, dict) and group.get("type") == 0]
    if len(video_groups) != 1 or not isinstance(video_groups[0].get("value"), list):
        return False
    indexed = video_groups[0]["value"]
    if len(indexed) != len(videos):
        return False
    for video, item in zip(videos, indexed):
        if not isinstance(video, dict) or not isinstance(item, dict):
            return False
        if (
            item.get("id") != video.get("local_material_id")
            or item.get("file_Path") != str(video.get("path", "")).replace("\\", "/")
            or item.get("duration") != video.get("duration")
            or item.get("width") != video.get("width")
            or item.get("height") != video.get("height")
            or item.get("metetype") != video.get("type")
            or item.get("type") != 0
        ):
            return False
    return True


def ensure_jianying_homepage_metadata(draft_path, draft_root, draft_name, content=None):
    now_ms = int(time.time() * 1000)
    now_us = now_ms * 1000
    now_s = now_ms // 1000
    content_path = draft_path / "draft_content.json"
    if content is None:
        content = json.loads(content_path.read_text(encoding="utf-8"))
    media_bin_videos = build_jianying_media_bin_videos(content, now_s, now_us)
    if not isinstance(content.get("create_time"), int) or content.get("create_time") <= 0:
        content["create_time"] = now_ms
    if not isinstance(content.get("update_time"), int) or content.get("update_time") < content["create_time"]:
        content["update_time"] = now_ms
    content_path.write_text(
        json.dumps(content, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )

    meta_path = draft_path / "draft_meta_info.json"
    meta = {}
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        if not isinstance(meta, dict):
            meta = {}
    except (OSError, json.JSONDecodeError):
        meta = {}
    meta.update({
        "draft_name": draft_name,
        "draft_fold_path": str(draft_path).replace("\\", "/"),
        "draft_root_path": str(draft_root),
        "draft_is_invisible": False,
        "tm_draft_create": meta.get("tm_draft_create") if isinstance(meta.get("tm_draft_create"), int) and meta.get("tm_draft_create") > 0 else now_us,
        "tm_draft_modified": now_us,
        "tm_draft_removed": 0,
        "tm_duration": content.get("duration", 0) if isinstance(content.get("duration", 0), int) else 0,
    })
    if not isinstance(meta.get("draft_id"), str) or len(meta.get("draft_id", "")) == 0:
        meta["draft_id"] = str(uuid.uuid4()).upper()
    if not isinstance(meta.get("draft_cover"), str) or len(meta.get("draft_cover")) == 0:
        meta["draft_cover"] = "draft_cover.jpg"
    draft_materials = meta.get("draft_materials")
    if not isinstance(draft_materials, list):
        draft_materials = []
    draft_materials = [
        group for group in draft_materials
        if isinstance(group, dict) and group.get("type") != 0
    ]
    meta["draft_materials"] = [{"type": 0, "value": media_bin_videos}, *draft_materials]
    write_json_atomic(meta_path, meta)
    if not validate_jianying_media_bin_metadata(draft_path, content):
        fail("JY002_DRAFT_STRUCTURE_INVALID")

    cover_name = meta.get("draft_cover")
    if isinstance(cover_name, str) and safe_name(cover_name) and cover_name.lower().endswith((".jpg", ".jpeg")):
        cover_path = draft_path / cover_name
        if not cover_path.exists() or cover_path.stat().st_size == 0:
            temporary_path = cover_path.with_name(f"{cover_path.name}.{os.getpid()}.tmp")
            temporary_path.write_bytes(MINIMAL_DRAFT_COVER_JPEG)
            os.replace(temporary_path, cover_path)


def repair_jianying_homepage_draft_name(draft_path, draft_name):
    if not safe_draft_label(draft_name):
        fail("JY002_PATH_PERMISSION_DENIED")
    meta_path = draft_path / "draft_meta_info.json"
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not isinstance(meta, dict):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    meta["draft_name"] = draft_name
    meta["tm_draft_modified"] = int(time.time() * 1000) * 1000
    write_json_atomic(meta_path, meta)
    try:
        persisted = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not isinstance(persisted, dict) or persisted.get("draft_name") != draft_name:
        fail("JY002_DRAFT_STRUCTURE_INVALID")


def staging_owner_path(staging_root, draft_id):
    return staging_root / f".{draft_id}.openvideo-owner.json"


@contextmanager
def draft_lock(root, draft_id):
    lock_root = root / ".openvideo-locks"
    lock_root.mkdir(parents=True, exist_ok=True)
    reject_reparse(lock_root)
    lock_path = resolve_child(lock_root, f"{draft_id}.lock")
    with open(lock_path, "a+b") as handle:
        reject_reparse(lock_path)
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
            os.fsync(handle.fileno())
        handle.seek(0)
        if os.name == "nt":
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def valid_owner(owner, payload, phases):
    bundle_fingerprint = payload.get("bundle_fingerprint")
    if bundle_fingerprint is not None and not (
        isinstance(bundle_fingerprint, str)
        and re.fullmatch(r"[a-f0-9]{64}", bundle_fingerprint)
    ):
        return False
    bundle_valid = (
        (bundle_fingerprint is None and "bundle_fingerprint" not in owner)
        or (isinstance(bundle_fingerprint, str) and re.fullmatch(r"[a-f0-9]{64}", bundle_fingerprint) and owner.get("bundle_fingerprint") == bundle_fingerprint)
    )
    return (
        isinstance(owner, dict)
        and set(owner.keys()).issubset({
            "schema_version", "owner_id", "request_id", "draft_id",
            "output_fingerprint", "phase", "bundle_fingerprint",
        })
        and set(owner.keys()) >= {
            "schema_version", "owner_id", "request_id", "draft_id",
            "output_fingerprint", "phase",
        }
        and owner["schema_version"] == 2
        and owner["owner_id"] == payload["owner_id"]
        and owner["request_id"] == payload["request_id"]
        and owner["draft_id"] == payload["draft_id"]
        and owner["output_fingerprint"] == payload["output_fingerprint"]
        and owner["phase"] in phases
        and bundle_valid
    )


def valid_bundle_fingerprint(value):
    return value is None or (
        isinstance(value, str)
        and re.fullmatch(r"[a-f0-9]{64}", value)
    )


def load_manifest():
    try:
        line = sys.stdin.buffer.readline(MAX_MANIFEST_BYTES + 1)
        if not line or len(line) > MAX_MANIFEST_BYTES or not line.endswith(b"\n"):
            fail("JY002_DRAFT_WRITE_FAILED")
        payload = json.loads(line[:-1].decode("utf-8"))
    except SystemExit:
        raise
    except Exception:
        fail("JY002_DRAFT_WRITE_FAILED")
    if not isinstance(payload, dict):
        fail("JY002_DRAFT_WRITE_FAILED")
    return payload


def validate_segment(segment, keys):
    if not isinstance(segment, dict) or any(key not in segment for key in keys):
        fail("JY002_DRAFT_WRITE_FAILED")
    for key in [item for item in keys if item.endswith("_us")]:
        minimum = 1 if key.endswith("_duration_us") else 0
        if not isinstance(segment[key], int) or segment[key] < minimum:
            fail("JY002_DRAFT_WRITE_FAILED")
    path = segment.get("path")
    if not isinstance(path, str) or not os.path.isabs(path) or not os.path.isfile(path):
        fail("JY002_MATERIAL_AUTHORIZATION_EXPIRED", {"stage": "validate_media", "exception_type": "missing_primary_media"})


def validate_segment_count(video_segments, voiceover_segments):
    if (
        not isinstance(video_segments, list)
        or not isinstance(voiceover_segments, list)
        or len(video_segments) == 0
        or len(video_segments) > MAX_SEGMENTS
        or len(voiceover_segments) not in [0, len(video_segments)]
    ):
        fail("JY002_DRAFT_STRUCTURE_INVALID")


def validate_packaging_segment(segment):
    base_keys = {"resource_id", "target_start_us", "target_duration_us"}
    if (
        not isinstance(segment, dict)
        or set(segment.keys()) not in (base_keys, base_keys | {"effect_id"})
        or not isinstance(segment["resource_id"], str)
        or not segment["resource_id"]
        or len(segment["resource_id"]) > 200
        or ("effect_id" in segment and (
            not isinstance(segment["effect_id"], str)
            or re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["effect_id"]) is None
        ))
        or not isinstance(segment["target_start_us"], int)
        or isinstance(segment["target_start_us"], bool)
        or segment["target_start_us"] < 0
        or not isinstance(segment["target_duration_us"], int)
        or isinstance(segment["target_duration_us"], bool)
        or segment["target_duration_us"] <= 0
    ):
        fail("JY002_DRAFT_STRUCTURE_INVALID")


def validate_sticker_segment(segment):
    base_keys = {"resource_id", "target_start_us", "target_duration_us"}
    keyed_keys = base_keys | {"keyframes"}
    if not isinstance(segment, dict) or set(segment.keys()) not in (base_keys, keyed_keys):
        fail("JY113_STICKER_KEYFRAME_STRUCTURE_INVALID")
    validate_packaging_segment({key: segment[key] for key in base_keys})
    keyframes = segment.get("keyframes", [])
    if not isinstance(keyframes, list):
        fail("JY113_STICKER_KEYFRAME_STRUCTURE_INVALID")
    previous_offset = -1
    for keyframe in keyframes:
        if (
            not isinstance(keyframe, dict)
            or set(keyframe.keys()) != {"capability_id", "offset_us", "value", "interpolation"}
            or keyframe.get("capability_id") != "transform.sticker.keyframe"
            or not isinstance(keyframe.get("offset_us"), int)
            or isinstance(keyframe.get("offset_us"), bool)
            or keyframe["offset_us"] < 0
            or keyframe["offset_us"] > segment["target_duration_us"]
            or keyframe["offset_us"] <= previous_offset
            or not isinstance(keyframe.get("value"), (int, float))
            or isinstance(keyframe.get("value"), bool)
            or not 0.1 <= float(keyframe["value"]) <= 10
            or keyframe.get("interpolation") != "linear"
        ):
            fail("JY113_STICKER_KEYFRAME_STRUCTURE_INVALID")
        previous_offset = keyframe["offset_us"]


def validate_filter_segment(segment):
    if (
        not isinstance(segment, dict)
        or set(segment.keys())
        != {"resource_id", "capability_id", "target_start_us", "target_duration_us", "intensity"}
        or segment["capability_id"] not in {"filter.video.named", "filter.video.track_named"}
        or not isinstance(segment["resource_id"], str)
        or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["resource_id"])
        or not isinstance(segment["target_start_us"], int)
        or isinstance(segment["target_start_us"], bool)
        or segment["target_start_us"] < 0
        or not isinstance(segment["target_duration_us"], int)
        or isinstance(segment["target_duration_us"], bool)
        or segment["target_duration_us"] <= 0
        or not isinstance(segment["intensity"], (int, float))
        or isinstance(segment["intensity"], bool)
        or not 0 <= float(segment["intensity"]) <= 100
    ):
        fail("JY016_FILTER_STRUCTURE_INVALID")


def validate_duration(value):
    if not isinstance(value, int) or value <= 0 or value > MAX_DURATION_US:
        fail("JY002_DRAFT_STRUCTURE_INVALID")


def handshake(payload):
    if not require_keys(payload, ["action", "python_module_root", "expected_upstream_commit"]):
        fail("JY002_DESKTOP_VERSION_UNSUPPORTED")
    module_root = payload["python_module_root"]
    expected_commit = payload["expected_upstream_commit"]
    if (
        not isinstance(module_root, str)
        or not os.path.isabs(module_root)
        or not isinstance(expected_commit, str)
        or len(expected_commit) != 40
        or any(character not in "0123456789abcdef" for character in expected_commit.lower())
    ):
        fail("JY002_DESKTOP_VERSION_UNSUPPORTED")
    try:
        canonical_root = Path(module_root).resolve()
        repository_root = Path(
            subprocess.run(
                ["git", "-C", str(canonical_root), "rev-parse", "--show-toplevel"],
                check=True,
                capture_output=True,
                text=True,
                timeout=5,
            ).stdout.strip()
        ).resolve()
        actual_commit = subprocess.run(
            ["git", "-C", str(canonical_root), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip()
        worktree_status = subprocess.run(
            ["git", "-C", str(canonical_root), "status", "--porcelain", "--untracked-files=all"],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout
        import pyJianYingDraft as draft
        module_file = Path(draft.__file__).resolve()
        module_belongs_to_checkout = os.path.commonpath([str(canonical_root), str(module_file)]) == str(canonical_root)
        if (
            repository_root != canonical_root
            or actual_commit != expected_commit
            or worktree_status.strip()
            or not module_belongs_to_checkout
            or not hasattr(draft, "TrackSpec")
            or not hasattr(draft, "DraftFolder")
        ):
            fail("JY002_DESKTOP_VERSION_UNSUPPORTED")
    except SystemExit:
        raise
    except Exception:
        fail("JY002_DESKTOP_VERSION_UNSUPPORTED")
    emit({"ok": True, "upstream_commit": actual_commit})


def validate_timerange(value, start, duration):
    return (
        isinstance(value, dict)
        and value.get("start") == start
        and value.get("duration") == duration
    )


def frame_tolerance_us(fps):
    return ((1_000_000 + fps - 1) // fps) if isinstance(fps, int) and fps > 0 else 0


DEFAULT_FRAME_TOLERANCE_US = frame_tolerance_us(30)


def validate_timerange_with_tolerance(value, start, duration, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    return (
        isinstance(value, dict)
        and isinstance(value.get("start"), int)
        and isinstance(value.get("duration"), int)
        and abs(value["start"] - start) <= tolerance_us
        and abs(value["duration"] - duration) <= tolerance_us
    )


def validate_track_segments(actual_segments, expected_segments, include_source, tolerance_us=0):
    if not isinstance(actual_segments, list) or len(actual_segments) != len(expected_segments):
        return False
    for actual, expected in zip(actual_segments, expected_segments):
        if not isinstance(actual, dict) or not validate_timerange_with_tolerance(
            actual.get("target_timerange"),
            expected["target_start_us"],
            expected["target_duration_us"],
            tolerance_us,
        ):
            return False
        if include_source:
            source_timerange = actual.get("source_timerange")
            if (
                not isinstance(source_timerange, dict)
                or source_timerange.get("start") != expected["source_start_us"]
                or not isinstance(source_timerange.get("duration"), int)
                or source_timerange["duration"] <= 0
                or source_timerange["duration"] > expected["source_duration_us"]
            ):
                return False
            if "speed" not in expected:
                continue
            speed = expected["speed"]
            expected_speed = speed["numerator"] / speed["denominator"]
            actual_speed = actual.get("speed")
            if actual_speed is None and expected_speed == 1:
                continue
            if (
                not isinstance(actual_speed, (int, float))
                or isinstance(actual_speed, bool)
                or not math.isfinite(actual_speed)
                or abs(actual_speed - expected_speed) > 1e-9
            ):
                return False
        if not include_source:
            source_timerange = actual.get("source_timerange")
            if (
                not isinstance(source_timerange, dict)
                or source_timerange.get("start") != 0
                or not isinstance(source_timerange.get("duration"), int)
                or source_timerange["duration"] <= 0
                or source_timerange["duration"] > expected["target_duration_us"]
            ):
                return False
    if include_source and actual_segments:
        for previous, current in zip(actual_segments, actual_segments[1:]):
            previous_range = previous.get("target_timerange") if isinstance(previous, dict) else None
            current_range = current.get("target_timerange") if isinstance(current, dict) else None
            if (
                not isinstance(previous_range, dict)
                or not isinstance(current_range, dict)
                or current_range.get("start") != previous_range.get("start", 0) + previous_range.get("duration", 0)
            ):
                return False
    return True


def validate_target_segments(actual_segments, expected_segments, tolerance_us=0):
    if not isinstance(actual_segments, list) or len(actual_segments) != len(expected_segments):
        return False
    return all(
        isinstance(actual, dict)
        and validate_timerange_with_tolerance(
            actual.get("target_timerange"),
            expected["target_start_us"],
            expected["target_duration_us"],
            tolerance_us,
        )
        for actual, expected in zip(actual_segments, expected_segments)
    )


def packaging_resource_id(content, track_type, segment):
    if not isinstance(segment, dict):
        return None
    material_id = segment.get("material_id")
    if not isinstance(material_id, str) or not material_id:
        return None
    materials = content.get("materials")
    if not isinstance(materials, dict):
        return None
    bucket = "stickers" if track_type == "sticker" else "video_effects"
    entries = materials.get(bucket)
    if not isinstance(entries, list):
        return None
    for material in entries:
        if not isinstance(material, dict) or material.get("id") != material_id:
            continue
        resource_id = material.get("resource_id")
        if resource_id is None:
            resource_id = material.get("sticker_id" if track_type == "sticker" else "effect_id")
        return None if resource_id is None else str(resource_id)
    return None


def packaging_effect_id(content, segment):
    if not isinstance(segment, dict) or not isinstance(segment.get("material_id"), str):
        return None
    materials = content.get("materials")
    entries = materials.get("video_effects") if isinstance(materials, dict) else None
    if not isinstance(entries, list):
        return None
    for material in entries:
        if isinstance(material, dict) and material.get("id") == segment["material_id"]:
            return None if material.get("effect_id") is None else str(material["effect_id"])
    return None


def filter_resource_id(content, segment):
    if not isinstance(segment, dict):
        return None
    material_id = segment.get("material_id")
    if not isinstance(material_id, str) or not material_id:
        return None
    materials = content.get("materials")
    entries = (
        [item for item in materials.get("effects", []) if isinstance(item, dict) and item.get("type") == "filter"]
        if isinstance(materials, dict) and isinstance(materials.get("effects"), list)
        else materials.get("filters") if isinstance(materials, dict) else None
    )
    if not isinstance(entries, list):
        return None
    for material in entries:
        if isinstance(material, dict) and material.get("id") == material_id:
            return None if material.get("resource_id") is None else str(material["resource_id"])
    return None


def filter_material_value(content, segment):
    if not isinstance(segment, dict) or not isinstance(segment.get("material_id"), str):
        return None
    materials = content.get("materials")
    entries = materials.get("effects", []) if isinstance(materials, dict) and isinstance(materials.get("effects"), list) else materials.get("filters", []) if isinstance(materials, dict) else []
    for material in entries:
        if isinstance(material, dict) and material.get("id") == segment["material_id"]:
            value = material.get("value")
            return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) else None
    return None


def validate_packaging_tracks(
    content, by_name, expected, prefix, track_type, allow_subset=False, tolerance_us=DEFAULT_FRAME_TOLERANCE_US
):
    expected_segments = list(expected)
    names = sorted(
        name for name in by_name
        if isinstance(name, str) and name.startswith(f"{prefix}-")
    )
    if not allow_subset and len(names) != len(expected_segments):
        return False
    if allow_subset and len(names) > len(expected_segments):
        return False
    for name in names:
        track = by_name[name]
        if track.get("type") != track_type:
            return False
        actual_segments = track.get("segments")
        if not isinstance(actual_segments, list) or len(actual_segments) != 1:
            return False
        actual = actual_segments[0]
        actual_resource_id = packaging_resource_id(content, track_type, actual)
        actual_effect_id = packaging_effect_id(content, actual) if track_type == "effect" else None
        match_index = next(
            (
                index for index, segment in enumerate(expected_segments)
                if validate_timerange_with_tolerance(
                    actual.get("target_timerange") if isinstance(actual, dict) else None,
                    segment["target_start_us"],
                    segment["target_duration_us"],
                    tolerance_us,
                )
                and str(segment["resource_id"]) == str(actual_resource_id)
                and ("effect_id" not in segment or str(segment["effect_id"]) == str(actual_effect_id))
            ),
            None,
        )
        if match_index is None:
            return False
        expected_segments.pop(match_index)
    return allow_subset or not expected_segments


def validate_filter_tracks(content, by_name, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    expected_segments = [
        segment for segment in expected
        if segment["capability_id"] == "filter.video.track_named"
    ]
    names = sorted(
        name for name in by_name
        if isinstance(name, str) and name.startswith("filter-")
    )
    if len(names) != len(expected_segments):
        return False
    for name in names:
        track = by_name[name]
        if track.get("type") != "filter":
            return False
        actual_segments = track.get("segments")
        if not isinstance(actual_segments, list) or len(actual_segments) != 1:
            return False
        actual = actual_segments[0]
        match_index = next(
            (
                index for index, segment in enumerate(expected_segments)
                if isinstance(actual, dict)
                and validate_timerange_with_tolerance(
                    actual.get("target_timerange"),
                    segment["target_start_us"],
                    segment["target_duration_us"],
                    tolerance_us,
                )
                and filter_resource_id(content, actual) == str(segment["resource_id"])
                and filter_material_value(content, actual) is not None
                and abs(filter_material_value(content, actual) - (float(segment["intensity"]) / 100.0)) < 0.000001
            ),
            None,
        )
        if match_index is None:
            return False
        expected_segments.pop(match_index)
    return not expected_segments


def validate_video_fades(content, video_track, expected_segments):
    actual_segments = video_track.get("segments") if isinstance(video_track, dict) else None
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    fades = materials.get("audio_fades") if isinstance(materials.get("audio_fades"), list) else []
    videos = materials.get("videos") if isinstance(materials.get("videos"), list) else []
    if not isinstance(actual_segments, list) or len(actual_segments) != len(expected_segments):
        return False
    expects_video_fade = any(
        segment.get("fade_in_us", 0) or segment.get("fade_out_us", 0)
        for segment in expected_segments if isinstance(segment, dict)
    )
    if not expects_video_fade:
        for actual in actual_segments:
            if not isinstance(actual, dict):
                return False
            refs = actual.get("extra_material_refs") if isinstance(actual.get("extra_material_refs"), list) else []
            if any(isinstance(fade, dict) and fade.get("id") in refs for fade in fades):
                return False
            video_materials = [
                video for video in videos
                if isinstance(video, dict) and video.get("id") == actual.get("material_id")
            ]
            if len(video_materials) > 1 or (
                len(video_materials) == 1 and video_materials[0].get("audio_fade") is not None
            ):
                return False
        return True
    referenced_fade_ids = []
    for actual, expected in zip(actual_segments, expected_segments):
        if not isinstance(actual, dict) or not isinstance(expected, dict):
            return False
        expected_in = expected.get("fade_in_us", 0)
        expected_out = expected.get("fade_out_us", 0)
        refs = actual.get("extra_material_refs") if isinstance(actual.get("extra_material_refs"), list) else []
        attached = [fade for fade in fades if isinstance(fade, dict) and fade.get("id") in refs]
        video_materials = [video for video in videos if isinstance(video, dict) and video.get("id") == actual.get("material_id")]
        if len(video_materials) != 1:
            return False
        if expected_in or expected_out:
            if len(attached) != 1 or attached[0].get("type") != "audio_fade" or attached[0].get("fade_in_duration") != expected_in or attached[0].get("fade_out_duration") != expected_out:
                return False
            if video_materials[0].get("audio_fade") != attached[0]:
                return False
            referenced_fade_ids.append(attached[0].get("id"))
        elif attached or video_materials[0].get("audio_fade") is not None:
            return False
    return len(referenced_fade_ids) == len(set(referenced_fade_ids))


def resolve_video_owner(video_track, expected_video_segments, target_start_us, target_duration_us, tolerance_us):
    """Resolve a packaging owner by canonical primary-video index, never by nearest range."""
    actual_segments = video_track.get("segments") if isinstance(video_track, dict) else None
    if not isinstance(actual_segments, list) or not isinstance(expected_video_segments, list):
        return None
    indexes = [
        index for index, expected in enumerate(expected_video_segments)
        if isinstance(expected, dict)
        and expected.get("target_start_us") == target_start_us
        and expected.get("target_duration_us") == target_duration_us
    ]
    if len(indexes) != 1 or indexes[0] >= len(actual_segments):
        return None
    owner = actual_segments[indexes[0]]
    return owner if isinstance(owner, dict) and validate_timerange_with_tolerance(
        owner.get("target_timerange"), target_start_us, target_duration_us, tolerance_us
    ) else None


def validate_segment_filters(content, video_track, expected_video_segments, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    expected_segments = [segment for segment in expected if segment["capability_id"] == "filter.video.named"]
    if not expected_segments:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    effects = materials.get("effects", []) if isinstance(materials.get("effects"), list) else materials.get("filters", [])
    filters = [item for item in effects if isinstance(item, dict) and (item.get("type") in (None, "filter"))]
    for expected_segment in expected_segments:
        match = resolve_video_owner(video_track, expected_video_segments, expected_segment["target_start_us"], expected_segment["target_duration_us"], tolerance_us)
        if match is None or not isinstance(match.get("extra_material_refs"), list):
            return False
        refs = [item for item in filters if item.get("resource_id") is not None and str(item.get("resource_id")) == str(expected_segment["resource_id"]) and item.get("id") in match["extra_material_refs"]]
        if len(refs) != 1:
            return False
    return True


def validate_animation_segments(content, video_track, expected_video_segments, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    if not expected:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    animations = materials.get("material_animations") if isinstance(materials.get("material_animations"), list) else []
    for item in expected:
        segment = resolve_video_owner(video_track, expected_video_segments, item["target_start_us"], item["target_duration_us"], tolerance_us)
        if segment is None or not isinstance(segment.get("extra_material_refs"), list):
            return False
        matches = [material for material in animations if isinstance(material, dict) and material.get("id") in segment["extra_material_refs"] and any(isinstance(animation, dict) and str(animation.get("resource_id")) == str(item["resource_id"]) and animation.get("duration") == item["duration_us"] for animation in material.get("animations", []))]
        if len(matches) != 1:
            return False
    return True


def validate_text_animation_segments(content, title_track, expected):
    if not expected:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    animations = materials.get("material_animations") if isinstance(materials.get("material_animations"), list) else []
    text_segments = title_track.get("segments") if isinstance(title_track, dict) else None
    if not isinstance(text_segments, list):
        return False
    expected_material_ids = set()
    for item in expected:
        segment = next((candidate for candidate in text_segments if isinstance(candidate, dict) and validate_timerange(candidate.get("target_timerange"), item["target_start_us"], item["target_duration_us"])), None)
        if segment is None or not isinstance(segment.get("extra_material_refs"), list):
            return False
        matches = [material for material in animations if isinstance(material, dict) and material.get("id") in segment["extra_material_refs"] and any(isinstance(animation, dict) and str(animation.get("resource_id")) == str(item["resource_id"]) and animation.get("duration") == item["duration_us"] and animation.get("type") in ("in", "out", "loop") for animation in material.get("animations", []))]
        if len(matches) != 1:
            return False
        material_id = matches[0].get("id")
        if not isinstance(material_id, str) or segment["extra_material_refs"].count(material_id) != 1 or material_id in expected_material_ids:
            return False
        reference_count = sum(candidate["extra_material_refs"].count(material_id) for candidate in text_segments if isinstance(candidate, dict) and isinstance(candidate.get("extra_material_refs"), list))
        if reference_count != 1:
            return False
        expected_material_ids.add(material_id)
    title_animation_refs = {
        reference
        for segment in text_segments
        if isinstance(segment, dict) and isinstance(segment.get("extra_material_refs"), list)
        for reference in segment["extra_material_refs"]
        if any(isinstance(material, dict) and material.get("id") == reference for material in animations)
    }
    if title_animation_refs != expected_material_ids:
        return False
    return True


def valid_text_style(style):
    if style is None:
        return True
    allowed = {"size", "color", "transformX", "transformY", "autoWrapping", "maxLineWidth"}
    if not isinstance(style, dict) or not set(style.keys()).issubset(allowed):
        return False
    for key, lower, upper in (("size", 1.0, 20.0), ("transformX", -1.0, 1.0), ("transformY", -1.0, 1.0), ("maxLineWidth", 0.01, 1.0)):
        if key not in style:
            continue
        value = style[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not lower <= value <= upper:
            return False
    if "autoWrapping" in style and not isinstance(style["autoWrapping"], bool):
        return False
    if "color" in style and (
        not isinstance(style["color"], list)
        or len(style["color"]) != 3
        or any(isinstance(channel, bool) or not isinstance(channel, (int, float)) or not math.isfinite(channel) or not 0 <= channel <= 1 for channel in style["color"])
    ):
        return False
    return True


def validate_title_layout_segments(content, title_track, expected):
    governed = [item for item in expected if isinstance(item, dict) and isinstance(item.get("style"), dict) and item["style"].get("autoWrapping") is True]
    if not governed:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    text_materials = materials.get("texts") if isinstance(materials.get("texts"), list) else []
    text_segments = title_track.get("segments") if isinstance(title_track, dict) else None
    if not isinstance(text_segments, list):
        return False
    for item in governed:
        style = item["style"]
        segment = next((candidate for candidate in text_segments if isinstance(candidate, dict) and validate_timerange(candidate.get("target_timerange"), item["target_start_us"], item["target_duration_us"])), None)
        if segment is None or not isinstance(segment.get("clip"), dict):
            return False
        transform = segment["clip"].get("transform")
        if not isinstance(transform, dict) or abs(float(transform.get("x", 99)) - float(style["transformX"])) > 0.000001 or abs(float(transform.get("y", 99)) - float(style["transformY"])) > 0.000001:
            return False
        material = next((candidate for candidate in text_materials if isinstance(candidate, dict) and candidate.get("id") == segment.get("material_id")), None)
        if material is None or material.get("type") != "subtitle" or abs(float(material.get("line_max_width", -1)) - float(style["maxLineWidth"])) > 0.000001:
            return False
        try:
            text_content = json.loads(material.get("content"))
            text_styles = text_content.get("styles")
            if text_content.get("text") != item["text"] or not isinstance(text_styles, list) or len(text_styles) != 1 or abs(float(text_styles[0].get("size", -1)) - float(style["size"])) > 0.000001:
                return False
        except (TypeError, ValueError, json.JSONDecodeError):
            return False
    return True


def validate_text_keyframe_segments(title_track, expected):
    if not expected:
        return True
    text_segments = title_track.get("segments") if isinstance(title_track, dict) else None
    if not isinstance(text_segments, list):
        return False
    for item in expected:
        segment = next((candidate for candidate in text_segments if isinstance(candidate, dict) and validate_timerange(candidate.get("target_timerange"), item["target_start_us"], item["target_duration_us"])), None)
        if segment is None or not isinstance(segment.get("common_keyframes"), list):
            return False
        scale_lists = [entry for entry in segment["common_keyframes"] if isinstance(entry, dict) and entry.get("property_type") == "KFTypeScaleX"]
        if len(scale_lists) != 1 or not isinstance(scale_lists[0].get("keyframe_list"), list):
            return False
        actual = scale_lists[0]["keyframe_list"]
        if len(actual) != len(item["keyframes"]):
            return False
        for actual_keyframe, expected_keyframe in zip(actual, item["keyframes"]):
            if not isinstance(actual_keyframe, dict) or actual_keyframe.get("time_offset") != expected_keyframe["offset_us"] or actual_keyframe.get("values") != [float(expected_keyframe["value"])]:
                return False
    return True


def validate_sticker_keyframe_segments(by_name, expected):
    for index, item in enumerate(expected):
        track = by_name.get(f"sticker-{index + 1}")
        segments = track.get("segments") if isinstance(track, dict) else None
        if not isinstance(segments, list) or len(segments) != 1:
            return False
        segment = segments[0]
        if not isinstance(segment, dict) or not validate_timerange(segment.get("target_timerange"), item["target_start_us"], item["target_duration_us"]):
            return False
        expected_keyframes = item.get("keyframes", [])
        common = segment.get("common_keyframes", [])
        if not isinstance(common, list):
            return False
        scale_lists = [entry for entry in common if isinstance(entry, dict) and entry.get("property_type") == "KFTypeScaleX"]
        if not expected_keyframes:
            if scale_lists:
                return False
            continue
        if len(scale_lists) != 1 or not isinstance(scale_lists[0].get("keyframe_list"), list):
            return False
        actual = scale_lists[0]["keyframe_list"]
        if len(actual) != len(expected_keyframes):
            return False
        for actual_keyframe, expected_keyframe in zip(actual, expected_keyframes):
            if not isinstance(actual_keyframe, dict) or actual_keyframe.get("time_offset") != expected_keyframe["offset_us"] or actual_keyframe.get("values") != [float(expected_keyframe["value"])]:
                return False
    return True


def validate_blend_segments(content, video_track, expected_video_segments, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    if not expected:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    effects = materials.get("effects") if isinstance(materials.get("effects"), list) else []
    for item in expected:
        target = resolve_video_owner(video_track, expected_video_segments, item["target_start_us"], item["target_duration_us"], tolerance_us)
        if target is None or not isinstance(target.get("extra_material_refs"), list):
            return False
        matches = [effect for effect in effects if isinstance(effect, dict) and effect.get("type") == "mix_mode" and str(effect.get("resource_id")) == str(item["resource_id"]) and effect.get("id") in target["extra_material_refs"]]
        if len(matches) != 1:
            return False
    return True


def validate_mask_segments(content, video_track, expected_video_segments, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    """Confirm each requested mask survived serialization and is segment-bound."""
    if not expected:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    masks = materials.get("masks") if isinstance(materials.get("masks"), list) else []
    common_masks = materials.get("common_mask") if isinstance(materials.get("common_mask"), list) else []
    for item in expected:
        segment = resolve_video_owner(video_track, expected_video_segments, item["target_start_us"], item["target_duration_us"], tolerance_us)
        if segment is None or not isinstance(segment.get("extra_material_refs"), list):
            return False
        if isinstance(item.get("common_mask_template"), dict):
            template_config = item["common_mask_template"].get("config", {})
            base_width = float(template_config.get("width", 0))
            base_height = float(template_config.get("height", 0))
            if base_width <= 0 or base_height <= 0:
                return False
            scale = float(item["size"]) / 0.5
            matches = [
                material for material in common_masks
                if isinstance(material, dict)
                and material.get("id") in segment["extra_material_refs"]
                and str(material.get("resource_id")) == str(item["common_mask_template"].get("resource_id"))
                and isinstance(material.get("config"), dict)
                and abs(float(material["config"].get("width")) - base_width * scale) < 0.000001
                and abs(float(material["config"].get("height")) - base_height * scale) < 0.000001
            ]
        else:
            matches = [
                material for material in masks
            if isinstance(material, dict)
            and material.get("id") in segment["extra_material_refs"]
            and str(material.get("resource_id")) == str(item["resource_id"])
            and isinstance(material.get("config"), dict)
            and abs(float(material["config"].get("centerX")) - float(item["center_x"])) < 0.000001
            and abs(float(material["config"].get("centerY")) - float(item["center_y"])) < 0.000001
            and abs(float(material["config"].get("height")) - float(item["size"])) < 0.000001
            and abs(float(material["config"].get("rotation")) - float(item["rotation"])) < 0.000001
            and abs(float(material["config"].get("feather")) - (float(item["feather"]) / 100.0)) < 0.000001
            and material["config"].get("invert") is item["invert"]
            ]
        if len(matches) != 1:
            return False
    return True


def validate_common_mask_template(value):
    if not isinstance(value, dict) or set(value.keys()) != {"id", "type", "category", "category_name", "category_id", "resource_id", "constant_material_id", "name", "resource_type", "path", "config", "text_config"}:
        return False
    if not all(isinstance(value.get(key), str) and 0 < len(value[key]) <= 512 for key in ("type", "category", "category_name", "category_id", "resource_id", "constant_material_id", "name", "resource_type", "path")):
        return False
    config = value.get("config")
    text_config = value.get("text_config")
    return isinstance(config, dict) and set(config.keys()) == {"width", "height"} and all(isinstance(config[key], (int, float)) and not isinstance(config[key], bool) and math.isfinite(config[key]) and config[key] > 0 for key in ("width", "height")) and isinstance(text_config, dict) and set(text_config.keys()) == {"align_type"} and isinstance(text_config["align_type"], int)


def apply_common_mask_templates(content, mask_segments):
    """Replace legacy upstream masks with the current Jianying common_mask schema."""
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else None
    tracks = content.get("tracks") if isinstance(content.get("tracks"), list) else None
    if materials is None or tracks is None:
        fail("JY045_MASK_PERSISTENCE_INVALID")
    legacy_masks = materials.get("masks") if isinstance(materials.get("masks"), list) else []
    common_masks = materials.setdefault("common_mask", [])
    if not isinstance(common_masks, list):
        fail("JY045_MASK_PERSISTENCE_INVALID")
    video_segments = [segment for track in tracks if isinstance(track, dict) and track.get("type") == "video" for segment in (track.get("segments") or []) if isinstance(segment, dict)]
    legacy_ids_to_remove = set()
    for item in mask_segments:
        template = item.get("common_mask_template")
        if template is None:
            continue
        target = next((segment for segment in video_segments if validate_timerange(segment.get("target_timerange"), item["target_start_us"], item["target_duration_us"])), None)
        if target is None or not isinstance(target.get("extra_material_refs"), list):
            fail("JY045_MASK_TARGET_UNRESOLVED")
        legacy_ids = {mask.get("id") for mask in legacy_masks if isinstance(mask, dict) and str(mask.get("resource_id")) == str(item["resource_id"])}
        legacy_ids_to_remove.update(legacy_ids)
        target["extra_material_refs"] = [reference for reference in target["extra_material_refs"] if reference not in legacy_ids]
        replacement = deepcopy(template)
        replacement["id"] = str(uuid.uuid4()).upper()
        scale = float(item["size"]) / 0.5
        replacement["config"] = {"width": float(template["config"]["width"]) * scale, "height": float(template["config"]["height"]) * scale}
        common_masks.append(replacement)
        target["extra_material_refs"].append(replacement["id"])
    if any(isinstance(item, dict) and item.get("common_mask_template") is not None for item in mask_segments):
        materials["masks"] = [mask for mask in legacy_masks if not isinstance(mask, dict) or mask.get("id") not in legacy_ids_to_remove]


def validate_background_segments(content, video_track, expected_video_segments, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    if not expected:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    canvases = materials.get("canvases") if isinstance(materials.get("canvases"), list) else []
    for item in expected:
        target = resolve_video_owner(video_track, expected_video_segments, item["target_start_us"], item["target_duration_us"], tolerance_us)
        if target is None or not isinstance(target.get("extra_material_refs"), list):
            return False
        expected_type = "canvas_blur" if item["fill_type"] == "blur" else "canvas_color"
        matches = [canvas for canvas in canvases if isinstance(canvas, dict) and canvas.get("id") in target["extra_material_refs"] and canvas.get("type") == expected_type and abs(float(canvas.get("blur", -1)) - float(item["blur"])) <= 1e-9 and str(canvas.get("color", "")).lower() == item["color"].lower()]
        if len(matches) != 1:
            return False
    return True


def validate_chroma_segments(content, video_track, expected_video_segments, expected, tolerance_us=DEFAULT_FRAME_TOLERANCE_US):
    """Confirm one exact normalized chroma material is uniquely target-bound."""
    if not expected:
        return True
    materials = content.get("materials") if isinstance(content.get("materials"), dict) else {}
    chromas = materials.get("chromas") if isinstance(materials.get("chromas"), list) else []
    video_segments = video_track.get("segments") if isinstance(video_track, dict) else None
    if not isinstance(video_segments, list) or len(chromas) != len(expected):
        return False
    matched_ids = set()
    expected_ranges = [(item["target_start_us"], item["target_duration_us"]) for item in expected]
    if len(set(expected_ranges)) != len(expected_ranges):
        return False
    for item in expected:
        target = resolve_video_owner(video_track, expected_video_segments, item["target_start_us"], item["target_duration_us"], tolerance_us)
        if target is None or not isinstance(target.get("extra_material_refs"), list):
            return False
        matches = [
            chroma for chroma in chromas
            if isinstance(chroma, dict)
            and chroma.get("id") in target["extra_material_refs"]
            and chroma.get("type") == "chroma"
            and chroma.get("version") == "v2"
            and chroma.get("should_transfer_color") is True
            and str(chroma.get("color", "")).lower() == item["color"].lower()
            and abs(float(chroma.get("intensity_value", -1)) - float(item["intensity"]) / 100.0) < 0.000001
            and abs(float(chroma.get("shadow_value", -1)) - float(item["shadow"]) / 100.0) < 0.000001
            and abs(float(chroma.get("edge_smooth_value", -1)) - float(item["edge_smooth"]) / 100.0) < 0.000001
            and abs(float(chroma.get("spill_value", -1)) - float(item["spill"]) / 100.0) < 0.000001
        ]
        if len(matches) != 1 or matches[0].get("id") in matched_ids:
            return False
        matched_ids.add(matches[0]["id"])
        reference_count = sum(
            sum(1 for reference in segment.get("extra_material_refs", []) if reference == matches[0]["id"])
            for segment in video_segments if isinstance(segment, dict) and isinstance(segment.get("extra_material_refs"), list)
        )
        if reference_count != 1:
            return False
    return len(matched_ids) == len(chromas)


def validate_tracks(content, expected):
    if not isinstance(content, dict):
        return False
    if expected.get("allow_overlay_tracks") is True:
        if not validate_overlay_tracks(content):
            return False
        canonical_content = dict(content)
        canonical_content["tracks"] = [
            track for track in content.get("tracks", [])
            if not (isinstance(track, dict) and isinstance(track.get("id"), str) and track["id"].startswith("ov_track_"))
        ]
        canonical_expected = dict(expected)
        canonical_expected.pop("allow_overlay_tracks", None)
        return validate_tracks(canonical_content, canonical_expected)
    actual_duration = content.get("duration")
    expected_duration = expected["duration_us"]
    fps = expected.get("fps", 30)
    tolerance_us = frame_tolerance_us(fps)
    if (
        not isinstance(actual_duration, int)
        or not isinstance(fps, int)
        or fps <= 0
        or abs(actual_duration - expected_duration) > tolerance_us
    ):
        return False
    tracks = content.get("tracks")
    title_segments = expected.get("title_segments") or []
    sfx_segments = expected.get("sfx_segments") or []
    sfx_track_names = expected.get("sfx_track_names") or []
    sticker_segments = expected.get("sticker_segments") or []
    effect_segments = expected.get("effect_segments") or []
    animation_segments = expected.get("animation_segments") or []
    mask_segments = expected.get("mask_segments") or []
    blend_segments = expected.get("blend_segments") or []
    filter_segments = expected.get("filter_segments") or []
    background_segments = expected.get("background_segments") or []
    chroma_segments = expected.get("chroma_segments") or []
    text_animation_segments = expected.get("text_animation_segments") or []
    text_keyframe_segments = expected.get("text_keyframe_segments") or []
    expected_names = {"video-primary"}
    if expected["voiceover_segments"]:
        expected_names.add("voiceover-primary")
    if expected["caption_segments"]:
        expected_names.add("caption-primary")
    if title_segments:
        expected_names.add("title-primary")
    if expected["bgm_path"]:
        expected_names.add("bgm-primary")
    if sfx_segments:
        expected_names.update(
            dict.fromkeys(sfx_track_names or ["sfx-primary"])
        )
    expected_names.update(
        f"sticker-{index + 1}" for index in range(len(sticker_segments))
    )
    expected_names.update(
        f"filter-{index + 1}"
        for index, segment in enumerate(filter_segments)
        if segment["capability_id"] == "filter.video.track_named"
    )
    effect_names = {
        track.get("name")
        for track in tracks
        if isinstance(track, dict)
        and isinstance(track.get("name"), str)
        and track["name"].startswith("effect-")
    } if isinstance(tracks, list) else set()
    expected_names.update(effect_names)
    if (
        not isinstance(tracks, list)
        or len(tracks) != len(expected_names)
        or {track.get("name") for track in tracks} != expected_names
    ):
        return False
    by_name = {track["name"]: track for track in tracks}
    if (
        by_name["video-primary"].get("type") != "video"
        or (
            expected["voiceover_segments"]
            and by_name["voiceover-primary"].get("type") != "audio"
        )
        or (
            expected["caption_segments"]
            and by_name["caption-primary"].get("type") != "text"
        )
        or (title_segments and by_name["title-primary"].get("type") != "text")
        or (
            expected["bgm_path"]
            and by_name["bgm-primary"].get("type") != "audio"
        )
        or any(
            sfx_segments
            and (by_name.get(track_name, {}).get("type") != "audio")
            for track_name in dict.fromkeys(sfx_track_names or ["sfx-primary"])
        )
    ):
        return False
    valid = validate_track_segments(
        by_name["video-primary"].get("segments"), expected["video_segments"], True, tolerance_us
    )
    valid = valid and validate_video_fades(content, by_name["video-primary"], expected["video_segments"])
    if expected["voiceover_segments"]:
        valid = valid and validate_track_segments(
            by_name["voiceover-primary"].get("segments"), expected["voiceover_segments"], False, tolerance_us
        )
    if expected["caption_segments"]:
        valid = valid and validate_target_segments(
            by_name["caption-primary"].get("segments"), expected["caption_segments"], tolerance_us
        )
    if title_segments:
        valid = valid and validate_target_segments(
            by_name["title-primary"].get("segments"), title_segments
        )
        valid = valid and validate_title_layout_segments(content, by_name["title-primary"], title_segments)
        valid = valid and validate_text_animation_segments(content, by_name["title-primary"], text_animation_segments)
        valid = valid and validate_text_keyframe_segments(by_name["title-primary"], text_keyframe_segments)
    elif text_animation_segments or text_keyframe_segments:
        return False
    if expected["bgm_path"]:
        valid = valid and validate_track_segments(
            by_name["bgm-primary"].get("segments"),
            [{"target_start_us": 0, "target_duration_us": expected["duration_us"]}],
            False, tolerance_us,
        )
        bgm_segments = by_name["bgm-primary"].get("segments")
        valid = (
            valid
            and isinstance(bgm_segments, list)
            and len(bgm_segments) == 1
            and isinstance(bgm_segments[0].get("volume"), (int, float))
            and abs(float(bgm_segments[0]["volume"]) - expected["bgm_volume"]) < 0.000001
        )
        bgm_materials = content.get("materials", {}).get("audios", [])
        matching_bgm_materials = [
            material for material in bgm_materials
            if isinstance(material, dict)
            and material.get("name") == "bgm"
            and material.get("path") == expected["bgm_path"]
        ]
        valid = valid and len(matching_bgm_materials) == 1
    if sfx_segments:
        expected_sfx_tracks = dict.fromkeys(sfx_track_names or ["sfx-primary"])
        for track_name in expected_sfx_tracks:
            grouped = [
                item for index, item in enumerate(sfx_segments)
                if (sfx_track_names[index] if sfx_track_names else "sfx-primary") == track_name
            ]
            valid = valid and validate_target_segments(
                by_name[track_name].get("segments"), grouped
            )
        expected_audio_effects = [item for item in sfx_segments if item.get("effect_resource_id")]
        if expected_audio_effects:
            materials = content.get("materials", {}).get("audio_effects", [])
            actual_segments = [
                segment
                for track_name in expected_sfx_tracks
                for segment in (by_name[track_name].get("segments") or [])
            ]
            expected_ranges = [
                (item["target_start_us"], item["target_duration_us"])
                for item in expected_audio_effects
            ]
            if len(set(expected_ranges)) != len(expected_ranges) or len(materials) != len(expected_audio_effects):
                valid = False
            audio_effect_ids = {
                material.get("id")
                for material in materials
                if isinstance(material, dict) and isinstance(material.get("id"), str)
            }
            for item in expected_audio_effects:
                targets = [segment for segment in actual_segments if validate_timerange(segment.get("target_timerange"), item["target_start_us"], item["target_duration_us"])]
                matches = [effect for effect in materials if isinstance(effect, dict) and effect.get("resource_id") == item["effect_resource_id"] and len(targets) == 1 and effect.get("id") in targets[0].get("extra_material_refs", [])]
                valid = valid and len(targets) == 1 and len(matches) == 1
                if len(matches) == 1:
                    reference_count = sum(
                        1
                        for track in content.get("tracks", [])
                        for segment in (track.get("segments", []) if isinstance(track, dict) else [])
                        if isinstance(segment, dict) and matches[0].get("id") in segment.get("extra_material_refs", [])
                    )
                    valid = valid and reference_count == 1
            referenced_audio_effect_ids = {
                reference
                for segment in actual_segments
                for reference in (segment.get("extra_material_refs", []) if isinstance(segment, dict) else [])
                if reference in audio_effect_ids
            }
            valid = valid and referenced_audio_effect_ids == audio_effect_ids
    if sticker_segments:
        valid = valid and validate_packaging_tracks(
            content, by_name, sticker_segments, "sticker", "sticker"
        )
        valid = valid and validate_sticker_keyframe_segments(by_name, sticker_segments)
    if effect_segments or effect_names:
        valid = valid and validate_packaging_tracks(
            content,
            by_name,
            effect_segments,
            "effect",
            "effect",
            allow_subset=not expected.get("effect_segments_resolved", False),
        )
    if filter_segments:
        materials = content.get("materials", {})
        filters = (
            [item for item in materials.get("effects", []) if isinstance(item, dict) and item.get("type") == "filter"]
            if isinstance(materials, dict) and isinstance(materials.get("effects"), list)
            else materials.get("filters") if isinstance(materials, dict) else None
        )
        actual_resource_ids = [
            str(item.get("resource_id"))
            for item in filters
            if isinstance(item, dict) and item.get("resource_id") is not None
        ] if isinstance(filters, list) else []
        expected_resource_ids = [str(item["resource_id"]) for item in filter_segments]
        valid = valid and sorted(actual_resource_ids) == sorted(expected_resource_ids)
        valid = valid and validate_filter_tracks(content, by_name, filter_segments, tolerance_us)
        valid = valid and validate_segment_filters(content, by_name["video-primary"], expected["video_segments"], filter_segments, tolerance_us)
    if animation_segments:
        valid = valid and validate_animation_segments(content, by_name["video-primary"], expected["video_segments"], animation_segments, tolerance_us)
    if mask_segments:
        valid = valid and validate_mask_segments(content, by_name["video-primary"], expected["video_segments"], mask_segments, tolerance_us)
    if blend_segments:
        valid = valid and validate_blend_segments(content, by_name["video-primary"], expected["video_segments"], blend_segments, tolerance_us)
    if background_segments:
        valid = valid and validate_background_segments(content, by_name["video-primary"], expected["video_segments"], background_segments, tolerance_us)
    if chroma_segments:
        valid = valid and validate_chroma_segments(content, by_name["video-primary"], expected["video_segments"], chroma_segments, tolerance_us)
    return valid


def private_batch_readback(payload, expected):
    """Build private token-to-material evidence after `validate_tracks` passed."""
    plan = payload.get("private_batch_plan", [])
    def batch_fail(reason):
        # Keep the diagnostic bounded and free of private tokens, paths, or raw
        # resource identifiers. The caller needs only the shape mismatch to
        # repair the current runtime catalog projection.
        kinds = {}
        if isinstance(plan, list):
            for candidate in plan:
                kind = candidate.get("kind") if isinstance(candidate, dict) else None
                key = kind if isinstance(kind, str) else "invalid"
                kinds[key] = kinds.get(key, 0) + 1
        expected_counts = {
            key: len(value) if isinstance(value, list) else None
            for key, value in expected_by_kind.items()
        } if "expected_by_kind" in locals() else {}
        fail("JY002_DRAFT_STRUCTURE_INVALID", {
            "stage": "private_batch_readback",
            "exception_type": "PrivateBatchReadbackError",
            "reason": reason,
            "plan_count": len(plan) if isinstance(plan, list) else None,
            "plan_kinds": kinds,
            "expected_segment_counts": expected_counts,
        })
    if not isinstance(plan, list) or len(plan) > 24:
        batch_fail("plan_shape")
    expected_by_kind = {
        "effect": expected.get("effect_segments") or [],
        "sticker": expected.get("sticker_segments") or [],
        "animation": expected.get("animation_segments") or [],
        "mask": expected.get("mask_segments") or [],
        "blend": expected.get("blend_segments") or [],
    }
    result = []
    seen_tokens = set()
    for item in plan:
        base_keys = {"packaging_token", "placement_id", "kind", "resource_id", "binding_fingerprint", "target_start_us", "target_duration_us"}
        if not isinstance(item, dict) or set(item.keys()) not in (
            base_keys,
            base_keys | {"duration_us"},
            base_keys | {"effect_id"},
        ):
            batch_fail("item_shape")
        token = item.get("packaging_token")
        placement_id = item.get("placement_id")
        kind = item.get("kind")
        resource_id = item.get("resource_id")
        binding_fingerprint = item.get("binding_fingerprint")
        start = item.get("target_start_us")
        duration = item.get("target_duration_us")
        effect_id = item.get("effect_id")
        if (
            not isinstance(token, str) or not re.fullmatch(r"ovj[A-Za-z0-9_]{12,200}", token)
            or not isinstance(placement_id, str) or len(placement_id) > 500
            or placement_id != f"{token}:{start}:{duration}"
            or placement_id in seen_tokens or kind not in expected_by_kind
            or not isinstance(resource_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", resource_id)
            or not isinstance(binding_fingerprint, str) or not re.fullmatch(r"[a-f0-9]{64}", binding_fingerprint)
            or not isinstance(start, int) or start < 0
            or not isinstance(duration, int) or duration <= 0
            or (kind == "animation" and (not isinstance(item.get("duration_us"), int) or item["duration_us"] <= 0))
            or (kind != "animation" and "duration_us" in item)
            or ("effect_id" in item and (kind != "effect" or not isinstance(effect_id, str) or re.fullmatch(r"[A-Za-z0-9_-]{4,80}", effect_id) is None))
        ):
            batch_fail("item_values")
        seen_tokens.add(placement_id)
        matches = [
            candidate for candidate in expected_by_kind[kind]
            if isinstance(candidate, dict)
            and candidate.get("resource_id") == resource_id
            and candidate.get("target_start_us") == start
            and candidate.get("target_duration_us") == duration
            and ("effect_id" not in item or candidate.get("effect_id") == effect_id)
            and (kind != "animation" or candidate.get("duration_us") == item["duration_us"])
        ]
        if len(matches) != 1:
            batch_fail("segment_match")
        result.append({
            "packagingToken": token,
            "placementId": placement_id,
            "kind": kind,
            "resourceId": resource_id,
            "bindingFingerprint": binding_fingerprint,
            "targetStartUs": start,
            "targetDurationUs": duration,
            **({"effectId": effect_id} if "effect_id" in item else {}),
            **({"durationUs": item["duration_us"]} if kind == "animation" else {}),
            "persisted": True,
        })
    return result


def validate_overlay_tracks(content):
    """Validate template-only packaging without weakening canonical tracks."""
    if not isinstance(content, dict) or not isinstance(content.get("tracks"), list):
        return False
    materials = content.get("materials")
    if not isinstance(materials, dict):
        return False
    material_ids = {
        item.get("id")
        for entries in materials.values()
        if isinstance(entries, list)
        for item in entries
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    allowed_types = {"text", "sticker", "effect"}
    for track in content["tracks"]:
        if not isinstance(track, dict):
            return False
        if not (isinstance(track.get("id"), str) and track["id"].startswith("ov_track_")):
            continue
        if track.get("type") not in allowed_types or not isinstance(track.get("segments"), list) or not track["segments"]:
            return False
        for segment in track["segments"]:
            timerange = segment.get("target_timerange") if isinstance(segment, dict) else None
            if (
                not isinstance(segment, dict)
                or not isinstance(segment.get("id"), str)
                or not isinstance(timerange, dict)
                or not isinstance(timerange.get("start"), int)
                or not isinstance(timerange.get("duration"), int)
                or timerange["start"] < 0
                or timerange["duration"] <= 0
                or timerange["start"] + timerange["duration"] > content.get("duration", 0)
                or not isinstance(segment.get("material_id"), str)
                or segment["material_id"] not in material_ids
                or not isinstance(segment.get("extra_material_refs", []), list)
                or any(not isinstance(reference, str) or reference not in material_ids for reference in segment.get("extra_material_refs", []))
            ):
                return False
    return True


def overlay_track_validation_diagnostic(content):
    """Return bounded reasons without exposing template identities."""
    tracks = content.get("tracks") if isinstance(content, dict) else None
    materials = content.get("materials") if isinstance(content, dict) else None
    if not isinstance(tracks, list) or not isinstance(materials, dict):
        return {"valid": False, "reason": "document_shape", "track_count": None}
    material_ids = {
        item.get("id")
        for entries in materials.values()
        if isinstance(entries, list)
        for item in entries
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    overlay_tracks = [
        track for track in tracks
        if isinstance(track, dict)
        and isinstance(track.get("id"), str)
        and track["id"].startswith("ov_track_")
    ]
    allowed_types = {"text", "sticker", "effect"}
    for track in overlay_tracks:
        segments = track.get("segments")
        if track.get("type") not in allowed_types:
            return {"valid": False, "reason": "track_type", "track_count": len(overlay_tracks)}
        if not isinstance(segments, list) or not segments:
            return {"valid": False, "reason": "segment_count", "track_count": len(overlay_tracks)}
        for segment in segments:
            timerange = segment.get("target_timerange") if isinstance(segment, dict) else None
            if not isinstance(segment, dict) or not isinstance(segment.get("id"), str):
                return {"valid": False, "reason": "segment_shape", "track_count": len(overlay_tracks)}
            if not isinstance(timerange, dict):
                return {"valid": False, "reason": "timerange_shape", "track_count": len(overlay_tracks)}
            if not isinstance(timerange.get("start"), int) or not isinstance(timerange.get("duration"), int):
                return {"valid": False, "reason": "timerange_type", "track_count": len(overlay_tracks)}
            if timerange["start"] < 0 or timerange["duration"] <= 0 or timerange["start"] + timerange["duration"] > content.get("duration", 0):
                return {"valid": False, "reason": "timerange_bounds", "track_count": len(overlay_tracks)}
            if not isinstance(segment.get("material_id"), str) or segment["material_id"] not in material_ids:
                return {"valid": False, "reason": "material_reference", "track_count": len(overlay_tracks)}
            references = segment.get("extra_material_refs", [])
            if not isinstance(references, list) or any(not isinstance(reference, str) or reference not in material_ids for reference in references):
                return {"valid": False, "reason": "extra_material_reference", "track_count": len(overlay_tracks)}
    return {"valid": True, "reason": None, "track_count": len(overlay_tracks)}


def track_validation_diagnostic(content, expected):
    """Return path-free evidence for private writer logs."""
    tracks = content.get("tracks") if isinstance(content, dict) else None
    by_name = {track.get("name"): track for track in tracks if isinstance(track, dict) and isinstance(track.get("name"), str)} if isinstance(tracks, list) else {}
    title_track = next((track for track in tracks if isinstance(track, dict) and track.get("name") == "title-primary"), None) if isinstance(tracks, list) else None
    title_segments = expected.get("title_segments") or []
    text_animation_segments = expected.get("text_animation_segments") or []
    text_keyframe_segments = expected.get("text_keyframe_segments") or []
    sticker_segments = expected.get("sticker_segments") or []
    effect_segments = expected.get("effect_segments") or []
    animation_segments = expected.get("animation_segments") or []
    mask_segments = expected.get("mask_segments") or []
    blend_segments = expected.get("blend_segments") or []
    fps = expected.get("fps", 30)
    frame_tolerance_us = ((1_000_000 + fps - 1) // fps) if isinstance(fps, int) and fps > 0 else None
    overlay_diagnostic = overlay_track_validation_diagnostic(content) if expected.get("allow_overlay_tracks") is True else None
    actual_duration = content.get("duration") if isinstance(content, dict) else None
    expected_duration = expected.get("duration_us")
    effect_tracks = [track for name, track in by_name.items() if isinstance(name, str) and name.startswith("effect-")]
    effect_shape_valid = len(effect_tracks) == len(effect_segments) and all(track.get("type") == "effect" and isinstance(track.get("segments"), list) and len(track.get("segments")) == 1 for track in effect_tracks)
    effect_range_valid = effect_shape_valid and all(
        any(validate_timerange_with_tolerance(segment.get("target_timerange"), expected_item.get("target_start_us"), expected_item.get("target_duration_us"), frame_tolerance_us or 0) for segment in track.get("segments", []) if isinstance(segment, dict))
        for track, expected_item in zip(sorted(effect_tracks, key=lambda item: item.get("name", "")), effect_segments)
    )
    effect_resource_valid = effect_shape_valid and all(
        packaging_resource_id(content, "effect", track.get("segments", [None])[0]) == str(expected_item.get("resource_id"))
        for track, expected_item in zip(sorted(effect_tracks, key=lambda item: item.get("name", "")), effect_segments)
    )
    effect_id_valid = effect_shape_valid and all(
        "effect_id" not in expected_item or packaging_effect_id(content, track.get("segments", [None])[0]) == str(expected_item.get("effect_id"))
        for track, expected_item in zip(sorted(effect_tracks, key=lambda item: item.get("name", "")), effect_segments)
    )
    return {
        "stage": "validate_tracks",
        "exception_type": "ValidationError",
        "actual_duration_us": actual_duration,
        "expected_duration_us": expected_duration,
        "duration_within_frame": isinstance(actual_duration, int) and isinstance(expected_duration, int) and frame_tolerance_us is not None and abs(actual_duration - expected_duration) <= frame_tolerance_us,
        "actual_tracks": [
            {
                "name": track.get("name"),
                "type": track.get("type"),
                "segment_count": len(track.get("segments", []))
                if isinstance(track.get("segments"), list)
                else None,
            }
            for track in tracks
            if isinstance(track, dict)
        ] if isinstance(tracks, list) else None,
        "expected_counts": {
            "video": len(expected.get("video_segments") or []),
            "voiceover": len(expected.get("voiceover_segments") or []),
            "caption": len(expected.get("caption_segments") or []),
            "title": len(expected.get("title_segments") or []),
            "sfx": len(expected.get("sfx_segments") or []),
            "effect": len(expected.get("effect_segments") or []),
            "sticker": len(expected.get("sticker_segments") or []),
            "filter": len(expected.get("filter_segments") or []),
            "bgm": 1 if expected.get("bgm_path") else 0,
        },
        "overlay_tracks_valid": overlay_diagnostic.get("valid") if overlay_diagnostic else None,
        "overlay_track_count": overlay_diagnostic.get("track_count") if overlay_diagnostic else None,
        "overlay_failure_reason": overlay_diagnostic.get("reason") if overlay_diagnostic else None,
        "video_fade_material_count": len(content.get("materials", {}).get("audio_fades", [])) if isinstance(content.get("materials"), dict) and isinstance(content.get("materials", {}).get("audio_fades"), list) else None,
        "expected_video_fade_count": sum(1 for segment in (expected.get("video_segments") or []) if segment.get("fade_in_us", 0) or segment.get("fade_out_us", 0)),
        "video_segments_valid": validate_track_segments(by_name.get("video-primary", {}).get("segments"), expected.get("video_segments") or [], True, frame_tolerance_us or 0),
        "video_fades_valid": validate_video_fades(content, by_name.get("video-primary"), expected.get("video_segments") or []),
        "voiceover_segments_valid": validate_track_segments(by_name.get("voiceover-primary", {}).get("segments"), expected.get("voiceover_segments") or [], False, frame_tolerance_us or 0) if expected.get("voiceover_segments") else None,
        "caption_segments_valid": validate_target_segments(by_name.get("caption-primary", {}).get("segments"), expected.get("caption_segments") or [], frame_tolerance_us or 0) if expected.get("caption_segments") else None,
        "bgm_segments_valid": validate_track_segments(by_name.get("bgm-primary", {}).get("segments"), [{"target_start_us": 0, "target_duration_us": expected_duration}], False, frame_tolerance_us or 0) if expected.get("bgm_path") and isinstance(expected_duration, int) else None,
        "title_segments_valid": validate_target_segments(title_track.get("segments"), title_segments) if isinstance(title_track, dict) else None,
        "text_animations_valid": validate_text_animation_segments(content, title_track, text_animation_segments) if isinstance(title_track, dict) else None,
        "text_keyframes_valid": validate_text_keyframe_segments(title_track, text_keyframe_segments) if isinstance(title_track, dict) else None,
        "sticker_keyframes_valid": validate_sticker_keyframe_segments(by_name, sticker_segments) if sticker_segments else None,
        "effect_tracks_valid": validate_packaging_tracks(content, by_name, effect_segments, "effect", "effect", allow_subset=not expected.get("effect_segments_resolved", False)) if effect_segments else None,
        "effect_shape_valid": effect_shape_valid if effect_segments else None,
        "effect_range_valid": effect_range_valid if effect_segments else None,
        "effect_resource_valid": effect_resource_valid if effect_segments else None,
        "effect_id_valid": effect_id_valid if effect_segments else None,
        "animation_segments_valid": validate_animation_segments(content, by_name.get("video-primary"), expected.get("video_segments") or [], animation_segments, frame_tolerance_us or 0) if animation_segments else None,
        "mask_segments_valid": validate_mask_segments(content, by_name.get("video-primary"), expected.get("video_segments") or [], mask_segments, frame_tolerance_us or 0) if mask_segments else None,
        "blend_segments_valid": validate_blend_segments(content, by_name.get("video-primary"), expected.get("video_segments") or [], blend_segments, frame_tolerance_us or 0) if blend_segments else None,
    }


def apply_video_keyframes(draft, video_segment, keyframes):
    if not keyframes:
        return
    for keyframe in keyframes:
        if not isinstance(keyframe, dict):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        capability = keyframe.get("capability_id")
        offset = keyframe.get("offset_us")
        value = keyframe.get("value")
        if not isinstance(offset, int) or offset < 0:
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if capability == "transform.scale":
            if not isinstance(value, (int, float)):
                fail("JY002_DRAFT_STRUCTURE_INVALID")
            video_segment.add_keyframe(draft.KeyframeProperty.uniform_scale, offset, float(value))
        elif capability == "transform.position":
            if not isinstance(value, dict) or "x" not in value or "y" not in value:
                fail("JY002_DRAFT_STRUCTURE_INVALID")
            video_segment.add_keyframe(draft.KeyframeProperty.position_x, offset, float(value["x"]))
            video_segment.add_keyframe(draft.KeyframeProperty.position_y, offset, float(value["y"]))
        elif capability == "opacity":
            if not isinstance(value, (int, float)):
                fail("JY002_DRAFT_STRUCTURE_INVALID")
            video_segment.add_keyframe(draft.KeyframeProperty.alpha, offset, float(value))
        elif capability == "transform.rotation":
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                fail("JY002_DRAFT_STRUCTURE_INVALID")
            video_segment.add_keyframe(draft.KeyframeProperty.rotation, offset, float(value))
        else:
            fail("JY004_CAPABILITY_UNSUPPORTED")


def apply_text_keyframes(draft, text_segment, keyframes):
    if not isinstance(keyframes, list):
        fail("JY084_TEXT_KEYFRAME_STRUCTURE_INVALID")
    previous_offset = -1
    for keyframe in keyframes:
        if (
            not isinstance(keyframe, dict)
            or set(keyframe.keys()) != {"capability_id", "offset_us", "value", "interpolation"}
            or keyframe.get("capability_id") != "transform.text.keyframe"
            or not isinstance(keyframe.get("offset_us"), int)
            or keyframe["offset_us"] < 0
            or keyframe["offset_us"] > text_segment.duration
            or keyframe["offset_us"] <= previous_offset
            or not isinstance(keyframe.get("value"), (int, float))
            or isinstance(keyframe.get("value"), bool)
            or not 0.1 <= float(keyframe["value"]) <= 10
            or keyframe.get("interpolation") != "linear"
        ):
            fail("JY084_TEXT_KEYFRAME_STRUCTURE_INVALID")
        text_segment.add_keyframe(draft.KeyframeProperty.uniform_scale, keyframe["offset_us"], float(keyframe["value"]))
        previous_offset = keyframe["offset_us"]


def apply_sticker_keyframes(draft, sticker_segment, keyframes, duration_us):
    validate_sticker_segment({
        "resource_id": "validated-sticker",
        "target_start_us": 0,
        "target_duration_us": duration_us,
        "keyframes": keyframes,
    })
    for keyframe in keyframes:
        sticker_segment.add_keyframe(draft.KeyframeProperty.uniform_scale, keyframe["offset_us"], float(keyframe["value"]))


def build_text_segment(draft, segment, default_size, default_transform_y):
    style = segment.get("style") if isinstance(segment.get("style"), dict) else None
    size = float(style["size"]) if style and isinstance(style.get("size"), (int, float)) else default_size
    color = tuple(style["color"]) if style and isinstance(style.get("color"), list) and len(style["color"]) == 3 else (1.0, 1.0, 1.0)
    transform_x = float(style["transformX"]) if style and isinstance(style.get("transformX"), (int, float)) else 0.0
    transform_y = float(style["transformY"]) if style and isinstance(style.get("transformY"), (int, float)) else default_transform_y
    auto_wrapping = style.get("autoWrapping") is True if style else False
    max_line_width = float(style["maxLineWidth"]) if style and isinstance(style.get("maxLineWidth"), (int, float)) else 0.82
    return draft.TextSegment(
        segment["text"],
        draft.Timerange(segment["target_start_us"], segment["target_duration_us"]),
        style=draft.TextStyle(size=size, color=color, align=1, auto_wrapping=auto_wrapping, max_line_width=max_line_width),
        clip_settings=draft.ClipSettings(transform_x=transform_x, transform_y=transform_y),
    )


def apply_audio_fade(audio_segment, segment):
    fade_in = segment.get("fade_in_us", 0)
    fade_out = segment.get("fade_out_us", 0)
    duration = segment.get("target_duration_us")
    if (
        not isinstance(fade_in, int)
        or isinstance(fade_in, bool)
        or not isinstance(fade_out, int)
        or isinstance(fade_out, bool)
        or fade_in < 0
        or fade_out < 0
        or not isinstance(duration, int)
        or fade_in > duration
        or fade_out > duration
    ):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if fade_in or fade_out:
        audio_segment.add_fade(fade_in, fade_out)


def video_fade_parameters(segment):
    fade_in = segment.get("fade_in_us", 0)
    fade_out = segment.get("fade_out_us", 0)
    duration = segment.get("target_duration_us")
    if (
        not isinstance(fade_in, int) or isinstance(fade_in, bool)
        or not isinstance(fade_out, int) or isinstance(fade_out, bool)
        or fade_in < 0 or fade_out < 0 or not isinstance(duration, int)
        or fade_in > duration or fade_out > duration
    ):
        fail("JY074_VIDEO_FADE_STRUCTURE_INVALID")
    return fade_in, fade_out


def apply_video_fade(video_segment, segment):
    fade_in, fade_out = video_fade_parameters(segment)
    if fade_in or fade_out:
        video_segment.add_fade(fade_in, fade_out)


def normalize_video_fade_materials(content):
    materials = content.get("materials")
    fades = materials.get("audio_fades") if isinstance(materials, dict) else None
    videos = materials.get("videos") if isinstance(materials, dict) else None
    tracks = content.get("tracks")
    video_track = next((track for track in tracks if isinstance(track, dict) and track.get("name") == "video-primary"), None) if isinstance(tracks, list) else None
    segments = video_track.get("segments") if isinstance(video_track, dict) else None
    if not isinstance(fades, list) or not isinstance(videos, list) or not isinstance(segments, list):
        return
    for segment in segments:
        refs = segment.get("extra_material_refs") if isinstance(segment, dict) else None
        if not isinstance(refs, list):
            continue
        attached = [fade for fade in fades if isinstance(fade, dict) and fade.get("type") == "audio_fade" and fade.get("id") in refs]
        if not attached:
            continue
        if len(attached) != 1:
            fail("JY074_VIDEO_FADE_STRUCTURE_INVALID")
        fade = attached[0]
        old_id = fade.get("id")
        new_id = str(uuid.uuid4()).upper()
        fade["id"] = new_id
        fade.pop("fade_type", None)
        segment["extra_material_refs"] = [new_id if ref == old_id else ref for ref in refs]
        matches = [video for video in videos if isinstance(video, dict) and video.get("id") == segment.get("material_id")]
        if len(matches) != 1:
            fail("JY074_VIDEO_FADE_STRUCTURE_INVALID")
        matches[0]["audio_fade"] = deepcopy(fade)


def apply_audio_keyframes(audio_segment, keyframes, duration_us):
    if not isinstance(keyframes, list):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    previous_offset = -1
    for keyframe in keyframes:
        if not isinstance(keyframe, dict):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if keyframe.get("capability_id") != "audio.volume.keyframe":
            fail("JY004_CAPABILITY_UNSUPPORTED")
        offset = keyframe.get("offset_us")
        value = keyframe.get("value")
        if (
            not isinstance(offset, int)
            or isinstance(offset, bool)
            or offset < 0
            or offset > duration_us
            or offset <= previous_offset
            or not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(value)
            or value < 0
            or value > 1
            or keyframe.get("interpolation") != "linear"
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        audio_segment.add_keyframe(offset, float(value))
        previous_offset = offset


def apply_video_transition(draft, video_segment, transition_out):
    if not transition_out:
        return
    if not isinstance(transition_out, dict):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    capability = transition_out.get("capability_id")
    duration = transition_out.get("duration_us")
    transition_name = transition_out.get("transition_name")
    if capability in (None, "transition.cut", "transition.none"):
        return
    if capability != "transition.dissolve":
        fail("JY004_CAPABILITY_UNSUPPORTED")
    if not isinstance(duration, int) or duration <= 0 or not isinstance(transition_name, str) or not transition_name:
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    transition_type = getattr(draft.TransitionType, transition_name, None)
    if transition_type is None:
        fail("JY004_TRANSITION_TOKEN_UNRESOLVED")
    video_segment.add_transition(transition_type, duration=duration)


def find_effect_type(draft, resource_id):
    for effect_enum in (
        draft.VideoSceneEffectType,
        draft.VideoCharacterEffectType,
    ):
        members = getattr(effect_enum, "__members__", None)
        candidates = members.values() if isinstance(members, dict) else vars(effect_enum).values()
        for member in candidates:
            value = getattr(member, "value", None)
            if str(getattr(value, "resource_id", "")) == str(resource_id):
                return member
    return None


def create_dynamic_effect_segment(draft, segment):
    members = getattr(draft.VideoSceneEffectType, "__members__", None)
    candidates = members.values() if isinstance(members, dict) else vars(draft.VideoSceneEffectType).values()
    placeholder = next((member for member in candidates if getattr(member, "value", None) is not None), None)
    if placeholder is None:
        fail("JY004_EFFECT_UNRESOLVED")
    effect_segment = draft.EffectSegment(
        placeholder,
        draft.Timerange(segment["target_start_us"], segment["target_duration_us"]),
    )
    effect = getattr(effect_segment, "effect_inst", None)
    if effect is None:
        fail("JY004_EFFECT_UNRESOLVED")
    effect.name = "OpenVideo local video effect"
    effect.resource_id = segment["resource_id"]
    effect.effect_id = segment["effect_id"]
    effect.effect_type = "video_effect"
    effect.apply_target_type = 2
    effect.adjust_params = []
    return effect_segment


def find_filter_type(draft, resource_id):
    members = getattr(draft.FilterType, "__members__", None)
    candidates = members.values() if isinstance(members, dict) else vars(draft.FilterType).values()
    for member in candidates:
        value = getattr(member, "value", None)
        if str(getattr(value, "resource_id", "")) == str(resource_id):
            return member
    return None


def find_animation_type(draft, resource_id):
    for animation_enum in (draft.IntroType, draft.OutroType, draft.GroupAnimationType):
        for member in getattr(animation_enum, "__members__", {}).values():
            if str(getattr(getattr(member, "value", None), "resource_id", "")) == str(resource_id):
                return member
    return None


def find_text_animation_type(draft, resource_id):
    for animation_enum in (draft.TextIntro, draft.TextOutro, draft.TextLoopAnim):
        for member in getattr(animation_enum, "__members__", {}).values():
            if str(getattr(getattr(member, "value", None), "resource_id", "")) == str(resource_id):
                return member
    return None


def add_animation_segments(draft, script, video_segments, animation_segments):
    for segment in animation_segments:
        animation_type = find_animation_type(draft, segment["resource_id"])
        if animation_type is None:
            fail("JY044_ANIMATION_UNRESOLVED")
        matches = [video for video in video_segments if video[0] == segment["target_start_us"] and video[1] == segment["target_duration_us"]]
        if len(matches) != 1:
            fail("JY044_ANIMATION_TARGET_UNRESOLVED")
        video = matches[0][2]
        video.add_animation(animation_type, duration=segment["duration_us"])
        if video.animations_instance is not None and video.animations_instance not in script.materials:
            script.materials.animations.append(video.animations_instance)


def add_blend_segments(draft, script, video_segments, blend_segments):
    for segment in blend_segments:
        mode = next((member for member in getattr(draft.MixModeType, "__members__", {}).values() if str(getattr(getattr(member, "value", None), "resource_id", "")) == str(segment["resource_id"])), None)
        if mode is None:
            fail("JY046_BLEND_UNRESOLVED")
        matches = [video for video in video_segments if video[0] == segment["target_start_us"] and video[1] == segment["target_duration_us"]]
        if len(matches) != 1:
            fail("JY046_BLEND_TARGET_UNRESOLVED")
        video = matches[0][2]
        video.set_mix_mode(mode)
        if video.mix_modes and video.mix_modes[-1] not in script.materials.mix_modes:
            script.materials.mix_modes.append(video.mix_modes[-1])


def find_mask_type(draft, resource_id):
    for member in getattr(draft.MaskType, "__members__", {}).values():
        if str(getattr(getattr(member, "value", None), "resource_id", "")) == str(resource_id):
            return member
    return None


def add_mask_segments(draft, script, video_segments, mask_segments):
    for segment in mask_segments:
        if isinstance(segment.get("common_mask_template"), dict):
            continue
        mask_type = find_mask_type(draft, segment["resource_id"])
        if mask_type is None:
            fail("JY045_MASK_UNRESOLVED")
        matches = [video for video in video_segments if video[0] == segment["target_start_us"] and video[1] == segment["target_duration_us"]]
        if len(matches) != 1:
            fail("JY045_MASK_TARGET_UNRESOLVED")
        video = matches[0][2]
        video.add_mask(mask_type, center_x=segment["center_x"], center_y=segment["center_y"], size=segment["size"], rotation=segment["rotation"], feather=segment["feather"], invert=segment["invert"])
        if video.mask is not None and video.mask not in script.materials.masks:
            script.materials.masks.append(video.mask.export_json())


def add_filter_segments(draft, script, video_segments, filter_segments, inserted_tracks=None):
    for index, segment in enumerate(filter_segments):
        filter_type = find_filter_type(draft, segment["resource_id"])
        if filter_type is None:
            fail("JY016_FILTER_UNRESOLVED")
        if segment["capability_id"] == "filter.video.named":
            matches = [
                video_segment
                for video_segment in video_segments
                if video_segment[0] == segment["target_start_us"]
                and video_segment[1] == segment["target_duration_us"]
            ]
            if len(matches) != 1:
                fail("JY016_FILTER_TARGET_UNRESOLVED")
            matches[0][2].add_filter(filter_type, float(segment["intensity"]))
            # The upstream API adds a segment-level filter after the video
            # segment has already been registered with the script. Register
            # the newly-created material explicitly so draft_content.json
            # persists the filter catalog entry as well.
            filter_instances = getattr(matches[0][2], "filters", None)
            if filter_instances and hasattr(script, "materials"):
                filter_material = filter_instances[-1]
                if filter_material not in script.materials.filters:
                    script.materials.filters.append(filter_material)
            continue
        track_name = f"filter-{index + 1}"
        track = (inserted_tracks or {}).get(track_name)
        if track is None:
            track = script.append_track(draft.TrackSpec(draft.TrackType.filter, track_name))
        script.add_filter(
            filter_type,
            draft.Timerange(segment["target_start_us"], segment["target_duration_us"]),
            track,
            float(segment["intensity"]),
        )


def add_packaging_segments(draft, script, effect_segments, sticker_segments, inserted_tracks=None):
    for index, segment in enumerate(sticker_segments):
        track_name = f"sticker-{index + 1}"
        track = (inserted_tracks or {}).get(track_name)
        if track is None:
            track = script.append_track(draft.TrackSpec(draft.TrackType.sticker, track_name))
        sticker_segment = draft.StickerSegment(
                segment["resource_id"],
                draft.Timerange(
                    segment["target_start_us"],
                    segment["target_duration_us"],
                ),
            )
        apply_sticker_keyframes(
            draft,
            sticker_segment,
            segment.get("keyframes", []),
            segment["target_duration_us"],
        )
        script.add_segment(sticker_segment, track)

    resolved_effects = []
    for segment in effect_segments:
        effect_type = find_effect_type(draft, segment["resource_id"])
        expected_effect_id = segment.get("effect_id")
        if effect_type is not None and expected_effect_id is not None and str(getattr(effect_type.value, "effect_id", "")) != expected_effect_id:
            fail("JY004_EFFECT_BINDING_MISMATCH")
        if effect_type is None and expected_effect_id is None:
            fail("JY004_EFFECT_UNRESOLVED")
        resolved_effects.append(segment)
        track_name = f"effect-{len(resolved_effects)}"
        track = (inserted_tracks or {}).get(track_name)
        if track is None:
            track = script.append_track(draft.TrackSpec(draft.TrackType.effect, track_name))
        effect_segment = create_dynamic_effect_segment(draft, segment) if effect_type is None else draft.EffectSegment(
                effect_type,
                draft.Timerange(
                    segment["target_start_us"],
                    segment["target_duration_us"],
                ),
            )
        script.add_segment(effect_segment, track)
        effect_material = getattr(effect_segment, "effect_inst", None)
        video_effects = getattr(getattr(script, "materials", None), "video_effects", None)
        if effect_material is None or not isinstance(video_effects, list):
            fail("JY004_EFFECT_UNRESOLVED")
        if effect_material not in video_effects:
            video_effects.append(effect_material)
    return resolved_effects


def validate_bgm_stream(stream):
    return (
        isinstance(stream, dict)
        and require_keys(stream, ["extension", "size", "sha256"])
        and stream["extension"] in BGM_EXTENSIONS
        and isinstance(stream["size"], int)
        and not isinstance(stream["size"], bool)
        and 0 < stream["size"] <= MAX_BGM_BYTES
        and isinstance(stream["sha256"], str)
        and len(stream["sha256"]) == 64
        and all(character in "0123456789abcdef" for character in stream["sha256"])
    )


def import_bgm_stream(staging_path, final_path, stream):
    assets_path = staging_path / ".openvideo-assets"
    assets_path.mkdir(mode=0o700, exist_ok=False)
    reject_reparse(assets_path)
    filename = f"bgm{stream['extension']}"
    staging_asset = resolve_child(assets_path, filename)
    final_asset = final_path / ".openvideo-assets" / filename
    digest = hashlib.sha256()
    remaining = stream["size"]
    with open(staging_asset, "xb") as handle:
        while remaining > 0:
            chunk = sys.stdin.buffer.read(min(1024 * 1024, remaining))
            if not chunk:
                fail("JY002_DRAFT_WRITE_FAILED")
            handle.write(chunk)
            digest.update(chunk)
            remaining -= len(chunk)
        if sys.stdin.buffer.read(1):
            fail("JY002_DRAFT_WRITE_FAILED")
        handle.flush()
        os.fsync(handle.fileno())
    reject_reparse(staging_asset)
    if staging_asset.stat().st_size != stream["size"] or digest.hexdigest() != stream["sha256"]:
        fail("JY002_DRAFT_WRITE_FAILED")
    return str(staging_asset), str(final_asset)


def validate_bgm_asset(actual_draft_path, final_draft_path, payload):
    expected_path = payload.get("bgm_path")
    expected_size = payload.get("bgm_size")
    expected_sha256 = payload.get("bgm_sha256")
    if expected_path is None:
        return expected_size is None and expected_sha256 is None
    if not isinstance(expected_path, str) or not os.path.isabs(expected_path):
        return False
    if expected_size is None and expected_sha256 is None:
        return os.path.isfile(expected_path)
    if (
        not isinstance(expected_size, int)
        or isinstance(expected_size, bool)
        or expected_size <= 0
        or not isinstance(expected_sha256, str)
        or len(expected_sha256) != 64
    ):
        return False
    expected = Path(expected_path)
    expected_assets = final_draft_path / ".openvideo-assets"
    if expected.parent.resolve() != expected_assets.resolve() or expected.suffix not in BGM_EXTENSIONS:
        return False
    actual_assets = actual_draft_path / ".openvideo-assets"
    actual = actual_assets / expected.name
    try:
        reject_reparse(actual_assets)
        reject_reparse(actual)
        if not actual.is_file() or actual.stat().st_size != expected_size:
            return False
        digest = hashlib.sha256()
        with open(actual, "rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
        return digest.hexdigest() == expected_sha256
    except OSError:
        return False


def write_draft(payload):
    required = [
        "action",
        "draft_root",
        "staging_name",
        "draft_id",
        "draft_label",
        "owner_id",
        "request_id",
        "width",
        "height",
        "fps",
        "duration_us",
        "video_segments",
        "voiceover_segments",
        "caption_segments",
        "title_segments",
        "subtitle_style",
        "bgm_path",
        "bgm_stream",
        "bgm_volume",
    ]
    if not isinstance(payload, dict) or any(key not in payload for key in required):
        fail("JY002_DRAFT_WRITE_FAILED")
    if not valid_bundle_fingerprint(payload.get("bundle_fingerprint")):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if (
        not safe_name(payload["staging_name"])
        or not safe_name(payload["draft_id"])
        or not safe_draft_label(payload["draft_label"])
        or not safe_name(payload["owner_id"])
        or not safe_name(payload["request_id"])
    ):
        fail("JY002_PATH_PERMISSION_DENIED")
    if (
        not isinstance(payload["duration_us"], int)
        or payload["duration_us"] <= 0
        or not isinstance(payload["width"], int)
        or payload["width"] <= 0
        or not isinstance(payload["height"], int)
        or payload["height"] <= 0
        or not isinstance(payload["fps"], int)
        or payload["fps"] <= 0
        or payload["width"] > MAX_DIMENSION
        or payload["height"] > MAX_DIMENSION
        or payload["fps"] > 120
    ):
        fail("JY002_DRAFT_WRITE_FAILED")
    root = Path(payload["draft_root"])
    if not root.is_absolute():
        fail("JY002_PATH_PERMISSION_DENIED")
    video_segments = payload["video_segments"]
    voiceover_segments = payload["voiceover_segments"]
    caption_segments = payload["caption_segments"]
    title_segments = payload["title_segments"]
    subtitle_style = payload["subtitle_style"]
    bgm_path = payload["bgm_path"]
    bgm_stream = payload["bgm_stream"]
    bgm_volume = payload["bgm_volume"]
    bgm_fade = payload.get("bgm_fade", {"fade_in_us": 0, "fade_out_us": 0})
    sfx_segments = payload.get("sfx_segments") or []
    sfx_track_names = payload.get("sfx_track_names") or []
    effect_segments = payload.get("effect_segments") or []
    sticker_segments = payload.get("sticker_segments") or []
    filter_segments = payload.get("filter_segments") or []
    animation_segments = payload.get("animation_segments") or []
    text_animation_segments = payload.get("text_animation_segments") or []
    blend_segments = payload.get("blend_segments") or []
    mask_segments = payload.get("mask_segments") or []
    background_segments = payload.get("background_segments") or []
    chroma_segments = payload.get("chroma_segments") or []
    text_keyframe_segments = [
        {"target_start_us": segment["target_start_us"], "target_duration_us": segment["target_duration_us"], "keyframes": segment.get("keyframes") or []}
        for segment in title_segments if isinstance(segment, dict) and segment.get("keyframes")
    ]
    validate_segment_count(video_segments, voiceover_segments)
    validate_duration(payload["duration_us"])
    if not isinstance(caption_segments, list) or len(caption_segments) > 100:
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not isinstance(title_segments, list) or len(title_segments) > MAX_TITLE_SEGMENTS:
        fail("JY002_DRAFT_STRUCTURE_INVALID", {
            "stage": "validate_counts",
            "exception_type": "ValidationError",
            "reason": "title_segment_count",
            "count": len(title_segments) if isinstance(title_segments, list) else None,
            "max": MAX_TITLE_SEGMENTS,
        })
    if not isinstance(sfx_segments, list) or len(sfx_segments) > MAX_SFX_SEGMENTS:
        fail("JY002_DRAFT_STRUCTURE_INVALID", {
            "stage": "validate_counts",
            "exception_type": "ValidationError",
            "reason": "sfx_segment_count",
            "count": len(sfx_segments) if isinstance(sfx_segments, list) else None,
            "max": MAX_SFX_SEGMENTS,
        })
    if (
        not isinstance(sfx_track_names, list)
        or (sfx_track_names and len(sfx_track_names) != len(sfx_segments))
        or any(
            not isinstance(name, str)
            or not re.fullmatch(r"sfx-(?:primary|[2-9][0-9]*)", name)
            for name in sfx_track_names
        )
    ):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not isinstance(effect_segments, list) or len(effect_segments) > 32:
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not isinstance(sticker_segments, list) or len(sticker_segments) > 32:
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not isinstance(filter_segments, list) or len(filter_segments) > 32:
        fail("JY016_FILTER_STRUCTURE_INVALID")
    if not isinstance(animation_segments, list) or len(animation_segments) > 32:
        fail("JY044_ANIMATION_STRUCTURE_INVALID")
    if not isinstance(blend_segments, list) or len(blend_segments) > 32:
        fail("JY046_BLEND_STRUCTURE_INVALID")
    if not isinstance(mask_segments, list) or len(mask_segments) > 32:
        fail("JY045_MASK_STRUCTURE_INVALID")
    if not isinstance(background_segments, list) or len(background_segments) > MAX_SEGMENTS:
        fail("JY062_BACKGROUND_STRUCTURE_INVALID")
    if not isinstance(chroma_segments, list) or len(chroma_segments) > MAX_SEGMENTS:
        fail("JY082_CHROMA_STRUCTURE_INVALID")
    chroma_ranges = set()
    video_ranges = {(item.get("target_start_us"), item.get("target_duration_us")) for item in video_segments if isinstance(item, dict)}
    for segment in chroma_segments:
        if not isinstance(segment, dict) or set(segment.keys()) != {"color", "intensity", "shadow", "edge_smooth", "spill", "target_start_us", "target_duration_us"} or not isinstance(segment["color"], str) or not re.fullmatch(r"#[0-9A-Fa-f]{8}", segment["color"]) or not all(isinstance(segment[key], (int, float)) and not isinstance(segment[key], bool) and math.isfinite(segment[key]) and 0 <= segment[key] <= 100 for key in ("intensity", "shadow", "edge_smooth", "spill")) or not isinstance(segment["target_start_us"], int) or not isinstance(segment["target_duration_us"], int) or segment["target_start_us"] < 0 or segment["target_duration_us"] <= 0:
            fail("JY082_CHROMA_STRUCTURE_INVALID")
        target_range = (segment["target_start_us"], segment["target_duration_us"])
        if target_range in chroma_ranges or target_range not in video_ranges:
            fail("JY082_CHROMA_DUPLICATE")
        chroma_ranges.add(target_range)
    for segment in background_segments:
        if not isinstance(segment, dict) or set(segment.keys()) != {"fill_type", "blur", "color", "target_start_us", "target_duration_us"} or segment["fill_type"] not in ("blur", "color") or not isinstance(segment["blur"], (int, float)) or isinstance(segment["blur"], bool) or not math.isfinite(segment["blur"]) or not 0 <= segment["blur"] <= 1 or not isinstance(segment["color"], str) or not re.fullmatch(r"#[0-9A-Fa-f]{8}", segment["color"]) or not isinstance(segment["target_start_us"], int) or not isinstance(segment["target_duration_us"], int) or segment["target_start_us"] < 0 or segment["target_duration_us"] <= 0:
            fail("JY062_BACKGROUND_STRUCTURE_INVALID")
    if subtitle_style not in ["default", "bottom_safe"]:
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if bgm_path is not None and (
        not isinstance(bgm_path, str) or not os.path.isabs(bgm_path) or not os.path.isfile(bgm_path)
    ):
        fail("JY002_MATERIAL_AUTHORIZATION_EXPIRED", {"stage": "validate_media", "exception_type": "missing_bgm_media"})
    if bgm_stream is not None and (bgm_path is not None or not validate_bgm_stream(bgm_stream)):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if (
        not isinstance(bgm_volume, (int, float))
        or isinstance(bgm_volume, bool)
        or bgm_volume < 0
        or bgm_volume > 1
    ):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    if not require_keys(bgm_fade, ["fade_in_us", "fade_out_us"]):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    for segment in video_segments:
        required_video_keys = {
            "path",
            "source_start_us",
            "source_duration_us",
            "target_start_us",
            "target_duration_us",
        }
        optional_video_keys = {"speed", "transition_out", "keyframes", "fade_in_us", "fade_out_us"}
        if (
            not isinstance(segment, dict)
            or not required_video_keys.issubset(segment.keys())
            or not set(segment.keys()).issubset(required_video_keys | optional_video_keys)
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        validate_segment(segment, ["path", "target_start_us", "target_duration_us"])
        video_fade_parameters(segment)
        speed = segment.get("speed", {"numerator": 1, "denominator": 1})
        if (
            not require_keys(speed, ["numerator", "denominator"])
            or isinstance(speed["numerator"], bool)
            or isinstance(speed["denominator"], bool)
            or not isinstance(speed["numerator"], int)
            or not isinstance(speed["denominator"], int)
            or speed["numerator"] <= 0
            or speed["denominator"] <= 0
            or not 0.25 <= speed["numerator"] / speed["denominator"] <= 4
        ):
            fail("JY066_SPEED_INVALID")
    for segment in voiceover_segments:
        validate_segment(segment, ["path", "target_start_us", "target_duration_us"])
    for segment in caption_segments:
        if (
            not isinstance(segment, dict)
            or "text" not in segment
            or "target_start_us" not in segment
            or "target_duration_us" not in segment
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if not valid_text_style(segment.get("style")):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if (
            not isinstance(segment["text"], str)
            or not segment["text"].strip()
            or not isinstance(segment["target_start_us"], int)
            or segment["target_start_us"] < 0
            or not isinstance(segment["target_duration_us"], int)
            or segment["target_duration_us"] <= 0
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
    for segment in title_segments:
        if (
            not isinstance(segment, dict)
            or "text" not in segment
            or "target_start_us" not in segment
            or "target_duration_us" not in segment
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        flower_effect_id = segment.get("flower_effect_id")
        flower_resource_id = segment.get("flower_resource_id")
        bubble_effect_id = segment.get("bubble_effect_id")
        bubble_resource_id = segment.get("bubble_resource_id")
        if flower_effect_id is not None and (
            not isinstance(flower_effect_id, str)
            or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", flower_effect_id)
            or (
                flower_resource_id is not None
                and (
                    not isinstance(flower_resource_id, str)
                    or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", flower_resource_id)
                )
            )
            or bubble_effect_id is not None
            or bubble_resource_id is not None
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if flower_resource_id is not None and flower_effect_id is None:
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if (bubble_effect_id is None) != (bubble_resource_id is None):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if bubble_effect_id is not None and (
            not isinstance(bubble_effect_id, str)
            or not isinstance(bubble_resource_id, str)
            or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", bubble_effect_id)
            or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", bubble_resource_id)
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if (
            not isinstance(segment["text"], str)
            or not segment["text"].strip()
            or not isinstance(segment["target_start_us"], int)
            or segment["target_start_us"] < 0
            or not isinstance(segment["target_duration_us"], int)
            or segment["target_duration_us"] <= 0
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if not valid_text_style(segment.get("style")):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
    for segment in sfx_segments:
        if (
            not isinstance(segment, dict)
            or "path" not in segment
            or "target_start_us" not in segment
            or "target_duration_us" not in segment
        ):
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        if (
            not isinstance(segment["path"], str)
            or not os.path.isabs(segment["path"])
            or not os.path.isfile(segment["path"])
            or not isinstance(segment["target_start_us"], int)
            or segment["target_start_us"] < 0
            or not isinstance(segment["target_duration_us"], int)
            or segment["target_duration_us"] <= 0
        ):
            fail("JY002_MATERIAL_AUTHORIZATION_EXPIRED", {"stage": "validate_media", "exception_type": "missing_sfx_media"})
        if "effect_resource_id" in segment and (
            not isinstance(segment["effect_resource_id"], str)
            or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["effect_resource_id"])
        ):
            fail("JY067_AUDIO_EFFECT_UNRESOLVED")
    for segment in effect_segments:
        validate_packaging_segment(segment)
    for segment in sticker_segments:
        validate_sticker_segment(segment)
    for segment in filter_segments:
        validate_filter_segment(segment)
    for segment in animation_segments:
        if not isinstance(segment, dict) or set(segment.keys()) != {"resource_id", "target_start_us", "target_duration_us", "duration_us"} or not isinstance(segment["resource_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["resource_id"]) or not isinstance(segment["target_start_us"], int) or not isinstance(segment["target_duration_us"], int) or not isinstance(segment["duration_us"], int) or segment["target_start_us"] < 0 or segment["target_duration_us"] <= 0 or segment["duration_us"] <= 0 or segment["duration_us"] > segment["target_duration_us"]:
            fail("JY044_ANIMATION_STRUCTURE_INVALID")
    title_ranges = {(segment["target_start_us"], segment["target_duration_us"]) for segment in title_segments if isinstance(segment, dict) and isinstance(segment.get("target_start_us"), int) and isinstance(segment.get("target_duration_us"), int)}
    if (text_animation_segments or text_keyframe_segments) and len(title_ranges) != len(title_segments):
        fail("JY084_TEXT_KEYFRAME_TARGET_INVALID", {"stage": "validate_text_binding", "exception_type": "duplicate_title_range", "title_range_count": len(title_ranges)})
    seen_text_animation_targets = set()
    for segment in text_animation_segments:
        if not isinstance(segment, dict) or set(segment.keys()) != {"target_segment_id", "resource_id", "duration_us", "target_start_us", "target_duration_us"} or not isinstance(segment["target_segment_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,160}", segment["target_segment_id"]) or not isinstance(segment["resource_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["resource_id"]) or not isinstance(segment["duration_us"], int) or segment["duration_us"] <= 0 or not isinstance(segment["target_start_us"], int) or not isinstance(segment["target_duration_us"], int) or segment["target_start_us"] < 0 or segment["target_duration_us"] <= 0:
            fail("JY083_TEXT_ANIMATION_STRUCTURE_INVALID")
        target_range = (segment["target_start_us"], segment["target_duration_us"])
        if target_range not in title_ranges or segment["duration_us"] > target_range[1] or target_range in seen_text_animation_targets:
            fail("JY083_TEXT_ANIMATION_TARGET_INVALID", {"stage": "validate_text_animation", "exception_type": "target_binding", "title_range_count": len(title_ranges), "target_start_us": target_range[0], "target_duration_us": target_range[1]})
        seen_text_animation_targets.add(target_range)
    for segment in blend_segments:
        if not isinstance(segment, dict) or set(segment.keys()) != {"resource_id", "target_start_us", "target_duration_us"} or not isinstance(segment["resource_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["resource_id"]) or not isinstance(segment["target_start_us"], int) or not isinstance(segment["target_duration_us"], int) or segment["target_start_us"] < 0 or segment["target_duration_us"] <= 0:
            fail("JY046_BLEND_STRUCTURE_INVALID")
    for segment in mask_segments:
        if not isinstance(segment, dict) or set(segment.keys()) not in ({"resource_id", "target_start_us", "target_duration_us", "center_x", "center_y", "size", "rotation", "feather", "invert"}, {"resource_id", "target_start_us", "target_duration_us", "center_x", "center_y", "size", "rotation", "feather", "invert", "common_mask_template"}) or not isinstance(segment["resource_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{4,80}", segment["resource_id"]) or not all(isinstance(segment[key], (int, float)) and not isinstance(segment[key], bool) and math.isfinite(segment[key]) for key in ("center_x", "center_y", "size", "rotation", "feather")) or not isinstance(segment["invert"], bool) or not isinstance(segment["target_start_us"], int) or not isinstance(segment["target_duration_us"], int) or segment["target_start_us"] < 0 or segment["target_duration_us"] <= 0 or not 0 < segment["size"] <= 1 or not 0 <= segment["feather"] <= 100 or ("common_mask_template" in segment and not validate_common_mask_template(segment["common_mask_template"])):
            fail("JY045_MASK_STRUCTURE_INVALID")

    resolved_effect_segments = []
    try:
        root.mkdir(parents=True, exist_ok=True)
        reject_reparse(root)
        staging_root = root / ".openvideo-staging"
        staging_root.mkdir(parents=True, exist_ok=True)
        reject_reparse(staging_root)
        final_path = resolve_child(root, payload["draft_id"])
        if final_path.exists():
            fail("JY002_OUTPUT_CONFLICT")
        staging_path = resolve_child(staging_root, payload["staging_name"])
        if staging_path.exists():
            fail("JY002_OUTPUT_CONFLICT")
    except OSError:
        fail("JY002_PATH_PERMISSION_DENIED")

    build_stage = "initialize"
    try:
        import pyJianYingDraft as draft

        folder = draft.DraftFolder(str(staging_root))
        script = folder.create_draft(
            payload["staging_name"],
            payload["width"],
            payload["height"],
            payload["fps"],
            maintrack_adsorb=True,
            allow_replace=False,
        )
        pending_owner_path = staging_owner_path(staging_root, payload["draft_id"])
        write_json_atomic(
            pending_owner_path,
            {
                "schema_version": 2,
                "owner_id": payload["owner_id"],
                "request_id": payload["request_id"],
                "draft_id": payload["draft_id"],
                "output_fingerprint": None,
                "phase": "staging",
            },
        )
        bgm_material_path = bgm_path
        expected_bgm_path = bgm_path
        if bgm_stream is not None:
            build_stage = "bgm_import"
            bgm_material_path, expected_bgm_path = import_bgm_stream(
                staging_path, final_path, bgm_stream
            )
        elif sys.stdin.buffer.read(1):
            fail("JY002_DRAFT_WRITE_FAILED")
        video_track = script.append_track(draft.TrackSpec(draft.TrackType.video, "video-primary"))
        optional_track_specs = []
        optional_track_names = []
        for enabled, track_type, track_name in (
            (bool(voiceover_segments), draft.TrackType.audio, "voiceover-primary"),
            (bool(caption_segments), draft.TrackType.text, "caption-primary"),
            (bool(title_segments), draft.TrackType.text, "title-primary"),
            (bool(bgm_path or bgm_stream), draft.TrackType.audio, "bgm-primary"),
            (False, draft.TrackType.audio, "sfx-primary"),
        ):
            if enabled:
                optional_track_specs.append(draft.TrackSpec(track_type, track_name))
                optional_track_names.append(track_name)
        resolved_sfx_track_names = list(dict.fromkeys(
            sfx_track_names or (["sfx-primary"] if sfx_segments else [])
        ))
        for track_name in resolved_sfx_track_names:
            optional_track_specs.append(draft.TrackSpec(draft.TrackType.audio, track_name))
            optional_track_names.append(track_name)
        for index, _segment in enumerate(effect_segments):
            optional_track_specs.append(draft.TrackSpec(draft.TrackType.effect, f"effect-{index + 1}"))
            optional_track_names.append(f"effect-{index + 1}")
        for index, _segment in enumerate(sticker_segments):
            optional_track_specs.append(draft.TrackSpec(draft.TrackType.sticker, f"sticker-{index + 1}"))
            optional_track_names.append(f"sticker-{index + 1}")
        for index, segment in enumerate(filter_segments):
            if segment.get("capability_id") != "filter.video.named":
                optional_track_specs.append(draft.TrackSpec(draft.TrackType.filter, f"filter-{index + 1}"))
                optional_track_names.append(f"filter-{index + 1}")
        inserted_by_name = create_optional_tracks(
            script,
            optional_track_specs,
            optional_track_names,
            payload.get("track_insertion_profile"),
            payload.get("track_insertion_capability"),
        )
        audio_track = inserted_by_name.get("voiceover-primary")
        caption_track = inserted_by_name.get("caption-primary")
        title_track = inserted_by_name.get("title-primary")
        bgm_track = inserted_by_name.get("bgm-primary")
        sfx_tracks = {
            track_name: inserted_by_name.get(track_name)
            for track_name in resolved_sfx_track_names
        }
        # Keep ordinary captions legible in the Jianying rich-text coordinate
        # system.  These defaults are only used when the canonical resolver
        # does not provide a segment-local style.
        caption_size = 7.8
        caption_y = -0.88
        build_stage = "video"
        written_video_segments = []
        for index, segment in enumerate(video_segments):
            material = draft.VideoMaterial(segment["path"], material_name=f"video-{index + 1}")
            available_duration_us = material.duration - segment["source_start_us"]
            if available_duration_us <= 0:
                raise ValueError("video source start exceeds material duration")
            source_duration_us = min(
                available_duration_us,
                segment["source_duration_us"],
            )
            speed = segment.get("speed")
            speed_options = (
                {"speed": speed["numerator"] / speed["denominator"]}
                if speed is not None
                else {}
            )
            video_segment = draft.VideoSegment(
                material,
                draft.Timerange(segment["target_start_us"], segment["target_duration_us"]),
                source_timerange=draft.Timerange(
                    segment["source_start_us"], source_duration_us
                ),
                **speed_options,
            )
            apply_video_keyframes(draft, video_segment, segment.get("keyframes") or [])
            apply_video_fade(video_segment, segment)
            apply_video_transition(draft, video_segment, segment.get("transition_out"))
            background = next((item for item in background_segments if item["target_start_us"] == segment["target_start_us"] and item["target_duration_us"] == segment["target_duration_us"]), None)
            if background is not None:
                video_segment.add_background_filling(background["fill_type"], background["blur"], background["color"])
            chroma = next((item for item in chroma_segments if item["target_start_us"] == segment["target_start_us"] and item["target_duration_us"] == segment["target_duration_us"]), None)
            if chroma is not None:
                video_segment.add_chroma(chroma["color"], chroma["intensity"], chroma["shadow"], chroma["edge_smooth"], chroma["spill"])
            script.add_segment(video_segment, video_track)
            written_video_segments.append((
                segment["target_start_us"],
                segment["target_duration_us"],
                video_segment,
            ))
        build_stage = "voiceover"
        for index, segment in enumerate(voiceover_segments):
            material = draft.AudioMaterial(segment["path"], material_name=f"voiceover-{index + 1}")
            source_duration_us = min(material.duration, segment["target_duration_us"])
            audio_segment = draft.AudioSegment(
                material,
                draft.Timerange(segment["target_start_us"], segment["target_duration_us"]),
                source_timerange=draft.Timerange(0, source_duration_us),
            )
            apply_audio_fade(audio_segment, segment)
            apply_audio_keyframes(audio_segment, segment.get("keyframes") or [], segment["target_duration_us"])
            script.add_segment(
                audio_segment,
                audio_track,
            )
        build_stage = "caption"
        for segment in caption_segments:
            script.add_segment(
                build_text_segment(draft, segment, caption_size, caption_y),
                caption_track,
            )
        build_stage = "title"
        for segment in title_segments:
            text_segment = build_text_segment(draft, segment, 8.0, 0.0)
            apply_text_keyframes(draft, text_segment, segment.get("keyframes") or [])
            if segment.get("flower_effect_id"):
                text_segment.add_effect(segment["flower_effect_id"])
                if segment.get("flower_resource_id"):
                    text_segment.effect.resource_id = segment["flower_resource_id"]
            elif segment.get("bubble_effect_id"):
                text_segment.add_bubble(
                    segment["bubble_effect_id"], segment["bubble_resource_id"]
                )
            # Some supported pyJianYingDraft/runtime combinations can leave
            # the same text-effect material reference twice. Jianying usually
            # tolerates it, but the result is version-dependent and can render
            # an effect more than once. Preserve order while enforcing the
            # canonical single-reference invariant.
            text_segment.extra_material_refs = list(dict.fromkeys(text_segment.extra_material_refs))
            text_animation = next((item for item in text_animation_segments if item["target_start_us"] == segment["target_start_us"] and item["target_duration_us"] == segment["target_duration_us"]), None)
            if text_animation is not None:
                animation_type = find_text_animation_type(draft, text_animation["resource_id"])
                if animation_type is None:
                    fail("JY083_TEXT_ANIMATION_UNRESOLVED")
                text_segment.add_animation(animation_type, duration=text_animation["duration_us"])
                if text_segment.animations_instance is not None and text_segment.animations_instance not in script.materials:
                    script.materials.animations.append(text_segment.animations_instance)
            script.add_segment(text_segment, title_track)
        build_stage = "sfx"
        for index, segment in enumerate(sfx_segments):
            material = draft.AudioMaterial(segment["path"], material_name=f"sfx-{index + 1}")
            volume = segment.get("volume", 1.0)
            if not isinstance(volume, (int, float)):
                volume = 1.0
            source_duration_us = min(segment["target_duration_us"], material.duration)
            audio_segment = draft.AudioSegment(
                material,
                draft.Timerange(segment["target_start_us"], segment["target_duration_us"]),
                source_timerange=draft.Timerange(0, source_duration_us),
                volume=float(volume),
            )
            if segment.get("effect_resource_id"):
                audio_segment.add_effect(resolve_audio_effect_meta(draft, segment["effect_resource_id"]))
            apply_audio_fade(audio_segment, segment)
            track_name = sfx_track_names[index] if sfx_track_names else "sfx-primary"
            sfx_track = sfx_tracks.get(track_name)
            if sfx_track is None:
                fail("JY002_DRAFT_STRUCTURE_INVALID")
            script.add_segment(audio_segment, sfx_track)
        build_stage = "packaging"
        resolved_effect_segments = add_packaging_segments(
            draft,
            script,
            effect_segments,
            sticker_segments,
            inserted_by_name,
        )
        add_filter_segments(draft, script, written_video_segments, filter_segments, inserted_by_name)
        add_animation_segments(draft, script, written_video_segments, animation_segments)
        add_blend_segments(draft, script, written_video_segments, blend_segments)
        add_mask_segments(draft, script, written_video_segments, mask_segments)
        build_stage = "bgm"
        if bgm_material_path:
            material = draft.AudioMaterial(bgm_material_path, material_name="bgm")
            bgm_segment = draft.AudioSegment(
                material,
                draft.Timerange(0, payload["duration_us"]),
                source_timerange=draft.Timerange(0, payload["duration_us"]),
                volume=float(bgm_volume),
            )
            apply_audio_fade(bgm_segment, {
                "target_duration_us": payload["duration_us"],
                "fade_in_us": bgm_fade.get("fade_in_us", 0) if isinstance(bgm_fade, dict) else None,
                "fade_out_us": bgm_fade.get("fade_out_us", 0) if isinstance(bgm_fade, dict) else None,
            })
            script.add_segment(
                bgm_segment,
                bgm_track,
            )
        build_stage = "save"
        script.save()
        content_path = staging_path / "draft_content.json"
        content = json.loads(content_path.read_text(encoding="utf-8"))
        apply_common_mask_templates(content, mask_segments)
        normalize_video_fade_materials(content)
        content_path.write_text(
            json.dumps(content, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )
        if bgm_stream is not None:
            audios = content.get("materials", {}).get("audios", [])
            matches = [
                audio for audio in audios
                if isinstance(audio, dict)
                and audio.get("name") == "bgm"
                and audio.get("path") == bgm_material_path
            ]
            if len(matches) != 1:
                fail("JY002_DRAFT_STRUCTURE_INVALID")
            matches[0]["path"] = expected_bgm_path
            content_path.write_text(
                json.dumps(content, ensure_ascii=False, separators=(",", ":")),
                encoding="utf-8",
            )
        ensure_jianying_homepage_metadata(
            staging_path,
            root,
            payload["draft_label"],
            content,
        )
        content_bytes = content_path.read_bytes()
        output_fingerprint = hashlib.sha256(content_bytes).hexdigest()
        owner_record = {
                "schema_version": 2,
                "owner_id": payload["owner_id"],
                "request_id": payload["request_id"],
                "draft_id": payload["draft_id"],
                "output_fingerprint": output_fingerprint,
                "phase": "staging",
            }
        if payload.get("bundle_fingerprint") is not None:
            owner_record["bundle_fingerprint"] = payload["bundle_fingerprint"]
        write_owner(
            staging_path,
            owner_record,
        )
        pending_owner_path.unlink(missing_ok=True)
        content = json.loads(content_bytes.decode("utf-8"))
        expected = {
            "duration_us": payload["duration_us"],
            "fps": payload["fps"],
            "video_segments": video_segments,
            "voiceover_segments": voiceover_segments,
            "caption_segments": caption_segments,
            "title_segments": title_segments,
            "bgm_path": expected_bgm_path,
            "bgm_size": bgm_stream["size"] if bgm_stream is not None else None,
            "bgm_sha256": bgm_stream["sha256"] if bgm_stream is not None else None,
            "bgm_volume": float(bgm_volume),
            "sfx_segments": sfx_segments,
            "sfx_track_names": sfx_track_names,
            "effect_segments": resolved_effect_segments,
            "effect_segments_resolved": True,
            "sticker_segments": sticker_segments,
            "filter_segments": filter_segments,
            "animation_segments": animation_segments,
            "text_animation_segments": text_animation_segments,
            "text_keyframe_segments": text_keyframe_segments,
            "blend_segments": blend_segments,
            "mask_segments": mask_segments,
            "background_segments": background_segments,
            "chroma_segments": chroma_segments,
        }
        if not validate_tracks(content, expected):
            fail("JY002_DRAFT_STRUCTURE_INVALID", track_validation_diagnostic(content, expected))
        batch_readback = private_batch_readback(payload, expected)
        emit({
            "ok": True,
            "output_fingerprint": output_fingerprint,
            "bgm_path": expected_bgm_path,
            "bgm_size": bgm_stream["size"] if bgm_stream is not None else None,
            "bgm_sha256": bgm_stream["sha256"] if bgm_stream is not None else None,
            "effect_segments": resolved_effect_segments,
            "sticker_segments": sticker_segments,
            "private_batch_readback": batch_readback,
        })
    except SystemExit:
        shutil.rmtree(staging_path, ignore_errors=True)
        staging_owner_path(staging_root, payload["draft_id"]).unlink(missing_ok=True)
        raise
    except FileExistsError:
        shutil.rmtree(staging_path, ignore_errors=True)
        staging_owner_path(staging_root, payload["draft_id"]).unlink(missing_ok=True)
        fail("JY002_OUTPUT_CONFLICT")
    except PermissionError:
        shutil.rmtree(staging_path, ignore_errors=True)
        staging_owner_path(staging_root, payload["draft_id"]).unlink(missing_ok=True)
        fail("JY002_PATH_PERMISSION_DENIED")
    except (FileNotFoundError, ValueError) as error:
        shutil.rmtree(staging_path, ignore_errors=True)
        staging_owner_path(staging_root, payload["draft_id"]).unlink(missing_ok=True)
        fail(
            "JY002_DRAFT_STRUCTURE_INVALID"
            if build_stage in ["caption", "title", "sfx", "packaging", "save"]
            else "JY002_MATERIAL_AUTHORIZATION_EXPIRED",
            {
                "stage": build_stage,
                "exception_type": type(error).__name__,
            },
        )
    except Exception as error:
        shutil.rmtree(staging_path, ignore_errors=True)
        staging_owner_path(staging_root, payload["draft_id"]).unlink(missing_ok=True)
        fail("JY002_DRAFT_WRITE_FAILED", {"stage": build_stage, "exception_type": type(error).__name__})


def verify_and_promote(payload):
    required = [
        "action",
        "draft_root",
        "staging_name",
        "draft_id",
        "output_fingerprint",
        "owner_id",
        "request_id",
        "duration_us",
        "video_segments",
        "voiceover_segments",
        "caption_segments",
        "title_segments",
        "subtitle_style",
        "bgm_path",
        "bgm_size",
        "bgm_sha256",
        "bgm_volume",
    ]
    if not isinstance(payload, dict) or any(key not in payload for key in required):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    validate_duration(payload["duration_us"])
    validate_segment_count(payload["video_segments"], payload["voiceover_segments"])
    root = Path(payload["draft_root"])
    reject_reparse(root)
    staging_root = root / ".openvideo-staging"
    reject_reparse(staging_root)
    staging_path = resolve_child(staging_root, payload["staging_name"])
    final_path = resolve_child(root, payload["draft_id"])
    try:
        owner = json.loads((staging_path / ".openvideo-owner.json").read_text(encoding="utf-8"))
        if not valid_owner(owner, payload, ["staging"]):
            fail("JY002_OUTPUT_CONFLICT")
        content_path = staging_path / "draft_content.json"
        content_bytes = content_path.read_bytes()
        if hashlib.sha256(content_bytes).hexdigest() != payload["output_fingerprint"]:
            fail("JY002_DRAFT_STRUCTURE_INVALID")
        content = json.loads(content_bytes.decode("utf-8"))
        tracks_valid = validate_tracks(content, payload)
        bgm_asset_valid = validate_bgm_asset(staging_path, final_path, payload)
        media_bin_valid = validate_jianying_media_bin_metadata(staging_path, content)
        if not tracks_valid or not bgm_asset_valid or not media_bin_valid:
            diagnostic = track_validation_diagnostic(content, payload)
            diagnostic["stage"] = "verify_and_promote"
            diagnostic["bgm_asset_valid"] = bgm_asset_valid
            diagnostic["media_bin_valid"] = media_bin_valid
            fail("JY002_DRAFT_STRUCTURE_INVALID", diagnostic)
        batch_readback = private_batch_readback(payload, payload)
        os.rename(staging_path, final_path)
        owner["phase"] = "published"
        write_owner(final_path, owner)
        try:
            staging_root.rmdir()
        except OSError:
            pass
        emit({"ok": True, "private_batch_readback": batch_readback})
    except SystemExit:
        raise
    except FileExistsError:
        fail("JY002_OUTPUT_CONFLICT")
    except PermissionError:
        fail("JY002_PATH_PERMISSION_DENIED")
    except Exception:
        fail("JY002_DRAFT_STRUCTURE_INVALID")


def verify_final(payload):
    required = [
        "action",
        "draft_root",
        "draft_id",
        "output_fingerprint",
        "owner_id",
        "request_id",
        "duration_us",
        "video_segments",
        "voiceover_segments",
        "caption_segments",
        "title_segments",
        "subtitle_style",
        "bgm_path",
        "bgm_size",
        "bgm_sha256",
        "bgm_volume",
    ]
    if not isinstance(payload, dict) or any(key not in payload for key in required):
        fail("JY002_DRAFT_STRUCTURE_INVALID")
    validate_duration(payload["duration_us"])
    validate_segment_count(payload["video_segments"], payload["voiceover_segments"])
    root = Path(payload["draft_root"])
    reject_reparse(root)
    final_path = resolve_child(root, payload["draft_id"])
    try:
        owner = json.loads((final_path / ".openvideo-owner.json").read_text(encoding="utf-8"))
        if not valid_owner(owner, payload, ["staging", "published", "committed"]):
            fail("JY002_OUTPUT_CONFLICT")
        content_bytes = (final_path / "draft_content.json").read_bytes()
        if hashlib.sha256(content_bytes).hexdigest() != payload["output_fingerprint"]:
            fail("JY002_OUTPUT_CONFLICT")
        content = json.loads(content_bytes.decode("utf-8"))
        tracks_valid = validate_tracks(content, payload)
        bgm_asset_valid = validate_bgm_asset(final_path, final_path, payload)
        media_bin_valid = validate_jianying_media_bin_metadata(final_path, content)
        if not tracks_valid or not bgm_asset_valid or not media_bin_valid:
            diagnostic = track_validation_diagnostic(content, payload)
            diagnostic["stage"] = "verify_final"
            diagnostic["bgm_asset_valid"] = bgm_asset_valid
            diagnostic["media_bin_valid"] = media_bin_valid
            fail("JY002_DRAFT_STRUCTURE_INVALID", diagnostic)
        batch_readback = private_batch_readback(payload, payload)
        if owner["phase"] == "staging":
            owner["phase"] = "published"
            write_owner(final_path, owner)
        emit({"ok": True, "private_batch_readback": batch_readback})
    except SystemExit:
        raise
    except FileNotFoundError:
        fail("JY002_OUTPUT_CONFLICT")
    except PermissionError:
        fail("JY002_PATH_PERMISSION_DENIED")
    except Exception as error:
        fail("JY002_DRAFT_STRUCTURE_INVALID", {
            "stage": "verify_final",
            "exception_type": type(error).__name__,
        })


def _cleanup_unlocked(payload):
    required = [
        "action",
        "draft_root",
        "staging_name",
        "final_name",
        "output_fingerprint",
        "owner_id",
        "request_id",
        "draft_id",
    ]
    if not require_keys(payload, required):
        fail("JY002_DRAFT_WRITE_FAILED")
    root = Path(payload["draft_root"])
    reject_reparse(root)
    staging_root = root / ".openvideo-staging"
    if staging_root.exists():
        reject_reparse(staging_root)
    staging_path = resolve_child(staging_root, payload["staging_name"])
    try:
        if staging_path.exists():
            owner_path = staging_path / ".openvideo-owner.json"
            if not owner_path.exists():
                owner_path = staging_owner_path(staging_root, payload["draft_id"])
            owner = json.loads(
                owner_path.read_text(encoding="utf-8")
            )
            if (
                owner.get("schema_version") != 2
                or owner.get("owner_id") != payload["owner_id"]
                or owner.get("request_id") != payload["request_id"]
                or owner.get("draft_id") != payload["draft_id"]
                or owner.get("phase") != "staging"
            ):
                fail("JY002_OUTPUT_CONFLICT")
            shutil.rmtree(staging_path)
            if owner_path.parent == staging_root:
                owner_path.unlink(missing_ok=True)
        if staging_path.exists():
            fail("JY002_DRAFT_WRITE_FAILED")
    except OSError:
        fail("JY002_DRAFT_WRITE_FAILED")
    final_name = payload["final_name"]
    if final_name is not None:
        fingerprint = payload["output_fingerprint"]
        if not safe_name(final_name) or not isinstance(fingerprint, str):
            fail("JY002_PATH_PERMISSION_DENIED")
        final_path = resolve_child(root, final_name)
        content_path = final_path / "draft_content.json"
        try:
            owner = json.loads(
                (final_path / ".openvideo-owner.json").read_text(encoding="utf-8")
            )
            if (
                valid_owner(owner, payload, ["published"])
                and hashlib.sha256(content_path.read_bytes()).hexdigest() == fingerprint
            ):
                shutil.rmtree(final_path)
            elif valid_owner(owner, payload, ["committed"]):
                pass
            elif final_path.exists():
                fail("JY002_OUTPUT_CONFLICT")
        except SystemExit:
            raise
        except OSError:
            fail("JY002_DRAFT_WRITE_FAILED")
    try:
        staging_root.rmdir()
    except OSError:
        pass
    emit({"ok": True})


def cleanup(payload):
    required = [
        "action",
        "draft_root",
        "staging_name",
        "final_name",
        "output_fingerprint",
        "owner_id",
        "request_id",
        "draft_id",
    ]
    if not require_keys(payload, required):
        fail("JY002_DRAFT_WRITE_FAILED")
    if not safe_name(payload["draft_id"]):
        fail("JY002_PATH_PERMISSION_DENIED")
    root = Path(payload["draft_root"])
    reject_reparse(root)
    with draft_lock(root, payload["draft_id"]):
        _cleanup_unlocked(payload)


def _owned_draft_unlocked(payload, commit):
    if not valid_owned_draft_payload(payload, commit):
        fail("JY002_DRAFT_WRITE_FAILED")
    if not safe_name(payload["request_id"]) or not safe_name(payload["draft_id"]):
        fail("JY002_PATH_PERMISSION_DENIED")
    root = Path(payload["draft_root"])
    reject_reparse(root)
    staging_root = root / ".openvideo-staging"
    final_path = resolve_child(root, payload["draft_id"])
    staging_path = (
        resolve_child(staging_root, payload["draft_id"])
        if staging_root.exists()
        else staging_root / payload["draft_id"]
    )

    target = final_path if final_path.exists() else staging_path
    if not target.exists():
        emit({"ok": True, "changed": False, "committed": False})
        return
    reject_reparse(target)
    try:
        owner_path = target / ".openvideo-owner.json"
        if target == staging_path and not owner_path.exists():
            owner_path = staging_owner_path(staging_root, payload["draft_id"])
        owner = json.loads(
            owner_path.read_text(encoding="utf-8")
        )
        if (
            owner.get("schema_version") != 2
            or owner.get("request_id") != payload["request_id"]
            or owner.get("draft_id") != payload["draft_id"]
            or owner.get("phase") not in ["staging", "published", "committed"]
        ):
            fail("JY002_OUTPUT_CONFLICT")
        if owner["phase"] == "committed":
            emit({"ok": True, "changed": False, "committed": True})
            return
        if commit:
            if target != final_path or owner["phase"] != "published":
                fail("JY002_OUTPUT_CONFLICT")
            draft_label = payload.get("draft_label")
            if draft_label is not None and not safe_draft_label(draft_label):
                fail("JY002_PATH_PERMISSION_DENIED")
            fingerprint = owner.get("output_fingerprint")
            if (
                not isinstance(fingerprint, str)
                or hashlib.sha256(
                    (final_path / "draft_content.json").read_bytes()
                ).hexdigest()
                != fingerprint
            ):
                fail("JY002_OUTPUT_CONFLICT")
            if draft_label is not None:
                repair_jianying_homepage_draft_name(final_path, draft_label)
            owner["phase"] = "committed"
            write_owner(final_path, owner)
            emit({"ok": True, "changed": True, "committed": True})
            return
        shutil.rmtree(target)
        if owner_path.parent == staging_root:
            owner_path.unlink(missing_ok=True)
        if target.exists():
            fail("JY002_DRAFT_WRITE_FAILED")
        if staging_root.exists():
            try:
                staging_root.rmdir()
            except OSError:
                pass
        emit({"ok": True, "changed": True, "committed": False})
    except SystemExit:
        raise
    except PermissionError:
        fail("JY002_PATH_PERMISSION_DENIED")
    except Exception:
        fail("JY002_DRAFT_WRITE_FAILED")


def owned_draft(payload, commit):
    if not valid_owned_draft_payload(payload, commit):
        fail("JY002_DRAFT_WRITE_FAILED")
    if not safe_name(payload["request_id"]) or not safe_name(payload["draft_id"]):
        fail("JY002_PATH_PERMISSION_DENIED")
    root = Path(payload["draft_root"])
    reject_reparse(root)
    with draft_lock(root, payload["draft_id"]):
        _owned_draft_unlocked(payload, commit)


def main():
    manifest = load_manifest()
    action = manifest.get("action")
    if action == "write":
        write_draft(manifest)
    elif action == "verify":
        verify_and_promote(manifest)
    elif action == "verify_final":
        verify_final(manifest)
    elif action == "cleanup":
        cleanup(manifest)
    elif action == "cleanup_owned":
        owned_draft(manifest, False)
    elif action == "commit_owned":
        owned_draft(manifest, True)
    elif action == "handshake":
        handshake(manifest)
    else:
        fail("JY002_DRAFT_WRITE_FAILED")


if __name__ == "__main__":
    main()
