import { randomBytes, timingSafeEqual } from 'node:crypto'
import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'

export const LOCAL_API_TOKEN_HEADER = 'x-openvideo-local-token'
export const LOCAL_API_TOKEN_FILE = 'local-api-token.json'
export const LOCAL_API_TOKEN_COOKIE = 'openvideo_local_session'

/** @param {string} dataRoot */
export const resolveLocalApiTokenPath = (dataRoot) => resolve(dataRoot, LOCAL_API_TOKEN_FILE)

/**
 * @param {string | null | undefined} dataRoot
 * @returns {Promise<string>}
 */
export const createOrLoadLocalApiToken = async (dataRoot) => {
  if (typeof dataRoot !== 'string' || dataRoot.length === 0) {
    return randomBytes(32).toString('hex')
  }
  const tokenPath = resolveLocalApiTokenPath(dataRoot)
  try {
    const parsed = JSON.parse(await readFile(tokenPath, 'utf8'))
    if (
      parsed &&
      typeof parsed === 'object' &&
      typeof parsed.token === 'string' &&
      /^[a-f0-9]{64}$/u.test(parsed.token)
    ) {
      return parsed.token
    }
  } catch {
    // recreate below
  }
  const token = randomBytes(32).toString('hex')
  await mkdir(dirname(tokenPath), { recursive: true })
  const temporaryPath = `${tokenPath}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
  try {
    await writeFile(
      temporaryPath,
      `${JSON.stringify({
        schema_version: 1,
        kind: 'openvideo_local_api_token',
        token,
        created_at: new Date().toISOString(),
      }, null, 2)}\n`,
      { encoding: 'utf8', flag: 'wx', mode: 0o600 },
    )
    await rename(temporaryPath, tokenPath)
  } finally {
    await rm(temporaryPath, { force: true }).catch(() => {})
  }
  return token
}

/** @param {Request} request */
export const isLocalApiWriteRequest = (request) =>
  !['GET', 'HEAD', 'OPTIONS'].includes(request.method) &&
  new URL(request.url).pathname.startsWith('/api/')

/** @param {string | null} value */
const readLocalApiTokenCookie = (value) => {
  if (typeof value !== 'string') return null
  for (const part of value.split(';')) {
    const [name, token] = part.trim().split('=', 2)
    if (name === LOCAL_API_TOKEN_COOKIE) return token ?? null
  }
  return null
}

/** @param {string} token */
export const localApiSessionCookie = (token) =>
  `${LOCAL_API_TOKEN_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict`

/**
 * @param {Request} request
 * @param {string} expectedToken
 */
export const isAuthorizedLocalApiWrite = (request, expectedToken) => {
  if (typeof expectedToken !== 'string' || !/^[a-f0-9]{64}$/u.test(expectedToken)) return false
  const provided = request.headers.get(LOCAL_API_TOKEN_HEADER) ??
    readLocalApiTokenCookie(request.headers.get('cookie'))
  if (typeof provided !== 'string' || provided.length !== expectedToken.length) return false
  return timingSafeEqual(Buffer.from(provided, 'utf8'), Buffer.from(expectedToken, 'utf8'))
}

