import { createHash, randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import {
  chmod,
  copyFile,
  lstat,
  mkdir,
  readdir,
  readFile,
  realpath,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { isAbsolute, join, relative, resolve } from 'node:path'

import {
  JianyingDraftDecryptError,
  isEncryptedDraftContent,
} from './jianying-draft-decrypt.mjs'
import { cloneJianyingDraft } from './jianying-template-cloner.mjs'

const defaultMaxFiles = 20_000
const defaultMaxBytes = 10 * 1024 * 1024 * 1024

/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const fragment = relative(resolve(parent), resolve(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? resolve(left).toLowerCase() === resolve(right).toLowerCase()
  : resolve(left) === resolve(right)

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * Windows realpath can return an 8.3 alias. Accept a different spelling only
 * when both names still identify the exact same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}

export class TemplateBlueprintStoreError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'TemplateBlueprintStoreError'
    this.code = code
    this.status = status
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   maxFiles?: number,
 *   maxBytes?: number,
 *   ensurePlaintextDraftContent?: (absolutePath: string) => Promise<Record<string, any> | void>,
 * }} options
 */
export const createTemplateBlueprintStore = ({
  dataRoot,
  maxFiles = defaultMaxFiles,
  maxBytes = defaultMaxBytes,
  ensurePlaintextDraftContent = undefined,
}) => {
  if (
    !isAbsolute(dataRoot) ||
    !Number.isSafeInteger(maxFiles) ||
    maxFiles < 1 ||
    !Number.isSafeInteger(maxBytes) ||
    maxBytes < 1
  ) throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_STORE_INVALID', 503)
  const root = resolve(dataRoot, 'template-blueprints')

  /** @param {string} relativePath */
  const basenameIsDotOpenVideo = (relativePath) =>
    relativePath === '.openvideo-blueprint.json' ||
    relativePath.endsWith('/.openvideo-blueprint.json')

  /** @param {string} source */
  const snapshot = async (source) => {
    /** @type {Array<{relativePath: string, absolutePath: string, size: number}>} */
    const files = []
    let totalBytes = 0
    /** @param {string} current @param {string} relativePath */
    const visit = async (current, relativePath) => {
      const metadata = await lstat(current)
      if (metadata.isSymbolicLink()) {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_SOURCE_INVALID', 400)
      }
      if (metadata.isDirectory()) {
        const children = await readdir(current)
        children.sort((left, right) => left.localeCompare(right, 'en'))
        for (const child of children) {
          await visit(join(current, child), relativePath ? `${relativePath}/${child}` : child)
        }
        return
      }
      if (!metadata.isFile()) {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_SOURCE_INVALID', 400)
      }
      if (basenameIsDotOpenVideo(relativePath)) return
      totalBytes += metadata.size
      files.push({ relativePath, absolutePath: current, size: metadata.size })
      if (files.length > maxFiles || totalBytes > maxBytes) {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_TOO_LARGE', 413)
      }
    }
    await visit(source, '')
    if (!files.some((entry) => entry.relativePath === 'draft_content.json')) {
      throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_SOURCE_INVALID', 400)
    }
    const hash = createHash('sha256')
    for (const file of files) {
      hash.update(file.relativePath)
      hash.update('\u0000')
      hash.update(String(file.size))
      hash.update('\u0000')
      hash.update(await readFile(file.absolutePath))
      hash.update('\u0000')
    }
    return {
      files,
      fileCount: files.length,
      byteSize: totalBytes,
      fingerprint: hash.digest('hex'),
    }
  }

  return {
    /** @param {string} sourceFolder */
    async ingest(sourceFolder) {
      if (!isAbsolute(sourceFolder)) {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_SOURCE_INVALID', 400)
      }
      const source = resolve(sourceFolder)
      let sourceMetadata
      try {
        sourceMetadata = await lstat(source, { bigint: true })
        const actualSource = await realpath(source)
        if (
          !sourceMetadata.isDirectory() ||
          sourceMetadata.isSymbolicLink() ||
          !await sameResolvedObject(source, actualSource, sourceMetadata)
        ) throw new Error('invalid source')
      } catch {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_SOURCE_INVALID', 400)
      }
      const temporary = resolve(root, `.ingest.${randomUUID()}.tmp`)
      await mkdir(temporary, { recursive: true, mode: 0o700 })
      /** @type {Record<string, any> | null} */
      let decryptMeta = null
      try {
        const sourceFiles = await snapshot(source)
        for (const file of sourceFiles.files) {
          const destination = resolve(temporary, file.relativePath)
          if (!inside(temporary, destination)) {
            throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_SOURCE_INVALID', 400)
          }
          await mkdir(resolve(destination, '..'), { recursive: true, mode: 0o700 })
          await copyFile(file.absolutePath, destination)
          await chmod(destination, 0o600).catch(() => {})
        }
        const draftContentPath = join(temporary, 'draft_content.json')
        const draftRaw = await readFile(draftContentPath)
        if (isEncryptedDraftContent(draftRaw)) {
          if (typeof ensurePlaintextDraftContent !== 'function') {
            throw new TemplateBlueprintStoreError('JY_TEMPLATE_DECRYPT_HELPER_MISSING', 503)
          }
          try {
            decryptMeta = await ensurePlaintextDraftContent(draftContentPath) || null
          } catch (error) {
            if (error instanceof JianyingDraftDecryptError) {
              throw new TemplateBlueprintStoreError(error.code, error.status)
            }
            throw error
          }
          const after = await readFile(draftContentPath)
          if (isEncryptedDraftContent(after)) {
            throw new TemplateBlueprintStoreError('JY_TEMPLATE_DECRYPT_FAILED', 502)
          }
        } else {
          decryptMeta = {
            scheme: 'plaintext',
            contentEncoding: 'plaintext',
          }
        }
        const captured = await snapshot(temporary)
        const blueprintId = `jtb_${captured.fingerprint.slice(0, 24)}`
        const target = resolve(root, blueprintId)
        if (!inside(root, target)) {
          throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_STORE_INVALID', 503)
        }
        const result = {
          blueprintId,
          fingerprint: captured.fingerprint,
          fileCount: captured.fileCount,
          byteSize: captured.byteSize,
          contentEncoding: 'plaintext',
          decryptScheme: decryptMeta?.scheme || decryptMeta?.decryptedFrom || 'plaintext',
          sourceAppVersion: typeof decryptMeta?.appVersion === 'string' ? decryptMeta.appVersion : null,
        }
        if (existsSync(target)) {
          await this.resolvePrivateFolder(blueprintId, captured.fingerprint)
          await rm(temporary, { recursive: true, force: true })
          return {
            blueprintId: result.blueprintId,
            fingerprint: result.fingerprint,
            fileCount: result.fileCount,
            byteSize: result.byteSize,
          }
        }
        await writeFile(
          join(temporary, '.openvideo-blueprint.json'),
          `${JSON.stringify({ schema_version: 1, ...result }, null, 2)}\n`,
          { encoding: 'utf8', mode: 0o600 },
        )
        await mkdir(root, { recursive: true, mode: 0o700 })
        await rename(temporary, target)
        return {
          blueprintId: result.blueprintId,
          fingerprint: result.fingerprint,
          fileCount: result.fileCount,
          byteSize: result.byteSize,
        }
      } catch (error) {
        await rm(temporary, { recursive: true, force: true })
        throw error
      }
    },

    /**
     * Clone a private blueprint into a new private Jianying draft. This is a
     * trusted server-side operation; no absolute path is returned to callers.
     * @param {{blueprintId: string, fingerprint: string, destinationFolder: string, videoAssets?: any[], audioAssets?: any[], textReplacements?: any[]}} input
     */
    async cloneDraft(input) {
      const sourceFolder = await this.resolvePrivateFolder(input?.blueprintId, input?.fingerprint)
      return cloneJianyingDraft({
        sourceFolder,
        destinationFolder: input?.destinationFolder,
        videoAssets: input?.videoAssets,
        audioAssets: input?.audioAssets,
        textReplacements: input?.textReplacements,
      })
    },

    /**
     * Trusted server-only boundary.
     * @param {string} blueprintId
     * @param {string} fingerprint
     */
    async resolvePrivateFolder(blueprintId, fingerprint) {
      if (
        !/^jtb_[a-f0-9]{24}$/u.test(blueprintId) ||
        !/^[a-f0-9]{64}$/u.test(fingerprint)
      ) throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_ID_INVALID', 400)
      const target = resolve(root, blueprintId)
      if (!inside(root, target)) {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_ID_INVALID', 400)
      }
      try {
        const metadata = await stat(target)
        const manifest = JSON.parse(await readFile(join(target, '.openvideo-blueprint.json'), 'utf8'))
        if (
          !metadata.isDirectory() ||
          manifest?.schema_version !== 1 ||
          manifest?.blueprintId !== blueprintId ||
          manifest?.fingerprint !== fingerprint
        ) throw new Error('invalid blueprint')
      } catch {
        throw new TemplateBlueprintStoreError('TEMPLATE_BLUEPRINT_NOT_FOUND', 404)
      }
      return target
    },
  }
}
