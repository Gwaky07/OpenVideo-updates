import { createHash, randomUUID } from 'node:crypto'
import { copyFile, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'

import {
  computeCapabilityRequirements,
  sealRichTimeline,
  toPublicTimelineSummary,
} from './rich-timeline-contracts.mjs'

const schemaVersion = 1
const opaqueIdPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u
const importAnalysisStages = new Set(['scanning', 'metadata', 'scenes', 'asr', 'visual', 'indexing', 'complete', 'failed'])

/**
 * @typedef {'ready' | 'stale' | 'unavailable'} LibraryState
 * @typedef {'scanning' | 'metadata' | 'scenes' | 'asr' | 'visual' | 'indexing' | 'complete' | 'failed'} ImportStage
 * @typedef {{id: string, start: number, end: number, summary?: string, tags?: string[], [key: string]: unknown}} MaterialScene
 * @typedef {{id: string, label: string, status: string, analyzedPercent: number, durationSeconds: number, sceneCount: number, scenes: MaterialScene[], folder?: unknown, folderTrail?: unknown[], analyzerVersion?: string, [key: string]: unknown}} MaterialAsset
 * @typedef {MaterialAsset & {libraryState: LibraryState, sourceProjectId: string, projectIds: string[], projectNames: string[], addedAt: string, lastUsedAt: string}} LibraryAsset
 * @typedef {{projectId: string, projectName: string, createdAt: string, updatedAt: string}} LibraryBinding
 * @typedef {{id: string, name: string, parentId?: string | null, assetIds: string[]}} LibraryCollection
 * @typedef {{favoriteAssetIds: string[], favoriteSceneRefs: string[], collections: LibraryCollection[], lastViewedAt: Record<string, string>, usageCounts: Record<string, number>, displayTitles?: Record<string, string>}} LibraryPreferences
 * @typedef {{id: string, name: string, authorizationId: string, createdAt: string, updatedAt: string}} LibraryImport
 * @typedef {{targetProjectId: string, sourceProjectId: string, sourceAuthorizationId: string, assetId: string, sceneId: string, start: number, end: number, createdAt: string}} ProjectReference
 * @typedef {{projectId: string, authorizationId: string, assetId: string, sceneId?: string}} MediaBinding
 * @typedef {{jobId: string, importId: string, sourceType: 'file'|'folder', status: 'queued'|'running'|'succeeded'|'failed'|'cancelled', total: number, analyzed: number, failed: number, progressPercent: number, stage: ImportStage, currentLabel: string|null, detail: string, error: {code: string, recoverable: boolean}|null, createdAt: string, updatedAt: string}} ImportJob
 * @typedef {{createdAt: number, assets: LibraryAsset[], needsStateReconcile: boolean}} CatalogCache
 * @typedef {{analysisStatus?: string, queued?: number, analyzerVersion?: string, assets?: MaterialAsset[], lastScanAt?: string, authorizationId?: string, [key: string]: unknown}} MaterialsSnapshot
 * @typedef {{id?: string, name?: string, createdAt?: string, updatedAt?: string, brief?: {orientation?: string}, materials?: MaterialsSnapshot, [key: string]: unknown}} ProjectRecord
 */

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @returns {value is string} */
const opaqueId = (value) => typeof value === 'string' && opaqueIdPattern.test(value)
/** @param {unknown} value @returns {value is string} */
const safeName = (value) => (
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.trim().length <= 40 &&
  !value.includes('\u0000') &&
  !value.includes('\\') &&
  !value.includes('/')
)
/** @param {unknown} value @returns {value is string} */
const safeImportLabel = (value) => (
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.trim().length <= 160 &&
  !value.includes('\u0000') &&
  !value.includes('\\') &&
  !value.includes('/') &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value.trim())
)
/** @type {Readonly<Record<ImportStage, string>>} */
const importStageDetail = Object.freeze({
  scanning: '正在扫描待分析的视频。',
  metadata: '正在读取视频信息。',
  scenes: '正在检测画面片段。',
  asr: '正在识别语音内容。',
  visual: '正在理解画面和屏幕文字。',
  indexing: '正在整理标签和搜索索引。',
  complete: '素材分析已完成。',
  failed: '素材分析未完成。',
})
/** @param {unknown} value @returns {ImportStage} */
const safeImportStage = (value) => typeof value === 'string' && importAnalysisStages.has(value) ? /** @type {ImportStage} */ (value) : 'scanning'
/** @param {ImportStage} stage @param {unknown} value */
const safeImportDetail = (stage, value) => {
  if (stage === 'visual' && typeof value === 'string') {
    const match = /^多帧理解\s+(\d{1,4})\s*\/\s*(\d{1,4})$/u.exec(value.trim())
    if (match) return `多帧理解 ${match[1]} / ${match[2]}`
  }
  return importStageDetail[stage] ?? importStageDetail.scanning
}
/** @param {ImportJob} job */
const publicImportDetail = (job) => {
  if (job.status === 'queued') return '已加入队列，等待开始分析。'
  if (job.status === 'cancelled') return '素材导入已取消。'
  if (job.status === 'failed') return '素材导入或分析失败，请重试。'
  if (job.status === 'succeeded') return job.sourceType === 'folder'
    ? '文件夹素材已批量导入并完成分析。'
    : '视频已导入并完成分析。'
  return safeImportDetail(safeImportStage(job.stage), job.detail)
}
const timestamp = () => new Date().toISOString()

/** @returns {LibraryPreferences} */
const emptyPreferences = () => ({
  favoriteAssetIds: [],
  favoriteSceneRefs: [],
  collections: [],
  lastViewedAt: {},
  usageCounts: {},
})

/** @param {unknown} value @returns {value is string} */
const validTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @param {unknown} value @returns {value is LibraryPreferences} */
const validPreferences = (value) => {
  if (!isRecord(value)) return false
  const preferenceKeys = Object.keys(value).sort().join('\u0000')
  const basePreferenceKeys = ['collections', 'favoriteAssetIds', 'favoriteSceneRefs', 'lastViewedAt', 'usageCounts'].sort().join('\u0000')
  const titledPreferenceKeys = ['collections', 'displayTitles', 'favoriteAssetIds', 'favoriteSceneRefs', 'lastViewedAt', 'usageCounts'].sort().join('\u0000')
  if (preferenceKeys !== basePreferenceKeys && preferenceKeys !== titledPreferenceKeys) return false
  if (
    !Array.isArray(value.favoriteAssetIds) ||
    value.favoriteAssetIds.length > 10_000 ||
    value.favoriteAssetIds.some((id) => !opaqueId(id)) ||
    new Set(value.favoriteAssetIds).size !== value.favoriteAssetIds.length ||
    !Array.isArray(value.favoriteSceneRefs) ||
    value.favoriteSceneRefs.length > 20_000 ||
    value.favoriteSceneRefs.some((reference) =>
      typeof reference !== 'string' ||
      reference.length > 401 ||
      !reference.includes(':')) ||
    new Set(value.favoriteSceneRefs).size !== value.favoriteSceneRefs.length ||
    !Array.isArray(value.collections) ||
    value.collections.length > 500 ||
    !isRecord(value.lastViewedAt) ||
    !isRecord(value.usageCounts)
  ) return false
  if (value.collections.some((collection) => {
    const keys = Object.keys(collection ?? {}).sort().join('\u0000')
    return !isRecord(collection) ||
    ![
      ['assetIds', 'id', 'name'].sort().join('\u0000'),
      ['assetIds', 'id', 'name', 'parentId'].sort().join('\u0000'),
    ].includes(keys) ||
    !opaqueId(collection.id) ||
    !safeName(collection.name) ||
    !(collection.parentId === undefined || collection.parentId === null || opaqueId(collection.parentId)) ||
    collection.parentId === collection.id ||
    !Array.isArray(collection.assetIds) ||
    collection.assetIds.length > 10_000 ||
    collection.assetIds.some((id) => !opaqueId(id)) ||
    new Set(collection.assetIds).size !== collection.assetIds.length
  })) return false
  if (new Set(value.collections.map((collection) => collection.id)).size !== value.collections.length) return false
  const collectionIds = new Set(value.collections.map((collection) => collection.id))
  if (value.collections.some((collection) => collection.parentId && !collectionIds.has(collection.parentId))) return false
  for (const collection of value.collections) {
    const visited = new Set([collection.id])
    let parentId = collection.parentId ?? null
    while (parentId) {
      if (visited.has(parentId)) return false
      visited.add(parentId)
      parentId = value.collections.find((entry) => entry.id === parentId)?.parentId ?? null
    }
  }
  if (Object.entries(value.lastViewedAt).some(([id, viewedAt]) => !opaqueId(id) || !validTimestamp(viewedAt))) return false
  if (Object.entries(value.usageCounts).some(([id, count]) =>
    !opaqueId(id) || typeof count !== 'number' || !Number.isSafeInteger(count) || count < 0 || count > 1_000_000_000)) return false
  if (value.displayTitles !== undefined) {
    if (!isRecord(value.displayTitles) || Object.keys(value.displayTitles).length > 20_000) return false
    if (Object.entries(value.displayTitles).some(([id, title]) => !opaqueId(id) || !safeName(title))) return false
  }
  return true
}

export class MaterialLibraryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'MaterialLibraryError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} error */
const materialErrorCode = (error) => (
  error && typeof error === 'object' && typeof /** @type {{code?: unknown}} */ (error).code === 'string'
    ? /** @type {{code: string}} */ (error).code
    : null
)

/** @param {unknown} error @returns {LibraryState} */
const bindingStateFor = (error) => {
  const code = materialErrorCode(error)
  if (code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') return 'stale'
  return 'unavailable'
}

/** @param {string} prefix @param {...string} parts */
const stableId = (prefix, ...parts) =>
  `${prefix}-${createHash('sha256').update(parts.join('\u0000')).digest('hex').slice(0, 24)}`

/** @param {{dataRoot: string, securePrivateRoot?: ((root: string) => Promise<unknown>) | null}} input */
const createPreferenceStore = async ({ dataRoot, securePrivateRoot }) => {
  const root = resolve(dataRoot, 'material-library')
  await mkdir(root, { recursive: true, mode: 0o700 })
  if (typeof securePrivateRoot === 'function') await securePrivateRoot(root)
  const filePath = resolve(root, 'preferences.json')
  const backupPath = `${filePath}.bak`
  /** @type {{schema_version: number, preferences: LibraryPreferences}} */
  let document = { schema_version: schemaVersion, preferences: emptyPreferences() }
  try {
    const loaded = JSON.parse(await readFile(filePath, 'utf8'))
    if (loaded?.schema_version !== schemaVersion || !validPreferences(loaded.preferences)) {
      throw new Error('invalid_preferences')
    }
    document = loaded
  } catch (primaryError) {
    try {
      const backup = JSON.parse(await readFile(backupPath, 'utf8'))
      if (backup?.schema_version !== schemaVersion || !validPreferences(backup.preferences)) {
        throw new Error('invalid_preferences_backup')
      }
      document = backup
      await writeFile(filePath, JSON.stringify(document), { encoding: 'utf8', mode: 0o600 })
    } catch (backupError) {
      if (/** @type {{code?: string}} */ (primaryError)?.code !== 'ENOENT' ||
          /** @type {{code?: string}} */ (backupError)?.code !== 'ENOENT') {
        throw new MaterialLibraryError('MATERIAL_LIBRARY_STORAGE_CORRUPT')
      }
    }
  }
  let queue = Promise.resolve()
  /** @param {{schema_version: number, preferences: LibraryPreferences}} next */
  const persist = async (next) => {
    const temporaryPath = `${filePath}.${randomUUID()}.tmp`
    await writeFile(temporaryPath, JSON.stringify(next), { encoding: 'utf8', mode: 0o600 })
    try {
      await copyFile(filePath, backupPath)
    } catch (error) {
      if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw error
    }
    await rename(temporaryPath, filePath)
  }
  return {
    read() {
      return clone(document.preferences)
    },
    write(/** @type {unknown} */ preferences) {
      if (!validPreferences(preferences)) {
        throw new MaterialLibraryError('MATERIAL_LIBRARY_PREFERENCES_INVALID', 400)
      }
      const operation = queue.then(async () => {
        const next = { schema_version: schemaVersion, preferences: clone(preferences) }
        await persist(next)
        document = next
        return clone(document.preferences)
      })
      queue = operation.then(() => undefined, () => undefined)
      return operation
    },
  }
}

/** @param {MaterialAsset} asset @param {LibraryBinding} binding @param {LibraryState} state @returns {LibraryAsset} */
const libraryAsset = (asset, binding, state) => ({
  ...clone(asset),
  status: state === 'ready' ? 'ready' : 'failed',
  analyzedPercent: state === 'ready' ? 100 : asset.analyzedPercent ?? 0,
  libraryState: state,
  sourceProjectId: binding.projectId,
  projectIds: [binding.projectId],
  projectNames: [binding.projectName],
  addedAt: binding.createdAt,
  lastUsedAt: binding.updatedAt,
})

/** @type {Readonly<Record<LibraryState, number>>} */
const statePriority = Object.freeze({ ready: 3, stale: 2, unavailable: 1 })
const catalogPageSize = 48
const catalogPageSizeMax = 100
const knownCatalogTagIds = new Set([
  'education', 'education_review', 'advanced_practice', 'topic_lesson',
  'geometry_cylinder', 'geometry_cone', 'math_geometry', 'course_explanation', 'practice_interaction',
  'screen_content', 'hand_operation', 'geometry_visual', 'explaining', 'ui_operation', 'writing', 'showing',
])

// List responses deliberately contain no scene transcript/OCR payload. A
// bounded display summary and tags preserve useful browsing context without
// making every page carry full scene cards.
/** @param {unknown} value */
const readableSceneSummary = (value) => {
  if (typeof value !== 'string') return ''
  const raw = value.replace(/\s+/gu, ' ').trim()
  if (
    !raw || raw.includes('\\') || raw.includes('/') ||
    /(?:%2f|%5c|%3a|\b[a-f0-9]{64}\b|\b(?:access[_ -]?token|api[_ -]?key|fingerprint)\b)/iu.test(raw)
  ) return ''
  const summary = raw
    .replace(/(?:OCR|屏幕文字|Observed OCR)\s*[:：]?[^|]*/giu, '')
    .replace(/\b[A-Za-z][A-Za-z0-9_.-]*\b/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
  return /[\u3400-\u9fff]{2}/u.test(summary) && !/[\u2500-\u257f\uFFFD]/u.test(summary)
    ? summary.slice(0, 180)
    : ''
}

/** @param {unknown} value */
const readableCatalogTag = (value) => (
  typeof value === 'string' &&
  (knownCatalogTagIds.has(value) || (/^[\u3400-\u9fff0-9]{2,20}$/u.test(value)))
    ? value
    : ''
)

/** @param {LibraryAsset} asset */
const catalogSummary = (asset) => {
  const scenes = Array.isArray(asset.scenes) ? asset.scenes : []
  const representativeIndexes = scenes.length <= 3
    ? scenes.map((_scene, index) => index)
    : [0, Math.floor((scenes.length - 1) / 2), scenes.length - 1]
  const displaySummary = [...new Set(representativeIndexes
    .map((index) => readableSceneSummary(scenes[index]?.summary))
    .filter(Boolean))]
    .join('；')
    .slice(0, 240)
  const displayTags = [...new Set(scenes.flatMap((scene) => Array.isArray(scene.tags) ? scene.tags : []))]
    .map(readableCatalogTag)
    .filter(Boolean)
    .slice(0, 5)
  return {
  id: asset.id,
  label: asset.label,
  status: asset.status,
  analyzedPercent: asset.analyzedPercent,
  durationSeconds: asset.durationSeconds,
  sceneCount: asset.sceneCount,
  folder: asset.folder ?? null,
  folderTrail: asset.folderTrail ?? [],
  libraryState: asset.libraryState,
  sourceProjectId: asset.sourceProjectId,
  projectIds: asset.projectIds,
  projectNames: asset.projectNames,
  addedAt: asset.addedAt,
  lastUsedAt: asset.lastUsedAt,
  // The public parser requires a non-empty safe summary. Keep the card
  // browsable when an analyzer only produced non-displayable evidence.
  displaySummary: displaySummary || '视频素材，暂未提取到可展示摘要。',
  displayTags,
  }
}

/** @param {LibraryAsset} asset */
const catalogFolderTrail = (asset) => {
  if (Array.isArray(asset.folderTrail) && asset.folderTrail.length > 0) {
    return asset.folderTrail.slice(0, 32)
  }
  if (isRecord(asset.folder) && typeof asset.folder.id === 'string') {
    return [asset.folder]
  }
  return [{ id: '__root__', label: '未分组', parentId: null }]
}

/** @param {LibraryAsset[]} assets */
const catalogFolderSummaries = (assets) => {
  const counts = new Map()
  for (const asset of assets) {
    const trail = catalogFolderTrail(asset)
    for (const [depth, folder] of trail.entries()) {
      if (!isRecord(folder) || typeof folder.id !== 'string' || !folder.id) continue
      const label = typeof folder.label === 'string' && folder.label.trim()
        ? folder.label.trim().slice(0, 80)
        : '未分组'
      const parentId = depth === 0
        ? null
        : (isRecord(trail[depth - 1]) && typeof /** @type {Record<string, any>} */ (trail[depth - 1]).id === 'string' ? /** @type {Record<string, any>} */ (trail[depth - 1]).id : null)
      const current = counts.get(folder.id)
      counts.set(folder.id, {
        id: folder.id,
        label,
        parentId,
        count: (current?.count ?? 0) + 1,
      })
    }
  }
  return [...counts.values()]
}

/** @param {LibraryAsset[]} assets */
const catalogStatusCounts = (assets) => ({
  all: assets.length,
  ready: assets.filter((asset) => asset.status === 'ready').length,
  analyzing: assets.filter((asset) => asset.status === 'analyzing').length,
  queued: assets.filter((asset) => asset.status === 'queued').length,
  failed: assets.filter((asset) => asset.status === 'failed').length,
})

/** @param {unknown} value */
const catalogPageLimit = (value) => (
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 1 && value <= catalogPageSizeMax
    ? value
    : catalogPageSize
)

/** @param {LibraryAsset | undefined} existing @param {MaterialAsset} asset @param {LibraryBinding} binding @param {LibraryState} state */
const mergeLibraryAsset = (existing, asset, binding, state) => {
  if (!existing) return libraryAsset(asset, binding, state)
  if (!existing.projectIds.includes(binding.projectId)) {
    existing.projectIds.push(binding.projectId)
    existing.projectNames.push(binding.projectName)
  }
  if (binding.updatedAt > existing.lastUsedAt) existing.lastUsedAt = binding.updatedAt
  if (binding.createdAt > existing.addedAt) existing.addedAt = binding.createdAt
  const sameSource = existing.sourceProjectId === binding.projectId
  if ((sameSource && state !== existing.libraryState) || statePriority[state] > statePriority[existing.libraryState]) {
    const next = libraryAsset(asset, binding, state)
    next.projectIds = existing.projectIds
    next.projectNames = existing.projectNames
    next.addedAt = existing.addedAt
    next.lastUsedAt = existing.lastUsedAt
    return next
  }
  return existing
}

/** @param {{projectId: string, authorizationId: string, assetId: string, sceneId: string, startUs: number, durationUs: number, orientation: string, now: string}} input */
const minimalTimeline = ({ projectId, authorizationId, assetId, sceneId, startUs, durationUs, orientation, now }) => ({
  schemaVersion: 1,
  timelineId: stableId('timeline', projectId, now, assetId, sceneId),
  projectId,
  revision: 1,
  parentRevision: null,
  parentRevisionFingerprint: null,
  status: 'draft',
  createdAt: now,
  durationUs,
  orientation,
  fps: { numerator: 30, denominator: 1 },
  source: {
    kind: 'editor',
    editPlanFingerprint: null,
    templateFingerprint: null,
    instructionFingerprint: null,
  },
  tracks: [{
    trackId: stableId('track', projectId, 'material-library-primary'),
    order: 0,
    enabled: true,
    locked: false,
    kind: 'video',
    role: 'primary',
    segments: [{
      segmentId: stableId('segment', projectId, authorizationId, assetId, sceneId, String(startUs), String(durationUs)),
      kind: 'video',
      asset: { authorizationId, assetId, sceneId },
      sourceRange: { startUs, durationUs },
      targetRange: { startUs: 0, durationUs },
      fit: 'cover',
      volume: 1,
      speed: { numerator: 1, denominator: 1 },
      keyframes: [],
      effects: [],
      audit: { origin: 'editor', candidateId: sceneId, instructionFingerprint: null },
      transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
    }],
  }],
  markers: [],
  capabilityRequirements: [],
})

/** @param {{timeline: Record<string, any>, authorizationId: string, assetId: string, sceneId: string, startUs: number, durationUs: number, now: string}} input */
const appendSceneToTimeline = ({ timeline, authorizationId, assetId, sceneId, startUs, durationUs, now }) => {
  const next = clone(timeline)
  const primary = next.tracks.find((/** @type {Record<string, any>} */ track) => track.kind === 'video' && track.role === 'primary')
  if (!primary || !Array.isArray(primary.segments)) {
    throw new MaterialLibraryError('MATERIAL_LIBRARY_TIMELINE_INVALID', 409)
  }
  if (primary.segments.some((/** @type {Record<string, any>} */ segment) =>
    segment.asset?.assetId === assetId &&
    segment.asset?.sceneId === sceneId &&
    segment.sourceRange?.startUs === startUs &&
    segment.sourceRange?.durationUs === durationUs)) {
    return null
  }
  const targetStartUs = next.durationUs
  const previous = primary.segments.at(-1)
  if (previous?.transitionOut?.capabilityId === 'transition.none') {
    previous.transitionOut = { capabilityId: 'transition.cut', durationUs: 0, parameters: {} }
  }
  primary.segments.push({
    segmentId: stableId('segment', next.projectId, authorizationId, assetId, sceneId, String(startUs), String(durationUs), String(next.revision + 1)),
    kind: 'video',
    asset: { authorizationId, assetId, sceneId },
    sourceRange: { startUs, durationUs },
    targetRange: { startUs: targetStartUs, durationUs },
    fit: 'cover',
    volume: 1,
    speed: { numerator: 1, denominator: 1 },
    keyframes: [],
    effects: [],
    audit: { origin: 'editor', candidateId: sceneId, instructionFingerprint: null },
    transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
  })
  next.revision += 1
  next.parentRevision = timeline.revision
  next.parentRevisionFingerprint = timeline.revisionFingerprint
  next.status = 'draft'
  next.createdAt = now
  next.durationUs += durationUs
  next.source = { ...next.source, kind: 'editor', instructionFingerprint: null }
  return next
}

/**
 * Private material-library service. All paths and authorization records stay
 * inside this boundary; callers receive only public analyzed-material fields.
 * @param {{
 *   dataRoot: string,
 *   projectRepository: {list: () => ProjectRecord[] | Promise<ProjectRecord[]>, get: (id: string) => ProjectRecord | null | Promise<ProjectRecord | null>, saveIfCurrent: Function},
 *   authorizationRepository: {get: (id: string) => Record<string, unknown> | null | Promise<Record<string, unknown> | null>},
 *   materialAnalysisProvider: {getStatus?: () => {available?: boolean, state?: unknown, analyzerVersion?: string}, restoreAnalysis: (input: {projectId: string, authorizationId: string, assetId?: string, assetIds?: string[]}) => Promise<MaterialsSnapshot>, restoreCompletedAnalysis?: (input: {projectId: string, authorizationId: string, assetId?: string, assetIds?: string[]}) => Promise<MaterialsSnapshot>, analyzeMaterials: (input: {projectId: string, authorizationId: string, signal: AbortSignal, onProgress: (progress?: {total?: number, analyzed?: number, overallPercent?: number, assets?: Array<{status?: string, stage?: unknown, label?: unknown, detail?: unknown}>}) => Promise<void>}) => Promise<MaterialsSnapshot & {total?: number, analyzed?: number, failed?: number}>},
 *   richTimelineRepository: {getCurrent: (input: {projectId: string}) => Promise<Record<string, any> | null>, getRevision: (pointer: Record<string, any>) => Promise<Record<string, any> | null>, saveDraftAndSetCurrent: (input: {timeline: Record<string, any>, expectedCurrent: Record<string, any> | null}) => Promise<Record<string, any>>},
 *   authorizeMaterialsFromPath: (input: {projectId: string, folderLabel?: string, sourceType?: 'file'|'folder'|'auto', sessionId?: string, nodeId?: string}) => Promise<{authorizationId?: string, authorized?: boolean, total?: number, sourceType?: 'file'|'folder'|'auto'}>,
 *   securePrivateRoot?: ((root: string) => Promise<unknown>) | null,
 * }} input
 */
export const createMaterialLibraryService = async ({
  dataRoot,
  projectRepository,
  authorizationRepository,
  materialAnalysisProvider,
  richTimelineRepository,
  authorizeMaterialsFromPath,
  securePrivateRoot,
}) => {
  if (
    typeof projectRepository?.list !== 'function' ||
    typeof projectRepository?.get !== 'function' ||
    typeof projectRepository?.saveIfCurrent !== 'function' ||
    typeof authorizationRepository?.get !== 'function' ||
    typeof materialAnalysisProvider?.restoreAnalysis !== 'function' ||
    typeof materialAnalysisProvider?.analyzeMaterials !== 'function' ||
    typeof richTimelineRepository?.getCurrent !== 'function' ||
    typeof richTimelineRepository?.getRevision !== 'function' ||
    typeof richTimelineRepository?.saveDraftAndSetCurrent !== 'function' ||
    typeof authorizeMaterialsFromPath !== 'function'
  ) throw new MaterialLibraryError('MATERIAL_LIBRARY_DEPENDENCY_UNAVAILABLE')

  const preferenceStore = await createPreferenceStore({ dataRoot, securePrivateRoot })
  const importsPath = resolve(dataRoot, 'material-library', 'imports.json')
  const importJobsPath = resolve(dataRoot, 'material-library', 'import-jobs.json')
  const catalogPath = resolve(dataRoot, 'material-library', 'catalog-index.json')
  const projectReferencesPath = resolve(dataRoot, 'material-library', 'project-references.json')
  /** @type {Array<{id: string, name: string, authorizationId: string, createdAt: string, updatedAt: string}>} */
  let libraryImports = []
  try {
    const loaded = JSON.parse(await readFile(importsPath, 'utf8'))
    if (Array.isArray(loaded)) libraryImports = loaded.filter((/** @type {Record<string, unknown>} */ entry) =>
      opaqueId(entry?.id) && opaqueId(entry?.authorizationId) && safeName(entry?.name) && validTimestamp(entry?.createdAt) && validTimestamp(entry?.updatedAt))
  } catch (error) {
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw new MaterialLibraryError('MATERIAL_LIBRARY_STORAGE_CORRUPT')
  }
  /** @type {Array<{targetProjectId: string, sourceProjectId: string, sourceAuthorizationId: string, assetId: string, sceneId: string, start: number, end: number, createdAt: string}>} */
  let projectReferences = []
  try {
    const loaded = JSON.parse(await readFile(projectReferencesPath, 'utf8'))
    if (loaded?.schema_version === schemaVersion && Array.isArray(loaded.references)) {
      projectReferences = loaded.references.filter((/** @type {Record<string, any>} */ entry) =>
        opaqueId(entry?.targetProjectId) && opaqueId(entry?.sourceProjectId) &&
        opaqueId(entry?.sourceAuthorizationId) && opaqueId(entry?.assetId) && opaqueId(entry?.sceneId) &&
        Number.isFinite(entry?.start) && entry.start >= 0 &&
        Number.isFinite(entry?.end) && entry.end > entry.start && validTimestamp(entry?.createdAt))
    }
  } catch (error) {
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw new MaterialLibraryError('MATERIAL_LIBRARY_STORAGE_CORRUPT')
  }
  /** @type {ImportJob[]} */
  let importJobs = []
  let recoveredImportJobs = false
  try {
    const loaded = JSON.parse(await readFile(importJobsPath, 'utf8'))
    if (loaded?.schema_version === schemaVersion && Array.isArray(loaded.jobs)) {
      importJobs = loaded.jobs.filter((/** @type {Record<string, any>} */ job) =>
        opaqueId(job?.jobId) &&
        opaqueId(job?.importId) &&
        ['file', 'folder'].includes(job?.sourceType) &&
        ['queued', 'running', 'succeeded', 'failed', 'cancelled'].includes(job?.status) &&
        Number.isSafeInteger(job?.total) && job.total >= 0 &&
        Number.isSafeInteger(job?.analyzed) && job.analyzed >= 0 &&
        Number.isSafeInteger(job?.failed) && job.failed >= 0 &&
        Number.isInteger(job?.progressPercent) && job.progressPercent >= 0 && job.progressPercent <= 100 &&
        validTimestamp(job?.createdAt) && validTimestamp(job?.updatedAt))
        .map((/** @type {Record<string, any>} */ job) => ({
          ...job,
          // Stage fields were added after the initial import-job schema. Keep
          // old persisted jobs readable without trusting arbitrary text.
          stage: job.status === 'succeeded'
            ? 'complete'
            : job.status === 'failed'
              ? 'failed'
              : safeImportStage(job.stage),
          currentLabel: safeImportLabel(job.currentLabel) ? job.currentLabel.trim() : null,
        }))
        .map((/** @type {ImportJob} */ job) => ({ ...job, detail: publicImportDetail(job) }))
      const recoveredAt = timestamp()
      importJobs = importJobs.map((job) => ['queued', 'running'].includes(job.status)
        ? {
            ...job,
            status: 'failed',
            currentLabel: null,
            detail: 'OpenVideo 重启后任务已中断，请重新添加素材。',
            error: { code: 'MATERIAL_LIBRARY_IMPORT_INTERRUPTED', recoverable: true },
            updatedAt: recoveredAt,
          }
        : job)
      recoveredImportJobs = importJobs.some((job) => job.error?.code === 'MATERIAL_LIBRARY_IMPORT_INTERRUPTED')
    }
  } catch (error) {
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw new MaterialLibraryError('MATERIAL_LIBRARY_STORAGE_CORRUPT')
  }
  let importQueue = Promise.resolve()
  let importJobQueue = Promise.resolve()
  let projectReferenceQueue = Promise.resolve()
  // Library navigation is read-heavy: restoring every project's analysis on each
  // route change makes the sidebar feel blocked. Keep a short-lived sanitized
  // snapshot and share an in-flight rebuild across concurrent requests.
  // Browsing the library must not walk every authorized source directory. The
  // saved project material cards are already sanitized and are sufficient for
  // a catalog view; selected media is still revalidated by addReference and
  // the media handlers before it can be used. Keep that lightweight snapshot
  // briefly across sidebar navigation instead of rebuilding it on every click.
  const catalogCacheTtlMs = 60_000
  /** @type {CatalogCache | null} */
  let catalogCache = null
  /** @returns {{available: boolean, state: unknown, analyzerVersion: string | null} | null} */
  const getCurrentAnalyzerStatus = () => {
    try {
      const status = materialAnalysisProvider.getStatus?.()
      if (!status || typeof status !== 'object') return null
      return {
        available: status.available === true,
        state: status.state,
        analyzerVersion: typeof status.analyzerVersion === 'string' && status.analyzerVersion.trim()
          ? status.analyzerVersion.trim()
          : null,
      }
    } catch {
      return null
    }
  }
  /** @param {any} materials @returns {boolean} */
  const isCurrentAnalysisSnapshot = (materials) => (
    materials?.analysisStatus === 'ready' &&
    materials?.queued === 0 &&
    (() => {
      const status = getCurrentAnalyzerStatus()
      return status?.available === true && status.state === 'ready' &&
        Boolean(status.analyzerVersion) && materials?.analyzerVersion === status.analyzerVersion
    })()
  )
  try {
    const persisted = JSON.parse(await readFile(catalogPath, 'utf8'))
    if (persisted?.schema_version === schemaVersion && Array.isArray(persisted.assets)) {
      catalogCache = { createdAt: Date.now(), assets: clone(persisted.assets), needsStateReconcile: true }
    }
  } catch (error) {
    if (/** @type {{code?: string}} */ (error)?.code !== 'ENOENT') throw new MaterialLibraryError('MATERIAL_LIBRARY_STORAGE_CORRUPT')
  }
  /** @type {Promise<LibraryAsset[]> | null} */
  let catalogBuild = null
  const invalidateCatalogCache = () => { catalogCache = null }
  /** @param {LibraryAsset[]} assets */
  const persistCatalog = async (assets) => {
    const temporaryPath = `${catalogPath}.${randomUUID()}.tmp`
    await writeFile(temporaryPath, JSON.stringify({ schema_version: schemaVersion, assets }), { encoding: 'utf8', mode: 0o600 })
    await rename(temporaryPath, catalogPath)
  }
  /** @param {LibraryImport[]} next */
  const persistImports = async (next) => {
    const temporaryPath = `${importsPath}.${randomUUID()}.tmp`
    await writeFile(temporaryPath, JSON.stringify(next), { encoding: 'utf8', mode: 0o600 })
    await rename(temporaryPath, importsPath)
  }
  /** @param {ProjectReference[]} next */
  const persistProjectReferences = async (next) => {
    const temporaryPath = `${projectReferencesPath}.${randomUUID()}.tmp`
    await writeFile(temporaryPath, JSON.stringify({ schema_version: schemaVersion, references: next }), { encoding: 'utf8', mode: 0o600 })
    await rename(temporaryPath, projectReferencesPath)
  }
  /** @param {ProjectReference} record */
  const rememberProjectReference = (record) => {
    const operation = projectReferenceQueue.then(async () => {
      const exists = projectReferences.some((entry) =>
        entry.targetProjectId === record.targetProjectId &&
        entry.assetId === record.assetId && entry.sceneId === record.sceneId &&
        Math.abs(entry.start - record.start) < 0.001 && Math.abs(entry.end - record.end) < 0.001)
      if (exists) return { record: clone(record), added: false }
      const next = [...projectReferences, record]
      await persistProjectReferences(next)
      projectReferences = clone(next)
      return { record: clone(record), added: true }
    })
    projectReferenceQueue = operation.then(() => undefined, () => undefined)
    return operation
  }
  /** @param {ProjectReference} record */
  const forgetProjectReference = (record) => {
    const operation = projectReferenceQueue.then(async () => {
      const next = projectReferences.filter((entry) => !(
        entry.targetProjectId === record.targetProjectId &&
        entry.sourceProjectId === record.sourceProjectId &&
        entry.assetId === record.assetId &&
        entry.sceneId === record.sceneId &&
        Math.abs(entry.start - record.start) < 0.001 &&
        Math.abs(entry.end - record.end) < 0.001
      ))
      if (next.length === projectReferences.length) return false
      await persistProjectReferences(next)
      projectReferences = clone(next)
      return true
    })
    projectReferenceQueue = operation.then(() => undefined, () => undefined)
    return operation
  }
  /** @param {LibraryImport} record */
  const appendImport = (record) => {
    const operation = importQueue.then(async () => {
      const next = [...libraryImports, record]
      await persistImports(next)
      libraryImports = clone(next)
      return clone(record)
    })
    importQueue = operation.then(() => undefined, () => undefined)
    return operation
  }
  /** @param {ImportJob[]} next */
  const persistImportJobs = async (next) => {
    const temporaryPath = `${importJobsPath}.${randomUUID()}.tmp`
    await writeFile(temporaryPath, JSON.stringify({ schema_version: schemaVersion, jobs: next }), { encoding: 'utf8', mode: 0o600 })
    await rename(temporaryPath, importJobsPath)
  }
  if (recoveredImportJobs) await persistImportJobs(importJobs)
  /** @type {Map<string, AbortController>} */
  const importControllers = new Map()
  /** @param {ImportJob} job */
  const prependImportJob = (job) => {
    const operation = importJobQueue.then(async () => {
      const next = [job, ...importJobs.filter((entry) => entry.jobId !== job.jobId)].slice(0, 500)
      await persistImportJobs(next)
      importJobs = clone(next)
      return publicImportJob(job)
    })
    importJobQueue = operation.then(() => undefined, () => undefined)
    return operation
  }
  /** @param {ImportJob} job */
  const publicImportJob = (job) => ({
    jobId: job.jobId,
    importId: job.importId,
    sourceType: job.sourceType,
    status: job.status,
    total: job.total,
    analyzed: job.analyzed,
    failed: job.failed,
    progressPercent: job.progressPercent,
    stage: safeImportStage(job.stage),
    currentLabel: safeImportLabel(job.currentLabel) ? job.currentLabel.trim() : null,
    detail: publicImportDetail(job),
    error: job.error,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
  })
  const listImportJobs = async () => ({
    schema_version: schemaVersion,
    jobs: clone(importJobs)
      .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))
      .map(publicImportJob),
  })
  /** @param {string} jobId @param {Partial<ImportJob>} patch */
  const updateImportJob = async (jobId, patch) => {
    const operation = importJobQueue.then(async () => {
      const next = importJobs.map((job) => job.jobId === jobId
        ? { ...job, ...patch, updatedAt: timestamp() }
        : job)
      await persistImportJobs(next)
      importJobs = clone(next)
      const updated = importJobs.find((job) => job.jobId === jobId)
      if (!updated) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_FOUND', 404)
      return publicImportJob(updated)
    })
    importJobQueue = operation.then(() => undefined, () => undefined)
    return operation
  }
  /** @param {string} jobId */
  const runImportJob = async (jobId) => {
    const job = importJobs.find((entry) => entry.jobId === jobId)
    const record = libraryImports.find((entry) => entry.id === job?.importId)
    if (!job || !record) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_FOUND', 404)
    if (importControllers.has(jobId)) return publicImportJob(job)
    const controller = new AbortController()
    importControllers.set(jobId, controller)
    let lastPersistedPercent = -1
    let lastPersistedAt = 0
    let lastVisibleAnalyzed = -1
    /** @type {ImportStage | null} */
    let lastStage = null
    /** @type {string | null} */
    let lastCurrentLabel = null
    /** @type {string | null} */
    let lastDetail = null
    try {
      await updateImportJob(jobId, {
        status: 'running', progressPercent: 0, analyzed: 0, failed: 0,
        stage: 'scanning', currentLabel: null,
        detail: job.sourceType === 'folder' ? '正在批量分析文件夹中的视频。' : '正在分析视频。',
        error: null,
      })
      const result = await materialAnalysisProvider.analyzeMaterials({
        projectId: record.id,
        authorizationId: record.authorizationId,
        signal: controller.signal,
        onProgress: async (progress = {}) => {
          const total = typeof progress.total === 'number' && Number.isSafeInteger(progress.total) && progress.total >= 0 ? progress.total : job.total
          const analyzed = typeof progress.analyzed === 'number' && Number.isSafeInteger(progress.analyzed) && progress.analyzed >= 0 ? progress.analyzed : 0
          const percent = typeof progress.overallPercent === 'number' && Number.isFinite(progress.overallPercent)
            ? Math.max(0, Math.min(99, Math.round(progress.overallPercent)))
            : total > 0 ? Math.max(0, Math.min(99, Math.round(analyzed / total * 100))) : 0
          const activeAsset = Array.isArray(progress.assets)
            ? progress.assets.find((asset) => asset?.status === 'analyzing')
            : null
          const stage = safeImportStage(activeAsset?.stage)
          const currentLabel = safeImportLabel(activeAsset?.label) ? activeAsset.label.trim() : null
          const detail = safeImportDetail(stage, activeAsset?.detail)
          const now = Date.now()
          const completedCountIncreased = analyzed > lastVisibleAnalyzed
          const presentationChanged = stage !== lastStage || currentLabel !== lastCurrentLabel || detail !== lastDetail
          if (!presentationChanged && !completedCountIncreased && percent === lastPersistedPercent && now - lastPersistedAt < 1_000) return
          if (!presentationChanged && !completedCountIncreased && percent < lastPersistedPercent + 2 && now - lastPersistedAt < 1_000) return
          lastPersistedPercent = percent
          lastPersistedAt = now
          lastStage = stage
          lastCurrentLabel = currentLabel
          lastDetail = detail
          await updateImportJob(jobId, {
            status: 'running', total, analyzed, progressPercent: percent,
            stage, currentLabel, detail,
          })
          if (completedCountIncreased) {
            lastVisibleAnalyzed = analyzed
            invalidateCatalogCache()
          }
        },
      })
      await updateImportJob(jobId, {
        status: 'succeeded',
        total: typeof result?.total === 'number' && Number.isSafeInteger(result.total) ? result.total : job.total,
        analyzed: typeof result?.analyzed === 'number' && Number.isSafeInteger(result.analyzed) ? result.analyzed : (result?.assets?.length ?? job.analyzed),
        failed: typeof result?.failed === 'number' && Number.isSafeInteger(result.failed) ? result.failed : 0,
        progressPercent: 100,
        stage: 'complete', currentLabel: null,
        detail: job.sourceType === 'folder' ? '文件夹素材已批量导入并完成分析。' : '视频已导入并完成分析。',
        error: null,
      })
      invalidateCatalogCache()
    } catch (error) {
      const cancelled = controller.signal.aborted
      const prior = importJobs.find((entry) => entry.jobId === jobId)
      await updateImportJob(jobId, {
        status: cancelled ? 'cancelled' : 'failed',
        // A failure does not erase the last completed pipeline stages.
        stage: cancelled ? 'scanning' : safeImportStage(prior?.stage), currentLabel: null,
        detail: cancelled ? '素材导入已取消。' : '素材导入或分析失败，请重试。',
        error: cancelled ? null : {
          code: materialErrorCode(error) ?? 'MATERIAL_LIBRARY_IMPORT_FAILED',
          recoverable: true,
        },
      }).catch(() => undefined)
    } finally {
      importControllers.delete(jobId)
    }
    const completed = importJobs.find((entry) => entry.jobId === jobId)
    if (!completed) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_FOUND', 404)
    return publicImportJob(completed)
  }

  /** @param {string} jobId */
  const cancelImportJob = async (jobId) => {
    const job = importJobs.find((entry) => entry.jobId === jobId)
    if (!job) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_FOUND', 404)
    if (!['queued', 'running'].includes(job.status)) return publicImportJob(job)
    importControllers.get(jobId)?.abort('cancelled')
    if (!importControllers.has(jobId)) {
      return updateImportJob(jobId, { status: 'cancelled', stage: 'scanning', currentLabel: null, detail: '素材导入已取消。', error: null })
    }
    return publicImportJob({ ...job, status: 'cancelled', stage: 'scanning', currentLabel: null, detail: '正在取消素材导入。' })
  }

  /** @param {string} jobId */
  const retryImportJob = async (jobId) => {
    const job = importJobs.find((entry) => entry.jobId === jobId)
    if (!job) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_FOUND', 404)
    if (!['failed', 'cancelled', 'succeeded'].includes(job.status)) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_RETRYABLE', 409)
    const queued = await updateImportJob(jobId, {
      status: 'queued', progressPercent: 0, analyzed: 0, failed: 0,
      stage: 'scanning', currentLabel: null,
      detail: '素材导入已重新排队。', error: null,
    })
    void runImportJob(jobId)
    return queued
  }

  /** @param {string} jobId */
  const dismissImportJob = async (jobId) => {
    const job = importJobs.find((entry) => entry.jobId === jobId)
    if (!job) throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_FOUND', 404)
    if (['queued', 'running'].includes(job.status)) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_IMPORT_JOB_NOT_DISMISSABLE', 409)
    }
    const operation = importJobQueue.then(async () => {
      const next = importJobs.filter((entry) => entry.jobId !== jobId)
      await persistImportJobs(next)
      importJobs = clone(next)
      return publicImportJob(job)
    })
    importJobQueue = operation.then(() => undefined, () => undefined)
    return operation
  }

  /** @param {CatalogCache} cached */
  const reconcileCachedCatalogStates = async (cached) => {
    if (!cached?.needsStateReconcile) return cached?.assets ?? []
    const sourceIds = [...new Set(cached.assets.flatMap((asset) => [
      asset?.sourceProjectId,
      ...(Array.isArray(asset?.projectIds) ? asset.projectIds : []),
    ]).filter((id) => opaqueId(id)))]
    const sourceProjects = await Promise.all(sourceIds.map(async (id) => /** @type {const} */ ([
      id,
      await Promise.resolve(projectRepository.get(id)),
    ])))
    const projectById = new Map(sourceProjects)
    const nextAssets = cached.assets.map((asset) => {
      // Standalone library imports are already backed by a private import
      // record. Their persisted state remains authoritative until a use-boundary
      // revalidation, while project-backed cards must reflect the current DTO.
      const assetSourceIds = [...new Set([
        asset?.sourceProjectId,
        ...(Array.isArray(asset?.projectIds) ? asset.projectIds : []),
      ].filter((id) => opaqueId(id)))]
      if (assetSourceIds.some((id) => libraryImports.some((entry) => entry.id === id))) return asset
      /** @type {{state: 'ready'|'stale'|'unavailable', sourceProjectId: string|null}} */
      let best = { state: 'unavailable', sourceProjectId: null }
      for (const sourceId of assetSourceIds) {
        const project = projectById.get(sourceId)
        const sourceAsset = project?.materials?.assets?.find((entry) => entry?.id === asset.id)
        /** @type {'ready'|'stale'|'unavailable'} */
        const state = !project
          ? 'unavailable'
          : !sourceAsset
            ? 'unavailable'
          : isCurrentAnalysisSnapshot(project.materials) &&
              sourceAsset.status === 'ready' && sourceAsset.analyzedPercent === 100
            ? 'ready'
            : 'stale'
        if (statePriority[state] > statePriority[best.state]) best = { state, sourceProjectId: sourceId }
      }
      return {
        ...asset,
        ...(best.sourceProjectId ? { sourceProjectId: best.sourceProjectId } : {}),
        libraryState: best.state,
        status: best.state === 'ready' ? 'ready' : 'failed',
        analyzedPercent: best.state === 'ready' ? 100 : asset.analyzedPercent ?? 0,
      }
    })
    cached.assets = clone(nextAssets)
    cached.needsStateReconcile = false
    return clone(cached.assets)
  }
  const catalogAssets = async () => {
    const now = Date.now()
    if (catalogCache) {
      if (catalogCache.needsStateReconcile) await reconcileCachedCatalogStates(catalogCache)
      if (now - catalogCache.createdAt >= catalogCacheTtlMs && !catalogBuild) {
        // A stale refresh must never turn a previously usable cached catalog
        // into an unhandled rejection. The next foreground request can retry.
        void buildCatalog().catch(() => undefined)
      }
      return clone(catalogCache.assets)
    }
    if (catalogBuild) return catalogBuild
    return buildCatalog()
  }
  const buildCatalog = async () => {
    if (catalogBuild) return catalogBuild
    catalogBuild = (async () => {
    const byId = new Map()
    const sources = [
      ...(await Promise.resolve(projectRepository.list())).map((project) => ({
        id: project?.id,
        name: project?.name,
        authorizationId: project?.materials?.authorizationId,
        materials: project?.materials,
        createdAt: project?.materials?.lastScanAt ?? project?.createdAt ?? project?.updatedAt,
        updatedAt: project?.updatedAt,
      })),
      ...libraryImports.map((entry) => ({
        id: entry.id,
        name: entry.name,
        authorizationId: entry.authorizationId,
        materials: null,
        createdAt: entry.createdAt,
        updatedAt: entry.updatedAt,
      })),
    ]
    for (const project of sources) {
      const authorizationId = project?.authorizationId
      if (!opaqueId(project?.id) || !opaqueId(authorizationId)) continue
      // Do not call restoreAnalysis here: it verifies the on-disk manifest and
      // recursively scans the source directory, which made a simple library
      // navigation block on every known source. This is an index view only.
      // Authorization and manifest freshness remain mandatory at the actual
      // use boundary (addReference, preview, and export).
      let materials = project.materials
      if (!materials && typeof projectRepository.get === 'function') {
        const fullProject = await Promise.resolve(projectRepository.get(project.id))
        materials = fullProject?.materials ?? null
      }
      /** @type {LibraryState} */
      let state = isCurrentAnalysisSnapshot(materials) ? 'ready' : 'stale'
      // Standalone library imports do not have a project snapshot yet. Keep
      // their in-progress visibility by restoring only those import records;
      // regular project navigation never reaches this expensive path.
      if (!materials) {
        try {
          // Successful imports persist to the analyzer index and then delete
          // checkpoints. Restore the completed index first so a finished
          // standalone import remains visible; checkpoints cover in-flight jobs.
          materials = await materialAnalysisProvider.restoreAnalysis({
            projectId: project.id,
            authorizationId,
          })
          state = isCurrentAnalysisSnapshot(materials) ? 'ready' : 'stale'
        } catch {
          try {
            const restoreCompletedAnalysis = materialAnalysisProvider.restoreCompletedAnalysis
            if (typeof restoreCompletedAnalysis !== 'function') throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
            materials = await restoreCompletedAnalysis({
              projectId: project.id,
              authorizationId,
            })
            state = isCurrentAnalysisSnapshot(materials) ? 'ready' : 'stale'
          } catch {
            materials = null
            state = 'unavailable'
          }
        }
      }
      /** @type {LibraryBinding} */
      const binding = {
        projectId: project.id,
        projectName: typeof project.name === 'string' ? project.name : '未命名项目',
        createdAt: validTimestamp(project.createdAt) ? project.createdAt : timestamp(),
        updatedAt: validTimestamp(project.updatedAt) ? project.updatedAt : timestamp(),
      }
      for (const asset of materials?.assets ?? []) {
        if (!opaqueId(asset?.id)) continue
        const visibleState = asset.status === 'ready' && asset.analyzedPercent === 100 && state === 'unavailable'
          ? 'stale'
          : state
        byId.set(asset.id, mergeLibraryAsset(byId.get(asset.id), asset, binding, visibleState))
      }
    }
    const preferences = preferenceStore.read()
    const assets = [...byId.values()]
      .sort((left, right) => right.lastUsedAt.localeCompare(left.lastUsedAt))
    catalogCache = { createdAt: Date.now(), assets: clone(assets), needsStateReconcile: false }
    await persistCatalog(assets)
    return clone(assets)
    })()
    try {
      return await catalogBuild
    } finally {
      catalogBuild = null
    }
  }

  /** @param {{refresh?: boolean, cursor?: string | null, limit?: number}} [input] */
  const listAssets = async (input = {}) => {
    if (input?.refresh === true) invalidateCatalogCache()
    const assets = await catalogAssets()
    const preferences = preferenceStore.read()
    const ordered = assets
      .map((asset) => ({ ...asset, lastUsedAt: preferences.lastViewedAt[asset.id] ?? asset.lastUsedAt }))
      .sort((left, right) =>
        right.lastUsedAt.localeCompare(left.lastUsedAt) || left.id.localeCompare(right.id))
    const cursor = input?.cursor ?? null
    if (cursor !== null && (!opaqueId(cursor) || !ordered.some((asset) => asset.id === cursor))) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_PAGE_INVALID', 400)
    }
    const start = cursor ? ordered.findIndex((asset) => asset.id === cursor) + 1 : 0
    const limit = catalogPageLimit(input?.limit)
    const assetsPage = ordered.slice(Math.max(0, start), Math.max(0, start) + limit)
    const nextCursor = start >= 0 && start + limit < ordered.length
      ? assetsPage.at(-1)?.id ?? null
      : null
    return {
      schema_version: schemaVersion,
      assets: assetsPage.map(catalogSummary),
      preferences,
      folders: catalogFolderSummaries(ordered),
      counts: catalogStatusCounts(ordered),
      page: { total: ordered.length, limit, nextCursor },
    }
  }

  /** @param {string} assetId */
  const getAsset = async (assetId) => {
    if (!opaqueId(assetId)) throw new MaterialLibraryError('MATERIAL_LIBRARY_ASSET_INVALID', 400)
    const asset = (await catalogAssets()).find((entry) => entry.id === assetId)
    if (!asset) throw new MaterialLibraryError('MATERIAL_LIBRARY_ASSET_NOT_FOUND', 404)
    const preferences = preferenceStore.read()
    return {
      schema_version: schemaVersion,
      asset: {
        ...clone(asset),
        lastUsedAt: preferences.lastViewedAt[asset.id] ?? asset.lastUsedAt,
      },
    }
  }

  /** @param {unknown} preferences */
  const savePreferences = async (preferences) => ({
    schema_version: schemaVersion,
    preferences: await preferenceStore.write(preferences),
  })

  /**
   * @param {string} projectId
   * @param {string} assetId
   * @param {{validateAnalysis?: boolean}} [options]
   * @returns {Promise<MediaBinding | null>}
   */
  const resolveMediaBinding = async (projectId, assetId, options = {}) => {
    if (!opaqueId(projectId) || !opaqueId(assetId)) return null
    const projectReference = projectReferences.find((entry) =>
      entry.targetProjectId === projectId && entry.assetId === assetId)
    const importRecord = libraryImports.find((entry) => entry.id === projectId)
    if (projectReference && !await Promise.resolve(projectRepository.get(projectId))) return null
    const binding = projectReference
      ? {
          projectId: projectReference.sourceProjectId,
          authorizationId: projectReference.sourceAuthorizationId,
          assetId: projectReference.assetId,
          sceneId: projectReference.sceneId,
        }
      : importRecord
        ? { projectId: importRecord.id, authorizationId: importRecord.authorizationId, assetId }
        : null
    if (!binding) return null
    if (options.validateAnalysis !== false) {
      const analysis = await materialAnalysisProvider.restoreAnalysis({
        projectId: binding.projectId,
        authorizationId: binding.authorizationId,
        assetId,
      })
      if (!analysis?.assets?.some((/** @type {{id?: string}} */ asset) => asset?.id === assetId)) return null
    }
    return binding
  }

  /**
   * Storyboard search uses the project's own folder authorization plus
   * explicit project references. Each scope keeps its own authorization
   * identity so search and later preview/export never treat one project
   * folder as global access.
   * @param {string} projectId
   * @returns {Promise<Array<{projectId: string, authorizationId: string}>>}
   */
  const collectStoryboardSearchScopes = async (projectId) => {
    if (!opaqueId(projectId)) return []
    /** @type {Array<{projectId: string, authorizationId: string}>} */
    const scopes = []
    const seen = new Set()
    /** @param {unknown} sourceProjectId @param {unknown} authorizationId */
    const add = (sourceProjectId, authorizationId) => {
      if (!opaqueId(sourceProjectId) || !opaqueId(authorizationId)) return
      const key = `${sourceProjectId}\u0000${authorizationId}`
      if (seen.has(key)) return
      seen.add(key)
      scopes.push({ projectId: sourceProjectId, authorizationId })
    }
    const project = await Promise.resolve(projectRepository.get(projectId))
    if (opaqueId(project?.materials?.authorizationId)) {
      add(projectId, project.materials.authorizationId)
    }
    for (const reference of projectReferences) {
      if (reference.targetProjectId === projectId) {
        add(reference.sourceProjectId, reference.sourceAuthorizationId)
      }
    }
    return scopes.slice(0, 64)
  }

  /**
   * @param {{projectId: string, authorizationId: string}} scope
   * @param {string} sceneId
   * @param {string} [preferredAssetId]
   * @returns {Promise<MediaBinding | null>}
   */
  const restoreSceneBindingFromScope = async (scope, sceneId, preferredAssetId) => {
    try {
      const analysis = await materialAnalysisProvider.restoreAnalysis({
        projectId: scope.projectId,
        authorizationId: scope.authorizationId,
        ...(opaqueId(preferredAssetId) ? { assetId: preferredAssetId } : {}),
      })
      const assets = Array.isArray(analysis?.assets) ? analysis.assets : []
      const asset = (opaqueId(preferredAssetId)
        ? assets.find((entry) => entry?.id === preferredAssetId)
        : null)
        ?? assets.find((entry) => entry?.scenes?.some((scene) => scene?.id === sceneId))
      if (!opaqueId(asset?.id) || !asset.scenes?.some((scene) => scene?.id === sceneId)) return null
      return {
        projectId: scope.projectId,
        authorizationId: scope.authorizationId,
        assetId: asset.id,
        sceneId,
      }
    } catch {
      return null
    }
  }

  /** @param {string} projectId @param {string} sceneId */
  const resolveSceneBinding = async (projectId, sceneId) => {
    if (!opaqueId(projectId) || !opaqueId(sceneId)) return null
    const referencedForTarget = projectReferences.filter((entry) =>
      entry.targetProjectId === projectId)
    const reference = referencedForTarget.find((entry) => entry.sceneId === sceneId)
    if (reference) {
      const binding = await resolveMediaBinding(projectId, reference.assetId)
      if (!binding || binding.sceneId !== sceneId) return null
      return restoreSceneBindingFromScope(
        { projectId: binding.projectId, authorizationId: binding.authorizationId },
        sceneId,
        binding.assetId,
      )
    }
    // A project reference admits the whole source asset. Another logical scene
    // on that same asset can still be rebound through the stored source auth.
    const scopes = await collectStoryboardSearchScopes(projectId)
    let preferredAssetId
    try {
      const catalogAsset = (await catalogAssets()).find((entry) =>
        Array.isArray(entry.scenes) && entry.scenes.some((scene) => scene?.id === sceneId))
      if (opaqueId(catalogAsset?.id)) preferredAssetId = catalogAsset.id
      const assetReference = opaqueId(preferredAssetId)
        ? referencedForTarget.find((entry) => entry.assetId === preferredAssetId)
        : null
      if (assetReference) {
        const binding = await restoreSceneBindingFromScope(
          {
            projectId: assetReference.sourceProjectId,
            authorizationId: assetReference.sourceAuthorizationId,
          },
          sceneId,
          preferredAssetId,
        )
        if (binding) return binding
      }
      const preferredScopes = opaqueId(catalogAsset?.sourceProjectId)
        ? scopes.filter((scope) =>
          scope.projectId === catalogAsset.sourceProjectId ||
          (Array.isArray(catalogAsset.projectIds) && catalogAsset.projectIds.includes(scope.projectId)))
        : []
      for (const scope of preferredScopes) {
        const binding = await restoreSceneBindingFromScope(scope, sceneId, preferredAssetId)
        if (binding) return binding
      }
    } catch {
      // Catalog is only a hint. Scope restore remains the use-boundary check.
    }
    for (const scope of scopes) {
      const binding = await restoreSceneBindingFromScope(scope, sceneId, preferredAssetId)
      if (binding) return binding
    }
    return null
  }

  /** @param {string} projectId */
  const getProjectReferenceState = async (projectId) => {
    if (!opaqueId(projectId)) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_INVALID', 400)
    const references = projectReferences.filter((entry) => entry.targetProjectId === projectId)
    const catalog = await catalogAssets()
    const targetExists = references.length > 0 && Boolean(await Promise.resolve(projectRepository.get(projectId)))
    // List/paint must stay catalog + authorization only. restoreAnalysis
    // recursively verifies manifests and blocked the material cards for tens
    // of seconds; preview/export/add still revalidate at the use boundary.
    let availableCount = 0
    const publicReferences = []
    for (const reference of references) {
      const asset = catalog.find((entry) => entry.id === reference.assetId)
      const scene = asset?.scenes?.find((entry) => entry.id === reference.sceneId)
      let availability = asset?.libraryState === 'stale' ? 'stale' : 'unavailable'
      if (targetExists && asset && scene) {
        try {
          const authorization = await Promise.resolve(authorizationRepository.get(reference.sourceAuthorizationId))
          if (!authorization || authorization.projectId !== reference.sourceProjectId || authorization.status !== 'authorized' || authorization.readOnly !== true) {
            throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
          }
          if (asset.libraryState === 'ready' &&
            Number.isFinite(scene.start) && Number.isFinite(scene.end) &&
            scene.end > scene.start && reference.start >= scene.start - 0.001 &&
            reference.end <= scene.end + 0.001) {
            availableCount += 1
            availability = 'available'
          }
        } catch (error) {
          // A revoked or changed source remains visible as unavailable, but no
          // private provider error or path crosses the public boundary.
          availability = bindingStateFor(error)
        }
      }
      publicReferences.push({
        assetId: reference.assetId,
        sceneId: reference.sceneId,
        start: reference.start,
        end: reference.end,
        label: typeof asset?.label === 'string' ? asset.label : '已加入素材',
        sourceProjectId: asset?.sourceProjectId ?? null,
        sourceProjectName: asset?.projectNames?.[0] ?? '总素材库',
        durationSeconds: typeof asset?.durationSeconds === 'number' ? asset.durationSeconds : 0,
        libraryState: asset?.libraryState ?? 'unavailable',
        availability,
        sceneSummary: typeof scene?.summary === 'string' ? scene.summary.slice(0, 240) : '',
      })
    }
    const currentPointer = await richTimelineRepository.getCurrent({ projectId })
    const timeline = currentPointer ? await richTimelineRepository.getRevision(currentPointer) : null
    const referencedSceneIds = new Set(references.map((entry) => entry.sceneId))
    const timelineContainsReference = timeline?.tracks?.some((/** @type {Record<string, any>} */ track) =>
      track.segments?.some((/** @type {Record<string, any>} */ segment) => referencedSceneIds.has(segment.asset?.sceneId)))
    return {
      schema_version: schemaVersion,
      referenceCount: references.length,
      availableCount,
      references: publicReferences,
      timeline: timelineContainsReference ? toPublicTimelineSummary(timeline) : null,
    }
  }

  /** @param {string} projectId */
  const removeProjectReferences = (projectId) => {
    if (!opaqueId(projectId)) return Promise.resolve(0)
    const operation = projectReferenceQueue.then(async () => {
      const next = projectReferences.filter((entry) =>
        entry.targetProjectId !== projectId && entry.sourceProjectId !== projectId)
      if (next.length === projectReferences.length) return 0
      await persistProjectReferences(next)
      const removed = projectReferences.length - next.length
      projectReferences = clone(next)
      return removed
    })
    projectReferenceQueue = operation.then(() => undefined, () => undefined)
    return operation
  }

  /** @param {{sourceType?: 'file'|'folder', folderLabel?: string, sessionId?: string, nodeId?: string}} input */
  const importMaterials = async (input) => {
    const requestedType = input?.sourceType === 'file' || input?.sourceType === 'folder' ? input.sourceType : undefined
    const libraryImportId = `library-${randomUUID()}`
    const label = safeName(input?.folderLabel)
      ? input.folderLabel.trim()
      : requestedType === 'file' ? '素材文件' : requestedType === 'folder' ? '素材文件夹' : undefined
    const authorization = await authorizeMaterialsFromPath({
      projectId: libraryImportId,
      folderLabel: label,
      sourceType: requestedType ?? 'auto',
      sessionId: input?.sessionId,
      nodeId: input?.nodeId,
    })
    if (!authorization?.authorizationId || authorization.authorized !== true) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_AUTHORIZATION_FAILED', 502)
    }
    const sourceType = authorization.sourceType === 'file' ? 'file' : requestedType === 'file' ? 'file' : 'folder'
    const now = timestamp()
    const record = { id: libraryImportId, name: label ?? (sourceType === 'file' ? '素材文件' : '素材文件夹'), authorizationId: authorization.authorizationId, createdAt: now, updatedAt: now }
    await appendImport(record)
    invalidateCatalogCache()
    /** @type {ImportJob} */
    const job = {
      jobId: `library-job-${randomUUID()}`,
      importId: libraryImportId,
      sourceType,
      status: 'queued',
      total: typeof authorization.total === 'number' && Number.isSafeInteger(authorization.total) ? authorization.total : 0,
      analyzed: 0,
      failed: 0,
      progressPercent: 0,
      stage: 'scanning',
      currentLabel: null,
      detail: sourceType === 'folder' ? '文件夹已加入队列，等待批量分析。' : '视频已加入队列，等待分析。',
      error: null,
      createdAt: now,
      updatedAt: now,
    }
    await prependImportJob(job)
    void runImportJob(job.jobId)
    return { schema_version: schemaVersion, job: publicImportJob(job) }
  }

  /** @param {string} projectId @param {unknown} input */
  const addReference = async (projectId, input) => {
    if (
      !opaqueId(projectId) ||
      !isRecord(input) ||
      Object.keys(input).sort().join('\u0000') !== ['assetId', 'end', 'sceneId', 'start'].sort().join('\u0000') ||
      !opaqueId(input.assetId) ||
      !opaqueId(input.sceneId) ||
      typeof input.start !== 'number' ||
      !Number.isFinite(input.start) ||
      input.start < 0 ||
      typeof input.end !== 'number' ||
      !Number.isFinite(input.end) ||
      input.end <= input.start
    ) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_INVALID', 400)

    const target = await Promise.resolve(projectRepository.get(projectId))
    if (!target) throw new MaterialLibraryError('PROJECT_NOT_FOUND', 404)
    const selected = (await getAsset(input.assetId)).asset
    const selectedScene = selected?.scenes?.find((scene) => scene.id === input.sceneId)
    if (!selected || selected.libraryState !== 'ready' || !selected.sourceProjectId || !selectedScene) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
    }
    const epsilon = 0.001
    if (input.start < selectedScene.start - epsilon || input.end > selectedScene.end + epsilon) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_RANGE_INVALID', 409)
    }

    const sourceProject = await Promise.resolve(projectRepository.get(selected.sourceProjectId))
    const sourceAuthorizationIdCandidate = sourceProject?.materials?.authorizationId ??
      libraryImports.find((entry) => entry.id === selected.sourceProjectId)?.authorizationId
    if (!opaqueId(sourceAuthorizationIdCandidate)) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
    }
    const sourceAuthorizationId = sourceAuthorizationIdCandidate
    const sourceRecord = await Promise.resolve(authorizationRepository.get(sourceAuthorizationId))
    if (!sourceRecord || sourceRecord.projectId !== selected.sourceProjectId || sourceRecord.status !== 'authorized' || sourceRecord.readOnly !== true) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
    }
    const currentAnalysis = await materialAnalysisProvider.restoreAnalysis({
      projectId: selected.sourceProjectId,
      authorizationId: sourceAuthorizationId,
      assetId: input.assetId,
    })
    const currentAsset = currentAnalysis?.assets?.find((asset) => asset?.id === input.assetId)
    const currentScene = currentAsset?.scenes?.find((scene) => scene?.id === input.sceneId)
    if (
      !isCurrentAnalysisSnapshot(currentAnalysis) ||
      currentAsset?.status !== 'ready' ||
      currentAsset?.analyzedPercent !== 100 ||
      !currentScene ||
      typeof currentScene.start !== 'number' ||
      !Number.isFinite(currentScene.start) ||
      typeof currentScene.end !== 'number' ||
      !Number.isFinite(currentScene.end) ||
      currentScene.end <= currentScene.start
    ) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
    }
    if (input.start < currentScene.start - epsilon || input.end > currentScene.end + epsilon) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_RANGE_INVALID', 409)
    }
    const currentPointer = await richTimelineRepository.getCurrent({ projectId })
    const currentTimeline = currentPointer
      ? await richTimelineRepository.getRevision(currentPointer)
      : null
    const startUs = Math.round(input.start * 1_000_000)
    const durationUs = Math.round((input.end - input.start) * 1_000_000)
    if (!Number.isSafeInteger(startUs) || !Number.isSafeInteger(durationUs) || durationUs <= 0) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_RANGE_INVALID', 409)
    }
    const now = timestamp()
    /** @type {ProjectReference} */
    const referenceRecord = {
      targetProjectId: projectId,
      sourceProjectId: selected.sourceProjectId,
      sourceAuthorizationId,
      assetId: input.assetId,
      sceneId: input.sceneId,
      start: input.start,
      end: input.end,
      createdAt: now,
    }
    const remembered = await rememberProjectReference(referenceRecord)
    try {
      const draft = currentTimeline
        ? appendSceneToTimeline({
          timeline: currentTimeline,
          authorizationId: sourceAuthorizationId,
          assetId: input.assetId,
          sceneId: input.sceneId,
          startUs,
          durationUs,
          now,
        })
        : minimalTimeline({
          projectId,
          authorizationId: sourceAuthorizationId,
          assetId: input.assetId,
          sceneId: input.sceneId,
          startUs,
          durationUs,
          orientation: ['portrait', 'landscape', 'square'].includes(target.brief?.orientation ?? '')
            ? /** @type {string} */ (target.brief?.orientation)
            : 'portrait',
          now,
        })
      if (!draft) {
        return {
          schema_version: schemaVersion,
          reference: { assetId: input.assetId, sceneId: input.sceneId, start: input.start, end: input.end },
          timeline: toPublicTimelineSummary(currentTimeline),
          alreadyPresent: true,
        }
      }
      draft.capabilityRequirements = computeCapabilityRequirements(draft.tracks)
      const sealed = sealRichTimeline(draft)
      const savedTimeline = await richTimelineRepository.saveDraftAndSetCurrent({
        timeline: sealed,
        expectedCurrent: currentPointer,
      })
      if (remembered.added) await touchTargetProject(projectId).catch(() => undefined)
      return {
        schema_version: schemaVersion,
        reference: { assetId: input.assetId, sceneId: input.sceneId, start: input.start, end: input.end },
        timeline: toPublicTimelineSummary(savedTimeline),
        alreadyPresent: false,
      }
    } catch (error) {
      if (remembered.added) await forgetProjectReference(referenceRecord).catch(() => undefined)
      throw error
    }
  }

  /** @param {string} projectId @param {unknown} input */
  const addReferences = async (projectId, input) => {
    if (!opaqueId(projectId) || !isRecord(input) || Object.keys(input).sort().join('\u0000') !== 'references' || !Array.isArray(input.references) || input.references.length === 0 || input.references.length > 500) {
      throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_INVALID', 400)
    }
    for (const reference of input.references) {
      if (!isRecord(reference) || Object.keys(reference).sort().join('\u0000') !== ['assetId', 'end', 'sceneId', 'start'].sort().join('\u0000') ||
        !opaqueId(reference.assetId) || !opaqueId(reference.sceneId) ||
        typeof reference.start !== 'number' || !Number.isFinite(reference.start) || reference.start < 0 ||
        typeof reference.end !== 'number' || !Number.isFinite(reference.end) || reference.end <= reference.start) {
        throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_INVALID', 400)
      }
    }
    /** @type {Array<{assetId: string, sceneId: string, start: number, end: number}>} */
    const references = input.references
    const operation = projectReferenceQueue.then(async () => {
    const target = await Promise.resolve(projectRepository.get(projectId))
    if (!target) throw new MaterialLibraryError('PROJECT_NOT_FOUND', 404)
    const failed = []
    const valid = []
    const epsilon = 0.001
    const catalog = await catalogAssets()
    for (const reference of references) {
      try {
        const selected = catalog.find((entry) => entry.id === reference.assetId)
        const selectedScene = selected?.scenes?.find((/** @type {MaterialScene} */ scene) => scene.id === reference.sceneId)
        if (!selected || selected.libraryState !== 'ready' || !selected.sourceProjectId || !selectedScene) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
        if (reference.start < selectedScene.start - epsilon || reference.end > selectedScene.end + epsilon) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_RANGE_INVALID', 409)
        const sourceProject = await Promise.resolve(projectRepository.get(selected.sourceProjectId))
        const sourceAuthorizationIdCandidate = sourceProject?.materials?.authorizationId ?? libraryImports.find((entry) => entry.id === selected.sourceProjectId)?.authorizationId
        if (!opaqueId(sourceAuthorizationIdCandidate)) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
        const sourceAuthorizationId = sourceAuthorizationIdCandidate
        const sourceRecord = opaqueId(sourceAuthorizationId) ? await Promise.resolve(authorizationRepository.get(sourceAuthorizationId)) : null
        if (!sourceRecord || sourceRecord.projectId !== selected.sourceProjectId || sourceRecord.status !== 'authorized' || sourceRecord.readOnly !== true) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
        const startUs = Math.round(reference.start * 1_000_000)
        const durationUs = Math.round((reference.end - reference.start) * 1_000_000)
        if (!Number.isSafeInteger(startUs) || !Number.isSafeInteger(durationUs) || durationUs <= 0) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_RANGE_INVALID', 409)
        valid.push({ reference, selected, selectedScene, sourceProjectId: selected.sourceProjectId, sourceAuthorizationId, startUs, durationUs })
      } catch (error) {
        failed.push({ assetId: reference.assetId, sceneId: reference.sceneId, code: error instanceof MaterialLibraryError ? error.code : 'MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE' })
      }
    }
    const currentPointer = await richTimelineRepository.getCurrent({ projectId })
    const originalTimeline = currentPointer ? await richTimelineRepository.getRevision(currentPointer) : null
    let currentTimeline = originalTimeline
    let timelineChanged = false
    const now = timestamp()
    const records = []
    const results = []
    for (const item of valid) {
      try {
        const currentAsset = item.selected
        const currentScene = item.selectedScene
        if (currentAsset.libraryState !== 'ready' || currentAsset.status !== 'ready' || currentAsset.analyzedPercent !== 100 || !currentScene || !Number.isFinite(currentScene.start) || !Number.isFinite(currentScene.end) || currentScene.end <= currentScene.start || item.reference.start < currentScene.start - epsilon || item.reference.end > currentScene.end + epsilon) throw new MaterialLibraryError('MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE', 409)
        const referencePresent = [...projectReferences, ...records].some((entry) => entry.targetProjectId === projectId && entry.assetId === item.reference.assetId && entry.sceneId === item.reference.sceneId && Math.abs(entry.start - item.reference.start) < epsilon && Math.abs(entry.end - item.reference.end) < epsilon)
        const timelinePresent = Boolean(currentTimeline?.tracks?.some((/** @type {Record<string, any>} */ track) => track.segments?.some((/** @type {Record<string, any>} */ segment) => segment.asset?.assetId === item.reference.assetId && segment.asset?.sceneId === item.reference.sceneId && segment.sourceRange?.startUs === item.startUs && segment.sourceRange?.durationUs === item.durationUs)))
        const alreadyPresent = referencePresent && timelinePresent
        if (!timelinePresent) {
          const nextTimeline = currentTimeline
            ? appendSceneToTimeline({ timeline: currentTimeline, authorizationId: item.sourceAuthorizationId, assetId: item.reference.assetId, sceneId: item.reference.sceneId, startUs: item.startUs, durationUs: item.durationUs, now })
            : minimalTimeline({ projectId, authorizationId: item.sourceAuthorizationId, assetId: item.reference.assetId, sceneId: item.reference.sceneId, startUs: item.startUs, durationUs: item.durationUs, orientation: ['portrait', 'landscape', 'square'].includes(target.brief?.orientation ?? '') ? /** @type {string} */ (target.brief?.orientation) : 'portrait', now })
          if (!nextTimeline) throw new MaterialLibraryError('MATERIAL_LIBRARY_TIMELINE_INVALID', 409)
          currentTimeline = nextTimeline
          // All appended scenes belong to one revision, not a chain of unsaved
          // intermediate revisions with missing or mismatched parent identities.
          currentTimeline.revision = originalTimeline ? originalTimeline.revision + 1 : 1
          currentTimeline.parentRevision = originalTimeline?.revision ?? null
          currentTimeline.parentRevisionFingerprint = originalTimeline?.revisionFingerprint ?? null
          timelineChanged = true
        }
        if (!referencePresent) records.push({ targetProjectId: projectId, sourceProjectId: item.sourceProjectId, sourceAuthorizationId: item.sourceAuthorizationId, assetId: item.reference.assetId, sceneId: item.reference.sceneId, start: item.reference.start, end: item.reference.end, createdAt: now })
        results.push({ reference: item.reference, alreadyPresent })
      } catch (error) {
        failed.push({ assetId: item.reference.assetId, sceneId: item.reference.sceneId, code: error instanceof MaterialLibraryError ? error.code : 'MATERIAL_LIBRARY_REFERENCE_UNAVAILABLE' })
      }
    }
    // Seal before persisting references so construction failures leave no debris.
    let savedTimeline = currentTimeline
    if (timelineChanged && currentTimeline) {
      currentTimeline.capabilityRequirements = computeCapabilityRequirements(currentTimeline.tracks)
      savedTimeline = sealRichTimeline(currentTimeline)
    }
    const previousReferences = projectReferences
    if (records.length) {
      const next = [...previousReferences, ...records]
      await persistProjectReferences(next)
      projectReferences = clone(next)
    }
    try {
      if (timelineChanged && savedTimeline) savedTimeline = await richTimelineRepository.saveDraftAndSetCurrent({ timeline: savedTimeline, expectedCurrent: currentPointer })
    } catch (error) {
      if (records.length) {
        await persistProjectReferences(previousReferences)
        projectReferences = previousReferences
      }
      throw error
    }
    if (records.length) await touchTargetProject(projectId).catch(() => undefined)
    const addedCount = results.filter((result) => !result.alreadyPresent).length
    const existingCount = results.filter((result) => result.alreadyPresent).length
    return {
      schema_version: schemaVersion,
      addedCount,
      existingCount,
      failed,
      references: results.map((result) => result.reference),
      timeline: savedTimeline ? toPublicTimelineSummary(savedTimeline) : null,
    }
    })
    projectReferenceQueue = operation.then(() => undefined, () => undefined)
    return operation
  }

  /** @param {string} projectId */
  const referencedAssetIds = (projectId) => {
    if (!opaqueId(projectId)) return []
    return [...new Set(projectReferences
      .filter((entry) => entry.targetProjectId === projectId)
      .map((entry) => entry.assetId))]
  }

  /** @param {string} projectId */
  const touchTargetProject = async (projectId) => {
    const current = await Promise.resolve(projectRepository.get(projectId))
    if (!current || !validTimestamp(current.updatedAt)) return
    const materials = current.materials && typeof current.materials === 'object' ? current.materials : {}
    const localIds = new Set(
      (Array.isArray(materials.assets) ? materials.assets : [])
        .map((/** @type {{id?: string}} */ asset) => asset?.id)
        .filter(Boolean),
    )
    let extra = 0
    for (const assetId of referencedAssetIds(projectId)) {
      if (!localIds.has(assetId)) extra += 1
    }
    const persistedTotal = typeof materials.total === 'number' && Number.isSafeInteger(materials.total)
      ? materials.total
      : 0
    const persistedAnalyzed = typeof materials.analyzed === 'number' && Number.isSafeInteger(materials.analyzed)
      ? materials.analyzed
      : 0
    const persistedExtra = typeof materials.referencedAssetCount === 'number' &&
      Number.isSafeInteger(materials.referencedAssetCount)
      ? materials.referencedAssetCount
      : 0
    const folderCount = Math.max(Math.max(0, persistedTotal - persistedExtra), localIds.size)
    const total = folderCount + extra
    const analyzed = extra === 0
      ? persistedAnalyzed
      : Math.max(persistedAnalyzed, Math.min(total, persistedAnalyzed + extra))
    const next = {
      ...clone(current),
      updatedAt: timestamp(),
      materials: {
        ...materials,
        total,
        analyzed,
        referencedAssetCount: extra,
      },
    }
    await Promise.resolve(projectRepository.saveIfCurrent(next, current))
  }

  /** @param {string} projectId */
  const listStoryboardSearchScopes = async (projectId) => collectStoryboardSearchScopes(projectId)

  const listImportAuthorizationIds = () => [...new Set(
    libraryImports.map((entry) => entry.authorizationId).filter((id) => opaqueId(id)),
  )]

  return { listAssets, getAsset, savePreferences, addReference, addReferences, importMaterials, listImportJobs, cancelImportJob, retryImportJob, dismissImportJob, resolveMediaBinding, resolveSceneBinding, getProjectReferenceState, removeProjectReferences, referencedAssetIds, listStoryboardSearchScopes, listImportAuthorizationIds }
}

export const __testing = { emptyPreferences, validPreferences }
