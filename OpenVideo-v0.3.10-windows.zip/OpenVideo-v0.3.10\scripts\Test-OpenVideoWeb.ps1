[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$pnpmCommand = Get-Command pnpm.cmd -ErrorAction SilentlyContinue
$packageRunner = if ($pnpmCommand) { $pnpmCommand.Source } else { (Get-Command corepack.cmd -ErrorAction Stop).Source }

function Invoke-Tool {
    param(
        [string]$Name,
        [string[]]$Arguments
    )

    Write-Host "==> OpenVideo web: $Name" -ForegroundColor Cyan
    if ($pnpmCommand) {
        & $packageRunner @Arguments
    } else {
        & $packageRunner pnpm @Arguments
    }
    if ($LASTEXITCODE -ne 0) {
        throw "OpenVideo web $Name failed with exit code $LASTEXITCODE"
    }
}

$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
$packagePath = Join-Path $resolvedRoot 'apps/web/package.json'
$lockfilePath = Join-Path $resolvedRoot 'pnpm-lock.yaml'

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw 'Node.js is required for OpenVideo web verification.'
}
if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) {
    throw 'OpenVideo web package.json is missing.'
}
if (-not (Test-Path -LiteralPath $lockfilePath -PathType Leaf)) {
    throw 'OpenVideo pnpm lockfile is missing.'
}

Push-Location $resolvedRoot
try {
    Invoke-Tool 'frozen install' @('install', '--frozen-lockfile')
    Invoke-Tool 'Gateway lint' @('--filter', '@openvideo/gateway', 'lint')
    Invoke-Tool 'Gateway preview lint' @('--filter', '@openvideo/gateway', 'lint:workbench-preview')
    Invoke-Tool 'Gateway template lint' @('--filter', '@openvideo/gateway', 'lint:tpl002')
    Invoke-Tool 'Gateway Jianying lint' @('--filter', '@openvideo/gateway', 'lint:jy002')
    Invoke-Tool 'web lint' @('--filter', '@openvideo/web', 'lint')
    Invoke-Tool 'Gateway typecheck' @('--filter', '@openvideo/gateway', 'typecheck')
    Invoke-Tool 'web typecheck' @('--filter', '@openvideo/web', 'typecheck')
    Invoke-Tool 'Gateway unit tests' @('--filter', '@openvideo/gateway', 'test')
    Invoke-Tool 'web unit tests' @('--filter', '@openvideo/web', 'test')
    Invoke-Tool 'Gateway build' @('--filter', '@openvideo/gateway', 'build')
    Invoke-Tool 'Gateway preview build' @('--filter', '@openvideo/gateway', 'build:workbench-preview')
    Invoke-Tool 'Gateway template build' @('--filter', '@openvideo/gateway', 'build:tpl002')
    Invoke-Tool 'Gateway Jianying build' @('--filter', '@openvideo/gateway', 'build:jy002')
    Invoke-Tool 'web production build' @('--filter', '@openvideo/web', 'build')
    $previousGatewayPort = $env:OPENVIDEO_E2E_GATEWAY_PORT
    $previousWebPort = $env:OPENVIDEO_E2E_WEB_PORT
    try {
        $env:OPENVIDEO_E2E_GATEWAY_PORT = '48788'
        $env:OPENVIDEO_E2E_WEB_PORT = '44173'
        Invoke-Tool 'browser routes' @('--filter', '@openvideo/web', 'test:e2e')
    }
    finally {
        $env:OPENVIDEO_E2E_GATEWAY_PORT = $previousGatewayPort
        $env:OPENVIDEO_E2E_WEB_PORT = $previousWebPort
    }
}
finally {
    Pop-Location
}

Write-Host 'OpenVideo web verification passed.' -ForegroundColor Green
exit 0
