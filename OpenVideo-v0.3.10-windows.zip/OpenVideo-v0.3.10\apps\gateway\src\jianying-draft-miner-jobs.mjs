// @ts-nocheck -- durable repository operates on validated JSON records; runtime validators are the type boundary.
import { copyFile, mkdir, open, readFile, rename, unlink } from 'node:fs/promises'
import { dirname } from 'node:path'
import { randomUUID } from 'node:crypto'

import {
  parseDraftMinerRequest,
  parseDraftMinerStartRequest,
  projectDraftMinerCandidate,
  projectDraftMinerJobRecord,
} from './jianying-draft-resource-contracts.mjs'

const ACTIVE_STATES = new Set(['queued', 'running'])
const TERMINAL_STATES = new Set(['succeeded', 'failed', 'cancelled'])
const clone = (value) => JSON.parse(JSON.stringify(value))
const fail = (code) => { const error = new Error(code); error.code = code; throw error }
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
const opaque = (prefix) => `${prefix}_${randomUUID().replaceAll('-', '')}`

/** @param {unknown} value */
const assertRecord = (value) => {
  try {
    projectDraftMinerJobRecord(value)
  } catch {
    fail('NATIVE004_STORAGE_CORRUPT')
  }
  return /** @type {Record<string, any>} */ (value)
}

/** @param {string} filePath */
const readDocument = async (filePath) => {
  const parsed = JSON.parse(await readFile(filePath, 'utf8'))
  if (!isRecord(parsed) || parsed.schema_version !== 1 || !Array.isArray(parsed.records)) fail('NATIVE004_STORAGE_CORRUPT')
  parsed.records.forEach(assertRecord)
  return /** @type {{schema_version: 1, records: Record<string, any>[]}} */ (parsed)
}

/** @param {string} filePath @param {{schema_version: 1, records: Record<string, any>[]}} document */
const writeDocument = async (filePath, document) => {
  const temporaryPath = `${filePath}.${randomUUID()}.tmp`
  await mkdir(dirname(filePath), { recursive: true })
  const handle = await open(temporaryPath, 'wx', 0o600)
  try {
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  try {
    await copyFile(filePath, `${filePath}.bak`)
  } catch (error) {
    if (error?.code !== 'ENOENT') {
      await unlink(temporaryPath).catch(() => {})
      throw error
    }
  }
  await rename(temporaryPath, filePath)
}

/** @param {string} filePath */
const loadDocument = async (filePath) => {
  try {
    return await readDocument(filePath)
  } catch (primaryError) {
    try {
      const backup = await readDocument(`${filePath}.bak`)
      const temporaryPath = `${filePath}.${randomUUID()}.restore.tmp`
      await open(temporaryPath, 'wx', 0o600).then(async (handle) => {
        try { await handle.writeFile(`${JSON.stringify(backup, null, 2)}\n`, 'utf8'); await handle.sync() } finally { await handle.close() }
      })
      await rename(temporaryPath, filePath)
      return backup
    } catch (backupError) {
      if (primaryError?.code === 'ENOENT' && backupError?.code === 'ENOENT') {
        const empty = { schema_version: 1, records: [] }
        await writeDocument(filePath, empty)
        return empty
      }
      fail('NATIVE004_STORAGE_CORRUPT')
    }
  }
}

/** @param {Record<string, any>} record */
const toPublicJob = (record) => {
  const projected = projectDraftMinerJobRecord(record)
  return Object.freeze({
    ...projected,
    candidates: projected.status === 'succeeded'
      ? Object.freeze(projected.candidates.map((candidate) => Object.freeze({ ...candidate })))
      : Object.freeze([]),
  })
}

/**
 * A repository-external, atomic JSON store for discovery jobs. It is deliberately
 * independent from writer repositories so a restart can never promote a mined
 * candidate to writer eligibility.
 * @param {{filePath: string, now?: () => number}} options
 */
export const createDraftMinerJobRepository = async ({ filePath, now = Date.now }) => {
  if (typeof filePath !== 'string' || filePath.length === 0) fail('NATIVE004_STORAGE_PATH_INVALID')
  const lockPath = `${filePath}.lock`
  const acquireStartupLock = async () => {
    for (let attempt = 0; attempt < 500; attempt += 1) {
      try {
        const handle = await open(lockPath, 'wx', 0o600)
        await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: Date.now() }), 'utf8')
        await handle.close()
        return
      } catch (error) {
        if (error?.code !== 'EEXIST') throw error
        try {
          const ownerText = await readFile(lockPath, 'utf8')
          const owner = JSON.parse(ownerText)
          let alive = true
          try { process.kill(Number(owner.pid), 0) } catch (probeError) { alive = probeError?.code !== 'ESRCH' }
          if (!alive || Date.now() - Number(owner.createdAt) > 300_000) {
            if (await readFile(lockPath, 'utf8') === ownerText) await unlink(lockPath)
          }
        } catch { /* owner metadata may still be completing; never unlink an unparsed lock */ }
        await new Promise((resolve) => setTimeout(resolve, 5))
      }
    }
    fail('NATIVE004_STORAGE_LOCKED')
  }
  await acquireStartupLock()
  let document
  let chain = Promise.resolve()
  const acquireFileLock = async () => {
    for (let attempt = 0; attempt < 500; attempt += 1) {
      try {
        const handle = await open(lockPath, 'wx', 0o600)
        await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: Date.now() }), 'utf8')
        await handle.close()
        return
      } catch (error) {
        if (error?.code !== 'EEXIST') throw error
        try {
          const ownerText = await readFile(lockPath, 'utf8')
          const owner = JSON.parse(ownerText)
          const age = Date.now() - Number(owner.createdAt)
          let alive = true
          try { process.kill(Number(owner.pid), 0) } catch (probeError) { alive = probeError?.code !== 'ESRCH' }
          if (!alive || (Number.isFinite(age) && age > 300_000)) {
            if (await readFile(lockPath, 'utf8') === ownerText) await unlink(lockPath)
          }
        } catch { /* owner metadata may still be completing; never unlink an unparsed lock */ }
        await new Promise((resolve) => setTimeout(resolve, 5))
      }
    }
    fail('NATIVE004_STORAGE_LOCKED')
  }
  const releaseFileLock = async () => { await unlink(lockPath).catch(() => {}) }
  const withLock = (operation) => {
    const next = chain.then(async () => {
      await acquireFileLock()
      try {
        document = await readDocument(filePath)
        return await operation()
      } finally {
        await releaseFileLock()
      }
    }, async () => {
      await acquireFileLock()
      try {
        document = await readDocument(filePath)
        return await operation()
      } finally {
        await releaseFileLock()
      }
    })
    chain = next.catch(() => {})
    return next
  }

  const persist = async () => writeDocument(filePath, document)
  const recover = async () => {
    let changed = false
    document.records = document.records.map((record) => {
      assertRecord(record)
      if (!ACTIVE_STATES.has(record.status)) return record
      changed = true
      return {
        ...record,
        status: 'failed',
        progress: Math.min(99, record.progress),
        errorCode: 'NATIVE004_RESTART_RECOVERY',
        cancelRequested: false,
        updatedAt: now(),
      }
    })
    if (changed) await persist()
  }
  try {
    document = await loadDocument(filePath)
    await recover()
  } finally {
    await releaseFileLock()
  }

  return Object.freeze({
    async get(jobId) {
      return withLock(async () => {
        const record = document.records.find((entry) => entry.id === jobId)
        return record ? clone(record) : null
      })
    },
    async list() {
      return withLock(async () => clone(document.records))
    },
    async findByIdempotency(authorizationId, idempotencyKey) {
      return withLock(async () => {
        const record = document.records.find((entry) => entry.authorizationId === authorizationId && entry.idempotencyKey === idempotencyKey)
        return record ? clone(record) : null
      })
    },
    async create(record) {
      return withLock(async () => {
        assertRecord(record)
        if (document.records.some((entry) => entry.id === record.id)) fail('NATIVE004_JOB_EXISTS')
        document.records.push(clone(record))
        await persist()
        return clone(record)
      })
    },
    async createIfAbsent(record, authorizationId, idempotencyKey) {
      return withLock(async () => {
        assertRecord(record)
        const existing = document.records.find((entry) => entry.authorizationId === authorizationId && entry.idempotencyKey === idempotencyKey)
        if (existing) return { created: false, record: clone(existing) }
        document.records.push(clone(record))
        await persist()
        return { created: true, record: clone(record) }
      })
    },
    async save(record) {
      return withLock(async () => {
        assertRecord(record)
        const index = document.records.findIndex((entry) => entry.id === record.id)
        if (index < 0) fail('NATIVE004_JOB_NOT_FOUND')
        document.records[index] = clone(record)
        await persist()
        return clone(record)
      })
    },
    /** @param {string} jobId @param {(record: Record<string, any>) => Record<string, any>} updater */
    async update(jobId, updater) {
      return withLock(async () => {
        const index = document.records.findIndex((entry) => entry.id === jobId)
        if (index < 0) return null
        const current = clone(document.records[index])
        const next = updater(current)
        assertRecord(next)
        document.records[index] = clone(next)
        await persist()
        return clone(next)
      })
    },
  })
}

/** @param {Record<string, any>} record */
const publicStatus = (record) => {
  const status = toPublicJob(record)
  return Object.freeze({ ...status, retryable: status.status === 'failed' || status.status === 'cancelled' })
}

/**
 * Server-owned job lifecycle around the NATIVE-003 miner. The only input that
 * reaches the miner is a server-minted request envelope; callers never provide
 * a path, draft ID, desktop identity or writer capability.
 * @param {{repository: Awaited<ReturnType<typeof createDraftMinerJobRepository>>, miner: {mine: (request: unknown) => Promise<{status: string, candidateCount: number, candidates: unknown[]}>}, now?: () => number, authorize?: (record: Record<string, any>) => Promise<boolean> | boolean}} options
 */
export const createDraftMinerJobService = ({ repository, miner, now = Date.now, authorize = async () => false }) => {
  if (!repository || typeof repository.get !== 'function' || !miner || typeof miner.mine !== 'function') fail('NATIVE004_DEPENDENCIES_INVALID')
  const run = async (record) => {
    const running = await repository.update(record.id, (current) => current.status === 'queued'
      ? { ...current, status: 'running', progress: 5, updatedAt: now() }
      : current)
    if (!running || running.status !== 'running') return
    try {
      const request = parseDraftMinerRequest({
        request_id: running.requestId,
        draft_authorization_id: running.authorizationId,
        ...(running.catalogRevision ? { catalog_revision: running.catalogRevision } : {}),
        mode: 'discover',
      })
      const result = await miner.mine(request)
      const candidates = result?.candidates?.map((candidate) => projectDraftMinerCandidate({
        packaging_token: candidate.packagingToken ?? candidate.packaging_token,
        family: candidate.family,
        label: candidate.label,
        tags: candidate.tags,
        state: candidate.state,
        writer_eligible: candidate.writerEligible ?? candidate.writer_eligible,
      }))
      if (result?.status !== 'succeeded' || !Array.isArray(candidates)) fail('NATIVE004_RESULT_INVALID')
      await repository.update(record.id, (current) => {
        if (current.cancelRequested) {
          return { ...current, status: 'cancelled', progress: Math.min(99, current.progress), errorCode: 'NATIVE004_CANCELLED', updatedAt: now() }
        }
        return {
          ...current,
          status: 'succeeded',
          progress: 100,
          errorCode: null,
          candidateCount: candidates.length,
          candidates: candidates.map((candidate) => ({
            packagingToken: candidate.packagingToken,
            family: candidate.family,
            label: candidate.label,
            tags: [...candidate.tags],
            state: candidate.state,
            writerEligible: false,
          })),
          updatedAt: now(),
        }
      })
    } catch (error) {
      const candidate = /** @type {{code?: unknown}} */ (error)
      const errorCode = typeof candidate?.code === 'string' && /^NATIVE00[1234]_[A-Z0-9_]{3,80}$/u.test(candidate.code)
        ? candidate.code
        : 'NATIVE004_MINER_FAILED'
      await repository.update(record.id, (current) => current.cancelRequested
        ? { ...current, status: 'cancelled', errorCode: 'NATIVE004_CANCELLED', updatedAt: now() }
        : { ...current, status: 'failed', progress: 100, errorCode, updatedAt: now() })
    }
  }

  const status = async (jobId) => {
    const record = await repository.get(jobId)
    if (!record || !(await authorize(record))) return null
    return publicStatus(record)
  }
  const start = async (input) => {
    const request = parseDraftMinerStartRequest(input)
    if (!(await authorize({ authorizationId: request.draft_authorization_id }))) fail('NATIVE004_AUTHORIZATION_INVALID')
    const timestamp = now()
    const record = {
      id: opaque('ovjob'),
      requestId: opaque('ovreq'),
      authorizationId: request.draft_authorization_id,
      idempotencyKey: request.idempotency_key,
      ...(request.catalog_revision ? { catalogRevision: request.catalog_revision } : {}),
      status: 'queued', progress: 0, errorCode: null, candidateCount: 0, candidates: [],
      attempt: 0, cancelRequested: false, createdAt: timestamp, updatedAt: timestamp,
    }
    const result = repository.createIfAbsent
      ? await repository.createIfAbsent(record, request.draft_authorization_id, request.idempotency_key)
      : { created: true, record: await repository.create(record) }
    if (result.created) void run(result.record).catch(() => {})
    return Object.freeze({ status: result.created ? 202 : 200, created: result.created, job: publicStatus(result.record) })
  }
  const cancel = async (jobId) => {
    const record = await repository.get(jobId)
    if (!record || !(await authorize(record))) return null
    const next = await repository.update(jobId, (current) => {
      if (TERMINAL_STATES.has(current.status)) return current
      if (current.status === 'queued') return { ...current, status: 'cancelled', progress: 0, errorCode: 'NATIVE004_CANCELLED', cancelRequested: false, updatedAt: now() }
      return { ...current, cancelRequested: true, updatedAt: now() }
    })
    return next ? publicStatus(next) : null
  }
  const retry = async (jobId) => {
    const record = await repository.get(jobId)
    if (!record || !(await authorize(record))) return null
    if (record.status === 'queued' || record.status === 'running') return publicStatus(record)
    if (!TERMINAL_STATES.has(record.status) || record.status === 'succeeded') return publicStatus(record)
    const nextRequestId = opaque('ovreq')
    const next = await repository.update(jobId, (current) => {
      if (current.status !== 'failed' && current.status !== 'cancelled') return current
      return {
        ...current, requestId: nextRequestId, status: 'queued', progress: 0, errorCode: null,
        candidates: [], candidateCount: 0, attempt: current.attempt + 1, cancelRequested: false, updatedAt: now(),
      }
    })
    if (next?.requestId === nextRequestId) void run(next).catch(() => {})
    return next ? publicStatus(next) : null
  }
  return Object.freeze({ start, status, cancel, retry })
}
