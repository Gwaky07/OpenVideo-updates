import {
  computePackagingCatalogRevisionToken,
  computePackagingResourceToken,
  isPackagingWriterReadyEntry,
  isPackagingResourceTokenForFamily,
  isOpaquePackagingToken,
  projectPackagingResourceCandidates,
} from './jianying-packaging-resource-index.mjs'

const MAX_REFRESH_TOTAL = 24
const MAX_REFRESH_PER_FAMILY = 4

/** @typedef {{maxPerFamily?: number, maxTotal?: number}} RefreshOptions */
/** @typedef {{packagingToken: string, family: string, label: string, tags: string[], state: string, outcome: string}} RefreshCandidate */
/** @typedef {{family: string, total: number, ready: number, discoveryOnly: number, candidates: RefreshCandidate[], selected: string[]}} RefreshGroup */

/**
 * Build a safe, family-scoped refresh view for one Jianying profile/version.
 * The private catalog remains server-side; only opaque tokens and sanitized
 * candidate labels cross this boundary.
 * @param {any} index
 * @param {RefreshOptions} [options]
 * @returns {Record<string, any>}
 */
export const buildFamilyVersionBatchRefreshPlan = (index, options = {}) => {
  if (!index || typeof index !== 'object' || Array.isArray(index) ||
      index.schemaVersion !== 1 || !Array.isArray(index.entries) ||
      index.entries.length > 20000 ||
      typeof index.profileId !== 'string' || !/^jianying-[a-z0-9-]{1,60}$/u.test(index.profileId) ||
      typeof index.appVersion !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(index.appVersion) ||
      typeof index.catalogFingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(index.catalogFingerprint) ||
      typeof index.catalogRevisionToken !== 'string' ||
      computePackagingCatalogRevisionToken(index.catalogFingerprint) !== index.catalogRevisionToken) {
    throw new Error('JY179_REFRESH_INDEX_INVALID')
  }
  const tokens = new Set()
  for (const entry of /** @type {Array<Record<string, any>>} */ (index.entries)) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry) ||
        typeof entry.packaging_token !== 'string' || !isOpaquePackagingToken(entry.packaging_token) ||
        typeof entry.family !== 'string' || !isPackagingResourceTokenForFamily(entry.family, entry.packaging_token) ||
        tokens.has(entry.packaging_token) ||
        !['discoverable', 'blocked', 'writer_eligible'].includes(entry.state) ||
        typeof entry.writer_eligible !== 'boolean') {
      throw new Error('JY179_REFRESH_INDEX_INVALID')
    }
    try {
      if (computePackagingResourceToken({
        family: entry.family,
        profileId: index.profileId,
        appVersion: index.appVersion,
        privateBinding: entry.private_binding,
      }) !== entry.packaging_token) throw new Error('stale')
    } catch {
      throw new Error('JY179_REFRESH_INDEX_INVALID')
    }
    tokens.add(entry.packaging_token)
  }
  const requestedPerFamily = /** @type {number | undefined} */ (options.maxPerFamily)
  const requestedTotal = /** @type {number | undefined} */ (options.maxTotal)
  const maxPerFamily = typeof requestedPerFamily === 'number' && Number.isSafeInteger(requestedPerFamily)
    ? Math.max(1, Math.min(MAX_REFRESH_PER_FAMILY, requestedPerFamily))
    : MAX_REFRESH_PER_FAMILY
  const maxTotal = typeof requestedTotal === 'number' && Number.isSafeInteger(requestedTotal)
    ? Math.max(1, Math.min(MAX_REFRESH_TOTAL, requestedTotal))
    : MAX_REFRESH_TOTAL
  const candidates = /** @type {RefreshCandidate[]} */ (projectPackagingResourceCandidates(index))
  const admittedTokens = new Set(/** @type {Array<Record<string, any>>} */ (index.entries)
    .filter((/** @type {Record<string, any>} */ entry) => isPackagingWriterReadyEntry(entry))
    .map((/** @type {Record<string, any>} */ entry) => entry.packaging_token))
  const groups = /** @type {Map<string, RefreshGroup>} */ (new Map())
  for (const candidate of candidates) {
    const group = groups.get(candidate.family) ?? /** @type {RefreshGroup} */ ({
      family: candidate.family,
      total: 0,
      ready: 0,
      discoveryOnly: 0,
      candidates: [],
      selected: [],
    })
    const ready = admittedTokens.has(candidate.packagingToken)
    group.total += 1
    if (ready) group.ready += 1
    else group.discoveryOnly += 1
    group.candidates.push(Object.freeze({
      packagingToken: candidate.packagingToken,
      family: candidate.family,
      label: candidate.label,
      tags: candidate.tags,
      state: candidate.state,
      outcome: ready ? 'JY179_RESOURCE_READY' : 'JY179_RESOURCE_DISCOVERY_ONLY',
    }))
    groups.set(candidate.family, group)
  }

  let selectedTotal = 0
  const normalizedGroups = [...groups.values()]
    .sort((left, right) => left.family.localeCompare(right.family))
    .map((group) => {
      const selected = group.candidates
        .filter((/** @type {RefreshCandidate} */ candidate) => candidate.outcome === 'JY179_RESOURCE_READY')
        .slice(0, Math.min(maxPerFamily, maxTotal - selectedTotal))
      selectedTotal += selected.length
      return Object.freeze({
        family: group.family,
        total: group.total,
        ready: group.ready,
        discoveryOnly: group.discoveryOnly,
        candidates: Object.freeze(/** @type {RefreshCandidate[]} */ (group.candidates)),
        selected: Object.freeze(selected.map((/** @type {RefreshCandidate} */ candidate) => candidate.packagingToken)),
      })
    })

  return Object.freeze({
    schema_version: 1,
    profile_id: index.profileId,
    app_version: index.appVersion,
    catalog_revision_token: index.catalogRevisionToken,
    max_per_family: maxPerFamily,
    max_total: maxTotal,
    selected_total: selectedTotal,
    groups: Object.freeze(normalizedGroups),
  })
}
