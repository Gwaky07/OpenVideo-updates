import { createHash, randomUUID } from 'node:crypto'

import {
  projectAnalyzedMaterialsForPublic,
  validAnalyzedMaterials,
  validSearchCandidate,
  validStoryboardMaterialIndex,
} from './material-analysis-contracts.mjs'
import { deriveMaterialContentTags } from './permissive-material-analyzer.mjs'
import { isEditPlan } from './director-contracts.mjs'
import { assignUniqueSceneCandidates } from './director-candidate-assignment.mjs'
import { validShortVideoFactoryResult } from './short-video-factory-contracts.mjs'
import { isTemplateSelectionRequest } from './template-library.mjs'
import {
  adaptTemplateGuidanceToCount,
  applyTemplateGuidanceToSelections,
  assertTemplateGuidanceExecutable,
  createTemplateGuidance,
} from './template-binding-consumption.mjs'
import {
  EditPlanTimelineAdapterError,
  adaptEditPlanToTimeline,
  realizeCreativeTechniqueDecisions,
} from './edit-plan-timeline-adapter.mjs'
import { assignTemplateSfxPoolByLlm } from './template-sfx-intent.mjs'
import {
  RichTimelineContractError,
  sealRichTimeline,
  secondsToMicroseconds,
  toPublicTimelineSummary,
  resolvePackagingFeedbackHandle,
} from './rich-timeline-contracts.mjs'
import { RichTimelineRepositoryError } from './rich-timeline-repository.mjs'
import { applyRichTimelinePatch } from './rich-timeline-patch.mjs'
import {
  TimelineTemplateConstraintsError,
  applyPackagingPlanToTimelineTemplateConstraints,
  createTimelineTemplateConstraints,
  usesUploadedDraftInventory,
} from './timeline-template-constraints.mjs'
import { projectRichTimelineToPreviewExport } from './rich-timeline-preview-projection.mjs'
import { assertJobRecord, toPublicJobDto } from './workbench-job-contracts.mjs'
import {
  EDITOR_BUDGETS,
  EDITOR_JOB_TYPE,
  EDITOR_TOOL_NAMES,
  EditorAgentContractError,
  assertEditorInstruction,
  createFrozenEditorJobInput,
  fingerprintCanonical,
  toEditorAgentCheckpointData,
  toEditorResumeCommittedExecutions,
} from './editor-agent-contracts.mjs'
import { createEditorAgent } from './editor-agent.mjs'
import { createEditorCapabilityRegistry } from './editor-capability-registry.mjs'
import {
  allowedCreativeCapabilityIds,
  createCreativeMaterialQuery,
  isCreativePlanningContext,
} from './creative-realization-policy.mjs'
import { createEditorMaterialTools } from './editor-material-tools.mjs'
import { isCreativeAudioCueDecision } from './creative-technique-policy.mjs'
import { resolvePackagingForExecution, resolvePackagingIntentFromEditorInstruction } from './brief-packaging.mjs'
import {
  buildAssignmentScenes,
  completeTemplatePackagingAssignments,
  createTemplateOverlayInventory,
  createTemplateStyleInventory,
  resolveAssignmentHighlights,
} from './template-style-inventory-assign.mjs'
import { createPackagingRecommendationProvider } from './jianying-packaging-recommendation-provider.mjs'
import { createLlmGatewayPackagingRanker } from './jianying-packaging-recommender.mjs'
import {
  EditorToolRegistryError,
  createDefaultEditorToolHandlers,
  createEditorToolRegistry,
} from './editor-tool-registry.mjs'
import {
  MATERIAL_ANALYSIS_PRIORITY_JOB_TYPES,
  createMaterialAnalysisRunGovernor,
} from './material-analysis-run-governor.mjs'

const supportedTypes = new Set(['material_analysis', 'storyboard_generation', 'preview_generation'])
const terminalStatuses = new Set(['succeeded', 'failed', 'cancelled', 'timed_out'])
const preservedEditorProductCapabilities = new Set([
  'caption.basic',
  'audio.voiceover.edge_tts',
  'audio.bgm.local',
  'audio.sfx.local',
  'sticker.named',
  'text.flower.private',
  'effect.video.named',
])
const requiredJobRepositoryMethods = [
  'createOrGet',
  'createOrGetExclusiveByType',
  'createOrGetFenced',
  'get',
  'assertExecutionFence',
  'withExecutionFence',
  'listByProject',
  'listRecoverable',
  'claim',
  'renewLease',
  'saveCheckpoint',
  'releaseForShutdown',
  'requestCancel',
  'finish',
  'retry',
  'failRetryPreparation',
]
const requiredEditPlanRepositoryMethods = ['draft', 'candidates', 'finalize', 'get', 'getFinalized']

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {number} start @param {number} span @param {number} completed @param {number} total */
const storyboardSpanProgress = (start, span, completed, total) =>
  start + Math.floor((total <= 0 ? 1 : completed / total) * span)

/**
 * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
 * @param {{stage: string, from: number, to: number, detail: string, intervalMs: number}} input
 */
const startStoryboardProgressHeartbeat = (checkpoint, { stage, from, to, detail, intervalMs }) => {
  let current = from
  let stopped = false
  let chain = Promise.resolve()
  const timer = setInterval(() => {
    chain = chain.then(async () => {
      if (stopped || current >= to) return
      current += 1
      try {
        await checkpoint(stage, current, { detail })
      } catch {
        stopped = true
      }
    })
  }, Math.max(400, Math.floor(intervalMs)))
  timer.unref?.()
  return async () => {
    stopped = true
    clearInterval(timer)
    await chain
  }
}
/** @param {Record<string, any> | null} constraints @param {Record<string, any> | null} index */
const hasCurrentCatalogTemplateBinding = (constraints, index) =>
  [...(constraints?.richTextSegments ?? []), ...(constraints?.packagingSegments ?? [])]
    .some((segment) => typeof segment.packagingToken === 'string' &&
      /^ovj(?:flower|sticker|video_effect)_v1_[a-z0-9_-]{1,96}$/u.test(segment.packagingToken) &&
      (index?.entries ?? []).some((/** @type {Record<string, any>} */ entry) =>
        entry.packaging_token === segment.packagingToken))
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const errorCode = (value) => {
  if (!value || typeof value !== 'object') return null
  if ('code' in value && typeof value.code === 'string') return value.code
  const message = value instanceof Error ? value.message : null
  return typeof message === 'string' && /^[A-Z][A-Z0-9_]{2,127}$/u.test(message)
    ? message
    : null
}

/**
 * A template can legitimately satisfy the complete packaging request before
 * the catalog provider is asked for a supplemental recommendation. Keep this
 * narrow: an empty recommendation is only a no-op when the current draft is
 * template-bound and already contains authored packaging segments.
 * @param {Record<string, any> | null | undefined} timeline
 */
export const hasExecutableTemplatePackaging = (timeline) => {
  if (!isRecord(timeline) || !isRecord(timeline.source?.templateIdentity) || !Array.isArray(timeline.tracks)) return false
  return timeline.tracks.some((track) =>
    Array.isArray(track?.segments) && track.segments.some((/** @type {Record<string, any>} */ segment) => [
      'text.flower.private',
      'text.bubble.private',
      'text.rich',
      'sticker.named',
      'effect.video.named',
    ].includes(segment?.capabilityId)),
  )
}
/** @param {unknown} value */
const finitePositiveSeconds = (value) =>
  typeof value === 'number' && Number.isFinite(value) && value > 0 ? value : null

/**
 * Unused media on one asset, starting at or after the analysis window.
 * Reserved ranges are half-open [start, end) in seconds and come only from
 * earlier selected narration on the same file.
 * @param {number} sceneStart
 * @param {number} sceneEnd
 * @param {number | null} assetDurationSeconds
 * @param {Array<{start: number, end: number}>} reservedRanges
 */
const unusedMediaWindow = (sceneStart, sceneEnd, assetDurationSeconds, reservedRanges) => {
  if (!Number.isFinite(sceneStart) || !Number.isFinite(sceneEnd) || sceneEnd <= sceneStart) {
    return null
  }
  const hardEnd = finitePositiveSeconds(assetDurationSeconds) ?? sceneEnd
  let start = sceneStart
  let end = hardEnd
  const reserved = [...reservedRanges]
    .filter((range) => Number.isFinite(range.start) && Number.isFinite(range.end) && range.end > range.start)
    .sort((left, right) => left.start - right.start || left.end - right.end)
  for (const range of reserved) {
    if (start + 1e-6 >= range.end) continue
    if (start < range.end && start + 1e-6 > range.start) {
      start = range.end
      continue
    }
    end = Math.min(end, range.start)
    break
  }
  if (!(end > start + 1e-6)) return null
  return { start, end }
}

/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= 200 &&
  !value.includes('\u0000')
/** @param {unknown} value */
const opaqueIdentifier = (value) =>
  identifier(value) &&
  /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u.test(/** @type {string} */ (value))
/** @param {unknown} value */
const draftIdentifier = (value) =>
  opaqueIdentifier(value) || (
    typeof value === 'string' &&
    value === value.trim() &&
    value.length > 0 &&
    value.length <= 100 &&
    !/[\\/\u0000-\u001f]/u.test(value) &&
    !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value)
  )
/** @param {unknown} value @param {number} maximum */
const publicText = (value, maximum) =>
  typeof value === 'string' &&
  value.length > 0 &&
  value.length <= maximum &&
  !/(?:[A-Za-z]:[\\/]|\\\\|file:|%2f|%5c|%3a)/iu.test(value)
/** @param {unknown} value */
const timestamp = (value) => {
  const date = value instanceof Date ? value : new Date(/** @type {any} */ (value))
  return Number.isFinite(date.getTime()) ? date.toISOString() : new Date().toISOString()
}
/** @param {unknown} value @returns {any} */
const canonicalize = (value) => {
  if (Array.isArray(value)) return value.map(canonicalize)
  if (!isRecord(value)) return value
  return Object.fromEntries(
    Object.keys(value).sort().map((key) => [key, canonicalize(value[key])]),
  )
}
/** @param {unknown} value */
const fingerprint = (value) =>
  createHash('sha256').update(JSON.stringify(canonicalize(value))).digest('hex')

/**
 * Resolve token-free Creative sound intent against the private catalog after
 * visual timing is final. The returned records are the adapter's only accepted
 * SFX shape; catalog failures degrade per cue and never alter visual timing.
 * @param {{
 *   projectId: string,
 *   timeline: Record<string, any>,
 *   editPlan: Record<string, any>,
 *   decisions: readonly Record<string, any>[],
 *   resolveCue: Function,
 *   signal?: AbortSignal,
 * }} input
 */
export const resolveCreativeAudioCuePlacements = async (input) => {
  const selected = (input.editPlan?.items ?? [])
    .filter((/** @type {Record<string, any>} */ item) => item?.status === 'selected')
    .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) => Number(left.order) - Number(right.order))
  const primary = input.timeline?.tracks?.find((/** @type {Record<string, any>} */ track) => track?.kind === 'video' && track?.role === 'primary')
  if (!opaqueIdentifier(input.projectId) || !Array.isArray(input.decisions) ||
      !input.decisions.every(isCreativeAudioCueDecision) || typeof input.resolveCue !== 'function' ||
      !Array.isArray(primary?.segments) || primary.segments.length !== selected.length) {
    throw coordinatorError('CREATIVE_AUDIO_CUE_REALIZATION_INVALID', 500)
  }
  const ranges = new Map(selected.map((/** @type {Record<string, any>} */ item, /** @type {number} */ index) =>
    [item.sentence_id, primary.segments[index]?.targetRange]))
  const placements = []
  const degradations = []
  for (const decision of input.decisions) {
    input.signal?.throwIfAborted()
    const range = ranges.get(decision.beat_id)
    if (!isRecord(range) || !Number.isSafeInteger(range.startUs) ||
        !Number.isSafeInteger(range.durationUs) || range.durationUs <= 0) {
      degradations.push({ beatId: decision.beat_id, reason: 'sound_target_unavailable' })
      continue
    }
    let resolved
    try {
      resolved = await input.resolveCue({
        projectId: input.projectId,
        semanticFamily: decision.semantic_family,
        importance: decision.importance,
        desiredDurationUs: Math.min(decision.desired_duration_us, range.durationUs),
        tags: decision.tags,
      })
    } catch {
      input.signal?.throwIfAborted()
      resolved = null
    }
    if (!isRecord(resolved) || !opaqueIdentifier(resolved.audioToken) ||
        resolved.semanticFamily !== decision.semantic_family ||
        !Number.isSafeInteger(resolved.durationUs) || resolved.durationUs <= 0 ||
        !Number.isFinite(resolved.volume) || resolved.volume < 0 || resolved.volume > 1 ||
        typeof resolved.catalogFingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(resolved.catalogFingerprint)) {
      degradations.push({ beatId: decision.beat_id, reason: 'sound_unavailable' })
      continue
    }
    const durationUs = Math.min(resolved.durationUs, decision.desired_duration_us, range.durationUs)
    const shotEndUs = range.startUs + range.durationUs
    const anchorUs = decision.anchor === 'shot_start'
      ? range.startUs
      : decision.anchor === 'action'
        ? range.startUs + Math.round(range.durationUs * 0.45)
        : decision.anchor === 'settle'
          ? range.startUs + Math.round(range.durationUs * 0.75)
          : shotEndUs - durationUs
    placements.push(Object.freeze({
      audioToken: resolved.audioToken,
      volume: resolved.volume,
      startUs: Math.max(range.startUs, Math.min(anchorUs, shotEndUs - durationUs)),
      durationUs,
    }))
  }
  return Object.freeze({
    placements: Object.freeze(placements),
    degradations: Object.freeze(degradations),
  })
}
const writerDegradationCapabilities = new Set(['text.flower.private', 'text.bubble.private'])
/** @param {unknown} value */
const normalizeWriterDegradations = (value) => {
  if (value === undefined) return []
  if (!Array.isArray(value) || value.length > 100) {
    throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
  }
  return value.map((entry) => {
    if (
      !isRecord(entry) ||
      Object.keys(entry).sort().join('|') !== 'from|reason|segmentId|to' ||
      !opaqueIdentifier(entry.segmentId) ||
      !writerDegradationCapabilities.has(entry.from) ||
      entry.to !== 'text.rich' ||
      entry.reason !== 'PRIVATE_TEXT_CAPABILITY_UNAVAILABLE'
    ) throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return {
      segmentId: entry.segmentId,
      from: entry.from,
      to: entry.to,
      reason: entry.reason,
    }
  })
}
/** @param {unknown} value @param {string[]} methods */
const hasMethods = (value, methods) =>
  isRecord(value) && methods.every((method) => typeof value[method] === 'function')
/** @param {unknown} value */
const safeBrief = (value) =>
  isRecord(value) &&
  typeof value.script === 'string' &&
  value.script.trim().length > 0 &&
  value.script.length <= 8000 &&
  typeof value.savedAt === 'string'

const materialSearchQueryLimit = 1_000
const materialSearchCandidateLimit = 10
const creativeAutomaticEditorInstruction =
  '\u6839\u636e\u5df2\u786e\u8ba4\u5206\u955c\u81ea\u52a8\u5339\u914d\u7d20\u6750\u3001\u7cbe\u786e\u88c1\u526a\u5e76\u751f\u6210\u65f6\u95f4\u7ebf\u3002'

/** @param {string} script */
const segmentationRecallQueries = (script) => {
  const queries = []
  let offset = 0
  while (offset < script.length) {
    let end = Math.min(offset + materialSearchQueryLimit, script.length)
    if (end < script.length) {
      const window = script.slice(offset, end)
      const boundary = Math.max(
        window.lastIndexOf('\n'),
        window.lastIndexOf('。'),
        window.lastIndexOf('！'),
        window.lastIndexOf('？'),
        window.lastIndexOf('.'),
        window.lastIndexOf('!'),
        window.lastIndexOf('?'),
        window.lastIndexOf('；'),
        window.lastIndexOf(';'),
        window.lastIndexOf('，'),
        window.lastIndexOf(','),
        window.lastIndexOf(' '),
      )
      if (boundary >= Math.floor(materialSearchQueryLimit / 2)) end = offset + boundary + 1
    }
    const query = script.slice(offset, end).trim()
    if (query.length > 0) queries.push(query)
    offset = end
  }
  return queries
}
/** @param {unknown} value */
const hasLibraryMaterialReferences = (value) =>
  isRecord(value) &&
  Number.isSafeInteger(value.referencedAssetCount) &&
  value.referencedAssetCount > 0

/** @param {unknown} value */
const optionalAuthorizationInput = (value) => identifier(value) ? { authorizationId: value } : {}

/** @param {unknown} value */
const validProjectSnapshot = (value) =>
  isRecord(value) &&
  identifier(value.id) &&
  isRecord(value.materials) &&
  (
    (
      value.materials.authorized === true &&
      value.materials.readOnlyConfirmed === true &&
      identifier(value.materials.authorizationId)
    ) ||
    hasLibraryMaterialReferences(value.materials)
  )

/**
 * Storyboard generation consumes a completed material index; it must never
 * take ownership of material analysis or publish transient analyzer states.
 * @param {Record<string, any> | null | undefined} project
 */
const hasCompleteMaterialIndex = (project) => {
  const materials = project?.materials
  if (!isRecord(materials)) return false
  if (hasLibraryMaterialReferences(materials)) return true
  return identifier(materials.authorizationId) &&
    validStoryboardMaterialIndex(materials, materials.authorizationId)
}

/**
 * `needsReview` is a creator-facing quality signal, not an analyzer-version
 * signal. Only the explicit legacy sentinel (or zero confidence) requires a
 * rescan before precise editing.
 * @param {Record<string, any> | null | undefined} scene
 */
const requiresMaterialReanalysis = (scene) =>
  isRecord(scene) && (
    scene.shotPurpose === 'legacy_analysis_review' ||
    scene.confidence === 0
  )

/** @param {Record<string, any>} project */
const materialAssetsFingerprint = (project) => {
  const lastScanAt = project?.materials?.lastScanAt
  if (
    !Array.isArray(project?.materials?.assets) ||
    typeof lastScanAt !== 'string' ||
    !Number.isFinite(Date.parse(lastScanAt)) ||
    new Date(lastScanAt).toISOString() !== lastScanAt
  ) return null
  const assets = project.materials.assets.map((/** @type {Record<string, any>} */ asset) => {
    if (
      !isRecord(asset) ||
      !identifier(asset.id) ||
      typeof asset.label !== 'string' ||
      asset.label.length === 0 ||
      asset.label.length > 200 ||
      !Number.isSafeInteger(asset.analyzedPercent) ||
      asset.analyzedPercent < 0 ||
      asset.analyzedPercent > 100 ||
      !Number.isFinite(asset.durationSeconds) ||
      asset.durationSeconds < 0 ||
      !Number.isSafeInteger(asset.sceneCount) ||
      asset.sceneCount < 0 ||
      !['ready', 'analyzing', 'queued', 'failed'].includes(asset.status)
    ) return null
    return {
      id: asset.id,
      label: asset.label,
      analyzedPercent: asset.analyzedPercent,
      durationSeconds: asset.durationSeconds,
      sceneCount: asset.sceneCount,
      status: asset.status,
    }
  })
  if (assets.some((/** @type {Record<string, any> | null} */ asset) => asset === null)) return null
  return fingerprint({
    lastScanAt,
    assets: assets.sort((
      /** @type {Record<string, any>} */ left,
      /** @type {Record<string, any>} */ right,
    ) => left.id.localeCompare(right.id)),
  })
}

/**
 * Distinguishes an actual analyzed-material replacement from a routine scan
 * refresh. Runtime counters and scan timestamps are deliberately excluded:
 * they do not change the material or its usable scene evidence, and must not
 * invalidate a completed storyboard, timeline, preview, or delivery output.
 * @param {Record<string, any> | null | undefined} materials
 */
export const materialContentFingerprint = (materials) => {
  if (!isRecord(materials)) return null
  if (hasLibraryMaterialReferences(materials) && !identifier(materials.authorizationId)) {
    return fingerprint({
      libraryReferences: true,
      referencedAssetCount: materials.referencedAssetCount,
    })
  }
  if (!identifier(materials.authorizationId) || !Array.isArray(materials.assets)) return null
  const assets = materials.assets.map((asset) => {
    if (!isRecord(asset) || !identifier(asset.id)) return null
    const stable = clone(asset)
    delete stable.analyzedPercent
    return stable
  })
  if (assets.some((asset) => asset === null)) return null
  const validAssets = /** @type {Record<string, any>[]} */ (assets)
  return fingerprint({
    authorizationId: materials.authorizationId,
    assets: validAssets.sort((left, right) => left.id.localeCompare(right.id)),
  })
}

export class WorkbenchJobCoordinatorError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'WorkbenchJobCoordinatorError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] */
const coordinatorError = (code, status) => new WorkbenchJobCoordinatorError(code, status)

/**
 * Full semantic creation may internally revise a server-created draft.
 * @param {Record<string, any>} privateInput
 */
export const isAutomaticPackagingRevision = (privateInput) =>
  // The persisted instruction is normalized to `revise` even for the first
  // automatic create. The explicit packaging flag is the authorization
  // boundary; ordinary create/revise editor jobs keep it false and cannot
  // enter this fallback.
  privateInput?.automaticPackaging === true

const revisionFingerprintPattern = /^[a-f0-9]{64}$/u

/**
 * Stitch Preview / Jianying enqueue identity from a known timeline id and a
 * committed editor result. `finalize_timeline` and `propose_timeline_patch`
 * omit timelineId; never read a result-only timelineId, even if a stray field
 * appears, so enqueue cannot retarget another draft.
 * @param {{
 *   knownTimelineId: unknown,
 *   result: unknown,
 * }} input
 * @returns {{timelineId: string, revision: number, revisionFingerprint: string} | null}
 */
export const toEditorAutomaticOutputIdentity = ({ knownTimelineId, result }) => {
  if (!identifier(knownTimelineId) || !isRecord(result)) return null
  const revision = Number.isSafeInteger(result.revision)
    ? result.revision
    : Number.isSafeInteger(result.proposedRevision)
      ? result.proposedRevision
      : null
  const revisionFingerprint = typeof result.revisionFingerprint === 'string'
    ? result.revisionFingerprint
    : typeof result.proposedRevisionFingerprint === 'string'
      ? result.proposedRevisionFingerprint
      : null
  if (
    !Number.isSafeInteger(revision) ||
    revision < 1 ||
    typeof revisionFingerprint !== 'string' ||
    !revisionFingerprintPattern.test(revisionFingerprint)
  ) return null
  return {
    timelineId: knownTimelineId,
    revision,
    revisionFingerprint,
  }
}

/**
 * Validate a persisted packaging application execution against the canonical
 * timeline after a Workbench restart. The base timeline may be absent because
 * the application action creates the first revision for the execution.
 * @param {{execution: Record<string, any>, projectId: string, instructionFingerprint: string, richTimelineRepository: {getRevision: Function}, recoveredRevisionReady: Function}} input
 */
export const validatePackagingApplicationResume = async ({
  execution,
  projectId,
  instructionFingerprint,
  richTimelineRepository,
  recoveredRevisionReady,
}) => {
  if (
    !isRecord(execution) ||
    execution.tool !== 'apply_packaging_recommendation' ||
    !isRecord(execution.result) ||
    !identifier(execution.result.timelineId) ||
    !Number.isSafeInteger(execution.result.proposedRevision) ||
    !identifier(projectId) ||
    typeof instructionFingerprint !== 'string'
  ) return null
  const revision = await richTimelineRepository.getRevision({
    projectId,
    timelineId: execution.result.timelineId,
    revision: execution.result.proposedRevision,
  })
  if (
    !revision ||
    !(await recoveredRevisionReady(revision)) ||
    revision.status !== 'draft' ||
    revision.source?.kind !== 'agent' ||
    revision.source?.instructionFingerprint !== instructionFingerprint ||
    revision.contentFingerprint !== execution.result.proposedContentFingerprint ||
    revision.revisionFingerprint !== execution.result.proposedRevisionFingerprint
  ) return null
  return {
    patchId: `packaging-${revision.revisionFingerprint.slice(0, 16)}`,
    validation: 'accepted',
    errorCode: null,
    timelineId: revision.timelineId,
    proposedRevision: revision.revision,
    proposedContentFingerprint: revision.contentFingerprint,
    proposedRevisionFingerprint: revision.revisionFingerprint,
  }
}
/** @param {string} code @param {boolean} [recoverable] */
const publicError = (code, recoverable = true) => ({ code, recoverable })

/** @type {Readonly<Record<string, string>>} */
const editorToolProgressDetail = Object.freeze({
  get_project_brief: '正在读取创作要求',
  search_materials: '正在按当前文案搜索匹配镜头',
  inspect_candidate: '正在核对候选镜头证据',
  get_template_constraints: '正在读取模板约束',
  get_capability_matrix: '正在核对可用剪辑能力',
  get_timeline_summary: '正在读取当前时间线',
  propose_timeline_patch: '正在写入语义匹配的镜头范围',
  apply_packaging_recommendation: '正在应用已验证的包装推荐',
  preflight_timeline: '正在检查时间线完整性',
  finalize_timeline: '正在定稿时间线',
  request_preview: '正在创建预览任务',
  request_jianying_export: '正在创建剪映草稿任务',
})
const jianyingDraftPublicErrorCodes = new Set([
  'TPL002_TEMPLATE_NOT_APPROVED',
  'JY002_TEMPLATE_CAPABILITY_UNSUPPORTED',
  'JY002_DRAFT_STRUCTURE_INVALID',
  'JY002_MATERIAL_AUTHORIZATION_EXPIRED',
  'JY002_VOICEOVER_AUDIO_MISSING',
  'JY002_PATH_PERMISSION_DENIED',
  'JY002_DESKTOP_VERSION_UNSUPPORTED',
  'JY002_OUTPUT_CONFLICT',
  'JY004_BGM_RANGE_UNSUPPORTED',
  'WORKBENCH_JIANYING_EXPORT_INPUT_INVALID',
])
/** @param {string} code */
const isJianyingPresetNarrationPublicErrorCode = (code) =>
  code === 'JIANYING_TTS_PRESET_NOT_FOUND' ||
  code.startsWith('JIANYING_LOCAL_TTS_')
const emptyPreview = () => ({
  status: 'not_started',
  resourceId: null,
  durationSeconds: null,
  updatedAt: null,
})
const emptyEditor = () => ({
  timelineId: null,
  timelineRevision: null,
})
const emptyDelivery = () => ({
  template: { status: 'not_started', name: null, version: null, reason: null },
  preflight: { status: 'not_started', checkedAt: null, checks: [] },
  exportJob: null,
  finalVideo: null,
  recoveryOptions: [],
})

/**
 * Build the default server-side packaging provider only when the private
 * index is bound to a known active Jianying identity. Keeping this factory
 * beside the coordinator prevents callers from accidentally bypassing the
 * profile/version admission check.
 * @param {{
 *   index?: Record<string, any> | null,
 *   ranker?: ((input: Record<string, any>) => unknown) | null,
 *   supportedFamilies?: string[] | null,
 *   profileId?: string | null,
 *   appVersion?: string | null,
 *   qualifyCandidate?: ((input: {entry: Record<string, any>, catalog: Record<string, any>, signal: AbortSignal | null}) => Promise<unknown> | unknown) | null,
 *   qualificationRegistry?: Record<string, any> | null,
 * }} input
 */
export const createWorkbenchPackagingRecommendationProvider = ({
  index = null,
  ranker = null,
  supportedFamilies = null,
  profileId = null,
  appVersion = null,
  qualifyCandidate = null,
  qualificationRegistry = null,
} = {}) => {
  if (index && (typeof profileId !== 'string' || typeof appVersion !== 'string')) return null
  return createPackagingRecommendationProvider({
    index,
    ranker,
    supportedFamilies,
    profileId,
    appVersion,
    qualifyCandidate,
    qualificationRegistry,
  })
}

/**
 * A resolved provider represents the current Writer admission boundary. Its
 * narrowed index must also drive template-token refresh; the startup catalog
 * may contain discoverable resources that are not admitted for that Writer.
 * @param {{index?: Record<string, any>} | null | undefined} provider
 * @param {Record<string, any> | null} startupIndex
 * @param {boolean} [dynamicResolverPresent]
 */
export const selectCurrentPackagingResourceIndex = (provider, startupIndex, dynamicResolverPresent = false) =>
  provider?.index ?? (dynamicResolverPresent ? null : startupIndex)

/**
 * Template-authored visual slots still need a current admitted catalog while
 * automatic recommendation is deferred to the queued Editor worker. Without
 * this distinction, suppressing the recommendation also strips every private
 * flower/sticker/effect slot from the base timeline before the worker starts.
 * @param {Record<string, any> | null} constraints
 */
const templateConstraintsRequirePackagingIndex = (constraints) => {
  if (!constraints) return false
  return (
    (Array.isArray(constraints.packagingSegments) && constraints.packagingSegments.length > 0) ||
    (Array.isArray(constraints.richTextSlots) && constraints.richTextSlots.some(
      (/** @type {Record<string, any>} */ slot) =>
        slot.decorationKind === 'flower' || slot.decorationKind === 'bubble',
    ))
  )
}

/**
 * Direct-ID candidates are qualified per request from the current private
 * Catalog, so they do not require any discovery row to be durably promoted.
 * Other providers still require a current admitted Writer index.
 * @param {{qualificationMode?: string} | null | undefined} provider
 * @param {{ready?: boolean, catalogAvailable?: boolean} | null | undefined} current
 */
export const isCurrentPackagingIdentityAvailable = (provider, current) =>
  current?.ready === true || (
    provider?.qualificationMode === 'request_scoped_direct_id' &&
    current?.catalogAvailable === true
  )

/**
 * @param {{
 *   jobRepository: Record<string, Function>,
 *   editPlanRepository: Record<string, Function>,
 *   projectRepository: {get: Function, save: Function, saveIfCurrent: Function, list?: Function},
 *   materialAnalysisProvider: {restoreAnalysis: Function, analyzeMaterials: Function, searchCandidates: Function, resolvePreviewSources: Function, inspectCandidate?: Function},
 *   director: {segmentScript: Function, rankCandidates: Function},
 *   previewProvider: {renderPreview: Function, getResource: Function, deleteResource: Function},
 *   referenceTemplateAdapter?: {generate: Function},
 *   referenceTemplateRepository?: {stageGenerated?: Function, getStage?: Function, commit?: Function, publish?: Function, rollback?: Function, rollbackByOwner?: Function, listPending?: Function, get?: Function, list?: Function, review?: Function, getApproved?: Function, getApprovedForExport?: Function},
 *   jianyingDraftCapability?: {exportDraft: Function, cleanupDraft: Function},
 *   ownerId?: string,
 *   concurrency?: number,
   *   richTimelineRepository?: {
 *     saveRevision: Function,
 *     saveDraftAndSetCurrent: Function,
 *     getRevision: Function,
 *     getRevisionByFingerprint: Function,
 *     listRevisions: Function,
 *     getCurrent: Function,
 *     setCurrent: Function,
 *     clearCurrent: Function,
 *     removeByProject: Function,
 *     finalize: Function,
 *   },
 *   llmGateway?: {generate: Function},
 *   bgmLibrary?: {isAuthorizedTrack: Function},
 *   narrationProvider?: {getNarrationBundle: Function, resolveNarrationBundle: Function, resolveAudioToken: Function},
 *   materialAnalysisRunGovernor?: {inspect: Function},
 *   materialAnalysisRuntimeRoot?: string | null,
 *   materialAnalysisTempRoot?: string | null,
 *   resolveMaterialLibrarySceneBinding?: ((input: {projectId: string, sceneId: string}) => Promise<{projectId: string, authorizationId: string} | null>) | null,
 *   listStoryboardSearchScopes?: ((projectId: string) => Promise<Array<{projectId: string, authorizationId: string}>> | Array<{projectId: string, authorizationId: string}>) | null,
 *   listReferencedAssetIds?: ((projectId: string) => string[] | null | undefined) | null,
 *   materialAnalysisResumeDelayMs?: number,
 *   batchTextCatalog?: {entries: readonly any[], profile_id: string, evidence_profile: Record<string, unknown>} | null,
 *   packagingResourceIndex?: Record<string, any> | null,
 *   packagingRecommendationFamilies?: string[] | null,
 *   jianyingProfileId?: string | null,
 *   jianyingAppVersion?: string | null,
 *   privateCatalogCapabilities?: string[],
 *   evidencedCapabilities?: string[],
 *   promotionReceipts?: readonly Record<string, unknown>[],
 *   packagingRanker?: ((input: Record<string, any>) => Promise<Record<string, any>> | Record<string, any>) | null,
 *   packagingRecommendationProvider?: {recommend: Function, index: Record<string, any>} | null,
 *   creativeShadowPlanner?: {run: Function, prepare?: Function, persist?: Function, bindTimeline?: Function} | null,
 *   creativePlanningMode?: 'off' | 'shadow' | 'active',
 *   creativeTechniqueMode?: 'off' | 'shadow' | 'active',
 *   creativeAudioCueMode?: 'off' | 'shadow' | 'active',
 *   resolveCreativeSfxCue?: ((input: {projectId: string, semanticFamily: string, importance: string, desiredDurationUs: number, tags?: string[]}) => Promise<Record<string, any> | null>) | null,
 *   creativeAutoOutputs?: boolean,
 *   readPackagingReadiness?: (input: {index: Record<string, any> | null, profileId: string | null, appVersion: string | null}) => Promise<{ready: boolean, catalogAvailable?: boolean, profileId?: string | null, appVersion?: string | null, catalogFingerprint?: string | null}> | {ready: boolean, catalogAvailable?: boolean, profileId?: string | null, appVersion?: string | null, catalogFingerprint?: string | null},
 *   resolvePackagingProvider?: () => Promise<{recommend: Function, index: Record<string, any>, qualificationMode?: string} | null> | {recommend: Function, index: Record<string, any>, qualificationMode?: string} | null,
 *   leaseDurationMs?: number,
 *   heartbeatIntervalMs?: number,
 *   storyboardProgressHeartbeatMs?: number,
 *   jobTimeoutMs?: number,
 *   logger?: (event: Record<string, unknown>) => void,
 *   now?: () => Date | string,
 *   createId?: (kind: 'job' | 'attempt' | 'plan') => string,
 * }} dependencies
 */
export const createWorkbenchJobCoordinator = (dependencies) => {
  const {
    jobRepository,
    editPlanRepository,
    projectRepository,
    materialAnalysisProvider,
    director,
    previewProvider,
    referenceTemplateAdapter,
    referenceTemplateRepository,
    jianyingDraftCapability,
    richTimelineRepository,
    llmGateway,
    bgmLibrary,
    narrationProvider,
    materialAnalysisRunGovernor = createMaterialAnalysisRunGovernor(),
    materialAnalysisRuntimeRoot = null,
    materialAnalysisTempRoot = null,
    resolveMaterialLibrarySceneBinding = null,
    listStoryboardSearchScopes = null,
    listReferencedAssetIds = null,
    materialAnalysisResumeDelayMs = 1_000,
    batchTextCatalog = null,
    packagingResourceIndex = null,
    packagingRecommendationFamilies = null,
    jianyingProfileId = null,
    jianyingAppVersion = null,
    privateCatalogCapabilities = [],
    evidencedCapabilities = [],
    promotionReceipts = [],
    packagingRanker = null,
    packagingRecommendationProvider = null,
    creativeShadowPlanner = null,
    creativePlanningMode = 'off',
    creativeTechniqueMode = 'off',
    creativeAudioCueMode = 'off',
    resolveCreativeSfxCue = null,
    creativeAutoOutputs = false,
    readPackagingReadiness = null,
    resolvePackagingProvider = null,
    ownerId = `workbench-worker-${randomUUID()}`,
    concurrency = 2,
    leaseDurationMs = 30_000,
    heartbeatIntervalMs = Math.max(100, Math.floor(leaseDurationMs / 3)),
    jobTimeoutMs = 10 * 60_000,
    storyboardProgressHeartbeatMs = 2_000,
    logger = () => {},
    now = () => new Date(),
    createId = (/** @type {'job' | 'attempt' | 'plan'} */ kind) => `${kind}-${randomUUID()}`,
  } = dependencies ?? {}
  const editorCapabilityOptions = {
    jianyingProfileId,
    privateCatalogCapabilities,
    evidencedCapabilities,
    promotionReceipts,
  }
  const creativeAllowedCapabilities = creativePlanningMode === 'active'
    ? allowedCreativeCapabilityIds(
        createEditorCapabilityRegistry(editorCapabilityOptions).list().capabilities,
      )
    : []
  const creativePlanner = /** @type {Record<string, Function> | null} */ (creativeShadowPlanner)
  const automaticPackagingRanker = packagingRanker ?? createLlmGatewayPackagingRanker({
    gateway: llmGateway,
    logger,
  })
  const staticAutomaticPackagingProvider = packagingRecommendationProvider ??
    createWorkbenchPackagingRecommendationProvider({
      index: packagingResourceIndex,
      ranker: automaticPackagingRanker,
      supportedFamilies: packagingRecommendationFamilies,
      profileId: jianyingProfileId,
      appVersion: jianyingAppVersion,
    })

  const resolveAutomaticPackagingProvider = async () => {
    if (typeof resolvePackagingProvider === 'function') {
      try { return await resolvePackagingProvider() } catch { return null }
    }
    return staticAutomaticPackagingProvider
  }

  const attachStyleAssignments = async (
    packaging,
    templateConstraints,
    editPlan,
    signal = null,
    brief = null,
    sceneCards = [],
  ) => {
    if (!templateConstraints || typeof llmGateway?.generate !== 'function') {
      return {
        ...packaging,
        effectAssignments: [],
        stickerAssignments: [],
      }
    }
    const highlights = resolveAssignmentHighlights({ packaging, brief })
    const inventory = createTemplateStyleInventory(templateConstraints.richTextSlots)
    const plan = await completeTemplatePackagingAssignments({
      generate: (request, options) => llmGateway.generate(request, options),
      highlights,
      inventory,
      effects: createTemplateOverlayInventory(templateConstraints.packagingSegments, 'effect'),
      stickers: createTemplateOverlayInventory(templateConstraints.packagingSegments, 'sticker'),
      scenes: buildAssignmentScenes({ editPlan, sceneCards }),
      signal,
    })
    if (!plan) {
      return {
        ...packaging,
        effectAssignments: [],
        stickerAssignments: [],
      }
    }
    return {
      ...packaging,
      styleAssignments: plan.styleAssignments,
      effectAssignments: plan.effectAssignments,
      stickerAssignments: plan.stickerAssignments,
    }
  }

  const resolveExportOverlayAssignments = async ({
    brief,
    packaging,
    templateGuidance,
    editPlan,
    projectId,
    signal,
  }) => {
    const empty = { effects: [], stickers: [] }
    if (!templateGuidance) return empty
    try {
      const constraints = createTimelineTemplateConstraints(templateGuidance)
      const attached = await attachStyleAssignments(
        resolvePackagingForExecution(packaging ?? brief?.packaging),
        constraints,
        editPlan,
        signal,
        brief,
        await packagingSceneCardsFor(projectId),
      )
      return {
        effects: Array.isArray(attached.effectAssignments) ? attached.effectAssignments : [],
        stickers: Array.isArray(attached.stickerAssignments) ? attached.stickerAssignments : [],
      }
    } catch {
      return empty
    }
  }

  /** @param {{recommend: Function, index: Record<string, any>, qualificationMode?: string} | null} provider */
  const assertCurrentPackagingReadiness = async (provider) => {
    if (!provider) return null
    if (typeof readPackagingReadiness !== 'function') {
      throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
    }
    let current
    try {
      current = await readPackagingReadiness({
        index: packagingResourceIndex,
        profileId: jianyingProfileId,
        appVersion: jianyingAppVersion,
      })
    } catch {
      throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
    }
    if (typeof resolvePackagingProvider === 'function') {
      const providerIndex = provider?.index
      const providerFingerprint = providerIndex?.catalogFingerprint
      const providerProfile = providerIndex?.profileId
      const providerVersion = providerIndex?.appVersion
      const identityReady = isCurrentPackagingIdentityAvailable(provider, current)
      if (
        !identityReady ||
        typeof providerFingerprint !== 'string' ||
        typeof providerProfile !== 'string' ||
        typeof providerVersion !== 'string' ||
        current.profileId !== providerProfile ||
        current.appVersion !== providerVersion ||
        current.catalogFingerprint !== providerFingerprint
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
      }
      return
    }
    const expectedCatalogFingerprint = packagingResourceIndex?.catalogFingerprint
    if (
      current?.ready !== true ||
      typeof jianyingProfileId !== 'string' ||
      typeof jianyingAppVersion !== 'string' ||
      current.profileId !== jianyingProfileId ||
      current.appVersion !== jianyingAppVersion ||
      typeof expectedCatalogFingerprint !== 'string' ||
      current.catalogFingerprint !== expectedCatalogFingerprint
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
    }
  }
  if (
    !hasMethods(jobRepository, requiredJobRepositoryMethods) ||
    !hasMethods(editPlanRepository, requiredEditPlanRepositoryMethods) ||
    !hasMethods(projectRepository, ['get', 'save', 'saveIfCurrent']) ||
    !hasMethods(materialAnalysisProvider, [
      'restoreAnalysis',
      'analyzeMaterials',
      'searchCandidates',
      'resolvePreviewSources',
    ]) ||
    !hasMethods(director, ['segmentScript', 'rankCandidates']) ||
    !hasMethods(previewProvider, ['renderPreview', 'getResource', 'deleteResource']) ||
    !['off', 'shadow', 'active'].includes(creativePlanningMode) ||
    !['off', 'shadow', 'active'].includes(creativeTechniqueMode) ||
    !['off', 'shadow', 'active'].includes(creativeAudioCueMode) ||
    (resolveCreativeSfxCue !== null && typeof resolveCreativeSfxCue !== 'function') ||
    typeof creativeAutoOutputs !== 'boolean' ||
    (creativeAutoOutputs && creativePlanningMode !== 'active') ||
    (creativePlanningMode === 'off' && creativeShadowPlanner !== null) ||
    (creativePlanningMode === 'shadow' && !hasMethods(creativeShadowPlanner, ['run'])) ||
    (creativePlanningMode === 'active' && !hasMethods(creativeShadowPlanner, ['prepare', 'persist']))
  ) {
    throw coordinatorError('WORKBENCH_JOB_COORDINATOR_DEPENDENCY_MISSING')
  }
  if (
    richTimelineRepository !== undefined &&
    !hasMethods(richTimelineRepository, [
      'saveRevision',
      'saveDraftAndSetCurrent',
      'getRevision',
      'getRevisionByFingerprint',
      'listRevisions',
      'getCurrent',
      'setCurrent',
      'clearCurrent',
      'finalize',
    ])
  ) {
    throw coordinatorError('WORKBENCH_JOB_COORDINATOR_DEPENDENCY_MISSING')
  }
  if (bgmLibrary !== undefined && !hasMethods(bgmLibrary, ['isAuthorizedTrack'])) {
    throw coordinatorError('WORKBENCH_JOB_COORDINATOR_DEPENDENCY_MISSING')
  }
  if (
    narrationProvider !== undefined &&
    !hasMethods(narrationProvider, ['getNarrationBundle', 'resolveNarrationBundle', 'resolveAudioToken'])
  ) throw coordinatorError('WORKBENCH_JOB_COORDINATOR_DEPENDENCY_MISSING')
  if (materialAnalysisRunGovernor !== undefined && !hasMethods(materialAnalysisRunGovernor, ['inspect'])) {
    throw coordinatorError('WORKBENCH_JOB_COORDINATOR_DEPENDENCY_MISSING')
  }
  if (resolveMaterialLibrarySceneBinding !== null && typeof resolveMaterialLibrarySceneBinding !== 'function') {
    throw coordinatorError('WORKBENCH_JOB_COORDINATOR_DEPENDENCY_MISSING')
  }
  if (
    !identifier(ownerId) ||
    !Number.isSafeInteger(concurrency) ||
    concurrency < 1 ||
    concurrency > 32 ||
    !Number.isSafeInteger(leaseDurationMs) ||
    leaseDurationMs < 1 ||
    !Number.isSafeInteger(heartbeatIntervalMs) ||
    heartbeatIntervalMs < 1 ||
    heartbeatIntervalMs >= leaseDurationMs ||
    !Number.isSafeInteger(jobTimeoutMs) ||
    jobTimeoutMs < 1 ||
    !Number.isSafeInteger(materialAnalysisResumeDelayMs) ||
    materialAnalysisResumeDelayMs < 1 ||
    typeof logger !== 'function'
  ) {
    throw coordinatorError('WORKBENCH_JOB_COORDINATOR_CONFIG_INVALID')
  }

  let started = false
  let shutdownController = new AbortController()
  const pending = new Map()
  const active = new Map()
  const retrying = new Set()
  /** @type {Map<string, Promise<void>>} */
  const editorJobCreationLocks = new Map()

  /**
   * Serialize editor creation per project before any RichTimeline mutation.
   * The persistent job repository still performs the final atomic type claim;
   * this local gate prevents a rejected fresh retry from moving the project's
   * current timeline pointer while another editor job owns the project.
   * @param {string} projectId
   */
  const acquireEditorJobCreationLock = async (projectId) => {
    const previous = editorJobCreationLocks.get(projectId) ?? Promise.resolve()
    /** @type {() => void} */
    let releaseCurrent = () => {}
    /** @type {Promise<void>} */
    const current = new Promise((resolve) => {
      releaseCurrent = () => resolve(undefined)
    })
    const tail = previous.catch(() => undefined).then(() => current)
    editorJobCreationLocks.set(projectId, tail)
    await previous.catch(() => undefined)
    let released = false
    return () => {
      if (released) return
      released = true
      releaseCurrent()
      if (editorJobCreationLocks.get(projectId) === tail) {
        editorJobCreationLocks.delete(projectId)
      }
    }
  }
  /** @type {Map<string, ReturnType<typeof setTimeout>>} */
  const materialResumeTimers = new Map()
  /** @type {Map<string, number>} */
  const materialResumeAttempts = new Map()
  /** @type {Map<string, Promise<void>>} */
  const materialStateLocks = new Map()
  /** @type {Promise<void>} */
  let drainPromise = Promise.resolve()

  const nowIso = () => timestamp(now())

  /** Serialize material job creation and orphan-state reconciliation per project. */
  /** @param {string} projectId @param {() => Promise<any>} operation */
  const withMaterialStateLock = async (projectId, operation) => {
    const previous = materialStateLocks.get(projectId) ?? Promise.resolve()
    /** @type {() => void} */
    let release = () => {}
    /** @type {Promise<void>} */
    const current = new Promise((resolve) => { release = () => resolve() })
    const queued = previous.then(() => current)
    materialStateLocks.set(projectId, queued)
    await previous
    try {
      return await operation()
    } finally {
      release()
      if (materialStateLocks.get(projectId) === queued) materialStateLocks.delete(projectId)
    }
  }

  /** Prepare one durable sentence audio asset and trusted scene bound per shot. */
  const prepareNarrationTimeline = async (
    /** @type {{projectId: string, authorizationId: string, editPlan: Record<string, any>, brief: unknown}} */ input,
    /** @type {{allowSynthesis?: boolean, signal?: AbortSignal}} */ options = {},
  ) => {
    const brief = isRecord(input.brief) ? input.brief : {}
    if (brief.voiceover !== 'required') return { narrationSegments: null, sceneBounds: undefined }
    if (!narrationProvider || !identifier(brief.voiceId)) {
      throw coordinatorError('WORKBENCH_VOICE_REQUIRED', 409)
    }
    const items = input.editPlan.items
      .filter((/** @type {Record<string, any>} */ item) => isRecord(item) && item.status === 'selected')
      .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) => Number(left.order) - Number(right.order))
    const selected = items.map((/** @type {Record<string, any>} */ item) => {
      const candidate = item.candidates.find((/** @type {Record<string, any>} */ entry) => entry.candidate_id === item.selected_candidate_id)
      if (!candidate) throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
      return { item, candidate }
    })
    const narrationInput = {
      projectId: input.projectId,
      jobId: `timeline-${fingerprint({ voiceId: brief.voiceId, rate: brief.voiceRate, items: items.map((/** @type {Record<string, any>} */ item) => [item.sentence_id, item.voiceover_text]) }).slice(0, 24)}`,
      voiceId: brief.voiceId,
      rate: Number.isInteger(brief.voiceRate) ? brief.voiceRate : 0,
      segments: items.map((/** @type {Record<string, any>} */ item) => ({ sentence_id: item.sentence_id, text: item.voiceover_text })),
      signal: options.signal,
    }
    const bundle = options.allowSynthesis
      ? await narrationProvider.resolveNarrationBundle(narrationInput)
      : await narrationProvider.getNarrationBundle(narrationInput)
    if (!bundle && !options.allowSynthesis) {
      throw coordinatorError('WORKBENCH_NARRATION_ASSET_REQUIRED', 409)
    }
    if (!Array.isArray(bundle?.segments) || bundle.segments.length !== selected.length) {
      throw coordinatorError('WORKBENCH_NARRATION_BUNDLE_INVALID', 502)
    }
    const signal = options.signal ?? new AbortController().signal
    const resolveSelectedSources = async (
      /** @type {Array<{candidate: Record<string, any>}>} */ entries,
    ) => {
      const resolvedSources = await resolveEditorTimelineSources(
        { projectId: input.projectId, authorizationId: input.authorizationId },
        entries.map((entry) => ({
          candidateId: entry.candidate.candidate_id,
          start: entry.candidate.start,
          end: entry.candidate.end,
          assetId: entry.candidate.asset_id,
          sceneId: entry.candidate.scene_id,
        })),
        signal,
      )
      if (!Array.isArray(resolvedSources) || resolvedSources.length !== entries.length) {
        throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      }
      return resolvedSources
    }
    const resolved = await resolveSelectedSources(selected)
    const currentProject = await projectRepository.get(input.projectId)
    const durationForAsset = (/** @type {Record<string, any>} */ candidate, /** @type {Record<string, any>} */ source) =>
      finitePositiveSeconds(source?.assetDurationSeconds) ??
      finitePositiveSeconds(currentProject?.materials?.assets?.find((
        /** @type {Record<string, any>} */ asset,
      ) => asset?.id === candidate.asset_id)?.durationSeconds)
    const windowFor = (
      /** @type {Record<string, any>} */ candidate,
      /** @type {Record<string, any>} */ source,
      /** @type {Map<string, Array<{start: number, end: number}>>} */ reservedByAsset,
    ) => unusedMediaWindow(
      source?.sceneStart,
      source?.sceneEnd,
      durationForAsset(candidate, source),
      reservedByAsset.get(candidate.asset_id) ?? [],
    )
    const coversNarration = (
      /** @type {{start: number, end: number} | null} */ window,
      /** @type {number} */ durationUs,
    ) => Boolean(window && Math.round((window.end - window.start) * 1_000_000) >= durationUs)
    /** @type {Set<string>} */
    const usedSceneKeys = new Set()
    /** @type {Map<string, Array<{start: number, end: number}>>} */
    const reservedByAsset = new Map()
    /** @type {Record<string, any>} */
    const sceneBounds = {}
    for (let index = 0; index < selected.length; index += 1) {
      const source = resolved[index]
      if (
        !Number.isFinite(source?.sceneStart) ||
        !Number.isFinite(source?.sceneEnd) ||
        source.sceneEnd <= source.sceneStart
      ) throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      const neededUs = bundle.segments[index]?.durationUs
      if (!Number.isSafeInteger(neededUs) || neededUs < 1) {
        throw coordinatorError('WORKBENCH_NARRATION_BUNDLE_INVALID', 502)
      }
      let { item, candidate } = selected[index]
      let chosenSource = source
      let window = windowFor(candidate, chosenSource, reservedByAsset)
      if (!coversNarration(window, neededUs)) {
        const alternatives = item.candidates.filter((/** @type {Record<string, any>} */ entry) =>
          entry.candidate_id !== candidate.candidate_id &&
          !usedSceneKeys.has(`${entry.asset_id}\u0000${entry.scene_id}`))
        for (const alternative of alternatives) {
          const [alternativeSource] = await resolveSelectedSources([{ item, candidate: alternative }])
          if (
            !Number.isFinite(alternativeSource?.sceneStart) ||
            !Number.isFinite(alternativeSource?.sceneEnd) ||
            alternativeSource.sceneEnd <= alternativeSource.sceneStart
          ) continue
          const alternativeWindow = windowFor(alternative, alternativeSource, reservedByAsset)
          if (!coversNarration(alternativeWindow, neededUs)) continue
          item.selected_candidate_id = alternative.candidate_id
          candidate = alternative
          chosenSource = alternativeSource
          window = alternativeWindow
          selected[index] = { item, candidate }
          resolved[index] = chosenSource
          break
        }
      }
      if (!coversNarration(window, neededUs)) {
        throw coordinatorError('WORKBENCH_NARRATION_MATERIAL_DURATION_INSUFFICIENT', 409)
      }
      const sceneKey = `${candidate.asset_id}\u0000${candidate.scene_id}`
      usedSceneKeys.add(sceneKey)
      sceneBounds[sceneKey] = {
        startUs: Math.round(window.start * 1_000_000),
        durationUs: Math.round((window.end - window.start) * 1_000_000),
      }
      const reserved = reservedByAsset.get(candidate.asset_id) ?? []
      reserved.push({ start: window.start, end: window.start + neededUs / 1_000_000 })
      reservedByAsset.set(candidate.asset_id, reserved)
    }
    return { narrationSegments: bundle.segments, sceneBounds }
  }

  /** @param {unknown} brief */
  const briefOrientation = (brief) => {
    const value = isRecord(brief) ? brief.orientation : null
    return value === 'landscape' || value === 'square' || value === 'portrait'
      ? value
      : 'portrait'
  }

  /** @param {unknown} error @returns {never} */
  const rethrowRichTimelineError = (error) => {
    if (
      error instanceof EditPlanTimelineAdapterError ||
      error instanceof RichTimelineContractError ||
      error instanceof RichTimelineRepositoryError ||
      error instanceof TimelineTemplateConstraintsError
    ) {
      if (error.code === 'WORKBENCH_RICH_TIMELINE_SHADOW_DIVERGED') throw error
      const status =
        'status' in error && typeof error.status === 'number' ? error.status : 409
      throw coordinatorError(
        error.code?.startsWith('WORKBENCH_')
          ? error.code
          : 'WORKBENCH_RICH_TIMELINE_SHADOW_INVALID',
        status,
      )
    }
    throw error
  }

  /** @param {string} projectId @param {Record<string, any>} editPlan */
  const shadowTimelineIdFor = (projectId, editPlan) =>
    `tl-${fingerprint({
      projectId,
      planId: editPlan.plan_id,
      editPlan,
    }).slice(0, 24)}`

  /** @param {Record<string, any>} left @param {Record<string, any>} right */
  const sameTimelineProjection = (left, right) =>
    left.contentFingerprint === right.contentFingerprint &&
    JSON.stringify(left.source?.templateIdentity ?? null) ===
      JSON.stringify(right.source?.templateIdentity ?? null) &&
    left.source?.automaticPackaging === right.source?.automaticPackaging &&
    left.source?.packagingCatalogFingerprint === right.source?.packagingCatalogFingerprint

  /** Load only public scene-card fields; the provider performs the final prompt-boundary validation. */
  /** @param {string} projectId */
  const packagingSceneCardsFor = async (projectId) => {
    const project = await projectRepository.get(projectId)
    return Array.isArray(project?.materials?.assets)
      ? project.materials.assets.flatMap((/** @type {Record<string, any>} */ asset) => Array.isArray(asset?.scenes) ? asset.scenes : [])
      : []
  }

  /**
   * Re-resolve every selected source immediately before asking the packaging
   * provider for recommendations. This deliberately returns no private source
   * data: successful resolution proves the active authorization and manifest
   * still admit the exact selected plan.
   * @param {{projectId: string, authorizationId: string, editPlan: Record<string, any>, signal?: AbortSignal}} input
   */
  const assertActivePackagingSources = async (input) => {
    const selectedItems = Array.isArray(input.editPlan?.items)
      ? input.editPlan.items
        .filter((/** @type {Record<string, any>} */ item) => item?.status === 'selected')
        .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) => Number(left.order) - Number(right.order))
      : []
    const sourceSelections = selectedItems.map((/** @type {Record<string, any>} */ item) => {
      const candidate = Array.isArray(item.candidates)
        ? item.candidates.find((/** @type {Record<string, any>} */ entry) => entry.candidate_id === item.selected_candidate_id)
        : null
      if (
        !identifier(item.sentence_id) ||
        !candidate ||
        !identifier(candidate.candidate_id) ||
        !Number.isFinite(candidate.start) ||
        !Number.isFinite(candidate.end) ||
        candidate.end <= candidate.start
      ) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
      }
      return {
        candidateId: candidate.candidate_id,
        start: candidate.start,
        end: candidate.end,
        assetId: candidate.asset_id,
        sceneId: candidate.scene_id,
      }
    })
    if (sourceSelections.length === 0) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
    }
    const resolvedSources = await resolveEditorTimelineSources(
      { projectId: input.projectId, authorizationId: input.authorizationId },
      sourceSelections,
      input.signal,
    )
    if (
      !Array.isArray(resolvedSources) ||
      resolvedSources.length !== sourceSelections.length ||
      resolvedSources.some((/** @type {Record<string, any>} */ source, index) =>
        !isRecord(source) ||
        source.candidateId !== sourceSelections[index].candidateId ||
        typeof source.sourcePath !== 'string' ||
        source.start !== sourceSelections[index].start ||
        source.end !== sourceSelections[index].end ||
        source.end <= source.start)
    ) {
      throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    return selectedItems.map((/** @type {Record<string, any>} */ item) => item.sentence_id)
  }

  /**
   * Bind uploaded-template SFX to current highlights by LLM intent.
   * The pool tokens stay private; only indexes are sent to the model.
   */
  const resolveTemplateSfxAssignment = async ({ packaging, templateConstraints, signal }) => {
    if (typeof packaging?.sfxAuthorizationId === 'string') return null
    const pool = Array.isArray(templateConstraints?.sfx) ? templateConstraints.sfx : []
    const highlights = Array.isArray(templateConstraints?.richTextSegments)
      ? templateConstraints.richTextSegments
        .map((/** @type {Record<string, any>} */ segment) => segment?.text)
        .filter((value) => typeof value === 'string' && value.trim())
      : []
    if (pool.length === 0 || highlights.length === 0) return null
    const assigned = await assignTemplateSfxPoolByLlm({
      pool,
      highlights,
      notes: typeof packaging?.packagingNotes === 'string' ? packaging.packagingNotes : '',
      gateway: llmGateway,
      signal: signal ?? null,
    })
    return assigned.length > 0 ? assigned : null
  }

  /**
   * Drop selected library shots that cannot be rebound to a live source
   * authorization. The public plan stays publishable; only bindable shots
   * enter narration and RichTimeline.
   * @param {string} projectId
   * @param {string | null | undefined} authorizationId
   * @param {Record<string, any>} editPlan
   */
  const demoteUnboundLibrarySelections = async (projectId, authorizationId, editPlan) => {
    if (!isRecord(editPlan) || !Array.isArray(editPlan.items)) return editPlan
    const project = await projectRepository.get(projectId)
    const localAuthorizationId = identifier(authorizationId) ? authorizationId : null
    /** @param {Record<string, any>} candidate */
    const candidateIsBound = async (candidate) => {
      if (!isRecord(candidate) || !identifier(candidate.candidate_id)) return false
      const sceneId = identifier(candidate.scene_id) ? candidate.scene_id : candidate.candidate_id
      const localAsset = Array.isArray(project?.materials?.assets)
        ? project.materials.assets.find((asset) =>
          asset?.id === candidate.asset_id &&
          Array.isArray(asset.scenes) &&
          asset.scenes.some((scene) => scene?.id === sceneId))
        : null
      if (localAsset && localAuthorizationId) return true
      if (typeof resolveMaterialLibrarySceneBinding === 'function') {
        const binding = await resolveMaterialLibrarySceneBinding({ projectId, sceneId })
        return identifier(binding?.authorizationId)
      }
      // Legacy local-folder jobs resolve through the project authorization
      // when no library hook is installed. Library-only projects must not.
      return Boolean(localAuthorizationId)
    }
    let changed = false
    const items = []
    for (const item of editPlan.items) {
      if (!isRecord(item) || !Array.isArray(item.candidates)) {
        items.push(item)
        continue
      }
      const keep = []
      for (const candidate of item.candidates) {
        if (await candidateIsBound(candidate)) keep.push(candidate)
        else changed = true
      }
      const selectedStillBound = keep.some((entry) => entry.candidate_id === item.selected_candidate_id)
      const nextStatus = item.status === 'selected' && selectedStillBound ? 'selected' : (
        item.status === 'selected' ? 'needs_capture' : item.status
      )
      const nextSelected = nextStatus === 'selected' ? item.selected_candidate_id : null
      if (
        nextStatus !== item.status ||
        nextSelected !== item.selected_candidate_id ||
        keep.length !== item.candidates.length
      ) changed = true
      items.push({
        ...item,
        status: nextStatus,
        selected_candidate_id: nextSelected,
        candidates: keep,
      })
    }
    return changed ? { ...editPlan, items } : editPlan
  }

  /**
   * Library-only projects have no folder authorization. Resolve each selected
   * candidate back to its source authorization before writing RichTimeline.
   * @param {string} projectId
   * @param {Record<string, any>} editPlan
   */
  const resolveLibraryAuthorizationByCandidate = async (projectId, editPlan) => {
    if (typeof resolveMaterialLibrarySceneBinding !== 'function') {
      throw coordinatorError('WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE', 409)
    }
    /** @type {Record<string, string>} */
    const authorizationByCandidateId = {}
    for (const item of (editPlan?.items ?? [])) {
      if (!isRecord(item) || item.status !== 'selected') continue
      const candidate = Array.isArray(item.candidates)
        ? item.candidates.find((entry) => entry?.candidate_id === item.selected_candidate_id)
        : null
      if (!isRecord(candidate) || !identifier(candidate.candidate_id)) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
      }
      const binding = await resolveMaterialLibrarySceneBinding({
        projectId,
        sceneId: identifier(candidate.scene_id) ? candidate.scene_id : candidate.candidate_id,
      })
      if (!identifier(binding?.authorizationId)) {
        throw coordinatorError('WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE', 409)
      }
      authorizationByCandidateId[candidate.candidate_id] = binding.authorizationId
    }
    if (Object.keys(authorizationByCandidateId).length === 0) {
      throw coordinatorError('WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE', 409)
    }
    return authorizationByCandidateId
  }

  /** @param {{projectId: string, authorizationId?: string | null, editPlan: Record<string, any>}} input */
  const timelineAuthorizationInput = async (input) => {
    if (identifier(input.authorizationId)) {
      return { authorizationId: input.authorizationId }
    }
    return {
      authorizationByCandidateId: await resolveLibraryAuthorizationByCandidate(
        input.projectId,
        input.editPlan,
      ),
    }
  }

  /**
   * Unidirectional shadow projection: EditPlan → RichTimeline only.
   * @param {{
   *   projectId: string,
   *   authorizationId: string,
   *   editPlan: Record<string, any>,
   *   templateGuidance: unknown,
   *   brief: unknown,
   *   createdAt?: string,
   *   allowNarrationSynthesis?: boolean,
   *   requireAutomaticPackaging?: boolean,
   *   suppressAutomaticPackagingRecommendation?: boolean,
   *   forceNewDraftRevision?: boolean,
 *   techniqueDecisions?: readonly Record<string, any>[],
 *   audioCueDecisions?: readonly Record<string, any>[],
   *   onTechniqueRealized?: (decisions: readonly Record<string, any>[]) => void,
   *   signal?: AbortSignal,
   * }} input
   */
  const persistShadowTimeline = async (input) => {
    if (!richTimelineRepository) return null
    try {
      input.editPlan = await demoteUnboundLibrarySelections(
        input.projectId,
        input.authorizationId,
        input.editPlan,
      )
      const brief = isRecord(input.brief) ? input.brief : {}
      const packaging = resolvePackagingForExecution(brief.packaging)
      const selectedCount = (input.editPlan.items ?? []).filter(
        (/** @type {Record<string, any>} */ item) => item?.status === 'selected',
      ).length
      if (selectedCount < 1) return null
      if (
        input.requireAutomaticPackaging === true &&
        !hasMethods(jianyingDraftCapability, ['exportDraft', 'cleanupDraft', 'commitDraft'])
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
      }
      const timelineId = shadowTimelineIdFor(input.projectId, input.editPlan)
      const baseTemplateConstraints = input.templateGuidance
        ? createTimelineTemplateConstraints(input.templateGuidance)
        : null
      const usesDraftInventory = usesUploadedDraftInventory(baseTemplateConstraints)
      const recommendationDeferred = input.suppressAutomaticPackagingRecommendation === true
      const packagingProvider = usesDraftInventory
        ? null
        : !recommendationDeferred ||
            templateConstraintsRequirePackagingIndex(baseTemplateConstraints)
          ? await resolveAutomaticPackagingProvider()
          : null
      const currentPackagingResourceIndex = selectCurrentPackagingResourceIndex(
        packagingProvider,
        packagingResourceIndex,
        typeof resolvePackagingProvider === 'function',
      )
      const templateConstraints = baseTemplateConstraints
        ? applyPackagingPlanToTimelineTemplateConstraints(
            baseTemplateConstraints,
            await attachStyleAssignments(
              packaging,
              baseTemplateConstraints,
              input.editPlan,
              input.signal,
              brief,
              await packagingSceneCardsFor(input.projectId),
            ),
            brief,
            batchTextCatalog,
            usesDraftInventory ? null : currentPackagingResourceIndex,
          )
        : null
      const narration = await prepareNarrationTimeline(input, {
        allowSynthesis: input.allowNarrationSynthesis === true,
        signal: input.signal,
      })
      let techniqueSceneBounds = narration.sceneBounds
      if (input.techniqueDecisions && techniqueSceneBounds === undefined) {
        try {
          const selected = (input.editPlan.items ?? [])
            .filter((/** @type {Record<string, any>} */ item) => item?.status === 'selected')
            .sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) => Number(left.order) - Number(right.order))
          const selections = selected.map((/** @type {Record<string, any>} */ item) => {
            const candidate = item.candidates?.find((/** @type {Record<string, any>} */ entry) => entry.candidate_id === item.selected_candidate_id)
            if (!candidate) throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
            return {
              candidateId: candidate.candidate_id,
              start: candidate.start,
              end: candidate.end,
              assetId: candidate.asset_id,
              sceneId: candidate.scene_id,
            }
          })
          const resolved = await resolveEditorTimelineSources(
            { projectId: input.projectId, authorizationId: input.authorizationId },
            selections,
            input.signal,
          )
          const validResolved = Array.isArray(resolved) && resolved.length === selected.length && resolved.every((source, index) =>
            source?.candidateId === selections[index].candidateId &&
            source?.start === selections[index].start &&
            source?.end === selections[index].end &&
            typeof source?.sourcePath === 'string' && source.sourcePath.length > 0 &&
            Number.isFinite(source?.sceneStart) && Number.isFinite(source?.sceneEnd) && source.sceneEnd > source.sceneStart)
          if (validResolved) {
            techniqueSceneBounds = {}
            for (let index = 0; index < selected.length; index += 1) {
              const item = selected[index]
              const selectedCandidate = item.candidates.find((/** @type {Record<string, any>} */ entry) => entry.candidate_id === item.selected_candidate_id)
              techniqueSceneBounds[`${selectedCandidate.asset_id}\u0000${selectedCandidate.scene_id}`] = {
                startUs: Math.round(resolved[index].sceneStart * 1_000_000),
                durationUs: Math.round((resolved[index].sceneEnd - resolved[index].sceneStart) * 1_000_000),
              }
            }
          } else {
            logger({ event: 'creative_technique_realization_degraded', code: 'CREATIVE_TECHNIQUE_SCENE_BOUND_UNAVAILABLE' })
          }
        } catch (error) {
          input.signal?.throwIfAborted()
          logger({ event: 'creative_technique_realization_degraded', code: errorCode(error) || 'CREATIVE_TECHNIQUE_SCENE_BOUND_UNAVAILABLE' })
        }
      }
      if (packagingProvider) {
        await assertCurrentPackagingReadiness(packagingProvider)
        await assertActivePackagingSources(input)
      }
      const automaticPackaging = packagingProvider && !recommendationDeferred
        ? await packagingProvider.recommend({
            brief,
            editPlan: input.editPlan,
            templateConstraints,
            narrationSegments: narration.narrationSegments,
            sceneCards: await packagingSceneCardsFor(input.projectId),
            signal: input.signal,
          })
        : null
      const templatePackagingApplied = hasCurrentCatalogTemplateBinding(templateConstraints, currentPackagingResourceIndex)
      if (
        input.requireAutomaticPackaging === true &&
        !automaticPackaging &&
        !templatePackagingApplied &&
        !usesDraftInventory
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
      }
      const selectedSentenceIds = new Set((input.editPlan.items ?? [])
        .filter((/** @type {Record<string, any>} */ item) => item?.status === 'selected')
        .map((/** @type {Record<string, any>} */ item) => item.sentence_id))
      const selectedTechniqueDecisions = Array.isArray(input.techniqueDecisions)
        ? input.techniqueDecisions.filter((decision) => selectedSentenceIds.has(decision?.beat_id))
        : null
      const selectedAudioCueDecisions = Array.isArray(input.audioCueDecisions)
        ? input.audioCueDecisions.filter((decision) => selectedSentenceIds.has(decision?.beat_id))
        : []
      const realizedTechniqueDecisions = selectedTechniqueDecisions
        ? realizeCreativeTechniqueDecisions({
            editPlan: input.editPlan,
            templateConstraints,
            sceneBounds: techniqueSceneBounds,
            narrationSegments: narration.narrationSegments,
            techniqueDecisions: selectedTechniqueDecisions,
          })
        : null
      const templateSfxAssignment = await resolveTemplateSfxAssignment({
        packaging,
        templateConstraints,
        signal: input.signal,
      })
      const adapterInput = {
        editPlan: input.editPlan,
        templateConstraints,
        ...(await timelineAuthorizationInput(input)),
        projectId: input.projectId,
        timelineId,
        createdAt: input.createdAt ?? nowIso(),
        orientation: briefOrientation(input.brief),
        captions: brief.captions,
        bgm: packaging.bgm === 'local_authorized' &&
          typeof packaging.bgmAuthorizationId === 'string'
          ? {
              audioToken: packaging.bgmAuthorizationId,
              volume: packaging.bgmVolume,
            }
          : null,
        ...(typeof packaging.sfxAuthorizationId === 'string'
          ? {
              sfx: [{
                audioToken: packaging.sfxAuthorizationId,
                volume: packaging.sfxVolume,
                startUs: packaging.sfxStartUs,
                durationUs: packaging.sfxDurationUs,
              }],
            }
          : templateSfxAssignment
            ? { sfx: templateSfxAssignment, sfxIntentAligned: true }
            : {}),
        ...narration,
        // Narration already chose unused-media windows. Technique bounds are
        // the tight analyzer scene and must not shrink that window, or a
        // legal TTS duration becomes source_range_outside_scene.
        ...(techniqueSceneBounds !== undefined && narration.sceneBounds === undefined
          ? { sceneBounds: techniqueSceneBounds }
          : {}),
        ...(realizedTechniqueDecisions ? { techniqueDecisions: realizedTechniqueDecisions } : {}),
        // Template tokens were resolved against this index even when automatic
        // recommendation is deferred. Preserve that provenance for the Writer.
        ...(usesDraftInventory
          ? {}
          : automaticPackaging
            ? {
                packagingRecommendation: automaticPackaging.recommendation,
                packagingCatalog: automaticPackaging.catalog,
              }
            : templatePackagingApplied
              ? { packagingCatalog: currentPackagingResourceIndex }
              : {}),
        automaticPackaging: usesDraftInventory ||
          automaticPackaging !== null ||
          templatePackagingApplied,
      }
      let draft = adaptEditPlanToTimeline(adapterInput)
      if (
        creativeAudioCueMode === 'active' &&
        selectedAudioCueDecisions.length > 0 &&
        packaging.sfxAuthorizationId == null
      ) {
        if (!creativeAllowedCapabilities.includes('audio.sfx.local') ||
            typeof resolveCreativeSfxCue !== 'function') {
          logger({ event: 'creative_audio_cue_realization_degraded', code: 'CREATIVE_AUDIO_CUE_CAPABILITY_UNAVAILABLE' })
        } else {
          const audio = await resolveCreativeAudioCuePlacements({
            projectId: input.projectId,
            timeline: draft,
            editPlan: input.editPlan,
            decisions: selectedAudioCueDecisions,
            resolveCue: resolveCreativeSfxCue,
            signal: input.signal,
          })
          for (const degradation of audio.degradations) {
            logger({ event: 'creative_audio_cue_realization_degraded', code: degradation.reason })
          }
          if (audio.placements.length > 0) {
            draft = adaptEditPlanToTimeline({ ...adapterInput, sfx: [...audio.placements] })
          }
        }
      }
      const pointer = await richTimelineRepository.getCurrent({ projectId: input.projectId })
      const revisions = await richTimelineRepository.listRevisions({
        projectId: input.projectId,
        timelineId: draft.timelineId,
      })
      const latest = revisions.at(-1) ?? null
      if (!latest) {
        const saved = await richTimelineRepository.saveDraftAndSetCurrent({
          timeline: draft,
          expectedCurrent: pointer,
        })
        if (realizedTechniqueDecisions && realizedTechniqueDecisions.length === input.techniqueDecisions?.length) {
          input.onTechniqueRealized?.(realizedTechniqueDecisions)
        }
        return saved
      }
      if (input.forceNewDraftRevision === true || !sameTimelineProjection(latest, draft)) {
        const nextDraft = sealRichTimeline({
          ...draft,
          revision: latest.revision + 1,
          parentRevision: latest.revision,
          parentRevisionFingerprint: latest.revisionFingerprint,
          status: 'draft',
        })
        const saved = await richTimelineRepository.saveDraftAndSetCurrent({
          timeline: nextDraft,
          expectedCurrent: pointer,
        })
        if (realizedTechniqueDecisions && realizedTechniqueDecisions.length === input.techniqueDecisions?.length) {
          input.onTechniqueRealized?.(realizedTechniqueDecisions)
        }
        return saved
      }
      const alreadyCurrent =
        pointer?.timelineId === latest.timelineId &&
        pointer?.revision === latest.revision
      if (!alreadyCurrent) {
        await richTimelineRepository.setCurrent({
          projectId: latest.projectId,
          timelineId: latest.timelineId,
          revision: latest.revision,
          expectedCurrent: pointer,
        })
      }
      if (realizedTechniqueDecisions && realizedTechniqueDecisions.length === input.techniqueDecisions?.length) {
        input.onTechniqueRealized?.(realizedTechniqueDecisions)
      }
      return latest
    } catch (error) {
      logger({
        event: 'rich_timeline_shadow_invalid',
        code: errorCode(error) || error?.code || 'WORKBENCH_RICH_TIMELINE_SHADOW_INVALID',
      })
      rethrowRichTimelineError(error)
    }
  }

  /** @param {string} projectId */
  const assertLegacyOutputMayProjectTimeline = async (projectId) => {
    if (!richTimelineRepository) return
    const pointer = await richTimelineRepository.getCurrent({ projectId })
    if (pointer) {
      throw coordinatorError('WORKBENCH_EDITOR_BOUND_OUTPUT_REQUIRED', 409)
    }
  }

  /**
   * Restore an immutable parent only while this failed Editor job still owns current draft.
   * @param {Record<string, any>} job
   */
  const restoreEditorParentIfCurrent = async (job) => {
    if (job.type !== EDITOR_JOB_TYPE || !richTimelineRepository) return
    const base = job.privateInput?.editorInstruction?.baseTimeline
    if (!isRecord(base)) return
    const draft = await richTimelineRepository.getRevision({
      projectId: job.projectId,
      timelineId: base.timelineId,
      revision: base.revision,
    })
    if (
      draft?.status !== 'draft' ||
      draft.source?.kind !== 'editor' ||
      !Number.isSafeInteger(draft.parentRevision) ||
      typeof draft.parentRevisionFingerprint !== 'string'
    ) return
    const parent = await richTimelineRepository.getRevision({
      projectId: job.projectId,
      timelineId: draft.timelineId,
      revision: draft.parentRevision,
    })
    if (
      parent?.status !== 'finalized' ||
      parent.revisionFingerprint !== draft.parentRevisionFingerprint
    ) return
    await richTimelineRepository.setCurrent({
      projectId: job.projectId,
      timelineId: parent.timelineId,
      revision: parent.revision,
      expectedCurrent: { timelineId: draft.timelineId, revision: draft.revision },
    }).catch((/** @type {unknown} */ error) => {
      if (!(error instanceof RichTimelineRepositoryError) || error.code !== 'RICH_TIMELINE_CAS_CONFLICT') {
        throw error
      }
    })
  }

  /**
   * Freeze a finalized RichTimeline identity into job private input.
   * @param {{
   *   projectId: string,
   *   authorizationId: string,
   *   editPlan: Record<string, any>,
   *   templateGuidance: unknown,
   *   brief: unknown,
   *   signal?: AbortSignal,
   * }} input
   */
  const freezeFinalizedTimelineIdentity = async (input) => {
    if (!richTimelineRepository) return null
    try {
      const brief = isRecord(input.brief) ? input.brief : {}
      const packaging = resolvePackagingForExecution(brief.packaging)
      const pointer = await richTimelineRepository.getCurrent({ projectId: input.projectId })
      const current = pointer
        ? await richTimelineRepository.getRevision(pointer)
        : null
      const timelineId =
        current?.timelineId ?? shadowTimelineIdFor(input.projectId, input.editPlan)
      const packagingProvider = await resolveAutomaticPackagingProvider()
      const currentPackagingResourceIndex = selectCurrentPackagingResourceIndex(
        packagingProvider,
        packagingResourceIndex,
        typeof resolvePackagingProvider === 'function',
      )
      const revisionTemplateConstraints = input.templateGuidance
        ? createTimelineTemplateConstraints(input.templateGuidance)
        : null
      const usesDraftInventory = usesUploadedDraftInventory(revisionTemplateConstraints)
      const templateConstraints = revisionTemplateConstraints
        ? applyPackagingPlanToTimelineTemplateConstraints(
            revisionTemplateConstraints,
            await attachStyleAssignments(
              packaging,
              revisionTemplateConstraints,
              input.editPlan,
              input.signal,
              brief,
              await packagingSceneCardsFor(input.projectId),
            ),
            brief,
            batchTextCatalog,
            usesDraftInventory ? null : currentPackagingResourceIndex,
          )
        : null
      const narration = await prepareNarrationTimeline(input)
      if (packagingProvider && !usesDraftInventory) {
        await assertCurrentPackagingReadiness(packagingProvider)
        await assertActivePackagingSources(input)
      }
      const automaticPackaging = packagingProvider && !usesDraftInventory
        ? await packagingProvider.recommend({
            brief,
            editPlan: input.editPlan,
            templateConstraints,
            narrationSegments: narration.narrationSegments,
            sceneCards: await packagingSceneCardsFor(input.projectId),
            signal: input.signal,
          })
        : null
      const templatePackagingApplied = hasCurrentCatalogTemplateBinding(templateConstraints, currentPackagingResourceIndex)
      const templateSfxAssignment = await resolveTemplateSfxAssignment({
        packaging,
        templateConstraints,
        signal: input.signal,
      })
      const adapted = adaptEditPlanToTimeline({
        editPlan: input.editPlan,
        templateConstraints,
        ...(await timelineAuthorizationInput(input)),
        projectId: input.projectId,
        timelineId,
        createdAt: nowIso(),
        orientation: briefOrientation(input.brief),
        captions: brief.captions,
        bgm: packaging.bgm === 'local_authorized' &&
          typeof packaging.bgmAuthorizationId === 'string'
          ? {
              audioToken: packaging.bgmAuthorizationId,
              volume: packaging.bgmVolume,
            }
          : null,
        ...(typeof packaging.sfxAuthorizationId === 'string'
          ? {
              sfx: [{
                audioToken: packaging.sfxAuthorizationId,
                volume: packaging.sfxVolume,
                startUs: packaging.sfxStartUs,
                durationUs: packaging.sfxDurationUs,
              }],
            }
          : templateSfxAssignment
            ? { sfx: templateSfxAssignment, sfxIntentAligned: true }
            : {}),
        ...narration,
        ...(usesDraftInventory
          ? {}
          : automaticPackaging
            ? {
                packagingRecommendation: automaticPackaging.recommendation,
                packagingCatalog: automaticPackaging.catalog,
              }
            : templatePackagingApplied
              ? { packagingCatalog: currentPackagingResourceIndex }
              : {}),
        automaticPackaging: usesDraftInventory ||
          automaticPackaging !== null ||
          templatePackagingApplied,
      })

      /** @param {Record<string, any>} timeline */
      const asFrozenIdentity = (timeline) => ({
        timelineId: timeline.timelineId,
        revision: timeline.revision,
        revisionFingerprint: timeline.revisionFingerprint,
        contentFingerprint: timeline.contentFingerprint,
        publicSummary: toPublicTimelineSummary(timeline),
      })

      if (current && sameTimelineProjection(current, adapted)) {
        if (current.status === 'finalized') return asFrozenIdentity(current)
        const finalized = await richTimelineRepository.finalize({
          projectId: current.projectId,
          timelineId: current.timelineId,
          revision: current.revision,
          revisionFingerprint: current.revisionFingerprint,
          expectedCurrent: pointer,
        })
        return asFrozenIdentity(finalized)
      }

      if (!current) {
        const revisions = await richTimelineRepository.listRevisions({
          projectId: input.projectId,
          timelineId,
        })
        const latest = revisions.at(-1) ?? null
        if (latest && sameTimelineProjection(latest, adapted)) {
          if (latest.status === 'finalized') {
            await richTimelineRepository.setCurrent({
              projectId: latest.projectId,
              timelineId: latest.timelineId,
              revision: latest.revision,
              expectedCurrent: null,
            })
            return asFrozenIdentity(latest)
          }
          const repaired = await richTimelineRepository.setCurrent({
            projectId: latest.projectId,
            timelineId: latest.timelineId,
            revision: latest.revision,
            expectedCurrent: null,
          })
          const finalized = await richTimelineRepository.finalize({
            projectId: latest.projectId,
            timelineId: latest.timelineId,
            revision: latest.revision,
            revisionFingerprint: latest.revisionFingerprint,
            expectedCurrent: repaired,
          })
          return asFrozenIdentity(finalized)
        }
        const candidate = latest
          ? sealRichTimeline({
              ...adapted,
              revision: latest.revision + 1,
              parentRevision: latest.revision,
              parentRevisionFingerprint: latest.revisionFingerprint,
              status: 'draft',
            })
          : adapted
        const draft = await richTimelineRepository.saveDraftAndSetCurrent({
          timeline: candidate,
          expectedCurrent: null,
        })
        const finalized = await richTimelineRepository.finalize({
          projectId: draft.projectId,
          timelineId: draft.timelineId,
          revision: draft.revision,
          revisionFingerprint: draft.revisionFingerprint,
          expectedCurrent: {
            timelineId: draft.timelineId,
            revision: draft.revision,
          },
        })
        return asFrozenIdentity(finalized)
      }

      const nextDraft = sealRichTimeline({
        ...adapted,
        revision: current.revision + 1,
        parentRevision: current.revision,
        parentRevisionFingerprint: current.revisionFingerprint,
        status: 'draft',
      })
      const saved = await richTimelineRepository.saveDraftAndSetCurrent({
        timeline: nextDraft,
        expectedCurrent: pointer,
      })
      const finalized = await richTimelineRepository.finalize({
        projectId: saved.projectId,
        timelineId: saved.timelineId,
        revision: saved.revision,
        revisionFingerprint: saved.revisionFingerprint,
        expectedCurrent: {
          timelineId: saved.timelineId,
          revision: saved.revision,
        },
      })
      return asFrozenIdentity(finalized)
    } catch (error) {
      rethrowRichTimelineError(error)
    }
  }

  /** @param {Record<string, any>} privateInput */
  const assertFrozenTimelineIdentity = async (privateInput) => {
    if (!richTimelineRepository) return null
    if (typeof privateInput.timelineId !== 'string') return null
    try {
      const revision = await richTimelineRepository.getRevisionByFingerprint({
        projectId: privateInput.projectId,
        timelineId: privateInput.timelineId,
        revision: privateInput.timelineRevision,
        revisionFingerprint: privateInput.timelineRevisionFingerprint,
      })
      if (!revision) {
        throw coordinatorError('WORKBENCH_RICH_TIMELINE_REVISION_MISSING', 409)
      }
      if (
        revision.status !== 'finalized' ||
        revision.contentFingerprint !== privateInput.timelineContentFingerprint
      ) {
        throw coordinatorError('WORKBENCH_RICH_TIMELINE_FINGERPRINT_MISMATCH', 409)
      }
      return revision
    } catch (error) {
      if (errorCode(error) === 'RICH_TIMELINE_FINGERPRINT_MISMATCH') {
        throw coordinatorError('WORKBENCH_RICH_TIMELINE_FINGERPRINT_MISMATCH', 409)
      }
      rethrowRichTimelineError(error)
    }
  }

  /**
   * A failed Editor may still have durably finalized its canonical revision
   * before a later output request failed. Explicit output retry is safe only
   * when that exact finalize result is present once in the signed repository
   * checkpoint; cancelled and timed-out parents remain ineligible.
   * @param {Record<string, any>} parent
   * @param {Record<string, any>} timeline
   */
  const failedEditorParentFinalizedTimeline = (parent, timeline) => {
    if (parent?.status !== 'failed' || !Array.isArray(parent.checkpoint?.data?.committedExecutions)) return false
    const matches = parent.checkpoint.data.committedExecutions.filter((/** @type {Record<string, any>} */ execution) =>
      execution?.tool === 'finalize_timeline' &&
      execution.result?.status === 'finalized' &&
      execution.result?.revision === timeline.revision &&
      execution.result?.contentFingerprint === timeline.contentFingerprint &&
      execution.result?.revisionFingerprint === timeline.revisionFingerprint)
    return matches.length === 1
  }

  /**
   * Resolve the immutable Editor parent and prove the child timeline descends
   * from that parent's frozen base revision with the same instruction identity.
   * Repository I/O failures intentionally propagate for retry and diagnostics.
   * @param {Record<string, any>} child
   * @param {Record<string, any> | null} [knownTimeline]
   */
  const resolveEditorBoundChildOwnership = async (child, knownTimeline = null) => {
    const privateInput = child?.privateInput
    if (!isRecord(privateInput) || privateInput.editorBound !== true || !richTimelineRepository) {
      return null
    }
    let timeline = knownTimeline
    if (!timeline) {
      timeline = await richTimelineRepository.getRevision({
        projectId: child.projectId,
        timelineId: privateInput.timelineId,
        revision: privateInput.timelineRevision,
      })
    }
    if (
      !timeline ||
      timeline.status !== 'finalized' ||
      timeline.revisionFingerprint !== privateInput.timelineRevisionFingerprint ||
      timeline.contentFingerprint !== privateInput.timelineContentFingerprint
    ) return null

    if (
      privateInput.editorParentJobId === null &&
      privateInput.editorInstructionFingerprint === null
    ) {
      return timeline.source?.kind === 'agent' ? null : { parent: null, timeline }
    }
    if (
      !identifier(privateInput.editorParentJobId) ||
      typeof privateInput.editorInstructionFingerprint !== 'string' ||
      !/^[a-f0-9]{64}$/u.test(privateInput.editorInstructionFingerprint)
    ) return null

    const parent = await jobRepository.get(child.projectId, privateInput.editorParentJobId)
    if (
      !parent ||
      parent.type !== EDITOR_JOB_TYPE ||
      parent.privateInput?.instructionFingerprint !== privateInput.editorInstructionFingerprint
    ) return null
    const parentInput = parent?.privateInput
    const parentInstruction = parentInput?.editorInstruction
    const baseTimeline = parentInstruction?.baseTimeline ?? null
    const canonicalParentInput = isRecord(parentInput) ? clone(parentInput) : null
    if (canonicalParentInput) delete canonicalParentInput.inputFingerprint
    if (
      !parent ||
      parent.projectId !== child.projectId ||
      parent.type !== EDITOR_JOB_TYPE ||
      !isRecord(parentInput) ||
      !isRecord(parentInstruction) ||
      !(baseTimeline === null || isRecord(baseTimeline)) ||
      parentInput.inputFingerprint !== fingerprint(canonicalParentInput) ||
      parentInput.instructionFingerprint !== privateInput.editorInstructionFingerprint ||
      fingerprintCanonical({
        instruction: parentInstruction.instruction,
        mode: parentInstruction.mode,
        baseTimeline,
      }) !== parentInput.instructionFingerprint ||
      (isRecord(baseTimeline) && baseTimeline.timelineId !== privateInput.timelineId)
    ) return null
    const matchingParents = (await jobRepository.listByProject(child.projectId)).filter((
      /** @type {Record<string, any>} */ candidate,
    ) => candidate.type === EDITOR_JOB_TYPE &&
      (!['failed', 'cancelled', 'timed_out'].includes(candidate.status) ||
        failedEditorParentFinalizedTimeline(candidate, timeline)) &&
      candidate.privateInput?.instructionFingerprint === privateInput.editorInstructionFingerprint)
    if (
      matchingParents.length !== 1 ||
      matchingParents[0].jobId !== privateInput.editorParentJobId
    ) return null

    if (
      timeline.source?.kind !== 'agent' ||
      timeline.source?.instructionFingerprint !== parentInput.instructionFingerprint
    ) return null

    let cursor = timeline
    while (isRecord(baseTimeline) && cursor.revision > baseTimeline.revision) {
      if (
        !Number.isSafeInteger(cursor.parentRevision) ||
        typeof cursor.parentRevisionFingerprint !== 'string'
      ) return null
      const parentRevision = await richTimelineRepository.getRevision({
        projectId: child.projectId,
        timelineId: cursor.timelineId,
        revision: cursor.parentRevision,
      })
      if (
        !parentRevision ||
        parentRevision.revisionFingerprint !== cursor.parentRevisionFingerprint
      ) return null
      cursor = parentRevision
    }
    if (
      isRecord(baseTimeline) &&
      (
        cursor.revision !== baseTimeline.revision ||
        cursor.revisionFingerprint !== baseTimeline.revisionFingerprint
      )
    ) return null
    return { parent, timeline }
  }

  /**
   * Prove that a finalized Agent timeline belongs to one immutable Editor job.
   * UI-created output jobs require a succeeded parent whose public result names
   * the exact current revision. An in-flight Agent tool may instead supply its
   * repository execution fence while the parent result is not committed yet.
   * @param {Record<string, any>} timeline
   * @param {Record<string, any> | null} parentFence
   */
  /**
   * @param {Record<string, any>} timeline
   * @param {Record<string, any> | null} parentFence
   * @param {{allowHistoricalRecovery?: boolean}} [options]
   */
  const resolveEditorTimelineOwnership = async (timeline, parentFence, options = {}) => {
    if (timeline.source?.kind !== 'agent') {
      throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
    }
    let ownership = parentFence
      ? {
          jobId: parentFence.jobId,
          instructionFingerprint: parentFence.instructionFingerprint,
        }
      : null
    if (!ownership) {
      const instructionFingerprint = timeline.source?.instructionFingerprint
      if (
        typeof instructionFingerprint !== 'string' ||
        !/^[a-f0-9]{64}$/u.test(instructionFingerprint)
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
      }
      const parents = (await jobRepository.listByProject(timeline.projectId)).filter((
        /** @type {Record<string, any>} */ job,
      ) => job.type === EDITOR_JOB_TYPE &&
        job.privateInput?.instructionFingerprint === instructionFingerprint &&
        ((job.status === 'succeeded' &&
          job.result?.timelineId === timeline.timelineId &&
          job.result?.timelineRevision === timeline.revision &&
          job.result?.timelineRevisionFingerprint === timeline.revisionFingerprint) ||
          failedEditorParentFinalizedTimeline(job, timeline)))
      if (parents.length !== 1) {
        throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
      }
      ownership = {
        jobId: parents[0].jobId,
        instructionFingerprint,
      }
    }
    const validated = await resolveEditorBoundChildOwnership({
      projectId: timeline.projectId,
      privateInput: {
        editorBound: true,
        editorParentJobId: ownership.jobId,
        editorInstructionFingerprint: ownership.instructionFingerprint,
        timelineId: timeline.timelineId,
        timelineRevision: timeline.revision,
        timelineRevisionFingerprint: timeline.revisionFingerprint,
        timelineContentFingerprint: timeline.contentFingerprint,
      },
    }, timeline)
    if (!validated?.parent && options.allowHistoricalRecovery === true) {
      const parent = await jobRepository.get(timeline.projectId, ownership.jobId)
      if (
        parent?.status === 'succeeded' &&
        parent.result?.timelineId === timeline.timelineId &&
        parent.result?.timelineRevision === timeline.revision &&
        parent.result?.timelineRevisionFingerprint === timeline.revisionFingerprint
      ) {
        return {
          editorParentJobId: ownership.jobId,
          editorInstructionFingerprint: ownership.instructionFingerprint,
        }
      }
    }
    if (!validated?.parent) {
      throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
    }
    return {
      editorParentJobId: ownership.jobId,
      editorInstructionFingerprint: ownership.instructionFingerprint,
    }
  }

  /** @param {Record<string, any>} timeline */
  const resolveHistoricalEditorTimelineOwnership = async (timeline) => {
    const parents = (await jobRepository.listByProject(timeline.projectId)).filter((/** @type {Record<string, any>} */ job) =>
      job.type === EDITOR_JOB_TYPE &&
      job.status === 'succeeded' &&
      job.privateInput?.instructionFingerprint === timeline.source?.instructionFingerprint &&
      job.result?.timelineId === timeline.timelineId &&
      job.result?.timelineRevision === timeline.revision &&
      job.result?.timelineRevisionFingerprint === timeline.revisionFingerprint,
    )
    if (parents.length !== 1) throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
    return {
      editorParentJobId: parents[0].jobId,
      editorInstructionFingerprint: timeline.source.instructionFingerprint,
    }
  }

  /** @param {string} projectId @param {string} jobId */
  const keyOf = (projectId, jobId) => `${projectId}\u0000${jobId}`
  /** @param {Record<string, any>} job */
  const enqueue = (job) => {
    if (!started || terminalStatuses.has(job.status)) return
    const key = keyOf(job.projectId, job.jobId)
    if (!active.has(key)) pending.set(key, { projectId: job.projectId, jobId: job.jobId })
    drain()
  }
  /** @param {Record<string, any>} job @param {boolean} [reuseAttempt] */
  const scheduleMaterialResume = (job, reuseAttempt = false) => {
    const key = keyOf(job.projectId, job.jobId)
    if (!started || materialResumeTimers.has(key)) return
    const attempt = reuseAttempt
      ? Math.max(1, materialResumeAttempts.get(key) ?? 1)
      : (materialResumeAttempts.get(key) ?? 0) + 1
    materialResumeAttempts.set(key, attempt)
    const delay = Math.min(30_000, 1_000 * (2 ** Math.min(5, attempt - 1)))
    const timer = setTimeout(() => {
      materialResumeTimers.delete(key)
      if (!started) return
      if (active.has(key)) {
        scheduleMaterialResume(job, true)
        return
      }
      enqueue(job)
    }, Math.max(materialAnalysisResumeDelayMs, delay))
    materialResumeTimers.set(key, timer)
  }

  /** @param {Record<string, any>} job */
  const finishCancellation = async (job) => {
    const attempt = job.attempts.at(-1)
    if (!attempt || !['queued', 'running'].includes(attempt.status)) return
    await rollbackReferenceFromJob(job)
    if (job.type === 'material_analysis') {
      await settleMaterialProgress(job, 'cancelled')
    }
    await jobRepository.finish({
      projectId: job.projectId,
      jobId: job.jobId,
      attemptId: attempt.attemptId,
      generation: attempt.generation,
      leaseToken: attempt.lease?.token ?? null,
      status: 'cancelled',
      finishedAt: nowIso(),
      result: null,
      error: null,
    })
  }

  /** @param {Record<string, any>} timeline */
  const editorTimelineSelectionsFrom = (timeline) => {
    const primary = timeline.tracks.find((/** @type {Record<string, any>} */ track) =>
      track.kind === 'video' && track.role === 'primary')
    if (!primary || !Array.isArray(primary.segments) || primary.segments.length === 0) {
      throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_INVALID', 409)
    }
    return primary.segments.map((/** @type {Record<string, any>} */ segment) => ({
      candidateId: segment.audit.candidateId,
      startUs: segment.sourceRange.startUs,
      durationUs: segment.sourceRange.durationUs,
      assetId: segment.asset.assetId,
      sceneId: segment.asset.sceneId,
    }))
  }

  /** @param {Record<string, any>} project @param {Record<string, any>} timeline */
  const timelineUsesOnlyLibraryReferences = (project, timeline) => {
    const localAuthorizationId = project?.materials?.authorizationId
    const segments = (timeline?.tracks ?? [])
      .filter((/** @type {Record<string, any>} */ track) => track.kind === 'video' && track.role === 'primary')
      .flatMap((/** @type {Record<string, any>} */ track) => Array.isArray(track.segments) ? track.segments : [])
    return segments.length > 0 && segments.every((/** @type {Record<string, any>} */ segment) => {
      const authorizationId = segment.asset?.authorizationId
      return identifier(authorizationId) && authorizationId !== localAuthorizationId
    })
  }

  /**
   * Resolve each editor selection at execution time. Library references never
   * borrow the target project's authorization: the resolver revalidates the
   * source authorization and manifest for every preview/export attempt.
   * @param {{projectId: string, authorizationId: string | null}} job
   * @param {Array<{candidateId: string, start: number, end: number, assetId?: string, sceneId?: string}>} selections
   * @param {AbortSignal} signal
   */
  const resolveEditorTimelineSources = async (job, selections, signal) => {
    const clips = new Array(selections.length)
    const targetProject = await projectRepository.get(job.projectId)
    const localAuthorizationId = targetProject?.materials?.authorizationId
    /** @type {Array<{index: number, previewSelection: {candidateId: string, start: number, end: number}}>} */
    const localSelections = []
    /** @type {Array<{index: number, selection: {candidateId: string, start: number, end: number, assetId?: string, sceneId?: string}, previewSelection: {candidateId: string, start: number, end: number}}>} */
    const externalSelections = []
    /**
     * @param {Record<string, any> | null | undefined} source
     * @param {{candidateId: string, start: number, end: number}} expected
     */
    const matchesSelection = (source, expected) =>
      source?.candidateId === expected.candidateId &&
      source?.start === expected.start &&
      source?.end === expected.end
    for (const [index, selection] of selections.entries()) {
      const previewSelection = {
        candidateId: selection.candidateId,
        start: selection.start,
        end: selection.end,
      }
      const localAsset = targetProject?.materials?.assets?.find((/** @type {Record<string, any>} */ asset) =>
        asset?.id === selection.assetId && Array.isArray(asset.scenes) && asset.scenes.some(
          (/** @type {Record<string, any>} */ scene) => scene?.id === selection.sceneId,
        ))
      if (localAsset && identifier(localAuthorizationId)) {
        localSelections.push({ index, previewSelection })
      } else {
        externalSelections.push({ index, selection, previewSelection })
      }
    }
    // Revalidate a project's local manifest once for the whole timeline. Calling
    // the provider once per shot re-hashed the same large video set repeatedly,
    // leaving real preview jobs at 0% for many minutes.
    if (localSelections.length > 0) {
      const resolvedLocal = await materialAnalysisProvider.resolvePreviewSources({
        projectId: job.projectId,
        authorizationId: localAuthorizationId,
        selections: localSelections.map((entry) => entry.previewSelection),
        signal,
      })
      if (
        !Array.isArray(resolvedLocal) ||
        resolvedLocal.length !== localSelections.length ||
        resolvedLocal.some((source, index) =>
          !matchesSelection(source, localSelections[index].previewSelection))
      ) {
        throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      }
      for (const [index, entry] of localSelections.entries()) {
        clips[entry.index] = resolvedLocal[index]
      }
    }
    for (const { index, selection, previewSelection } of externalSelections) {
      let binding = null
      if (typeof resolveMaterialLibrarySceneBinding === 'function') {
        binding = await resolveMaterialLibrarySceneBinding({
          projectId: job.projectId,
          sceneId: selection.sceneId ?? selection.candidateId,
        })
        if (!identifier(binding?.projectId) || !identifier(binding?.authorizationId)) {
          throw coordinatorError('WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE', 409)
        }
      }
      const sourceProjectId = binding?.projectId ?? job.projectId
      const authorizationId = binding?.authorizationId ?? job.authorizationId
      if (!identifier(sourceProjectId) || !identifier(authorizationId)) {
        throw coordinatorError('WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE', 409)
      }
      const resolved = await materialAnalysisProvider.resolvePreviewSources({
        projectId: sourceProjectId,
        authorizationId,
        selections: [previewSelection],
        signal,
      })
      if (
        !Array.isArray(resolved) ||
        resolved.length !== 1 ||
        !matchesSelection(resolved[0], previewSelection)
      ) {
        throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      }
      clips[index] = resolved[0]
    }
    return clips
  }

  /** @param {Record<string, any>} timeline */
  const editorTimelineVoiceoverSegments = (timeline) => {
    const captionTrack = timeline.tracks.find((/** @type {Record<string, any>} */ track) =>
      track.kind === 'caption')
    const voiceoverTrack = timeline.tracks.find((/** @type {Record<string, any>} */ track) =>
      track.kind === 'audio' && track.role === 'voiceover')
    if (Array.isArray(captionTrack?.segments) && captionTrack.segments.length > 0) {
      return captionTrack.segments.map((
        /** @type {Record<string, any>} */ segment,
        /** @type {number} */ index,
      ) => ({
        sentenceId: `editor-caption-${index + 1}`,
        text: typeof segment.text === 'string' && segment.text.trim()
          ? segment.text.trim().slice(0, 500)
          : `镜头 ${index + 1}`,
      }))
    }
    if (Array.isArray(voiceoverTrack?.segments) && voiceoverTrack.segments.length > 0) {
      return voiceoverTrack.segments.map((
        /** @type {Record<string, any>} */ segment,
        /** @type {number} */ index,
      ) => ({
        sentenceId: `editor-voice-${index + 1}`,
        text: `镜头 ${index + 1}`,
      }))
    }
    const primary = timeline.tracks.find((/** @type {Record<string, any>} */ track) =>
      track.kind === 'video' && track.role === 'primary')
    return (primary?.segments ?? []).map((
      /** @type {Record<string, any>} */ _segment,
      /** @type {number} */ index,
    ) => ({
      sentenceId: `editor-${index + 1}`,
      text: `镜头 ${index + 1}`,
    }))
  }

  /**
   * @param {Record<string, any>} timeline
   * @param {{projectId: string, planId: string, createdAt: string}} meta
   */
  const editPlanFromEditorTimeline = (timeline, meta) => {
    const selections = editorTimelineSelectionsFrom(timeline)
    const voiceoverSegments = editorTimelineVoiceoverSegments(timeline)
    const items = selections.map((
      /** @type {Record<string, any>} */ selection,
      /** @type {number} */ index,
    ) => {
      const start = selection.startUs / 1_000_000
      const end = (selection.startUs + selection.durationUs) / 1_000_000
      const voiceoverText = voiceoverSegments[index]?.text ?? `镜头 ${index + 1}`
      return {
        sentence_id: `editor-${index + 1}`,
        order: index + 1,
        voiceover_text: voiceoverText,
        status: 'selected',
        selected_candidate_id: selection.candidateId,
        candidates: [{
          candidate_id: selection.candidateId,
          asset_id: selection.assetId,
          // EditPlan forbids reusing the same asset+scene across selected items.
          scene_id: `${selection.sceneId}-slot${index + 1}`,
          source: 'search',
          start,
          end,
          summary: `editor segment ${index + 1}`,
          tags: [],
          search_score: 1,
          director_score: 1,
          reason: 'finalized RichTimeline segment',
        }],
      }
    })
    const plan = {
      schema_version: 1,
      plan_id: meta.planId,
      project_id: meta.projectId,
      created_at: meta.createdAt,
      items,
    }
    if (!isEditPlan(plan)) {
      throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_INVALID', 409)
    }
    return plan
  }

  /**
   * @param {Record<string, any>} project
   * @param {Record<string, any>} privateInput
   */
  const editorBoundPrivateInputMatchesProject = (project, privateInput) => {
    const libraryReferenceOnly = privateInput.libraryReferenceOnly === true
    if (!safeBrief(project.brief) ||
      (!libraryReferenceOnly && (!isRecord(project.storyboard) || !identifier(project.storyboard.id)))) {
      return false
    }
    const agentOwnership = identifier(privateInput.editorParentJobId) &&
      typeof privateInput.editorInstructionFingerprint === 'string' &&
      /^[a-f0-9]{64}$/u.test(privateInput.editorInstructionFingerprint)
    const directOwnership = privateInput.editorParentJobId === null &&
      privateInput.editorInstructionFingerprint === null
    if (
      privateInput.editorBound !== true ||
      (!agentOwnership && !directOwnership) ||
      !Array.isArray(privateInput.editorTimelineSelections) ||
      privateInput.editorTimelineSelections.length === 0 ||
      typeof privateInput.timelineId !== 'string' ||
      !Number.isSafeInteger(privateInput.timelineRevision) ||
      typeof privateInput.timelineRevisionFingerprint !== 'string' ||
      typeof privateInput.timelineContentFingerprint !== 'string'
    ) {
      return false
    }
    /** @type {Record<string, any>} */
    let canonical
    if (privateInput.type === 'jianying_draft_export') {
      if (
        typeof privateInput.editPlanFingerprint !== 'string' ||
        !/^[a-f0-9]{64}$/u.test(privateInput.editPlanFingerprint)
      ) {
        return false
      }
      canonical = {
        projectId: project.id,
        type: privateInput.type,
        ...optionalAuthorizationInput(project.materials.authorizationId),
        brief: clone(project.brief),
        briefFingerprint: fingerprint(project.brief),
        planId: libraryReferenceOnly ? privateInput.planId : project.storyboard.id,
        storyboardFingerprint: libraryReferenceOnly ? null : fingerprint(project.storyboard),
        templateBindingFingerprint: fingerprint(project.templateBinding ?? null),
        templateBinding: clone(project.templateBinding ?? null),
        templateGuidance: clone(privateInput.templateGuidance ?? null),
        editorBound: true,
        ...(libraryReferenceOnly ? { libraryReferenceOnly: true } : {}),
        editorParentJobId: privateInput.editorParentJobId,
        editorInstructionFingerprint: privateInput.editorInstructionFingerprint,
        editorTimelineSelections: clone(privateInput.editorTimelineSelections),
        voiceoverSegments: clone(privateInput.voiceoverSegments ?? []),
        selections: clone(privateInput.selections),
        editPlanFingerprint: privateInput.editPlanFingerprint,
        timelineId: privateInput.timelineId,
        timelineRevision: privateInput.timelineRevision,
        timelineRevisionFingerprint: privateInput.timelineRevisionFingerprint,
        timelineContentFingerprint: privateInput.timelineContentFingerprint,
      }
    } else {
      canonical = {
        projectId: project.id,
        type: privateInput.type,
        ...optionalAuthorizationInput(project.materials.authorizationId),
        brief: clone(project.brief),
        briefFingerprint: fingerprint(project.brief),
        planId: libraryReferenceOnly ? privateInput.planId : project.storyboard.id,
        storyboardFingerprint: libraryReferenceOnly ? null : fingerprint(project.storyboard),
        templateGuidance: clone(createTemplateGuidance(project.templateBinding ?? null)),
        templateBindingFingerprint: fingerprint(project.templateBinding ?? null),
        editorBound: true,
        ...(libraryReferenceOnly ? { libraryReferenceOnly: true } : {}),
        editorParentJobId: privateInput.editorParentJobId,
        editorInstructionFingerprint: privateInput.editorInstructionFingerprint,
        editorTimelineSelections: clone(privateInput.editorTimelineSelections),
        voiceoverSegments: clone(privateInput.voiceoverSegments ?? []),
        selections: clone(privateInput.selections),
        timelineId: privateInput.timelineId,
        timelineRevision: privateInput.timelineRevision,
        timelineRevisionFingerprint: privateInput.timelineRevisionFingerprint,
        timelineContentFingerprint: privateInput.timelineContentFingerprint,
      }
    }
    const persistedCanonical = clone(privateInput)
    delete persistedCanonical.inputFingerprint
    return JSON.stringify(persistedCanonical) === JSON.stringify(canonical) &&
      privateInput.inputFingerprint === fingerprint(canonical)
  }

  /** @param {Record<string, any>} project @param {Record<string, any>} privateInput */
  const inputStillCurrent = (project, privateInput) => {
    const projectAuthorizationId = identifier(project.materials.authorizationId)
      ? project.materials.authorizationId
      : undefined
    const inputAuthorizationId = identifier(privateInput.authorizationId)
      ? privateInput.authorizationId
      : undefined
    if (
      !validProjectSnapshot(project) ||
      project.id !== privateInput.projectId ||
      projectAuthorizationId !== inputAuthorizationId
    ) return false
    if (privateInput.type === 'storyboard_generation') {
      return privateTemplateInputMatchesProject(project, privateInput)
    }
    if (privateInput.type === 'preview_generation') {
      if (privateInput.editorBound === true) {
        return editorBoundPrivateInputMatchesProject(project, privateInput)
      }
      return privateTemplateInputMatchesProject(project, privateInput)
    }
    if (privateInput.type === 'reference_template_generation') {
      if (privateInput.sourceKind === 'authorization') {
        return identifier(privateInput.referenceAuthorizationId) &&
          safeBrief(project.brief) &&
          fingerprint(project.brief) === privateInput.briefFingerprint
      }
      const currentFingerprint = materialAssetsFingerprint(project)
      return currentFingerprint !== null &&
        currentFingerprint === privateInput.assetsFingerprint &&
        project.materials.assets.some(
          (/** @type {Record<string, any>} */ asset) => asset?.id === privateInput.assetId,
        )
    }
    if (privateInput.type === 'jianying_draft_export') {
      if (privateInput.editorBound === true) {
        return editorBoundPrivateInputMatchesProject(project, privateInput)
      }
      return privateTemplateInputMatchesProject(project, privateInput)
    }
    return true
  }

  /**
   * Publishes a project transition under the repository file lock.
   * @param {Record<string, any>} current
   * @param {Record<string, any>} next
   */
  const saveProjectIfCurrent = async (current, next) => {
    const saved = await projectRepository.saveIfCurrent(next, current)
    if (!saved) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    return saved
  }

  /** @param {Record<string, any>} job */
  async function rollbackReferenceFromJob(job) {
    if (
      job?.type !== 'reference_template_generation' ||
      !hasMethods(referenceTemplateRepository, ['rollbackByOwner'])
    ) return false
    return /** @type {Record<string, Function>} */ (referenceTemplateRepository).rollbackByOwner({
      projectId: job.projectId,
      jobId: job.jobId,
    })
  }

  /** @param {Record<string, any>} project */
  const previewSelections = (project) => {
    if (
      !isRecord(project.storyboard) ||
      !identifier(project.storyboard.id) ||
      !Array.isArray(project.storyboard.sentences) ||
      project.storyboard.sentences.length === 0
    ) return null
    const selections = []
    for (const sentence of project.storyboard.sentences) {
      if (
        !isRecord(sentence) ||
        !identifier(sentence.selectedCandidateId) ||
        !Array.isArray(sentence.candidates)
      ) return null
      const selected = sentence.candidates.find(
        (candidate) => candidate?.id === sentence.selectedCandidateId,
      )
      if (
        !selected ||
        !identifier(sentence.id) ||
        !identifier(selected.id)
      ) return null
      selections.push({
        sentenceId: sentence.id,
        candidateId: selected.id,
      })
    }
    return selections
  }

  /**
   * Rebuilds every project-derived private field instead of trusting either the
   * persisted guidance or its self-declared fingerprint.
   * @param {Record<string, any>} project
   * @param {Record<string, any>} privateInput
   */
  const privateTemplateInputMatchesProject = (project, privateInput) => {
    if (!safeBrief(project.brief)) return false
    let bindingGuidance
    try {
      bindingGuidance = createTemplateGuidance(project.templateBinding ?? null)
    } catch {
      return false
    }
    /** @type {Record<string, any> | null} */
    let canonical = null
    if (privateInput.type === 'storyboard_generation') {
      canonical = {
        projectId: project.id,
        type: privateInput.type,
        ...optionalAuthorizationInput(project.materials.authorizationId),
        materialsContentFingerprint: materialContentFingerprint(project.materials),
        brief: clone(project.brief),
        briefFingerprint: fingerprint(project.brief),
        templateGuidance: clone(bindingGuidance),
        templateBindingFingerprint: fingerprint(project.templateBinding ?? null),
        creativeAutoOutputs: privateInput.creativeAutoOutputs === true,
      }
    } else {
      const selections = previewSelections(project)
      if (!isRecord(project.storyboard) || !selections) return false
      const templateGuidance = bindingGuidance
        ? adaptTemplateGuidanceToCount(bindingGuidance, selections.length)
        : null
      canonical = {
        projectId: project.id,
        type: privateInput.type,
        ...optionalAuthorizationInput(project.materials.authorizationId),
        brief: clone(project.brief),
        briefFingerprint: fingerprint(project.brief),
        planId: project.storyboard.id,
        storyboardFingerprint: fingerprint(project.storyboard),
        ...(privateInput.type === 'jianying_draft_export'
          ? {
              templateBindingFingerprint: fingerprint(project.templateBinding ?? null),
              templateBinding: clone(project.templateBinding ?? null),
              templateGuidance: clone(templateGuidance),
              editPlanFingerprint: privateInput.editPlanFingerprint,
            }
          : {
              templateGuidance: clone(templateGuidance),
              templateBindingFingerprint: fingerprint(project.templateBinding ?? null),
            }),
        selections,
        ...(typeof privateInput.timelineId === 'string'
          ? {
              timelineId: privateInput.timelineId,
              timelineRevision: privateInput.timelineRevision,
              timelineRevisionFingerprint: privateInput.timelineRevisionFingerprint,
              timelineContentFingerprint: privateInput.timelineContentFingerprint,
            }
          : {}),
      }
      if (
        privateInput.type === 'jianying_draft_export' &&
        (
          typeof privateInput.editPlanFingerprint !== 'string' ||
          !/^[a-f0-9]{64}$/u.test(privateInput.editPlanFingerprint)
        )
      ) return false
    }
    const persistedCanonical = clone(privateInput)
    delete persistedCanonical.inputFingerprint
    return JSON.stringify(persistedCanonical) === JSON.stringify(canonical) &&
      privateInput.inputFingerprint === fingerprint(canonical)
  }

  /** @param {Record<string, any>} privateInput */
  const editorTimelineStillCurrent = async (privateInput) => {
    if (privateInput.editorBound !== true) return true
    if (!richTimelineRepository) return false
    const pointer = await richTimelineRepository.getCurrent({
      projectId: privateInput.projectId,
    })
    if (
      !pointer ||
      pointer.timelineId !== privateInput.timelineId ||
      pointer.revision !== privateInput.timelineRevision
    ) return false
    const timeline = await richTimelineRepository.getRevision(pointer)
    return Boolean(
      timeline &&
      timeline.status === 'finalized' &&
      timeline.revisionFingerprint === privateInput.timelineRevisionFingerprint &&
      timeline.contentFingerprint === privateInput.timelineContentFingerprint,
    )
  }

  /**
   * No-fence idempotent replay must bind to the same public timeline identity.
   * @param {Record<string, any> | null | undefined} existing
   * @param {Record<string, any>} input
   */
  const editorBoundJobMatchesRequest = (existing, input) => {
    const privateInput = existing?.privateInput
    return isRecord(privateInput)
      && privateInput.editorBound === true
      && privateInput.timelineId === input.timelineId
      && privateInput.timelineRevision === input.revision
      && privateInput.timelineRevisionFingerprint === input.revisionFingerprint
  }

  /**
   * Early no-fence replay must still enforce create-path currency checks.
   * @param {Record<string, any>} existing
   * @param {Record<string, any>} input
   */
  const assertEditorBoundReplayStillValid = async (existing, input) => {
    if (!editorBoundJobMatchesRequest(existing, input)) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
    if (!richTimelineRepository) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING', 503)
    }
    const privateInput = existing.privateInput
    const current = await projectRepository.get(input.projectId)
    const libraryReferenceOnly = Boolean(
      current &&
      !current.storyboard &&
      privateInput.libraryReferenceOnly === true &&
      privateInput.storyboardFingerprint === null,
    )
    if (
      !validProjectSnapshot(current) ||
      !safeBrief(current.brief) ||
      (!isRecord(current.storyboard) && !libraryReferenceOnly) ||
      (!libraryReferenceOnly && !identifier(current.storyboard.id))
    ) {
      throw coordinatorError(
        current ? 'WORKBENCH_JOB_INPUT_INVALID' : 'WORKBENCH_PROJECT_NOT_FOUND',
        current ? 409 : 404,
      )
    }
    if (
      fingerprint(current.brief) !== privateInput.briefFingerprint ||
      (libraryReferenceOnly
        ? privateInput.libraryReferenceOnly !== true || privateInput.storyboardFingerprint !== null
        : fingerprint(current.storyboard) !== privateInput.storyboardFingerprint)
    ) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
    let pointer = await richTimelineRepository.getCurrent({ projectId: input.projectId })
    let timeline = pointer
      ? await richTimelineRepository.getRevision(pointer)
      : null
    const requestedTimeline = await richTimelineRepository.getRevision({
      projectId: input.projectId,
      timelineId: input.timelineId,
      revision: input.revision,
    })
    const requestedIsCurrent = Boolean(
      timeline &&
      timeline.timelineId === input.timelineId &&
      timeline.revision === input.revision &&
      timeline.revisionFingerprint === input.revisionFingerprint,
    )
    if (!requestedIsCurrent) {
      throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
    }
    if (
      !timeline ||
      timeline.status !== 'finalized' ||
      timeline.timelineId !== input.timelineId ||
      timeline.revision !== input.revision ||
      timeline.revisionFingerprint !== input.revisionFingerprint
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
    }
    if (timeline.contentFingerprint !== privateInput.timelineContentFingerprint) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
    if (libraryReferenceOnly !== timelineUsesOnlyLibraryReferences(current, timeline)) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
    if (!await resolveEditorBoundChildOwnership(existing, timeline)) {
      throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
    }
  }

  /**
   * Legacy export creation freezes the canonical timeline before the job is
   * stored. A network retry must replay that job without treating its own
   * frozen timeline as an Editor takeover, while still rejecting changed
   * project inputs or a superseded timeline.
   * @param {Record<string, any>} existing
   * @param {Record<string, any>} input
   */
  const assertLegacyJianyingReplayStillValid = async (existing, input) => {
    const privateInput = existing?.privateInput
    const current = await projectRepository.get(input.projectId)
    if (
      !isRecord(privateInput) ||
      !validProjectSnapshot(current) ||
      !safeBrief(current.brief) ||
      !isRecord(current.storyboard) ||
      !identifier(current.storyboard.id) ||
      current.preview?.status !== 'ready'
    ) {
      throw coordinatorError(
        current ? 'WORKBENCH_JOB_IDEMPOTENCY_CONFLICT' : 'WORKBENCH_PROJECT_NOT_FOUND',
        current ? 409 : 404,
      )
    }
    const plan = await editPlanRepository.getFinalized({
      projectId: input.projectId,
      planId: current.storyboard.id,
    })
    const selections = previewSelections(current)
    if (
      plan?.status !== 'finalized' ||
      !isEditPlan(plan.final) ||
      !selections ||
      privateInput.authorizationId !== current.materials.authorizationId ||
      privateInput.planId !== current.storyboard.id ||
      privateInput.briefFingerprint !== fingerprint(current.brief) ||
      privateInput.storyboardFingerprint !== fingerprint(current.storyboard) ||
      privateInput.templateBindingFingerprint !== fingerprint(current.templateBinding ?? null) ||
      privateInput.editPlanFingerprint !== fingerprint(plan.final) ||
      fingerprint(privateInput.selections) !== fingerprint(selections)
    ) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
    if (!richTimelineRepository) {
      if (typeof privateInput.timelineId === 'string') {
        throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
      }
      return
    }
    const pointer = await richTimelineRepository.getCurrent({ projectId: input.projectId })
    if (
      typeof privateInput.timelineId !== 'string' ||
      pointer?.timelineId !== privateInput.timelineId ||
      pointer?.revision !== privateInput.timelineRevision
    ) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
    const timeline = await assertFrozenTimelineIdentity(privateInput)
    if (!timeline || timeline.revisionFingerprint !== privateInput.timelineRevisionFingerprint) {
      throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
    }
  }

  /**
   * Applies the public storyboard choice to the private finalized plan without
   * mutating the persisted Director result.
   * @param {Record<string, any>} plan
   * @param {unknown} selections
   */
  const applyPrivateSelections = (plan, selections) => {
    if (
      !isEditPlan(plan) ||
      !Array.isArray(selections) ||
      plan.items.length !== selections.length
    ) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
    }
    const sentenceIds = new Set()
    for (const selection of selections) {
      if (
        !identifier(selection?.sentenceId) ||
        !identifier(selection?.candidateId) ||
        sentenceIds.has(selection.sentenceId)
      ) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
      }
      sentenceIds.add(selection.sentenceId)
    }
    if (
      plan.items.some(
        (/** @type {Record<string, any>} */ item) =>
          !sentenceIds.has(item.sentence_id),
      )
    ) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
    }
    const selectedPlan = clone(plan)
    for (const selection of selections) {
      const item = selectedPlan.items.find(
        (/** @type {Record<string, any>} */ entry) =>
          entry.sentence_id === selection?.sentenceId,
      )
      const candidateIndex = item?.candidates.findIndex(
        (/** @type {Record<string, any>} */ entry) =>
          entry.candidate_id === selection?.candidateId,
      )
      if (!item || candidateIndex === undefined || candidateIndex < 0) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
      }
      const [candidate] = item.candidates.splice(candidateIndex, 1)
      item.candidates.unshift(candidate)
      item.selected_candidate_id = candidate.candidate_id
      item.status = 'selected'
    }
    if (!isEditPlan(selectedPlan)) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
    }
    return selectedPlan
  }

  /** @param {Record<string, any>} privateInput */
  const resolvePrivateSelections = async (privateInput) => {
    const plan = await editPlanRepository.getFinalized({
      projectId: privateInput.projectId,
      planId: privateInput.planId,
    })
    if (
      plan?.status !== 'finalized' ||
      !isEditPlan(plan.final) ||
      plan.final.project_id !== privateInput.projectId ||
      plan.final.plan_id !== privateInput.planId
    ) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
    }
    const selectedPlan = applyPrivateSelections(plan.final, privateInput.selections)
    const resolvedSelections = privateInput.selections.map((/** @type {Record<string, any>} */ selection) => {
      const item = selectedPlan.items.find(
        (/** @type {Record<string, any>} */ entry) =>
          entry.sentence_id === selection.sentenceId,
      )
      const candidate = item?.candidates.find(
        (/** @type {Record<string, any>} */ entry) =>
          entry.candidate_id === selection.candidateId,
      )
      if (!candidate) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
      }
      return {
        candidateId: candidate.candidate_id,
        start: candidate.start,
        end: candidate.end,
      }
    })
    return {
      selections: resolvedSelections,
      voiceoverSegments: selectedPlan.items.map((/** @type {Record<string, any>} */ item) => ({
        sentenceId: item.sentence_id,
        text: item.voiceover_text,
      })),
    }
  }

  /** @param {string} projectId @param {string} resourceId */
  const rollbackPreview = async (projectId, resourceId) => {
    const deleted = await previewProvider.deleteResource({ projectId, resourceId }).catch(() => false)
    if (deleted !== true) {
      throw coordinatorError('WORKBENCH_PREVIEW_CLEANUP_FAILED', 500)
    }
    for (let attempt = 0; attempt < 5; attempt += 1) {
    const current = await projectRepository.get(projectId)
    if (current?.preview?.resourceId !== resourceId) return
      const saved = await projectRepository.saveIfCurrent({
      ...clone(current),
      preview: emptyPreview(),
      delivery: emptyDelivery(),
      currentStage: current.storyboard ? 'storyboard' : 'brief',
      updatedAt: nowIso(),
      }, current)
      if (saved) return
    }
    throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
  }
  /** @param {string} projectId @param {string} jobId */
  const rollbackJianyingDelivery = async (projectId, jobId) => {
    for (let attempt = 0; attempt < 5; attempt += 1) {
    const current = await projectRepository.get(projectId)
    if (current?.delivery?.exportJob?.id !== jobId) return
      const saved = await projectRepository.saveIfCurrent({
      ...clone(current),
      delivery: {
        ...clone(current.delivery),
        exportJob: null,
      },
      currentStage: current.preview?.status === 'ready' ? 'preview' : 'storyboard',
      updatedAt: nowIso(),
      }, current)
      if (saved) return
    }
    throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
  }
  /** @param {Record<string, any> | null} project */
  const deleteProjectMedia = async (project) => {
    if (!project) return
    const resourceIds = new Set([
      project?.preview?.resourceId,
      project?.delivery?.finalVideo?.resourceId,
    ].filter(identifier))
    for (const resourceId of resourceIds) {
      const deleted = await previewProvider.deleteResource({
        projectId: project.id,
        resourceId,
      }).catch(() => false)
      if (deleted !== true) {
        throw coordinatorError('WORKBENCH_PREVIEW_CLEANUP_FAILED', 500)
      }
    }
  }

  /**
   * Merges material-worker state into the latest persisted project without
   * overwriting concurrent template or workbench changes.
   * @param {Record<string, any>} claimed
   * @param {(current: Record<string, any>) => Promise<Record<string, any> | null> | Record<string, any> | null} createNext
   */
  const saveMaterialUpdate = async (claimed, createNext) => {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const current = await projectRepository.get(claimed.projectId)
      if (!inputStillCurrent(current, claimed.privateInput)) {
        throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
      }
      const next = await createNext(current)
      if (!next) return null
      const saved = await projectRepository.saveIfCurrent(next, current)
      if (saved) return saved
    }
    throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
  }

  /**
   * Writer ownership is immutable after cleanup/commit, while a Workbench job
   * deliberately keeps its public identity across retries. Give every attempt
   * a private owner identity so a rolled-back attempt cannot block the next
   * exactly-one Writer claim.
   *
   * @param {Record<string, any>} job
   */
  const jianyingWriterAttemptId = (job) => {
    const generation = job?.attempts?.at(-1)?.generation
    if (!identifier(job?.jobId) || !Number.isSafeInteger(generation) || generation < 1) {
      throw coordinatorError('WORKBENCH_JOB_STATE_INVALID', 500)
    }
    return generation === 1 ? job.jobId : `${job.jobId}-retry-${generation}`
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   * @param {{analyzed: number, total: number, label?: string | null, overallPercent?: number, assets?: unknown[], completedMaterials?: unknown}} progressUpdate
   */
  const publishMaterialProgress = async (claimed, checkpoint, progressUpdate) => {
    const total = Number.isSafeInteger(progressUpdate.total) && progressUpdate.total > 0
      ? progressUpdate.total
      : 0
    const analyzed = Math.max(
      0,
      Math.min(total, Number.isSafeInteger(progressUpdate.analyzed) ? progressUpdate.analyzed : 0),
    )
    const label = typeof progressUpdate.label === 'string' &&
      progressUpdate.label.trim() &&
      progressUpdate.label.length <= 160 &&
      !progressUpdate.label.includes('\\') &&
      !progressUpdate.label.includes('/')
      ? progressUpdate.label.trim()
      : null
    const rawAssets = Array.isArray(progressUpdate.assets) && progressUpdate.assets.length === total
      ? progressUpdate.assets
      : []
    const progressAssets = rawAssets.every((entry) => {
      const asset = /** @type {Record<string, any>} */ (entry)
      return isRecord(entry) &&
        opaqueIdentifier(asset.id) &&
        publicText(asset.label, 160) &&
        ['queued', 'analyzing', 'ready', 'failed'].includes(asset.status) &&
        Number.isSafeInteger(asset.progressPercent) &&
        asset.progressPercent >= 0 &&
        asset.progressPercent <= 100 &&
        ['queued', 'metadata', 'scenes', 'asr', 'visual', 'indexing', 'complete', 'failed'].includes(asset.stage) &&
        publicText(asset.detail, 160)
    })
      ? rawAssets.map((entry) => {
          const asset = /** @type {Record<string, any>} */ (entry)
          return {
            id: asset.id,
            label: asset.label,
            status: asset.status,
            progressPercent: asset.progressPercent,
            stage: asset.stage,
            detail: asset.detail,
          }
        })
      : []
    const incomingOverall = Number(progressUpdate.overallPercent)
    const measuredOverall = Number.isSafeInteger(incomingOverall) &&
      incomingOverall >= 0 &&
      incomingOverall <= 100 &&
      progressAssets.length === total
      ? incomingOverall
      : total > 0
        ? Math.round((analyzed / total) * 100)
        : 0
    const detail = total > 0
      ? `正在分析 ${total} 个素材 · ${analyzed} / ${total} 已完成${label ? ` · ${label}` : ''}`
      : '正在扫描素材文件夹'
    const progressPercent = total > 0
      ? Math.min(89, Math.max(5, Math.round(5 + measuredOverall * 0.84)))
      : 5
    const completedCandidate = isRecord(progressUpdate.completedMaterials) &&
      progressUpdate.completedMaterials.authorizationId === claimed.privateInput.authorizationId &&
      progressUpdate.completedMaterials.total === total &&
      progressUpdate.completedMaterials.analyzed === analyzed &&
      progressUpdate.completedMaterials.queued === Math.max(0, total - analyzed) &&
      progressUpdate.completedMaterials.failed === 0 &&
      progressUpdate.completedMaterials.analysisStatus === 'analyzing' &&
      Array.isArray(progressUpdate.completedMaterials.assets) &&
      progressUpdate.completedMaterials.assets.length === analyzed &&
      analyzed > 0
      ? projectAnalyzedMaterialsForPublic({
        ...progressUpdate.completedMaterials,
        total: analyzed,
        analyzed,
        queued: 0,
        analysisStatus: 'ready',
      }, claimed.privateInput.authorizationId)
      : null
    /** @type {Record<string, any> | null} */
    const completedMaterials = completedCandidate
      ? {
          ...completedCandidate,
          total,
          analyzed,
          queued: Math.max(0, total - analyzed),
          analysisStatus: 'analyzing',
        }
      : null
    const selectedAssetAnalysis = Boolean(claimed.privateInput.assetId)
    await saveMaterialUpdate(claimed, (current) => ({
        ...clone(current),
        materials: {
          ...clone(current.materials),
          ...(selectedAssetAnalysis
            ? {}
            : {
                total,
                analyzed,
                queued: Math.max(0, total - analyzed),
                failed: 0,
              }),
          analysisStatus: 'analyzing',
          // Detailed per-asset progress identifies a new manifest, so stale
          // cards must not be browseable. Aggregate-only progress cannot make
          // that claim and preserves the last safe cards for cancellation and
          // timeout recovery.
          assets: selectedAssetAnalysis
            ? Array.isArray(current.materials?.assets) ? clone(current.materials.assets) : []
            : completedMaterials
            ? clone(completedMaterials.assets)
            : progressAssets.length === total && total > 0
            ? analyzed === 0
              ? []
              : Array.isArray(current.materials?.assets) ? clone(current.materials.assets) : []
            : Array.isArray(current.materials?.assets) ? clone(current.materials.assets) : [],
          ...(completedMaterials?.analyzerVersion
            ? { analyzerVersion: completedMaterials.analyzerVersion }
            : {}),
          ...(completedMaterials?.lastScanAt
            ? { lastScanAt: completedMaterials.lastScanAt }
            : {}),
          analysisProgress: progressAssets.length === total && total > 0
            ? { overallPercent: measuredOverall, assets: progressAssets }
            : null,
        },
        updatedAt: nowIso(),
      }))
    await checkpoint('material_analyzing', progressPercent, {
      analyzed,
      total,
      detail,
    })
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {'cancelled' | 'failed' | 'timed_out'} status
   */
  const settleMaterialProgress = async (claimed, status) => {
    const cancelled = status === 'cancelled'
    await saveMaterialUpdate(claimed, (current) => {
      if (current.materials.analysisStatus !== 'analyzing') return null
      if (claimed.privateInput.assetId) {
        return {
          ...clone(current),
          materials: {
            ...clone(current.materials),
            analysisStatus: current.materials.analyzed === current.materials.total && current.materials.failed === 0
              ? 'ready'
              : cancelled ? 'queued' : 'failed',
            analysisProgress: null,
          },
          updatedAt: nowIso(),
        }
      }
      return {
        ...clone(current),
        materials: {
          ...clone(current.materials),
          queued: Math.max(0, current.materials.total - current.materials.analyzed),
          failed: cancelled ? current.materials.failed : Math.max(1, current.materials.failed),
          analysisStatus: cancelled ? 'queued' : 'failed',
          analysisProgress: null,
        },
        updatedAt: nowIso(),
      }
    }).catch((error) => {
      if (errorCode(error) !== 'WORKBENCH_JOB_INPUT_SUPERSEDED') throw error
    })
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   * @param {{readyProgress: number, publishedProgress: number}} progress
   * @param {((input: {initialMaterials: Record<string, any>, progressPublished: boolean, progressPercent: number, detail: string}) => Promise<{released: true, summary: string} | null>) | null} [maybePauseMaterialAnalysis]
   */
  const restoreOrAnalyzeMaterials = async (claimed, signal, checkpoint, progress, maybePauseMaterialAnalysis = null) => {
    const { privateInput } = claimed
    const providerInput = {
      projectId: claimed.projectId,
      authorizationId: privateInput.authorizationId,
      ...(privateInput.assetId ? { assetId: privateInput.assetId } : {}),
      signal,
    }
    signal.throwIfAborted()
    /** @type {Record<string, any> | null} */
    let analyzed = null
    const currentProject = await projectRepository.get(claimed.projectId)
    const initialMaterials = clone(currentProject.materials)
    const hasLegacyReviewScene = Array.isArray(currentProject?.materials?.assets) && currentProject.materials.assets.some((/** @type {Record<string, any>} */ asset) =>
      Array.isArray(asset?.scenes) && asset.scenes.some(requiresMaterialReanalysis)
    )
    // A selected card explicitly asks for a fresh representative frame. Do not
    // satisfy that request from the project's complete-but-old analysis record.
    let restored = !privateInput.assetId && !hasLegacyReviewScene
    if (restored) {
      try {
        analyzed = await materialAnalysisProvider.restoreAnalysis(providerInput)
      } catch (error) {
        if (errorCode(error) !== 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') throw error
        restored = false
      }
    }
    if (!restored && maybePauseMaterialAnalysis) {
      const pause = await maybePauseMaterialAnalysis({
        initialMaterials,
        progressPublished: false,
        progressPercent: progress.readyProgress,
        detail: '素材分析可在资源空闲后继续。',
      })
      if (pause) return pause
    }
    if (!restored) {
      await publishMaterialProgress(claimed, checkpoint, {
        analyzed: 0,
        total: 0,
        label: null,
      })
      try {
        analyzed = await materialAnalysisProvider.analyzeMaterials({
          ...providerInput,
          ...(privateInput.assetId ? { force: true } : {}),
          onProgress: async (/** @type {{analyzed: number, total: number, label: string | null, overallPercent?: number, assets?: unknown[], completedMaterials?: unknown}} */ update) => {
            signal.throwIfAborted()
            await publishMaterialProgress(claimed, checkpoint, update)
            if (!maybePauseMaterialAnalysis) return
            const pause = await maybePauseMaterialAnalysis({
              initialMaterials,
              progressPublished: true,
              progressPercent: typeof update.overallPercent === 'number' && Number.isFinite(update.overallPercent)
                ? update.overallPercent
                : progress.readyProgress,
              detail: '预览或剪映导出任务优先，素材分析已暂停，可稍后继续。',
            })
            if (pause) throw Object.assign(new Error('WORKBENCH_MATERIAL_ANALYSIS_RELEASED'), {
              code: 'WORKBENCH_MATERIAL_ANALYSIS_RELEASED',
              summary: pause.summary,
            })
          },
        })
      } catch (error) {
        if (errorCode(error) === 'WORKBENCH_MATERIAL_ANALYSIS_RELEASED') {
          return { released: true, summary: /** @type {{summary?: string}} */ (error).summary ?? '素材分析已暂停，可稍后继续。' }
        }
        throw error
      }
    }
    signal.throwIfAborted()
    const publicAnalyzed = projectAnalyzedMaterialsForPublic(analyzed, privateInput.authorizationId)
    if (!publicAnalyzed) {
      throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    analyzed = publicAnalyzed
    await checkpoint('materials_ready', progress.readyProgress, {
      restored,
      analyzed: analyzed.analyzed,
      detail: restored
        ? `已恢复 ${analyzed.analyzed} 个素材分析结果`
        : `已分析 ${analyzed.analyzed} 个素材，正在写入项目`,
    })
    signal.throwIfAborted()
    let shouldInvalidateOutputs = false
    await saveMaterialUpdate(claimed, async (current) => {
    signal.throwIfAborted()
    // `lastScanAt`, progress counters, and equivalent transport state change on
    // every successful restore. Compare only the authorization and analyzed
    // asset/scene content so a harmless refresh cannot erase finished work.
    const currentMaterialContent = materialContentFingerprint(current.materials)
    const analyzedMaterialContent = materialContentFingerprint(analyzed)
    const materialsChanged =
      currentMaterialContent === null ||
      analyzedMaterialContent === null ||
      currentMaterialContent !== analyzedMaterialContent
    shouldInvalidateOutputs = materialsChanged && Boolean(
      current.storyboard ||
      current.editor?.timelineId ||
      current.preview?.resourceId ||
      current.preview?.timelineId ||
      current.delivery?.exportJob,
    )
    if (materialsChanged) await deleteProjectMedia(current)
      return {
      ...clone(current),
      materials: clone(analyzed),
      ...(materialsChanged
        ? {
            storyboard: null,
            editor: emptyEditor(),
            preview: emptyPreview(),
            delivery: emptyDelivery(),
          }
        : {}),
      currentStage: 'materials',
      updatedAt: nowIso(),
      }
    })
    if (shouldInvalidateOutputs) {
      await invalidateProjectOutputs(claimed.projectId)
    }
    await checkpoint('materials_published', progress.publishedProgress, {
      analyzed: analyzed.analyzed,
      detail: `已分析 ${analyzed.analyzed} 个素材`,
    })
    return analyzed
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   * @param {((input: {initialMaterials: Record<string, any>, progressPublished: boolean, progressPercent: number, detail: string}) => Promise<{released: true, summary: string} | null>) | null} maybePauseMaterialAnalysis
   */
  const runMaterialAnalysis = async (claimed, signal, checkpoint, maybePauseMaterialAnalysis) => {
    const analyzed = await restoreOrAnalyzeMaterials(
      claimed,
      signal,
      checkpoint,
      { readyProgress: 90, publishedProgress: 100 },
      maybePauseMaterialAnalysis,
    )
    if (analyzed?.released === true) return analyzed
    const completed = /** @type {Record<string, any>} */ (analyzed)
    return {
      resourceId: `materials-${claimed.projectId}`,
      summary: `已分析 ${completed.analyzed} 个素材`,
    }
  }

  /** @param {Record<string, any>} candidate */
  const toDirectorCandidate = (candidate) => {
    const detail = [
      candidate.summary,
      candidate.ocrText !== 'No visible text detected' ? `OCR ${candidate.ocrText}` : '',
      candidate.asrSummary !== 'No reliable speech detected' ? `ASR ${candidate.asrSummary}` : '',
      candidate.shotPurpose ? `purpose ${candidate.shotPurpose}` : '',
      candidate.recommendedUse ? `use ${candidate.recommendedUse}` : '',
      Number.isFinite(candidate.confidence) ? `confidence ${candidate.confidence}` : '',
      candidate.needsReview === true ? 'needs review' : '',
      Array.isArray(candidate.evidenceReferences) && candidate.evidenceReferences.length > 0
        ? `evidence ${candidate.evidenceReferences.join(', ')}`
        : '',
    ].filter(Boolean).join(' | ').slice(0, 500).trim()
    const tags = [...new Set([
      ...(Array.isArray(candidate.tags) ? candidate.tags : []),
      ...(Array.isArray(candidate.domainTags) ? candidate.domainTags : []),
      ...(Array.isArray(candidate.visualTags) ? candidate.visualTags : []),
      ...(Array.isArray(candidate.actionTags) ? candidate.actionTags : []),
      ...deriveMaterialContentTags(candidate.summary || ''),
    ])].slice(0, 12)
    return {
      candidate_id: candidate.id,
      asset_id: candidate.assetId,
      scene_id: candidate.id,
      source: 'material_analysis',
      start: candidate.start,
      end: candidate.end,
      summary: detail || candidate.summary,
      tags,
      search_score: candidate.matchScore,
    }
  }

  /** @param {any[]} candidateEntries */
  const candidateEntryMap = (candidateEntries) =>
    new Map(candidateEntries.map(([sentenceId, value]) => [sentenceId, value]))

  /**
   * @param {Record<string, any>} finalPlan
   * @param {any[]} candidateEntries
   * @param {string} title
   * @param {Record<string, any> | null} templateGuidance
   */
  const toPublicStoryboard = (finalPlan, candidateEntries, title, templateGuidance) => {
    const privateById = new Map()
    for (const [, value] of candidateEntries) {
      for (const candidate of value.publicCandidates ?? []) {
        privateById.set(candidate.id, candidate)
      }
    }
    return {
      id: finalPlan.plan_id,
      title,
      updatedAt: finalPlan.created_at,
      templateFingerprint: templateGuidance?.fingerprint ?? null,
      templateRevision: templateGuidance?.revision ?? null,
      sentences: finalPlan.items.map((/** @type {Record<string, any>} */ item) => ({
        id: item.sentence_id,
        order: item.order,
        text: item.voiceover_text,
        selectedCandidateId: item.selected_candidate_id,
        status: item.status,
        candidates: item.candidates.map((/** @type {Record<string, any>} */ candidate) => {
          const original = privateById.get(candidate.candidate_id)
          if (
            !validSearchCandidate(original) ||
            original.id !== candidate.candidate_id ||
            original.assetId !== candidate.asset_id ||
            original.start !== candidate.start ||
            original.end !== candidate.end ||
            original.summary !== candidate.summary
          ) {
            throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
          }
          const decisionProjection = original.shotPurpose
            ? {
                shotPurpose: original.shotPurpose,
                recommendedUse: original.recommendedUse,
                confidence: original.confidence,
                needsReview: original.semanticFallback === true || original.needsReview === true,
                semanticFallback: original.semanticFallback === true,
                entities: original.entities,
                actions: original.actions,
                screenState: original.screenState,
                sceneChanges: original.sceneChanges,
                educationContext: original.educationContext,
                editingValue: original.editingValue,
                qualityReasons: original.qualityReasons,
              }
            : {}
          return {
            id: candidate.candidate_id,
            assetLabel: original.assetLabel,
            start: candidate.start,
            end: candidate.end,
            summary: candidate.summary,
            matchScore: candidate.search_score,
            reason: candidate.reason,
            ...decisionProjection,
            rankingSource: ['llm_gateway', 'local_search', 'search_refill'].includes(candidate.ranking_source)
              ? candidate.ranking_source
              : null,
          }
        }),
      })),
    }
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   */
  const runStoryboard = async (claimed, signal, checkpoint) => {
    const { privateInput } = claimed
    await checkpoint('storyboard_initializing', 3, {
      detail: '正在确认创作要求和已分析素材',
    })
    let current = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(current, privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    if (!hasCompleteMaterialIndex(current)) {
      throw coordinatorError('MATERIAL_ANALYSIS_RESCAN_REQUIRED', 409)
    }
    const identity = {
      projectId: claimed.projectId,
      jobId: claimed.jobId,
      fingerprint: privateInput.inputFingerprint,
      generation: claimed.attempts.at(-1).generation,
    }
    let plan = await editPlanRepository.get(identity)
    let templateGuidance = privateInput.templateGuidance
      ? adaptTemplateGuidanceToCount(
          privateInput.templateGuidance,
          plan?.final?.items?.length ?? plan?.draft?.sentences?.length ?? 1,
        )
      : null
    if (plan?.status === 'finalized') {
      if (!isEditPlan(plan.final) || !Array.isArray(plan.candidates)) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
      }
      current = await projectRepository.get(claimed.projectId)
      if (!inputStillCurrent(current, privateInput)) {
        throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
      }
      const storyboard = toPublicStoryboard(
        plan.final,
        plan.candidates,
        privateInput.brief.title || current.name,
        templateGuidance,
      )
      signal.throwIfAborted()
      await deleteProjectMedia(current)
      await saveProjectIfCurrent(current, {
        ...clone(current),
        storyboard,
        editor: emptyEditor(),
        preview: emptyPreview(),
        delivery: emptyDelivery(),
        currentStage: 'storyboard',
        updatedAt: nowIso(),
      })
      await checkpoint('storyboard_published', 100, {
        completedSentenceIds: plan.final.items.map(
          (/** @type {Record<string, any>} */ item) => item.sentence_id,
        ),
        completedSentenceCount: plan.final.items.length,
        planId: plan.final.plan_id,
      })
      return {
        resourceId: plan.final.plan_id,
        summary: `已生成 ${plan.final.items.length} 个镜头拍点`,
        outputFingerprint: fingerprint(storyboard),
        templateFingerprint: templateGuidance?.fingerprint ?? null,
        templateRevision: templateGuidance?.revision ?? null,
      }
    }
    /** @param {string} visualText @param {Record<string, any> | null} [creativeContext] */
    const searchForVisualText = async (visualText, creativeContext = null) => {
      const candidatesById = new Map()
      let searchText = visualText
      if (creativeContext) {
        try {
          searchText = createCreativeMaterialQuery(visualText, creativeContext, materialSearchQueryLimit)
        } catch (error) {
          logger({
            event: 'creative_active_query_degraded',
            code: errorCode(error) || 'CREATIVE_MATERIAL_QUERY_INVALID',
          })
        }
      }
      const scopes = identifier(privateInput.authorizationId)
        ? [{
            projectId: claimed.projectId,
            authorizationId: privateInput.authorizationId,
          }]
        : []
      const referencedAssetIds = typeof listReferencedAssetIds === 'function'
        ? [...new Set((listReferencedAssetIds(claimed.projectId) ?? []).filter((id) => identifier(id)))]
        : []
      const referencedAssetIdSet = new Set(referencedAssetIds)
      const localAuthorizationId = identifier(privateInput.authorizationId)
        ? privateInput.authorizationId
        : null
      const searchLimit = referencedAssetIdSet.size > 0
        ? Math.min(50, Math.max(materialSearchCandidateLimit, referencedAssetIdSet.size))
        : materialSearchCandidateLimit
      if (typeof listStoryboardSearchScopes === 'function') {
        try {
          const extra = await listStoryboardSearchScopes(claimed.projectId)
          if (Array.isArray(extra)) {
            for (const scope of extra.slice(0, 64)) {
              if (!identifier(scope?.projectId) || !identifier(scope?.authorizationId)) continue
              if (scopes.some((existing) =>
                existing.projectId === scope.projectId &&
                existing.authorizationId === scope.authorizationId)) continue
              scopes.push({
                projectId: scope.projectId,
                authorizationId: scope.authorizationId,
              })
            }
          }
        } catch (error) {
          logger({
            event: 'storyboard_library_scope_degraded',
            code: errorCode(error) || 'MATERIAL_LIBRARY_SCOPE_UNAVAILABLE',
          })
        }
      }
      /** @type {unknown} */
      let primarySearchError = null
      for (const query of segmentationRecallQueries(searchText)) {
        for (const [scopeIndex, scope] of scopes.entries()) {
          let recalled
          try {
            recalled = await materialAnalysisProvider.searchCandidates({
              projectId: scope.projectId,
              authorizationId: scope.authorizationId,
              query,
              limit: materialSearchCandidateLimit,
              allowSemanticFallback: true,
              ...(referencedAssetIdSet.size > 0 && scope.authorizationId !== localAuthorizationId
                ? { assetIds: [...referencedAssetIdSet] }
                : {}),
              signal,
            })
          } catch (error) {
            signal.throwIfAborted()
            if (scopeIndex === 0 && !primarySearchError) primarySearchError = error
            else {
              logger({
                event: 'storyboard_library_search_degraded',
                code: errorCode(error) || 'MATERIAL_ANALYSIS_FAILED',
              })
            }
            continue
          }
          signal.throwIfAborted()
          if (
            !Array.isArray(recalled) ||
            recalled.some((candidate) => !validSearchCandidate(candidate))
          ) {
            if (scopeIndex === 0) {
              throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
            }
            logger({
              event: 'storyboard_library_search_degraded',
              code: 'WORKBENCH_CAPABILITY_RESPONSE_INVALID',
            })
            continue
          }
          for (const [rank, candidate] of recalled.entries()) {
            const assetId = identifier(candidate.assetId) ? candidate.assetId : candidate.asset_id
            if (
              referencedAssetIdSet.size > 0 &&
              scope.authorizationId !== localAuthorizationId &&
              !referencedAssetIdSet.has(assetId)
            ) continue
            const existing = candidatesById.get(candidate.id)
            if (
              !existing ||
              rank < existing.rank ||
              (rank === existing.rank && candidate.matchScore > existing.candidate.matchScore)
            ) {
              candidatesById.set(candidate.id, { candidate, rank })
            }
          }
        }
      }
      if (candidatesById.size === 0 && primarySearchError) {
        const code = errorCode(primarySearchError)
        if (code === 'MATERIAL_ANALYSIS_QUERY_INVALID' || code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') {
          logger({
            event: 'storyboard_search_query_degraded',
            code,
          })
        } else {
          throw primarySearchError
        }
      }
      return [...candidatesById.values()]
        .sort((left, right) =>
          left.rank - right.rank ||
          right.candidate.matchScore - left.candidate.matchScore ||
          left.candidate.id.localeCompare(right.candidate.id))
        .map((entry) => entry.candidate)
        .slice(0, searchLimit)
    }
    let sentences = plan?.draft?.sentences
    if (!Array.isArray(sentences)) {
      const segmentDetail = '正在理解脚本节奏并规划镜头段落'
      await checkpoint('storyboard_segmenting', 4, {
        detail: segmentDetail,
      })
      const stopSegmentHeartbeat = startStoryboardProgressHeartbeat(checkpoint, {
        stage: 'storyboard_segmenting',
        from: 4,
        to: 9,
        detail: segmentDetail,
        intervalMs: storyboardProgressHeartbeatMs,
      })
      try {
        const segmentationEvidence = await searchForVisualText(privateInput.brief.script)
        sentences = await director.segmentScript(privateInput.brief.script, {
          signal,
          templateGuidance: clone(privateInput.templateGuidance),
          materialEvidence: segmentationEvidence.map(toDirectorCandidate),
        })
      } finally {
        await stopSegmentHeartbeat()
      }
      signal.throwIfAborted()
      if (!Array.isArray(sentences) || sentences.length === 0) {
        throw coordinatorError('WORKBENCH_DIRECTOR_RESPONSE_INVALID', 502)
      }
      await checkpoint('storyboard_segmented', 10, {
        completedSentenceIds: sentences.map((sentence) => sentence.id),
        completedSentenceCount: sentences.length,
        detail: '镜头段落已规划，正在检索匹配画面',
      })
    }
    templateGuidance = privateInput.templateGuidance
      ? adaptTemplateGuidanceToCount(privateInput.templateGuidance, sentences.length)
      : null
    if (!plan) {
      plan = await editPlanRepository.draft({
        ...identity,
        draft: {
          sentences: clone(sentences),
          brief: clone(privateInput.brief),
          templateGuidance: clone(templateGuidance),
        },
        updatedAt: nowIso(),
      })
    }
    /** @type {Record<string, any> | null} */
    let activeCreativePrepared = null
    if (creativePlanningMode === 'active' && creativePlanner) {
      try {
        const prepared = await creativePlanner.prepare({
          sentences: clone(sentences),
          allowedCapabilityIds: creativeAllowedCapabilities,
          signal,
        })
        if (
          !isRecord(prepared) ||
          !(prepared.contexts instanceof Map) ||
          prepared.contexts.size !== sentences.length ||
          sentences.some((sentence) => {
            const context = prepared.contexts.get(sentence.id)
            return !isCreativePlanningContext(context) || context.sentence_id !== sentence.id
          })
        ) {
          throw coordinatorError('CREATIVE_ACTIVE_CONTEXT_INVALID', 502)
        }
        activeCreativePrepared = prepared
      } catch (error) {
        signal.throwIfAborted()
        logger({
          event: 'creative_active_context_degraded',
          code: errorCode(error) || 'CREATIVE_ACTIVE_CONTEXT_UNAVAILABLE',
        })
      }
    }
    /** @type {any[]} */
    let candidateEntries = Array.isArray(plan.candidates) ? clone(plan.candidates) : []
    let privateCandidates = candidateEntryMap(candidateEntries)
    for (let index = 0; index < sentences.length; index += 1) {
      const sentence = sentences[index]
      if (privateCandidates.has(sentence.id)) continue
      signal.throwIfAborted()
      const searchDetail = `正在检索第 ${index + 1} / ${sentences.length} 个镜头拍点的候选画面`
      const searchFrom = storyboardSpanProgress(10, 60, index, sentences.length)
      const searchUntil = Math.max(
        searchFrom,
        storyboardSpanProgress(10, 60, index + 1, sentences.length) - 1,
      )
      await checkpoint(
        'storyboard_candidates',
        searchFrom,
        {
          completedSentenceIds: sentences.slice(0, index).map((entry) => entry.id),
          completedSentenceCount: index,
          detail: searchDetail,
        },
      )
      const stopSearchHeartbeat = startStoryboardProgressHeartbeat(checkpoint, {
        stage: 'storyboard_candidates',
        from: searchFrom,
        to: searchUntil,
        detail: searchDetail,
        intervalMs: storyboardProgressHeartbeatMs,
      })
      let eligibleCandidates
      try {
        eligibleCandidates = await searchForVisualText(
          sentence.text,
          activeCreativePrepared?.contexts?.get(sentence.id) ?? null,
        )
      } finally {
        await stopSearchHeartbeat()
      }
      privateCandidates.set(sentence.id, {
        directorCandidates: eligibleCandidates.map(toDirectorCandidate),
        publicCandidates: clone(eligibleCandidates),
      })
      candidateEntries = sentences
        .filter((entry) => privateCandidates.has(entry.id))
        .map((entry) => [entry.id, privateCandidates.get(entry.id)])
      plan = await editPlanRepository.candidates({
        ...identity,
        candidates: candidateEntries,
        updatedAt: nowIso(),
      })
      const completedSentenceIds = candidateEntries.map(([sentenceId]) => sentenceId)
      await checkpoint(
        'storyboard_candidates',
        storyboardSpanProgress(10, 60, completedSentenceIds.length, sentences.length),
        {
          completedSentenceIds,
          completedSentenceCount: completedSentenceIds.length,
          detail: `已找到第 ${completedSentenceIds.length} / ${sentences.length} 个镜头拍点的候选画面`,
        },
      )
    }
    privateCandidates = candidateEntryMap(candidateEntries)
    const eligibleCandidateSets = new Map(sentences.map((sentence) => [
      sentence.id,
      privateCandidates.get(sentence.id)?.directorCandidates ?? [],
    ]))
    // The provider performs multi-signal Top-K recall. Keep that complete allowed
    // set for the LLM Gateway reranker; only the final EditPlan is capped at Top 3.
    const candidateSets = eligibleCandidateSets
    const candidateEvidenceIdsBySentence = new Map(sentences.map((sentence) => [
      sentence.id,
      (candidateSets.get(sentence.id) ?? []).map(
        (/** @type {Record<string, any>} */ candidate) => candidate.candidate_id,
      ),
    ]))
    /** @type {Promise<Record<string, any> | null> | null} */
    let creativeTracePromise = null
    if (creativePlanningMode !== 'off' && creativePlanner) {
      const attempt = claimed.attempts.at(-1)
      if (!attempt?.lease?.token) throw coordinatorError('WORKBENCH_JOB_ATTEMPT_INVALID', 500)
      const traceInput = {
          projectId: claimed.projectId,
          storyboardJobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          inputFingerprint: privateInput.inputFingerprint,
          sentences: clone(sentences),
          candidateEvidenceIdsBySentence,
          signal,
        }
      creativeTracePromise = (creativePlanningMode === 'active' && activeCreativePrepared
        ? creativePlanner.persist({
            ...traceInput,
            prepared: activeCreativePrepared,
            realizedAs: 'active_context',
          })
        : creativePlanningMode === 'shadow'
          ? creativePlanner.run(traceInput)
          : Promise.resolve(null))
        .catch((/** @type {unknown} */ error) => {
          signal.throwIfAborted()
          logger({
            event: creativePlanningMode === 'active'
              ? 'creative_active_trace_degraded'
              : 'creative_shadow_degraded',
            code: errorCode(error) || 'CREATIVE_SHADOW_UNAVAILABLE',
          })
          return null
        })
    }
    const rankDetail = '候选镜头已找齐，正在按创作要求排序 Top 3'
    await checkpoint('storyboard_ranking', 70, {
      completedSentenceIds: sentences.map((sentence) => sentence.id),
      completedSentenceCount: sentences.length,
      detail: rankDetail,
    })
    const stopRankHeartbeat = startStoryboardProgressHeartbeat(checkpoint, {
      stage: 'storyboard_ranking',
      from: 70,
      to: 79,
      detail: rankDetail,
      intervalMs: storyboardProgressHeartbeatMs,
    })
    let rankings
    try {
      rankings = await director.rankCandidates(sentences, candidateSets, {
        signal,
        templateGuidance: clone(templateGuidance),
        creativeContextBySentence: activeCreativePrepared?.contexts ?? null,
      })
    } finally {
      await stopRankHeartbeat()
    }
    signal.throwIfAborted()
    if (!(rankings instanceof Map)) {
      throw coordinatorError('WORKBENCH_DIRECTOR_RESPONSE_INVALID', 502)
    }
    const rankingResultsBySentence = new Map(sentences.map((sentence) => {
      const value = rankings.get(sentence.id)
      if (Array.isArray(value)) {
        return [sentence.id, { ranked: value, rejected: [] }]
      }
      if (
        isRecord(value) &&
        Array.isArray(value.ranked) &&
        Array.isArray(value.rejected)
      ) {
        return [sentence.id, { ranked: value.ranked, rejected: value.rejected }]
      }
      throw coordinatorError('WORKBENCH_DIRECTOR_RESPONSE_INVALID', 502)
    }))
    await checkpoint('storyboard_ranked', 80, {
      completedSentenceIds: sentences.map((sentence) => sentence.id),
      completedSentenceCount: sentences.length,
      detail: 'Top 3 候选已排序，正在确认镜头覆盖与时长',
    })
    const planId = createId('plan')
    const createdAt = nowIso()
    /** @type {Map<string, any[]>} */
    const assignmentCandidatesBySentence = new Map()
    /** @type {Map<string, any[]>} */
    const fallbackAssignmentCandidatesBySentence = new Map()
    /** @type {Map<string, any[]>} */
    const displayCandidatesBySentence = new Map()
    /** @type {Map<string, Set<string>>} */
    const semanticFallbackCandidateIdsBySentence = new Map()
    /** @type {Map<string, Set<string>>} */
    const reviewRequiredCandidateIdsBySentence = new Map()
    for (const [index, sentence] of sentences.entries()) {
      const publicCandidatesById = new Map(
        (privateCandidates.get(sentence.id)?.publicCandidates ?? []).map(
          (/** @type {Record<string, any>} */ candidate) => [candidate.id, candidate],
        ),
      )
      semanticFallbackCandidateIdsBySentence.set(
        sentence.id,
        new Set(
          [...publicCandidatesById.values()]
            .filter((candidate) => candidate.semanticFallback === true)
            .map((candidate) => candidate.id),
        ),
      )
      reviewRequiredCandidateIdsBySentence.set(
        sentence.id,
        new Set(
          [...publicCandidatesById.values()]
            .filter((candidate) => candidate.needsReview === true)
            .map((candidate) => candidate.id),
        ),
      )
      const candidatesById = new Map(
        (eligibleCandidateSets.get(sentence.id) ?? []).map(
          (/** @type {Record<string, any>} */ candidate) => [candidate.candidate_id, candidate],
        ),
      )
      const reviewReason = (/** @type {string} */ candidateId) => {
        const candidate = publicCandidatesById.get(candidateId)
        return candidate?.semanticFallback === true
          ? '未找到强相关画面，按语义相似度补位，请人工确认。'
          : ''
      }
      /** @type {any[]} */
      const ranked = []
      const rankedIds = new Set()
      for (const entry of rankingResultsBySentence.get(sentence.id)?.ranked ?? []) {
        const candidate = candidatesById.get(entry.candidate_id)
        if (!candidate) throw coordinatorError('WORKBENCH_DIRECTOR_RESPONSE_INVALID', 502)
        rankedIds.add(candidate.candidate_id)
        ranked.push({
          ...candidate,
          summary: publicCandidatesById.get(candidate.candidate_id)?.summary ?? candidate.summary,
          director_score: entry.score,
          reason: [reviewReason(candidate.candidate_id), entry.reason].filter(Boolean).join(' '),
          ranking_source: entry.ranking_source === 'llm_gateway' || entry.ranking_source === 'local_search'
            ? entry.ranking_source
            : 'unknown',
        })
      }
      for (const candidate of eligibleCandidateSets.get(sentence.id) ?? []) {
        if (rankedIds.has(candidate.candidate_id)) continue
        ranked.push({
          ...candidate,
          summary: publicCandidatesById.get(candidate.candidate_id)?.summary ?? candidate.summary,
          director_score: candidate.search_score,
          reason: [
            reviewReason(candidate.candidate_id),
            '检索补位候选：用于保证每个镜头拍点都有不重复的可选镜头。',
          ].filter(Boolean).join(' '),
          ranking_source: 'search_refill',
        })
      }
      const requiredDurationSeconds = templateGuidance
        ? templateGuidance.slots[index].recommendedDurationMs / 1000
        : 0
      const durationOk = []
      const durationShort = []
      for (const candidate of ranked) {
        if (candidate.end - candidate.start + 1e-6 >= requiredDurationSeconds) {
          durationOk.push(candidate)
        } else {
          durationShort.push({
            ...candidate,
            reason: requiredDurationSeconds > 0
              ? [
                  reviewReason(candidate.candidate_id),
                  `时长偏短（约 ${Math.max(0.1, candidate.end - candidate.start).toFixed(1)} 秒），模板该句建议至少 ${requiredDurationSeconds.toFixed(1)} 秒；仍可选择，但套模板时可能不够用。`,
                ].filter(Boolean).join(' ')
              : candidate.reason,
          })
        }
      }
      const displayCandidates = [...durationOk, ...durationShort]
      displayCandidatesBySentence.set(sentence.id, displayCandidates)
      // Required narration replaces template guidance with the synthesized audio
      // duration, so a shorter-than-template scene remains eligible and receives
      // an exact scene-bound check before publication. Non-narrated templates must
      // keep the duration-ok requirement because their slot duration is unchanged.
      const automaticallyAssignableCandidates = privateInput.brief.voiceover === 'required'
        ? displayCandidates
        : durationOk
      assignmentCandidatesBySentence.set(
        sentence.id,
        automaticallyAssignableCandidates.filter((candidate) => {
          const publicCandidate = publicCandidatesById.get(candidate.candidate_id)
          return publicCandidate?.semanticFallback !== true &&
            (activeCreativePrepared === null || publicCandidate?.needsReview !== true)
        }),
      )
      fallbackAssignmentCandidatesBySentence.set(
        sentence.id,
        activeCreativePrepared !== null
          ? []
          : automaticallyAssignableCandidates.filter((candidate) =>
              publicCandidatesById.get(candidate.candidate_id)?.semanticFallback === true),
      )
    }
    const selectedBySentence = assignUniqueSceneCandidates(
      sentences.map((sentence) => sentence.id),
      assignmentCandidatesBySentence,
    )
    // Preserve strong matches first. When a sentence has no strong match, use
    // its best eligible semantic fallback so the default workflow can proceed;
    // the public projection continues to flag it for human review and allows
    // replacement. Candidates that fail duration constraints never enter either
    // assignment set.
    const selectedSceneKeys = new Set(
      [...selectedBySentence.values()].map((candidate) =>
        `${candidate.asset_id}\u0000${candidate.scene_id}`),
    )
    const fallbackSentenceIds = sentences
      .map((sentence) => sentence.id)
      .filter((sentenceId) => !selectedBySentence.has(sentenceId))
    const fallbackSelections = assignUniqueSceneCandidates(
      fallbackSentenceIds,
      new Map(fallbackSentenceIds.map((sentenceId) => [
        sentenceId,
        (fallbackAssignmentCandidatesBySentence.get(sentenceId) ?? []).filter((candidate) =>
          !selectedSceneKeys.has(`${candidate.asset_id}\u0000${candidate.scene_id}`)),
      ])),
    )
    for (const [sentenceId, candidate] of fallbackSelections) {
      selectedBySentence.set(sentenceId, candidate)
    }
    const selectedSceneKeysBySentence = new Map()
    for (const sentence of sentences) {
      const selected = selectedBySentence.get(sentence.id)
      if (!selected) continue
      selectedSceneKeysBySentence.set(
        sentence.id,
        `${selected.asset_id}\u0000${selected.scene_id}`,
      )
    }
    const finalPlan = {
      schema_version: 1,
      plan_id: planId,
      project_id: claimed.projectId,
      created_at: createdAt,
      items: sentences.map((sentence, index) => {
        const displayCandidates = displayCandidatesBySentence.get(sentence.id) ?? []
        const selected = selectedBySentence.get(sentence.id)
        const occupiedByOtherSentence = new Set(
          [...selectedSceneKeysBySentence.entries()]
            .filter(([sentenceId]) => sentenceId !== sentence.id)
            .map(([, sceneKey]) => sceneKey),
        )
        const availableDisplayCandidates = displayCandidates.filter((candidate) =>
          !occupiedByOtherSentence.has(`${candidate.asset_id}\u0000${candidate.scene_id}`),
        )
        // Active planning keeps low-confidence evidence visible but never turns
        // it into a timeline selection. Legacy and shadow modes retain their
        // existing semantic fallback behavior.
        const candidatesForSentence = selected
          ? [
              selected,
              ...availableDisplayCandidates.filter(
                (candidate) => candidate.candidate_id !== selected.candidate_id,
              ),
            ].slice(0, 3)
          : availableDisplayCandidates
              .filter((candidate) => {
                return semanticFallbackCandidateIdsBySentence
                  .get(sentence.id)?.has(candidate.candidate_id) ||
                  (activeCreativePrepared !== null && reviewRequiredCandidateIdsBySentence
                    .get(sentence.id)?.has(candidate.candidate_id))
              })
              .slice(0, 3)
        return {
          sentence_id: sentence.id,
          order: index + 1,
          voiceover_text: sentence.text,
          status: selected ? 'selected' : 'needs_capture',
          selected_candidate_id: selected?.candidate_id ?? null,
          candidates: candidatesForSentence,
          rejectReasons: (rankingResultsBySentence.get(sentence.id)?.rejected ?? []).map(
            (entry) => ({
              candidateId: entry.candidate_id,
              reason: entry.reason,
              category: 'other',
            }),
          ),
        }
      }),
    }
    if (!isEditPlan(finalPlan)) {
      throw coordinatorError('WORKBENCH_DIRECTOR_RESPONSE_INVALID', 502)
    }
    const boundPlan = await demoteUnboundLibrarySelections(
      claimed.projectId,
      privateInput.authorizationId,
      finalPlan,
    )
    if (!isEditPlan(boundPlan)) {
      throw coordinatorError('WORKBENCH_DIRECTOR_RESPONSE_INVALID', 502)
    }
    await editPlanRepository.finalize({
      ...identity,
      final: boundPlan,
      updatedAt: createdAt,
    })
    const timelineDetail = privateInput.brief.voiceover === 'required'
      ? '正在生成配音并写入分镜时间线'
      : '正在写入分镜时间线'
    await checkpoint('storyboard_timeline_synthesizing', 84, {
      completedSentenceIds: sentences.map((sentence) => sentence.id),
      completedSentenceCount: sentences.length,
      planId,
      detail: timelineDetail,
    })
    const stopTimelineHeartbeat = startStoryboardProgressHeartbeat(checkpoint, {
      stage: 'storyboard_timeline_synthesizing',
      from: 84,
      to: 89,
      detail: timelineDetail,
      intervalMs: storyboardProgressHeartbeatMs,
    })
    let realizedTechniqueDecisions = null
    let shadowTimeline
    try {
      shadowTimeline = await persistShadowTimeline({
        projectId: claimed.projectId,
        authorizationId: privateInput.authorizationId,
        editPlan: boundPlan,
        templateGuidance,
        brief: privateInput.brief,
        createdAt,
        allowNarrationSynthesis: true,
        ...(creativeTechniqueMode === 'active' && activeCreativePrepared?.techniqueMode === 'active' && activeCreativePrepared.techniquePolicies instanceof Map
          ? { techniqueDecisions: [...activeCreativePrepared.techniquePolicies.values()] }
          : {}),
        ...(creativeAudioCueMode === 'active' && activeCreativePrepared?.audioCueMode === 'active' &&
          Array.isArray(activeCreativePrepared.audioCueDecisions)
          ? { audioCueDecisions: activeCreativePrepared.audioCueDecisions }
          : {}),
        onTechniqueRealized: (decisions) => { realizedTechniqueDecisions = decisions },
        ...(privateInput.creativeAutoOutputs === true
          ? { suppressAutomaticPackagingRecommendation: true }
          : {}),
        signal,
      })
    } finally {
      await stopTimelineHeartbeat()
    }
    const creativeTraceResult = creativeTracePromise ? await creativeTracePromise : null
    if (
      creativeTraceResult &&
      shadowTimeline?.revisionFingerprint &&
      typeof creativePlanner?.bindTimeline === 'function'
    ) {
      const attempt = claimed.attempts.at(-1)
      try {
        if (!attempt?.lease?.token) throw coordinatorError('WORKBENCH_JOB_ATTEMPT_INVALID', 500)
        await creativePlanner.bindTimeline({
          projectId: claimed.projectId,
          storyboardJobId: claimed.jobId,
          knowledgeSnapshotFingerprint: creativeTraceResult.knowledgeSnapshotFingerprint,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          timelineRevisionFingerprint: shadowTimeline.revisionFingerprint,
          ...(realizedTechniqueDecisions ? { techniquePolicies: realizedTechniqueDecisions } : {}),
        })
      } catch (error) {
        signal.throwIfAborted()
        logger({
          event: 'creative_shadow_timeline_bind_degraded',
          code: errorCode(error) || 'CREATIVE_SHADOW_TIMELINE_BIND_UNAVAILABLE',
        })
      }
    }
    await checkpoint('storyboard_ready', 90, {
      completedSentenceIds: sentences.map((sentence) => sentence.id),
      completedSentenceCount: sentences.length,
      planId,
      detail: '分镜时间线已准备好，正在发布到项目',
      ...(shadowTimeline
        ? {
            timelineId: shadowTimeline.timelineId,
            timelineRevision: shadowTimeline.revision,
            timelineContentFingerprint: shadowTimeline.contentFingerprint,
          }
        : {}),
    })
    current = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(current, privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    const storyboard = toPublicStoryboard(
      boundPlan,
      candidateEntries,
      privateInput.brief.title || current.name,
      templateGuidance,
    )
    signal.throwIfAborted()
    await deleteProjectMedia(current)
    await saveProjectIfCurrent(current, {
      ...clone(current),
      storyboard,
      editor: emptyEditor(),
      preview: emptyPreview(),
      delivery: emptyDelivery(),
      currentStage: 'storyboard',
      updatedAt: nowIso(),
    })
    await checkpoint('storyboard_published', 100, {
      completedSentenceIds: sentences.map((sentence) => sentence.id),
      completedSentenceCount: sentences.length,
      planId,
    })
    return {
      resourceId: planId,
      summary: `已生成 ${sentences.length} 个镜头拍点`,
      outputFingerprint: fingerprint(storyboard),
      templateFingerprint: templateGuidance?.fingerprint ?? null,
      templateRevision: templateGuidance?.revision ?? null,
    }
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   */
  const runPreview = async (claimed, signal, checkpoint) => {
    const { privateInput } = claimed
    let current = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(current, privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    const frozenTimeline = await assertFrozenTimelineIdentity(privateInput)
    if (
      privateInput.editorBound === true &&
      !await resolveEditorBoundChildOwnership(claimed, frozenTimeline)
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
    }
    let generated
    try {
      const editorBound = privateInput.editorBound === true
      /** @type {Record<string, any> | null} */
      let previewProjection = null
      if (editorBound) {
        if (!frozenTimeline || frozenTimeline.status !== 'finalized') {
          throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
        }
        try {
          previewProjection = projectRichTimelineToPreviewExport(frozenTimeline)
        } catch (error) {
          if (
            error &&
            typeof error === 'object' &&
            'code' in error &&
            typeof error.code === 'string'
          ) {
            throw coordinatorError(error.code, 'status' in error && typeof error.status === 'number'
              ? error.status
              : 409)
          }
          throw error
        }
      }
      const recoveredData = ['preview_rendered', 'preview_published'].includes(claimed.checkpoint?.stage)
        ? claimed.checkpoint?.data
        : null
      const recoveredResult = isRecord(recoveredData)
        ? {
            resourceId: recoveredData.resourceId,
            durationSeconds: recoveredData.durationSeconds,
            provider: recoveredData.provider,
            features: recoveredData.features,
          }
        : null
      if (
        recoveredResult &&
        validShortVideoFactoryResult(recoveredResult) &&
        await previewProvider.getResource({
          projectId: claimed.projectId,
          resourceId: recoveredResult.resourceId,
        })
      ) {
        generated = recoveredResult
      } else {
        const privatePlan = editorBound && previewProjection
          ? {
              selections: previewProjection.selections.map(
                (/** @type {Record<string, any>} */ selection) => ({
                  candidateId: selection.candidateId,
                  start: selection.startUs / 1_000_000,
                  end: (selection.startUs + selection.durationUs) / 1_000_000,
                }),
              ),
              voiceoverSegments: (previewProjection.packaging.voiceoverGuide ?? []).map(
                (/** @type {Record<string, any>} */ segment) => ({
                  sentenceId: segment.sentenceId,
                  text: segment.text,
                }),
              ),
            }
          : Array.isArray(privateInput.editorTimelineSelections)
            ? {
                selections: privateInput.editorTimelineSelections.map(
                  (/** @type {Record<string, any>} */ selection) => ({
                    candidateId: selection.candidateId,
                    start: selection.startUs / 1_000_000,
                    end: (selection.startUs + selection.durationUs) / 1_000_000,
                  }),
                ),
                voiceoverSegments: Array.isArray(privateInput.voiceoverSegments)
                  ? privateInput.voiceoverSegments
                  : [],
              }
            : await resolvePrivateSelections(privateInput)
        const selections = editorBound || Array.isArray(privateInput.editorTimelineSelections)
          ? privatePlan.selections
          : applyTemplateGuidanceToSelections(
              privatePlan.selections,
              privateInput.templateGuidance,
            )
        const clips = editorBound
          ? await resolveEditorTimelineSources({
              projectId: claimed.projectId,
              authorizationId: privateInput.authorizationId,
            }, editorTimelineSelectionsFrom(frozenTimeline).map((/** @type {{candidateId: string, sceneId: string, assetId: string, startUs: number, durationUs: number}} */ selection) => ({
              candidateId: selection.candidateId,
              sceneId: selection.sceneId,
              assetId: selection.assetId,
              start: selection.startUs / 1_000_000,
              end: (selection.startUs + selection.durationUs) / 1_000_000,
            })), signal)
          : await materialAnalysisProvider.resolvePreviewSources({
              projectId: claimed.projectId,
              authorizationId: privateInput.authorizationId,
              selections,
              signal,
            })
        if (
          !Array.isArray(clips) ||
          clips.length !== privateInput.selections.length ||
          clips.some((clip) =>
            !isRecord(clip) ||
            !identifier(clip.candidateId) ||
            typeof clip.sourcePath !== 'string' ||
            typeof clip.start !== 'number' ||
            typeof clip.end !== 'number')
        ) {
          throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
        }
        await checkpoint('preview_sources_ready', 15, {
          clipCount: clips.length,
          ...(previewProjection
            ? {
                timelineContentFingerprint: previewProjection.packaging.timelineContentFingerprint,
                degradationCodes: previewProjection.degradationCodes,
              }
            : {}),
        })
        generated = await previewProvider.renderPreview({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          brief: clone(privateInput.brief),
          clips,
          voiceoverSegments: clone(privatePlan.voiceoverSegments),
          templateGuidance: editorBound ? null : clone(privateInput.templateGuidance),
          ...(previewProjection
            ? {
                editorBound: true,
                timelinePackaging: clone(previewProjection.packaging),
                script: previewProjection.script,
                orientation: previewProjection.orientation,
              }
            : {}),
          signal,
          onStarted: () => checkpoint('preview_rendering', 20, { providerStarted: true }),
        })
        if (!validShortVideoFactoryResult(generated)) {
          throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
        }
        await checkpoint('preview_rendered', 90, {
          resourceId: generated.resourceId,
          durationSeconds: generated.durationSeconds,
          provider: generated.provider,
          features: generated.features,
          ...(previewProjection
            ? { degradationCodes: previewProjection.degradationCodes }
            : {}),
        })
      }
      current = await projectRepository.get(claimed.projectId)
      if (
        !inputStillCurrent(current, privateInput) ||
        !(await editorTimelineStillCurrent(privateInput))
      ) {
        throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
      }
      signal.throwIfAborted()
      if (current.preview?.resourceId !== generated.resourceId) {
        await deleteProjectMedia(current)
      }
      await saveProjectIfCurrent(current, {
        ...clone(current),
        preview: {
          status: 'ready',
          resourceId: generated.resourceId,
          durationSeconds: generated.durationSeconds,
          updatedAt: nowIso(),
          ...(previewProjection
            ? {
                previewStatus: previewProjection.degradationCodes.length > 0 ? 'preview_degraded' : 'ready',
                degradationCodes: [...previewProjection.degradationCodes],
              }
            : {}),
          timelineId: privateInput.timelineId,
          timelineRevision: privateInput.timelineRevision,
          timelineRevisionFingerprint: privateInput.timelineRevisionFingerprint,
          timelineContentFingerprint: privateInput.timelineContentFingerprint,
          templateFingerprint: privateInput.templateGuidance?.fingerprint ?? null,
          templateRevision: privateInput.templateGuidance?.revision ?? null,
        },
        delivery: emptyDelivery(),
        currentStage: 'preview',
        updatedAt: nowIso(),
      })
      // Publish then re-check: close the TOCTOU window where a newer revision
      // lands between the pre-save check and project write. Catch rolls back media.
      if (!(await editorTimelineStillCurrent(privateInput))) {
        throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
      }
      await checkpoint('preview_published', 100, {
        resourceId: generated.resourceId,
        durationSeconds: generated.durationSeconds,
        provider: generated.provider,
        features: generated.features,
        ...(previewProjection
          ? {
              previewStatus: previewProjection.degradationCodes.length > 0 ? 'preview_degraded' : 'ready',
              degradationCodes: previewProjection.degradationCodes,
            }
          : {}),
      })
      return {
        resourceId: generated.resourceId,
        summary: '正式预览已生成',
        outputFingerprint: fingerprint(generated),
        templateFingerprint: privateInput.templateGuidance?.fingerprint ?? null,
        templateRevision: privateInput.templateGuidance?.revision ?? null,
        ...(previewProjection
          ? {
              previewStatus: previewProjection.degradationCodes.length > 0 ? 'preview_degraded' : 'ready',
              degradationCodes: previewProjection.degradationCodes,
            }
          : {}),
      }
    } catch (error) {
      if (generated?.resourceId) {
        await rollbackPreview(claimed.projectId, generated.resourceId)
      }
      throw error
    }
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   */
  const runReferenceTemplate = async (
    claimed,
    signal,
    checkpoint,
    /** @type {(publication: {referenceTemplateId: string, publication: string, owned: boolean}) => void} */
    onPublication,
  ) => {
    if (
      !hasMethods(referenceTemplateAdapter, ['generate']) ||
      !hasMethods(referenceTemplateRepository, [
        'stageGenerated',
        'getStage',
        'commit',
        'publish',
        'rollback',
        'rollbackByOwner',
      ])
    ) throw coordinatorError('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE', 503)
    const adapter = /** @type {Record<string, Function>} */ (referenceTemplateAdapter)
    const repository = /** @type {Record<string, Function>} */ (referenceTemplateRepository)
    const attempt = claimed.attempts.at(-1)
    if (!attempt) throw coordinatorError('WORKBENCH_JOB_ATTEMPT_INVALID', 500)
    const owner = {
      jobId: claimed.jobId,
      attemptId: attempt.attemptId,
      generation: attempt.generation,
      inputFingerprint: claimed.privateInput.inputFingerprint,
    }
    const current = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(current, claimed.privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    const recoveredId = ['reference_template_staged', 'reference_template_committed']
      .includes(claimed.checkpoint?.stage)
      ? claimed.checkpoint?.data?.referenceTemplateId
      : null
    if (identifier(recoveredId)) {
      const existing = await repository.getStage({
        projectId: claimed.projectId,
        referenceTemplateId: recoveredId,
        ...owner,
      })
      if (existing) {
        onPublication(existing)
        return { resourceId: existing.referenceTemplateId, summary: '参考模板草案已生成' }
      }
    }
    await checkpoint('reference_template_inspecting', 10, {
      sourceKind: claimed.privateInput.sourceKind,
    })
    const generated = await adapter.generate({
      projectId: claimed.projectId,
      authorizationId: claimed.privateInput.authorizationId,
      assetId: claimed.privateInput.assetId,
      referenceAuthorizationId: claimed.privateInput.referenceAuthorizationId,
      templateSelectionRequest: clone(claimed.privateInput.templateSelectionRequest),
      signal,
    })
    signal.throwIfAborted()
    const afterGeneration = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(afterGeneration, claimed.privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    const stored = await repository.stageGenerated({
      projectId: claimed.projectId,
      ...owner,
      generated,
    })
    if (!stored.owned && stored.publication !== 'committed') {
      throw coordinatorError('REFERENCE_TEMPLATE_PENDING_CONFLICT', 409)
    }
    onPublication(stored)
    await checkpoint('reference_template_staged', 95, {
      referenceTemplateId: stored.referenceTemplateId,
    })
    const afterStage = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(afterStage, claimed.privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    return { resourceId: stored.referenceTemplateId, summary: '参考模板草案已生成' }
  }

  /**
   * @param {Record<string, any>} claimed
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   */
  const runJianyingDraftExport = async (claimed, signal, checkpoint) => {
    if (
      !hasMethods(jianyingDraftCapability, ['exportDraft', 'cleanupDraft', 'commitDraft'])
    ) throw coordinatorError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE', 503)
    const capability = /** @type {Record<string, Function>} */ (jianyingDraftCapability)
    const writerJobId = jianyingWriterAttemptId(claimed)
    const current = await projectRepository.get(claimed.projectId)
    if (!inputStillCurrent(current, claimed.privateInput)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    const frozenTimeline = await assertFrozenTimelineIdentity(claimed.privateInput)
    if (
      claimed.privateInput.editorBound === true &&
      !await resolveEditorBoundChildOwnership(claimed, frozenTimeline)
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_CHILD_BINDING_INVALID', 409)
    }
    /** @type {Record<string, any>} */
    let selectedPlan
    /** @type {Record<string, any> | null} */
    let editorTimeline = null
    if (claimed.privateInput.editorBound === true) {
      if (!richTimelineRepository) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING', 503)
      }
      const timeline = await richTimelineRepository.getRevisionByFingerprint({
        projectId: claimed.projectId,
        timelineId: claimed.privateInput.timelineId,
        revision: claimed.privateInput.timelineRevision,
        revisionFingerprint: claimed.privateInput.timelineRevisionFingerprint,
      })
      if (
        !timeline ||
        timeline.status !== 'finalized' ||
        timeline.contentFingerprint !== claimed.privateInput.timelineContentFingerprint
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
      }
      editorTimeline = timeline
      selectedPlan = editPlanFromEditorTimeline(timeline, {
        projectId: claimed.projectId,
        planId: claimed.privateInput.planId,
        createdAt: timeline.createdAt,
      })
      if (fingerprint(selectedPlan) !== claimed.privateInput.editPlanFingerprint) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
      }
    } else {
    const plan = await editPlanRepository.getFinalized({
      projectId: claimed.projectId,
      planId: claimed.privateInput.planId,
    })
    if (
      plan?.status !== 'finalized' ||
      !isEditPlan(plan.final) ||
      fingerprint(plan.final) !== claimed.privateInput.editPlanFingerprint
    ) throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 500)
      selectedPlan = applyPrivateSelections(
        plan.final,
        claimed.privateInput.selections,
      )
    }
    const templateAudit = {
      templateFingerprint: claimed.privateInput.templateGuidance?.fingerprint ?? null,
      templateRevision: claimed.privateInput.templateGuidance?.revision ?? null,
    }
    /** @param {string} stage @param {number} progressPercent @param {Record<string, any>} data */
    const auditedCheckpoint = (stage, progressPercent, data) =>
      checkpoint(stage, progressPercent, { ...clone(data), ...templateAudit })
    signal.throwIfAborted()
    await auditedCheckpoint('jianying_draft_preflight', 10, {})
    const resolvedEditorMaterials = editorTimeline
      ? await resolveEditorTimelineSources(
          { projectId: claimed.projectId, authorizationId: claimed.privateInput.authorizationId },
          editorTimelineSelectionsFrom(editorTimeline).map((/** @type {{candidateId: string, sceneId: string, assetId: string, startUs: number, durationUs: number}} */ selection) => ({
            candidateId: selection.candidateId,
            sceneId: selection.sceneId,
            assetId: selection.assetId,
            start: selection.startUs / 1_000_000,
            end: (selection.startUs + selection.durationUs) / 1_000_000,
          })),
          signal,
        )
      : null
    const result = await capability.exportDraft({
      projectId: claimed.projectId,
      projectName: current.name,
      jobId: writerJobId,
      authorizationId: claimed.privateInput.authorizationId ?? null,
      brief: clone(claimed.privateInput.brief),
      editPlan: selectedPlan,
      ...(resolvedEditorMaterials ? { resolvedMaterials: resolvedEditorMaterials } : {}),
      templateBinding: clone(claimed.privateInput.templateBinding),
      templateGuidance: clone(claimed.privateInput.templateGuidance),
      overlayAssignments: await resolveExportOverlayAssignments({
        brief: claimed.privateInput.brief,
        packaging: claimed.privateInput.brief?.packaging,
        templateGuidance: claimed.privateInput.templateGuidance,
        editPlan: selectedPlan,
        projectId: claimed.projectId,
        signal,
      }),
      ...(frozenTimeline
        ? {
            richTimeline: clone(frozenTimeline),
          }
        : {}),
      ...(editorTimeline
        ? {
            editorBound: true,
            richTimeline: clone(editorTimeline),
          }
        : {}),
      signal,
      checkpoint: auditedCheckpoint,
    })
    if (
      !isRecord(result) ||
      !draftIdentifier(result.draftId) ||
      typeof result.outputFingerprint !== 'string' ||
      !/^[a-f0-9]{64}$/u.test(result.outputFingerprint) ||
      !publicText(result.summary, 1000) ||
      result.handoffMode !== 'manual_open_required' ||
      result.desktopOpened !== false ||
      !publicText(result.draftLabel, 180) ||
      !publicText(result.manualOpenHint, 300)
    ) throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    const writerDegradations = normalizeWriterDegradations(result.writerDegradations)
    const writerProjectionFingerprint = result.writerProjectionFingerprint ?? null
    if (
      (writerProjectionFingerprint !== null &&
        (typeof writerProjectionFingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(writerProjectionFingerprint))) ||
      (writerDegradations.length > 0 && writerProjectionFingerprint === null)
    ) throw coordinatorError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    const writerAudit = {
      writerProjectionFingerprint,
      writerDegradationCount: writerDegradations.length,
      writerDegradationCapabilities: [...new Set(writerDegradations.map((entry) => entry.from))].sort(),
    }
    const auditedOutputFingerprint = fingerprint({
      providerOutputFingerprint: result.outputFingerprint,
      planId: claimed.privateInput.planId,
      writerProjectionFingerprint,
      writerDegradations,
      ...templateAudit,
    })
    await auditedCheckpoint('jianying_draft_verified', 95, {
      draftId: result.draftId,
      outputFingerprint: auditedOutputFingerprint,
      ...writerAudit,
    })
    signal.throwIfAborted()
    const afterExport = await projectRepository.get(claimed.projectId)
    if (
      !inputStillCurrent(afterExport, claimed.privateInput) ||
      !(await editorTimelineStillCurrent(claimed.privateInput))
    ) {
      await capability.cleanupDraft({
        projectId: claimed.projectId,
        jobId: writerJobId,
        draftId: result.draftId,
      })
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    await saveProjectIfCurrent(afterExport, {
      ...clone(afterExport),
      delivery: {
        ...clone(afterExport.delivery),
        template: {
          status: 'confirmed',
          name: claimed.privateInput.templateBinding?.label ?? '无模板自动创作',
          version: claimed.privateInput.templateGuidance
            ? `revision ${claimed.privateInput.templateGuidance.revision}`
            : 'automatic',
          reason: claimed.privateInput.templateGuidance
            ? '使用项目不可变模板绑定快照生成。'
            : '项目未绑定模板，使用自动创作默认规则生成。',
        },
        preflight: {
          status: 'ready',
          checkedAt: nowIso(),
          checks: [
            { label: '分镜完整性', status: 'pass' },
            { label: '模板绑定快照', status: 'pass' },
            { label: '素材与音频授权', status: 'pass' },
            { label: '草稿结构', status: 'pass' },
          ],
        },
        exportJob: {
          id: claimed.jobId,
          state: 'ready_to_open',
          progressPercent: 100,
          recoverable: false,
          error: null,
          result: {
            draftLabel: result.draftLabel,
            outputFingerprint: auditedOutputFingerprint,
            handoffMode: result.handoffMode,
            desktopOpened: result.desktopOpened,
            manualOpenHint: result.manualOpenHint,
            ...(writerProjectionFingerprint ? { writerProjectionFingerprint } : {}),
            ...(writerDegradations.length > 0 ? { writerDegradations: clone(writerDegradations) } : {}),
          },
        },
      },
      currentStage: 'delivery',
      updatedAt: nowIso(),
    })
    // Publish then re-check: outer catch cleans draft + rolls back delivery.
    if (!(await editorTimelineStillCurrent(claimed.privateInput))) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
    }
    await auditedCheckpoint('jianying_draft_published', 100, {
      draftId: result.draftId,
      outputFingerprint: auditedOutputFingerprint,
      ...writerAudit,
    })
    return {
      resourceId: result.draftId,
      summary: result.summary,
      outputFingerprint: auditedOutputFingerprint,
      ...(writerProjectionFingerprint ? { writerProjectionFingerprint } : {}),
      ...(writerDegradations.length > 0 ? { writerDegradations: clone(writerDegradations) } : {}),
      ...templateAudit,
    }
  }

  /**
   * @param {{projectId: string, jobId: string}} identity
   * @param {{controller: AbortController | null, claimed: Record<string, any> | null, promise: Promise<void> | null}} worker
   */
  const run = async (identity, worker) => {
    const key = keyOf(identity.projectId, identity.jobId)
    const userController = new AbortController()
    worker.controller = userController
    let claimed
    try {
      const beforeClaim = await jobRepository.get(identity.projectId, identity.jobId)
      if (!beforeClaim || terminalStatuses.has(beforeClaim.status)) {
        active.delete(key)
        return
      }
      if (beforeClaim.status === 'cancelling') {
        await finishCancellation(beforeClaim)
        active.delete(key)
        return
      }
      const claimedAt = new Date(now())
      claimed = await jobRepository.claim({
        ...identity,
        ownerId,
        leaseDurationMs,
        now: claimedAt.toISOString(),
        deadlineAt: beforeClaim.type === 'material_analysis'
          ? null
          : new Date(claimedAt.getTime() + jobTimeoutMs).toISOString(),
      })
    } catch (error) {
      active.delete(key)
      const code = errorCode(error)
      if (code && ['WORKBENCH_JOB_LEASE_ACTIVE', 'WORKBENCH_JOB_NOT_CLAIMABLE'].includes(code)) return
      throw error
    }
    const attempt = claimed.attempts.at(-1)
    const referenceOwnerInput = {
      jobId: claimed.jobId,
      attemptId: attempt.attemptId,
      generation: attempt.generation,
      inputFingerprint: claimed.privateInput.inputFingerprint,
    }
    const leaseLostController = new AbortController()
    const deadlineController = new AbortController()
    /** @type {ReturnType<typeof setTimeout> | null} */
    let deadlineTimer = null
    if (attempt.deadlineAt !== null) {
      const remainingDeadlineMs = Date.parse(attempt.deadlineAt) - new Date(now()).getTime()
      if (remainingDeadlineMs <= 0) {
        deadlineController.abort(coordinatorError('WORKBENCH_JOB_TIMED_OUT', 408))
      } else {
        deadlineTimer = setTimeout(() => {
          deadlineController.abort(coordinatorError('WORKBENCH_JOB_TIMED_OUT', 408))
        }, remainingDeadlineMs)
        deadlineTimer.unref?.()
      }
    }
    const deadlineSignal = deadlineController.signal
    const signal = AbortSignal.any([
      userController.signal,
      shutdownController.signal,
      deadlineSignal,
      leaseLostController.signal,
    ])
    worker.claimed = claimed
    let renewing = false
    const heartbeat = setInterval(async () => {
      if (renewing || signal.aborted) return
      renewing = true
      try {
        await jobRepository.renewLease({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          leaseDurationMs,
          renewedAt: nowIso(),
        })
      } catch {
        leaseLostController.abort(coordinatorError('WORKBENCH_JOB_LEASE_LOST', 409))
      } finally {
        renewing = false
      }
    }, heartbeatIntervalMs)
    heartbeat.unref?.()
    /** @param {string} stage @param {number} progressPercent @param {Record<string, any>} data */
    const checkpoint = async (stage, progressPercent, data) => {
      signal.throwIfAborted()
      try {
        await jobRepository.saveCheckpoint({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          checkpoint: {
            generation: attempt.generation,
            stage,
            progressPercent,
            updatedAt: nowIso(),
            data,
          },
        })
      } catch (error) {
        if (errorCode(error) === 'WORKBENCH_JOB_LEASE_FENCED') {
          leaseLostController.abort(coordinatorError('WORKBENCH_JOB_LEASE_LOST', 409))
        }
        throw error
      }
    }
    /** @param {string} currentKey */
    const collectPriorityJobTypes = async (currentKey) => {
      const jobTypes = new Set()
      for (const [otherKey, otherWorker] of active.entries()) {
        if (otherKey === currentKey) continue
        const otherType = otherWorker.claimed?.type
        if (MATERIAL_ANALYSIS_PRIORITY_JOB_TYPES.has(String(otherType))) {
          jobTypes.add(String(otherType))
        }
      }
      for (const [otherKey, queuedIdentity] of pending.entries()) {
        if (otherKey === currentKey) continue
        const queuedJob = await jobRepository.get(queuedIdentity.projectId, queuedIdentity.jobId).catch(() => null)
        if (
          queuedJob &&
          ['queued', 'running', 'cancelling'].includes(queuedJob.status) &&
          MATERIAL_ANALYSIS_PRIORITY_JOB_TYPES.has(String(queuedJob.type))
        ) {
          jobTypes.add(String(queuedJob.type))
        }
      }
      return [...jobTypes]
    }
    /**
     * @param {{
     *   initialMaterials: Record<string, any>,
     *   progressPublished: boolean,
     *   progressPercent: number,
     *   detail: string,
     * }} input
     * @returns {Promise<{released: true, summary: string} | null>}
     */
    const maybePauseMaterialAnalysis = async (input) => {
      if (claimed.type !== 'material_analysis') return null
      const assessment = await materialAnalysisRunGovernor.inspect({
        activeJobTypes: await collectPriorityJobTypes(key),
        runtimeRoot: materialAnalysisRuntimeRoot,
        tempRoot: materialAnalysisTempRoot,
      })
      if (!assessment.pause) return null
      await checkpoint('material_analysis_paused', Math.max(0, Math.min(89, input.progressPercent)), {
        detail: assessment.detail ?? input.detail,
        reason: assessment.reason,
      })
      const preserveInitialReady =
        input.progressPublished !== true &&
        input.initialMaterials?.analysisStatus === 'ready' &&
        Number.isFinite(input.initialMaterials?.total) &&
        input.initialMaterials.total > 0 &&
        input.initialMaterials.analyzed === input.initialMaterials.total &&
        input.initialMaterials.failed === 0 &&
        Array.isArray(input.initialMaterials.assets) &&
        input.initialMaterials.assets.length > 0
      await saveMaterialUpdate(claimed, (current) => {
        if (current.materials.analysisStatus !== 'analyzing') return null
        return {
          ...clone(current),
          materials: preserveInitialReady
            ? {
                ...clone(input.initialMaterials),
                analysisProgress: null,
              }
            : {
                ...clone(current.materials),
                queued: Math.max(0, current.materials.total - current.materials.analyzed),
                failed: 0,
                analysisStatus: 'queued',
                analysisProgress: null,
              },
          updatedAt: nowIso(),
        }
      }).catch((error) => {
        if (errorCode(error) !== 'WORKBENCH_JOB_INPUT_SUPERSEDED') throw error
      })
      await jobRepository.releaseForShutdown({
        projectId: claimed.projectId,
        jobId: claimed.jobId,
        attemptId: attempt.attemptId,
        generation: attempt.generation,
        leaseToken: attempt.lease.token,
        releasedAt: nowIso(),
        resetDeadline: true,
      })
      return {
        released: true,
        summary: assessment.detail ?? input.detail,
      }
    }
    /** @type {Record<string, any> | null} */
    let executionResult = null
    /** @type {any} */
    let referencePublication = null
    try {
      switch (claimed.type) {
        case 'material_analysis':
          executionResult = await runMaterialAnalysis(claimed, signal, checkpoint, maybePauseMaterialAnalysis)
          if (executionResult?.released === true) {
            scheduleMaterialResume(claimed)
            return
          }
          materialResumeAttempts.delete(key)
          break
        case 'storyboard_generation':
          executionResult = await runStoryboard(claimed, signal, checkpoint)
          break
        case 'preview_generation':
          executionResult = await runPreview(claimed, signal, checkpoint)
          break
        case 'reference_template_generation':
          executionResult = await runReferenceTemplate(
            claimed,
            signal,
            checkpoint,
            (/** @type {{referenceTemplateId: string, publication: string, owned: boolean}} */ publication) => {
              referencePublication = publication
            },
          )
          break
        case 'jianying_draft_export':
          executionResult = await runJianyingDraftExport(claimed, signal, checkpoint)
          break
        case EDITOR_JOB_TYPE:
          executionResult = await runEditorAgent(claimed, signal, checkpoint)
          break
        default:
          throw coordinatorError('WORKBENCH_JOB_TYPE_UNSUPPORTED', 400)
      }
      signal.throwIfAborted()
      const latestBeforeFinish = await jobRepository.get(claimed.projectId, claimed.jobId)
      if (latestBeforeFinish?.status === 'cancelling' || latestBeforeFinish?.cancelRequestedAt) {
        if (claimed.type === 'preview_generation' && executionResult?.resourceId) {
          await rollbackPreview(claimed.projectId, executionResult.resourceId)
        }
        if (claimed.type === 'reference_template_generation') {
          await /** @type {Record<string, Function>} */ (referenceTemplateRepository).rollbackByOwner({
            projectId: claimed.projectId,
            jobId: claimed.jobId,
            attemptId: attempt.attemptId,
            generation: attempt.generation,
          })
          referencePublication = null
        }
        if (claimed.type === 'jianying_draft_export' && executionResult?.resourceId) {
          await /** @type {Record<string, Function>} */ (jianyingDraftCapability).cleanupDraft({
            projectId: claimed.projectId,
            jobId: jianyingWriterAttemptId(claimed),
            draftId: executionResult.resourceId,
          })
          await rollbackJianyingDelivery(claimed.projectId, claimed.jobId)
        }
        await restoreEditorParentIfCurrent(claimed)
        await jobRepository.finish({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          status: 'cancelled',
          finishedAt: nowIso(),
          result: null,
          error: null,
        })
      } else {
        if (claimed.type === 'reference_template_generation') {
          const current = await projectRepository.get(claimed.projectId)
          if (!inputStillCurrent(current, claimed.privateInput)) {
            throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
          }
          signal.throwIfAborted()
          if (referencePublication?.owned && referencePublication.publication === 'staged') {
            await /** @type {Record<string, Function>} */ (referenceTemplateRepository).commit({
              projectId: claimed.projectId,
              referenceTemplateId: referencePublication.referenceTemplateId,
              ...referenceOwnerInput,
            })
            referencePublication.publication = 'prepared'
          }
          signal.throwIfAborted()
        }
        if (claimed.type === 'jianying_draft_export') {
          if (!(await editorTimelineStillCurrent(claimed.privateInput))) {
            throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
          }
          const committed = await /** @type {Record<string, Function>} */ (jianyingDraftCapability).commitDraft({
            projectId: claimed.projectId,
            jobId: jianyingWriterAttemptId(claimed),
            draftId: executionResult?.resourceId,
          })
          if (committed !== true) {
            throw coordinatorError('WORKBENCH_JIANYING_COMMIT_FAILED', 500)
          }
          // Commit then re-check: catch cleans draft + rolls back delivery.
          if (!(await editorTimelineStillCurrent(claimed.privateInput))) {
            throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
          }
        }
        await jobRepository.finish({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          status: 'succeeded',
          finishedAt: nowIso(),
          result: executionResult,
          error: null,
        })
        if (
          claimed.type === EDITOR_JOB_TYPE &&
          identifier(executionResult?.timelineId) &&
          Number.isInteger(executionResult?.timelineRevision)
        ) {
          try {
            const current = await projectRepository.get(claimed.projectId)
            if (current) {
              await saveProjectIfCurrent(current, {
                ...clone(current),
                editor: {
                  timelineId: executionResult.timelineId,
                  timelineRevision: executionResult.timelineRevision,
                },
                ...(current.currentStage === 'storyboard' ? { currentStage: 'editor' } : {}),
                updatedAt: nowIso(),
              })
            }
          } catch (error) {
            if (errorCode(error) !== 'WORKBENCH_JOB_INPUT_SUPERSEDED') throw error
          }
        }
        if (claimed.type === 'storyboard_generation') {
          await maybeCreateAutomaticCreativeEditorJob(claimed, executionResult)
        }
        if (
          claimed.type === 'reference_template_generation' &&
          referencePublication?.owned &&
          referencePublication.publication === 'prepared'
        ) {
          await /** @type {Record<string, Function>} */ (referenceTemplateRepository).publish({
            projectId: claimed.projectId,
            referenceTemplateId: referencePublication.referenceTemplateId,
            ...referenceOwnerInput,
          })
          referencePublication.publication = 'committed'
        }
      }
    } catch (error) {
      const latest = await jobRepository.get(claimed.projectId, claimed.jobId)
      if (latest?.status === 'succeeded' && claimed.type === 'jianying_draft_export') {
        await /** @type {Record<string, Function>} */ (jianyingDraftCapability).commitDraft({
          projectId: claimed.projectId,
          jobId: jianyingWriterAttemptId(claimed),
          draftId: executionResult?.resourceId,
        }).catch(() => {})
        return
      }
      if (
        latest?.status === 'succeeded' &&
        claimed.type === 'reference_template_generation' &&
        referencePublication?.owned
      ) {
        await /** @type {Record<string, Function>} */ (referenceTemplateRepository).publish({
          projectId: claimed.projectId,
          referenceTemplateId: referencePublication.referenceTemplateId,
          ...referenceOwnerInput,
        }).catch(() => {})
        return
      }
      if (shutdownController.signal.aborted) {
        if (claimed.type === 'reference_template_generation') {
          await /** @type {Record<string, Function>} */ (referenceTemplateRepository).rollbackByOwner({
            projectId: claimed.projectId,
            jobId: claimed.jobId,
            attemptId: attempt.attemptId,
            generation: attempt.generation,
          }).catch(() => {})
        }
        if (claimed.type === 'jianying_draft_export') {
          await /** @type {Record<string, Function>} */ (jianyingDraftCapability).cleanupDraft({
            projectId: claimed.projectId,
            jobId: jianyingWriterAttemptId(claimed),
          }).catch(() => {})
          await rollbackJianyingDelivery(claimed.projectId, claimed.jobId).catch(() => {})
        }
        await jobRepository.releaseForShutdown({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
          leaseToken: attempt.lease.token,
          releasedAt: nowIso(),
        }).catch(() => {})
        return
      }
      const cancellationRequested = userController.signal.aborted ||
        latest?.status === 'cancelling' ||
        Boolean(latest?.cancelRequestedAt)
      if (
        (leaseLostController.signal.aborted || errorCode(error) === 'WORKBENCH_JOB_LEASE_FENCED') &&
        !cancellationRequested
      ) return
      if (claimed.type === 'reference_template_generation') {
        await /** @type {Record<string, Function>} */ (referenceTemplateRepository).rollbackByOwner({
          projectId: claimed.projectId,
          jobId: claimed.jobId,
          attemptId: attempt.attemptId,
          generation: attempt.generation,
        }).catch(() => {})
        referencePublication = null
      }
      if (claimed.type === 'jianying_draft_export') {
        await /** @type {Record<string, Function>} */ (jianyingDraftCapability).cleanupDraft({
          projectId: claimed.projectId,
          jobId: jianyingWriterAttemptId(claimed),
          draftId: executionResult?.resourceId,
        }).catch(() => {})
        await rollbackJianyingDelivery(claimed.projectId, claimed.jobId).catch(() => {})
      }
      await restoreEditorParentIfCurrent(claimed).catch(() => {})
      const cancelled = cancellationRequested ||
        errorCode(error) === 'WORKBENCH_JOB_FINISH_INVALID'
      const timedOut = deadlineSignal.aborted
      const code = errorCode(error)
      if (
        claimed.type === 'preview_generation' &&
        executionResult?.resourceId &&
        (cancelled || timedOut)
      ) {
        await rollbackPreview(claimed.projectId, executionResult.resourceId)
      }
      logger({
        event: 'workbench_job_attempt_failed',
        jobType: claimed.type,
        code: code ?? 'WORKBENCH_UNKNOWN_FAILURE',
        stage: latest?.checkpoint?.stage ?? 'accepted',
      })
      const status = cancelled ? 'cancelled' : timedOut ? 'timed_out' : 'failed'
      const safeFailure = cancelled
        ? null
        : timedOut
          ? publicError('WORKBENCH_JOB_TIMED_OUT')
          : code === 'LLM_CONFIGURATION_REQUIRED'
            ? publicError(code, false)
            : code === 'WORKBENCH_JOB_INPUT_SUPERSEDED' ||
              code === 'WORKBENCH_EDITOR_CHILD_BINDING_INVALID' ||
              code === 'WORKBENCH_NARRATION_MATERIAL_DURATION_INSUFFICIENT' ||
              code === 'WORKBENCH_NARRATION_ASSET_REQUIRED' ||
              code === 'WORKBENCH_NARRATION_SCENE_BOUND_REQUIRED' ||
              code === 'WORKBENCH_NARRATION_SCENE_REUSE_FORBIDDEN' ||
              code === 'WORKBENCH_BGM_AUTHORIZATION_REQUIRED' ||
              code === 'SHORT_VIDEO_FACTORY_MATERIAL_DURATION_INSUFFICIENT' ||
              code === 'SHORT_VIDEO_FACTORY_SCRIPT_TOO_LONG'
            ? publicError(
                code === 'SHORT_VIDEO_FACTORY_MATERIAL_DURATION_INSUFFICIENT'
                  ? 'WORKBENCH_NARRATION_MATERIAL_DURATION_INSUFFICIENT'
                  : code === 'SHORT_VIDEO_FACTORY_SCRIPT_TOO_LONG'
                    ? 'WORKBENCH_SCRIPT_TOO_LONG'
                    : code,
              )
            : code === 'WORKBENCH_EDITOR_AGENT_REGISTRY_MISMATCH' ||
                code === 'WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID' ||
                code === 'WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE' ||
                code === 'WORKBENCH_EDITOR_SEMANTIC_MATCHING_REQUIRED' ||
                code === 'WORKBENCH_EDITOR_SEMANTIC_MATCHING_UNSUPPORTED' ||
                code === 'WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING' ||
                code === 'WORKBENCH_EDITOR_AGENT_UNAVAILABLE' ||
                code === 'WORKBENCH_EDITOR_BGM_AUTHORIZATION_REQUIRED' ||
                code === 'WORKBENCH_EDITOR_BASE_TIMELINE_NOT_FOUND' ||
                code === 'WORKBENCH_EDITOR_BASE_TIMELINE_STALE' ||
                code === 'WORKBENCH_EDITOR_OUTPUT_IDENTITY_INVALID' ||
                code === 'EDITOR_SEMANTIC_MATCHING_REQUIRED' ||
                code === 'EDITOR_CHECKPOINT_INVALID' ||
                code === 'EDITOR_CHECKPOINT_PRIVATE_REFERENCE'
              ? publicError(
                code === 'EDITOR_CHECKPOINT_INVALID' ||
                  code === 'EDITOR_CHECKPOINT_PRIVATE_REFERENCE'
                  ? 'WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID'
                  : code === 'EDITOR_SEMANTIC_MATCHING_REQUIRED'
                    ? 'WORKBENCH_EDITOR_SEMANTIC_MATCHING_REQUIRED'
                    : code,
              )
            : code === 'WORKBENCH_CAPABILITY_RESPONSE_INVALID' ||
                code === 'WORKBENCH_DIRECTOR_RESPONSE_INVALID'
              ? publicError(code, false)
              : claimed.type === 'reference_template_generation' &&
                  typeof code === 'string' &&
                  code.startsWith('REFERENCE_TEMPLATE_')
                ? publicError(code)
              : claimed.type === 'jianying_draft_export' &&
                  typeof code === 'string' &&
                  jianyingDraftPublicErrorCodes.has(code)
                ? publicError(code)
              : claimed.type === 'storyboard_generation' &&
                  typeof code === 'string' &&
                  (isJianyingPresetNarrationPublicErrorCode(code) ||
                    code === 'MATERIAL_ANALYSIS_RESCAN_REQUIRED' ||
                    code === 'WORKBENCH_RICH_TIMELINE_SHADOW_INVALID' ||
                    code === 'WORKBENCH_LIBRARY_REFERENCE_UNAVAILABLE')
                ? publicError(code)
              : claimed.type === EDITOR_JOB_TYPE &&
                  typeof code === 'string' &&
                  code.startsWith('PACKAGING_TEXT_LAYOUT_')
                ? publicError(code)
              : publicError(
                claimed.type === 'material_analysis'
                  ? 'WORKBENCH_MATERIAL_ANALYSIS_FAILED'
                  : claimed.type === 'storyboard_generation'
                    ? 'WORKBENCH_STORYBOARD_GENERATION_FAILED'
                    : claimed.type === 'preview_generation' &&
                        typeof code === 'string' &&
                        (code.startsWith('VID004_') || code.startsWith('SHORT_VIDEO_FACTORY_'))
                      ? code
                    : claimed.type === 'preview_generation'
                      ? 'WORKBENCH_PREVIEW_GENERATION_FAILED'
                    : claimed.type === EDITOR_JOB_TYPE
                      ? 'WORKBENCH_EDITOR_AGENT_FAILED'
                      : claimed.type === 'reference_template_generation'
                        ? 'WORKBENCH_REFERENCE_TEMPLATE_GENERATION_FAILED'
                        : 'WORKBENCH_JIANYING_EXPORT_FAILED',
              )
      if (claimed.type === 'material_analysis') {
        await settleMaterialProgress(claimed, status)
      }
      await jobRepository.finish({
        projectId: claimed.projectId,
        jobId: claimed.jobId,
        attemptId: attempt.attemptId,
        generation: attempt.generation,
        leaseToken: attempt.lease.token,
        status,
        finishedAt: nowIso(),
        result: null,
        error: safeFailure,
      }).catch(() => {})
    } finally {
      if (deadlineTimer) clearTimeout(deadlineTimer)
      clearInterval(heartbeat)
      active.delete(key)
      if (
        claimed.type === EDITOR_JOB_TYPE &&
        started &&
        !shutdownController.signal.aborted
      ) {
        await recoverAutomaticCreativeContinuations().catch((error) => {
          logger({
            event: 'creative_auto_editor_recovery_failed',
            code: errorCode(error) ?? 'WORKBENCH_UNKNOWN_FAILURE',
          })
        })
        const recoveryTimer = setTimeout(() => {
          if (!started || shutdownController.signal.aborted) return
          recoverAutomaticCreativeContinuations().catch((error) => {
            logger({
              event: 'creative_auto_editor_recovery_failed',
              code: errorCode(error) ?? 'WORKBENCH_UNKNOWN_FAILURE',
            })
          })
        }, 0)
        recoveryTimer.unref?.()
      }
    }
  }

  function drain() {
    drainPromise = drainPromise.then(async () => {
      while (started && active.size < concurrency && pending.size > 0) {
        const next = pending.entries().next()
        if (next.done) break
        const [key, identity] = next.value
        pending.delete(key)
        if (active.has(key)) continue
        /** @type {{controller: AbortController | null, claimed: Record<string, any> | null, promise: Promise<void> | null}} */
        const worker = { controller: null, claimed: null, promise: null }
        active.set(key, worker)
        const promise = run(identity, worker)
          .catch((error) => {
            logger({
              event: 'workbench_job_worker_failed',
              code: errorCode(error) ?? 'WORKBENCH_UNKNOWN_FAILURE',
              projectScoped: true,
            })
          })
          .finally(() => drain())
        worker.promise = promise
      }
    })
  }

  /** @param {unknown} input */
  const createJobUnserialized = async (input) => {
    if (
      !isRecord(input) ||
      !(
        Object.keys(input).sort().join('\u0000') ===
          ['idempotencyKey', 'projectId', 'type'].sort().join('\u0000') ||
        Object.keys(input).sort().join('\u0000') ===
          ['assetId', 'idempotencyKey', 'projectId', 'type'].sort().join('\u0000')
      ) ||
      !identifier(input.projectId) ||
      !identifier(input.idempotencyKey) ||
      !supportedTypes.has(input.type) ||
      (input.assetId !== undefined && (!identifier(input.assetId) || input.type !== 'material_analysis'))
    ) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    }
    const current = await projectRepository.get(input.projectId)
    if (!validProjectSnapshot(current)) {
      throw coordinatorError(current ? 'WORKBENCH_JOB_INPUT_INVALID' : 'WORKBENCH_PROJECT_NOT_FOUND', current ? 409 : 404)
    }
    if (input.type === 'storyboard_generation' && (
      !safeBrief(current.brief) ||
      !materialContentFingerprint(current.materials)
    )) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    const selections = input.type === 'preview_generation' ? previewSelections(current) : null
    if (
      input.type === 'preview_generation' &&
      (!safeBrief(current.brief) || selections === null)
    ) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    if (input.type === 'preview_generation') {
      await assertLegacyOutputMayProjectTimeline(input.projectId)
      const briefVoiceId = typeof current.brief?.voiceId === 'string' ? current.brief.voiceId.trim() : ''
      if (current.brief?.voiceover === 'required' && !briefVoiceId) {
        throw coordinatorError('WORKBENCH_VOICE_REQUIRED', 409)
      }
      const packaging = current.brief?.packaging
      if (
        packaging &&
        typeof packaging === 'object' &&
        packaging.bgm === 'local_authorized' &&
        !(typeof packaging.bgmAuthorizationId === 'string' && packaging.bgmAuthorizationId.trim())
      ) {
        throw coordinatorError('WORKBENCH_BGM_AUTHORIZATION_REQUIRED', 409)
      }
    }
    const bindingGuidance = createTemplateGuidance(current.templateBinding ?? null)
    const templateGuidance = input.type === 'preview_generation' && bindingGuidance
      ? adaptTemplateGuidanceToCount(
          bindingGuidance,
          /** @type {any[]} */ (selections).length,
        )
      : bindingGuidance
    if (input.type === 'preview_generation') {
      assertTemplateGuidanceExecutable(templateGuidance)
    }
    /** @type {Record<string, any> | null} */
    let frozenTimeline = null
    if (input.type === 'preview_generation' && richTimelineRepository) {
      const plan = await editPlanRepository.getFinalized({
        projectId: input.projectId,
        planId: current.storyboard.id,
      })
      if (plan?.status !== 'finalized' || !isEditPlan(plan.final)) {
        throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
      }
      const selectedPlan = applyPrivateSelections(plan.final, selections)
      frozenTimeline = await freezeFinalizedTimelineIdentity({
        projectId: input.projectId,
        authorizationId: current.materials.authorizationId,
        editPlan: selectedPlan,
        templateGuidance,
        brief: current.brief,
      })
    }
    /** @type {Record<string, any>} */
    /** @type {Record<string, any>} */
    const privateInput = {
      projectId: input.projectId,
      type: input.type,
      ...optionalAuthorizationInput(current.materials.authorizationId),
      ...(input.assetId ? { assetId: input.assetId } : {}),
      ...(input.type === 'storyboard_generation'
        ? {
            materialsContentFingerprint: materialContentFingerprint(current.materials),
            brief: clone(current.brief),
            briefFingerprint: fingerprint(current.brief),
            templateGuidance: clone(templateGuidance),
            templateBindingFingerprint: fingerprint(current.templateBinding ?? null),
            creativeAutoOutputs,
          }
        : {}),
      ...(input.type === 'preview_generation'
        ? {
            brief: clone(current.brief),
            briefFingerprint: fingerprint(current.brief),
            planId: current.storyboard.id,
            storyboardFingerprint: fingerprint(current.storyboard),
            templateGuidance: clone(templateGuidance),
            templateBindingFingerprint: fingerprint(current.templateBinding ?? null),
            selections,
            ...(frozenTimeline
              ? {
                  timelineId: frozenTimeline.timelineId,
                  timelineRevision: frozenTimeline.revision,
                  timelineRevisionFingerprint: frozenTimeline.revisionFingerprint,
                  timelineContentFingerprint: frozenTimeline.contentFingerprint,
                }
              : {}),
          }
        : {}),
    }
    const fingerprintInput = clone(privateInput)
    privateInput.inputFingerprint = fingerprint(fingerprintInput)
    const createdAt = nowIso()
    const job = assertJobRecord({
      jobId: createId('job'),
      projectId: input.projectId,
      idempotencyKey: input.idempotencyKey,
      type: input.type,
      status: 'queued',
      createdAt,
      updatedAt: createdAt,
      cancelRequestedAt: null,
      privateInput,
      attempts: [{
        attemptId: createId('attempt'),
        generation: 1,
        deadlineAt: null,
        status: 'queued',
        startedAt: null,
        finishedAt: null,
        lease: null,
        error: null,
      }],
      checkpoint: null,
      result: null,
      error: null,
    })
    const stored = input.type === 'material_analysis'
      ? await jobRepository.createOrGetExclusiveByType(job)
      : await jobRepository.createOrGet(job)
    enqueue(stored)
    return toPublicJobDto(stored)
  }

  /** @param {unknown} input */
  const createJob = async (input) => {
    if (isRecord(input) && input.type === 'material_analysis' && identifier(input.projectId)) {
      return withMaterialStateLock(input.projectId, () => createJobUnserialized(input))
    }
    return createJobUnserialized(input)
  }

  /** @param {unknown} input */
  const createReferenceTemplateJob = async (input) => {
    if (
      !isRecord(input) ||
      !(
        Object.keys(input).sort().join('\u0000') ===
        ['assetId', 'idempotencyKey', 'projectId', 'templateSelectionRequest'].sort().join('\u0000') ||
        Object.keys(input).sort().join('\u0000') ===
          ['idempotencyKey', 'projectId', 'referenceAuthorizationId', 'templateSelectionRequest'].sort().join('\u0000')
      ) ||
      !identifier(input.projectId) ||
      (input.assetId !== undefined && !identifier(input.assetId)) ||
      (input.referenceAuthorizationId !== undefined && !identifier(input.referenceAuthorizationId)) ||
      !identifier(input.idempotencyKey) ||
      !isTemplateSelectionRequest(input.templateSelectionRequest) ||
      input.templateSelectionRequest.project_id !== input.projectId
    ) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    if (
      !hasMethods(referenceTemplateAdapter, ['generate']) ||
      !hasMethods(referenceTemplateRepository, [
        'stageGenerated',
        'getStage',
        'commit',
        'publish',
        'rollback',
        'rollbackByOwner',
        'listPending',
        'get',
        'list',
        'review',
        'getApproved',
      ])
    ) throw coordinatorError('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE', 503)
    const current = await projectRepository.get(input.projectId)
    if (!validProjectSnapshot(current)) {
      throw coordinatorError(current ? 'WORKBENCH_JOB_INPUT_INVALID' : 'WORKBENCH_PROJECT_NOT_FOUND', current ? 409 : 404)
    }
    const assetsFingerprint = materialAssetsFingerprint(current)
    const usesReferenceAuthorization = identifier(input.referenceAuthorizationId)
    if (!usesReferenceAuthorization && (
      assetsFingerprint === null ||
      !current.materials.assets.some(
        (/** @type {Record<string, any>} */ asset) => asset?.id === input.assetId,
      )
    )) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    if (usesReferenceAuthorization && !safeBrief(current.brief)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    /** @type {Record<string, any>} */
    const privateInput = {
      projectId: input.projectId,
      type: 'reference_template_generation',
      authorizationId: current.materials.authorizationId,
      sourceKind: usesReferenceAuthorization ? 'authorization' : 'asset',
      ...(usesReferenceAuthorization
        ? {
            referenceAuthorizationId: input.referenceAuthorizationId,
            briefFingerprint: fingerprint(current.brief),
          }
        : {
      assetId: input.assetId,
            assetsFingerprint,
          }),
      templateSelectionRequest: clone(input.templateSelectionRequest),
      selectionRequestFingerprint: fingerprint(input.templateSelectionRequest),
    }
    privateInput.inputFingerprint = fingerprint(privateInput)
    const createdAt = nowIso()
    const job = assertJobRecord({
      jobId: createId('job'),
      projectId: input.projectId,
      idempotencyKey: input.idempotencyKey,
      type: 'reference_template_generation',
      status: 'queued',
      createdAt,
      updatedAt: createdAt,
      cancelRequestedAt: null,
      privateInput,
      attempts: [{
        attemptId: createId('attempt'),
        generation: 1,
        deadlineAt: null,
        status: 'queued',
        startedAt: null,
        finishedAt: null,
        lease: null,
        error: null,
      }],
      checkpoint: null,
      result: null,
      error: null,
    })
    const stored = await jobRepository.createOrGet(job)
    enqueue(stored)
    return toPublicJobDto(stored)
  }

  /**
   * @param {unknown} input
   * @param {Record<string, any> | null} [parentFence]
   */
  const createJianyingDraftJob = async (input, parentFence = null) => {
    if (
      !isRecord(input) ||
      !(
        Object.keys(input).sort().join('\u0000') ===
          ['idempotencyKey', 'projectId'].sort().join('\u0000') ||
        Object.keys(input).sort().join('\u0000') ===
          ['idempotencyKey', 'projectId', 'referenceTemplateId'].sort().join('\u0000')
      ) ||
      !identifier(input.projectId) ||
      (input.referenceTemplateId !== undefined && !identifier(input.referenceTemplateId)) ||
      !identifier(input.idempotencyKey)
    ) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    if (!parentFence && typeof jobRepository.getByIdempotencyKey === 'function') {
      const existing = await jobRepository.getByIdempotencyKey(
        input.projectId,
        input.idempotencyKey,
      )
      if (existing) {
        if (existing.type !== 'jianying_draft_export') {
          throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
        }
        await assertLegacyJianyingReplayStillValid(existing, input)
        return toPublicJobDto(existing)
      }
    }
    await assertLegacyOutputMayProjectTimeline(input.projectId)
    if (
      !hasMethods(jianyingDraftCapability, ['exportDraft', 'cleanupDraft', 'commitDraft'])
    ) throw coordinatorError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE', 503)
    const current = await projectRepository.get(input.projectId)
    if (
      !validProjectSnapshot(current) ||
      !safeBrief(current.brief) ||
      !isRecord(current.storyboard) ||
      !identifier(current.storyboard.id) ||
      current.preview?.status !== 'ready'
    ) throw coordinatorError(current ? 'WORKBENCH_JOB_INPUT_INVALID' : 'WORKBENCH_PROJECT_NOT_FOUND', current ? 409 : 404)
    const plan = await editPlanRepository.getFinalized({
      projectId: input.projectId,
      planId: current.storyboard.id,
    })
    if (plan?.status !== 'finalized' || !isEditPlan(plan.final)) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
    }
    const selections = previewSelections(current)
    if (!selections) {
      throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
    }
    const bindingGuidance = createTemplateGuidance(current.templateBinding ?? null)
    const templateGuidance = bindingGuidance
      ? adaptTemplateGuidanceToCount(bindingGuidance, selections.length)
      : null
    assertTemplateGuidanceExecutable(templateGuidance)
    const selectedPlan = applyPrivateSelections(plan.final, selections)
    const frozenTimeline = await freezeFinalizedTimelineIdentity({
      projectId: input.projectId,
      authorizationId: current.materials.authorizationId,
      editPlan: selectedPlan,
      templateGuidance,
      brief: current.brief,
    })
    /** @type {Record<string, any>} */
    const privateInput = {
      projectId: input.projectId,
      type: 'jianying_draft_export',
      ...optionalAuthorizationInput(current.materials.authorizationId),
      brief: clone(current.brief),
      briefFingerprint: fingerprint(current.brief),
      planId: current.storyboard.id,
      storyboardFingerprint: fingerprint(current.storyboard),
      templateBindingFingerprint: fingerprint(current.templateBinding ?? null),
      templateBinding: clone(current.templateBinding ?? null),
      templateGuidance: clone(templateGuidance),
      editPlanFingerprint: fingerprint(plan.final),
      selections,
      ...(frozenTimeline
        ? {
            timelineId: frozenTimeline.timelineId,
            timelineRevision: frozenTimeline.revision,
            timelineRevisionFingerprint: frozenTimeline.revisionFingerprint,
            timelineContentFingerprint: frozenTimeline.contentFingerprint,
          }
        : {}),
    }
    privateInput.inputFingerprint = fingerprint(privateInput)
    const createdAt = nowIso()
    const job = assertJobRecord({
      jobId: createId('job'),
      projectId: input.projectId,
      idempotencyKey: input.idempotencyKey,
      type: 'jianying_draft_export',
      status: 'queued',
      createdAt,
      updatedAt: createdAt,
      cancelRequestedAt: null,
      privateInput,
      attempts: [{
        attemptId: createId('attempt'),
        generation: 1,
        deadlineAt: null,
        status: 'queued',
        startedAt: null,
        finishedAt: null,
        lease: null,
        error: null,
      }],
      checkpoint: null,
      result: null,
      error: null,
    })
    const stored = parentFence
      ? await jobRepository.createOrGetFenced(parentFence, job)
      : await jobRepository.createOrGet(job)
    enqueue(stored)
    return toPublicJobDto(stored)
  }

  /**
   * @param {Record<string, any>} input
   * @param {Record<string, any> | null} parentFence
   */
  const createEditorTimelinePreviewJob = async (input, parentFence = null) => {
    if (!parentFence && typeof jobRepository.getByIdempotencyKey === 'function') {
      const existing = await jobRepository.getByIdempotencyKey(
        input.projectId,
        input.idempotencyKey,
      )
      if (existing) {
        if (existing.type !== 'preview_generation') {
          throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
        }
        await assertEditorBoundReplayStillValid(existing, input)
        return toPublicJobDto(existing)
      }
    }
    const current = await projectRepository.get(input.projectId)
    if (
      !validProjectSnapshot(current) ||
      !safeBrief(current.brief) ||
      !richTimelineRepository
    ) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    let pointer = await richTimelineRepository.getCurrent({ projectId: input.projectId })
    let timeline = pointer
      ? await richTimelineRepository.getRevision(pointer)
      : null
    const requestedTimeline = await richTimelineRepository.getRevision({
      projectId: input.projectId,
      timelineId: input.timelineId,
      revision: input.revision,
    })
    const requestedIsCurrent = Boolean(
      timeline && timeline.timelineId === input.timelineId &&
      timeline.revision === input.revision &&
      timeline.revisionFingerprint === input.revisionFingerprint,
    )
    if (!requestedIsCurrent) {
      if (
        !pointer ||
        !requestedTimeline || requestedTimeline.status !== 'finalized' ||
        requestedTimeline.source?.kind !== 'agent' ||
        requestedTimeline.revisionFingerprint !== input.revisionFingerprint
      ) throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
      await resolveHistoricalEditorTimelineOwnership(requestedTimeline)
      await richTimelineRepository.setCurrent({
        projectId: input.projectId,
        timelineId: requestedTimeline.timelineId,
        revision: requestedTimeline.revision,
        expectedCurrent: pointer,
      })
      timeline = requestedTimeline
    }
    if (
      !timeline || timeline.status !== 'finalized' ||
      timeline.timelineId !== input.timelineId ||
      timeline.revision !== input.revision ||
      timeline.revisionFingerprint !== input.revisionFingerprint
    ) throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
    const libraryReferenceOnly = Boolean(
      current && !current.storyboard && timelineUsesOnlyLibraryReferences(current, timeline),
    )
    if (!current.storyboard && !libraryReferenceOnly) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    const editorOwnership = requestedIsCurrent
      ? await resolveEditorTimelineOwnership(timeline, parentFence)
      : await resolveHistoricalEditorTimelineOwnership(timeline)
    const templateGuidance = createTemplateGuidance(current.templateBinding ?? null)
    const editorTimelineSelections = editorTimelineSelectionsFrom(timeline).map((
      /** @type {Record<string, any>} */ selection,
    ) => ({
      candidateId: selection.candidateId,
      startUs: selection.startUs,
      durationUs: selection.durationUs,
      assetId: selection.assetId,
      sceneId: selection.sceneId,
    }))
    const voiceoverSegments = editorTimelineVoiceoverSegments(timeline)
    /** @type {Record<string, any>} */
    const privateInput = {
      projectId: input.projectId,
      type: 'preview_generation',
      ...optionalAuthorizationInput(current.materials.authorizationId),
      brief: clone(current.brief),
      briefFingerprint: fingerprint(current.brief),
      planId: libraryReferenceOnly ? timeline.timelineId : current.storyboard.id,
      storyboardFingerprint: libraryReferenceOnly ? null : fingerprint(current.storyboard),
      ...(libraryReferenceOnly ? { libraryReferenceOnly: true } : {}),
      templateGuidance: clone(templateGuidance),
      templateBindingFingerprint: fingerprint(current.templateBinding ?? null),
      editorBound: true,
      ...editorOwnership,
      editorTimelineSelections,
      voiceoverSegments,
      selections: editorTimelineSelections.map((
        /** @type {Record<string, any>} */ selection,
        /** @type {number} */ index,
      ) => ({
        sentenceId: `editor-${index + 1}`,
        candidateId: selection.candidateId,
      })),
      timelineId: timeline.timelineId,
      timelineRevision: timeline.revision,
      timelineRevisionFingerprint: timeline.revisionFingerprint,
      timelineContentFingerprint: timeline.contentFingerprint,
    }
    privateInput.inputFingerprint = fingerprint(privateInput)
    const createdAt = nowIso()
    const job = assertJobRecord({
      jobId: createId('job'),
      projectId: input.projectId,
      idempotencyKey: input.idempotencyKey,
      type: 'preview_generation',
      status: 'queued',
      createdAt,
      updatedAt: createdAt,
      cancelRequestedAt: null,
      privateInput,
      attempts: [{
        attemptId: createId('attempt'),
        generation: 1,
        deadlineAt: null,
        status: 'queued',
        startedAt: null,
        finishedAt: null,
        lease: null,
        error: null,
      }],
      checkpoint: null,
      result: null,
      error: null,
    })
    const stored = parentFence
      ? await jobRepository.createOrGetFenced(parentFence, job)
      : await jobRepository.createOrGet(job)
    enqueue(stored)
    return toPublicJobDto(stored)
  }

  /**
   * @param {Record<string, any>} input
   * @param {Record<string, any> | null} parentFence
   */
  const createEditorTimelineExportJob = async (input, parentFence = null) => {
    if (!parentFence && typeof jobRepository.getByIdempotencyKey === 'function') {
      const existing = await jobRepository.getByIdempotencyKey(
        input.projectId,
        input.idempotencyKey,
      )
      if (existing) {
        if (existing.type !== 'jianying_draft_export') {
          throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
        }
        await assertEditorBoundReplayStillValid(existing, input)
        return toPublicJobDto(existing)
      }
    }
    if (
      !hasMethods(jianyingDraftCapability, ['exportDraft', 'cleanupDraft', 'commitDraft'])
    ) throw coordinatorError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE', 503)
    if (!richTimelineRepository) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING', 503)
    }
    const current = await projectRepository.get(input.projectId)
    if (
      !validProjectSnapshot(current) ||
      !safeBrief(current.brief) ||
      !richTimelineRepository
    ) {
      throw coordinatorError(
        current ? 'WORKBENCH_JOB_INPUT_INVALID' : 'WORKBENCH_PROJECT_NOT_FOUND',
        current ? 409 : 404,
      )
    }
    let pointer = await richTimelineRepository.getCurrent({ projectId: input.projectId })
    let timeline = pointer ? await richTimelineRepository.getRevision(pointer) : null
    const requestedTimeline = await richTimelineRepository.getRevision({
      projectId: input.projectId,
      timelineId: input.timelineId,
      revision: input.revision,
    })
    const requestedIsCurrent = Boolean(
      timeline && timeline.timelineId === input.timelineId &&
      timeline.revision === input.revision &&
      timeline.revisionFingerprint === input.revisionFingerprint,
    )
    if (!requestedIsCurrent) {
      if (
        !requestedTimeline || requestedTimeline.status !== 'finalized' ||
        requestedTimeline.source?.kind !== 'agent' ||
        requestedTimeline.revisionFingerprint !== input.revisionFingerprint
      ) throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
      await resolveEditorTimelineOwnership(requestedTimeline, parentFence, { allowHistoricalRecovery: true })
      await richTimelineRepository.setCurrent({
        projectId: input.projectId,
        timelineId: requestedTimeline.timelineId,
        revision: requestedTimeline.revision,
        expectedCurrent: pointer,
      })
      timeline = requestedTimeline
    }
    if (
      !timeline || timeline.status !== 'finalized' ||
      timeline.timelineId !== input.timelineId ||
      timeline.revision !== input.revision ||
      timeline.revisionFingerprint !== input.revisionFingerprint
    ) throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_SUPERSEDED', 409)
    const libraryReferenceOnly = Boolean(
      current && !current.storyboard && timelineUsesOnlyLibraryReferences(current, timeline),
    )
    if (!isRecord(current.storyboard) && !libraryReferenceOnly) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    if (!libraryReferenceOnly && !identifier(current.storyboard.id)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 409)
    }
    const editorOwnership = requestedIsCurrent
      ? await resolveEditorTimelineOwnership(timeline, parentFence)
      : await resolveHistoricalEditorTimelineOwnership(timeline)
    const editorTimelineSelections = editorTimelineSelectionsFrom(timeline)
    const voiceoverSegments = editorTimelineVoiceoverSegments(timeline)
    const createdAt = nowIso()
    const editPlan = editPlanFromEditorTimeline(timeline, {
      projectId: input.projectId,
      planId: libraryReferenceOnly ? timeline.timelineId : current.storyboard.id,
      createdAt: timeline.createdAt,
    })
    const bindingGuidance = createTemplateGuidance(current.templateBinding ?? null)
    const templateGuidance = bindingGuidance
      ? adaptTemplateGuidanceToCount(bindingGuidance, editPlan.items.length)
      : null
    assertTemplateGuidanceExecutable(templateGuidance)
    /** @type {Record<string, any>} */
    const privateInput = {
      projectId: input.projectId,
      type: 'jianying_draft_export',
      ...optionalAuthorizationInput(current.materials.authorizationId),
      brief: clone(current.brief),
      briefFingerprint: fingerprint(current.brief),
      planId: libraryReferenceOnly ? timeline.timelineId : current.storyboard.id,
      storyboardFingerprint: libraryReferenceOnly ? null : fingerprint(current.storyboard),
      ...(libraryReferenceOnly ? { libraryReferenceOnly: true } : {}),
      templateBindingFingerprint: fingerprint(current.templateBinding ?? null),
      templateBinding: clone(current.templateBinding ?? null),
      templateGuidance: clone(templateGuidance),
      editorBound: true,
      ...editorOwnership,
      editorTimelineSelections: editorTimelineSelections.map((
        /** @type {Record<string, any>} */ selection,
      ) => ({
        candidateId: selection.candidateId,
        startUs: selection.startUs,
        durationUs: selection.durationUs,
        assetId: selection.assetId,
        sceneId: selection.sceneId,
      })),
      voiceoverSegments,
      selections: editorTimelineSelections.map((
        /** @type {Record<string, any>} */ selection,
        /** @type {number} */ index,
      ) => ({
        sentenceId: `editor-${index + 1}`,
        candidateId: selection.candidateId,
      })),
      editPlanFingerprint: fingerprint(editPlan),
      timelineId: timeline.timelineId,
      timelineRevision: timeline.revision,
      timelineRevisionFingerprint: timeline.revisionFingerprint,
      timelineContentFingerprint: timeline.contentFingerprint,
    }
    privateInput.inputFingerprint = fingerprint(privateInput)
    const job = assertJobRecord({
      jobId: createId('job'),
      projectId: input.projectId,
      idempotencyKey: input.idempotencyKey,
      type: 'jianying_draft_export',
      status: 'queued',
      createdAt,
      updatedAt: createdAt,
      cancelRequestedAt: null,
      privateInput,
      attempts: [{
        attemptId: createId('attempt'),
        generation: 1,
        deadlineAt: null,
        status: 'queued',
        startedAt: null,
        finishedAt: null,
        lease: null,
        error: null,
      }],
      checkpoint: null,
      result: null,
      error: null,
    })
    const stored = parentFence
      ? await jobRepository.createOrGetFenced(parentFence, job)
      : await jobRepository.createOrGet(job)
    enqueue(stored)
    return toPublicJobDto(stored)
  }

  /**
   * @param {Record<string, any>} job
   * @param {AbortSignal} signal
   * @param {(stage: string, progressPercent: number, data: Record<string, any>) => Promise<void>} checkpoint
   */
  const runEditorAgent = async (job, signal, checkpoint) => {
    if (!llmGateway || typeof llmGateway.generate !== 'function') {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE', 503)
    }
    assertEditorInstruction(job.privateInput.editorInstruction)
    const attempt = job.attempts.at(-1)
    const recoveredData = isRecord(job.checkpoint?.data) ? job.checkpoint.data : null
    if (recoveredData?.frozen) {
      const frozen = recoveredData.frozen
      if (
        frozen.instructionFingerprint !== job.privateInput.instructionFingerprint ||
        frozen.baseTimelineFingerprint !== job.privateInput.baseTimelineFingerprint ||
        frozen.toolRegistryFingerprint !== job.privateInput.toolRegistryFingerprint ||
        frozen.capabilityRegistryFingerprint !== job.privateInput.capabilityRegistryFingerprint ||
        !Number.isSafeInteger(frozen.attemptGeneration) ||
        frozen.attemptGeneration > job.checkpoint.generation
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID', 409)
      }
    }
    let resumeExecutions = []
    try {
      resumeExecutions = Array.isArray(recoveredData?.committedExecutions)
        ? toEditorResumeCommittedExecutions(recoveredData.committedExecutions)
        : []
    } catch (error) {
      if (error instanceof EditorAgentContractError) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID', 409)
      }
      throw error
    }
    const recoveredPackagingApplication = resumeExecutions.find((execution) =>
      execution.tool === 'apply_packaging_recommendation') ?? null
    const baseTimelineIdentity = job.privateInput.editorInstruction.baseTimeline
    let baseRevision = null
    if (!richTimelineRepository) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING', 503)
    }
    if (baseTimelineIdentity) {
      baseRevision = await richTimelineRepository.getRevision({
        projectId: job.projectId,
        timelineId: baseTimelineIdentity.timelineId,
        revision: baseTimelineIdentity.revision,
      })
      if (!baseRevision) {
        throw coordinatorError('WORKBENCH_EDITOR_BASE_TIMELINE_NOT_FOUND', 409)
      }
      if (baseRevision.revisionFingerprint !== baseTimelineIdentity.revisionFingerprint) {
        throw coordinatorError('WORKBENCH_EDITOR_BASE_TIMELINE_STALE', 409)
      }
    }
    const requiredSemanticSegmentIds = job.privateInput.semanticCreate === true &&
      recoveredPackagingApplication === null
      ? baseRevision?.tracks
          ?.find((/** @type {Record<string, any>} */ track) =>
            track.kind === 'video' && track.role === 'primary')
          ?.segments
          ?.map((/** @type {Record<string, any>} */ segment) => segment.segmentId) ?? []
      : []
    const protectedSegmentIds = baseRevision?.tracks.flatMap(
      (/** @type {Record<string, any>} */ track) => track.segments
        .filter((/** @type {Record<string, any>} */ segment) => {
          const capabilityIds = [
            segment.capabilityId,
            ...(Array.isArray(segment.effects)
              ? segment.effects.map((/** @type {Record<string, any>} */ effect) => effect.capabilityId)
              : []),
          ]
          return capabilityIds.some((capabilityId) =>
            preservedEditorProductCapabilities.has(capabilityId))
        })
        .map((/** @type {Record<string, any>} */ segment) => segment.segmentId),
    ) ?? []
    if (
      job.privateInput.semanticCreate === true &&
      recoveredPackagingApplication === null &&
      (
        requiredSemanticSegmentIds.length === 0 ||
        requiredSemanticSegmentIds.length > EDITOR_BUDGETS.maxSearchMaterials
      )
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_SEMANTIC_MATCHING_UNSUPPORTED', 409)
    }
    if (!hasMethods(materialAnalysisProvider, ['searchCandidates', 'inspectCandidate'])) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING', 503)
    }
    const materialTools = createEditorMaterialTools({
      projectRepository,
      materialAnalysisProvider: /** @type {{searchCandidates: Function, inspectCandidate: Function}} */ (
        materialAnalysisProvider
      ),
      listSearchScopes: typeof listStoryboardSearchScopes === 'function'
        ? (projectId) => listStoryboardSearchScopes(projectId)
        : null,
      resolveInspectScope: typeof resolveMaterialLibrarySceneBinding === 'function'
        ? async (projectId, candidateId) => {
            const binding = await resolveMaterialLibrarySceneBinding({
              projectId,
              sceneId: candidateId,
            })
            if (!identifier(binding?.projectId) || !identifier(binding?.authorizationId)) {
              return null
            }
            return {
              projectId: binding.projectId,
              authorizationId: binding.authorizationId,
            }
          }
        : null,
    })
    const capabilityRegistry = createEditorCapabilityRegistry(editorCapabilityOptions)
    const editorFence = {
      projectId: job.projectId,
      jobId: job.jobId,
      instructionFingerprint: job.privateInput.instructionFingerprint,
      attemptId: attempt.attemptId,
      generation: attempt.generation,
      leaseToken: attempt.lease.token,
      now: nowIso(),
    }
    const assertEditorFence = async () => {
      signal.throwIfAborted()
      await jobRepository.assertExecutionFence({
        ...editorFence,
        now: nowIso(),
      })
      signal.throwIfAborted()
    }
    const withEditorFence = async (/** @type {() => Promise<unknown>} */ operation) => {
      signal.throwIfAborted()
      return jobRepository.withExecutionFence({
        ...editorFence,
        now: nowIso(),
      }, async () => {
        signal.throwIfAborted()
        return operation()
      })
    }
    const handlers = createDefaultEditorToolHandlers({
      projectId: job.projectId,
      projectRepository,
      materialTools,
      richTimelineRepository,
      capabilityRegistry,
      batchTextCatalog,
      packagingResourceIndex,
      instructionFingerprint: job.privateInput.instructionFingerprint,
      assertExecutionFence: assertEditorFence,
      withExecutionFence: withEditorFence,
      enqueuePreview: (/** @type {Record<string, any>} */ input) =>
        createEditorTimelinePreviewJob(input, { ...editorFence, now: nowIso() }),
      enqueueJianyingExport: (/** @type {Record<string, any>} */ input) =>
        createEditorTimelineExportJob(input, { ...editorFence, now: nowIso() }),
      authorizeAudioToken: (/** @type {Record<string, any>} */ input) =>
        bgmLibrary?.isAuthorizedTrack({
          projectId: input.projectId,
          trackId: input.audioToken,
        }) ?? false,
      recommendPackaging: async (/** @type {{projectId: string}} */ input) => {
        let packagingRecommendationStage = 'resolve_provider'
        try {
          const packagingProvider = await resolveAutomaticPackagingProvider()
          if (!packagingProvider) return null
          packagingRecommendationStage = 'project'
          const current = await projectRepository.get(input.projectId)
          if (
            !validProjectSnapshot(current) ||
            !safeBrief(current.brief) ||
            !isRecord(current.storyboard) ||
            !identifier(current.storyboard.id) ||
            !Array.isArray(current.storyboard.sentences)
          ) {
            return null
          }
          const selections = current.storyboard.sentences
            .filter((/** @type {Record<string, any>} */ sentence) =>
              isRecord(sentence) &&
              identifier(sentence.id) &&
              identifier(sentence.selectedCandidateId))
            .map((/** @type {Record<string, any>} */ sentence) => ({
              sentenceId: sentence.id,
              candidateId: sentence.selectedCandidateId,
            }))
          if (selections.length === 0) return null
          if (
            usesUploadedDraftInventory(current.templateBinding) ||
            usesUploadedDraftInventory(createTemplateGuidance(current.templateBinding ?? null))
          ) {
            return null
          }
          packagingRecommendationStage = 'plan'
          const plan = await editPlanRepository.getFinalized({
            projectId: input.projectId,
            planId: current.storyboard.id,
          })
          if (plan?.status !== 'finalized' || !isEditPlan(plan.final)) {
            throw coordinatorError('WORKBENCH_EDIT_PLAN_PRIVATE_DATA_INVALID', 409)
          }
          const selectedPlan = applyPrivateSelections(plan.final, selections)
          packagingRecommendationStage = 'readiness'
          await assertCurrentPackagingReadiness(packagingProvider)
          packagingRecommendationStage = 'source_authorization'
          const allowedTargetSegmentIds = await assertActivePackagingSources({
            projectId: input.projectId,
            authorizationId: current.materials.authorizationId,
            editPlan: selectedPlan,
            signal,
          })
          packagingRecommendationStage = 'template'
          const bindingGuidance = createTemplateGuidance(current.templateBinding ?? null)
          const templateGuidance = bindingGuidance
            ? adaptTemplateGuidanceToCount(bindingGuidance, selections.length)
            : null
          if (templateGuidance) {
            assertTemplateGuidanceExecutable(templateGuidance)
          }
          const packagingIntent = resolvePackagingIntentFromEditorInstruction(
            job.privateInput.editorInstruction?.instruction,
          )
          const packaging = {
            ...resolvePackagingForExecution(current.brief?.packaging),
            ...(packagingIntent.visualStyle ? { visualStyle: packagingIntent.visualStyle } : {}),
            ...(packagingIntent.packagingDensity
              ? { packagingDensity: packagingIntent.packagingDensity }
              : {}),
          }
          const editorTemplateConstraints = templateGuidance
            ? createTimelineTemplateConstraints(templateGuidance)
            : null
          const templateConstraints = editorTemplateConstraints
            ? applyPackagingPlanToTimelineTemplateConstraints(
                editorTemplateConstraints,
                await attachStyleAssignments(
                  packaging,
                  editorTemplateConstraints,
                  current.editPlan,
                  input.signal,
                  current.brief,
                  await packagingSceneCardsFor(input.projectId),
                ),
                current.brief,
                batchTextCatalog,
                selectCurrentPackagingResourceIndex(
                  packagingProvider,
                  packagingResourceIndex,
                  typeof resolvePackagingProvider === 'function',
                ),
              )
            : null
          packagingRecommendationStage = 'narration'
          const narration = await prepareNarrationTimeline({
            projectId: input.projectId,
            authorizationId: current.materials.authorizationId,
            editPlan: selectedPlan,
            brief: current.brief,
          })
          packagingRecommendationStage = 'readiness_recheck'
          await assertCurrentPackagingReadiness(packagingProvider)
          packagingRecommendationStage = 'provider'
          const recommendation = await packagingProvider.recommend({
            brief: current.brief,
            editPlan: selectedPlan,
            templateConstraints,
            narrationSegments: narration.narrationSegments,
            sceneCards: await packagingSceneCardsFor(input.projectId),
            excludedPackagingTokens: (() => {
              if (typeof job.privateInput.packagingFeedbackToken === 'string') {
                return [job.privateInput.packagingFeedbackToken]
              }
              if (!baseRevision || typeof job.privateInput.packagingFeedbackHandle !== 'string') return []
              const token = resolvePackagingFeedbackHandle(baseRevision, job.privateInput.packagingFeedbackHandle)
              if (!token) throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_FEEDBACK_INVALID', 409)
              return [token]
            })(),
            signal,
          })
          return recommendation
            ? {
                ...recommendation,
                allowedTargetSegmentIds,
              }
            : null
        } catch (error) {
          logger({
            event: 'workbench_packaging_recommendation_failed',
            stage: packagingRecommendationStage,
            code: errorCode(error) ?? 'PACKAGING_RECOMMENDATION_FAILED',
          })
          throw error
        }
      },
    })
    const bgmAuthorizationRequired = () =>
      coordinatorError('WORKBENCH_BGM_AUTHORIZATION_REQUIRED', 409)

    /** @param {Record<string, any> | null | undefined} revision */
    const assertRecoveredBgmAuthorizations = async (revision) => {
      if (!revision || !Array.isArray(revision.tracks)) return false
      const tokens = new Set()
      for (const track of revision.tracks) {
        if (track?.kind !== 'audio' || track.role !== 'bgm' || !Array.isArray(track.segments)) continue
        for (const segment of track.segments) {
          if (segment?.capabilityId !== 'audio.bgm.local') continue
          const token = segment.source?.kind === 'generated'
            ? segment.source.generatedAudioId
            : segment.source?.reference?.assetId ?? segment.source?.reference?.authorizationId
          if (typeof token !== 'string' || token.length === 0) throw bgmAuthorizationRequired()
          tokens.add(token)
        }
      }
      if (tokens.size === 0) return true
      if (typeof bgmLibrary?.isAuthorizedTrack !== 'function') throw bgmAuthorizationRequired()
      for (const trackId of tokens) {
        try {
          if (await bgmLibrary.isAuthorizedTrack({ projectId: job.projectId, trackId }) !== true) {
            throw bgmAuthorizationRequired()
          }
        } catch {
          throw bgmAuthorizationRequired()
        }
      }
      return true
    }
    /** @param {Record<string, any> | null | undefined} revision */
    const recoveredRevisionReady = async (revision) =>
      Boolean(revision) && await assertRecoveredBgmAuthorizations(revision)
    const validateResumeExecution = async (/** @type {Record<string, any>} */ execution) => {
      if (execution.tool === 'apply_packaging_recommendation') {
        return validatePackagingApplicationResume({
          execution,
          projectId: job.projectId,
          instructionFingerprint: job.privateInput.instructionFingerprint,
          richTimelineRepository,
          recoveredRevisionReady,
        })
      }
      const expectedTimelineId = job.privateInput.editorInstruction?.baseTimeline?.timelineId ??
        null
      if (typeof expectedTimelineId !== 'string') return null
      if (execution.tool === 'propose_timeline_patch') {
        const revision = await richTimelineRepository.getRevision({
          projectId: job.projectId,
          timelineId: expectedTimelineId,
          revision: execution.result.proposedRevision,
        })
        if (
          !await recoveredRevisionReady(revision) ||
          revision.status !== 'draft' ||
          revision.source?.kind !== 'agent' ||
          revision.source?.instructionFingerprint !== job.privateInput.instructionFingerprint ||
          revision.contentFingerprint !== execution.result.proposedContentFingerprint ||
          revision.revisionFingerprint !== execution.result.proposedRevisionFingerprint
        ) return null
        if (execution.tool === 'propose_timeline_patch' && execution.request !== null) {
          const request = execution.request
          if (
            request.projectId !== job.projectId ||
            revision.parentRevision !== request.baseRevision ||
            revision.parentRevisionFingerprint !== request.baseRevisionFingerprint
          ) return null
          const base = await richTimelineRepository.getRevision({
            projectId: job.projectId,
            timelineId: revision.timelineId,
            revision: request.baseRevision,
          })
          if (!base) return null
          const expected = applyRichTimelinePatch({
            base,
            operations: request.operations,
            instructionFingerprint: job.privateInput.instructionFingerprint,
            jobOperationsUsed: request.jobOperationsUsed,
            candidateReferences: request.candidateReferences,
          })
          if (expected.contentFingerprint !== revision.contentFingerprint) return null
        }
        return {
          patchId: `patch-${revision.revisionFingerprint.slice(0, 16)}`,
          validation: 'accepted',
          errorCode: null,
          proposedRevision: revision.revision,
          proposedContentFingerprint: revision.contentFingerprint,
          proposedRevisionFingerprint: revision.revisionFingerprint,
        }
      }
      if (execution.tool === 'finalize_timeline') {
        const revision = await richTimelineRepository.getRevision({
          projectId: job.projectId,
          timelineId: expectedTimelineId,
          revision: execution.result.revision,
        })
        if (
          !await recoveredRevisionReady(revision) ||
          revision.status !== 'finalized' ||
          revision.source?.kind !== 'agent' ||
          revision.source?.instructionFingerprint !== job.privateInput.instructionFingerprint ||
          revision.contentFingerprint !== execution.result.contentFingerprint ||
          revision.revisionFingerprint !== execution.result.revisionFingerprint
        ) return null
        if (
          execution.request !== null &&
          (
            execution.request.projectId !== job.projectId ||
            execution.request.timelineId !== revision.timelineId ||
            execution.request.revision !== revision.parentRevision ||
            execution.request.revisionFingerprint !== revision.parentRevisionFingerprint
          )
        ) return null
        return {
          status: 'finalized',
          revision: revision.revision,
          contentFingerprint: revision.contentFingerprint,
          revisionFingerprint: revision.revisionFingerprint,
        }
      }
      if (execution.tool === 'request_preview' || execution.tool === 'request_jianying_export') {
        const child = await jobRepository.get(job.projectId, execution.result.jobId)
        const expectedType = execution.tool === 'request_preview'
          ? 'preview_generation'
          : 'jianying_draft_export'
        if (
          !child ||
          child.projectId !== job.projectId ||
          child.type !== expectedType ||
          child.idempotencyKey !== execution.idempotencyKey ||
          child.privateInput?.editorBound !== true ||
          child.privateInput.editorParentJobId !== job.jobId ||
          child.privateInput.editorInstructionFingerprint !== job.privateInput.instructionFingerprint ||
          fingerprintCanonical({
            projectId: child.projectId,
            timelineId: child.privateInput.timelineId,
            revision: child.privateInput.timelineRevision,
            revisionFingerprint: child.privateInput.timelineRevisionFingerprint,
            idempotencyKey: child.idempotencyKey,
          }) !== execution.requestHash
        ) return null
        const childRevision = await richTimelineRepository.getRevision({
          projectId: child.projectId,
          timelineId: child.privateInput.timelineId,
          revision: child.privateInput.timelineRevision,
        })
        if (!await recoveredRevisionReady(childRevision)) return null
        const ownership = await resolveEditorBoundChildOwnership(child)
        if (!ownership || ownership.parent?.jobId !== job.jobId) return null
        return { jobId: child.jobId, status: 'queued' }
      }
      return null
    }
    const liveToolRegistryFingerprint = fingerprintCanonical({
      tools: EDITOR_TOOL_NAMES,
      budgets: EDITOR_BUDGETS,
    })
    const liveCapabilityRegistryFingerprint = capabilityRegistry.registryFingerprint
    if (
      job.privateInput.toolRegistryFingerprint !== liveToolRegistryFingerprint ||
      job.privateInput.capabilityRegistryFingerprint !== liveCapabilityRegistryFingerprint
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_REGISTRY_MISMATCH', 409)
    }
    if (baseTimelineIdentity && resumeExecutions.length === 0) {
      await assertRecoveredBgmAuthorizations(baseRevision)
    }
    const createRegistry = (/** @type {any[]} */ executions) =>
      createEditorToolRegistry({
        projectId: job.projectId,
        handlers,
        toolRegistryFingerprint: job.privateInput.toolRegistryFingerprint,
        capabilityRegistryFingerprint: job.privateInput.capabilityRegistryFingerprint,
        validateResumeExecution,
        resumeExecutions: executions,
        authorizeAudioToken: (/** @type {Record<string, any>} */ input) =>
          bgmLibrary?.isAuthorizedTrack({
            projectId: input.projectId,
            trackId: input.audioToken,
          }) ?? false,
        requiredSemanticSegmentIds,
        protectedSegmentIds,
      })
    const registry = createRegistry(resumeExecutions)
    try {
      await registry.validateResumeExecutions()
      await checkpoint('editor_agent_start', 5, toEditorAgentCheckpointData({
        instructionFingerprint: job.privateInput.instructionFingerprint,
        committedExecutions: registry.committedExecutions(),
        ...(isRecord(recoveredData?.frozen) ? { frozen: recoveredData.frozen } : {}),
        detail: requiredSemanticSegmentIds.length > 0
          ? `准备按 ${requiredSemanticSegmentIds.length} 句文案重新匹配镜头`
          : '正在读取当前时间线',
      }))
    } catch (error) {
      if (
        error instanceof EditorAgentContractError ||
        error instanceof EditorToolRegistryError
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID', 409)
      }
      throw error
    }
    /**
     * @param {{
     *   currentTimeline: Record<string, any>,
     *   executionRegistry: ReturnType<typeof createEditorToolRegistry>,
     *   frozen?: Record<string, any> | null,
     *   toolCalls?: number,
     * }} input
     */
    const requestAutomaticOutputChildren = async ({
      currentTimeline,
      executionRegistry,
      frozen = null,
      toolCalls,
    }) => {
      if (
        !identifier(currentTimeline?.timelineId) ||
        !Number.isSafeInteger(currentTimeline?.revision) ||
        currentTimeline.revision < 1 ||
        typeof currentTimeline?.revisionFingerprint !== 'string' ||
        !/^[a-f0-9]{64}$/u.test(currentTimeline.revisionFingerprint)
      ) {
        // finalize_timeline's committed result has no timelineId. Callers must
        // keep the known identity; undefined here becomes EDITOR_TOOL_ARGUMENTS_INVALID.
        throw coordinatorError('WORKBENCH_EDITOR_OUTPUT_IDENTITY_INVALID', 409)
      }
      const checkpointToolCalls = Number.isSafeInteger(toolCalls)
        ? toolCalls
        : executionRegistry.budgets().toolCalls
      const automaticOutputs = [
        ['request_preview', `${job.jobId}-automatic-preview`],
        ['request_jianying_export', `${job.jobId}-automatic-jianying-export`],
      ]
      const pendingOutputs = automaticOutputs.flatMap(([tool, idempotencyKey]) => {
        const alreadyRequested = executionRegistry.committedExecutions().some((
          /** @type {Record<string, any>} */ execution,
        ) =>
          execution.tool === tool)
        if (alreadyRequested) return []
        return [{
          tool,
          promise: executionRegistry.invoke(tool, {
              projectId: job.projectId,
              timelineId: currentTimeline.timelineId,
              revision: currentTimeline.revision,
              revisionFingerprint: currentTimeline.revisionFingerprint,
              idempotencyKey,
            }, { signal })
            .then(
              (value) => ({ ok: true, value }),
              (error) => ({ ok: false, error }),
            ),
        }]
      })
      // Preview and Jianying own different child jobs, so their durable enqueue
      // work can overlap. Await them in stable order to preserve the existing
      // per-output checkpoint and retry semantics when only one enqueue fails.
      for (const { tool, promise } of pendingOutputs) {
        const settled = await promise
        if ('error' in settled) throw settled.error
        await checkpoint(`editor_automatic_${tool}`, 92, toEditorAgentCheckpointData({
          tool,
          toolCalls: checkpointToolCalls,
          ...(isRecord(frozen) ? { frozen } : {}),
          committedExecutions: executionRegistry.committedExecutions(),
          detail: editorToolProgressDetail[tool],
        }))
      }
    }
    const recoveredFinalization = resumeExecutions.find((execution) =>
      execution.tool === 'finalize_timeline') ?? null
    /**
     * Confirmed storyboard shots already have analyzed scene ranges. Match
     * those from the private index before the LLM starts so a 12-sentence
     * create does not depend on twelve model-issued search_materials calls.
     * @param {unknown} range
     * @param {unknown} available
     */
    const sourceRangeWithin = (range, available) => {
      if (
        !isRecord(range) ||
        !isRecord(available) ||
        !Number.isSafeInteger(range.startUs) ||
        !Number.isSafeInteger(range.durationUs) ||
        range.startUs < 0 ||
        range.durationUs < 1 ||
        !Number.isSafeInteger(available.startUs) ||
        !Number.isSafeInteger(available.durationUs) ||
        available.startUs < 0 ||
        available.durationUs < 1
      ) return false
      return range.startUs >= available.startUs &&
        range.startUs + range.durationUs <= available.startUs + available.durationUs
    }
    /**
     * @param {{
     *   project: Record<string, any> | null | undefined,
     *   candidateId: unknown,
     *   assetId: unknown,
     *   sceneId: unknown,
     *   preferredRange: unknown,
     *   desiredDurationUs: number,
     *   usedSceneKeys: Set<string>,
     * }} input
     */
    const resolveIndexedCandidateRange = async (input) => {
      if (
        !identifier(input.candidateId) ||
        !identifier(input.assetId) ||
        !identifier(input.sceneId)
      ) return null
      const sceneKey = `${input.assetId}\u0000${input.sceneId}`
      if (input.usedSceneKeys.has(sceneKey)) return null
      const scopes = []
      const seenScopes = new Set()
      const addScope = (scope) => {
        if (!identifier(scope?.projectId) || !identifier(scope?.authorizationId)) return
        const key = `${scope.projectId}\u0000${scope.authorizationId}`
        if (seenScopes.has(key)) return
        seenScopes.add(key)
        scopes.push({ projectId: scope.projectId, authorizationId: scope.authorizationId })
      }
      if (typeof resolveMaterialLibrarySceneBinding === 'function') {
        try {
          addScope(await resolveMaterialLibrarySceneBinding({
            projectId: job.projectId,
            sceneId: input.sceneId,
          }))
        } catch {
          // Binding is only a hint; project and remaining scopes still revalidate.
        }
      }
      addScope({
        projectId: job.projectId,
        authorizationId: input.project?.materials?.authorizationId,
      })
      if (typeof listStoryboardSearchScopes === 'function') {
        try {
          const extra = await listStoryboardSearchScopes(job.projectId)
          if (Array.isArray(extra)) extra.slice(0, 64).forEach(addScope)
        } catch {
          // Optional library scopes must not block index revalidation.
        }
      }
      for (const scope of scopes) {
        signal.throwIfAborted()
        try {
          const analysis = await materialAnalysisProvider.restoreAnalysis({
            projectId: scope.projectId,
            authorizationId: scope.authorizationId,
            assetId: input.assetId,
            signal,
          })
          const assets = Array.isArray(analysis?.assets) ? analysis.assets : []
          const asset = assets.find((entry) => entry?.id === input.assetId)
            ?? assets.find((entry) => entry?.scenes?.some((scene) => scene?.id === input.sceneId))
          const scene = Array.isArray(asset?.scenes)
            ? asset.scenes.find((entry) => entry?.id === input.sceneId || entry?.id === input.candidateId)
            : null
          if (
            !identifier(asset?.id) ||
            !isRecord(scene) ||
            (
              scene.needsReview === true &&
              (!Array.isArray(scene.evidenceReferences) || scene.evidenceReferences.length === 0) &&
              !(Number(scene.confidence) > 0)
            )
          ) continue
          if (
            !Number.isFinite(scene.start) ||
            !Number.isFinite(scene.end) ||
            scene.end <= scene.start
          ) continue
          const startUs = secondsToMicroseconds(scene.start)
          const durationUs = secondsToMicroseconds(scene.end) - startUs
          if (!Number.isSafeInteger(startUs) || startUs < 0 || !Number.isSafeInteger(durationUs) || durationUs < 1) {
            continue
          }
          const available = { startUs, durationUs }
          const clipped = {
            startUs: available.startUs,
            durationUs: Math.min(input.desiredDurationUs, available.durationUs),
          }
          const sourceRange = sourceRangeWithin(input.preferredRange, available)
            ? {
                startUs: /** @type {Record<string, any>} */ (input.preferredRange).startUs,
                durationUs: /** @type {Record<string, any>} */ (input.preferredRange).durationUs,
              }
            : clipped
          if (!sourceRange || !sourceRangeWithin(sourceRange, available)) continue
          input.usedSceneKeys.add(sceneKey)
          return {
            candidateId: input.candidateId,
            authorizationId: scope.authorizationId,
            availableSourceRange: available,
            sourceRange,
          }
        } catch (error) {
          if (signal.aborted) throw error
        }
      }
      return null
    }
    /**
     * @param {ReturnType<typeof createEditorToolRegistry>} executionRegistry
     */
    const runIndexFirstPrematch = async (executionRegistry) => {
      const project = await projectRepository.get(job.projectId)
      const pointer = await richTimelineRepository.getCurrent({ projectId: job.projectId })
      const currentRevision = pointer
        ? await richTimelineRepository.getRevision(pointer)
        : null
      const primarySegments = currentRevision?.tracks
        ?.find((/** @type {Record<string, any>} */ track) =>
          track.kind === 'video' && track.role === 'primary')
        ?.segments
      const sentences = Array.isArray(project?.storyboard?.sentences)
        ? [...project.storyboard.sentences].sort((left, right) => left.order - right.order)
        : []
      if (
        !pointer ||
        !currentRevision ||
        currentRevision.status !== 'draft' ||
        !Array.isArray(primarySegments) ||
        primarySegments.length === 0 ||
        primarySegments.length !== requiredSemanticSegmentIds.length ||
        sentences.length !== primarySegments.length
      ) {
        return { remaining: requiredSemanticSegmentIds.length, timelineIdentity: null }
      }
      /** @type {Record<string, any> | null} */
      let selectedPlan = null
      try {
        const selections = previewSelections(project)
        if (selections && identifier(project.storyboard?.id)) {
          const plan = await editPlanRepository.getFinalized({
            projectId: job.projectId,
            planId: project.storyboard.id,
          })
          if (plan?.status === 'finalized' && isEditPlan(plan.final)) {
            selectedPlan = applyPrivateSelections(plan.final, selections)
          }
        }
      } catch {
        selectedPlan = null
      }
      if (!selectedPlan) return { remaining: requiredSemanticSegmentIds.length, timelineIdentity: null }
      const usedSceneKeys = new Set()
      const operations = []
      for (let index = 0; index < primarySegments.length; index += 1) {
        const segment = primarySegments[index]
        const sentence = sentences[index]
        const desiredDurationUs = Number.isSafeInteger(segment.targetRange?.durationUs) &&
          segment.targetRange.durationUs > 0
          ? segment.targetRange.durationUs
          : segment.sourceRange?.durationUs
        if (!Number.isSafeInteger(desiredDurationUs) || desiredDurationUs < 1) continue
        const planItem = Array.isArray(selectedPlan.items)
          ? selectedPlan.items.find((/** @type {Record<string, any>} */ item) =>
              item.sentence_id === sentence?.id)
          : null
        const planCandidate = Array.isArray(planItem?.candidates)
          ? planItem.candidates.find((/** @type {Record<string, any>} */ candidate) =>
              candidate.candidate_id === sentence?.selectedCandidateId) ??
            planItem.candidates[0]
          : null
        if (!planCandidate) continue
        const keepCurrentRange = segment.audit?.candidateId === planCandidate.candidate_id
          ? segment.sourceRange
          : null
        const authorized = await resolveIndexedCandidateRange({
          project,
          candidateId: planCandidate.candidate_id,
          assetId: planCandidate.asset_id,
          sceneId: planCandidate.scene_id,
          preferredRange: keepCurrentRange,
          desiredDurationUs,
          usedSceneKeys,
        })
        if (!authorized) continue
        executionRegistry.registerVerifiedCandidate({
          candidateId: authorized.candidateId,
          assetId: planCandidate.asset_id,
          sceneId: planCandidate.scene_id,
          availableSourceRange: authorized.availableSourceRange,
          ...(identifier(authorized.authorizationId)
            ? { authorizationId: authorized.authorizationId }
            : {}),
        })
        operations.push({
          op: 'replace_candidate',
          segmentId: segment.segmentId,
          candidateId: authorized.candidateId,
          sourceRange: authorized.sourceRange,
        })
      }
      if (operations.length === 0) {
        return { remaining: requiredSemanticSegmentIds.length, timelineIdentity: null }
      }
      try {
        const proposed = await executionRegistry.invoke('propose_timeline_patch', {
          projectId: job.projectId,
          baseRevision: currentRevision.revision,
          baseRevisionFingerprint: currentRevision.revisionFingerprint,
          operations,
          rationale: '已确认分镜优先使用分析索引中的镜头时间段，不默认截取素材开头。',
          idempotencyKey: `${job.jobId}-semantic-index-prematch`,
        }, { signal })
        await checkpoint('editor_semantic_prematch', 18, toEditorAgentCheckpointData({
          tool: 'propose_timeline_patch',
          committedExecutions: executionRegistry.committedExecutions(),
          detail: `已按已确认分镜从分析索引写入 ${operations.length} / ${primarySegments.length} 个镜头，模型继续完成包装和定稿`,
        }))
        return {
          remaining: requiredSemanticSegmentIds.length - operations.length,
          timelineIdentity: {
            timelineId: currentRevision.timelineId,
            revision: proposed.proposedRevision,
            revisionFingerprint: proposed.proposedRevisionFingerprint,
          },
        }
      } catch (error) {
        // Video-only index prematch must not fail-closed the whole editor job
        // when inherited template titles cannot be re-laid-out. Keep the
        // existing draft and continue with LLM / finalize fallback.
        if (signal.aborted) throw error
        logger({
          event: 'editor_index_prematch_degraded',
          code: errorCode(error) || 'EDITOR_TOOL_EXECUTION_FAILED',
        })
        return { remaining: requiredSemanticSegmentIds.length, timelineIdentity: null }
      }
    }
    /**
     * After index prematch has already replaced every required shot, an LLM
     * timeout must finalize that draft instead of searching all sentences again.
     * @param {ReturnType<typeof createEditorToolRegistry>} executionRegistry
     * @param {{timelineId: string, revision: number, revisionFingerprint: string}} timelineIdentity
     */
    const finalizePrematchedDraft = async (executionRegistry, timelineIdentity) => {
      signal.throwIfAborted()
      const frozen = createFrozenEditorJobInput({
        instructionFingerprint: job.privateInput.instructionFingerprint,
        baseTimelineFingerprint: job.privateInput.baseTimelineFingerprint,
        toolRegistryFingerprint: job.privateInput.toolRegistryFingerprint,
        capabilityRegistryFingerprint: job.privateInput.capabilityRegistryFingerprint,
        attemptGeneration: attempt.generation,
        fencingToken: attempt.lease.token,
      })
      await executionRegistry.invoke('get_project_brief', { projectId: job.projectId }, { signal })
      await executionRegistry.invoke('get_timeline_summary', {
        projectId: job.projectId,
        timelineId: timelineIdentity.timelineId,
        revision: timelineIdentity.revision,
      }, { signal })
      let prepared = {
        timelineId: timelineIdentity.timelineId,
        proposedRevision: timelineIdentity.revision,
        proposedRevisionFingerprint: timelineIdentity.revisionFingerprint,
      }
      let packagingUnavailableAfterMatch = false
      const matchedIdentity = {
        timelineId: timelineIdentity.timelineId,
        proposedRevision: timelineIdentity.revision,
        proposedRevisionFingerprint: timelineIdentity.revisionFingerprint,
      }
      if (job.privateInput.automaticPackaging === true) {
        // Index prematch already wrote every shot. Catalog ranking goes through
        // the same LLM that just timed out or returned invalid JSON, and an
        // invalid private catalog (JY132) makes this sit on 70% until the
        // lease dies. Finalize the matched draft now; packaging can be a
        // later revision once the catalog is writable.
        const currentRevision = await richTimelineRepository.getRevision({
          projectId: job.projectId,
          timelineId: timelineIdentity.timelineId,
          revision: timelineIdentity.revision,
        })
        if (!hasExecutableTemplatePackaging(currentRevision)) {
          packagingUnavailableAfterMatch = true
        }
        prepared = matchedIdentity
        logger({ event: 'editor_prematch_packaging_skipped', code: 'INDEX_PREMATCH_COMPLETE' })
      }
      const preflight = await executionRegistry.invoke('preflight_timeline', {
        projectId: job.projectId,
        timelineId: prepared.timelineId,
        revision: prepared.proposedRevision,
        revisionFingerprint: prepared.proposedRevisionFingerprint,
      }, { signal })
      if (preflight?.ready !== true) {
        logger({
          event: 'editor_prematch_preflight_rejected',
          errors: Array.isArray(preflight?.errors) ? preflight.errors : [],
        })
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_RESULT_INVALID', 409)
      }
      const finalized = await executionRegistry.invoke('finalize_timeline', {
        projectId: job.projectId,
        timelineId: prepared.timelineId,
        revision: prepared.proposedRevision,
        revisionFingerprint: prepared.proposedRevisionFingerprint,
        idempotencyKey: `${job.jobId}-prematch-finalize`,
      }, { signal })
      if (job.privateInput.automaticOutputs === true) {
        // Prematch finalization must produce the same two durable child jobs as
        // the regular editor path. Calling the shared helper also preserves
        // independent idempotency and checkpoint semantics for Preview and
        // Jianying export. finalize_timeline's committed result has no
        // timelineId; stitch from the known prematch identity.
        const outputIdentity = toEditorAutomaticOutputIdentity({
          knownTimelineId: timelineIdentity.timelineId,
          result: finalized,
        })
        if (!outputIdentity) {
          logger({
            event: 'editor_automatic_output_identity_invalid',
            tool: 'finalize_timeline',
            hasKnownTimelineId: identifier(timelineIdentity.timelineId),
            hasRevision: Number.isSafeInteger(finalized?.revision),
          })
          throw coordinatorError('WORKBENCH_EDITOR_OUTPUT_IDENTITY_INVALID', 409)
        }
        await requestAutomaticOutputChildren({
          currentTimeline: outputIdentity,
          executionRegistry,
          frozen,
        })
      }
      await checkpoint('editor_prematch_finalize', 88, toEditorAgentCheckpointData({
        tool: 'finalize_timeline',
        frozen,
        committedExecutions: executionRegistry.committedExecutions(),
        detail: packagingUnavailableAfterMatch
          ? '索引已匹配全部镜头并定稿；当前没有可写包装推荐'
          : '索引已匹配全部镜头，模型超时后已自动定稿',
      }))
      return {
        summary: packagingUnavailableAfterMatch
          ? '已按已确认分镜写入互不重复的镜头并定稿；当前没有可写包装推荐，未写入不完整包装。'
          : job.privateInput.automaticOutputs === true
            ? '已按已确认分镜写入互不重复的镜头，时间线已定稿并开始生成预览。'
            : '已按已确认分镜写入互不重复的镜头，时间线已定稿。',
        frozen,
        budgets: executionRegistry.budgets(),
      }
    }
    let llmRequiredSemanticSegmentCount = requiredSemanticSegmentIds.length
    /** @type {{timelineId: string, revision: number, revisionFingerprint: string} | null} */
    let prematchedTimelineIdentity = null
    if (
      job.privateInput.semanticCreate === true &&
      recoveredPackagingApplication === null &&
      !recoveredFinalization &&
      requiredSemanticSegmentIds.length > 0 &&
      resumeExecutions.length === 0
    ) {
      const prematched = await runIndexFirstPrematch(registry)
      llmRequiredSemanticSegmentCount = prematched.remaining
      prematchedTimelineIdentity = prematched.timelineIdentity
    } else if (job.privateInput.semanticCreate === true && !prematchedTimelineIdentity) {
      const prematchExecution = resumeExecutions.find((execution) =>
        execution.tool === 'propose_timeline_patch' &&
        typeof execution.idempotencyKey === 'string' &&
        execution.idempotencyKey.endsWith('-semantic-index-prematch'))
      const proposed = isRecord(prematchExecution?.result) ? prematchExecution.result : null
      const timelineId = job.privateInput.editorInstruction?.baseTimeline?.timelineId
      if (
        proposed &&
        typeof timelineId === 'string' &&
        Number.isSafeInteger(proposed.proposedRevision) &&
        typeof proposed.proposedRevisionFingerprint === 'string'
      ) {
        prematchedTimelineIdentity = {
          timelineId,
          revision: proposed.proposedRevision,
          revisionFingerprint: proposed.proposedRevisionFingerprint,
        }
        const ops = Array.isArray(prematchExecution.request?.operations)
          ? prematchExecution.request.operations
          : []
        llmRequiredSemanticSegmentCount = ops.length > 0
          ? Math.max(0, requiredSemanticSegmentIds.length - ops.filter((op) => op?.op === 'replace_candidate').length)
          : 0
      }
    }
    if (job.privateInput.automaticOutputs === true && recoveredFinalization) {
      const recoveredTimeline = await richTimelineRepository.getRevision({
        projectId: job.projectId,
        timelineId: job.privateInput.editorInstruction.baseTimeline.timelineId,
        revision: recoveredFinalization.result.revision,
      })
      if (
        !recoveredTimeline ||
        recoveredTimeline.status !== 'finalized' ||
        recoveredTimeline.revisionFingerprint !== recoveredFinalization.result.revisionFingerprint
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID', 409)
      }
      await requestAutomaticOutputChildren({
        currentTimeline: recoveredTimeline,
        executionRegistry: registry,
        frozen: recoveredData?.frozen,
      })
      await checkpoint('editor_agent_finish', 95, toEditorAgentCheckpointData({
        frozen: recoveredData?.frozen,
        committedExecutions: registry.committedExecutions(),
        detail: '时间线已定稿，正在确认任务结果',
      }))
      return {
        resourceId: `editor-${job.jobId}`,
        summary: '已恢复自动预览和剪映导出。',
        timelineId: recoveredTimeline.timelineId,
        timelineRevision: recoveredTimeline.revision,
        timelineRevisionFingerprint: recoveredTimeline.revisionFingerprint,
      }
    }
    const agent = createEditorAgent({
      gateway: llmGateway,
      registry,
      automaticPackaging: job.privateInput.automaticPackaging === true,
      automaticOutputs: job.privateInput.automaticOutputs === true,
      executionFence: {
        attemptGeneration: attempt.generation,
        fencingToken: attempt.lease.token,
      },
      requiredSemanticSegmentCount: llmRequiredSemanticSegmentCount,
      ...(recoveredPackagingApplication
        ? {
            recoveredTimelineIdentity: {
              timelineId: recoveredPackagingApplication.result.timelineId,
              revision: recoveredPackagingApplication.result.proposedRevision,
              revisionFingerprint: recoveredPackagingApplication.result.proposedRevisionFingerprint,
            },
          }
        : prematchedTimelineIdentity
          ? { recoveredTimelineIdentity: prematchedTimelineIdentity }
          : {}),
      onCheckpoint: async (stage, data) => {
        try {
          const usedToolCalls = registry.budgets().toolCalls
          const progressPercent = Math.min(
            90,
            usedToolCalls * 4 + (stage === 'intent' ? 14 : 12),
          )
          const detail = typeof data.tool === 'string'
            ? editorToolProgressDetail[data.tool] ?? '正在编排时间线'
            : '正在编排时间线'
          await checkpoint(`editor_${stage}`, progressPercent, { ...data, detail })
        } catch (error) {
          if (error instanceof EditorAgentContractError) {
            throw coordinatorError('WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID', 409)
          }
          throw error
        }
      },
      onToolResult: (event) => {
        logger({
          event: 'editor_agent_tool_result',
          tool: event.tool,
          ok: event.ok,
          ...(event.errorCode ? { code: event.errorCode } : {}),
        })
      },
      // Automatic editor creation must not hold the workbench in a half-open
      // state for the manual fifteen-minute agent budget.  Thinking models still
      // get enough time for a few tool rounds; a bounded failure is handled by
      // the existing semantic fallback/error path and leaves the previous
      // revision intact.
      ...(job.privateInput.semanticCreate === true || isAutomaticPackagingRevision(job.privateInput)
        ? { timeoutMs: EDITOR_BUDGETS.automaticCreateTimeoutMs }
        : {}),
    })
    const semanticFallbackCodes = new Set([
      'EDITOR_AGENT_SEMANTIC_FALLBACK_REQUIRED',
      'EDITOR_AGENT_TIMEOUT',
      'EDITOR_AGENT_FINISH_INVALID',
      'EDITOR_AGENT_INCOMPLETE_WORKFLOW',
      'EDITOR_AGENT_TOOL_CALL_INVALID',
      'EDITOR_AGENT_TURN_INVALID',
      'INVALID_UPSTREAM_RESPONSE',
      // Provider 4xx (not auth / timeout / rate-limit) is a request reject, not
      // an outage. With confirmed storyboard shots we finish the timeline
      // instead of showing a hard editor failure.
      'UPSTREAM_REJECTED',
    ])
    const packagingFallbackCodes = new Set([
      ...semanticFallbackCodes,
      'REQUEST_TIMEOUT',
      'RATE_LIMITED',
      'UPSTREAM_UNAVAILABLE',
      'WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE',
    ])
    /** @type {ReturnType<typeof createEditorToolRegistry> | null} */
    let semanticFallbackRegistry = null
    /** @type {ReturnType<typeof createEditorToolRegistry> | null} */
    let packagingFallbackRegistry = null
    const runSemanticFallback = async () => {
      signal.throwIfAborted()
      const fallbackRegistry = createRegistry([])
      semanticFallbackRegistry = fallbackRegistry
      const fallbackFrozen = createFrozenEditorJobInput({
        instructionFingerprint: job.privateInput.instructionFingerprint,
        baseTimelineFingerprint: job.privateInput.baseTimelineFingerprint,
        toolRegistryFingerprint: job.privateInput.toolRegistryFingerprint,
        capabilityRegistryFingerprint: job.privateInput.capabilityRegistryFingerprint,
        attemptGeneration: attempt.generation,
        fencingToken: attempt.lease.token,
      })
      const project = await projectRepository.get(job.projectId)
      const pointer = await richTimelineRepository.getCurrent({ projectId: job.projectId })
      const currentRevision = pointer
        ? await richTimelineRepository.getRevision(pointer)
        : null
      const primarySegments = currentRevision?.tracks
        ?.find((/** @type {Record<string, any>} */ track) =>
          track.kind === 'video' && track.role === 'primary')
        ?.segments
      const sentences = Array.isArray(project?.storyboard?.sentences)
        ? [...project.storyboard.sentences].sort((left, right) => left.order - right.order)
        : []
      if (
        !pointer ||
        !currentRevision ||
        !Array.isArray(primarySegments) ||
        primarySegments.length === 0 ||
        primarySegments.length !== requiredSemanticSegmentIds.length ||
        sentences.length !== primarySegments.length
      ) {
        throw coordinatorError('WORKBENCH_EDITOR_SEMANTIC_MATCHING_REQUIRED', 409)
      }

      await fallbackRegistry.invoke('get_project_brief', { projectId: job.projectId }, { signal })
      await fallbackRegistry.invoke('get_timeline_summary', {
        projectId: job.projectId,
        timelineId: pointer.timelineId,
        revision: pointer.revision,
      }, { signal })
      /** @type {Record<string, any> | null} */
      let selectedPlan = null
      try {
        const selections = previewSelections(project)
        if (selections && identifier(project.storyboard?.id)) {
          const plan = await editPlanRepository.getFinalized({
            projectId: job.projectId,
            planId: project.storyboard.id,
          })
          if (plan?.status === 'finalized' && isEditPlan(plan.final)) {
            selectedPlan = applyPrivateSelections(plan.final, selections)
          }
        }
      } catch {
        selectedPlan = null
      }
      const usedSceneKeys = new Set()
      /** @param {unknown} range @param {unknown} available */
      const sourceRangeWithin = (range, available) => {
        if (
          !isRecord(range) ||
          !isRecord(available) ||
          !Number.isSafeInteger(range.startUs) ||
          !Number.isSafeInteger(range.durationUs) ||
          range.startUs < 0 ||
          range.durationUs < 1 ||
          !Number.isSafeInteger(available.startUs) ||
          !Number.isSafeInteger(available.durationUs) ||
          available.startUs < 0 ||
          available.durationUs < 1
        ) return false
        return range.startUs >= available.startUs &&
          range.startUs + range.durationUs <= available.startUs + available.durationUs
      }
      /**
       * @param {{
       *   candidateId: unknown,
       *   assetId: unknown,
       *   sceneId: unknown,
       *   preferredRange: unknown,
       *   desiredDurationUs: number,
       * }} input
       */
      const authorizeUniqueCandidate = async (input) => {
        if (
          !identifier(input.candidateId) ||
          !identifier(input.assetId) ||
          !identifier(input.sceneId)
        ) return null
        const sceneKey = `${input.assetId}\u0000${input.sceneId}`
        if (usedSceneKeys.has(sceneKey)) return null
        const scopes = []
        const seenScopes = new Set()
        const addScope = (scope) => {
          if (!identifier(scope?.projectId) || !identifier(scope?.authorizationId)) return
          const key = `${scope.projectId}\u0000${scope.authorizationId}`
          if (seenScopes.has(key)) return
          seenScopes.add(key)
          scopes.push({ projectId: scope.projectId, authorizationId: scope.authorizationId })
        }
        if (typeof resolveMaterialLibrarySceneBinding === 'function') {
          try {
            addScope(await resolveMaterialLibrarySceneBinding({
              projectId: job.projectId,
              sceneId: input.sceneId,
            }))
          } catch {
            // Binding is only a hint; project and remaining scopes still revalidate.
          }
        }
        addScope({
          projectId: job.projectId,
          authorizationId: project?.materials?.authorizationId,
        })
        if (typeof listStoryboardSearchScopes === 'function') {
          try {
            const extra = await listStoryboardSearchScopes(job.projectId)
            if (Array.isArray(extra)) extra.slice(0, 64).forEach(addScope)
          } catch {
            // Optional library scopes must not block index revalidation.
          }
        }
        /** @type {{authorizationId: string, availableSourceRange: {startUs: number, durationUs: number}} | null} */
        let indexed = null
        for (const scope of scopes) {
          signal.throwIfAborted()
          try {
            const analysis = await materialAnalysisProvider.restoreAnalysis({
              projectId: scope.projectId,
              authorizationId: scope.authorizationId,
              assetId: input.assetId,
              signal,
            })
            const assets = Array.isArray(analysis?.assets) ? analysis.assets : []
            const asset = assets.find((entry) => entry?.id === input.assetId)
              ?? assets.find((entry) => entry?.scenes?.some((scene) => scene?.id === input.sceneId))
            const scene = Array.isArray(asset?.scenes)
              ? asset.scenes.find((entry) => entry?.id === input.sceneId || entry?.id === input.candidateId)
              : null
            if (
              !identifier(asset?.id) ||
              !isRecord(scene) ||
              (
                scene.needsReview === true &&
                (!Array.isArray(scene.evidenceReferences) || scene.evidenceReferences.length === 0) &&
                !(Number(scene.confidence) > 0)
              )
            ) continue
            if (
              !Number.isFinite(scene.start) ||
              !Number.isFinite(scene.end) ||
              scene.end <= scene.start
            ) continue
            const startUs = secondsToMicroseconds(scene.start)
            const durationUs = secondsToMicroseconds(scene.end) - startUs
            if (!Number.isSafeInteger(startUs) || startUs < 0 || !Number.isSafeInteger(durationUs) || durationUs < 1) {
              continue
            }
            indexed = {
              authorizationId: scope.authorizationId,
              availableSourceRange: { startUs, durationUs },
            }
            break
          } catch (error) {
            if (signal.aborted) throw error
          }
        }
        let inspected = indexed
          ? {
              authorizationId: indexed.authorizationId,
              availableSourceRange: indexed.availableSourceRange,
            }
          : null
        if (!inspected) {
          try {
            inspected = await fallbackRegistry.invoke('inspect_candidate', {
              projectId: job.projectId,
              candidateId: input.candidateId,
            }, { signal })
          } catch (error) {
            if (signal.aborted) throw error
            return null
          }
        }
        const available = inspected?.availableSourceRange
        const clipped = isRecord(available) &&
          Number.isSafeInteger(available.startUs) &&
          Number.isSafeInteger(available.durationUs) &&
          available.durationUs > 0
          ? {
              startUs: available.startUs,
              durationUs: Math.min(input.desiredDurationUs, available.durationUs),
            }
          : null
        const sourceRange = sourceRangeWithin(input.preferredRange, available)
          ? {
              startUs: /** @type {Record<string, any>} */ (input.preferredRange).startUs,
              durationUs: /** @type {Record<string, any>} */ (input.preferredRange).durationUs,
            }
          : clipped
        if (!sourceRange || !sourceRangeWithin(sourceRange, available)) return null
        fallbackRegistry.registerVerifiedCandidate({
          candidateId: input.candidateId,
          assetId: input.assetId,
          sceneId: input.sceneId,
          availableSourceRange: available,
          ...(identifier(inspected?.authorizationId)
            ? { authorizationId: inspected.authorizationId }
            : {}),
        })
        usedSceneKeys.add(sceneKey)
        return {
          candidateId: input.candidateId,
          sourceRange,
        }
      }
      /** @param {number} index */
      const searchSemanticSegment = async (index) => {
        signal.throwIfAborted()
        const segment = primarySegments[index]
        const sentence = sentences[index]
        const rawQuery = typeof sentence?.text === 'string'
          ? sentence.text
          : `镜头 ${index + 1}`
        const query = rawQuery.replace(/[\\/]/gu, ' ').trim().slice(0, 1_000) || `镜头 ${index + 1}`
        const desiredDurationUs = Number.isSafeInteger(segment.targetRange?.durationUs) &&
          segment.targetRange.durationUs > 0
          ? segment.targetRange.durationUs
          : segment.sourceRange?.durationUs
        if (!Number.isSafeInteger(desiredDurationUs) || desiredDurationUs < 1) {
          throw coordinatorError('WORKBENCH_EDITOR_SEMANTIC_MATCHING_REQUIRED', 409)
        }
        const search = await fallbackRegistry.invoke('search_materials', {
          projectId: job.projectId,
          query,
          desiredDurationUs,
          limit: 3,
        }, { signal })
        const planItem = Array.isArray(selectedPlan?.items)
          ? selectedPlan.items.find((/** @type {Record<string, any>} */ item) =>
              item.sentence_id === sentence?.id)
          : null
        const planCandidate = Array.isArray(planItem?.candidates)
          ? planItem.candidates.find((/** @type {Record<string, any>} */ candidate) =>
              candidate.candidate_id === sentence?.selectedCandidateId) ??
            planItem.candidates[0]
          : null
        return {
          index,
          segment,
          sentence,
          search,
          planCandidate,
          desiredDurationUs,
        }
      }
      /**
       * Search hits are already authorized by search_materials. Inspect is only
       * required for storyboard/current shots that did not appear in this search.
       * @param {unknown} candidate
       * @param {unknown} preferredRange
       * @param {number} desiredDurationUs
       */
      const takeAuthorizedSearchCandidate = (candidate, preferredRange, desiredDurationUs) => {
        if (
          !isRecord(candidate) ||
          !identifier(candidate.candidateId) ||
          !identifier(candidate.assetId) ||
          !identifier(candidate.sceneId) ||
          !isRecord(candidate.availableSourceRange)
        ) return null
        const sceneKey = `${candidate.assetId}\u0000${candidate.sceneId}`
        if (usedSceneKeys.has(sceneKey)) return null
        const clipped = {
          startUs: candidate.availableSourceRange.startUs,
          durationUs: Math.min(desiredDurationUs, candidate.availableSourceRange.durationUs),
        }
        const sourceRange = sourceRangeWithin(preferredRange, candidate.availableSourceRange)
          ? {
              startUs: /** @type {Record<string, any>} */ (preferredRange).startUs,
              durationUs: /** @type {Record<string, any>} */ (preferredRange).durationUs,
            }
          : clipped
        if (!sourceRangeWithin(sourceRange, candidate.availableSourceRange)) return null
        usedSceneKeys.add(sceneKey)
        return {
          candidateId: candidate.candidateId,
          sourceRange,
        }
      }
      /** @param {Awaited<ReturnType<typeof searchSemanticSegment>>} prepared */
      const assignSemanticSegment = async (prepared) => {
        const { segment, sentence, search, planCandidate, desiredDurationUs } = prepared
        const searchCandidates = Array.isArray(search?.candidates) ? search.candidates : []
        const keepCurrentRange = segment.audit?.candidateId === planCandidate?.candidate_id
          ? segment.sourceRange
          : null
        const searchedPreferred = planCandidate
          ? searchCandidates.find((/** @type {any} */ candidate) =>
              isRecord(candidate) && candidate.candidateId === planCandidate.candidate_id)
          : null
        const preferred = searchedPreferred
          ? takeAuthorizedSearchCandidate(searchedPreferred, keepCurrentRange, desiredDurationUs)
          : planCandidate
            ? await authorizeUniqueCandidate({
                candidateId: planCandidate.candidate_id,
                assetId: planCandidate.asset_id,
                sceneId: planCandidate.scene_id,
                preferredRange: keepCurrentRange,
                desiredDurationUs,
              })
            : null
        if (preferred) {
          return {
            op: 'replace_candidate',
            segmentId: segment.segmentId,
            candidateId: preferred.candidateId,
            sourceRange: preferred.sourceRange,
          }
        }
        for (const candidate of searchCandidates) {
          const searched = takeAuthorizedSearchCandidate(candidate, null, desiredDurationUs)
          if (searched) {
            return {
              op: 'replace_candidate',
              segmentId: segment.segmentId,
              candidateId: searched.candidateId,
              sourceRange: searched.sourceRange,
            }
          }
        }
        const current = await authorizeUniqueCandidate({
          candidateId: segment.audit?.candidateId,
          assetId: segment.asset?.assetId,
          sceneId: segment.asset?.sceneId,
          preferredRange: sentence?.selectedCandidateId === segment.audit?.candidateId
            ? segment.sourceRange
            : null,
          desiredDurationUs,
        })
        if (current) {
          return {
            op: 'replace_candidate',
            segmentId: segment.segmentId,
            candidateId: current.candidateId,
            sourceRange: current.sourceRange,
          }
        }
        throw coordinatorError('WORKBENCH_EDITOR_SEMANTIC_MATCHING_REQUIRED', 409)
      }
      const operations = []
      for (let start = 0; start < primarySegments.length; start += 2) {
        const batchIndexes = Array.from(
          { length: Math.min(2, primarySegments.length - start) },
          (_, offset) => start + offset,
        )
        const prepared = await Promise.all(batchIndexes.map(searchSemanticSegment))
        for (const item of prepared) {
          operations.push(await assignSemanticSegment(item))
        }
        const completed = start + prepared.length
        await checkpoint('editor_semantic_fallback', 20 + Math.floor((completed / primarySegments.length) * 45),
          toEditorAgentCheckpointData({
            tool: 'search_materials',
            frozen: fallbackFrozen,
            committedExecutions: fallbackRegistry.committedExecutions(),
            detail: `模型本轮响应超时，已自动使用已分析素材继续完成第 ${completed} / ${primarySegments.length} 个镜头`,
          }))
      }
      const latestPointer = await richTimelineRepository.getCurrent({ projectId: job.projectId })
      const latestRevision = latestPointer
        ? await richTimelineRepository.getRevision(latestPointer)
        : null
      if (!latestPointer || !latestRevision) {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
      }
      const proposed = await fallbackRegistry.invoke('propose_timeline_patch', {
        projectId: job.projectId,
        baseRevision: latestRevision.revision,
        baseRevisionFingerprint: latestRevision.revisionFingerprint,
        operations,
        rationale: '优先沿用已确认分镜镜头，搜索仅用于补位，且同一素材场景不得复用。',
        idempotencyKey: `${job.jobId}-semantic-fallback-patch`,
      }, { signal })
      let prepared = {
        timelineId: latestRevision.timelineId,
        proposedRevision: proposed.proposedRevision,
        proposedRevisionFingerprint: proposed.proposedRevisionFingerprint,
      }
      let packagingUnavailableAfterMatch = false
      if (job.privateInput.automaticPackaging === true) {
        const recommended = await fallbackRegistry.invoke('recommend_packaging', {
          projectId: job.projectId,
        }, { signal })
        const recommendation = recommended?.recommendation
        if (!isRecord(recommendation)) {
          if (!hasExecutableTemplatePackaging(latestRevision)) {
            packagingUnavailableAfterMatch = true
            await checkpoint('editor_semantic_fallback', 70,
              toEditorAgentCheckpointData({
                tool: 'recommend_packaging',
                frozen: fallbackFrozen,
                committedExecutions: fallbackRegistry.committedExecutions(),
                detail: '镜头已按文案匹配，当前没有可写包装推荐，先定稿已匹配时间线',
              }))
          } else {
            await checkpoint('editor_semantic_fallback', 70,
              toEditorAgentCheckpointData({
                tool: 'recommend_packaging',
                frozen: fallbackFrozen,
                committedExecutions: fallbackRegistry.committedExecutions(),
                detail: '模板已覆盖包装需求，保留模板包装并继续定稿',
              }))
          }
        } else {
          await checkpoint('editor_semantic_fallback', 70,
            toEditorAgentCheckpointData({
              tool: 'recommend_packaging',
              frozen: fallbackFrozen,
              committedExecutions: fallbackRegistry.committedExecutions(),
              detail: '镜头已匹配，正在应用自动包装',
            }))
          prepared = await fallbackRegistry.invoke('apply_packaging_recommendation', {
            projectId: job.projectId,
            timelineId: latestRevision.timelineId,
            revision: proposed.proposedRevision,
            revisionFingerprint: proposed.proposedRevisionFingerprint,
            recommendationId: recommendation.recommendationId,
            catalogRevisionToken: recommendation.catalogRevisionToken,
            idempotencyKey: `${job.jobId}-semantic-fallback-packaging`,
          }, { signal })
        }
      }
      const preflight = await fallbackRegistry.invoke('preflight_timeline', {
        projectId: job.projectId,
        timelineId: prepared.timelineId,
        revision: prepared.proposedRevision,
        revisionFingerprint: prepared.proposedRevisionFingerprint,
      }, { signal })
      if (preflight?.ready !== true) {
        logger({
          event: 'editor_semantic_fallback_preflight_rejected',
          errors: Array.isArray(preflight?.errors) ? preflight.errors : [],
        })
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_RESULT_INVALID', 409)
      }
      const finalized = await fallbackRegistry.invoke('finalize_timeline', {
        projectId: job.projectId,
        timelineId: prepared.timelineId,
        revision: prepared.proposedRevision,
        revisionFingerprint: prepared.proposedRevisionFingerprint,
        idempotencyKey: `${job.jobId}-semantic-fallback-finalize`,
      }, { signal })
      await fallbackRegistry.invoke('request_preview', {
        projectId: job.projectId,
        timelineId: latestRevision.timelineId,
        revision: finalized.revision,
        revisionFingerprint: finalized.revisionFingerprint,
        idempotencyKey: `${job.jobId}-semantic-fallback-preview`,
      }, { signal })
      return {
        summary: packagingUnavailableAfterMatch
          ? '已按已确认分镜写入互不重复的镜头并定稿；当前没有可写包装推荐，未写入不完整包装。'
          : '已按已确认分镜写入互不重复的镜头，时间线已定稿并开始生成预览。',
        frozen: fallbackFrozen,
        budgets: fallbackRegistry.budgets(),
      }
    }
    const runPackagingFallback = async () => {
      signal.throwIfAborted()
      if (registry.committedExecutions().length !== 0) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_FAILED', 409)
      }
      const fallbackRegistry = createRegistry([])
      packagingFallbackRegistry = fallbackRegistry
      const fallbackFrozen = createFrozenEditorJobInput({
        instructionFingerprint: job.privateInput.instructionFingerprint,
        baseTimelineFingerprint: job.privateInput.baseTimelineFingerprint,
        toolRegistryFingerprint: job.privateInput.toolRegistryFingerprint,
        capabilityRegistryFingerprint: job.privateInput.capabilityRegistryFingerprint,
        attemptGeneration: attempt.generation,
        fencingToken: attempt.lease.token,
      })
      /** @param {string} tool @param {number} progressPercent */
      const persistFallback = async (tool, progressPercent) => checkpoint(
        'editor_packaging_fallback',
        progressPercent,
        toEditorAgentCheckpointData({
          tool,
          frozen: fallbackFrozen,
          committedExecutions: fallbackRegistry.committedExecutions(),
          detail: editorToolProgressDetail[tool] ?? '正在自动完成包装编排',
        }),
      )
      await fallbackRegistry.invoke('get_project_brief', { projectId: job.projectId }, { signal })
      await persistFallback('get_project_brief', 25)
      const pointer = await richTimelineRepository.getCurrent({ projectId: job.projectId })
      const currentRevision = pointer
        ? await richTimelineRepository.getRevision(pointer)
        : null
      if (!currentRevision || currentRevision.status !== 'draft') {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
      }
      let recommendation = null
      try {
        const recommended = await fallbackRegistry.invoke('recommend_packaging', {
          projectId: job.projectId,
        }, { signal })
        recommendation = recommended?.recommendation
      } catch (error) {
        if (errorCode(error) !== 'WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE') throw error
      }
      if (!isRecord(recommendation)) {
        // A follow-template packaging revision may legitimately have no new
        // catalog recommendation: the shadow draft already carries the
        // authored flower/bubble/effect/sticker slots. Preserve that draft
        // and continue through the normal preflight/finalize/output path.
        const retainedPackaging = hasExecutableTemplatePackaging(currentRevision)
        if (!retainedPackaging) {
          const parent = Number.isSafeInteger(currentRevision.parentRevision)
            ? await richTimelineRepository.getRevision({
                projectId: job.projectId,
                timelineId: currentRevision.timelineId,
                revision: currentRevision.parentRevision,
              })
            : null
          if (
            parent?.status !== 'finalized' ||
            parent.revisionFingerprint !== currentRevision.parentRevisionFingerprint
          ) {
            throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
          }
          await richTimelineRepository.setCurrent({
            projectId: job.projectId,
            timelineId: parent.timelineId,
            revision: parent.revision,
            expectedCurrent: {
              timelineId: currentRevision.timelineId,
              revision: currentRevision.revision,
            },
          })
          return {
            summary: '已保留当前镜头并定稿；当前没有可写包装推荐，未写入不完整包装。',
            frozen: fallbackFrozen,
            budgets: fallbackRegistry.budgets(),
            keptPreviousFinalized: {
              timelineId: parent.timelineId,
              revision: parent.revision,
              revisionFingerprint: parent.revisionFingerprint,
            },
          }
        }
        const preflight = await fallbackRegistry.invoke('preflight_timeline', {
          projectId: job.projectId,
          timelineId: currentRevision.timelineId,
          revision: currentRevision.revision,
          revisionFingerprint: currentRevision.revisionFingerprint,
        }, { signal })
        if (preflight?.ready !== true) {
          throw coordinatorError('WORKBENCH_EDITOR_AGENT_RESULT_INVALID', 409)
        }
        await persistFallback('preflight_timeline', 75)
        await fallbackRegistry.invoke('finalize_timeline', {
          projectId: job.projectId,
          timelineId: currentRevision.timelineId,
          revision: currentRevision.revision,
          revisionFingerprint: currentRevision.revisionFingerprint,
          idempotencyKey: `${job.jobId}-packaging-fallback-finalize-retained`,
        }, { signal })
        await persistFallback('finalize_timeline', 88)
        return {
          summary: '当前模板已有有效包装，本次未找到更换候选，已保留模板并完成定稿。',
          frozen: fallbackFrozen,
          budgets: fallbackRegistry.budgets(),
        }
      }
      await persistFallback('recommend_packaging', 45)
      const applied = await fallbackRegistry.invoke('apply_packaging_recommendation', {
        projectId: job.projectId,
        timelineId: currentRevision.timelineId,
        revision: currentRevision.revision,
        revisionFingerprint: currentRevision.revisionFingerprint,
        recommendationId: recommendation.recommendationId,
        catalogRevisionToken: recommendation.catalogRevisionToken,
        idempotencyKey: `${job.jobId}-packaging-fallback-apply`,
      }, { signal })
      await persistFallback('apply_packaging_recommendation', 65)
      const preflight = await fallbackRegistry.invoke('preflight_timeline', {
        projectId: job.projectId,
        timelineId: applied.timelineId,
        revision: applied.proposedRevision,
        revisionFingerprint: applied.proposedRevisionFingerprint,
      }, { signal })
      if (preflight?.ready !== true) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_RESULT_INVALID', 409)
      }
      await persistFallback('preflight_timeline', 75)
      await fallbackRegistry.invoke('finalize_timeline', {
        projectId: job.projectId,
        timelineId: applied.timelineId,
        revision: applied.proposedRevision,
        revisionFingerprint: applied.proposedRevisionFingerprint,
        idempotencyKey: `${job.jobId}-packaging-fallback-finalize`,
      }, { signal })
      await persistFallback('finalize_timeline', 88)
      return {
        summary: '模型未完成工具调用，已由受控编排器自动选择并应用包装。',
        frozen: fallbackFrozen,
        budgets: fallbackRegistry.budgets(),
      }
    }
    let result
    if (llmRequiredSemanticSegmentCount === 0 && prematchedTimelineIdentity) {
      // Confirmed storyboard shots are already on the draft. A thinking-model
      // packaging loop can sit on one empty/invalid turn until the lease dies
      // and surface WORKBENCH_EDITOR_AGENT_FAILED after 10–30 minutes.
      logger({ event: 'editor_agent_finalize_prematched', code: 'INDEX_PREMATCH_COMPLETE' })
      await checkpoint('editor_semantic_prematch', 70, toEditorAgentCheckpointData({
        tool: 'propose_timeline_patch',
        committedExecutions: registry.committedExecutions(),
        detail: '已按已确认分镜写入全部镜头，正在完成包装和定稿',
      }))
      result = await finalizePrematchedDraft(registry, prematchedTimelineIdentity)
    } else try {
      result = await agent.run({
        instruction: job.privateInput.editorInstruction,
        signal,
      })
    } catch (error) {
      const code = errorCode(error)
      const committedTools = new Set(
        registry.committedExecutions().map((execution) => execution.tool),
      )
      const agentAlreadyFinalized = committedTools.has('finalize_timeline') &&
        (job.privateInput.automaticOutputs === true || committedTools.has('request_preview'))
      if (
        agentAlreadyFinalized &&
        ['EDITOR_AGENT_TIMEOUT', 'EDITOR_AGENT_INCOMPLETE_WORKFLOW', 'EDITOR_AGENT_FINISH_INVALID'].includes(code ?? '')
      ) {
        logger({ event: 'editor_agent_keep_completed_workflow', code })
        result = {
          summary: job.privateInput.automaticOutputs === true
            ? '时间线已定稿，等待服务器创建 Preview 和剪映输出任务。'
            : '时间线已定稿，预览任务已排队，等待渲染结果。',
          frozen: createFrozenEditorJobInput({
            instructionFingerprint: job.privateInput.instructionFingerprint,
            baseTimelineFingerprint: job.privateInput.baseTimelineFingerprint,
            toolRegistryFingerprint: job.privateInput.toolRegistryFingerprint,
            capabilityRegistryFingerprint: job.privateInput.capabilityRegistryFingerprint,
            attemptGeneration: attempt.generation,
            fencingToken: attempt.lease.token,
          }),
          budgets: registry.budgets(),
        }
      } else {
      const packagingFallbackAllowed =
        isAutomaticPackagingRevision(job.privateInput) &&
        job.privateInput.semanticCreate !== true &&
        !signal.aborted &&
        packagingFallbackCodes.has(code ?? '') &&
        !registry.committedExecutions().some((execution) =>
          execution.tool === 'apply_packaging_recommendation')
      if (packagingFallbackAllowed) {
        logger({ event: 'editor_agent_packaging_fallback', code })
        try {
          result = await runPackagingFallback()
        } catch (fallbackError) {
          logger({
            event: 'editor_agent_packaging_fallback_failed',
            code: errorCode(fallbackError) ?? 'WORKBENCH_EDITOR_AGENT_FAILED',
          })
          throw fallbackError
        }
      } else {
        if (
          job.privateInput.semanticCreate !== true ||
          requiredSemanticSegmentIds.length === 0 ||
          signal.aborted ||
          !(
            semanticFallbackCodes.has(code ?? '') ||
            (
              job.privateInput.automaticPackaging === true &&
              packagingFallbackCodes.has(code ?? '')
            )
          )
        ) throw error
        if (llmRequiredSemanticSegmentCount === 0 && prematchedTimelineIdentity) {
          logger({ event: 'editor_agent_finalize_prematched', code })
          try {
            result = await finalizePrematchedDraft(registry, prematchedTimelineIdentity)
          } catch (fallbackError) {
            logger({
              event: 'editor_agent_finalize_prematched_failed',
              code: errorCode(fallbackError) ?? 'WORKBENCH_EDITOR_AGENT_FAILED',
            })
            throw fallbackError
          }
        } else {
        logger({ event: 'editor_agent_semantic_fallback', code })
        try {
          result = await runSemanticFallback()
        } catch (fallbackError) {
          logger({
            event: 'editor_agent_semantic_fallback_failed',
            code: errorCode(fallbackError) ?? 'WORKBENCH_EDITOR_AGENT_FAILED',
          })
          throw fallbackError
        }
        }
      }
      }
    }
    if (!result) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_RESULT_INVALID', 409)
    }
    const currentPointer = await richTimelineRepository.getCurrent({ projectId: job.projectId })
    const currentTimeline = currentPointer
      ? await richTimelineRepository.getRevision(currentPointer)
      : null
    const keptPreviousFinalized = isRecord(/** @type {Record<string, any>} */ (result).keptPreviousFinalized)
      && currentTimeline?.status === 'finalized'
      && currentTimeline.timelineId === /** @type {Record<string, any>} */ (result).keptPreviousFinalized.timelineId
      && currentTimeline.revision === /** @type {Record<string, any>} */ (result).keptPreviousFinalized.revision
      && currentTimeline.revisionFingerprint === /** @type {Record<string, any>} */ (result).keptPreviousFinalized.revisionFingerprint
    if (
      !currentTimeline ||
      currentTimeline.status !== 'finalized' ||
      (
        !keptPreviousFinalized &&
        (
          currentTimeline.source?.kind !== 'agent' ||
          currentTimeline.source?.instructionFingerprint !== job.privateInput.instructionFingerprint
        )
      )
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_RESULT_INVALID', 409)
    }
    const executionRegistry = packagingFallbackRegistry ?? semanticFallbackRegistry ?? registry
    if (!keptPreviousFinalized && job.privateInput.automaticOutputs === true) {
      await requestAutomaticOutputChildren({
        currentTimeline,
        executionRegistry,
        frozen: result.frozen,
        toolCalls: result.budgets.toolCalls,
      })
    }
    try {
      await checkpoint('editor_agent_finish', 95, toEditorAgentCheckpointData({
        toolCalls: result.budgets.toolCalls,
        frozen: result.frozen,
        committedExecutions: executionRegistry.committedExecutions(),
        detail: '时间线已定稿，正在确认任务结果',
      }))
    } catch (error) {
      if (error instanceof EditorAgentContractError) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_CHECKPOINT_INVALID', 409)
      }
      throw error
    }
    return {
      resourceId: `editor-${job.jobId}`,
      summary: result.summary.slice(0, 1000),
      timelineId: currentTimeline.timelineId,
      timelineRevision: currentTimeline.revision,
      timelineRevisionFingerprint: currentTimeline.revisionFingerprint,
    }
  }

  /**
   * @param {unknown} input
   * @param {{automaticOutputs?: boolean}} [internalOptions]
   */
  const createEditorAgentJob = async (input, internalOptions = {}) => {
    const inputRecord = isRecord(input) ? /** @type {Record<string, unknown>} */ (input) : null
    const inputKeys = inputRecord
      ? Object.keys(inputRecord).sort().join('\u0000')
      : ''
    const acceptsFreshRetry = (
      inputKeys === ['automaticPackaging', 'fresh', 'idempotencyKey', 'instruction'].sort().join('\u0000') ||
      inputKeys === ['automaticPackaging', 'fresh', 'idempotencyKey', 'instruction', 'packagingFeedbackHandle'].sort().join('\u0000')
    ) &&
      typeof inputRecord?.fresh === 'boolean' &&
      typeof inputRecord?.automaticPackaging === 'boolean' &&
      (inputRecord.packagingFeedbackHandle === undefined || inputRecord.packagingFeedbackHandle === null || typeof inputRecord.packagingFeedbackHandle === 'string')
    const acceptsStandardInput = (
      inputKeys === ['automaticPackaging', 'idempotencyKey', 'instruction'].sort().join('\u0000') ||
      inputKeys === ['automaticPackaging', 'idempotencyKey', 'instruction', 'packagingFeedbackHandle'].sort().join('\u0000')
    ) &&
      typeof inputRecord?.automaticPackaging === 'boolean' &&
      (inputRecord.packagingFeedbackHandle === undefined || inputRecord.packagingFeedbackHandle === null || typeof inputRecord.packagingFeedbackHandle === 'string')
    const acceptsLegacyStandardInput = inputKeys ===
      ['idempotencyKey', 'instruction'].sort().join('\u0000')
    const acceptsLegacyFreshRetry = inputKeys ===
      ['fresh', 'idempotencyKey', 'instruction'].sort().join('\u0000') &&
      typeof inputRecord?.fresh === 'boolean'
    if (
      !inputRecord ||
      (!acceptsStandardInput && !acceptsFreshRetry && !acceptsLegacyStandardInput && !acceptsLegacyFreshRetry) ||
      !identifier(inputRecord.idempotencyKey) ||
      !isRecord(inputRecord.instruction)
    ) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    }
    if (!llmGateway || typeof llmGateway.generate !== 'function') {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE', 503)
    }
    if (!richTimelineRepository) {
      throw coordinatorError('WORKBENCH_EDITOR_AGENT_DEPENDENCY_MISSING', 503)
    }
    let instruction = assertEditorInstruction(inputRecord.instruction)
    const semanticCreate = instruction.mode === 'create'
    const automaticPackaging = inputRecord.automaticPackaging === true
    // Automatic packaging creates are product-level exports: once the
    // template timeline is finalized, enqueue both Preview and Jianying.
    // Revisions stay opt-in through internalOptions so ordinary editor jobs
    // do not unexpectedly write a draft.
    const automaticOutputs = internalOptions.automaticOutputs === true ||
      (semanticCreate && automaticPackaging)
    if (
      automaticPackaging &&
      !hasMethods(jianyingDraftCapability, ['exportDraft', 'cleanupDraft', 'commitDraft'])
    ) {
      throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_UNAVAILABLE', 409)
    }
    const requestFingerprint = fingerprintCanonical({
      instruction,
      fresh: inputRecord.fresh === true,
      automaticPackaging,
      automaticOutputs,
      packagingFeedbackHandle: inputRecord.packagingFeedbackHandle ?? null,
    })
    const releaseCreation = await acquireEditorJobCreationLock(instruction.projectId)
    try {
      const existing = typeof jobRepository.getByIdempotencyKey === 'function'
        ? await jobRepository.getByIdempotencyKey(
            instruction.projectId,
            /** @type {string} */ (inputRecord.idempotencyKey),
          )
        : null
      if (existing) {
        if (
          typeof existing.privateInput?.requestFingerprint !== 'string' ||
          existing.privateInput.requestFingerprint !== requestFingerprint
        ) {
          throw coordinatorError('WORKBENCH_JOB_IDEMPOTENCY_CONFLICT', 409)
        }
        return toPublicJobDto(existing)
      }
      if (inputRecord.packagingFeedbackHandle !== null && inputRecord.packagingFeedbackHandle !== undefined &&
          (instruction.mode !== 'revise' || typeof inputRecord.packagingFeedbackHandle !== 'string' ||
            !/^ovpkgfb_v1_[a-f0-9]{24}$/u.test(inputRecord.packagingFeedbackHandle))) {
        throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_FEEDBACK_INVALID', 409)
      }
      const activeEditor = (await jobRepository.listByProject(instruction.projectId)).find((
        /** @type {Record<string, any>} */ candidate,
      ) => candidate.type === EDITOR_JOB_TYPE &&
        ['queued', 'running', 'cancelling'].includes(candidate.status))
      if (activeEditor) {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_BUSY', 409)
      }
    const current = await projectRepository.get(instruction.projectId)
    if (!validProjectSnapshot(current)) {
      throw coordinatorError(
        current ? 'WORKBENCH_JOB_INPUT_INVALID' : 'WORKBENCH_PROJECT_NOT_FOUND',
        current ? 409 : 404,
      )
    }
    /** @type {string | null} */
    let packagingFeedbackToken = null
    /** @type {Record<string, any> | null} */
    let createTimelineInput = null
    if (instruction.mode === 'create') {
      if (!isRecord(current.storyboard) || !identifier(current.storyboard.id)) {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
      }
      const plan = await editPlanRepository.getFinalized({
        projectId: instruction.projectId,
        planId: current.storyboard.id,
      })
      if (plan?.status !== 'finalized' || !isEditPlan(plan.final)) {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
      }
      const selections = previewSelections(current)
      const incompleteStoryboard = !selections ||
        current.storyboard.sentences.some(
          (/** @type {Record<string, any>} */ sentence) => sentence.status !== 'selected',
        ) ||
        plan.final.items.some(
          (/** @type {Record<string, any>} */ item) =>
            item.status !== 'selected' || !identifier(item.selected_candidate_id),
        )
      if (incompleteStoryboard) {
        throw coordinatorError('WORKBENCH_EDITOR_STORYBOARD_INCOMPLETE', 409)
      }
      const materialScenes = new Map(
        (current.materials.assets ?? []).flatMap((/** @type {Record<string, any>} */ asset) =>
          (asset.scenes ?? []).map((/** @type {Record<string, any>} */ scene) => [scene.id, scene])),
      )
      /** @type {string[]} */
      const selectedSceneIds = current.storyboard.sentences
        .map((/** @type {Record<string, any>} */ sentence) => sentence.selectedCandidateId)
        .filter(identifier)
      if (selectedSceneIds.some((sceneId) =>
        requiresMaterialReanalysis(materialScenes.get(sceneId)))) {
        throw coordinatorError('WORKBENCH_EDITOR_MATERIAL_REANALYSIS_REQUIRED', 409)
      }
      const bindingGuidance = createTemplateGuidance(current.templateBinding ?? null)
      const templateGuidance = bindingGuidance
        ? adaptTemplateGuidanceToCount(bindingGuidance, selections.length)
        : null
      const selectedPlan = applyPrivateSelections(plan.final, selections)
      for (const sentence of current.storyboard.sentences ?? []) {
        const item = selectedPlan.items.find((
          /** @type {Record<string, any>} */ entry,
        ) => entry.sentence_id === sentence.id)
        if (item && typeof sentence.text === 'string' && sentence.text.trim()) {
          item.voiceover_text = sentence.text
        }
      }
      createTimelineInput = {
        projectId: instruction.projectId,
        authorizationId: current.materials.authorizationId,
        editPlan: selectedPlan,
        templateGuidance,
        brief: current.brief,
      }
    }
    const freshCreateRetry =
      inputRecord.fresh === true &&
      instruction.mode === 'create' &&
      instruction.baseTimeline === null
    if (instruction.baseTimeline === null) {
      const pointer = freshCreateRetry
        ? null
        : await richTimelineRepository.getCurrent({
            projectId: instruction.projectId,
          })
      let timeline = pointer
        ? await richTimelineRepository.getRevision(pointer)
        : null
      const expectedCreateTimelineId = createTimelineInput
        ? shadowTimelineIdFor(instruction.projectId, createTimelineInput.editPlan)
        : null
      const reusableAutomaticTimeline =
        automaticOutputs &&
        timeline?.timelineId === expectedCreateTimelineId &&
        ['draft', 'finalized'].includes(timeline.status)
      if (
        (
          freshCreateRetry ||
          (automaticOutputs && !reusableAutomaticTimeline) ||
          !timeline ||
          (timeline.status !== 'draft' && !reusableAutomaticTimeline)
        ) &&
        instruction.mode === 'create'
      ) {
        if (!createTimelineInput) {
          throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
        }
        let freshTimelineInput = createTimelineInput
        if (freshCreateRetry && isRecord(createTimelineInput.brief)) {
          const brief = structuredClone(createTimelineInput.brief)
          const packaging = resolvePackagingForExecution(brief.packaging)
          if (packaging.bgm === 'local_authorized' && typeof packaging.bgmAuthorizationId === 'string') {
            let authorized = false
            try {
              authorized = await bgmLibrary?.isAuthorizedTrack({
                projectId: instruction.projectId,
                trackId: packaging.bgmAuthorizationId,
              }) === true
            } catch {
              authorized = false
            }
            if (!authorized) {
              brief.packaging = { ...packaging, bgm: 'none', bgmAuthorizationId: null, bgmLabel: '' }
              freshTimelineInput = { ...createTimelineInput, brief }
              logger({
                event: 'editor_fresh_retry_dropped_invalid_bgm',
                projectId: instruction.projectId,
                dropped: true,
              })
            }
          }
        }
        if (automaticPackaging) {
          freshTimelineInput = {
            ...freshTimelineInput,
            // Provider resolution, catalog revalidation, recommendation and
            // application all run after the durable editor job exists. This
            // keeps slow private-catalog I/O outside the HTTP creation path;
            // the queued worker still fails closed before using any resource.
            suppressAutomaticPackagingRecommendation: true,
          }
        }
        if (automaticOutputs) {
          freshTimelineInput = {
            ...freshTimelineInput,
            suppressAutomaticPackagingRecommendation: true,
          }
        }
        timeline = await persistShadowTimeline(/** @type {any} */ ({
          ...freshTimelineInput,
          // Storyboard is supposed to mint the durable bundle. If that
          // persist returned null or the spoken-text fingerprint drifted,
          // editor create must synthesize instead of 409 before a job exists.
          allowNarrationSynthesis: true,
          ...(freshCreateRetry ? { forceNewDraftRevision: true } : {}),
        }))
      }
      if (timeline?.status === 'finalized') {
        const finalizedParent = {
          timelineId: timeline.timelineId,
          revision: timeline.revision,
          revisionFingerprint: timeline.revisionFingerprint,
          contentFingerprint: timeline.contentFingerprint,
        }
        for (let attempt = 0; attempt < 3; attempt += 1) {
          const pointerAfter = await richTimelineRepository.getCurrent({
            projectId: instruction.projectId,
          })
          const currentRevision = pointerAfter
            ? await richTimelineRepository.getRevision(pointerAfter)
            : null
          if (
            currentRevision?.status === 'draft' &&
            currentRevision.timelineId === finalizedParent.timelineId &&
            currentRevision.parentRevision === finalizedParent.revision &&
            currentRevision.parentRevisionFingerprint === finalizedParent.revisionFingerprint &&
            currentRevision.contentFingerprint === finalizedParent.contentFingerprint
          ) {
            timeline = currentRevision
            break
          }
          if (!currentRevision || currentRevision.status !== 'finalized') {
            timeline = currentRevision
            break
          }
          const draft = sealRichTimeline({
            ...currentRevision,
            revision: currentRevision.revision + 1,
            parentRevision: currentRevision.revision,
            parentRevisionFingerprint: currentRevision.revisionFingerprint,
            status: 'draft',
            source: {
              ...clone(currentRevision.source),
              kind: 'editor',
              instructionFingerprint: null,
            },
          })
          try {
            timeline = await richTimelineRepository.saveDraftAndSetCurrent({
              timeline: draft,
              expectedCurrent: {
                timelineId: currentRevision.timelineId,
                revision: currentRevision.revision,
              },
            })
            break
          } catch (error) {
            if (
              !(error instanceof RichTimelineRepositoryError) ||
              error.code !== 'RICH_TIMELINE_CAS_CONFLICT' ||
              attempt === 2
            ) {
              rethrowRichTimelineError(error)
            }
          }
        }
      }
      if (!timeline || timeline.status !== 'draft') {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
      }
      instruction = {
        ...instruction,
        mode: 'revise',
        baseTimeline: {
          timelineId: timeline.timelineId,
          revision: timeline.revision,
          revisionFingerprint: timeline.revisionFingerprint,
        },
      }
    } else if (instruction.mode === 'revise') {
      const requestedBase = await richTimelineRepository.getRevision({
        projectId: instruction.projectId,
        timelineId: instruction.baseTimeline.timelineId,
        revision: instruction.baseTimeline.revision,
      })
      if (
        !requestedBase ||
        requestedBase.revisionFingerprint !== instruction.baseTimeline.revisionFingerprint
      ) {
        throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
      }
      if (typeof inputRecord.packagingFeedbackHandle === 'string') {
        packagingFeedbackToken = resolvePackagingFeedbackHandle(
          requestedBase,
          inputRecord.packagingFeedbackHandle,
        )
        if (!packagingFeedbackToken) {
          throw coordinatorError('WORKBENCH_EDITOR_PACKAGING_FEEDBACK_INVALID', 409)
        }
      }
      let timeline = requestedBase
      if (requestedBase.status === 'finalized') {
        for (let attempt = 0; attempt < 3; attempt += 1) {
          const pointer = await richTimelineRepository.getCurrent({
            projectId: instruction.projectId,
          })
          const currentRevision = pointer
            ? await richTimelineRepository.getRevision(pointer)
            : null
          if (
            currentRevision?.status === 'draft' &&
            currentRevision.timelineId === requestedBase.timelineId &&
            currentRevision.parentRevision === requestedBase.revision &&
            currentRevision.parentRevisionFingerprint === requestedBase.revisionFingerprint &&
            currentRevision.contentFingerprint === requestedBase.contentFingerprint
          ) {
            timeline = currentRevision
            break
          }
          if (
            !currentRevision ||
            currentRevision.status !== 'finalized' ||
            currentRevision.timelineId !== requestedBase.timelineId ||
            currentRevision.revision !== requestedBase.revision ||
            currentRevision.revisionFingerprint !== requestedBase.revisionFingerprint
          ) {
            throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
          }
          const revisions = await richTimelineRepository.listRevisions({
            projectId: requestedBase.projectId,
            timelineId: requestedBase.timelineId,
          })
          const reusableDrafts = revisions.filter((/** @type {Record<string, any>} */ revision) =>
            revision.status === 'draft' &&
            revision.parentRevision === requestedBase.revision &&
            revision.parentRevisionFingerprint === requestedBase.revisionFingerprint &&
            revision.contentFingerprint === requestedBase.contentFingerprint &&
            revision.source?.kind === 'editor' &&
            revision.source?.instructionFingerprint === null)
          if (reusableDrafts.length > 1) {
            throw coordinatorError('WORKBENCH_RICH_TIMELINE_SHADOW_INVALID', 409)
          }
          if (reusableDrafts.length === 1) {
            try {
              await richTimelineRepository.setCurrent({
                projectId: requestedBase.projectId,
                timelineId: requestedBase.timelineId,
                revision: reusableDrafts[0].revision,
                expectedCurrent: {
                  timelineId: requestedBase.timelineId,
                  revision: requestedBase.revision,
                },
              })
              timeline = reusableDrafts[0]
              break
            } catch (error) {
              if (
                !(error instanceof RichTimelineRepositoryError) ||
                error.code !== 'RICH_TIMELINE_CAS_CONFLICT' ||
                attempt === 2
              ) {
                rethrowRichTimelineError(error)
              }
              continue
            }
          }
          const nextRevision = Math.max(
            requestedBase.revision,
            ...revisions.map((/** @type {Record<string, any>} */ revision) => revision.revision),
          ) + 1
          const draft = sealRichTimeline({
            ...requestedBase,
            revision: nextRevision,
            parentRevision: requestedBase.revision,
            parentRevisionFingerprint: requestedBase.revisionFingerprint,
            status: 'draft',
            source: {
              ...clone(requestedBase.source),
              kind: 'editor',
              instructionFingerprint: null,
            },
          })
          try {
            timeline = await richTimelineRepository.saveDraftAndSetCurrent({
              timeline: draft,
              expectedCurrent: {
                timelineId: requestedBase.timelineId,
                revision: requestedBase.revision,
              },
            })
            break
          } catch (error) {
            if (
              !(error instanceof RichTimelineRepositoryError) ||
              error.code !== 'RICH_TIMELINE_CAS_CONFLICT' ||
              attempt === 2
            ) {
              rethrowRichTimelineError(error)
            }
          }
        }
      }
      if (timeline.status !== 'draft') {
        throw coordinatorError('WORKBENCH_EDITOR_TIMELINE_REQUIRED', 409)
      }
      instruction = {
        ...instruction,
        baseTimeline: {
          timelineId: timeline.timelineId,
          revision: timeline.revision,
          revisionFingerprint: timeline.revisionFingerprint,
        },
      }
    }
    const instructionFingerprint = fingerprintCanonical({
      instruction: instruction.instruction,
      mode: instruction.mode,
      baseTimeline: instruction.baseTimeline,
    })
    const toolRegistryFingerprint = fingerprintCanonical({
      tools: EDITOR_TOOL_NAMES,
      budgets: EDITOR_BUDGETS,
    })
    const capabilityRegistryFingerprint =
      createEditorCapabilityRegistry(editorCapabilityOptions).registryFingerprint
    /** @type {Record<string, any>} */
    const privateInput = {
      projectId: instruction.projectId,
      type: EDITOR_JOB_TYPE,
      editorInstruction: {
        projectId: instruction.projectId,
        instruction: instruction.instruction,
        baseTimeline: instruction.baseTimeline,
        mode: instruction.mode,
        idempotencyKey: instruction.idempotencyKey,
      },
      instructionFingerprint,
      baseTimelineFingerprint: instruction.baseTimeline?.revisionFingerprint ?? null,
      toolRegistryFingerprint,
      capabilityRegistryFingerprint,
      requestFingerprint,
      semanticCreate,
      automaticPackaging,
      automaticOutputs,
      packagingFeedbackHandle: inputRecord.packagingFeedbackHandle ?? null,
      packagingFeedbackToken,
      riskFlags: instruction.riskFlags,
    }
    privateInput.inputFingerprint = fingerprint(privateInput)
    const createdAt = nowIso()
    const job = assertJobRecord({
      jobId: createId('job'),
      projectId: instruction.projectId,
      idempotencyKey: inputRecord.idempotencyKey,
      type: EDITOR_JOB_TYPE,
      status: 'queued',
      createdAt,
      updatedAt: createdAt,
      cancelRequestedAt: null,
      privateInput,
      attempts: [{
        attemptId: createId('attempt'),
        generation: 1,
        deadlineAt: null,
        status: 'queued',
        startedAt: null,
        finishedAt: null,
        lease: null,
        error: null,
      }],
      checkpoint: null,
      result: null,
      error: null,
    })
    let stored
    try {
      stored = await jobRepository.createOrGetExclusiveByType(job)
    } catch (error) {
      if (errorCode(error) === 'WORKBENCH_JOB_TYPE_ALREADY_RUNNING') {
        throw coordinatorError('WORKBENCH_EDITOR_AGENT_BUSY', 409)
      }
      throw error
    }
    enqueue(stored)
    return toPublicJobDto(stored)
    } finally {
      releaseCreation()
    }
  }

  /**
   * @param {Record<string, any>} storyboardJob
   * @param {Record<string, any> | null} [storyboardResult]
   */
  const maybeCreateAutomaticCreativeEditorJob = async (
    storyboardJob,
    storyboardResult = null,
    { retryPartialOutputs = false } = {},
  ) => {
    if (!creativeAutoOutputs || creativePlanningMode !== 'active') return null
    if (storyboardJob?.type !== 'storyboard_generation') return null
    if (!identifier(storyboardJob.projectId) || !identifier(storyboardJob.jobId)) return null
    if (storyboardJob.privateInput?.creativeAutoOutputs !== true) return null
    const persistedParent = await jobRepository.get(storyboardJob.projectId, storyboardJob.jobId)
    if (
      persistedParent?.status !== 'succeeded' ||
      persistedParent.privateInput?.creativeAutoOutputs !== true
    ) return null
    const outputFingerprint = storyboardResult?.outputFingerprint ??
      persistedParent.result?.outputFingerprint
    if (!identifier(outputFingerprint)) return null
    const current = await projectRepository.get(storyboardJob.projectId)
    if (
      !validProjectSnapshot(current) ||
      !safeBrief(current.brief) ||
      !isRecord(current.storyboard) ||
      fingerprint(current.storyboard) !== outputFingerprint ||
      !Array.isArray(current.storyboard.sentences) ||
      current.storyboard.sentences.length === 0 ||
      current.storyboard.sentences.some((/** @type {Record<string, any>} */ sentence) =>
        sentence?.status !== 'selected')
    ) return null
    const idempotencyKey = `creative-auto-editor-${storyboardJob.jobId}`
    try {
      if (!hasMethods(jianyingDraftCapability, ['exportDraft', 'cleanupDraft', 'commitDraft'])) {
        throw coordinatorError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE', 503)
      }
      const editor = await createEditorAgentJob({
        idempotencyKey,
        automaticPackaging: false,
        instruction: {
          projectId: storyboardJob.projectId,
          instruction: creativeAutomaticEditorInstruction,
          baseTimeline: null,
          mode: 'create',
          idempotencyKey,
        },
      }, { automaticOutputs: true })
      const persistedEditor = await jobRepository.getByIdempotencyKey(
        storyboardJob.projectId,
        idempotencyKey,
      )
      const committedExecutions = Array.isArray(
        persistedEditor?.checkpoint?.data?.committedExecutions,
      )
        ? persistedEditor.checkpoint.data.committedExecutions
        : []
      const hasPreview = committedExecutions.some((/** @type {Record<string, any>} */ execution) =>
        execution?.tool === 'request_preview')
      const hasJianying = committedExecutions.some((/** @type {Record<string, any>} */ execution) =>
        execution?.tool === 'request_jianying_export')
      if (
        retryPartialOutputs &&
        persistedEditor?.privateInput?.automaticOutputs === true &&
        ['failed', 'timed_out'].includes(persistedEditor.status) &&
        hasPreview &&
        !hasJianying
      ) {
        return retryJob(storyboardJob.projectId, persistedEditor.jobId)
      }
      return editor
    } catch (error) {
      if (errorCode(error) === 'WORKBENCH_EDITOR_AGENT_BUSY') {
        const exactEditor = typeof jobRepository.getByIdempotencyKey === 'function'
          ? await jobRepository.getByIdempotencyKey(storyboardJob.projectId, idempotencyKey)
          : null
        if (
          exactEditor?.type === EDITOR_JOB_TYPE &&
          exactEditor.idempotencyKey === idempotencyKey &&
          exactEditor.privateInput?.automaticOutputs === true
        ) return toPublicJobDto(exactEditor)
      }
      logger({
        event: 'creative_auto_editor_continuation_failed',
        code: errorCode(error) ?? 'WORKBENCH_UNKNOWN_FAILURE',
      })
      return null
    }
  }

  const recoverAutomaticCreativeContinuations = async ({ retryPartialOutputs = false } = {}) => {
    if (!creativeAutoOutputs || creativePlanningMode !== 'active') return
    if (!hasMethods(jobRepository, ['listByProject'])) return
    const listProjects = /** @type {Record<string, Function>} */ (projectRepository).list
    const projects = typeof listProjects === 'function'
      ? await listProjects.call(projectRepository)
      : []
    const projectIds = new Set()
    for (const project of projects) {
      if (identifier(project?.id)) projectIds.add(project.id)
    }
    for (const projectId of projectIds) {
      if (!identifier(projectId)) continue
      const jobs = await jobRepository.listByProject(projectId)
      const storyboards = jobs
        .filter((/** @type {Record<string, any>} */ job) =>
          job.type === 'storyboard_generation' &&
          job.status === 'succeeded' &&
          job.privateInput?.creativeAutoOutputs === true)
        .sort((
          /** @type {Record<string, any>} */ left,
          /** @type {Record<string, any>} */ right,
        ) => Date.parse(right.updatedAt) - Date.parse(left.updatedAt))
      for (const storyboard of storyboards) {
        await maybeCreateAutomaticCreativeEditorJob(
          storyboard,
          null,
          { retryPartialOutputs },
        )
      }
    }
  }

  /** @param {string} projectId @param {string} jobId */
  const getJob = async (projectId, jobId) => {
    if (!identifier(projectId) || !identifier(jobId)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    }
    const job = await jobRepository.get(projectId, jobId)
    return job ? toPublicJobDto(job) : null
  }
  /**
   * A process interruption can persist project progress after its owning job
   * has already reached a terminal state. Reconcile that split state before
   * exposing jobs so the UI never polls an analysis that cannot be cancelled.
   * @param {string} projectId
   * @param {Record<string, any>[]} jobs
   */
  const reconcileMaterialAnalysisState = async (projectId, jobs) => {
    const hasActiveAnalysis = jobs.some((/** @type {Record<string, any>} */ job) =>
      job.type === 'material_analysis' &&
      ['queued', 'running', 'cancelling'].includes(job.status))
    if (hasActiveAnalysis) return

    for (let attempt = 0; attempt < 5; attempt += 1) {
      const current = await projectRepository.get(projectId)
      if (!current || current.materials?.analysisStatus !== 'analyzing') return
      const latestJobs = await jobRepository.listByProject(projectId)
      if (latestJobs.some((/** @type {Record<string, any>} */ job) =>
        job.type === 'material_analysis' &&
        ['queued', 'running', 'cancelling'].includes(job.status))) return
      const total = Number.isSafeInteger(current.materials.total)
        ? Math.max(0, current.materials.total)
        : 0
      const analyzed = Number.isSafeInteger(current.materials.analyzed)
        ? Math.max(0, Math.min(total, current.materials.analyzed))
        : 0
      const next = {
        ...clone(current),
        materials: {
          ...clone(current.materials),
          total,
          analyzed,
          queued: Math.max(0, total - analyzed),
          failed: Math.max(1, current.materials.failed ?? 0),
          analysisStatus: 'failed',
          analysisProgress: null,
        },
        updatedAt: nowIso(),
      }
      if (await projectRepository.saveIfCurrent(next, current)) return
    }
    throw coordinatorError('WORKBENCH_JOB_INPUT_SUPERSEDED', 409)
  }
  /** @type {Promise<void> | null} */
  let jobListPrune = null
  let jobListPrunedAt = 0
  /** @type {Map<string, Promise<void>>} */
  const jobListReconciliations = new Map()
  /** @param {string} projectId */
  const listJobs = async (projectId) => {
    if (!identifier(projectId)) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    const jobs = await jobRepository.listByProject(projectId)
    const materialLockBusy = materialStateLocks.has(projectId)
    let reconciliation = jobListReconciliations.get(projectId)
    // Read-side maintenance must not wait behind long generation write leases.
    // Keep a bounded single flight per project; later polling retries overflow.
    if (!reconciliation && jobListReconciliations.size < 32) {
      reconciliation = withMaterialStateLock(projectId, () => reconcileMaterialAnalysisState(projectId, jobs))
        .catch(() => { logger({ event: 'workbench_job_list_reconciliation_failed' }) })
        .finally(() => { jobListReconciliations.delete(projectId) })
      jobListReconciliations.set(projectId, reconciliation)
    }
    if (reconciliation && !materialLockBusy) {
      // Preserve immediate orphan recovery when uncontended, with a hard read
      // budget if persistence is busy. The same recovery continues in background.
      /** @type {ReturnType<typeof setTimeout> | undefined} */
      let timeout
      try {
        await Promise.race([reconciliation, new Promise((resolve) => { timeout = setTimeout(resolve, 50) })])
      } finally {
        if (timeout) clearTimeout(timeout)
      }
    }
    if (!jobListPrune && Date.now() - jobListPrunedAt >= 60_000 && typeof jobRepository.pruneTerminal === 'function') {
      jobListPrune = Promise.resolve().then(() => jobRepository.pruneTerminal({
        now: nowIso(), retentionDays: 30, maximumPerProject: 100,
      })).then(() => undefined, () => { logger({ event: 'workbench_job_list_prune_failed' }) })
        .finally(() => { jobListPrunedAt = Date.now(); jobListPrune = null })
    }
    return jobs.map(toPublicJobDto)
  }
  const globalJobProjectLimit = 20
  /** @param {string[]} projectIds */
  const listJobsForProjects = async (projectIds) => {
    const unique = [...new Set((Array.isArray(projectIds) ? projectIds : []).filter(identifier))]
      .slice(0, globalJobProjectLimit)
    if (!unique.length) return []
    const jobs = typeof jobRepository.listByProjects === 'function'
      ? await jobRepository.listByProjects(unique)
      : (await Promise.all(unique.map((projectId) => jobRepository.listByProject(projectId)))).flat()
    for (const projectId of unique) {
      if (jobListReconciliations.has(projectId) || jobListReconciliations.size >= 32) continue
      const projectJobs = jobs.filter((/** @type {any} */ job) => job.projectId === projectId)
      const reconciliation = withMaterialStateLock(projectId, () => reconcileMaterialAnalysisState(projectId, projectJobs))
        .catch(() => { logger({ event: 'workbench_job_list_reconciliation_failed' }) })
        .finally(() => { jobListReconciliations.delete(projectId) })
      jobListReconciliations.set(projectId, reconciliation)
    }
    if (!jobListPrune && Date.now() - jobListPrunedAt >= 60_000 && typeof jobRepository.pruneTerminal === 'function') {
      jobListPrune = Promise.resolve().then(() => jobRepository.pruneTerminal({
        now: nowIso(), retentionDays: 30, maximumPerProject: 100,
      })).then(() => undefined, () => { logger({ event: 'workbench_job_list_prune_failed' }) })
        .finally(() => { jobListPrunedAt = Date.now(); jobListPrune = null })
    }
    return jobs.map(toPublicJobDto)
  }
  /** @param {string} projectId @param {string[]} jobIds */
  const dismissJobs = async (projectId, jobIds) => {
    if (
      !identifier(projectId) ||
      !Array.isArray(jobIds) ||
      jobIds.length === 0 ||
      jobIds.some((jobId) => !identifier(jobId))
    ) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    if (typeof jobRepository.dismissTerminal !== 'function') {
      throw coordinatorError('WORKBENCH_JOB_DISMISS_UNAVAILABLE', 503)
    }
    return jobRepository.dismissTerminal({
      projectId,
      jobIds,
      dismissedAt: nowIso(),
    })
  }
  /** @param {string} projectId */
  const dismissFailedJobs = async (projectId) => {
    if (!identifier(projectId)) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    const jobs = await jobRepository.listByProject(projectId)
    const jobIds = jobs
      .filter((/** @type {Record<string, any>} */ job) =>
        ['failed', 'cancelled', 'timed_out'].includes(job.status))
      .map((/** @type {Record<string, any>} */ job) => job.jobId)
    if (!jobIds.length) return []
    return dismissJobs(projectId, jobIds)
  }
  /** @param {string} projectId */
  const assertProjectIdle = async (projectId) => {
    if (!identifier(projectId)) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    const jobs = await jobRepository.listByProject(projectId)
    const busy = jobs.some((/** @type {Record<string, any>} */ job) =>
      ['queued', 'running', 'cancelling'].includes(job.status)) ||
      [...pending.keys(), ...active.keys(), ...retrying].some((key) => key.startsWith(`${projectId}\u0000`))
    if (busy) throw coordinatorError('WORKBENCH_PROJECT_BUSY', 409)
    return true
  }
  /** @param {string} projectId */
  const deleteProjectData = async (projectId) => {
    await assertProjectIdle(projectId)
    if (
      typeof jobRepository.removeByProject !== 'function' ||
      typeof editPlanRepository.removeByProject !== 'function' ||
      (richTimelineRepository && typeof richTimelineRepository.removeByProject !== 'function')
    ) {
      throw coordinatorError('WORKBENCH_PROJECT_CLEANUP_UNAVAILABLE', 503)
    }
    await editPlanRepository.removeByProject(projectId)
    await richTimelineRepository?.removeByProject({ projectId })
    await jobRepository.removeByProject(projectId)
    return true
  }
  /** @param {string} projectId @param {{createdBefore?: string}} [options] */
  const invalidateProjectOutputs = async (projectId, options = {}) => {
    if (!identifier(projectId)) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    const createdBefore = options.createdBefore
    if (
      createdBefore !== undefined &&
      (typeof createdBefore !== 'string' || !Number.isFinite(Date.parse(createdBefore)))
    ) throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    const createdBeforeMs = createdBefore === undefined
      ? Number.POSITIVE_INFINITY
      : Date.parse(createdBefore)
    if (typeof jobRepository.invalidateProjectOutputs !== 'function') {
      throw coordinatorError('WORKBENCH_JOB_INVALIDATION_UNAVAILABLE', 503)
    }
    const outputTypes = new Set([
      EDITOR_JOB_TYPE,
      'storyboard_generation',
      'preview_generation',
      'jianying_draft_export',
    ])
    const jobs = await jobRepository.listByProject(projectId)
    for (const job of jobs) {
      if (!outputTypes.has(job.type) || Date.parse(job.createdAt) > createdBeforeMs) continue
      pending.delete(keyOf(projectId, job.jobId))
      active.get(keyOf(projectId, job.jobId))?.controller?.abort(
        coordinatorError('WORKBENCH_JOB_INPUT_INVALIDATED', 409),
      )
    }
    const invalidated = await jobRepository.invalidateProjectOutputs({
      projectId,
      types: [...outputTypes],
      invalidatedAt: nowIso(),
      ...(createdBefore === undefined ? {} : { createdBefore }),
    })
    if (richTimelineRepository) {
      for (let attempt = 0; attempt < 3; attempt += 1) {
        try {
          const pointer = await richTimelineRepository.getCurrent({ projectId })
          const timeline = pointer
            ? await richTimelineRepository.getRevision(pointer)
            : null
          const latestJobs = await jobRepository.listByProject(projectId)
          const timelineOwner = timeline?.source?.kind === 'agent'
            ? latestJobs.find((/** @type {Record<string, any>} */ job) =>
              job.type === EDITOR_JOB_TYPE &&
              job.privateInput?.instructionFingerprint === timeline.source.instructionFingerprint &&
              job.result?.timelineId === timeline.timelineId &&
              job.result?.timelineRevision === timeline.revision &&
              job.result?.timelineRevisionFingerprint === timeline.revisionFingerprint)
            : null
          if (timelineOwner && Date.parse(timelineOwner.createdAt) > createdBeforeMs) break
          await richTimelineRepository.clearCurrent({
            projectId,
            expectedCurrent: pointer
              ? { timelineId: pointer.timelineId, revision: pointer.revision }
              : null,
          })
          break
        } catch (error) {
          if (
            error instanceof RichTimelineRepositoryError &&
            error.code === 'RICH_TIMELINE_CAS_CONFLICT' &&
            attempt < 2
          ) continue
          rethrowRichTimelineError(error)
        }
      }
    }
    return invalidated.map(toPublicJobDto)
  }
  /** @param {string} projectId @param {string} jobId */
  const cancelJob = async (projectId, jobId) => {
    if (!identifier(projectId) || !identifier(jobId)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    }
    const requested = await jobRepository.requestCancel({
      projectId,
      jobId,
      requestedAt: nowIso(),
    })
    active.get(keyOf(projectId, jobId))?.controller?.abort(
      coordinatorError('WORKBENCH_JOB_CANCELLED', 409),
    )
    if (requested.status === 'cancelling') enqueue(requested)
    return toPublicJobDto(requested)
  }
  /** @param {string} projectId @param {string} jobId */
  const retryJob = async (projectId, jobId) => {
    if (!identifier(projectId) || !identifier(jobId)) {
      throw coordinatorError('WORKBENCH_JOB_INPUT_INVALID', 400)
    }
    const retryKey = keyOf(projectId, jobId)
    if (retrying.has(retryKey)) {
      throw coordinatorError('WORKBENCH_JOB_RETRY_IN_PROGRESS', 409)
    }
    retrying.add(retryKey)
    try {
      const currentJob = await jobRepository.get(projectId, jobId)
      if (!currentJob) throw coordinatorError('WORKBENCH_JOB_NOT_FOUND', 404)
      const expectedGeneration = currentJob.attempts.at(-1).generation
      const releaseEditorCreation = currentJob.type === EDITOR_JOB_TYPE
        ? await acquireEditorJobCreationLock(projectId)
        : () => {}
      try {
      let retried
      try {
        retried = await jobRepository.retry({
          projectId,
          jobId,
          attemptId: createId('attempt'),
          expectedGeneration,
          retriedAt: nowIso(),
        })
      } catch (error) {
        if (
          currentJob.type === EDITOR_JOB_TYPE &&
          errorCode(error) === 'WORKBENCH_JOB_TYPE_ALREADY_RUNNING'
        ) {
          throw coordinatorError('WORKBENCH_EDITOR_AGENT_BUSY', 409)
        }
        throw error
      }
      try {
        if (hasMethods(referenceTemplateRepository, ['rollbackByOwner'])) {
          await /** @type {Record<string, Function>} */ (referenceTemplateRepository).rollbackByOwner({
            projectId,
            jobId,
          })
        }
        if (
          currentJob.type === 'jianying_draft_export' &&
          hasMethods(jianyingDraftCapability, ['cleanupDraft'])
        ) {
          await /** @type {Record<string, Function>} */ (jianyingDraftCapability).cleanupDraft({
            projectId,
            jobId: jianyingWriterAttemptId(currentJob),
          })
        }
      } catch {
        try {
          await jobRepository.failRetryPreparation({
            projectId,
            jobId,
            attemptId: retried.attempts.at(-1).attemptId,
            generation: retried.attempts.at(-1).generation,
            failedAt: nowIso(),
          })
        } catch {
          // If durable failure publication itself is unavailable, keep the
          // already-queued retry executable rather than leaving a ghost job.
          enqueue(retried)
        }
        throw coordinatorError('WORKBENCH_JOB_RETRY_PREPARATION_FAILED', 500)
      }
      enqueue(retried)
      return toPublicJobDto(retried)
      } finally {
        releaseEditorCreation()
      }
    } finally {
      retrying.delete(retryKey)
    }
  }
  const start = async () => {
    if (started) return
    started = true
    shutdownController = new AbortController()
    if (hasMethods(referenceTemplateRepository, ['listPending', 'publish', 'rollbackByOwner'])) {
      const repository = /** @type {Record<string, Function>} */ (referenceTemplateRepository)
      for (const pendingReference of await repository.listPending()) {
        const ownerJob = await jobRepository.get(
          pendingReference.projectId,
          pendingReference.jobId,
        )
        const ownerAttempt = ownerJob?.attempts?.at(-1)
        const ownerMatches =
          ownerAttempt?.attemptId === pendingReference.attemptId &&
          ownerAttempt?.generation === pendingReference.generation
        if (
          ownerJob?.status === 'succeeded' &&
          ownerMatches &&
          pendingReference.publication === 'prepared'
        ) {
          await repository.publish({
            projectId: pendingReference.projectId,
            referenceTemplateId: pendingReference.referenceTemplateId,
            jobId: pendingReference.jobId,
            attemptId: pendingReference.attemptId,
            generation: pendingReference.generation,
            inputFingerprint: pendingReference.inputFingerprint,
          })
        } else if (
          !ownerMatches ||
          !ownerJob ||
          !['queued', 'running'].includes(ownerJob.status)
        ) {
          await repository.rollbackByOwner({
            projectId: pendingReference.projectId,
            jobId: pendingReference.jobId,
            attemptId: pendingReference.attemptId,
            generation: pendingReference.generation,
          })
        }
      }
    }
    const recoverableJobs = await jobRepository.listRecoverable(nowIso())
    for (const job of recoverableJobs) enqueue(job)
    await recoverAutomaticCreativeContinuations({ retryPartialOutputs: true })
  }
  const stop = async () => {
    if (!started) return
    started = false
    pending.clear()
    for (const timer of materialResumeTimers.values()) clearTimeout(timer)
    materialResumeTimers.clear()
    materialResumeAttempts.clear()
    shutdownController.abort(coordinatorError('WORKBENCH_JOB_SHUTDOWN', 503))
    await Promise.allSettled(
      [...active.values()].map((worker) => worker.promise).filter(Boolean),
    )
  }

  /** @param {string} projectId */
  const getCurrentEditorTimeline = async (projectId) => {
    if (!identifier(projectId) || !richTimelineRepository) return null
    const pointer = await richTimelineRepository.getCurrent({ projectId })
    if (pointer) {
      const timeline = await richTimelineRepository.getRevision(pointer)
      return timeline ? toPublicTimelineSummary(timeline) : null
    }

    // A successful editor job and its immutable revision can be committed in
    // separate storage mutations. If the process restarts between those
    // writes, repair the missing current pointer from the exact job identity
    // instead of making the UI treat a completed edit as unsynchronized.
    const recovered = await getLatestValidEditorTimeline(projectId)
    const timeline = recovered?.timeline
    if (!timeline) return null
    try {
      await richTimelineRepository.setCurrent({
        projectId,
        timelineId: timeline.timelineId,
        revision: timeline.revision,
        expectedCurrent: null,
      })
    } catch (error) {
      if (
        !(error instanceof RichTimelineRepositoryError) ||
        error.code !== 'RICH_TIMELINE_CAS_CONFLICT'
      ) throw error
      // Another writer won the repair race. Read its pointer and expose that
      // authoritative version rather than returning a stale candidate.
      const current = await richTimelineRepository.getCurrent({ projectId })
      const currentTimeline = current
        ? await richTimelineRepository.getRevision(current)
        : null
      return currentTimeline ? toPublicTimelineSummary(currentTimeline) : null
    }
    return toPublicTimelineSummary(timeline)
  }

  /** @param {string} projectId */
  const getEditorStageState = async (projectId) => {
    const editorTimeline = await getLatestValidEditorTimeline(projectId)
    if (!editorTimeline) return null
    const { latest, succeeded, timeline } = editorTimeline
    if (!latest) {
      const pointer = await richTimelineRepository?.getCurrent({ projectId })
      const persistedTimeline = pointer
        ? await richTimelineRepository?.getRevision(pointer)
        : null
      if (
        persistedTimeline?.status === 'finalized' &&
        persistedTimeline.source?.kind === 'agent'
      ) {
        return {
          status: 'complete',
          jobId: null,
          summary: null,
          timeline: toPublicTimelineSummary(persistedTimeline),
        }
      }
    }
    const latestSucceededTimeline = succeeded && latest?.jobId === succeeded.jobId
    return {
      status: ['queued', 'running', 'cancelling'].includes(latest?.status)
        ? 'processing'
        : ['failed', 'cancelled', 'timed_out'].includes(latest?.status)
          ? 'failed'
          : latestSucceededTimeline
            ? 'complete'
            : 'not_started',
      jobId: ['failed', 'cancelled', 'timed_out', 'queued', 'running', 'cancelling']
        .includes(latest?.status)
          ? latest.jobId
          : succeeded?.jobId ?? latest?.jobId ?? null,
      summary: latestSucceededTimeline ? succeeded.result?.summary ?? null : null,
      timeline: latestSucceededTimeline ? toPublicTimelineSummary(timeline) : null,
    }
  }

  /** @param {string} projectId */
  const getLatestValidEditorTimeline = async (projectId) => {
    if (!identifier(projectId) || !richTimelineRepository) return null
    const jobs = await jobRepository.listByProject(projectId)
    const editorJobs = jobs
      .filter((/** @type {Record<string, any>} */ job) => job.type === EDITOR_JOB_TYPE)
      .sort((
        /** @type {Record<string, any>} */ left,
        /** @type {Record<string, any>} */ right,
      ) => Date.parse(right.updatedAt) - Date.parse(left.updatedAt))
    const latest = editorJobs[0] ?? null
    const succeededCandidates = editorJobs.filter(
      (/** @type {Record<string, any>} */ job) => job.status === 'succeeded',
    )
    for (const candidate of succeededCandidates) {
      if (
        !identifier(candidate.result?.timelineId) ||
        !Number.isInteger(candidate.result?.timelineRevision)
      ) continue
      const timeline = await richTimelineRepository.getRevision({
        projectId,
        timelineId: candidate.result?.timelineId,
        revision: candidate.result?.timelineRevision,
      })
      if (
        timeline?.status === 'finalized' &&
        timeline.source?.kind === 'agent' &&
        candidate.privateInput?.instructionFingerprint ===
          timeline.source.instructionFingerprint &&
        candidate.result?.timelineRevisionFingerprint ===
          timeline.revisionFingerprint
      ) {
        return { latest, succeeded: candidate, timeline }
      }
    }
    return { latest, succeeded: null, timeline: null }
  }

  /** @param {string} projectId @param {string | null | undefined} resourceId */
  const getPreviewStageState = async (projectId, resourceId) => {
    if (!identifier(projectId) || !richTimelineRepository) return { status: 'not_started' }
    const project = await projectRepository.get(projectId)
    const persistedPreview = project?.preview
    const pointer = await richTimelineRepository.getCurrent({ projectId })
    const currentTimeline = pointer
      ? await richTimelineRepository.getRevision(pointer)
      : null
    const hasRecordedBinding =
      identifier(persistedPreview?.timelineId) &&
      Number.isInteger(persistedPreview?.timelineRevision) &&
      identifier(persistedPreview?.timelineRevisionFingerprint) &&
      identifier(persistedPreview?.timelineContentFingerprint)
    const matchesCurrentTimeline = currentTimeline?.status === 'finalized' &&
      currentTimeline.source?.kind === 'agent' &&
      (!hasRecordedBinding || (
        currentTimeline.timelineId === persistedPreview.timelineId &&
        currentTimeline.revision === persistedPreview.timelineRevision &&
        currentTimeline.revisionFingerprint === persistedPreview.timelineRevisionFingerprint &&
        currentTimeline.contentFingerprint === persistedPreview.timelineContentFingerprint
      ))
    // Output media is persisted independently from task history. Once a job
    // retention policy removes old records, keep a verified current resource
    // playable instead of treating it as a new, unstarted preview.
    if (
      persistedPreview?.status === 'ready' &&
      identifier(resourceId) &&
      persistedPreview.resourceId === resourceId &&
      !project?.pendingOutputInvalidation &&
      matchesCurrentTimeline
    ) return { status: 'complete' }
    const editorTimeline = await getLatestValidEditorTimeline(projectId)
    if (!editorTimeline?.succeeded || !editorTimeline.timeline) {
      return { status: 'not_started' }
    }
    const timeline = editorTimeline.timeline
    const jobs = (await jobRepository.listByProject(projectId))
      .filter((/** @type {Record<string, any>} */ job) =>
        job.type === 'preview_generation' &&
        job.privateInput?.editorBound === true &&
        job.privateInput?.editorParentJobId === editorTimeline.succeeded.jobId &&
        job.privateInput?.timelineId === timeline.timelineId &&
        job.privateInput?.timelineRevision === timeline.revision &&
        job.privateInput?.timelineRevisionFingerprint === timeline.revisionFingerprint)
      .sort((
        /** @type {Record<string, any>} */ left,
        /** @type {Record<string, any>} */ right,
      ) => Date.parse(right.updatedAt) - Date.parse(left.updatedAt))
    if (
      identifier(resourceId) &&
      jobs.some((/** @type {Record<string, any>} */ job) =>
        job.status === 'succeeded' && job.result?.resourceId === resourceId)
    ) return { status: 'complete' }
    const latest = jobs[0]
    return {
      status: ['queued', 'running', 'cancelling'].includes(latest?.status)
        ? 'processing'
        : ['failed', 'cancelled', 'timed_out'].includes(latest?.status)
          ? 'failed'
          : 'not_started',
    }
  }

  /** @param {string} projectId @param {string | null | undefined} exportJobId */
  const getDeliveryStageState = async (projectId, exportJobId) => {
    if (!identifier(projectId) || !richTimelineRepository) {
      return { status: 'not_started', jobId: null }
    }
    const editorTimeline = await getLatestValidEditorTimeline(projectId)
    if (!editorTimeline?.succeeded || !editorTimeline.timeline) {
      return { status: 'not_started', jobId: null }
    }
    const timeline = editorTimeline.timeline
    const jobs = (await jobRepository.listByProject(projectId))
      .filter((/** @type {Record<string, any>} */ job) =>
        job.type === 'jianying_draft_export' &&
        job.privateInput?.editorBound === true &&
        job.privateInput?.editorParentJobId === editorTimeline.succeeded.jobId &&
        job.privateInput?.timelineId === timeline.timelineId &&
        job.privateInput?.timelineRevision === timeline.revision &&
        job.privateInput?.timelineRevisionFingerprint === timeline.revisionFingerprint)
      .sort((
        /** @type {Record<string, any>} */ left,
        /** @type {Record<string, any>} */ right,
      ) => Date.parse(right.updatedAt) - Date.parse(left.updatedAt))
    const completed = identifier(exportJobId)
      ? jobs.find((/** @type {Record<string, any>} */ job) =>
          job.jobId === exportJobId && job.status === 'succeeded')
      : null
    if (completed) return { status: 'complete', jobId: completed.jobId }
    const latest = jobs[0]
    return {
      status: latest?.status === 'succeeded'
        ? 'complete'
        : ['queued', 'running', 'cancelling'].includes(latest?.status)
        ? 'processing'
        : ['failed', 'cancelled', 'timed_out'].includes(latest?.status)
          ? 'failed'
          : 'not_started',
      jobId: latest?.jobId ?? null,
    }
  }

  /** @param {string} projectId @param {string} resourceId */
  const isCurrentEditorPreviewResource = async (projectId, resourceId) => {
    if (!identifier(resourceId)) return false
    return (await getPreviewStageState(projectId, resourceId)).status === 'complete'
  }

  return {
    createJob,
    createReferenceTemplateJob,
    createJianyingDraftJob,
    createEditorAgentJob,
    createEditorTimelinePreviewJob,
    createEditorTimelineExportJob,
    getCurrentEditorTimeline,
    getEditorStageState,
    getPreviewStageState,
    getDeliveryStageState,
    isCurrentEditorPreviewResource,
    getJob,
    listJobs,
    listJobsForProjects,
    dismissJobs,
    dismissFailedJobs,
    assertProjectIdle,
    deleteProjectData,
    invalidateProjectOutputs,
    cancelJob,
    retryJob,
    start,
    stop,
  }
}

