import { execFile } from 'node:child_process'
import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { promisify } from 'node:util'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { createJianyingBlendCatalog } from '../apps/gateway/src/jianying-blend-catalog.mjs'

const run = promisify(execFile)
const main = async () => {
  const moduleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (typeof moduleRoot !== 'string' || moduleRoot.length === 0) throw new Error('JY046_UPSTREAM_MISSING')
  const { stdout } = await run('python', ['-c', 'import pyJianYingDraft as d,json; x=list(d.MixModeType); print(json.dumps([{"display_name":x[i].value.name,"resource_id":x[i].value.resource_id} for i in (0,5)],ensure_ascii=False))'], { env: { ...process.env, PYTHONPATH: moduleRoot }, windowsHide: true })
  const raw = JSON.parse(stdout)
  const catalog = createJianyingBlendCatalog([{ role: 'initial', ...raw[0] }, { role: 'expected_post', ...raw[1] }])
  const root = loadLocalRuntimeConfig().dataRoot
  await mkdir(path.join(root, 'catalogs'), { recursive: true })
  await writeFile(path.join(root, 'catalogs', 'jy046-blend-catalog.json'), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(JSON.stringify({ ok: true, capability: 'blend.video.named', entries: 2 }) + '\n')
}
main().catch(error => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY046_CATALOG_FAILED' }) + '\n'); process.exitCode = 1 })
