import { createHash } from 'node:crypto'
import { createReadStream, createWriteStream, existsSync, realpathSync } from 'node:fs'
import {
  chmod,
  copyFile,
  mkdir,
  readFile,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { isAbsolute, join, relative, resolve } from 'node:path'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { randomUUID } from 'node:crypto'

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  /** @param {string} value */
  const canonical = (value) => existsSync(value) ? realpathSync.native(value) : resolve(value)
  const fragment = relative(canonical(parent), canonical(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}

export class ProjectTemplateAbPreviewError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'ProjectTemplateAbPreviewError'
    this.code = code
    this.status = status
  }
}

/**
 * Private baseline/template A/B media store for project template try-on.
 * @param {{
 *   dataRoot: string,
 *   previewProvider: { renderPreview: Function, getResource?: Function },
 *   now?: () => Date,
 *   createId?: () => string,
 * }} options
 */
export const createProjectTemplateAbPreviewStore = ({
  dataRoot,
  previewProvider,
  now = () => new Date(),
  createId = () => randomUUID().replace(/-/g, '').slice(0, 24),
}) => {
  if (!dataRoot || !isAbsolute(dataRoot)) {
    throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_ROOT_INVALID', 503)
  }
  if (!previewProvider || typeof previewProvider.renderPreview !== 'function') {
    throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_PROVIDER_INVALID', 503)
  }
  const root = resolve(dataRoot, 'project-template-ab')
  /** @type {Map<string, Promise<any>>} */
  const queues = new Map()

  /** @param {string} projectId */
  const projectDir = (projectId) => {
    if (!identifier(projectId)) throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_PROJECT_INVALID', 400)
    return resolve(root, projectId)
  }

  /** @param {string} projectId */
  const metaPath = (projectId) => join(projectDir(projectId), 'ab.json')

  /** @param {string} projectId */
  const readMeta = async (projectId) => {
    try {
      const raw = JSON.parse(await readFile(metaPath(projectId), 'utf8'))
      return record(raw) ? raw : null
    } catch (error) {
      if (record(error) && error.code === 'ENOENT') return null
      throw error
    }
  }

  /** @param {string} projectId @param {Record<string, any>} meta */
  const writeMeta = async (projectId, meta) => {
    const directory = projectDir(projectId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const temporary = join(directory, `ab.${process.pid}.${Date.now()}.tmp`)
    await writeFile(temporary, `${JSON.stringify(meta, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 })
    await rename(temporary, metaPath(projectId))
    await chmod(metaPath(projectId), 0o600).catch(() => {})
  }

  /** @param {string} filePath */
  const sha256File = async (filePath) => {
    const hash = createHash('sha256')
    await new Promise((resolveHash, rejectHash) => {
      const stream = createReadStream(filePath)
      stream.on('data', (chunk) => hash.update(chunk))
      stream.on('error', rejectHash)
      stream.on('end', () => resolveHash(undefined))
    })
    return hash.digest('hex')
  }

  /**
   * @param {string} projectId
   * @param {object} input
   */
  const enqueue = async (projectId, /** @type {Parameters<typeof runGenerate>[1]} */ input) => {
    const previous = queues.get(projectId) || Promise.resolve()
    const next = previous
      .catch(() => {})
      .then(() => runGenerate(projectId, input))
    queues.set(projectId, next)
    try {
      return await next
    } finally {
      if (queues.get(projectId) === next) queues.delete(projectId)
    }
  }

  /**
   * @param {string} projectId
   * @param {{
   *   brief: Record<string, any>,
   *   clips: Array<Record<string, any>>,
   *   voiceoverSegments?: Array<{ sentenceId: string, text: string }>,
   *   templateGuidance: Record<string, any>,
   *   templateFingerprint: string,
   *   templateRevision: number,
   *   libraryTemplateId: string,
   *   signal?: AbortSignal,
   * }} input
   */
  const runGenerate = async (projectId, input) => {
    if (!record(input?.brief) || !Array.isArray(input.clips) || input.clips.length < 1) {
      throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_INPUT_INVALID', 400)
    }
    if (!record(input.templateGuidance)) {
      throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_GUIDANCE_REQUIRED', 400)
    }
    const voiceoverSegments = Array.isArray(input.voiceoverSegments)
      ? input.voiceoverSegments.map((segment) => ({ ...segment }))
      : []
    const jobId = createId()
    const directory = projectDir(projectId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const startedAt = now().toISOString()
    /** @type {Record<string, any>} */
    let meta = {
      schemaVersion: 1,
      projectId,
      jobId,
      status: 'running',
      libraryTemplateId: input.libraryTemplateId,
      templateRevision: input.templateRevision,
      templateFingerprint: input.templateFingerprint,
      confirmed: false,
      baseline: { status: 'pending', fileName: null, sha256: null, byteSize: null },
      template: { status: 'pending', fileName: null, sha256: null, byteSize: null },
      errorCode: null,
      startedAt,
      updatedAt: startedAt,
    }
    await writeMeta(projectId, meta)

    /** @param {'baseline' | 'template'} side @param {Record<string, any> | null} guidance */
    const publishSide = async (side, guidance) => {
      const rendered = await previewProvider.renderPreview({
        projectId,
        jobId: `${jobId}-${side}`,
        brief: input.brief,
        clips: input.clips.map((clip) => ({ ...clip })),
        voiceoverSegments: voiceoverSegments.map((segment) => ({ ...segment })),
        templateGuidance: guidance,
        signal: input.signal,
      })
      let sourcePath = null
      let resource = null
      if (rendered?.absolutePath && existsSync(rendered.absolutePath)) {
        sourcePath = rendered.absolutePath
      } else if (rendered?.path && existsSync(rendered.path)) {
        sourcePath = rendered.path
      } else if (rendered?.resourceId && typeof previewProvider.getResource === 'function') {
        resource = await previewProvider.getResource({
          projectId,
          resourceId: rendered.resourceId,
        })
        sourcePath = resource?.absolutePath || resource?.path || null
      }
      const resourceStreamAvailable =
        Number.isSafeInteger(resource?.size) &&
        resource.size > 0 &&
        typeof resource.createStream === 'function'
      if ((!sourcePath || !existsSync(sourcePath)) && !resourceStreamAvailable) {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_RENDER_MISSING', 502)
      }
      const fileName = `${side}.mp4`
      const target = join(directory, fileName)
      const temporary = join(directory, `${side}.${process.pid}.tmp.mp4`)
      try {
        if (sourcePath && existsSync(sourcePath)) {
          await copyFile(sourcePath, temporary)
        } else {
          const stream = resource.createStream({ start: 0, end: resource.size - 1 })
          await pipeline(
            Readable.fromWeb(stream),
            createWriteStream(temporary, { flags: 'wx', mode: 0o600 }),
          )
        }
        await rename(temporary, target)
      } finally {
        await rm(temporary, { force: true }).catch(() => {})
      }
      await chmod(target, 0o600).catch(() => {})
      const info = await stat(target)
      const sha256 = await sha256File(target)
      return {
        status: 'ready',
        fileName,
        contentType: 'video/mp4',
        byteSize: info.size,
        sha256,
      }
    }

    try {
      meta.baseline = await publishSide('baseline', null)
      meta.template = await publishSide('template', input.templateGuidance)
      meta.status = 'ready'
      meta.updatedAt = now().toISOString()
      meta.contentFingerprint = createHash('sha256')
        .update(JSON.stringify({
          baseline: meta.baseline.sha256,
          template: meta.template.sha256,
          templateFingerprint: input.templateFingerprint,
          clipCount: input.clips.length,
          script: input.brief.script || '',
        }))
        .digest('hex')
      await writeMeta(projectId, meta)
      return toPublic(meta)
    } catch (error) {
      const candidate = error && typeof error === 'object'
        ? /** @type {{ code?: unknown, status?: unknown }} */ (error)
        : {}
      const providerCode = typeof candidate.code === 'string' &&
        /^[A-Z][A-Z0-9_]{2,80}$/u.test(candidate.code)
        ? candidate.code
        : 'TEMPLATE_AB_RENDER_FAILED'
      const providerStatus = Number.isInteger(candidate.status) &&
        /** @type {number} */ (candidate.status) >= 400 &&
        /** @type {number} */ (candidate.status) <= 599
        ? /** @type {number} */ (candidate.status)
        : 502
      meta.status = 'failed'
      meta.errorCode = error instanceof ProjectTemplateAbPreviewError
        ? error.code
        : providerCode
      meta.updatedAt = now().toISOString()
      await writeMeta(projectId, meta)
      throw error instanceof ProjectTemplateAbPreviewError
        ? error
        : new ProjectTemplateAbPreviewError(providerCode, providerStatus)
    }
  }

  /** @param {Record<string, any>} meta */
  const toPublic = (meta) => ({
    schemaVersion: 1,
    projectId: meta.projectId,
    jobId: meta.jobId,
    status: meta.status,
    libraryTemplateId: meta.libraryTemplateId,
    templateRevision: meta.templateRevision,
    templateFingerprint: meta.templateFingerprint,
    contentFingerprint: meta.contentFingerprint || null,
    confirmed: Boolean(meta.confirmed),
    baselinePlayable: meta.baseline?.status === 'ready',
    templatePlayable: meta.template?.status === 'ready',
    errorCode: meta.errorCode || null,
    startedAt: meta.startedAt,
    updatedAt: meta.updatedAt,
  })

  return {
    /**
     * @param {string} projectId
     * @param {Parameters<typeof runGenerate>[1]} input
     */
    async generate(projectId, input) {
      return enqueue(projectId, input)
    },
    /** @param {string} projectId */
    async get(projectId) {
      const meta = await readMeta(projectId)
      return meta ? toPublic(meta) : null
    },
    /**
     * @param {string} projectId
     * @param {{ expectedJobId: string, expectedContentFingerprint: string }} input
     */
    async confirm(projectId, input) {
      const meta = await readMeta(projectId)
      if (!meta || meta.status !== 'ready') {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_NOT_READY', 409)
      }
      if (
        meta.jobId !== input.expectedJobId ||
        meta.contentFingerprint !== input.expectedContentFingerprint
      ) {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_STALE', 409)
      }
      if (meta.baseline?.status !== 'ready' || meta.template?.status !== 'ready') {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_NOT_READY', 409)
      }
      meta.confirmed = true
      meta.confirmedAt = now().toISOString()
      meta.updatedAt = meta.confirmedAt
      await writeMeta(projectId, meta)
      return toPublic(meta)
    },
    /**
     * @param {string} projectId
     * @param {'baseline' | 'template'} side
     */
    async resolveResource(projectId, side) {
      if (side !== 'baseline' && side !== 'template') {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_SIDE_INVALID', 400)
      }
      const meta = await readMeta(projectId)
      if (!meta) throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_NOT_FOUND', 404)
      const entry = meta[side]
      if (!entry?.fileName || entry.status !== 'ready') {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_SIDE_UNAVAILABLE', 409)
      }
      const directory = projectDir(projectId)
      const filePath = join(directory, entry.fileName)
      if (!inside(directory, filePath) || !existsSync(filePath)) {
        throw new ProjectTemplateAbPreviewError('TEMPLATE_AB_FILE_MISSING', 409)
      }
      const info = await stat(filePath)
      return {
        size: info.size,
        contentType: entry.contentType || 'video/mp4',
        etag: `"${entry.sha256 || info.mtimeMs}"`,
        createStream: ({ start = 0, end = info.size - 1 } = {}) =>
          /** @type {ReadableStream} */ (
            /** @type {unknown} */ (Readable.toWeb(createReadStream(filePath, { start, end })))
          ),
      }
    },
    readMeta,
  }
}
