import { createHash, randomUUID } from 'node:crypto'
import { lstat, mkdir, mkdtemp, readdir, realpath, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  fingerprintCanonicalJY200Draft,
  createJY200WriterEnvironment,
  probeArtistEffectPayload,
  runBoundedJY200ProbeProcess,
  sanitizeJY200ProbeError,
  signArtistEffectStickerReceipt,
  validateJY200ProbeArtifactTree,
  validateJY200PythonExecutable,
  validateJY200ProbeStagingRoot,
} from '../apps/gateway/src/jianying-artist-effect-probe.mjs'
import { detectJianyingDesktop, inspectPyJianyingUpstream } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { createJianyingDesktopBinding, parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import { loadPackagingResourceEvidenceIntegrityKey } from '../apps/gateway/src/jianying-packaging-resource-evidence.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const tokenPattern = /^ovjsticker_v1_[a-f0-9]{24}$/u
const sha256 = (value) => createHash('sha256').update(value).digest('hex')

const sameRetainedObject = async (requested, actual, metadata) => {
  const samePath = process.platform === 'win32'
    ? path.resolve(requested).toLowerCase() === path.resolve(actual).toLowerCase()
    : path.resolve(requested) === path.resolve(actual)
  if (samePath) return true
  if (process.platform !== 'win32') return false
  const observed = await lstat(actual, { bigint: true })
  return metadata.dev === observed.dev && metadata.ino === observed.ino
}

/** @param {string} target */
export const retainJY200ProbeStaging = async (target) => {
  const resolved = path.resolve(target)
  const [metadata, actual] = await Promise.all([lstat(resolved, { bigint: true }), realpath(resolved)])
  if (!metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameRetainedObject(resolved, actual, metadata)) {
    throw new Error('JY200_STAGING_ROOT_UNSAFE')
  }
  return Object.freeze({ path: resolved, identity: `${metadata.dev}:${metadata.ino}` })
}
/** @param {{path: string, identity: string}} binding */
const assertRetainedDirectory = async (binding) => {
  const current = await retainJY200ProbeStaging(binding.path)
  if (current.identity !== binding.identity) throw new Error('JY200_STAGING_ROOT_REPLACED')
}
/** @param {{path: string, identity: string}} binding */
export const removeRetainedJY200ProbeStaging = async (binding) => {
  await assertRetainedDirectory(binding)
  const tombstone = path.join(path.dirname(binding.path), `.openvideo-delete-${randomUUID().replaceAll('-', '')}`)
  await rename(binding.path, tombstone)
  const tombstoneBinding = await retainJY200ProbeStaging(tombstone)
  if (tombstoneBinding.identity !== binding.identity) throw new Error('JY200_STAGING_ROOT_REPLACED')
  await rm(tombstone, { recursive: true })
}
const writerSource = [
  'import json, sys',
  'import pyJianYingDraft as draft',
  'value=json.load(sys.stdin)',
  'folder=draft.DraftFolder(value["root"])',
  'script=folder.create_draft(value["draft_name"],1080,1920,allow_replace=False)',
  'script.append_tracks([draft.TrackSpec(draft.TrackType.sticker,"probe_sticker")])',
  'script.add_segment(draft.StickerSegment(value["resource_id"],draft.trange("0s","3s")),"probe_sticker")',
  'script.save()',
].join('\n')

/** @param {string[]} [argv] */
export const runStickerWriterCandidateProbe = async (argv = process.argv.slice(2)) => {
  const packagingToken = argv[0]
  if (!tokenPattern.test(packagingToken ?? '') || argv.length !== 1) {
    throw new Error('JY200_PACKAGING_TOKEN_INVALID')
  }
  const runtime = await loadLauncherRuntimeConfig({ repositoryRoot: root })
  const dataRoot = runtime.dataRoot
  const pyModuleRoot = runtime.pyJianyingDraftRoot
  let stagingRoot = null
  let stagingBinding = null
  let liveDraftRoot = null
  let cleanupAllowed = false
  try {
    const [compatibilityManifest, upstreamManifest] = await Promise.all([
      readFileNoReparse(path.join(root, 'config', 'jianying-compatibility.json'), root).then(JSON.parse),
      readFileNoReparse(path.join(root, 'config', 'pyjianyingdraft-upstream.json'), root).then(JSON.parse),
    ])
    const desktop = await detectJianyingDesktop({ compatibilityManifest })
    liveDraftRoot = desktop.draftRoot
    const upstream = await inspectPyJianyingUpstream({ upstreamRoot: pyModuleRoot, manifest: upstreamManifest })
    const catalogRoot = path.join(dataRoot, 'catalogs')
    const catalog = parsePrivatePackagingResourceIndex(
      JSON.parse(await readFileNoReparse(path.join(catalogRoot, 'native018-private-draft-catalog.json'), catalogRoot, 32 * 1024 * 1024)),
      { profileId: desktop.profileId, appVersion: desktop.version },
    )
    const entry = catalog.entries.find((candidate) => candidate.packaging_token === packagingToken &&
      candidate.family === 'sticker' && candidate.writer_eligible === false && candidate.state === 'discoverable')
    if (!entry) throw new Error('JY200_STICKER_CANDIDATE_UNAVAILABLE')
    const payload = await probeArtistEffectPayload({ desktop, resourceId: entry.private_binding.resourceId })
    if (!payload) throw new Error('JY200_STICKER_PAYLOAD_UNAVAILABLE')
    const integrityKey = await loadPackagingResourceEvidenceIntegrityKey({
      evidenceRoot: path.join(dataRoot, 'evidence', 'jy132-packaging-resources'),
    })

    const stagingParent = path.join(dataRoot, 'JY-200', 'staging')
    await mkdir(stagingParent, { recursive: true, mode: 0o700 })
    await validateJY200ProbeStagingRoot({ runtimeRoot: dataRoot, stagingRoot: stagingParent, liveDraftRoot: desktop.draftRoot })
    stagingRoot = await mkdtemp(path.join(stagingParent, 'sticker-'))
    await validateJY200ProbeStagingRoot({ runtimeRoot: dataRoot, stagingRoot, liveDraftRoot: desktop.draftRoot })
    stagingBinding = await retainJY200ProbeStaging(stagingRoot)
    cleanupAllowed = true
    const draftId = 'probe'
    const pythonExecutable = await validateJY200PythonExecutable({
      executable: process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE,
    })
    await runBoundedJY200ProbeProcess({
      command: pythonExecutable,
      args: ['-c', writerSource],
      cwd: root,
      env: createJY200WriterEnvironment(process.env, pyModuleRoot),
      input: { root: stagingRoot, resource_id: entry.private_binding.resourceId, draft_name: draftId },
    })
    await validateJY200ProbeStagingRoot({ runtimeRoot: dataRoot, stagingRoot, liveDraftRoot: desktop.draftRoot })
    const draftRoot = path.join(stagingRoot, draftId)
    await validateJY200ProbeArtifactTree({ stagingRoot, artifactRoot: draftRoot })
    const draftBytes = await readFileNoReparseBuffer(path.join(draftRoot, 'draft_content.json'), draftRoot, 4 * 1024 * 1024)
    const draft = JSON.parse(draftBytes.toString('utf8'))
    const stickers = Array.isArray(draft?.materials?.stickers) ? draft.materials.stickers : []
    const tracks = Array.isArray(draft?.tracks) ? draft.tracks.filter((track) => track?.type === 'sticker') : []
    const segments = tracks.flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
    const initialRotation = segments[0]?.clip?.rotation
    const readbackOk = stickers.length === 1 && tracks.length === 1 && segments.length === 1 && Number.isFinite(initialRotation) &&
      stickers[0]?.resource_id === entry.private_binding.resourceId && segments[0]?.material_id === stickers[0]?.id
    if (!readbackOk) throw new Error('JY200_STICKER_READBACK_FAILED')
    const unsignedReceipt = {
      schema_version: 1,
      kind: 'jy200_sticker_probe_candidate',
      run_id: randomUUID(),
      status: 'probed',
      admission: 'deferred',
      writer_eligible: false,
      resource_mode: payload.mode,
      packaging_token: packagingToken,
      resource_id_fingerprint: payload.resourceIdFingerprint,
      payload_fingerprint: payload.payloadFingerprint,
      catalog_fingerprint: catalog.catalogFingerprint,
      desktop_binding_fingerprint: createJianyingDesktopBinding(desktop).binding_fingerprint,
      writer: { provider: 'pyjianyingdraft-direct-probe', commit: upstream.commit, license: upstream.license },
      readback: {
        ok: true,
        materials: 1,
        tracks: 1,
        segments: 1,
        draft_fingerprint: sha256(draftBytes),
        initial_rotation: initialRotation,
        initial_plaintext_fingerprint: fingerprintCanonicalJY200Draft(draft),
      },
      publish: { requested: false, completed: false, draft_id: null },
      lifecycle: { opened: false, edited: false, saved: false, closed: false, reopened: false },
      integrity_revision: 1,
    }
    const receipt = { ...unsignedReceipt, integrity_signature: signArtistEffectStickerReceipt(unsignedReceipt, integrityKey) }
    const evidenceRoot = path.join(dataRoot, 'evidence', 'jy200-sticker-probes')
    await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
    const output = path.join(evidenceRoot, `${receipt.run_id}.json`)
    const temporary = `${output}.${process.pid}.tmp`
    await writeFile(temporary, `${JSON.stringify(receipt, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await rename(temporary, output)
    return Object.freeze({
      status: receipt.status,
      admission: receipt.admission,
      writerEligible: false,
      resourceMode: receipt.resource_mode,
      readback: {
        ok: receipt.readback.ok,
        materials: receipt.readback.materials,
        tracks: receipt.readback.tracks,
        segments: receipt.readback.segments,
      },
      publish: { requested: receipt.publish.requested, completed: receipt.publish.completed },
      lifecycle: receipt.lifecycle,
      runId: receipt.run_id,
    })
  } finally {
    if (stagingRoot && stagingBinding && cleanupAllowed && liveDraftRoot) {
      try {
        await validateJY200ProbeStagingRoot({
          runtimeRoot: dataRoot,
          stagingRoot,
          liveDraftRoot,
        })
        const entries = await readdir(stagingRoot, { withFileTypes: true })
        for (const entry of entries) {
          await validateJY200ProbeArtifactTree({ stagingRoot, artifactRoot: path.join(stagingRoot, entry.name) })
        }
        await removeRetainedJY200ProbeStaging(stagingBinding)
      } catch { /* fail closed: never traverse an invalidated staging root */ }
    }
  }
}

const main = async () => {
  try {
    process.stdout.write(`${JSON.stringify(await runStickerWriterCandidateProbe())}\n`)
  } catch (error) {
    process.stdout.write(`${JSON.stringify({ status: 'deferred', reason: sanitizeJY200ProbeError(error), writerEligible: false })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
