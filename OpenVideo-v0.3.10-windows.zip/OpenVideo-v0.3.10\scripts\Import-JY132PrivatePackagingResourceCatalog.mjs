import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'

import {
  computePackagingCatalogFingerprint,
  computePackagingResourceToken,
  parsePrivatePackagingResourceIndex,
  serializePrivatePackagingResourceIndex,
} from '../apps/gateway/src/jianying-packaging-resource-index.mjs'

const privateSourcePattern = /^(?:pyjianyingdraft-metadata|user-draft-discovery|approved-runtime-bridge)$/u

const usage = () => {
  process.stderr.write('Usage: node scripts/Import-JY132PrivatePackagingResourceCatalog.mjs --input <private-json> --output <private-json> --profile-id <opaque> --app-version <version>\n')
}

const args = (argv) => {
  const result = {}
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index]
    if (!key.startsWith('--')) continue
    result[key.slice(2)] = argv[index + 1]
    index += 1
  }
  return result
}

const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
const identifierShapedValuePattern = /(?:^|[^a-z0-9])(?:\d{8,}|[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}|[a-f0-9]{32,64})(?=$|[^a-z0-9])/iu

const safeLabel = (value, fallback) => {
  const label = typeof value === 'string' ? value.trim().slice(0, 160) : ''
  return label && !identifierShapedValuePattern.test(label) ? label : fallback
}

/** Convert a private discovery payload into a governed private catalog. */
export const buildPrivatePackagingCatalog = (input, { profileId, appVersion } = {}) => {
  if (!isRecord(input) || input.schema_version !== 1 || !privateSourcePattern.test(String(input.source ?? ''))) {
    throw new Error('JY132_DISCOVERY_SOURCE_INVALID')
  }
  if (typeof profileId !== 'string' || typeof appVersion !== 'string' || !Array.isArray(input.entries)) {
    throw new Error('JY132_DISCOVERY_INPUT_INVALID')
  }
  const entries = input.entries.map((raw, index) => {
    if (!isRecord(raw) || typeof raw.family !== 'string' || typeof raw.private_identity !== 'string') {
      throw new Error('JY132_DISCOVERY_ENTRY_INVALID')
    }
    const privateBinding = isRecord(raw.private_binding)
      ? raw.private_binding
      : { kind: raw.family, private_identity: raw.private_identity }
    const token = computePackagingResourceToken({
      family: raw.family,
      profileId,
      appVersion,
      privateBinding,
    })
    return {
      packaging_token: token,
      family: raw.family,
      label: safeLabel(raw.label ?? raw.name, `${raw.family} ${index + 1}`),
      tags: Array.isArray(raw.tags) ? raw.tags.filter((tag) => typeof tag === 'string').slice(0, 16) : [],
      state: 'discoverable',
      writer_eligible: false,
      parameter_schema: isRecord(raw.parameter_schema) ? raw.parameter_schema : {},
      private_binding: privateBinding,
    }
  })
  return parsePrivatePackagingResourceIndex({
    schema_version: 1,
    profile_id: profileId,
    app_version: appVersion,
    source: input.source,
    catalog_fingerprint: computePackagingCatalogFingerprint({ profileId, appVersion, entries }),
    entries,
  }, { profileId, appVersion })
}

const run = async () => {
  const input = args(process.argv.slice(2))
  if (!input.input || !input.output || !input['profile-id'] || !input['app-version']) {
    usage()
    process.exitCode = 2
    return
  }
  const source = JSON.parse(await readFile(resolve(input.input), 'utf8'))
  const catalog = buildPrivatePackagingCatalog(source, {
    profileId: input['profile-id'],
    appVersion: input['app-version'],
  })
  const output = resolve(input.output)
  await mkdir(dirname(output), { recursive: true })
  const temporary = `${output}.tmp-${process.pid}`
  await writeFile(temporary, `${JSON.stringify(serializePrivatePackagingResourceIndex(catalog))}\n`, { encoding: 'utf8', flag: 'wx' })
  await rename(temporary, output)
  process.stdout.write(JSON.stringify({ ok: true, entries: catalog.entries.length, writerEligible: 0 }) + '\n')
}

if (import.meta.url === `file://${process.argv[1]?.replaceAll('\\', '/')}`) await run()
