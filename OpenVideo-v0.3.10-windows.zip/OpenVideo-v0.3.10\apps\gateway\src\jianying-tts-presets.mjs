import { randomUUID, createHash } from 'node:crypto'
import { copyFile, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve } from 'node:path'

const schemaVersion = 1
const maxPresets = 40
const idPattern = /^jy_[a-f0-9]{24}$/u
const speakerPattern = /^[A-Za-z][A-Za-z0-9_]{2,79}$/u
const labelMax = 80

/**
 * @typedef {{id: string, label: string, speakerId: string, createdAt: string, updatedAt: string}} JianyingTtsPreset
 * @typedef {{schema_version: number, presets: JianyingTtsPreset[]}} JianyingTtsDocument
 */

/** Small UX suggestions only — not a full Jianying catalog dump. */
export const JIANYING_TTS_SUGGESTIONS = Object.freeze([
  { label: '小孩', speakerId: 'zh_female_xiaopengyou' },
  { label: '活力男声', speakerId: 'zh_male_huoli' },
  { label: '温柔姐姐', speakerId: 'zh_female_inspirational' },
  { label: '熊二', speakerId: 'zh_male_xionger_stream_gpu' },
  { label: '清亮男声', speakerId: 'zh_male_iclvop_xiaolinkepu' },
  { label: '沉稳解说', speakerId: 'BV701_streaming' },
  { label: '甜美女声', speakerId: 'ICL_zh_female_basidigua2' },
  { label: '磁性男声', speakerId: 'zh_male_iclvop_zhangjinxiangnanzhu' },
])

export class JianyingTtsPresetsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'JianyingTtsPresetsError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}
/** @param {unknown} error */
const errorCode = (error) =>
  error && typeof error === 'object' && 'code' in error ? String(error.code) : null

const newPresetId = () => `jy_${createHash('sha256').update(randomUUID()).digest('hex').slice(0, 24)}`

/** @param {unknown} value */
const normalizeLabel = (value) => {
  if (typeof value !== 'string') return null
  const label = value.trim()
  return label.length > 0 && label.length <= labelMax ? label : null
}

/** @param {unknown} value */
const normalizeSpeakerId = (value) =>
  typeof value === 'string' && speakerPattern.test(value.trim()) ? value.trim() : null

/** @param {unknown} value @returns {value is JianyingTtsPreset} */
const validPreset = (value) =>
  isRecord(value) &&
  typeof value.id === 'string' &&
  idPattern.test(value.id) &&
  typeof value.label === 'string' &&
  value.label.length > 0 &&
  value.label.length <= labelMax &&
  typeof value.speakerId === 'string' &&
  speakerPattern.test(value.speakerId) &&
  typeof value.createdAt === 'string' &&
  typeof value.updatedAt === 'string'

/** @param {unknown} value @returns {value is JianyingTtsDocument} */
const validDocument = (value) => {
  if (!isRecord(value) || value.schema_version !== schemaVersion) return false
  if (!Array.isArray(value.presets) || value.presets.length > maxPresets) return false
  return value.presets.every(validPreset)
}

/** @returns {JianyingTtsDocument} */
const emptyDocument = () => ({ schema_version: schemaVersion, presets: [] })

/** @param {string} path @param {Record<string, unknown>} document */
const writeDocument = async (path, document) => {
  const temporaryPath = `${path}.${randomUUID()}.tmp`
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  await writeFile(temporaryPath, `${JSON.stringify(document, null, 2)}\n`, {
    encoding: 'utf8',
    flag: 'wx',
    mode: 0o600,
  })
  try {
    await copyFile(path, `${path}.bak`).catch((error) => {
      if (errorCode(error) !== 'ENOENT') throw error
    })
    await rename(temporaryPath, path)
    await copyFile(path, `${path}.bak`).catch(() => {})
  } finally {
    await rm(temporaryPath, { force: true })
  }
}

/** @param {string} path @returns {Promise<JianyingTtsDocument>} */
const readDocument = async (path) => {
  try {
    const parsed = JSON.parse(await readFile(path, 'utf8'))
    if (!validDocument(parsed)) throw new JianyingTtsPresetsError('JIANYING_TTS_PRESETS_STORAGE_INVALID', 500)
    return parsed
  } catch (primaryError) {
    if (primaryError instanceof JianyingTtsPresetsError) {
      try {
        const backup = JSON.parse(await readFile(`${path}.bak`, 'utf8'))
        if (!validDocument(backup)) throw primaryError
        await writeDocument(path, backup)
        return backup
      } catch {
        throw primaryError
      }
    }
    if (errorCode(primaryError) === 'ENOENT') {
      try {
        const backup = JSON.parse(await readFile(`${path}.bak`, 'utf8'))
        if (validDocument(backup)) {
          await writeDocument(path, backup)
          return backup
        }
      } catch {
        /* fallthrough */
      }
      return emptyDocument()
    }
    throw new JianyingTtsPresetsError('JIANYING_TTS_PRESETS_STORAGE_INVALID', 500)
  }
}

/** @param {JianyingTtsPreset} preset */
const publicPreset = (preset) => ({
  id: preset.id,
  label: preset.label,
  speakerId: preset.speakerId,
  createdAt: preset.createdAt,
  updatedAt: preset.updatedAt,
})

/**
 * @param {{
 *   settingsPath: string,
 *   privateConfigRoot: string,
 * }} input
 */
export const createJianyingTtsPresetsService = ({ settingsPath, privateConfigRoot }) => {
  if (!isAbsolute(settingsPath) || !isAbsolute(privateConfigRoot)) {
    throw new JianyingTtsPresetsError('JIANYING_TTS_PRESETS_STORAGE_INVALID', 500)
  }
  const resolvedRoot = resolve(privateConfigRoot)
  const resolvedPath = resolve(settingsPath)
  if (!inside(resolvedRoot, resolvedPath) || resolvedRoot === resolvedPath) {
    throw new JianyingTtsPresetsError('JIANYING_TTS_PRESETS_STORAGE_INVALID', 500)
  }
  let serialization = Promise.resolve()
  /** @template T @param {() => Promise<T>} operation */
  const runSerialized = (operation) => {
    const result = serialization.then(operation, operation)
    serialization = result.then(() => {}, () => {})
    return result
  }

  return {
    async list() {
      return runSerialized(async () => {
        const document = await readDocument(resolvedPath)
        return {
          schema_version: schemaVersion,
          presets: document.presets.map(publicPreset),
          suggestions: JIANYING_TTS_SUGGESTIONS.map((item) => ({ ...item })),
        }
      })
    },
    /** @param {string} id */
    async get(id) {
      return runSerialized(async () => {
        if (typeof id !== 'string' || !idPattern.test(id)) {
          throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_NOT_FOUND', 404)
        }
        const document = await readDocument(resolvedPath)
        const preset = document.presets.find((entry) => entry.id === id)
        if (!preset) throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_NOT_FOUND', 404)
        return publicPreset(preset)
      })
    },
    /** @param {unknown} input */
    async add(input) {
      return runSerialized(async () => {
        if (!isRecord(input)) throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_INVALID')
        const label = normalizeLabel(input.label)
        const speakerId = normalizeSpeakerId(input.speakerId)
        if (!label || !speakerId) throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_INVALID')
        const document = await readDocument(resolvedPath)
        if (document.presets.length >= maxPresets) {
          throw new JianyingTtsPresetsError('JIANYING_TTS_PRESETS_LIMIT', 409)
        }
        if (document.presets.some((entry) => entry.speakerId === speakerId && entry.label === label)) {
          throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_DUPLICATE', 409)
        }
        const now = new Date().toISOString()
        const preset = {
          id: newPresetId(),
          label,
          speakerId,
          createdAt: now,
          updatedAt: now,
        }
        document.presets.push(preset)
        await writeDocument(resolvedPath, document)
        return publicPreset(preset)
      })
    },
    /** @param {string} id */
    async remove(id) {
      return runSerialized(async () => {
        if (typeof id !== 'string' || !idPattern.test(id)) {
          throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_NOT_FOUND', 404)
        }
        const document = await readDocument(resolvedPath)
        const next = document.presets.filter((entry) => entry.id !== id)
        if (next.length === document.presets.length) {
          throw new JianyingTtsPresetsError('JIANYING_TTS_PRESET_NOT_FOUND', 404)
        }
        document.presets = next
        await writeDocument(resolvedPath, document)
        return { removed: true, id }
      })
    },
    async listVoices() {
      const { presets } = await this.list()
      return presets.map((preset) => ({
        id: preset.id,
        label: preset.label,
        gender: 'custom',
        locale: 'zh-CN',
        source: 'jianying-preset',
        kind: 'preset',
        // Keep exact public WorkbenchVoice keys so /api/workbench/voices
        // never fails closed when presets exist.
        referenceLabel: null,
        consentConfirmedAt: null,
        ready: true,
      }))
    },
  }
}

/** @param {unknown} value */
export const isJianyingPresetVoiceId = (value) =>
  typeof value === 'string' && idPattern.test(value)

/** @param {unknown} body @param {number} [status] */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  },
})

/**
 * @param {{ service: ReturnType<typeof createJianyingTtsPresetsService> }} input
 */
export const createJianyingTtsPresetsHandler = ({ service }) => async (/** @type {Request} */ request) => {
  const url = new URL(request.url)
  const pathname = url.pathname
  try {
    if (pathname === '/api/settings/jianying-tts-presets' && request.method === 'GET') {
      return jsonResponse(await service.list())
    }
    if (pathname === '/api/settings/jianying-tts-presets' && request.method === 'POST') {
      if (request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
        return jsonResponse({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
      }
      return jsonResponse(await service.add(await request.json()), 201)
    }
    const match = pathname.match(/^\/api\/settings\/jianying-tts-presets\/(jy_[a-f0-9]{24})$/u)
    if (match && request.method === 'DELETE') {
      return jsonResponse(await service.remove(match[1]))
    }
    return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  } catch (error) {
    const status = error instanceof JianyingTtsPresetsError ? error.status : 502
    const code = error instanceof JianyingTtsPresetsError
      ? error.code
      : 'JIANYING_TTS_PRESETS_OPERATION_FAILED'
    return jsonResponse({ error: { code, message: 'Jianying TTS presets operation failed safely.' } }, status)
  }
}
