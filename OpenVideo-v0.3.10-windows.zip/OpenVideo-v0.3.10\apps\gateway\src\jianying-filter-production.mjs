import { join } from 'node:path'

import { loadJianyingFilterCatalogForWriter } from './jianying-filter-catalog-intake.mjs'
import { createJianyingFilterResolver } from './jianying-filter-resolver.mjs'
import { readFileNoReparse } from './jianying-native-safe-file.mjs'

const capabilities = Object.freeze([
  Object.freeze({
    capabilityId: 'filter.video.named',
    catalogName: 'jy041-filter-catalog.json',
    evidenceName: 'jy041-filter',
  }),
  Object.freeze({
    capabilityId: 'filter.video.track_named',
    catalogName: 'jy042-filter-track-catalog.json',
    evidenceName: 'jy042-filter-track',
  }),
])
const resourceIdPattern = /^[A-Za-z0-9_-]{4,80}$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const semverPattern = /^\d+\.\d+\.\d+(?:\.\d+)?$/u
const tokenPatterns = Object.freeze({
  'filter.video.named': /^ovjflt_v1_segment_[A-Za-z0-9_-]{32,160}$/u,
  'filter.video.track_named': /^ovjflt_v1_track_[A-Za-z0-9_-]{32,160}$/u,
})

/** @typedef {{loadCatalog?: (input: Record<string, string>) => Promise<any>, readEvidence?: (filePath: string, rootPath: string) => Promise<string>}} FilterProductionDeps */

export class JianyingFilterProductionError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingFilterProductionError'
    this.code = code
  }
}

/** @param {string} code @returns {never} */
const fail = (code) => { throw new JianyingFilterProductionError(code) }
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Load only the private writer-side filter bindings that satisfy catalog,
 * profile, and same-draft manual evidence gates. Missing files return null so
 * the caller can leave the capability fail closed during normal startup.
 * @param {{dataRoot: string, desktop: {profileId: string, version: string}, upstreamRoot: string}} input
 * @param {FilterProductionDeps} [testDeps]
 */
const loadJianyingFilterProductionInternal = async ({ dataRoot, desktop, upstreamRoot }, testDeps = {}) => {
  if (!isRecord(desktop) || desktop.profileId !== 'jianying-11-1-provisional' || typeof desktop.version !== 'string' || !semverPattern.test(desktop.version)) return null
  /** @type {Map<string, {catalogVersion: string, catalogFingerprint: string, resourceId: string, filterToken: string, evidence: {supportedVersion: string, catalogFingerprint: string, draftFingerprint: string, opened: true, edited: true, saved: true}}>} */
  const entries = new Map()
  const loadCatalog = testDeps.loadCatalog ?? loadJianyingFilterCatalogForWriter
  const readEvidence = testDeps.readEvidence ?? ((/** @type {string} */ filePath, /** @type {string} */ rootPath) => readFileNoReparse(filePath, rootPath))
  for (const definition of capabilities) {
    /** @type {any} */
    let catalog
    let evidence
    try {
      const catalogPath = join(dataRoot, 'catalogs', definition.catalogName)
      catalog = await loadCatalog({
        runtimeRoot: dataRoot,
        catalogPath,
        desktopVersion: desktop.version,
        upstreamRoot,
      })
      evidence = JSON.parse(await readEvidence(join(dataRoot, 'evidence', definition.evidenceName, 'verified.json'), dataRoot))
    } catch {
      continue
    }
    const candidate = catalog.privateEntries.find((/** @type {{capabilityId: string}} */ entry) => entry.capabilityId === definition.capabilityId)
    const token = candidate?.filterToken
    const tokenPattern = tokenPatterns[definition.capabilityId]
    if (
      !candidate || candidate.filterToken !== token ||
      typeof candidate.resourceId !== 'string' || !resourceIdPattern.test(candidate.resourceId) ||
      typeof catalog.catalogVersion !== 'string' || typeof catalog.catalogFingerprint !== 'string' ||
      !fingerprintPattern.test(catalog.catalogFingerprint) ||
      !isRecord(evidence) || evidence.schema_version !== 1 || evidence.capabilityId !== definition.capabilityId ||
      evidence.profileId !== desktop.profileId || evidence.desktopVersion !== desktop.version ||
      evidence.catalogFingerprint !== catalog.catalogFingerprint || evidence.filterToken !== token ||
      typeof evidence.draftFingerprint !== 'string' || !fingerprintPattern.test(evidence.draftFingerprint) ||
      evidence.opened !== true || evidence.edited !== true || evidence.saved !== true || evidence.reopened !== true ||
      !tokenPattern || !tokenPattern.test(candidate.filterToken)
    ) continue
    entries.set(definition.capabilityId, {
      catalogVersion: catalog.catalogVersion,
      catalogFingerprint: catalog.catalogFingerprint,
      resourceId: candidate.resourceId,
      filterToken: candidate.filterToken,
      evidence: Object.freeze({
        supportedVersion: desktop.version,
        catalogFingerprint: catalog.catalogFingerprint,
        draftFingerprint: evidence.draftFingerprint,
        opened: true,
        edited: true,
        saved: true,
      }),
    })
  }
  if (entries.size === 0) return null
  const filterResolver = createJianyingFilterResolver({
    resolveFilterToken: ({ filterToken, capabilityId }) => {
      const binding = entries.get(capabilityId)
      if (!binding || binding.filterToken !== filterToken) return null
      return {
        resourceId: binding.resourceId,
        catalogFingerprint: binding.catalogFingerprint,
        catalogVersion: binding.catalogVersion,
        editableEvidence: binding.evidence,
      }
    },
    getTrustedEvidenceBinding: (capabilityId) => {
      const binding = typeof capabilityId === 'string' ? entries.get(capabilityId) : undefined
      return binding
        ? {
            supportedVersion: binding.evidence.supportedVersion,
            catalogFingerprint: binding.catalogFingerprint,
            draftFingerprint: binding.evidence.draftFingerprint,
          }
        : null
    },
  })
  return Object.freeze({
    capabilities: Object.freeze([...entries.keys()]),
    filterResolver,
  })
}

/** @param {{dataRoot: string, desktop: {profileId: string, version: string}, upstreamRoot: string}} input */
export const loadJianyingFilterProduction = (input) => loadJianyingFilterProductionInternal(input)

/** Test-only seam; runtime callers must use loadJianyingFilterProduction. */
/** @param {{dataRoot: string, desktop: {profileId: string, version: string}, upstreamRoot: string}} input @param {FilterProductionDeps} deps */
export const __testLoadJianyingFilterProduction = (input, deps) => loadJianyingFilterProductionInternal(input, deps)
