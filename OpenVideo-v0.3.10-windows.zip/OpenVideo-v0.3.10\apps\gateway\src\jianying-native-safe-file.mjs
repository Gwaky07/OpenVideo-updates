import { spawn } from 'node:child_process'
import { constants } from 'node:fs'
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { lstat, open, realpath } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'

const scriptPath = join(dirname(fileURLToPath(import.meta.url)), '../../../scripts/Read-OpenVideoNoReparseFile.ps1')
const batchScriptPath = join(dirname(fileURLToPath(import.meta.url)), '../../../scripts/Read-OpenVideoNoReparseFiles.ps1')
export const MAX_NATIVE_FILE_BYTES = 256 * 1024 * 1024
const DEFAULT_NATIVE_FILE_BYTES = 4 * 1024 * 1024
const NATIVE_READ_CHUNK_BYTES = 64 * 1024
const MAX_NATIVE_STDERR_BYTES = 64 * 1024
const MAX_NATIVE_SINGLE_STDOUT_BYTES = 384 * 1024 * 1024
const NATIVE_SINGLE_READ_TIMEOUT_MS = 90_000
const nativeErrorPattern = /\b(?:JY018|JY135)_NATIVE_[A-Z_]+\b/u

/** @param {unknown} value @returns {string | undefined} */
const extractNativeErrorCode = (value) => String(value).match(nativeErrorPattern)?.[0]

/** @param {string} path @param {string} rootPath @param {number} [maxBytes] @returns {Promise<Buffer>} */
const readPosixNoReparseBuffer = async (path, rootPath, maxBytes = DEFAULT_NATIVE_FILE_BYTES) => {
  if (typeof path !== 'string' || typeof rootPath !== 'string' || !isAbsolute(path) || !isAbsolute(rootPath)) {
    throw new Error('JY018_NATIVE_READ_FAILED')
  }
  if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0 || maxBytes > MAX_NATIVE_FILE_BYTES) {
    throw new Error('JY018_NATIVE_FILE_TOO_LARGE')
  }
  const lexicalRoot = resolve(rootPath)
  const lexicalPath = resolve(path)
  const [canonicalRoot, canonicalPath, stat] = await Promise.all([realpath(lexicalRoot), realpath(lexicalPath), lstat(lexicalPath)])
  const contained = relative(canonicalRoot, canonicalPath)
  if (canonicalRoot !== lexicalRoot || canonicalPath !== lexicalPath || !contained || contained === '..' || contained.startsWith(`..${sep}`) || isAbsolute(contained) || !stat.isFile() || stat.isSymbolicLink()) {
    throw new Error('JY018_NATIVE_REPARSE_REJECTED')
  }
  if (stat.size > maxBytes) throw new Error('JY018_NATIVE_FILE_TOO_LARGE')
  const handle = await open(lexicalPath, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0))
  try {
    const opened = await handle.stat()
    if (!opened.isFile() || opened.size > maxBytes) throw new Error('JY018_NATIVE_FILE_TOO_LARGE')
    const chunks = []
    const buffer = Buffer.allocUnsafe(Math.min(NATIVE_READ_CHUNK_BYTES, maxBytes))
    let total = 0
    while (true) {
      const remaining = maxBytes - total
      if (remaining === 0) {
        const probe = Buffer.allocUnsafe(1)
        const result = await handle.read(probe, 0, 1, null)
        if (result.bytesRead > 0) throw new Error('JY018_NATIVE_FILE_TOO_LARGE')
        break
      }
      const result = await handle.read(buffer, 0, Math.min(buffer.length, remaining), null)
      if (result.bytesRead <= 0) break
      chunks.push(Buffer.from(buffer.subarray(0, result.bytesRead)))
      total += result.bytesRead
    }
    const closed = await handle.stat()
    if (closed.size > maxBytes) throw new Error('JY018_NATIVE_FILE_TOO_LARGE')
    return Buffer.concat(chunks, total)
  } finally { await handle.close() }
}

/**
 * Read a private file through a handle opened with FILE_FLAG_OPEN_REPARSE_POINT.
 * The helper deliberately returns bytes only; callers must keep the source path private.
 * @param {string} path
 * @param {string} rootPath
 * @returns {Promise<Buffer>}
 */
export const readFileNoReparseBuffer = (path, rootPath, maxBytes = DEFAULT_NATIVE_FILE_BYTES) => new Promise((resolve, reject) => {
  if (process.platform !== 'win32') {
    readPosixNoReparseBuffer(path, rootPath, maxBytes).then(resolve, reject)
    return
  }
  if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0 || maxBytes > MAX_NATIVE_FILE_BYTES) {
    reject(new Error('JY018_NATIVE_FILE_TOO_LARGE'))
    return
  }
  const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, '-LiteralPath', path, '-RootPath', rootPath, '-MaxBytes', String(maxBytes)], { windowsHide: true })
  let stdout = ''; let stderr = ''
  let stdoutBytes = 0
  let settled = false
  /** @type {NodeJS.Timeout|undefined} */
  let timer
  /** @param {Error} error */
  const fail = (error) => {
    if (settled) return
    settled = true
    if (timer) clearTimeout(timer)
    try { child.kill() } catch { /* best effort */ }
    reject(error)
  }
  child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8')
  child.stdout.on('data', (chunk) => {
    const text = String(chunk)
    stdoutBytes += Buffer.byteLength(text, 'utf8')
    const expectedBase64Bytes = Math.ceil(maxBytes / 3) * 4 + 4096
    if (stdoutBytes > Math.min(MAX_NATIVE_SINGLE_STDOUT_BYTES, expectedBase64Bytes)) {
      fail(new Error('JY018_NATIVE_READ_FAILED'))
      return
    }
    stdout += text
  })
  child.stderr.on('data', (chunk) => {
    stderr += chunk
    if (Buffer.byteLength(stderr, 'utf8') > MAX_NATIVE_STDERR_BYTES) {
      fail(new Error('JY018_NATIVE_READ_FAILED'))
    }
  })
  child.once('error', () => fail(new Error('JY018_NATIVE_HELPER_UNAVAILABLE')))
  child.once('close', (code) => {
    if (settled) return
    if (code !== 0) {
      const helperCode = extractNativeErrorCode(stderr)
      fail(new Error(helperCode ?? 'JY018_NATIVE_READ_FAILED'))
      return
    }
    try {
      settled = true
      if (timer) clearTimeout(timer)
      resolve(Buffer.from(stdout.trim(), 'base64'))
    } catch { fail(new Error('JY018_NATIVE_READ_FAILED')) }
  })
  timer = setTimeout(() => fail(new Error('JY018_NATIVE_READ_FAILED')), NATIVE_SINGLE_READ_TIMEOUT_MS)
})

/**
 * Read a private file as UTF-8 with the same bounded native-reader contract as
 * readFileNoReparseBuffer. Callers with larger governed artifacts must pass an
 * explicit cap; the 4 MiB default remains the safe general-purpose limit.
 * @param {string} path
 * @param {string} rootPath
 * @param {number} [maxBytes]
 * @returns {Promise<string>}
 */
export const readFileNoReparse = async (path, rootPath, maxBytes = DEFAULT_NATIVE_FILE_BYTES) =>
  (await readFileNoReparseBuffer(path, rootPath, maxBytes)).toString('utf8')

/**
 * Read a bounded set of private files through one native helper process. Input
 * paths travel only over stdin; stdout contains index + base64 content and no
 * path. The helper rechecks final-handle containment and byte limits per item.
 * @param {{path: string, rootPath: string}[]} items
 * @param {{spawnImpl?: typeof spawn, timeoutMs?: number, maxStdoutBytes?: number, maxFileBytes?: number, maxTotalBytes?: number, asBuffer?: boolean}} [options]
 * @returns {Promise<(string|Buffer)[]>}
 */
export const readFilesNoReparse = (items, {
  spawnImpl = spawn,
  timeoutMs = 90_000,
  maxStdoutBytes = 96 * 1024 * 1024,
  maxFileBytes = DEFAULT_NATIVE_FILE_BYTES,
  maxTotalBytes = 64 * 1024 * 1024,
  asBuffer = false,
} = {}) => new Promise((resolve, reject) => {
  if (!Array.isArray(items) || items.length > 4096 || items.some((item) => !item || typeof item.path !== 'string' || typeof item.rootPath !== 'string')) {
    reject(new Error('JY135_NATIVE_READ_FAILED')); return
  }
  if (!Number.isSafeInteger(maxFileBytes) || maxFileBytes <= 0 || maxFileBytes > MAX_NATIVE_FILE_BYTES ||
      !Number.isSafeInteger(maxTotalBytes) || maxTotalBytes <= 0 || maxTotalBytes > MAX_NATIVE_FILE_BYTES * 4096) {
    reject(new Error('JY135_NATIVE_READ_FAILED')); return
  }
  if (items.length === 0) { resolve([]); return }
  if (process.platform !== 'win32') {
    ;(async () => {
      /** @type {(string|Buffer)[]} */
      const values = []
      let totalBytes = 0
      for (const item of items) {
        const bytes = await readPosixNoReparseBuffer(item.path, item.rootPath, maxFileBytes)
        totalBytes += bytes.byteLength
        if (totalBytes > maxTotalBytes) throw new Error('JY018_NATIVE_TOTAL_TOO_LARGE')
        values.push(asBuffer ? bytes : bytes.toString('utf8'))
      }
      return values
    })().then(resolve, reject)
    return
  }
  const child = spawnImpl('powershell.exe', [
    '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', batchScriptPath,
    '-MaxFiles', '4096', '-MaxFileBytes', String(maxFileBytes), '-MaxTotalBytes', String(maxTotalBytes),
  ], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] })
  /** @type {((string|Buffer)|undefined)[]} */
  const values = Array(items.length)
  const seen = Array(items.length).fill(false)
  let stdout = ''
  let stdoutBytes = 0
  let settled = false
  /** @type {NodeJS.Timeout|undefined} */
  let timer
  const fail = (code = 'JY135_NATIVE_READ_FAILED') => {
    if (settled) return
    settled = true
    if (timer) clearTimeout(timer)
    try { child.kill() } catch { /* best effort */ }
    reject(new Error(code))
  }
  const acceptLine = (/** @type {string} */ line) => {
    let entry
    try { entry = JSON.parse(line) } catch { fail(); return false }
    if (entry && typeof entry === 'object' && !Array.isArray(entry) &&
      Object.keys(entry).sort().join('|') === 'error|index' && Number.isSafeInteger(entry.index) &&
      typeof entry.error === 'string' && nativeErrorPattern.test(entry.error)) {
      fail(entry.error)
      return false
    }
    if (!entry || typeof entry !== 'object' || Array.isArray(entry) ||
      Object.keys(entry).sort().join('|') !== 'content|index' ||
      !Number.isSafeInteger(entry.index) || entry.index < 0 || entry.index >= items.length || seen[entry.index] ||
      typeof entry.content !== 'string' || entry.content.length % 4 !== 0 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u.test(entry.content)) {
      fail(); return false
    }
    seen[entry.index] = true
    const bytes = Buffer.from(entry.content, 'base64')
    values[entry.index] = asBuffer ? bytes : bytes.toString('utf8')
    return true
  }
  child.stdout.setEncoding('utf8')
  child.stdout.on('data', (chunk) => {
    stdoutBytes += Buffer.byteLength(chunk, 'utf8')
    if (stdoutBytes > maxStdoutBytes) { fail(); return }
    stdout += chunk
    let newline
    while ((newline = stdout.indexOf('\n')) >= 0) {
      const line = stdout.slice(0, newline).trim()
      stdout = stdout.slice(newline + 1)
      if (!line) continue
      if (!acceptLine(line)) return
    }
  })
  let stderr = ''
  let stderrBytes = 0
  child.stderr.setEncoding('utf8')
  child.stderr.on('data', (chunk) => {
    const text = String(chunk)
    stderrBytes += Buffer.byteLength(text, 'utf8')
    if (stderrBytes > MAX_NATIVE_STDERR_BYTES) { fail(); return }
    stderr += text
  })
  child.once('error', () => fail())
  child.once('close', (code) => {
    if (settled) return
    const tail = stdout.trim()
    if (tail && !acceptLine(tail)) return
    if (code !== 0) { fail(extractNativeErrorCode(stderr)); return }
    if (seen.some((value) => value !== true) || values.some((value) => typeof value !== 'string' && !Buffer.isBuffer(value))) { fail(); return }
    settled = true
    if (timer) clearTimeout(timer)
    resolve(/** @type {(string|Buffer)[]} */ (values))
  })
  timer = setTimeout(fail, timeoutMs)
  child.stdin.end(Buffer.from(JSON.stringify({
    schema_version: 1,
    items: items.map((item) => ({ path: item.path, root: item.rootPath })),
  }), 'utf8').toString('base64'))
})

