import { computePackagingCatalogFingerprint } from './jianying-packaging-resource-index.mjs'

const authorizationPattern = /^ovauth_[A-Za-z0-9_-]{8,160}$/u
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 503) => {
  const error = /** @type {Error & {code?: string, status?: number}} */ (new Error(code))
  error.code = code
  error.status = status
  throw error
}

/** Keep decoder-specific failures inside the stable NATIVE-017 contract. */
/** @param {unknown} error @returns {never} */
const failExtraction = (error) => {
  const candidate = /** @type {{code?: unknown, status?: unknown, message?: unknown}} */ (error)
  const status = typeof candidate?.status === 'number' && Number.isInteger(candidate.status)
    ? candidate.status
    : 503
  const rawCode = typeof candidate?.code === 'string'
    ? candidate.code
    : candidate?.message && typeof candidate.message === 'string'
      ? candidate.message
      : ''
  const mappedCode = {
    NATIVE018_DRAFT_SOURCE_INVALID: 'NATIVE017_DRAFT_SOURCE_INVALID',
    NATIVE018_DRAFT_SOURCE_UNAVAILABLE: 'NATIVE017_DRAFT_SOURCE_UNAVAILABLE',
    NATIVE018_DRAFT_AUTHORIZATION_INVALID: 'NATIVE017_DRAFT_AUTHORIZATION_INVALID',
    NATIVE018_DRAFT_AUTHORIZATION_UNAVAILABLE: 'NATIVE017_DRAFT_AUTHORIZATION_UNAVAILABLE',
    NATIVE018_DECODER_UNAVAILABLE: 'NATIVE017_DRAFT_DECODER_UNAVAILABLE',
    NATIVE018_SOURCE_CHANGED: 'NATIVE017_DRAFT_SOURCE_CHANGED',
    NATIVE018_DECODER_UNSUPPORTED_VERSION: 'NATIVE017_DRAFT_DECODER_UNSUPPORTED_VERSION',
    NATIVE018_DESKTOP_BINDING_INVALID: 'NATIVE017_DRAFT_DESKTOP_BINDING_INVALID',
    NATIVE018_DRAFT_STRUCTURE_INVALID: 'NATIVE017_DRAFT_CATALOG_INVALID',
    NATIVE018_CATALOG_TOO_LARGE: 'NATIVE017_DRAFT_SOURCE_TOO_LARGE',
    NATIVE018_SOURCE_TOO_LARGE: 'NATIVE017_DRAFT_SOURCE_TOO_LARGE',
    NATIVE018_REPARSE_POINT_REJECTED: 'NATIVE017_DRAFT_SOURCE_REPARSE_REJECTED',
    NATIVE018_DESKTOP_BINDING_UNAVAILABLE: 'NATIVE017_DRAFT_DESKTOP_BINDING_UNAVAILABLE',
  }[rawCode]
  if (typeof mappedCode === 'string') fail(mappedCode, status)
  if (/^NATIVE017_[A-Z_]+$/u.test(rawCode)) fail(rawCode, status)
  if (rawCode === 'JY018_NATIVE_FILE_TOO_LARGE') fail('NATIVE017_DRAFT_SOURCE_TOO_LARGE', 413)
  if (rawCode === 'JY018_NATIVE_REPARSE_REJECTED') fail('NATIVE017_DRAFT_SOURCE_REPARSE_REJECTED', 409)
  if (/^JY018_NATIVE_/u.test(rawCode)) fail('NATIVE017_DRAFT_SOURCE_UNAVAILABLE', status)
  fail('NATIVE017_DRAFT_EXTRACTION_UNAVAILABLE', status)
}

/**
 * Adapt a server-owned draft authorization to the NATIVE-016 provider shape.
 * The extractor is deliberately injected: this module owns authorization and
 * fingerprint/revocation gates, while a future exact-version decoder owns the
 * private draft format. No authorization path or raw catalog binding leaves
 * this module.
 *
 * @param {{resolveAuthorization: (id: string) => Promise<Record<string, any> | null>, extractCatalog: (input: {authorization: Record<string, any>, desktop: Record<string, any>}) => Promise<{entries: readonly Record<string, any>[], catalogFingerprint?: string, sourceFingerprint?: string}>}} dependencies
 */
export const createUserDraftCatalogProvider = ({ resolveAuthorization, extractCatalog }) => {
  if (typeof resolveAuthorization !== 'function' || typeof extractCatalog !== 'function') {
    fail('NATIVE017_DEPENDENCIES_INVALID', 500)
  }
  /** @param {unknown} authorizationId @returns {Promise<Record<string, any>>} */
  const authorize = async (authorizationId) => {
    if (typeof authorizationId !== 'string' || !authorizationPattern.test(authorizationId)) fail('NATIVE017_DRAFT_AUTHORIZATION_INVALID', 400)
    let authorization
    try { authorization = await resolveAuthorization(authorizationId) } catch { fail('NATIVE017_DRAFT_AUTHORIZATION_UNAVAILABLE', 503) }
    if (!isRecord(authorization) || authorization.authorizationId !== authorizationId || authorization.readOnly !== true || authorization.expired !== false || authorization.revoked !== false) {
      fail('NATIVE017_DRAFT_AUTHORIZATION_UNAVAILABLE', 503)
    }
    return /** @type {Record<string, any>} */ (authorization)
  }
  /** @param {{authorizationId: string, desktop: Record<string, any>, expectedFingerprint?: string | null, expectedSourceFingerprint?: string | null}} input @returns {Promise<{entries: Record<string, any>[], catalogFingerprint: string, sourceFingerprint: string}>} */
  const extract = async ({ authorizationId, desktop, expectedFingerprint = null, expectedSourceFingerprint = null }) => {
    const authorization = await authorize(authorizationId)
    let result
    try { result = await extractCatalog({ authorization, desktop }) } catch (error) { failExtraction(error) }
    // The decoder may run long enough for the user to revoke or replace the
    // draft. Re-resolve before accepting its snapshot, matching the miner's
    // post-decode authorization gate.
    await authorize(authorizationId)
    if (!isRecord(result) || !Array.isArray(result.entries) || result.entries.length > 20_000) fail('NATIVE017_DRAFT_CATALOG_INVALID', 503)
    if (typeof result.sourceFingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(result.sourceFingerprint)) fail('NATIVE017_DRAFT_SOURCE_FINGERPRINT_INVALID', 503)
    const entries = /** @type {Record<string, any>[]} */ (result.entries)
    let fingerprint
    try {
      fingerprint = computePackagingCatalogFingerprint({
        profileId: desktop.profileId,
        appVersion: desktop.version,
        entries,
        desktopBinding: desktop.binding,
      })
    } catch { fail('NATIVE017_DRAFT_CATALOG_INVALID', 503) }
    if (result.catalogFingerprint !== undefined && result.catalogFingerprint !== fingerprint) fail('NATIVE017_DRAFT_CATALOG_FINGERPRINT_MISMATCH', 409)
    if (expectedFingerprint !== null && fingerprint !== expectedFingerprint) fail('NATIVE017_DRAFT_CHANGED', 409)
    if (expectedSourceFingerprint !== null && result.sourceFingerprint !== expectedSourceFingerprint) fail('NATIVE017_DRAFT_SOURCE_CHANGED', 409)
    return { entries, catalogFingerprint: fingerprint, sourceFingerprint: result.sourceFingerprint }
  }
  return Object.freeze({
    /** @param {{desktop: Record<string, any>, draftAuthorizationId?: string | null}} input */
    prepare: async ({ desktop, draftAuthorizationId }) => {
      if (!draftAuthorizationId) fail('NATIVE017_DRAFT_AUTHORIZATION_REQUIRED', 400)
      const initial = await extract({ authorizationId: draftAuthorizationId, desktop })
      return Object.freeze({
        catalogFingerprint: initial.catalogFingerprint,
        /** @returns {Promise<Record<string, any>>} */
        ingest: async () => {
        const current = await extract({ authorizationId: draftAuthorizationId, desktop, expectedFingerprint: initial.catalogFingerprint, expectedSourceFingerprint: initial.sourceFingerprint })
          return Object.freeze({
            profile_id: desktop.profileId,
            app_version: desktop.version,
            catalog_fingerprint: current.catalogFingerprint,
            private_source_binding: {
              draft_authorization_id: draftAuthorizationId,
              source_fingerprint: current.sourceFingerprint,
            },
            state: 'discovery_only',
            entries: current.entries,
          })
        },
      })
    },
  })
}
