import { createHash } from 'node:crypto'

const resourcePattern = /^[A-Za-z0-9_-]{4,80}$/u
/** @param {string} resourceId */
const tokenFor = (resourceId) => `ovjblend_v1_${createHash('sha256').update(resourceId).digest('hex')}`
/** @param {unknown} catalog */
const fingerprint = (catalog) => createHash('sha256').update(JSON.stringify(catalog)).digest('hex')

/**
 * @typedef {{
 *   role: 'initial' | 'expected_post',
 *   display_name: string,
 *   resource_id: string,
 * }} BlendCatalogEntryInput
 * @typedef {{
 *   capability_id: 'blend.video.named',
 *   role: 'initial' | 'expected_post',
 *   blend_token: string,
 *   display_name: string,
 *   resource_id: string,
 * }} BlendCatalogEntry
 */

/**
 * @param {ReadonlyArray<BlendCatalogEntryInput>} entries
 */
export const createJianyingBlendCatalog = (entries) => {
  const normalized = entries.map(({ role, display_name, resource_id }) => ({
    capability_id: 'blend.video.named', role, blend_token: tokenFor(resource_id), display_name, resource_id,
  }))
  const body = { schema_version: 1, kind: 'jy046_blend_catalog', entries: normalized }
  return { ...body, catalog_fingerprint: fingerprint(body) }
}

/** @param {unknown} value */
export const parseJianyingBlendCatalog = (value) => {
  if (!value || typeof value !== 'object') return null
  const candidate = /** @type {Record<string, unknown>} */ (value)
  if (candidate.schema_version !== 1 || candidate.kind !== 'jy046_blend_catalog' || !Array.isArray(candidate.entries) || candidate.entries.length !== 2) return null
  const roles = candidate.entries.map((entry) => /** @type {Record<string, unknown>} */ (entry).role)
  if (roles[0] !== 'initial' || roles[1] !== 'expected_post') return null
  for (const entry of candidate.entries) {
    const item = /** @type {Record<string, unknown>} */ (entry)
    if (item.capability_id !== 'blend.video.named' || typeof item.display_name !== 'string' || !resourcePattern.test(typeof item.resource_id === 'string' ? item.resource_id : '') || item.blend_token !== tokenFor(typeof item.resource_id === 'string' ? item.resource_id : '')) return null
  }
  const body = { schema_version: 1, kind: 'jy046_blend_catalog', entries: candidate.entries }
  if (candidate.catalog_fingerprint !== fingerprint(body)) return null
  return structuredClone(candidate)
}
