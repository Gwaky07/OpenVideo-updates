const PROVIDER_ID = /^[a-z][a-z0-9_-]{2,63}$/
const COMMIT = /^[0-9a-f]{40}$/i
const STATES = Object.freeze(['candidate', 'audited', 'installed', 'probed', 'admitted'])
const REQUIRED_NETWORK_IDENTITY_BOUNDARY_KEYS = Object.freeze([
  'remote_resources',
  'cloud_upload',
  'account_device_identity',
  'inherited_cache',
])
const AUDIT_SHA256 = /^[0-9a-f]{64}$/iu

/** @param {string} value */
const pathLikeAuditEntry = (value) => value.startsWith('/') || /^[a-z]:[\\/]/iu.test(value) || value.startsWith('\\\\') ||
  value.split(/[\\/]/u).some((part) => part === '' || part === '.' || part === '..')

/** @param {string} reason */
const failClosed = (reason) => Object.freeze({
  state: 'candidate',
  enabled: false,
  admitted: false,
  reason,
})

/**
 * Evaluate a private external Writer manifest and evidence without exposing
 * upstream IDs, paths or runtime configuration to public DTOs.
 * @param {unknown} manifest
 * @param {unknown} evidence
 */
export const evaluateExternalWriterAdmission = (manifest, evidence) => {
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) return failClosed('JY200_MANIFEST_INVALID')
  const m = /** @type {Record<string, unknown>} */ (manifest)
  if (typeof m.provider !== 'string' || !PROVIDER_ID.test(m.provider)) return failClosed('JY200_PROVIDER_INVALID')
  if (typeof m.commit !== 'string' || !COMMIT.test(m.commit)) return failClosed('JY200_COMMIT_INVALID')
  if (m.default_enabled !== false) return failClosed('JY200_DEFAULT_ENABLED_DENIED')
  if (m.admission !== 'candidate' || !Array.isArray(m.audit_files) || m.audit_files.length === 0 ||
      m.audit_files.some((entry) => {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return true
        const audit = /** @type {Record<string, unknown>} */ (entry)
        return Object.keys(audit).sort().join('\0') !== ['path', 'sha256', 'size'].sort().join('\0') ||
          typeof audit.path !== 'string' || audit.path.length === 0 || pathLikeAuditEntry(audit.path) ||
          !Number.isSafeInteger(audit.size) || Number(audit.size) <= 0 ||
          typeof audit.sha256 !== 'string' || !AUDIT_SHA256.test(audit.sha256)
      })) return failClosed('JY200_PROVENANCE_INCOMPLETE')
  if (!Object.hasOwn(m, 'nested_dependencies') || !Array.isArray(m.nested_dependencies)) {
    return failClosed('JY200_NESTED_PROVENANCE_UNRESOLVED')
  }
  const nested = m.nested_dependencies
  if (nested.some((entry) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return true
    const dependency = /** @type {Record<string, unknown>} */ (entry)
    return dependency.status !== 'audited' || typeof dependency.path !== 'string' || dependency.path.length === 0 ||
      typeof dependency.commit !== 'string' || !COMMIT.test(dependency.commit)
  })) {
    return failClosed('JY200_NESTED_PROVENANCE_UNRESOLVED')
  }
  if (Object.hasOwn(m, 'excluded_components')) {
    if (!Array.isArray(m.excluded_components) || m.excluded_components.some((entry) => {
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return true
      const excluded = /** @type {Record<string, unknown>} */ (entry)
      return Object.keys(excluded).sort().join('\0') !== ['path', 'commit', 'status'].sort().join('\0') ||
        typeof excluded.path !== 'string' || excluded.path.length === 0 || pathLikeAuditEntry(excluded.path) ||
        typeof excluded.commit !== 'string' || !COMMIT.test(excluded.commit) ||
        excluded.status !== 'excluded_from_build_runtime_release'
    }) || new Set(m.excluded_components.map((entry) => /** @type {Record<string, unknown>} */ (entry).path)).size !== m.excluded_components.length) {
      return failClosed('JY200_EXCLUDED_COMPONENTS_INVALID')
    }
  }
  const boundary = m.network_identity_boundary
  const boundaryRecord = boundary && typeof boundary === 'object' && !Array.isArray(boundary)
    ? /** @type {Record<string, unknown>} */ (boundary)
    : null
  if (!boundaryRecord ||
      !REQUIRED_NETWORK_IDENTITY_BOUNDARY_KEYS.every((key) => Object.hasOwn(boundaryRecord, key) && boundaryRecord[key] === 'denied') ||
      Object.values(boundaryRecord).some((value) => value !== 'denied')) {
    return failClosed('JY200_NETWORK_IDENTITY_BOUNDARY_REQUIRED')
  }
  if (!evidence || typeof evidence !== 'object' || Array.isArray(evidence)) return failClosed('JY200_PROBE_EVIDENCE_MISSING')
  const e = /** @type {Record<string, unknown>} */ (evidence)
  if (e.provider !== m.provider || e.commit !== m.commit) return failClosed('JY200_EVIDENCE_IDENTITY_MISMATCH')
  if (e.staging_readback !== true || e.independent_readback !== true) return failClosed('JY200_READBACK_REQUIRED')
  if (e.same_draft_lifecycle !== true) return failClosed('JY200_SAME_DRAFT_LIFECYCLE_REQUIRED')
  if (e.current_catalog_bound !== true || e.build_digest_verified !== true) return failClosed('JY200_CURRENT_BINDING_REQUIRED')
  if (typeof e.advanced_family_count !== 'number' || e.advanced_family_count < 3) return failClosed('JY200_MULTI_FAMILY_EVIDENCE_REQUIRED')
  return Object.freeze({
    state: 'probed',
    enabled: false,
    admitted: false,
    provider: m.provider,
    commit: m.commit,
    reason: 'JY200_TRUSTED_REGISTRY_REQUIRED',
  })
}

/** @returns {ReadonlyArray<string>} */
export const externalWriterAdmissionStates = () => STATES
