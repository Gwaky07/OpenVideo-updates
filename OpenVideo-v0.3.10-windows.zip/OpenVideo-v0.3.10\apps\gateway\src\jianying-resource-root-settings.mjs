import { lstat, realpath } from 'node:fs/promises'
import path from 'node:path'

const opaqueIdPattern = /^[a-z0-9][a-z0-9._:-]{0,159}$/iu

export class JianyingResourceRootSettingsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) { super(code); this.code = code; this.status = status }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {string} parent @param {string} candidate */
const inside = (parent, candidate) => {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

const expectedDraftSuffix = path.join('Projects', 'com.lveditor.draft')
const resourceMetadataSuffixes = Object.freeze([
  Object.freeze(['Resources']),
  Object.freeze(['Cache', 'effect']),
])

/**
 * Derive only fixed resource-metadata directories from the exact trusted draft
 * root suffix. Never scan the draft tree, all of User Data, Config or identity
 * stores.
 * @param {{available?: unknown, profileId?: unknown, version?: unknown, installRoot?: unknown, draftRoot?: unknown}} desktop
 */
const desktopBoundaries = (desktop) => {
  if (desktop?.available !== true || typeof desktop.profileId !== 'string' || !/^jianying-[a-z0-9-]{1,60}$/u.test(desktop.profileId) ||
    typeof desktop.version !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(desktop.version) ||
    typeof desktop.installRoot !== 'string' || !path.isAbsolute(desktop.installRoot) ||
    typeof desktop.draftRoot !== 'string' || !path.isAbsolute(desktop.draftRoot)) return []
  const draftRoot = path.resolve(desktop.draftRoot)
  if (!draftRoot.toLowerCase().endsWith(expectedDraftSuffix.toLowerCase())) return []
  const userDataRoot = path.resolve(draftRoot, '..', '..')
  return resourceMetadataSuffixes.map((segments) => path.join(userDataRoot, ...segments))
}

/**
 * Require every existing node between candidate and its trusted desktop
 * boundary to resolve to itself. This rejects symlinks and Windows junctions
 * before JY135's native no-reparse reader sees any file.
 * @param {string} candidate
 * @param {readonly string[]} boundaries
 */
const validateCandidate = async (candidate, boundaries) => {
  if (typeof candidate !== 'string' || !path.isAbsolute(candidate)) return null
  const resolved = path.resolve(candidate)
  const boundary = boundaries.find((item) => inside(item, resolved))
  if (!boundary) return null
  let cursor = resolved
  while (true) {
    try {
      const [metadata, actual] = await Promise.all([lstat(cursor), realpath(cursor)])
      if (!metadata.isDirectory() || metadata.isSymbolicLink()) return null
      if (path.resolve(actual).toLowerCase() !== cursor.toLowerCase()) {
        if (process.platform !== 'win32') return null
        const actualMetadata = await lstat(actual)
        if (!actualMetadata.isDirectory() || actualMetadata.isSymbolicLink() ||
          actualMetadata.dev !== metadata.dev || actualMetadata.ino !== metadata.ino) return null
      }
    } catch { return null }
    if (cursor.toLowerCase() === boundary.toLowerCase()) break
    const parent = path.dirname(cursor)
    if (parent === cursor || !inside(boundary, parent)) return null
    cursor = parent
  }
  return resolved
}

/**
 * Server-owned automatic Jianying metadata roots. Private picker persistence is
 * deliberately disabled until a handle-pinned atomic writer exists.
 * @param {{detectDesktop: () => Promise<any>, desktopCacheTtlMs?: number, now?: () => number}} input
 */
export const createJianyingResourceRootSettingsService = ({ detectDesktop, desktopCacheTtlMs = 30_000, now = Date.now }) => {
  if (typeof detectDesktop !== 'function' || !Number.isSafeInteger(desktopCacheTtlMs) || desktopCacheTtlMs < 0 ||
      desktopCacheTtlMs > 30_000 || typeof now !== 'function') {
    throw new JianyingResourceRootSettingsError('JY175_SETTINGS_INVALID', 500)
  }
  let serialization = Promise.resolve()
  /** @type {Record<string, any> | null} */
  let cachedDesktop = null
  let desktopCachedAt = 0
  /** @template T @param {() => Promise<T>} operation */
  const serialize = (operation) => {
    const result = serialization.then(operation, operation)
    serialization = result.then(() => undefined, () => undefined)
    return result
  }
  const resolve = async () => {
    const observedAt = now()
    let desktop = cachedDesktop && observedAt >= desktopCachedAt && observedAt - desktopCachedAt <= desktopCacheTtlMs
      ? cachedDesktop
      : null
    if (!desktop) {
      try {
        desktop = await detectDesktop()
        if (desktop?.available === true) {
          cachedDesktop = desktop
          desktopCachedAt = now()
        }
      } catch { desktop = null }
    }
    const boundaries = desktop ? desktopBoundaries(desktop) : []
    /** @type {string[]} */
    const automatic = []
    for (const candidate of boundaries) {
      const accepted = await validateCandidate(candidate, boundaries)
      if (accepted) automatic.push(accepted)
    }
    return automatic.length > 0
      ? { roots: Object.freeze(automatic), source: 'automatic', desktop }
      : { roots: Object.freeze([]), source: 'none', desktop }
  }
  const publicState = (/** @type {{roots: readonly string[], source: string}} */ state) => Object.freeze({
    schema_version: 1,
    status: state.roots.length === 0 ? 'unconfigured' : state.source,
    configured: state.roots.length > 0,
    private_selection_available: false,
  })
  return Object.freeze({
    resolvePrivate: () => serialize(resolve),
    readPublic: () => serialize(async () => publicState(await resolve())),
  })
}

/** @param {Request} request */
const readStrictJson = async (request) => {
  if ((request.headers.get('content-type') ?? '').split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new JianyingResourceRootSettingsError('UNSUPPORTED_MEDIA_TYPE', 415)
  }
  try {
    const value = await request.json()
    if (!record(value)) throw new Error('not-object')
    return value
  } catch { throw new JianyingResourceRootSettingsError('JY175_INPUT_INVALID') }
}

/** @param {{service: ReturnType<typeof createJianyingResourceRootSettingsService>}} input */
export const createJianyingResourceRootSettingsHandler = ({ service }) => async (/** @type {Request} */ request) => {
  const pathname = new URL(request.url).pathname
  try {
    if (pathname === '/api/settings/jianying-resource-roots' && request.method === 'GET') {
      return Response.json(await service.readPublic())
    }
    if (pathname === '/api/settings/jianying-resource-roots/select' && request.method === 'POST') {
      const input = await readStrictJson(request)
      if (Object.keys(input).sort().join('|') !== 'nodeId|sessionId' ||
        typeof input.sessionId !== 'string' || !opaqueIdPattern.test(input.sessionId) ||
        typeof input.nodeId !== 'string' || !opaqueIdPattern.test(input.nodeId)) {
        throw new JianyingResourceRootSettingsError('JY175_INPUT_INVALID')
      }
      throw new JianyingResourceRootSettingsError('JY175_PRIVATE_SELECTION_UNAVAILABLE', 503)
    }
    return Response.json({ error: { code: 'METHOD_NOT_ALLOWED' } }, { status: 405 })
  } catch (error) {
    const known = error instanceof JianyingResourceRootSettingsError
    return Response.json({ error: { code: known ? error.code : 'JY175_SETTINGS_UNAVAILABLE' } }, { status: known ? error.status : 503 })
  }
}
