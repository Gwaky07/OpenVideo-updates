import { isProjectTemplateBinding } from './reusable-template-contracts.mjs'
import { buildStyleSummaryFromArtifact } from './template-style-profile.mjs'

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

export class TemplateBindingConsumptionError extends Error {
  /** @param {string} [code] @param {number} [status] */
  constructor(code = 'WORKBENCH_TEMPLATE_BINDING_INVALID', status = 409) {
    super(code)
    this.name = 'TemplateBindingConsumptionError'
    this.code = code
    this.status = status
    this.recoverable = true
  }
}

/** @param {Record<string, any>} rules */
const publicRules = (rules) => {
  const cadence = record(rules.caption_cadence) ? rules.caption_cadence : {}
  const packaging = record(rules.packaging) ? rules.packaging : {}
  return {
    captionCadence: {
      mode: typeof cadence.mode === 'string' ? cadence.mode : 'none',
      ...(Number.isSafeInteger(cadence.max_chars_per_card)
        ? { maxCharsPerCard: cadence.max_chars_per_card }
        : {}),
      ...(Number.isSafeInteger(cadence.cards_per_minute)
        ? { cardsPerMinute: cadence.cards_per_minute }
        : {}),
    },
    packaging: {
      ...(typeof packaging.intro === 'string' ? { intro: packaging.intro } : {}),
      ...(typeof packaging.outro === 'string' ? { outro: packaging.outro } : {}),
      ...(typeof packaging.subtitle_style === 'string'
        ? { subtitleStyle: packaging.subtitle_style }
        : {}),
    },
  }
}

/**
 * Converts the immutable project snapshot into a path-free execution contract.
 * @param {unknown} binding
 */
export const createTemplateGuidance = (binding) => {
  if (binding === null || binding === undefined) return null
  if (!isProjectTemplateBinding(binding)) {
    throw new TemplateBindingConsumptionError()
  }
  const value = /** @type {Record<string, any>} */ (binding)
  return {
    schemaVersion: 1,
    source: 'project_template_binding',
    libraryTemplateId: value.libraryTemplateId,
    revision: value.revision,
    fingerprint: value.fingerprint,
    orientation: value.orientation,
    targetDurationMs: value.draft.targetDurationMs,
    pacing: value.pacing,
    ...(Array.isArray(value.blendSources)
      ? { blendSources: clone(value.blendSources) }
      : {}),
    styleProfile: clone(value.styleProfile ?? buildStyleSummaryFromArtifact({
      draft: {
        slots: value.draft.slots,
        rules: value.draft.rules,
      },
      analysis: {},
    })),
    ...(
      value.replicationRecipe && typeof value.replicationRecipeFingerprint === 'string'
        ? { replicationRecipe: clone(value.replicationRecipe) }
        : {}
    ),
    slots: [...value.draft.slots]
      .sort((left, right) => left.order - right.order)
      .map((slot) => ({
        order: slot.order,
        role: slot.role,
        recommendedDurationMs: slot.recommended_duration_ms,
        transitionOut: slot.transition_out,
      })),
    rules: publicRules(value.draft.rules),
  }
}

/**
 * Deterministically compresses adjacent slots or repeats evenly sampled slots.
 * Slot durations are retained as style metadata only; canonical timing belongs
 * to the current project's shots and narration.
 * @param {Record<string, any> | null} guidance
 * @param {number} count
 * @returns {Record<string, any>}
 */
export const adaptTemplateGuidanceToCount = (guidance, count) => {
  if (
    !guidance ||
    !Number.isSafeInteger(count) ||
    count < 1 ||
    !Array.isArray(guidance.slots) ||
    guidance.slots.length < 1
  ) {
    throw new TemplateBindingConsumptionError()
  }
  const source = guidance.slots
  /** @type {Record<string, any>[]} */
  const slots = []
  if (count <= source.length) {
    for (let index = 0; index < count; index += 1) {
      const start = Math.floor(index * source.length / count)
      const end = Math.floor((index + 1) * source.length / count)
      const group = source.slice(start, Math.max(start + 1, end))
      slots.push({
        ...clone(group[0]),
        order: index + 1,
        recommendedDurationMs: group.reduce(
          (total, slot) => total + slot.recommendedDurationMs,
          0,
        ),
        transitionOut: index === count - 1
          ? 'none'
          : /** @type {Record<string, any>} */ (group.at(-1)).transitionOut,
      })
    }
  } else {
    const sourceCounts = new Array(source.length).fill(0)
    const sourceIndexes = []
    for (let index = 0; index < count; index += 1) {
      const sourceIndex = count === 1
        ? 0
        : Math.round(index * (source.length - 1) / (count - 1))
      sourceIndexes.push(sourceIndex)
      sourceCounts[sourceIndex] += 1
    }
    const weights = sourceIndexes.map(
      (sourceIndex) => source[sourceIndex].recommendedDurationMs / sourceCounts[sourceIndex],
    )
    const extraBudget = guidance.targetDurationMs - count
    if (extraBudget < 0) throw new TemplateBindingConsumptionError()
    const weightTotal = weights.reduce((total, weight) => total + weight, 0)
    const rawExtras = weights.map((weight) => extraBudget * weight / weightTotal)
    const extras = rawExtras.map((value) => Math.floor(value))
    const remainder = extraBudget - extras.reduce((total, value) => total + value, 0)
    const remainderOrder = rawExtras
      .map((value, index) => ({ index, fraction: value - extras[index] }))
      .sort((left, right) => right.fraction - left.fraction || left.index - right.index)
    for (let index = 0; index < remainder; index += 1) {
      extras[remainderOrder[index].index] += 1
    }
    for (let index = 0; index < count; index += 1) {
      const sourceIndex = sourceIndexes[index]
      const sourceSlot = source[sourceIndex]
      const isLast = index === count - 1
      slots.push({
        ...clone(sourceSlot),
        order: index + 1,
        recommendedDurationMs: 1 + extras[index],
        transitionOut: isLast
          ? 'none'
          : sourceSlot.transitionOut === 'none'
            ? 'cut'
            : sourceSlot.transitionOut,
      })
    }
  }
  return { ...clone(guidance), slots }
}

/**
 * Keeps provider claims honest until both production writers implement richer
 * transitions. Adjacent clips already provide a real cut; the final slot is none.
 * @param {Record<string, any> | null} guidance
 */
export const assertTemplateGuidanceExecutable = (guidance) => {
  if (guidance === null) return null
  if (
    !guidance ||
    !Array.isArray(guidance.slots) ||
    guidance.slots.some((slot) => !['cut', 'none'].includes(slot.transitionOut))
  ) {
    throw new TemplateBindingConsumptionError(
      'WORKBENCH_TEMPLATE_TRANSITION_UNSUPPORTED',
      409,
    )
  }
  return guidance
}

/**
 * @param {unknown} selections
 * @param {Record<string, any> | null} guidance
 */
export const applyTemplateGuidanceToSelections = (selections, guidance) => {
  if (!Array.isArray(selections)) throw new TemplateBindingConsumptionError()
  const result = clone(selections)
  if (guidance === null) return result
  if (
    !guidance ||
    !Array.isArray(guidance.slots) ||
    guidance.slots.reduce(
      (total, slot) => total + slot.recommendedDurationMs,
      0,
    ) !== guidance.targetDurationMs
  ) {
    throw new TemplateBindingConsumptionError()
  }
  return result.map((selection) => {
    if (
      !record(selection) ||
      typeof selection.start !== 'number' ||
      !Number.isFinite(selection.start) ||
      typeof selection.end !== 'number' ||
      !Number.isFinite(selection.end) ||
      selection.end <= selection.start
    ) {
      throw new TemplateBindingConsumptionError(
        'WORKBENCH_TEMPLATE_SELECTION_RANGE_INVALID',
        409,
      )
    }
    return selection
  })
}

/**
 * Validates the selected candidates while retaining their current-project
 * ranges. Template slot durations remain learning metadata only.
 * @param {unknown} editPlan
 * @param {Record<string, any> | null} guidance
 */
export const applyTemplateGuidanceToEditPlan = (editPlan, guidance) => {
  if (!record(editPlan) || !Array.isArray(editPlan.items)) {
    throw new TemplateBindingConsumptionError()
  }
  const result = clone(editPlan)
  if (guidance === null) return result
  if (
    !guidance ||
    !Array.isArray(guidance.slots) ||
    guidance.slots.reduce(
      (total, slot) => total + slot.recommendedDurationMs,
      0,
    ) !== guidance.targetDurationMs
  ) {
    throw new TemplateBindingConsumptionError()
  }
  result.items = result.items.map((
    /** @type {Record<string, any>} */ item,
  ) => {
    if (!record(item) || !Array.isArray(item.candidates)) {
      throw new TemplateBindingConsumptionError()
    }
    if (item.status !== 'selected') return item
    const selectedIndex = item.candidates.findIndex(
      (candidate) =>
        record(candidate) &&
        candidate.candidate_id === item.selected_candidate_id,
    )
    if (selectedIndex < 0) throw new TemplateBindingConsumptionError()
    const selected = item.candidates[selectedIndex]
    if (
      typeof selected.start !== 'number' ||
      !Number.isFinite(selected.start) ||
      typeof selected.end !== 'number' ||
      !Number.isFinite(selected.end) ||
      selected.end <= selected.start
    ) {
      throw new TemplateBindingConsumptionError(
        'WORKBENCH_TEMPLATE_SELECTION_RANGE_INVALID',
        409,
      )
    }
    return {
      ...item,
      candidates: [
        selected,
        ...item.candidates.filter((_, candidateIndex) => candidateIndex !== selectedIndex),
      ],
    }
  })
  return result
}
