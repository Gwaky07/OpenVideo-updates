import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { lstat, readFile, readdir, rename, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import process from 'node:process'
import path from 'node:path'
import { pipeline } from 'node:stream/promises'

import { JianyingDraftAdapterError } from './jianying-draft-adapter.mjs'
import { validatePrivateBatchPlanForWriter as validatePrivateBatchPlanAgainstAdmission, verifyPrivateBatchDraftReadback } from './jianying-private-batch-packaging.mjs'
import { isJianyingFlowerTextTrackName, isJianyingOverlayRichTextTrack, overlayJianyingTemplatePackaging } from './jianying-template-cloner.mjs'
import { selectMatchedRichTextReplacements, toPackagingVideoRange } from './jianying-template-packaging-select.mjs'
import { fingerprintRenderBundleIdentity, assertRenderBundleIdentity } from './jianying-render-contracts.mjs'

const maxBridgeOutputBytes = 65_536
const isolationStatConcurrency = 32
const governedUpstreamCommit = 'c3318066d964744e2bfc66f75c71745fe8cea52a'

/** @template T, R @param {T[]} items @param {number} limit @param {(item: T) => Promise<R>} mapper */
const mapLimit = async (items, limit, mapper) => {
  if (items.length === 0) return []
  /** @type {R[]} */
  const results = new Array(items.length)
  let index = 0
  const settled = await Promise.allSettled(Array.from(
    { length: Math.min(Math.max(limit, 1), items.length) },
    async () => {
      while (index < items.length) {
        const current = index
        index += 1
        results[current] = await mapper(items[current])
      }
    },
  ))
  const firstRejection = settled.find((entry) => entry.status === 'rejected')
  if (firstRejection) throw firstRejection.reason
  return results
}
const draftCanvasByOrientation = Object.freeze({
  portrait: Object.freeze({ width: 1080, height: 1920 }),
  landscape: Object.freeze({ width: 1920, height: 1080 }),
  square: Object.freeze({ width: 1080, height: 1080 }),
})
/** @param {unknown} orientation */
const resolveDraftCanvas = (orientation) =>
  orientation === 'portrait'
    ? draftCanvasByOrientation.portrait
    : orientation === 'landscape'
      ? draftCanvasByOrientation.landscape
      : orientation === 'square'
        ? draftCanvasByOrientation.square
        : null

export const inspectTemplateTextTracks = (blueprintContent) => {
  const tracks = Array.isArray(blueprintContent?.tracks) ? blueprintContent.tracks : []
  const names = tracks
    .filter((/** @type {Record<string, any>} */ track) => track?.type === 'text')
    .map((/** @type {Record<string, any>} */ track) => String(track?.name ?? '').trim())
  return {
    hasFlowerText: tracks.some((/** @type {Record<string, any>} */ track) => isJianyingOverlayRichTextTrack(track)),
    hasSubtitles: names.some((name) => /subtitles|字幕/iu.test(name)),
  }
}

/**
 * Rich/flower titles are template overlay replacements. Putting them on the
 * single Python title-primary track overlaps and fail-closes the whole draft.
 * @param {Array<Record<string, any>> | undefined} titleSegments
 */
export const selectPythonWriterTitleSegments = (titleSegments) =>
  (Array.isArray(titleSegments) ? titleSegments : []).filter((segment) => segment?.rich === false)

/**
 * Verify must expect the same title-primary payload Python wrote. Overlay
 * flower/sticker tracks are checked separately and must not revive 45 rich
 * titles as a missing title-primary lane.
 * @param {{pythonTitleSegments: Array<Record<string, any>>, allTitleSegments?: Array<Record<string, any>>, templateHasFlowerText?: boolean, templateBackedRichIndexes?: Set<number>}} input
 */
export const selectVerifiedWriterTitleSegments = ({
  pythonTitleSegments,
  allTitleSegments = [],
  templateHasFlowerText = false,
  templateBackedRichIndexes = new Set(),
}) => {
  if (templateHasFlowerText) return pythonTitleSegments
  if (templateBackedRichIndexes.size > 0) {
    return allTitleSegments.filter((segment, index) =>
      !templateBackedRichIndexes.has(index) && segment?.rich === false)
  }
  return pythonTitleSegments
}

/**
 * The Python writer creates every canonical title before the private template
 * overlay runs. Once FlowerText has accepted the rich replacements, keeping
 * those generated segments would render the same copy twice. Remove only the
 * rich entries by their original positional identity; ordinary title cards
 * and captions remain untouched.
 * @param {{draftFolder: string, titleSegments: Array<Record<string, any>>, removedIndexes: Set<number>}} input
 */
const removeTemplateBackedRichTitleSegments = async ({ draftFolder, titleSegments, removedIndexes }) => {
  if (removedIndexes.size === 0) return null
  const contentPath = path.join(draftFolder, 'draft_content.json')
  let content
  try {
    content = JSON.parse(await readFile(contentPath, 'utf8'))
  } catch {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-rich-deduplication' })
  }
  const tracks = /** @type {Array<Record<string, any>>} */ (Array.isArray(content?.tracks) ? content.tracks : [])
  const titleTracks = tracks.filter((/** @type {Record<string, any>} */ track) =>
    track?.type === 'text' && track?.name === 'title-primary')
  if (titleTracks.length !== 1 || !Array.isArray(titleTracks[0].segments) || titleTracks[0].segments.length !== titleSegments.length) {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-rich-deduplication' })
  }
  const removedMaterialIds = new Set()
  titleTracks[0].segments = titleTracks[0].segments.filter((/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => {
    if (!removedIndexes.has(index)) return true
    if (typeof segment?.material_id === 'string') removedMaterialIds.add(segment.material_id)
    return false
  })
  if (titleTracks[0].segments.length === 0) {
    content.tracks = tracks.filter((/** @type {Record<string, any>} */ track) => track !== titleTracks[0])
  }
  const retainedMaterialIds = new Set(
    content.tracks.flatMap((/** @type {Record<string, any>} */ track) => Array.isArray(track?.segments)
      ? track.segments.map((/** @type {Record<string, any>} */ segment) => segment?.material_id)
        .filter((/** @type {unknown} */ value) => typeof value === 'string')
      : []),
  )
  if (Array.isArray(content?.materials?.texts)) {
    content.materials.texts = content.materials.texts.filter((/** @type {Record<string, any>} */ material) =>
      !removedMaterialIds.has(material?.id) || retainedMaterialIds.has(material.id))
  }
  const bytes = Buffer.from(JSON.stringify(content, null, 2), 'utf8')
  await writeFile(contentPath, bytes, { mode: 0o600 })
  return createHash('sha256').update(bytes).digest('hex')
}

/**
 * Verify that a template overlay produced real editable Jianying entities.
 * The Python writer only knows about canonical tracks; the private template
 * overlay is appended afterwards, so its presence must be checked separately
 * before the draft can be promoted.
 * @param {{draftFolder: string, expectedRichCount: number, expectedRichReplacementCount: number, expectedCaptionCount?: number}} input
 */
const verifyTemplateOverlayReadback = async ({ draftFolder, expectedRichCount, expectedRichReplacementCount, expectedCaptionCount = 0 }) => {
  let content
  try {
    content = JSON.parse(await readFile(path.join(draftFolder, 'draft_content.json'), 'utf8'))
  } catch {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-readback' })
  }
  const tracks = Array.isArray(content?.tracks) ? content.tracks : []
  const materials = content?.materials && typeof content.materials === 'object' ? content.materials : {}
  const materialById = new Map(
    Object.values(materials)
      .filter(Array.isArray)
      .flat()
      .filter((entry) => entry && typeof entry === 'object' && typeof entry.id === 'string')
      .map((entry) => [entry.id, entry]),
  )
  const overlayTracks = tracks.filter((/** @type {Record<string, any>} */ track) =>
    track && typeof track === 'object' && typeof track.id === 'string' && track.id.startsWith('ov_track_'))
  if (overlayTracks.length === 0 || overlayTracks.some((/** @type {Record<string, any>} */ track) => !Array.isArray(track.segments) || track.segments.length === 0)) {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-readback' })
  }
  const richTracks = overlayTracks.filter((/** @type {Record<string, any>} */ track) =>
    isJianyingOverlayRichTextTrack(track) || isJianyingFlowerTextTrackName(track.name))
  const richSegments = richTracks.flatMap((/** @type {Record<string, any>} */ track) => track.segments)
  // Timeline rich text must land on a real FlowerText lane. A sticker-only
  // overlay with expectedRichReplacementCount=0 used to pass readback and
  // publish a draft that opened with zero visible flower text.
  if (expectedRichCount > 0 && richSegments.length < expectedRichCount) {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-rich-readback' })
  }
  if (expectedRichReplacementCount > 0 && richSegments.length === 0) {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-rich-readback' })
  }
  const captionTracks = overlayTracks.filter((/** @type {Record<string, any>} */ track) =>
    track.type === 'text' && /^(?:subtitles|字幕)$/iu.test(String(track.name ?? '').trim()))
  const captionOverlaySegments = captionTracks.flatMap((/** @type {Record<string, any>} */ track) => track.segments)
  if (expectedCaptionCount > 0 && captionOverlaySegments.length < expectedCaptionCount) {
    throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-caption-readback' })
  }
  for (const segment of richSegments) {
    if (!segment || typeof segment.material_id !== 'string' || !materialById.has(segment.material_id)) {
      throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-material-readback' })
    }
  }
  return { overlayTrackCount: overlayTracks.length, richSegmentCount: richSegments.length }
}
const bridgeErrorCodes = new Set([
  'JY002_MATERIAL_AUTHORIZATION_EXPIRED',
  'JY002_PATH_PERMISSION_DENIED',
  'JY002_DESKTOP_VERSION_UNSUPPORTED',
  'JY002_OUTPUT_CONFLICT',
  'JY002_DRAFT_WRITE_FAILED',
  'JY002_DRAFT_STRUCTURE_INVALID',
])

/** @param {unknown} error */
export const projectWriterDiagnosticReason = (error) =>
  error instanceof Error && /^JY\d+_[A-Z0-9_]+$/u.test(error.message)
    ? error.message
    : 'PRIVATE_BATCH_INVALID'

/** Keep template identity opaque and exact before any private resolver call. */
/** @param {unknown} value @returns {{blueprintId: string, fingerprint: string} | null} */
export const normalizeJianyingTemplateBlueprint = (value) => {
  if (value === null || value === undefined) return null
  if (!isRecord(value) || Object.keys(value).sort().join('|') !== 'blueprintId|fingerprint' ||
      typeof value.blueprintId !== 'string' || !/^[A-Za-z0-9_-]{1,120}$/u.test(value.blueprintId) ||
      typeof value.fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(value.fingerprint)) {
    throw new JianyingDraftAdapterError('JY002_TEMPLATE_CAPABILITY_UNSUPPORTED')
  }
  return Object.freeze({ blueprintId: value.blueprintId, fingerprint: value.fingerprint })
}

/** Map private plan shape failures to the stable writer boundary error. */
/** @param {unknown} plan @param {((packagingToken: string) => Record<string, any> | null) | null} [resolvePackagingToken] @returns {ReadonlyArray<Record<string, any>>} */
export const validatePrivateBatchPlanForWriter = (plan, resolvePackagingToken = null) => {
  try {
    return validatePrivateBatchPlanAgainstAdmission(plan, resolvePackagingToken)
  } catch {
    throw new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID')
  }
}

/**
 * Keep private template resolver failures behind the stable writer boundary.
 * Resolver implementations may use private-store-specific error codes, but
 * callers only need to know that the selected template cannot be resolved.
 * @param {unknown} error
 * @returns {JianyingDraftAdapterError}
 */
export const mapTemplateResolverError = (error) => {
  if (error instanceof JianyingDraftAdapterError) return error
  return new JianyingDraftAdapterError('JY002_TEMPLATE_CAPABILITY_UNSUPPORTED')
}

/**
 * Keep private blueprint read/overlay failures behind the stable writer
 * boundary. The canonical RichTimeline has already been projected by the
 * bridge; a failed overlay must therefore fail the draft instead of leaking a
 * private clone error or leaving a partially modified result.
 * @param {unknown} error
 * @returns {JianyingDraftAdapterError}
 */
export const mapTemplateOverlayError = (error) => {
  if (error instanceof JianyingDraftAdapterError) return error
  return Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay' })
}

/**
 * Match canonical SFX segments to the authored template audio track that owns
 * the same cue. Template tracks are grouped by track in draft_content.json,
 * while RichTimeline segments are ordered by time, so flattening the tracks is
 * incorrect whenever the authored tracks interleave.
 *
 * Exact start/duration matches are preferred. When a timeline has been
 * time-scaled, normalized start and duration provide a deterministic fallback.
 * @param {{sfxSegments: Array<Record<string, any>>, audioTracks: Array<Record<string, any>>, targetDurationUs: number, templateDurationUs: number}} input
 * @returns {string[] | null}
 */
export const matchTemplateSfxTrackNames = ({
  sfxSegments,
  audioTracks,
  targetDurationUs,
  templateDurationUs,
}) => {
  if (!Array.isArray(sfxSegments) || !Array.isArray(audioTracks) || sfxSegments.length === 0 ||
      !Number.isSafeInteger(targetDurationUs) || targetDurationUs <= 0 ||
      !Number.isSafeInteger(templateDurationUs) || templateDurationUs <= 0) return null
  const cues = audioTracks.flatMap((track, trackIndex) =>
    (Array.isArray(track?.segments) ? track.segments : []).map((segment) => ({
      start: segment?.target_timerange?.start,
      duration: segment?.target_timerange?.duration,
      trackName: trackIndex === 0 ? 'sfx-primary' : `sfx-${trackIndex + 1}`,
    })),
  )
  if (cues.length !== sfxSegments.length || cues.some((cue) =>
    !Number.isSafeInteger(cue.start) || cue.start < 0 ||
    !Number.isSafeInteger(cue.duration) || cue.duration <= 0)) return null

  const used = new Set()
  /** @type {string[]} */
  const matchedTrackNames = []
  for (const segment of sfxSegments) {
    const exactIndex = cues.findIndex((cue, index) =>
      !used.has(index) && cue.start === segment?.target_start_us && cue.duration === segment?.target_duration_us)
    let matchIndex = exactIndex
    if (matchIndex < 0) {
      const targetStart = Number(segment?.target_start_us) / targetDurationUs
      const targetDuration = Number(segment?.target_duration_us) / targetDurationUs
      if (!Number.isFinite(targetStart) || !Number.isFinite(targetDuration)) return null
      let bestScore = Number.POSITIVE_INFINITY
      for (let index = 0; index < cues.length; index += 1) {
        if (used.has(index)) continue
        const cue = cues[index]
        const score = Math.abs(cue.start / templateDurationUs - targetStart) +
          Math.abs(cue.duration / templateDurationUs - targetDuration)
        if (score < bestScore) {
          bestScore = score
          matchIndex = index
        }
      }
    }
    if (matchIndex < 0) return null
    used.add(matchIndex)
    matchedTrackNames.push(cues[matchIndex].trackName)
  }
  return matchedTrackNames
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {value is {path: string}} */
const isPrivateResolvedPath = (value) => {
  if (!isRecord(value) || Object.keys(value).length !== 1) return false
  const record = /** @type {Record<string, unknown>} */ (value)
  return typeof record.path === 'string' && path.isAbsolute(record.path)
}
/**
 * Fingerprints top-level draft names and filesystem metadata only.
 * Nested media, draft JSON and asset trees are never listed or read. A full
 * recursive walk of a live Jianying draft root (hundreds of projects) blocks
 * the writer for minutes at 55%/80% and can miss the export deadline.
 * @param {string} root
 * @param {Set<string>} excludedTopLevel
 */
export const snapshotJianyingDraftIsolationMetadata = async (root, excludedTopLevel) => {
  const topLevel = await readdir(root)
  topLevel.sort()
  // The staging root is writer-owned scratch space. Its directory metadata
  // necessarily changes during every write and must never be treated as an
  // existing user draft for isolation accounting.
  const writerOwnedRoots = new Set(['.openvideo-staging', '.openvideo-locks'])
  const included = topLevel.filter((name) => !writerOwnedRoots.has(name) && !excludedTopLevel.has(name))
  const startedAt = performance.now()
  const entries = await mapLimit(included, isolationStatConcurrency, async (name) => {
    const metadata = await lstat(path.join(root, name))
    return {
      name: name.replaceAll(path.sep, '/'),
      type: metadata.isDirectory() ? 'directory' : metadata.isFile() ? 'file' : 'other',
      size: metadata.size,
      mtime_ms: metadata.mtimeMs,
    }
  })
  const snapshot = {
    entryCount: included.length,
    fingerprint: createHash('sha256').update(JSON.stringify(entries)).digest('hex'),
  }
  console.warn(JSON.stringify({
    event: 'jianying_writer_isolation_snapshot',
    entryCount: snapshot.entryCount,
    ms: Math.round(performance.now() - startedAt),
  }))
  return snapshot
}

const snapshotDraftMetadata = snapshotJianyingDraftIsolationMetadata

/** @param {string} code */
const toAdapterError = (code) =>
  new JianyingDraftAdapterError(
    bridgeErrorCodes.has(code)
      ? /** @type {ConstructorParameters<typeof JianyingDraftAdapterError>[0]} */ (code)
      : 'JY002_DRAFT_WRITE_FAILED',
  )

/** @param {number} optionalTrackCount @param {string | null} requestedCapability */
export const resolveTrackInsertionCapability = (optionalTrackCount, requestedCapability) => {
  const derived = optionalTrackCount === 1 ? 'track.insert' : optionalTrackCount > 1 ? 'track.insert_many' : null
  if (!requestedCapability || requestedCapability !== derived) {
    throw Object.assign(new JianyingDraftAdapterError('JY092_TRACK_INSERTION_REQUIREMENT_MISSING'), { stage: 'track-insertion-requirement' })
  }
  return requestedCapability
}

/**
 * @param {{draftRoot: string, pythonExecutable?: string, pythonModuleRoot?: string, bridgePath?: string, timeoutMs?: number, captions?: boolean, bgmPath?: string | null, getBgmLease?: ((requestId: string) => {extension: string, sha256: string, size: number, createStream: () => import('node:stream').Readable, release: () => Promise<void>} | null) | null, getRenderOptions?: ((input: Record<string, any>) => {draftLabel?: string, captions?: boolean, bgmPath?: string | null, bgmVolume?: number, subtitleStyle?: 'default' | 'bottom_safe', titleSegments?: Array<{segment_id?: string, text: string, target_start_us: number, target_duration_us: number, rich?: boolean, template_slot_id?: string}>, keywordHighlights?: string[], captionSegments?: Array<Record<string, any>> | null, timelinePackaging?: Record<string, any> | null, trackInsertionProfile?: string | null, trackInsertionCapability?: string | null, templateBlueprint?: {blueprintId: string, fingerprint: string} | null, renderBundleIdentity?: Record<string, any> | null, resolvePrivatePackagingToken?: ((packagingToken: string) => Record<string, any> | null) | null}) | null, resolvePrivatePackagingToken?: ((packagingToken: string) => Record<string, any> | null) | null, resolveTemplateBlueprint?: ((input: {blueprintId: string, fingerprint: string}) => Promise<string | null>) | null}} options
 */
export const createPyJianyingDraftWriter = ({
  draftRoot,
  pythonExecutable = 'python',
  pythonModuleRoot,
  bridgePath = fileURLToPath(new URL('./jianying-draft-writer.py', import.meta.url)),
  timeoutMs = 60_000,
  captions = false,
  bgmPath = null,
  getBgmLease = null,
  getRenderOptions = null,
  resolvePrivatePackagingToken = null,
  resolveTemplateBlueprint = null,
}) => {
  if (
    !path.isAbsolute(draftRoot) ||
    !path.isAbsolute(bridgePath) ||
    (pythonModuleRoot !== undefined && !path.isAbsolute(pythonModuleRoot)) ||
    typeof captions !== 'boolean' ||
    (bgmPath !== null && !path.isAbsolute(bgmPath)) ||
    (getBgmLease !== null && typeof getBgmLease !== 'function') ||
    (getRenderOptions !== null && typeof getRenderOptions !== 'function') ||
    (resolvePrivatePackagingToken !== null && typeof resolvePrivatePackagingToken !== 'function') ||
    (resolveTemplateBlueprint !== null && typeof resolveTemplateBlueprint !== 'function') ||
    timeoutMs < 1_000
  ) {
    throw new JianyingDraftAdapterError('JY002_PATH_PERMISSION_DENIED')
  }

  const resolveRenderOptions = (input = {}) => {
    const override = typeof getRenderOptions === 'function' ? getRenderOptions(input) : null
    const titleSegments = Array.isArray(override?.titleSegments) ? override.titleSegments : []
    const keywordHighlights = Array.isArray(override?.keywordHighlights)
      ? override.keywordHighlights.filter((item) => typeof item === 'string' && item.trim())
      : []
    const captionSegments = Array.isArray(override?.captionSegments) ? override.captionSegments : null
    const timelinePackaging = override?.timelinePackaging && typeof override.timelinePackaging === 'object'
      ? override.timelinePackaging
      : null
    // Segment-local video effects are intentionally blocked until a private
    // catalog, writer projection and same-draft Jianying evidence chain exists.
    // Silently dropping this field would turn an unsupported request into a
    // false-success draft.
    if (timelinePackaging && Object.hasOwn(timelinePackaging, 'segment_effect_segments')) {
      const segmentEffectSegments = timelinePackaging.segment_effect_segments
      if (!Array.isArray(segmentEffectSegments) || segmentEffectSegments.length > 0) {
        throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'segment-effect-projection' })
      }
    }
    const privateBatchPlan = /** @type {Record<string, any>[]} */ (Array.isArray(timelinePackaging?.private_batch_plan)
      ? timelinePackaging.private_batch_plan
      : [])
    try {
      validatePrivateBatchPlanForWriter(
        privateBatchPlan,
        typeof override?.resolvePrivatePackagingToken === 'function'
          ? override.resolvePrivatePackagingToken
          : resolvePrivatePackagingToken,
      )
    } catch (error) {
      console.warn(JSON.stringify({
        event: 'jianying_writer_render_options_rejected',
        stage: 'private_batch_admission',
        privateBatchCount: privateBatchPlan.length,
        privateBatchKinds: privateBatchPlan.map((entry) => entry?.kind).filter((value) => typeof value === 'string'),
        reason: projectWriterDiagnosticReason(error),
      }))
      throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'private-batch-admission' })
    }
    const trackInsertionCapability = override?.trackInsertionCapability
    let renderBundleFingerprint = null
    if (override?.renderBundleIdentity !== undefined && override.renderBundleIdentity !== null) {
      try {
        renderBundleFingerprint = fingerprintRenderBundleIdentity(assertRenderBundleIdentity(override.renderBundleIdentity))
      } catch {
        throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'render-bundle-identity' })
      }
    }

    return {
      draftLabel: typeof override?.draftLabel === 'string' && override.draftLabel.length > 0
        ? override.draftLabel
        : null,
      captions: typeof override?.captions === 'boolean' ? override.captions : captions,
      bgmPath: override && 'bgmPath' in override ? override.bgmPath ?? null : bgmPath,
      bgmVolume: typeof override?.bgmVolume === 'number' && Number.isFinite(override.bgmVolume)
        ? Math.max(0, Math.min(1, override.bgmVolume))
        : 0.12,
      subtitleStyle: override?.subtitleStyle === 'bottom_safe' ? 'bottom_safe' : 'default',
      titleSegments,
      keywordHighlights,
      trackInsertionProfile: typeof override?.trackInsertionProfile === 'string'
        ? override.trackInsertionProfile
        : null,
      trackInsertionCapability: trackInsertionCapability === 'track.insert' || trackInsertionCapability === 'track.insert_many'
        ? trackInsertionCapability
        : null,
      captionSegments,
      timelinePackaging,
      privateBatchPlan,
      templateBlueprint: normalizeJianyingTemplateBlueprint(override?.templateBlueprint),
      renderBundleFingerprint,
      overlayAssignments: isRecord(override?.overlayAssignments)
        ? override.overlayAssignments
        : { effects: [], stickers: [] },
    }
  }

  /** @param {ReturnType<typeof resolveRenderOptions>} render @param {Record<string, any>[]} voiceoverSegments */
  const resolveCaptionSegments = (render, voiceoverSegments) => {
    if (Array.isArray(render.captionSegments)) return render.captionSegments
    if (!render.captions) return []
    const keywordLine = render.keywordHighlights.length
      ? `【卖点】${render.keywordHighlights.join(' · ')}`
      : ''
    return voiceoverSegments.map((segment, index) => ({
      text: index === 0 && keywordLine
        ? `${segment.text}\n${keywordLine}`
        : segment.text,
      target_start_us: segment.target_range.start,
      target_duration_us: segment.target_range.duration,
    }))
  }

  /** @type {Map<string, {draftId: string, draftLabel: string, requestId: string, stagingName: string, outputFingerprint: string, renderBundleFingerprint: string | null, promoted: boolean, templateOverlay: boolean, bgmPath: string | null, bgmSize: number | null, bgmSha256: string | null, privateBatchPlan: Record<string, any>[], packagingSnapshot: {video: any[], voiceover_segments: any[], caption_segments: any[], title_segments: any[], subtitle_style: string, bgm_volume: number, sfx_segments: any[], audio_effect_segments: any[], effect_segments: any[], sticker_segments: any[], filter_segments: any[], animation_segments: any[], text_animation_segments: any[], mask_segments: any[], blend_segments: any[], chroma_segments: any[], background_segments: any[]}, isolationBefore: {entryCount: number, fingerprint: string}, isolationEvidence: null | {schema_version: 1, existing_entry_count: number, before_fingerprint: string, after_existing_fingerprint: string, created_draft_id: string}}>} */
  const writes = new Map()
  /** @type {Map<string, string>} */
  const outputOwners = new Map()
  /** @type {Promise<Record<string, any>> | null} */
  let runtimeHandshake = null

  /** @param {import('node:child_process').ChildProcess} child @returns {Promise<void>} */
  const terminateChild = (child) =>
    new Promise((resolve) => {
      if (process.platform === 'win32' && child.pid) {
        let finished = false
        const finish = () => {
          if (finished) return
          finished = true
          resolve()
        }
        const fallback = setTimeout(() => {
          child.kill('SIGKILL')
          finish()
        }, 1_000)
        const killer = spawn('taskkill.exe', ['/pid', String(child.pid), '/t', '/f'], {
          stdio: 'ignore',
          windowsHide: true,
        })
        killer.once('error', () => {
          clearTimeout(fallback)
          child.kill('SIGKILL')
          finish()
        })
        killer.once('close', () => {
          clearTimeout(fallback)
          if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL')
          finish()
        })
        return
      }
      child.kill('SIGKILL')
      resolve()
    })

  /** @param {Record<string, any>} payload @param {AbortSignal} [signal] @param {import('node:stream').Readable | null} [inputStream] */
  const runBridge = (payload, signal, inputStream = null) =>
    new Promise((resolve, reject) => {
      if (signal?.aborted) {
        reject(new JianyingDraftAdapterError('JY002_CANCELLED'))
        return
      }
      const environment = {
        ...process.env,
        PYTHONPATH:
          pythonModuleRoot === undefined
            ? process.env.PYTHONPATH
            : [pythonModuleRoot, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter),
        PYTHONDONTWRITEBYTECODE: '1',
        PYTHONIOENCODING: 'utf-8',
        PYTHONUTF8: '1',
      }
      const child = spawn(pythonExecutable, [bridgePath], {
        env: environment,
        stdio: ['pipe', 'pipe', 'pipe'],
        windowsHide: true,
      })
      /** @type {Buffer[]} */
      const stdout = []
      /** @type {Buffer[]} */
      const stderr = []
      let stderrBytes = 0
      let stdoutBytes = 0
      let settled = false
      let cancellationRequested = false
      /** @type {Promise<void> | null} */
      let termination = null
      const onAbort = () => {
        if (settled || cancellationRequested) return
        cancellationRequested = true
        termination = terminateChild(child)
      }
      signal?.addEventListener('abort', onAbort, { once: true })
      const timeout = setTimeout(() => {
        if (settled) return
        settled = true
        void terminateChild(child).finally(() => reject(new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED')))
      }, timeoutMs)
      child.stdout.on('data', (chunk) => {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
        stdoutBytes += buffer.length
        if (stdoutBytes <= maxBridgeOutputBytes) stdout.push(buffer)
      })
      child.stderr.on('data', (chunk) => {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
        stderrBytes += buffer.length
        if (stderrBytes <= 16_384) stderr.push(buffer)
      })
      child.on('error', () => {
        clearTimeout(timeout)
        signal?.removeEventListener('abort', onAbort)
        if (!settled) {
          reject(new JianyingDraftAdapterError(cancellationRequested ? 'JY002_CANCELLED' : 'JY002_DRAFT_WRITE_FAILED'))
        }
        settled = true
      })
      child.on('close', (code, terminationSignal) => {
        clearTimeout(timeout)
        signal?.removeEventListener('abort', onAbort)
        if (settled) return
        if (cancellationRequested) {
          settled = true
          void Promise.resolve(termination).finally(() => reject(new JianyingDraftAdapterError('JY002_CANCELLED')))
          return
        }
        settled = true
        if (stdoutBytes > maxBridgeOutputBytes) {
          reject(new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED'))
          return
        }
        if (code !== 0 || terminationSignal !== null) {
          const stderrText = Buffer.concat(stderr).toString('utf8')
          const exceptionMatch = stderrText.match(/(?:^|\r?\n)([A-Za-z_][A-Za-z0-9_]*(?:Error|Exception))(?::|\r?\n)/u)
          console.warn(JSON.stringify({
            event: 'jianying_writer_bridge_process_rejected',
            code: typeof code === 'number' ? code : null,
            signal: terminationSignal,
            stderrBytes,
            stderrHasTraceback: /Traceback \(most recent call last\)/u.test(stderrText),
            stderrExceptionType: exceptionMatch?.[1] ?? null,
          }))
          reject(new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED'))
          return
        }
        try {
          const response = JSON.parse(Buffer.concat(stdout).toString('utf8'))
          if (!isRecord(response) || typeof response.ok !== 'boolean') {
            reject(new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED'))
          } else if (response.ok !== true) {
            console.warn(JSON.stringify({
              event: 'jianying_writer_rejected_code',
              action: typeof payload.action === 'string' ? payload.action : null,
              code: typeof response.code === 'string' ? response.code : 'JY002_DRAFT_WRITE_FAILED',
            }))
            if (
              isRecord(response.diagnostic) &&
              typeof response.diagnostic.stage === 'string' &&
              typeof response.diagnostic.exception_type === 'string'
            ) {
              console.warn(JSON.stringify({
                event: 'jianying_writer_rejected',
                stage: response.diagnostic.stage,
                exceptionType: response.diagnostic.exception_type,
                titleRangeCount: response.diagnostic.title_range_count ?? null,
                targetStartUs: response.diagnostic.target_start_us ?? null,
                targetDurationUs: response.diagnostic.target_duration_us ?? null,
                ...(['validate_tracks', 'verify_and_promote', 'verify_final'].includes(response.diagnostic.stage)
                  ? {
                      actualDurationUs: response.diagnostic.actual_duration_us ?? null,
                      expectedDurationUs: response.diagnostic.expected_duration_us ?? null,
                      durationWithinFrame: response.diagnostic.duration_within_frame ?? null,
                      actualTracks: response.diagnostic.actual_tracks ?? null,
                      expectedCounts: response.diagnostic.expected_counts ?? null,
                      overlayTracksValid: response.diagnostic.overlay_tracks_valid ?? null,
                      overlayTrackCount: response.diagnostic.overlay_track_count ?? null,
                      overlayFailureReason: response.diagnostic.overlay_failure_reason ?? null,
                      videoFadeMaterialCount: response.diagnostic.video_fade_material_count ?? null,
                      expectedVideoFadeCount: response.diagnostic.expected_video_fade_count ?? null,
                      videoSegmentsValid: response.diagnostic.video_segments_valid ?? null,
                      videoFadesValid: response.diagnostic.video_fades_valid ?? null,
                      voiceoverSegmentsValid: response.diagnostic.voiceover_segments_valid ?? null,
                      captionSegmentsValid: response.diagnostic.caption_segments_valid ?? null,
                      bgmSegmentsValid: response.diagnostic.bgm_segments_valid ?? null,
                      bgmAssetValid: response.diagnostic.bgm_asset_valid ?? null,
                      titleSegmentsValid: response.diagnostic.title_segments_valid ?? null,
                      textAnimationsValid: response.diagnostic.text_animations_valid ?? null,
                      effectTracksValid: response.diagnostic.effect_tracks_valid ?? null,
                      effectShapeValid: response.diagnostic.effect_shape_valid ?? null,
                      effectRangeValid: response.diagnostic.effect_range_valid ?? null,
                      effectResourceValid: response.diagnostic.effect_resource_valid ?? null,
                      effectIdValid: response.diagnostic.effect_id_valid ?? null,
                      animationSegmentsValid: response.diagnostic.animation_segments_valid ?? null,
                      maskSegmentsValid: response.diagnostic.mask_segments_valid ?? null,
                      blendSegmentsValid: response.diagnostic.blend_segments_valid ?? null,
                    }
                  : {}),
              }))
            }
            reject(toAdapterError(String(response.code)))
          } else {
            resolve(response)
          }
        } catch {
          reject(new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED'))
        }
      })
      if (signal?.aborted) onAbort()
      child.stdin.write(`${JSON.stringify(payload)}\n`)
      if (inputStream) {
        void pipeline(inputStream, child.stdin).catch(() => {
          if (!settled && !cancellationRequested) void terminateChild(child)
        })
      } else {
        child.stdin.end()
      }
    })

  const ensureRuntime = async () => {
    if (runtimeHandshake) return runtimeHandshake
    if (!pythonModuleRoot) throw new JianyingDraftAdapterError('JY002_DESKTOP_VERSION_UNSUPPORTED')
    runtimeHandshake = runBridge({
      action: 'handshake',
      python_module_root: pythonModuleRoot,
      expected_upstream_commit: governedUpstreamCommit,
    }).catch((error) => {
      runtimeHandshake = null
      throw error
    })
    return runtimeHandshake
  }

  return {
    /** @param {Record<string, any>} input */
    async writeDraft(input) {
      // Validate private packaging admission before starting the Python bridge.
      // A missing resolver or forged token must fail closed without side effects.
      const render = resolveRenderOptions(input)
      const preparation = /** @type {Record<string, any>} */ (input.export_request.preparation)
      const timeline = /** @type {Record<string, any>} */ (preparation.timeline)
      const tracks = /** @type {Record<string, any>[]} */ (timeline.tracks)
      // RichTimeline permits an audio-only SFX lane without a voiceover lane.
      // Select by canonical role rather than positional index so that a SFX
      // segment is never mistaken for a required voiceover authorization.
      const videoTrack = tracks.find((track) => track?.kind === 'video' && track?.role === 'primary') ?? tracks[0]
      const voiceoverTrack = tracks.find((track) => track?.kind === 'audio' && track?.role === 'voiceover') ??
        (tracks[1]?.role === undefined && (input.voiceovers?.length > 0 || tracks[1]?.segments?.some((/** @type {Record<string, any>} */ segment) => typeof segment?.capabilityId === 'string' && segment.capabilityId.startsWith('audio.voiceover.')) || (!render.timelinePackaging?.sfx_segments?.length && tracks[1]?.segments?.length === 0)) ? tracks[1] : undefined)
      const videoSegments = /** @type {Record<string, any>[]} */ (videoTrack?.segments ?? [])
      const voiceoverSegments = /** @type {Record<string, any>[]} */ (voiceoverTrack?.segments ?? [])
      const requestId = String(input.request_id)
      const bgmLeaseForCount = typeof getBgmLease === 'function' ? getBgmLease(requestId) : null
      const packaging = /** @type {Record<string, any>} */ (render.timelinePackaging ?? {})
      // Template SFX cues may intentionally share timestamps across separate
      // audio tracks. Resolve the private blueprint once and preserve that
      // authored track grouping for the Python writer.
      let resolvedTemplateBlueprintFolder = null
      let templateSfxTrackNames = null
      let templateHasFlowerText = false
      let templateHasSubtitles = false
      if (render.templateBlueprint && typeof resolveTemplateBlueprint === 'function') {
        try {
          resolvedTemplateBlueprintFolder = await resolveTemplateBlueprint(render.templateBlueprint)
          if (typeof resolvedTemplateBlueprintFolder === 'string' && path.isAbsolute(resolvedTemplateBlueprintFolder)) {
            const blueprintContent = JSON.parse(await readFile(path.join(resolvedTemplateBlueprintFolder, 'draft_content.json'), 'utf8'))
            const templateTextTracks = inspectTemplateTextTracks(blueprintContent)
            templateHasFlowerText = templateTextTracks.hasFlowerText
            templateHasSubtitles = templateTextTracks.hasSubtitles
            const audioTracks = Array.isArray(blueprintContent?.tracks)
              ? blueprintContent.tracks.filter((/** @type {Record<string, any>} */ track) => track?.type === 'audio' && !/^(?:bgm|音乐|配乐)$/iu.test(String(track?.name ?? '').trim()))
              : []
            const authoredSfxCount = audioTracks.reduce((/** @type {number} */ total, /** @type {Record<string, any>} */ track) => total + (Array.isArray(track?.segments) ? track.segments.length : 0), 0)
            const requestedSfxCount = Array.isArray(packaging.sfx_segments) ? packaging.sfx_segments.length : 0
            if (authoredSfxCount > 0 && authoredSfxCount === requestedSfxCount) {
              templateSfxTrackNames = matchTemplateSfxTrackNames({
                sfxSegments: packaging.sfx_segments,
                audioTracks,
                targetDurationUs: timeline.duration,
                templateDurationUs: Number.isSafeInteger(blueprintContent?.duration) && blueprintContent.duration > 0
                  ? blueprintContent.duration
                  : timeline.duration,
              })
            }
          }
        } catch (error) {
          throw mapTemplateResolverError(error)
        }
      }
      const sfxSegments = Array.isArray(packaging.sfx_segments) ? packaging.sfx_segments : []
      const writerSfxSegments = sfxSegments.map((segment, index) => ({
        ...segment,
        ...(templateSfxTrackNames?.[index] ? { track_name: templateSfxTrackNames[index] } : {}),
      }))
      const sfxTrackCount = new Set(writerSfxSegments.map((segment) => segment.track_name ?? 'sfx-primary')).size
      const resolvedCaptionSegments = resolveCaptionSegments(render, voiceoverSegments)
      const pythonTitleSegments = selectPythonWriterTitleSegments(render.titleSegments)
      const pythonCaptionSegments = templateHasSubtitles ? [] : resolvedCaptionSegments
      const optionalTrackCount = [
        voiceoverSegments.length > 0,
        pythonCaptionSegments.length > 0,
        pythonTitleSegments.length > 0,
        Boolean(render.bgmPath || bgmLeaseForCount),
        sfxTrackCount > 0,
        ...(packaging.effect_segments ?? []).map(() => true),
        ...(packaging.sticker_segments ?? []).map(() => true),
        ...(packaging.filter_segments ?? [])
          .filter((/** @type {Record<string, any>} */ segment) => segment?.capability_id === 'filter.video.track_named')
          .map(() => true),
      ].filter(Boolean).length
      const requiredTrackInsertion = render.trackInsertionProfile
        ? resolveTrackInsertionCapability(optionalTrackCount, render.trackInsertionCapability ?? null)
        : null
      const packagingVoiceoverTokens = input.export_request.packaging?.voiceover_audio_tokens
      const expectedVoiceoverCount = Array.isArray(packagingVoiceoverTokens)
        ? packagingVoiceoverTokens.length
        : voiceoverSegments.length
      if (![0, voiceoverSegments.length].includes(expectedVoiceoverCount)) {
        throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'voiceover-token-count' })
      }
      const resolvedVoiceoverSegments = expectedVoiceoverCount === 0 ? [] : voiceoverSegments
      const materials = /** @type {unknown[]} */ (input.materials)
      const voiceovers = /** @type {unknown[]} */ (input.voiceovers)
      const canvas = resolveDraftCanvas(input.orientation ?? 'portrait')
      if (!canvas) throw new JianyingDraftAdapterError('JY002_TEMPLATE_CAPABILITY_UNSUPPORTED')
      if (
        materials.length !== videoSegments.length ||
        voiceovers.length !== resolvedVoiceoverSegments.length ||
        !materials.every(isPrivateResolvedPath) ||
        !voiceovers.every(isPrivateResolvedPath)
      ) {
        throw new JianyingDraftAdapterError('JY002_MATERIAL_AUTHORIZATION_EXPIRED')
      }
      await ensureRuntime()
      const privateMaterials = /** @type {{path: string}[]} */ (materials)
      const privateVoiceovers = /** @type {{path: string}[]} */ (voiceovers)
      const jobId = String(input.job_id)
      const draftId = String(input.output_policy.draft_id)
      const stagingName = draftId
      const bgmLease = bgmLeaseForCount
      const bgmStream = bgmLease
        ? { extension: bgmLease.extension, size: bgmLease.size, sha256: bgmLease.sha256 }
        : null
      const draftBgmPath = bgmStream
        ? path.join(draftRoot, draftId, '.openvideo-assets', `bgm${bgmStream.extension}`)
        : render.bgmPath
      if (outputOwners.has(draftId) || writes.has(jobId)) {
        throw new JianyingDraftAdapterError('JY002_OUTPUT_CONFLICT')
      }
      const isolationBefore = await snapshotDraftMetadata(draftRoot, new Set([stagingName, draftId]))
      try {
        const finalPath = path.join(draftRoot, draftId)
        const owner = JSON.parse(await readFile(path.join(finalPath, '.openvideo-owner.json'), 'utf8'))
        const ownerKeys = Object.keys(owner ?? {}).sort().join(',')
        const legacyOwnerKeys = ['draft_id', 'output_fingerprint', 'owner_id', 'phase', 'request_id', 'schema_version'].join(',')
        const bundleOwnerKeys = ['bundle_fingerprint', 'draft_id', 'output_fingerprint', 'owner_id', 'phase', 'request_id', 'schema_version'].join(',')
        if (
          !isRecord(owner) ||
          ![legacyOwnerKeys, bundleOwnerKeys].includes(ownerKeys) ||
          owner.schema_version !== 2 ||
          owner.owner_id !== jobId ||
          owner.request_id !== requestId ||
          owner.draft_id !== draftId ||
          !['staging', 'published', 'committed'].includes(owner.phase) ||
          typeof owner.output_fingerprint !== 'string' ||
          !/^[a-f0-9]{64}$/u.test(owner.output_fingerprint)
          || (owner.bundle_fingerprint !== undefined && !/^[a-f0-9]{64}$/u.test(owner.bundle_fingerprint))
        ) {
          throw new JianyingDraftAdapterError('JY002_OUTPUT_CONFLICT')
        }
        const existingContent = await readFile(path.join(finalPath, 'draft_content.json'))
        const outputFingerprint = createHash('sha256').update(existingContent).digest('hex')
        if (outputFingerprint !== owner.output_fingerprint) {
          throw new JianyingDraftAdapterError('JY002_OUTPUT_CONFLICT')
        }
        const idempotentRender = resolveRenderOptions(input)
        if ((owner.bundle_fingerprint ?? null) !== (idempotentRender.renderBundleFingerprint ?? null)) {
          throw new JianyingDraftAdapterError('JY002_OUTPUT_CONFLICT')
        }
        writes.set(jobId, {
          draftId,
          draftLabel: idempotentRender.draftLabel ?? draftId,
          requestId,
          stagingName,
          outputFingerprint,
          promoted: true,
          templateOverlay: false,
          bgmPath: draftBgmPath,
          bgmSize: bgmStream?.size ?? null,
          bgmSha256: bgmStream?.sha256 ?? null,
          privateBatchPlan: structuredClone(idempotentRender.privateBatchPlan),
          renderBundleFingerprint: idempotentRender.renderBundleFingerprint,
          packagingSnapshot: {
            video: structuredClone(idempotentRender.timelinePackaging?.video ?? []),
            voiceover_segments: structuredClone(resolvedVoiceoverSegments),
            caption_segments: structuredClone(resolveCaptionSegments(idempotentRender, voiceoverSegments)),
            title_segments: structuredClone(idempotentRender.titleSegments),
            subtitle_style: idempotentRender.subtitleStyle,
            bgm_volume: idempotentRender.bgmVolume,
            sfx_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.sfx_segments)
                ? idempotentRender.timelinePackaging.sfx_segments
                : [],
            ),
            audio_effect_segments: structuredClone(idempotentRender.timelinePackaging?.audio_effect_segments ?? []),
            effect_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.effect_segments)
                ? idempotentRender.timelinePackaging.effect_segments
                : [],
            ),
            sticker_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.sticker_segments)
                ? idempotentRender.timelinePackaging.sticker_segments
                : [],
            ),
            filter_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.filter_segments)
                ? idempotentRender.timelinePackaging.filter_segments
                : [],
            ),
            animation_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.animation_segments)
                ? idempotentRender.timelinePackaging.animation_segments
                : [],
            ),
            text_animation_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.text_animation_segments)
                ? idempotentRender.timelinePackaging.text_animation_segments
                : [],
            ),
            mask_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.mask_segments)
                ? idempotentRender.timelinePackaging.mask_segments
                : [],
            ),
            blend_segments: structuredClone(
              Array.isArray(idempotentRender.timelinePackaging?.blend_segments)
                ? idempotentRender.timelinePackaging.blend_segments
                : [],
            ),
            chroma_segments: structuredClone(idempotentRender.timelinePackaging?.chroma_segments ?? []),
            background_segments: structuredClone(idempotentRender.timelinePackaging?.background_segments ?? []),
          },
          isolationBefore,
          isolationEvidence: null,
        })
        outputOwners.set(draftId, jobId)
        return {
          draft_id: draftId,
          output_fingerprint: outputFingerprint,
        }
      } catch (error) {
        if (/** @type {NodeJS.ErrnoException} */ (error).code !== 'ENOENT') {
          throw new JianyingDraftAdapterError('JY002_OUTPUT_CONFLICT')
        }
      }
      outputOwners.set(draftId, jobId)
      const packagingVideo = Array.isArray(render.timelinePackaging?.video)
        ? render.timelinePackaging.video
        : []
      if (
        packagingVideo.length > 0 &&
        packagingVideo.length !== videoSegments.length
      ) {
        throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'video-packaging-count' })
      }
      const packagingVoiceover = Array.isArray(render.timelinePackaging?.voiceover_segments)
        ? render.timelinePackaging.voiceover_segments
        : []
      if (
        packagingVoiceover.length !== 0 &&
        packagingVoiceover.length !== resolvedVoiceoverSegments.length
      ) {
        throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'voiceover-packaging-count' })
      }
      if (
        packagingVoiceover.length > 0 &&
        packagingVoiceover.some((fade, index) =>
          typeof fade?.segment_id !== 'string' ||
          fade.segment_id !== resolvedVoiceoverSegments[index]?.segment_id)
      ) {
        throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'voiceover-packaging-binding' })
      }
      const voiceoverFadeBySegmentId = new Map(
        packagingVoiceover.map((fade) => [fade.segment_id, fade]),
      )
      const effectSegments = Array.isArray(render.timelinePackaging?.effect_segments)
        ? render.timelinePackaging.effect_segments
        : []
      const stickerSegments = Array.isArray(render.timelinePackaging?.sticker_segments)
        ? render.timelinePackaging.sticker_segments
        : []
      const filterSegments = Array.isArray(render.timelinePackaging?.filter_segments)
        ? render.timelinePackaging.filter_segments
        : []
      const animationSegments = Array.isArray(render.timelinePackaging?.animation_segments)
        ? render.timelinePackaging.animation_segments
        : []
      const maskSegments = Array.isArray(render.timelinePackaging?.mask_segments)
        ? render.timelinePackaging.mask_segments
        : []
      const blendSegments = Array.isArray(render.timelinePackaging?.blend_segments)
        ? render.timelinePackaging.blend_segments
        : []
      const privateBatchPlan = render.privateBatchPlan
      const backgroundSegments = Array.isArray(render.timelinePackaging?.background_segments)
        ? render.timelinePackaging.background_segments
        : []
      const chromaSegments = Array.isArray(render.timelinePackaging?.chroma_segments)
        ? render.timelinePackaging.chroma_segments
        : []
      const textAnimationSegments = Array.isArray(render.timelinePackaging?.text_animation_segments)
        ? render.timelinePackaging.text_animation_segments
        : []
      let finalTitleSegments = pythonTitleSegments
      let finalTextAnimationSegments = textAnimationSegments
      if (textAnimationSegments.length > 0) {
        const titleRanges = render.titleSegments.map((segment) => `${segment.target_start_us}:${segment.target_duration_us}`)
        if (new Set(titleRanges).size !== titleRanges.length) {
          throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'text-animation-target-binding' })
        }
        const titleIds = new Set(render.titleSegments.map((segment) => segment.segment_id))
        if (textAnimationSegments.some((segment) => !titleIds.has(segment.target_segment_id))) {
          throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'text-animation-target-binding' })
        }
      }
      const captionSegments = pythonCaptionSegments
      const payload = {
        action: 'write',
        draft_root: draftRoot,
        staging_name: stagingName,
        draft_id: draftId,
        draft_label: render.draftLabel ?? draftId,
        owner_id: jobId,
        request_id: requestId,
        width: canvas.width,
        height: canvas.height,
        fps: 30,
        duration_us: timeline.duration,
        video_segments: videoSegments.map((segment, index) => {
          const speed = packagingVideo[index]?.speed ?? segment.speed ?? { numerator: 1, denominator: 1 }
          return {
            path: privateMaterials[index].path,
            source_start_us: segment.source_range.start,
            source_duration_us: segment.source_range.duration,
            target_start_us: segment.target_range.start,
            target_duration_us: segment.target_range.duration,
            ...(speed.numerator === speed.denominator ? {} : { speed }),
            fade_in_us: packagingVideo[index]?.fade_in_us ?? 0,
            fade_out_us: packagingVideo[index]?.fade_out_us ?? 0,
            transition_out: packagingVideo[index]?.transition_out ?? null,
            keyframes: packagingVideo[index]?.keyframes ?? [],
          }
        }),
        voiceover_segments: resolvedVoiceoverSegments.map((segment, index) => ({
          path: privateVoiceovers[index].path,
          target_start_us: segment.target_range.start,
          target_duration_us: segment.target_range.duration,
          fade_in_us: voiceoverFadeBySegmentId.get(segment.segment_id)?.fade_in_us ?? 0,
          fade_out_us: voiceoverFadeBySegmentId.get(segment.segment_id)?.fade_out_us ?? 0,
          keyframes: voiceoverFadeBySegmentId.get(segment.segment_id)?.keyframes ?? [],
        })),
        caption_segments: captionSegments,
        title_segments: pythonTitleSegments,
        subtitle_style: render.subtitleStyle,
        bgm_path: render.bgmPath,
        bgm_stream: bgmStream,
        bgm_volume: render.bgmVolume,
        bgm_fade: render.timelinePackaging?.bgm ?? { fade_in_us: 0, fade_out_us: 0 },
        sfx_segments: writerSfxSegments,
        // Keep one track name per cue. The Python writer uses this positional
        // mapping when placing each SFX segment; it derives the unique track
        // specs separately.
        sfx_track_names: writerSfxSegments.map((segment) => segment.track_name ?? 'sfx-primary'),
        audio_effect_segments: render.timelinePackaging?.audio_effect_segments ?? [],
        effect_segments: effectSegments,
        sticker_segments: stickerSegments,
        filter_segments: filterSegments,
        animation_segments: animationSegments,
        mask_segments: maskSegments,
        blend_segments: blendSegments,
        chroma_segments: chromaSegments,
        text_animation_segments: templateHasFlowerText
          ? textAnimationSegments.filter((segment) =>
            pythonTitleSegments.some((title) => title?.segment_id === segment?.target_segment_id))
          : textAnimationSegments,
        background_segments: backgroundSegments,
        private_batch_plan: privateBatchPlan.map((entry) => ({
          packaging_token: entry.packagingToken,
          placement_id: entry.placementId,
          kind: entry.kind,
          resource_id: entry.privateBinding?.resourceId,
          ...(entry.kind === 'effect' && typeof entry.privateBinding?.effectId === 'string'
            ? { effect_id: entry.privateBinding.effectId }
            : {}),
          binding_fingerprint: entry.bindingFingerprint,
          target_start_us: entry.targetStartUs,
          target_duration_us: entry.targetDurationUs,
          ...(entry.kind === 'animation' ? { duration_us: entry.privateBinding?.durationUs } : {}),
        })),
        track_insertion_profile: render.trackInsertionProfile,
        track_insertion_capability: requiredTrackInsertion,
        ...(render.renderBundleFingerprint ? { bundle_fingerprint: render.renderBundleFingerprint } : {}),
      }
      let response
      let templateOverlayApplied = false
      try {
        response = /** @type {Record<string, any>} */ (await runBridge(
          payload,
          input.signal,
          bgmLease?.createStream() ?? null,
        ))
          if (render.templateBlueprint) {
          if (typeof resolveTemplateBlueprint !== 'function') {
            throw new JianyingDraftAdapterError('JY002_TEMPLATE_CAPABILITY_UNSUPPORTED')
          }
          let blueprintFolder
            try {
              blueprintFolder = resolvedTemplateBlueprintFolder ?? await resolveTemplateBlueprint(render.templateBlueprint)
          } catch (error) {
            throw mapTemplateResolverError(error)
          }
          if (typeof blueprintFolder !== 'string' || !path.isAbsolute(blueprintFolder)) {
            throw new JianyingDraftAdapterError('JY002_TEMPLATE_CAPABILITY_UNSUPPORTED')
          }
          let overlay
          const titleTextReplacements = render.titleSegments.map((segment) => ({
              text: segment.text,
              slot: /** @type {'rich' | 'title'} */ (segment.rich === false ? 'title' : 'rich'),
              ...(typeof segment.template_slot_id === 'string' ? { slotId: segment.template_slot_id } : {}),
              ...(Number.isSafeInteger(segment.target_start_us) ? { targetStartUs: segment.target_start_us } : {}),
              ...(Number.isSafeInteger(segment.target_duration_us) ? { targetDurationUs: segment.target_duration_us } : {}),
            }))
          const titleRichTexts = new Set(titleTextReplacements
            .filter((replacement) => replacement.slot === 'rich')
            .map((replacement) => replacement.text.trim()))
          const keywordTextReplacements = templateHasFlowerText
            ? render.keywordHighlights
              .filter((text) => !titleRichTexts.has(text.trim()))
              .map((text) => ({ text, slot: /** @type {'rich'} */ ('rich') }))
            : []
          const videoRanges = videoSegments
            .map((segment) => toPackagingVideoRange(segment))
            .filter(Boolean)
          const textReplacements = selectMatchedRichTextReplacements([
            ...titleTextReplacements,
            ...keywordTextReplacements,
            ...(templateHasSubtitles
              ? resolvedCaptionSegments
                .filter((segment) => typeof segment?.text === 'string' && segment.text.trim())
                .map((segment) => ({
                  text: segment.text,
                  slot: /** @type {'caption'} */ ('caption'),
                  ...(Number.isSafeInteger(segment.target_start_us) ? { targetStartUs: segment.target_start_us } : {}),
                  ...(Number.isSafeInteger(segment.target_duration_us) ? { targetDurationUs: segment.target_duration_us } : {}),
                }))
              : []),
          ], videoRanges, {
            projectDurationUs: Number.isSafeInteger(timeline?.duration) ? timeline.duration : undefined,
          })
          const overlayAssignments = isRecord(render.overlayAssignments) ? render.overlayAssignments : {}
          const effectAssignments = Array.isArray(overlayAssignments.effects) ? overlayAssignments.effects : []
          const stickerAssignments = (Array.isArray(overlayAssignments.stickers) ? overlayAssignments.stickers : [])
            .map((assignment) => {
              if (!isRecord(assignment)) return null
              if (Number.isSafeInteger(assignment.targetStartUs) && Number.isSafeInteger(assignment.targetDurationUs)) {
                return assignment
              }
              const range = Number.isSafeInteger(assignment.shotIndex) ? videoRanges[assignment.shotIndex] : null
              if (!range) return null
              return {
                ...assignment,
                targetStartUs: range.start,
                targetDurationUs: range.duration,
              }
            })
            .filter(Boolean)
          try {
            overlay = await overlayJianyingTemplatePackaging({
              blueprintFolder,
              draftFolder: path.join(draftRoot, '.openvideo-staging', stagingName),
              targetDurationUs: timeline.duration,
              effectAssignments,
              stickerAssignments,
              // Keep legacy title replacement positional for existing blueprints,
              // then bind user-selected highlights only to dynamic FlowerText
              // tracks. Static template copy must never be overwritten merely
              // because a project has keyword highlights.
              textReplacements,
              // Every generated rich-text segment must use a real authored
              // FlowerText slot. The source draft may expose fewer style
              // slots than the current script, so cycle the immutable source
              // material instead of falling back to a plain white title.
              reuseOverflowRichText: true,
            })
          } catch (error) {
            console.warn(JSON.stringify({
              event: 'jianying_writer_template_overlay_rejected',
              exceptionType: error instanceof Error ? error.constructor.name : typeof error,
              code: error instanceof Error && typeof error.code === 'string'
                ? error.code
                : error instanceof Error && /^JY_TEMPLATE_[A-Z0-9_]+$/u.test(error.message)
                  ? error.message
                  : 'JY_TEMPLATE_CLONE_FAILED',
              message: error instanceof Error ? error.message : String(error),
              materialId: error instanceof Error && typeof error.materialId === 'string' ? error.materialId : null,
              overlayStage: error instanceof Error && typeof error.stage === 'string' ? error.stage : null,
              templateHasFlowerText,
              richReplacementCount: textReplacements.filter((replacement) => replacement.slot === 'rich').length,
              captionReplacementCount: textReplacements.filter((replacement) => replacement.slot === 'caption').length,
            }))
            throw mapTemplateOverlayError(error)
          }
          const hasValidOverlayCounts =
            Number.isSafeInteger(overlay?.trackCount) &&
            overlay.trackCount >= 0 &&
            Number.isSafeInteger(overlay?.materialCount) &&
            overlay.materialCount >= 0
          if (!hasValidOverlayCounts || ((overlay.trackCount === 0) !== (overlay.materialCount === 0))) {
            throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-overlay-counts' })
          }
          templateOverlayApplied = overlay.trackCount > 0 && overlay.materialCount > 0
          if (overlay.danglingReferenceCount > 0) {
            console.warn(JSON.stringify({
              event: 'jianying_writer_template_dangling_references_removed',
              count: overlay.danglingReferenceCount,
            }))
          }
          const templateBackedRichIndexes = new Set(
            Array.isArray(overlay.richReplacementIndexes)
              ? overlay.richReplacementIndexes.filter((index) =>
                Number.isSafeInteger(index) && index >= 0 && index < render.titleSegments.length)
              : [],
          )
          if (templateHasFlowerText) {
            const overlayRichIds = new Set(render.titleSegments
              .filter((segment) => segment?.rich !== false)
              .map((segment) => segment?.segment_id)
              .filter((value) => typeof value === 'string'))
            finalTitleSegments = selectVerifiedWriterTitleSegments({
              pythonTitleSegments,
              allTitleSegments: render.titleSegments,
              templateHasFlowerText,
              templateBackedRichIndexes,
            })
            finalTextAnimationSegments = textAnimationSegments.filter((segment) =>
              !overlayRichIds.has(segment?.target_segment_id))
          } else if (templateBackedRichIndexes.size > 0) {
            const deduplicatedFingerprint = await removeTemplateBackedRichTitleSegments({
              draftFolder: path.join(draftRoot, '.openvideo-staging', stagingName),
              titleSegments: render.titleSegments,
              removedIndexes: templateBackedRichIndexes,
            })
            if (typeof deduplicatedFingerprint !== 'string') {
              throw Object.assign(new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID'), { stage: 'template-rich-deduplication' })
            }
            overlay.outputFingerprint = deduplicatedFingerprint
            const templateBackedRichIds = new Set(render.titleSegments
              .filter((_segment, index) => templateBackedRichIndexes.has(index))
              .map((segment) => segment?.segment_id)
              .filter((value) => typeof value === 'string'))
            finalTitleSegments = selectVerifiedWriterTitleSegments({
              pythonTitleSegments,
              allTitleSegments: render.titleSegments,
              templateHasFlowerText,
              templateBackedRichIndexes,
            })
            finalTextAnimationSegments = textAnimationSegments.filter((segment) =>
              !templateBackedRichIds.has(segment?.target_segment_id))
          } else {
            finalTitleSegments = selectVerifiedWriterTitleSegments({
              pythonTitleSegments,
              allTitleSegments: render.titleSegments,
              templateHasFlowerText,
              templateBackedRichIndexes,
            })
          }
          // Promotion is only valid when the private template entities made it
          // into the draft itself. A non-empty overlay response alone can be
          // stale or metadata-only, so read the staged JSON back before the
          // writer reports success.
          await verifyTemplateOverlayReadback({
            draftFolder: path.join(draftRoot, '.openvideo-staging', stagingName),
            expectedRichCount: textReplacements.filter((replacement) => replacement.slot === 'rich').length,
            expectedRichReplacementCount: Array.isArray(overlay.richReplacementIndexes)
              ? overlay.richReplacementIndexes.length
              : 0,
            expectedCaptionCount: templateHasSubtitles ? resolvedCaptionSegments.length : 0,
          })
          const ownerPath = path.join(draftRoot, '.openvideo-staging', stagingName, '.openvideo-owner.json')
          const owner = JSON.parse(await readFile(ownerPath, 'utf8'))
          owner.output_fingerprint = overlay.outputFingerprint
          await writeFile(ownerPath, JSON.stringify(owner), 'utf8')
          response.output_fingerprint = overlay.outputFingerprint
          response.template_overlay = {
            track_count: overlay.trackCount,
            material_count: overlay.materialCount,
          }
        }
      } catch (error) {
        let cleanupFailed = false
        try {
          await runBridge({
            action: 'cleanup',
            draft_root: draftRoot,
            staging_name: stagingName,
            final_name: null,
            output_fingerprint: null,
            owner_id: jobId,
            request_id: requestId,
            draft_id: draftId,
          })
        } catch {
          cleanupFailed = true
        }
        outputOwners.delete(draftId)
        if (cleanupFailed) throw new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED')
        throw error
      }
      if (
        typeof response.output_fingerprint !== 'string' ||
        !/^[a-f0-9]{64}$/u.test(response.output_fingerprint) ||
        response.bgm_path !== draftBgmPath ||
        response.bgm_size !== (bgmStream?.size ?? null) ||
        response.bgm_sha256 !== (bgmStream?.sha256 ?? null)
      ) {
        try {
          await runBridge({
            action: 'cleanup',
            draft_root: draftRoot,
            staging_name: stagingName,
            final_name: null,
            output_fingerprint: null,
            owner_id: jobId,
            request_id: requestId,
            draft_id: draftId,
          })
        } catch {
          // Keep the stable writer failure when cleanup also fails.
        }
        outputOwners.delete(draftId)
        throw new JianyingDraftAdapterError('JY002_DRAFT_WRITE_FAILED')
      }
      const writtenEffects = Array.isArray(response.effect_segments)
        ? response.effect_segments
        : effectSegments
      const writtenStickers = Array.isArray(response.sticker_segments)
        ? response.sticker_segments
        : stickerSegments
      const privateBatchReadback = response.private_batch_readback ?? []
      if (!verifyPrivateBatchDraftReadback(privateBatchReadback, privateBatchPlan)) {
        console.warn(JSON.stringify({
          event: 'jianying_writer_verify_rejected',
          stage: 'write_private_batch_readback',
          expectedPrivateBatchCount: privateBatchPlan.length,
          actualPrivateBatchCount: Array.isArray(privateBatchReadback) ? privateBatchReadback.length : null,
        }))
        try {
          await runBridge({
            action: 'cleanup', draft_root: draftRoot, staging_name: stagingName, final_name: null,
            output_fingerprint: null, owner_id: jobId, request_id: requestId, draft_id: draftId,
          })
        } catch {
          // Preserve the controlled writer failure if private cleanup also fails.
        }
        outputOwners.delete(draftId)
        throw new JianyingDraftAdapterError('JY002_DRAFT_STRUCTURE_INVALID')
      }
      writes.set(jobId, {
        draftId,
        draftLabel: render.draftLabel ?? draftId,
        requestId,
        stagingName,
        outputFingerprint: response.output_fingerprint,
        renderBundleFingerprint: render.renderBundleFingerprint,
        promoted: false,
        templateOverlay: templateOverlayApplied,
        bgmPath: draftBgmPath,
        bgmSize: bgmStream?.size ?? null,
        bgmSha256: bgmStream?.sha256 ?? null,
        privateBatchPlan: structuredClone(privateBatchPlan),
        packagingSnapshot: {
          video: structuredClone(packagingVideo),
          voiceover_segments: structuredClone(resolvedVoiceoverSegments),
          caption_segments: structuredClone(captionSegments),
          title_segments: structuredClone(finalTitleSegments),
          subtitle_style: render.subtitleStyle,
          bgm_volume: render.bgmVolume,
            sfx_segments: structuredClone(writerSfxSegments),
          audio_effect_segments: structuredClone(render.timelinePackaging?.audio_effect_segments ?? []),
          effect_segments: structuredClone(writtenEffects),
          sticker_segments: structuredClone(writtenStickers),
          filter_segments: structuredClone(filterSegments),
          animation_segments: structuredClone(animationSegments),
          text_animation_segments: structuredClone(finalTextAnimationSegments),
          mask_segments: structuredClone(maskSegments),
          blend_segments: structuredClone(blendSegments),
          chroma_segments: structuredClone(chromaSegments),
          background_segments: structuredClone(backgroundSegments),
        },
        isolationBefore,
        isolationEvidence: null,
      })
      return {
        draft_id: draftId,
        output_fingerprint: response.output_fingerprint,
      }
    },
    /** @param {Record<string, any>} input */
    async verifyDraft(input) {
      const record = writes.get(String(input.job_id))
      if (!record || record.outputFingerprint !== input.write_result.output_fingerprint) {
        console.warn(JSON.stringify({ event: 'jianying_writer_verify_rejected', stage: 'record_fingerprint' }))
        return false
      }
      await ensureRuntime()
      const preparation = /** @type {Record<string, any>} */ (input.request.export_request.preparation)
      const timeline = /** @type {Record<string, any>} */ (preparation.timeline)
      const tracks = /** @type {Record<string, any>[]} */ (timeline.tracks)
      const packaging = record.packagingSnapshot
      const videoTrack = tracks.find((track) => track?.kind === 'video' && track?.role === 'primary') ?? tracks[0]
      const voiceoverTrack = tracks.find((track) => track?.kind === 'audio' && track?.role === 'voiceover') ??
        (tracks[1]?.role === undefined && (
          input.request.voiceover_bindings?.length > 0 ||
          packaging.voiceover_segments?.length > 0 ||
          tracks[1]?.segments?.some((/** @type {Record<string, any>} */ segment) =>
            typeof segment?.capabilityId === 'string' && segment.capabilityId.startsWith('audio.voiceover.')) ||
          (!packaging.sfx_segments?.length && tracks[1]?.segments?.length === 0)
        ) ? tracks[1] : undefined)
      const videoSegments = /** @type {Record<string, any>[]} */ (videoTrack?.segments ?? [])
      let voiceoverSegments = /** @type {Record<string, any>[]} */ (voiceoverTrack?.segments ?? [])
      // The canonical request can omit the role metadata after editor
      // finalization even though writeDraft resolved and wrote voiceover
      // bindings. Reuse that exact write snapshot for verification; do not
      // infer or relax the expected count.
      if (voiceoverSegments.length === 0 && Array.isArray(packaging.voiceover_segments) && packaging.voiceover_segments.length > 0) {
        voiceoverSegments = structuredClone(packaging.voiceover_segments)
      }
      const packagingVoiceoverTokens = input.request.export_request.packaging?.voiceover_audio_tokens
      const expectedVoiceoverCount = Array.isArray(packagingVoiceoverTokens)
        ? packagingVoiceoverTokens.length
        : voiceoverSegments.length
      if (![0, voiceoverSegments.length].includes(expectedVoiceoverCount)) {
        console.warn(JSON.stringify({ event: 'jianying_writer_verify_rejected', stage: 'voiceover_count', expectedVoiceoverCount, actualVoiceoverCount: voiceoverSegments.length }))
        return false
      }
      const resolvedVoiceoverSegments = expectedVoiceoverCount === 0 ? [] : voiceoverSegments
      const verifyResponse = await runBridge({
        action: record.promoted ? 'verify_final' : 'verify',
        draft_root: draftRoot,
        ...(record.promoted ? {} : { staging_name: record.stagingName }),
        draft_id: record.draftId,
        owner_id: String(input.job_id),
        request_id: record.requestId,
        output_fingerprint: record.outputFingerprint,
        ...(record.renderBundleFingerprint ? { bundle_fingerprint: record.renderBundleFingerprint } : {}),
        duration_us: timeline.duration,
        video_segments: videoSegments.map((segment, index) => {
          const packaged = packaging.video?.[index]
          const speed = packaged?.speed ?? segment.speed ?? { numerator: 1, denominator: 1 }
          return {
            source_start_us: segment.source_range.start,
            source_duration_us: segment.source_range.duration,
            target_start_us: segment.target_range.start,
            target_duration_us: segment.target_range.duration,
            ...(speed.numerator === speed.denominator ? {} : { speed }),
            fade_in_us: packaged?.fade_in_us ?? 0,
            fade_out_us: packaged?.fade_out_us ?? 0,
          }
        }),
        voiceover_segments: resolvedVoiceoverSegments.map((segment) => ({
          target_start_us: segment.target_range.start,
          target_duration_us: segment.target_range.duration,
        })),
        caption_segments: packaging.caption_segments,
        title_segments: packaging.title_segments,
        subtitle_style: packaging.subtitle_style,
        bgm_path: record.bgmPath,
        bgm_size: record.bgmSize,
        bgm_sha256: record.bgmSha256,
        bgm_volume: packaging.bgm_volume,
        sfx_segments: packaging.sfx_segments,
        sfx_track_names: (packaging.sfx_segments ?? []).map((segment) => segment.track_name ?? 'sfx-primary'),
        audio_effect_segments: packaging.audio_effect_segments ?? [],
        effect_segments: packaging.effect_segments,
        sticker_segments: packaging.sticker_segments,
        filter_segments: packaging.filter_segments,
        animation_segments: packaging.animation_segments ?? [],
        text_animation_segments: packaging.text_animation_segments ?? [],
        mask_segments: packaging.mask_segments ?? [],
        blend_segments: packaging.blend_segments ?? [],
        chroma_segments: packaging.chroma_segments ?? [],
        background_segments: packaging.background_segments ?? [],
        private_batch_plan: record.privateBatchPlan.map((entry) => ({
          packaging_token: entry.packagingToken,
          placement_id: entry.placementId,
          kind: entry.kind,
          resource_id: entry.privateBinding?.resourceId,
          ...(entry.kind === 'effect' && typeof entry.privateBinding?.effectId === 'string'
            ? { effect_id: entry.privateBinding.effectId }
            : {}),
          binding_fingerprint: entry.bindingFingerprint,
          target_start_us: entry.targetStartUs,
          target_duration_us: entry.targetDurationUs,
          ...(entry.kind === 'animation' ? { duration_us: entry.privateBinding?.durationUs } : {}),
        })),
        effect_segments_resolved: true,
        allow_overlay_tracks: record.templateOverlay,
      })
      const privateBatchValid = verifyPrivateBatchDraftReadback(
        verifyResponse?.private_batch_readback ?? [],
        record.privateBatchPlan,
      )
      if (verifyResponse?.ok !== true || !privateBatchValid) {
        console.warn(JSON.stringify({
          event: 'jianying_writer_verify_rejected',
          stage: verifyResponse?.ok === true ? 'private_batch_readback' : 'bridge_verify',
          expectedPrivateBatchCount: record.privateBatchPlan.length,
          actualPrivateBatchCount: Array.isArray(verifyResponse?.private_batch_readback)
            ? verifyResponse.private_batch_readback.length
            : null,
        }))
        return false
      }
      record.promoted = true
      const isolationAfter = await snapshotDraftMetadata(
        draftRoot,
        new Set([record.stagingName, record.draftId]),
      )
      record.isolationEvidence = {
        schema_version: 1,
        existing_entry_count: record.isolationBefore.entryCount,
        before_fingerprint: record.isolationBefore.fingerprint,
        after_existing_fingerprint: isolationAfter.fingerprint,
        created_draft_id: record.draftId,
      }
      return true
    },
    /** @param {{job_id: string}} input */
    getIsolationEvidence(input) {
      const evidence = writes.get(String(input.job_id))?.isolationEvidence
      return evidence ? structuredClone(evidence) : null
    },
    /** @param {Record<string, any>} input */
    async cleanupDraft(input) {
      const jobId = String(input.job_id)
      const record = writes.get(jobId)
      if (!record) return
      await ensureRuntime()
      await runBridge({
        action: 'cleanup',
        draft_root: draftRoot,
        staging_name: record.stagingName,
        final_name: record.promoted ? record.draftId : null,
        output_fingerprint: record.outputFingerprint,
        owner_id: jobId,
        request_id: record.requestId,
        draft_id: record.draftId,
      }, input.signal)
      writes.delete(jobId)
      if (outputOwners.get(record.draftId) === jobId) outputOwners.delete(record.draftId)
    },
    /** @param {Record<string, any>} input */
    async releaseDraft(input) {
      const jobId = String(input.job_id)
      const record = writes.get(jobId)
      if (!record) return false
      await ensureRuntime()
      await runBridge({
        action: 'commit_owned',
        draft_root: draftRoot,
        request_id: record.requestId,
        draft_id: record.draftId,
        draft_label: record.draftLabel,
      })
      writes.delete(jobId)
      if (record && outputOwners.get(record.draftId) === jobId) outputOwners.delete(record.draftId)
      return true
    },
    /** @param {{requestId: string, draftId: string}} input */
    async cleanupOwnedDraft(input) {
      await ensureRuntime()
      const result = await runBridge({
        action: 'cleanup_owned',
        draft_root: draftRoot,
        request_id: input.requestId,
        draft_id: input.draftId,
      })
      return result.committed !== true
    },
    /** @param {{requestId: string, draftId: string}} input */
    async releaseOwnedDraft(input) {
      await ensureRuntime()
      const result = await runBridge({
        action: 'commit_owned',
        draft_root: draftRoot,
        request_id: input.requestId,
        draft_id: input.draftId,
      })
      return result.committed === true
    },
  }
}
