import { readFile } from 'node:fs/promises'

import {
  fingerprintCreativeKnowledgeSnapshot,
  isCreativeKnowledgeManifest,
  isCreativeKnowledgeSnapshot,
} from './creative-knowledge-contracts.mjs'

const defaultSnapshotUrl = new URL('../../../config/creative-knowledge/shotcraft-v1.json', import.meta.url)
const defaultManifestUrl = new URL('../../../config/creative-knowledge/shotcraft-v1.manifest.json', import.meta.url)
const defaultV2SnapshotUrl = new URL('../../../config/creative-knowledge/shotcraft-v2.json', import.meta.url)
const defaultV2ManifestUrl = new URL('../../../config/creative-knowledge/shotcraft-v2.manifest.json', import.meta.url)
const maxSnapshotBytes = 2 * 1024 * 1024
const maxManifestBytes = 512 * 1024

export class CreativeKnowledgeLoadError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'CreativeKnowledgeLoadError'
    this.code = code
  }
}

/** @param {string} code @returns {never} */
const fail = (code) => {
  throw new CreativeKnowledgeLoadError(code)
}

/**
 * @param {URL|string} source
 * @param {number} maximumBytes
 * @param {string} code
 * @returns {Promise<any>}
 */
const readBoundedJson = async (source, maximumBytes, code) => {
  let text
  try {
    text = await readFile(source, 'utf8')
  } catch {
    fail(code)
  }
  if (Buffer.byteLength(text, 'utf8') > maximumBytes) fail(code)
  try {
    return JSON.parse(text)
  } catch {
    fail(code)
  }
}

/** @param {Record<string, any>} left @param {Record<string, any>} right */
const sameSource = (left, right) =>
  left.repository === right.repository &&
  left.commit === right.commit &&
  left.license === right.license &&
  left.license_sha256 === right.license_sha256

/** @template T @param {T} value @returns {T} */
const deepFreeze = (value) => {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value
  for (const child of Object.values(/** @type {object} */ (value))) deepFreeze(child)
  return Object.freeze(value)
}

/**
 * Loads only the release snapshot. Source Markdown and upstream media are never
 * read by the production runtime.
 * @param {{release?: 'v1'|'v2', snapshotSource?: URL|string, manifestSource?: URL|string}} [options]
 */
export const loadCreativeKnowledge = async ({
  release = 'v1',
  snapshotSource = release === 'v2' ? defaultV2SnapshotUrl : defaultSnapshotUrl,
  manifestSource = release === 'v2' ? defaultV2ManifestUrl : defaultManifestUrl,
} = {}) => {
  if (!['v1', 'v2'].includes(release)) fail('CREATIVE_KNOWLEDGE_RELEASE_INVALID')
  const [snapshot, manifest] = await Promise.all([
    readBoundedJson(snapshotSource, maxSnapshotBytes, 'CREATIVE_KNOWLEDGE_SNAPSHOT_UNAVAILABLE'),
    readBoundedJson(manifestSource, maxManifestBytes, 'CREATIVE_KNOWLEDGE_MANIFEST_UNAVAILABLE'),
  ])
  if (!isCreativeKnowledgeSnapshot(snapshot)) fail('CREATIVE_KNOWLEDGE_SNAPSHOT_INVALID')
  if (!isCreativeKnowledgeManifest(manifest)) fail('CREATIVE_KNOWLEDGE_MANIFEST_INVALID')
  const fingerprint = fingerprintCreativeKnowledgeSnapshot(snapshot)
  if (snapshot.snapshot_fingerprint !== fingerprint || manifest.snapshot_fingerprint !== fingerprint) {
    fail('CREATIVE_KNOWLEDGE_FINGERPRINT_MISMATCH')
  }
  if (!sameSource(snapshot.source, manifest.source) || snapshot.normalizer_version !== manifest.normalizer.version) {
    fail('CREATIVE_KNOWLEDGE_IDENTITY_MISMATCH')
  }
  if ((release === 'v1' && snapshot.schema_version !== 1) || (release === 'v2' && snapshot.schema_version !== 2)) {
    fail('CREATIVE_KNOWLEDGE_IDENTITY_MISMATCH')
  }
  if (!snapshot.recipes.every((/** @type {Record<string, any>} */ recipe) =>
    recipe.sourceRepository === snapshot.source.repository &&
    recipe.sourceCommit === snapshot.source.commit &&
    recipe.license === snapshot.source.license)) {
    fail('CREATIVE_KNOWLEDGE_RECIPE_SOURCE_MISMATCH')
  }
  const recipeCards = snapshot.recipes.map((/** @type {Record<string, any>} */ recipe) => recipe.sourceCard).sort()
  const manifestCards = manifest.files.map((/** @type {Record<string, any>} */ entry) => entry.path).sort()
  const techniqueCards = snapshot.schema_version === 2
    ? manifest.technique_sources.map((/** @type {Record<string, any>} */ entry) => entry.path)
    : []
  const expectedCards = [...recipeCards, ...techniqueCards].sort()
  if (expectedCards.length !== manifestCards.length || expectedCards.some((/** @type {string} */ card, /** @type {number} */ index) => card !== manifestCards[index])) {
    fail('CREATIVE_KNOWLEDGE_FILESET_MISMATCH')
  }
  if (snapshot.schema_version === 2) {
    const rulesById = new Map(snapshot.technique_rules.map((/** @type {Record<string, any>} */ rule) => [rule.ruleId, rule]))
    if (!manifest.technique_sources.every((/** @type {Record<string, any>} */ source) =>
      source.rule_ids.every((/** @type {string} */ id) => rulesById.get(id)?.sourceCard === source.path))) {
      fail('CREATIVE_KNOWLEDGE_TECHNIQUE_SOURCE_MISMATCH')
    }
  }
  return deepFreeze({
    snapshot,
    manifest,
    summary: {
      schemaVersion: snapshot.schema_version,
      recipeCount: snapshot.recipes.length,
      techniqueRuleCount: snapshot.technique_rules?.length ?? 0,
      techniqueSourceCount: manifest.technique_sources?.length ?? 0,
      skippedCount: manifest.skipped?.length ?? 0,
      sourceCommit: snapshot.source.commit,
      fingerprint,
    },
  })
}

export const creativeKnowledgeReleaseSources = Object.freeze({
  defaultSnapshotUrl,
  defaultManifestUrl,
  defaultV2SnapshotUrl,
  defaultV2ManifestUrl,
})
