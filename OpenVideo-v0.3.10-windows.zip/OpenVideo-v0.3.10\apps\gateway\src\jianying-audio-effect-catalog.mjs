import { createHash } from 'node:crypto'
import { fingerprintCanonical } from './editor-agent-contracts.mjs'

const tokenPattern = /^ovjaudfx_v1_[a-f0-9]{64}$/u

export class JianyingAudioEffectCatalogError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingAudioEffectCatalogError'
    this.code = code
  }
}

/** Parse an owner-private catalog without exposing raw fields to public callers. */
/** @param {unknown} value */
export const parseJianyingAudioEffectCatalog = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new JianyingAudioEffectCatalogError('JY067_AUDIO_CATALOG_INVALID')
  }
  const body = /** @type {Record<string, any>} */ ({ ...value })
  const fingerprint = body.catalog_fingerprint
  delete body.catalog_fingerprint
  const digest = createHash('sha256').update(JSON.stringify(body)).digest('hex')
  const legacyDigest = fingerprintCanonical(body)
  if (body.schema_version !== 1 || body.kind !== 'jy064_audio_effect_catalog' ||
    body.catalog_version !== '1.0.0' || typeof fingerprint !== 'string' ||
    digest !== fingerprint && legacyDigest !== fingerprint) {
    throw new JianyingAudioEffectCatalogError('JY067_AUDIO_CATALOG_FINGERPRINT_INVALID')
  }
  if (!Array.isArray(body.entries) || body.entries.length === 0) {
    throw new JianyingAudioEffectCatalogError('JY067_AUDIO_CATALOG_EMPTY')
  }
  const entries = new Map()
  for (const entry of /** @type {Record<string, any>[]} */ (body.entries)) {
    if (!entry || entry.capability_id !== 'audio.effect.named' ||
      typeof entry.effect_token !== 'string' || !tokenPattern.test(entry.effect_token) ||
      typeof entry.resource_id !== 'string' || !/^[A-Za-z0-9_-]{4,80}$/u.test(entry.resource_id) ||
      entries.has(entry.effect_token)) {
      throw new JianyingAudioEffectCatalogError('JY067_AUDIO_CATALOG_ENTRY_INVALID')
    }
    entries.set(entry.effect_token, Object.freeze({ resourceId: entry.resource_id }))
  }
  return Object.freeze({ fingerprint, version: body.catalog_version, entries })
}

/** @param {{entries: Map<string, {resourceId: string}>}} catalog @param {unknown} token */
export const resolveJianyingAudioEffectToken = (catalog, token) => {
  if (!catalog?.entries || typeof token !== 'string' || !tokenPattern.test(token)) {
    throw new JianyingAudioEffectCatalogError('JY067_AUDIO_EFFECT_TOKEN_UNRESOLVED')
  }
  const resolved = catalog.entries.get(token)
  if (!resolved) throw new JianyingAudioEffectCatalogError('JY067_AUDIO_EFFECT_TOKEN_UNRESOLVED')
  return { effectToken: token, resourceId: resolved.resourceId }
}

/** @param {unknown} value @param {string} catalogFingerprint @param {{profileId: string, version: string}} desktop */
export const parseJianyingAudioEffectEvidence = (value, catalogFingerprint, desktop) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const candidate = /** @type {Record<string, any>} */ (value)
  const expectedKeys = [
    'schema_version', 'manual_evidence_verified', 'manual_attestation',
    'profile_id', 'app_version', 'catalog_fingerprint', 'scheme',
    'pre_open_fingerprint', 'post_save_fingerprint', 'opened', 'edited',
    'saved', 'reopened', 'matching_effect_count', 'attached',
    'temporary_media_cleaned',
  ]
  if (
    Object.keys(candidate).sort().join('\0') !== expectedKeys.sort().join('\0') ||
    candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.manual_attestation !== 'opened-edited-saved-reopened' ||
    candidate.profile_id !== desktop.profileId || candidate.app_version !== desktop.version ||
    candidate.catalog_fingerprint !== catalogFingerprint || candidate.scheme !== 'encrypt_v2' ||
    !/^[a-f0-9]{64}$/u.test(candidate.pre_open_fingerprint) ||
    !/^[a-f0-9]{64}$/u.test(candidate.post_save_fingerprint) ||
    candidate.pre_open_fingerprint === candidate.post_save_fingerprint ||
    candidate.opened !== true || candidate.edited !== true || candidate.saved !== true ||
    candidate.reopened !== true || candidate.matching_effect_count !== 1 ||
    candidate.attached !== true || candidate.temporary_media_cleaned !== true
  ) return null
  return Object.freeze({ ...candidate })
}
