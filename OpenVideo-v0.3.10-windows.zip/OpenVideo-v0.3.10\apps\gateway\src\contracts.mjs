import { isIP } from 'node:net'

import { isSupportedJsonSchema } from './json-schema.mjs'

const capabilities = ['text', 'vision', 'json']
const roles = ['system', 'user', 'assistant']
const maxMessages = 100
const maxPartsPerMessage = 20
const maxTextLength = 100_000
const maxInlineImageBytes = 10 * 1024 * 1024
const maxSchemaBytes = 100_000

const blockedHostnames = new Set(['localhost', 'localhost.localdomain', 'ip6-localhost'])

/** @param {string} hostname */
const isPublicHostname = (hostname) => {
  const normalized = hostname.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '')
  return Boolean(normalized) && !blockedHostnames.has(normalized) && !normalized.endsWith('.local') && isIP(normalized) === 0
}

/** @param {Record<string, unknown>} value @param {string[]} allowed */
const hasExactKeys = (value, allowed) =>
  Object.keys(value).every((key) => allowed.includes(key)) && allowed.every((key) => Object.hasOwn(value, key))

/** @param {string} url */
const isSafeImageUrl = (url) => {
  if (url.startsWith('https://')) {
    try {
      const parsed = new URL(url)
      return (
        parsed.protocol === 'https:' &&
        Boolean(parsed.hostname) &&
        !parsed.username &&
        !parsed.password &&
        isPublicHostname(parsed.hostname)
      )
    } catch {
      return false
    }
  }
  const match = /^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(url)
  if (!match) return false
  const payload = match[2]
  if (
    payload.length % 4 !== 0 ||
    !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(payload)
  ) {
    return false
  }
  const decoded = Buffer.from(payload, 'base64')
  return decoded.length <= maxInlineImageBytes && decoded.toString('base64') === payload
}

/** @param {unknown} value */
const isPart = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const record = /** @type {Record<string, unknown>} */ (value)
  if (record.type === 'text') {
    return (
      hasExactKeys(record, ['type', 'text']) &&
      typeof record.text === 'string' &&
      record.text.length > 0 &&
      record.text.length <= maxTextLength
    )
  }
  if (record.type === 'image') {
    return hasExactKeys(record, ['type', 'url']) && typeof record.url === 'string' && isSafeImageUrl(record.url)
  }
  return false
}

/** @param {unknown} value */
const isMessage = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const record = /** @type {Record<string, unknown>} */ (value)
  return (
    hasExactKeys(record, ['role', 'parts']) &&
    typeof record.role === 'string' &&
    roles.includes(record.role) &&
    Array.isArray(record.parts) &&
    record.parts.length > 0 &&
    record.parts.length <= maxPartsPerMessage &&
    record.parts.every(isPart)
  )
}

/** @param {unknown} value */
const isJsonSchema = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const record = /** @type {Record<string, unknown>} */ (value)
  if (
    !hasExactKeys(record, ['name', 'schema']) ||
    typeof record.name !== 'string' ||
    !/^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(record.name) ||
    !record.schema ||
    typeof record.schema !== 'object' ||
    Array.isArray(record.schema)
  ) {
    return false
  }
  try {
    return (
      Buffer.byteLength(JSON.stringify(record.schema), 'utf8') <= maxSchemaBytes &&
      isSupportedJsonSchema(record.schema)
    )
  } catch {
    return false
  }
}

/** @param {unknown} value */
export const isGatewayRequest = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const record = /** @type {Record<string, unknown>} */ (value)
  const allowed = record.capability === 'json' ? ['capability', 'messages', 'jsonSchema'] : ['capability', 'messages']
  if (!hasExactKeys(record, allowed)) return false
  if (typeof record.capability !== 'string' || !capabilities.includes(record.capability)) return false
  if (
    !Array.isArray(record.messages) ||
    record.messages.length === 0 ||
    record.messages.length > maxMessages ||
    !record.messages.every(isMessage)
  ) {
    return false
  }
  if (
    record.capability === 'vision' &&
    !record.messages.some((message) => {
      const parts = /** @type {Record<string, unknown>} */ (message).parts
      return Array.isArray(parts) && parts.some((part) => /** @type {Record<string, unknown>} */ (part).type === 'image')
    })
  ) {
    return false
  }
  return record.capability !== 'json' || isJsonSchema(record.jsonSchema)
}
