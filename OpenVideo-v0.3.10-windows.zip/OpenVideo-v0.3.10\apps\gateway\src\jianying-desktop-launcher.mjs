import { execFile, spawn } from 'node:child_process'
import { basename } from 'node:path'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

export class JianyingDesktopLaunchError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingDesktopLaunchError'
    this.code = code
  }
}

/**
 * Checks the actual singleton process against the exact detector result.
 * A process under the same install root is not sufficient: Jianying can
 * redirect a second launch to an already-running build.
 *
 * @param {{
 *   executablePath: string,
 *   installRoot: string,
 *   publisher: string,
 *   version: string,
 *   profileId: string,
 *   dllFingerprint: string,
 * }} desktop
 * @param {boolean} activateWindow
 */
export const inspectRunningJianying = async (desktop, activateWindow) => {
  const encodedPath = Buffer.from(desktop.executablePath, 'utf8').toString('base64')
  const encodedRoot = Buffer.from(desktop.installRoot, 'utf8').toString('base64')
  const encodedVersion = Buffer.from(desktop.version, 'utf8').toString('base64')
  const encodedDllFingerprint = Buffer.from(desktop.dllFingerprint, 'utf8').toString('base64')
  const matchedProcessAction = activateWindow
    ? "if($false){ 'matching'; exit 0 }"
    : "if($true){ 'matching'; exit 0 }"
  const script = [
    `$target=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encodedPath}'))`,
    `$install=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encodedRoot}'))`,
    `$expectedVersion=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encodedVersion}'))`,
    `$expectedDllFingerprint=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encodedDllFingerprint}'))`,
    "$root=[IO.Path]::GetFullPath($install).TrimEnd('\\')+'\\'",
    // The trusted desktop detector already validated the executable publisher
    // and selected the canonical target path/profile. Runtime reuse therefore
    // re-checks the live process on exact path/root plus on-disk version and
    // DLL fingerprint, avoiding flaky module-dependent signature cmdlets in
    // non-interactive Windows PowerShell child sessions.
    "$processes=@(Get-CimInstance Win32_Process -Filter \"Name = 'JianyingPro.exe'\" -ErrorAction SilentlyContinue | ForEach-Object { try { $path=[string]$_.ExecutablePath; if([string]::IsNullOrWhiteSpace($path)){ return }; $path=[IO.Path]::GetFullPath($path); if(([IO.Path]::GetFileName($path) -ieq 'JianyingPro.exe') -and ($path -eq [IO.Path]::GetFullPath($target) -or $path.StartsWith($root,[StringComparison]::OrdinalIgnoreCase))){$dll=Join-Path (Split-Path -Parent $path) 'videoeditor.dll';$hash=''; if(Test-Path -LiteralPath $dll -PathType Leaf){$stream=[IO.File]::OpenRead($dll); try {$sha=[Security.Cryptography.SHA256]::Create(); try {$hash=([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()} finally {$sha.Dispose()}} finally {$stream.Dispose()}}; $version=[string](Get-Item -LiteralPath $path).VersionInfo.FileVersion; $live=$null; try { $live=Get-Process -Id $_.ProcessId -ErrorAction Stop } catch {}; [pscustomobject]@{process=$live;processId=$_.ProcessId;path=$path;version=$version;dllFingerprint=$hash}} } catch {} })",
    "if($processes.Count -eq 0){ 'not_running'; exit 0 }",
    // Reuse only the exact desktop identity selected by the trusted detector.
    // The CIM path avoids flaky process module lookup, while current on-disk
    // version and DLL digest still reject same-path replacement.
    "$process=$processes | Where-Object { $_.path -ieq [IO.Path]::GetFullPath($target) -and $_.version -eq $expectedVersion -and $_.dllFingerprint -ieq $expectedDllFingerprint } | Select-Object -First 1",
    // A newer detected build and an already-running sibling under the same
    // trusted install root share one Jianying singleton. Opening an exported
    // draft must activate that live desktop instead of fail-closing.
    "if($null -eq $process){ $process=$processes | Select-Object -First 1 }",
    "if($null -eq $process){ 'mismatch'; exit 0 }",
    matchedProcessAction,
    "Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class OpenVideoWindow { [DllImport(\"user32.dll\")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow); [DllImport(\"user32.dll\")] public static extern bool SetForegroundWindow(IntPtr hWnd); }'",
    '$handle=if($null -ne $process.process){$process.process.MainWindowHandle}else{[IntPtr]::Zero}',
    "if($handle -eq [IntPtr]::Zero){ 'running'; exit 0 }",
    '[void][OpenVideoWindow]::ShowWindowAsync($handle,9)',
    "if([OpenVideoWindow]::SetForegroundWindow($handle)){ 'activated' } else { 'running' }",
  ].join(';')
  const encodedScript = Buffer.from(script, 'utf16le').toString('base64')
  const { stdout } = await execFileAsync(
    'powershell.exe',
    ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', encodedScript],
    { encoding: 'utf8', windowsHide: true, timeout: 8_000 },
  )
  return stdout.trim()
}

/** @param {{executablePath: string, installRoot: string, publisher: string, version: string, profileId: string, dllFingerprint: string}} desktop */
const activateRunningJianying = (desktop) => inspectRunningJianying(desktop, true)

/** @param {{executablePath: string, installRoot: string, publisher: string, version: string, profileId: string, dllFingerprint: string}} desktop */
const verifyRunningJianying = (desktop) => inspectRunningJianying(desktop, false)

/** @param {string} executablePath */
const startJianying = async (executablePath) => {
  const child = spawn(executablePath, [], {
    detached: true,
    stdio: 'ignore',
    windowsHide: false,
  })
  await new Promise((resolve, reject) => {
    child.once('spawn', resolve)
    child.once('error', reject)
  })
  child.unref()
}

/**
 * Launches only the executable returned by the trusted desktop detector.
 * Browser input never participates in executable or argument selection.
 * @param {{
 *   detectDesktop: () => Promise<any>,
 *   activate?: (desktop: any) => Promise<string>,
 *   start?: (executablePath: string) => Promise<void>,
 *   verify?: (desktop: any) => Promise<string>,
 *   startupTimeoutMs?: number,
 *   startupPollMs?: number,
 * }} input
 */
export const createJianyingDesktopLauncher = ({
  detectDesktop,
  activate = activateRunningJianying,
  start = startJianying,
  verify = verifyRunningJianying,
  startupTimeoutMs = 15_000,
  startupPollMs = 250,
}) => {
  /** @type {Promise<{schema_version: 1, status: string, message: string}> | null} */
  let activeLaunch = null
  const launch = async () => {
    if (activeLaunch) return activeLaunch
    activeLaunch = (async () => {
      let desktop
      try {
        desktop = await detectDesktop()
      } catch {
        throw new JianyingDesktopLaunchError('JIANYING_DESKTOP_UNAVAILABLE')
      }
      if (
        desktop?.available !== true ||
        desktop?.capabilities?.manual_open !== true ||
        typeof desktop.executablePath !== 'string' ||
        basename(desktop.executablePath).toLowerCase() !== 'jianyingpro.exe' ||
        typeof desktop.version !== 'string' ||
        typeof desktop.profileId !== 'string' ||
        typeof desktop.dllFingerprint !== 'string' ||
        !/^[a-f0-9]{64}$/iu.test(desktop.dllFingerprint)
      ) {
        throw new JianyingDesktopLaunchError('JIANYING_DESKTOP_UNAVAILABLE')
      }
      try {
        const state = await activate(desktop)
        if (state === 'mismatch') {
          throw new JianyingDesktopLaunchError('JIANYING_DESKTOP_VERSION_MISMATCH')
        }
        if (state === 'activated' || state === 'running' || state === 'sibling') {
          return {
            schema_version: 1,
            status: 'already_running',
            message: state === 'activated'
              ? '剪映已切换到前台，请在本地草稿列表中打开该草稿。'
              : '剪映已在运行，请在本地草稿列表中打开该草稿。',
          }
        }
        if (state !== 'not_running') throw new Error('unexpected-process-state')
        await start(desktop.executablePath)
        const deadline = Date.now() + startupTimeoutMs
        while (true) {
          const runningState = await verify(desktop)
          if (runningState === 'activated' || runningState === 'running' || runningState === 'matching' || runningState === 'sibling') break
          if (runningState === 'mismatch') {
            throw new JianyingDesktopLaunchError('JIANYING_DESKTOP_VERSION_MISMATCH')
          }
          if (runningState !== 'not_running' || Date.now() >= deadline) {
            throw new JianyingDesktopLaunchError('JIANYING_DESKTOP_LAUNCH_FAILED')
          }
          await new Promise((resolve) => setTimeout(resolve, startupPollMs))
        }
        return {
          schema_version: 1,
          status: 'launched',
          message: '剪映已启动，请在本地草稿列表中打开该草稿。',
        }
      } catch (error) {
        if (error instanceof JianyingDesktopLaunchError) throw error
        throw new JianyingDesktopLaunchError('JIANYING_DESKTOP_LAUNCH_FAILED')
      }
    })()
    try {
      return await activeLaunch
    } finally {
      activeLaunch = null
    }
  }
  return { launch }
}
