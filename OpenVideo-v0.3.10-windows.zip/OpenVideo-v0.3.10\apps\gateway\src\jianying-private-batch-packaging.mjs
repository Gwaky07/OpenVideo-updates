import {
  assertPackagingWriterBinding,
  assertBoundedPrivatePackagingValue,
  computePackagingEntryBindingFingerprint,
  isPackagingResourceTokenForFamily,
  isOpaquePackagingToken,
  resolvePrivatePackagingResourceToken,
} from './jianying-packaging-resource-index.mjs'

const MAX_BATCH = 24
const supportedKinds = new Set(['sticker', 'effect', 'animation', 'mask', 'blend'])
const kindFamily = /** @type {Readonly<Record<string, string>>} */ (Object.freeze({
  sticker: 'sticker', effect: 'video_effect', animation: 'video_animation', mask: 'mask', blend: 'blend',
}))
const familyKind = /** @type {Readonly<Record<string, string>>} */ (Object.freeze({
  sticker: 'sticker',
  video_effect: 'effect',
  video_animation: 'animation',
  mask: 'mask',
  blend: 'blend',
}))

/** @param {unknown} start @param {unknown} duration */
const hasValidTargetRange = (start, duration) =>
  typeof start === 'number' && Number.isSafeInteger(start) && start >= 0 &&
  typeof duration === 'number' && Number.isSafeInteger(duration) && duration > 0

/**
 * Build a writer-private batch from canonical opaque-token requests. Discovery
 * entries intentionally resolve to null until evidence admission upgrades them.
 * @param {unknown} index
 * @param {unknown} requests
 * @returns {{writerPlan: ReadonlyArray<Record<string, any>>, summary: ReadonlyArray<Record<string, any>>}}
 */
export const planPrivatePackagingBatch = (index, requests) => {
  if (!Array.isArray(requests)) throw new Error('JY136_BATCH_REQUESTS_INVALID')
  const writerPlan = []
  const summary = []
  const seen = new Set()
  for (const [position, request] of requests.entries()) {
    const token = request?.packagingToken
    if (!isOpaquePackagingToken(token)) {
      summary.push({ position, status: 'skipped', reason: 'JY136_TOKEN_INVALID' })
      continue
    }
    if (!hasValidTargetRange(request?.targetStartUs, request?.targetDurationUs)) {
      summary.push({ position, packagingToken: token, status: 'skipped', reason: 'JY137_TARGET_RANGE_INVALID' })
      continue
    }
    const placementKey = `${token}:${String(request?.targetStartUs)}:${String(request?.targetDurationUs)}`
    if (seen.has(placementKey)) {
      summary.push({ position, packagingToken: token, status: 'skipped', reason: 'JY136_DUPLICATE_TOKEN' })
      continue
    }
    seen.add(placementKey)
    const resolved = resolvePrivatePackagingResourceToken(index, token)
    if (!resolved || !supportedKinds.has(resolved.kind)) {
      summary.push({
        position,
        packagingToken: token,
        status: 'skipped',
        reason: resolved?.kind === 'flower' || resolved?.kind === 'bubble'
          ? 'JY137_WRITER_FAMILY_UNSUPPORTED'
          : 'JY136_RESOURCE_NOT_ADMITTED',
      })
      continue
    }
    try {
      assertPackagingWriterBinding(resolved.family, resolved)
    } catch {
      summary.push({ position, packagingToken: token, status: 'skipped', reason: 'JY137_WRITER_BINDING_INVALID' })
      continue
    }
    if (writerPlan.length >= MAX_BATCH) {
      summary.push({ position, packagingToken: token, status: 'skipped', reason: 'JY136_BATCH_LIMIT' })
      continue
    }
    const privateBinding = { ...resolved }
    delete privateBinding.packagingToken
    delete privateBinding.family
    delete privateBinding.kind
    writerPlan.push(Object.freeze({
      packagingToken: token,
      placementId: placementKey,
      family: resolved.family,
      kind: resolved.kind,
      privateBinding,
      bindingFingerprint: computePackagingEntryBindingFingerprint({ family: resolved.family, privateBinding }),
      targetStartUs: request?.targetStartUs,
      targetDurationUs: request?.targetDurationUs,
    }))
    summary.push({ position, packagingToken: token, status: 'accepted', family: resolved.family })
  }
  return Object.freeze({ writerPlan: Object.freeze(writerPlan), summary: Object.freeze(summary) })
}

/** Validate the private plan immediately before it crosses the direct writer boundary. */
/** @param {unknown} plan @returns {ReadonlyArray<Record<string, any>>} */
export const assertPrivateBatchPlanForWriter = (plan) => {
  if (!Array.isArray(plan) || plan.length > MAX_BATCH) throw new Error('JY140_PRIVATE_BATCH_PLAN_INVALID')
  const placements = new Set()
  for (const entry of plan) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) throw new Error('JY140_PRIVATE_BATCH_ENTRY_INVALID')
    const keys = Object.keys(entry).sort()
    if (keys.join('|') !== 'bindingFingerprint|family|kind|packagingToken|placementId|privateBinding|targetDurationUs|targetStartUs') {
      throw new Error('JY140_PRIVATE_BATCH_ENTRY_INVALID')
    }
    if (!isOpaquePackagingToken(entry.packagingToken) || entry.family !== kindFamily[entry.kind] ||
        !isPackagingResourceTokenForFamily(entry.family, entry.packagingToken) ||
        !supportedKinds.has(entry.kind) || !Number.isSafeInteger(entry.targetStartUs) ||
        entry.targetStartUs < 0 || !Number.isSafeInteger(entry.targetDurationUs) || entry.targetDurationUs <= 0 ||
        typeof entry.placementId !== 'string' || entry.placementId !== `${entry.packagingToken}:${entry.targetStartUs}:${entry.targetDurationUs}` ||
        !/^[a-f0-9]{64}$/u.test(entry.bindingFingerprint) || !entry.privateBinding ||
        typeof entry.privateBinding !== 'object' || Array.isArray(entry.privateBinding)) {
      throw new Error('JY140_PRIVATE_BATCH_ENTRY_INVALID')
    }
    if (placements.has(entry.placementId)) throw new Error('JY140_PRIVATE_BATCH_DUPLICATE')
    placements.add(entry.placementId)
    assertBoundedPrivatePackagingValue(entry.privateBinding)
    assertPackagingWriterBinding(entry.family, entry.privateBinding)
    if (computePackagingEntryBindingFingerprint({ family: entry.family, privateBinding: entry.privateBinding }) !== entry.bindingFingerprint) {
      throw new Error('JY140_PRIVATE_BATCH_FINGERPRINT_INVALID')
    }
  }
  return plan
}

/**
 * Require every non-empty plan to resolve through the already admitted private
 * catalog before it reaches the Python writer. The resolver is intentionally
 * callback-shaped so private index contents never become part of the writer
 * request or public DTOs.
 * @param {unknown} plan
 * @param {((packagingToken: string) => Record<string, any> | null) | null} resolvePackagingToken
 * @returns {ReadonlyArray<Record<string, any>>}
 */
export const validatePrivateBatchPlanForWriter = (plan, resolvePackagingToken = null) => {
  const validated = assertPrivateBatchPlanForWriter(plan)
  if (validated.length === 0) return validated
  if (typeof resolvePackagingToken !== 'function') throw new Error('JY140_PRIVATE_BATCH_ADMISSION_REQUIRED')
  for (const entry of validated) {
    const resolved = resolvePackagingToken(entry.packagingToken)
    if (
      !resolved ||
      resolved.packagingToken !== entry.packagingToken ||
      resolved.family !== entry.family ||
      resolved.kind !== entry.kind
    ) {
      throw new Error('JY140_PRIVATE_BATCH_ADMISSION_REQUIRED')
    }
    const privateBinding = { ...resolved }
    delete privateBinding.kind
    delete privateBinding.packagingToken
    delete privateBinding.family
    if (computePackagingEntryBindingFingerprint({ family: resolved.family, privateBinding }) !== entry.bindingFingerprint) {
      throw new Error('JY140_PRIVATE_BATCH_ADMISSION_REQUIRED')
    }
  }
  return validated
}

/** @param {unknown} value @param {ReadonlyArray<Record<string, any>>} plan */
export const verifyPrivateBatchDraftReadback = (value, plan) => {
  if (!Array.isArray(value) || value.length !== plan.length) return false
  const expected = new Map(plan.map((entry) => [entry.placementId, entry]))
  const seen = new Set()
  for (const entry of value) {
    const planned = expected.get(entry?.placementId)
    if (
      !isOpaquePackagingToken(entry?.packagingToken) ||
      entry.packagingToken !== planned?.packagingToken ||
      entry.placementId !== planned?.placementId ||
      entry.persisted !== true ||
      seen.has(entry.placementId) ||
      !planned ||
      entry.kind !== planned.kind ||
      entry.resourceId !== planned.privateBinding?.resourceId ||
      entry.bindingFingerprint !== planned.bindingFingerprint ||
      entry.targetStartUs !== planned.targetStartUs ||
      entry.targetDurationUs !== planned.targetDurationUs ||
      (planned.kind === 'effect' && (entry.effectId ?? null) !== (planned.privateBinding?.effectId ?? null)) ||
      (planned.kind === 'animation' && entry.durationUs !== planned.privateBinding?.durationUs)
    ) return false
    seen.add(entry.placementId)
  }
  return seen.size === expected.size
}

/** Convert only admitted private bindings into the exact writer packaging shape. */
/** @param {ReadonlyArray<Record<string, any>>} plan */
export const projectPrivatePackagingBatchForWriter = (plan) => {
  /** @type {Record<string, any[]>} */
  const projected = { effect_segments: [], sticker_segments: [], animation_segments: [], mask_segments: [], blend_segments: [] }
  for (const entry of plan) {
    if (!Number.isSafeInteger(entry.targetStartUs) || !Number.isSafeInteger(entry.targetDurationUs) || entry.targetStartUs < 0 || entry.targetDurationUs <= 0) {
      throw new Error('JY136_TARGET_RANGE_INVALID')
    }
    const base = { resource_id: entry.privateBinding.resourceId, target_start_us: entry.targetStartUs, target_duration_us: entry.targetDurationUs }
    if (entry.kind === 'effect') projected.effect_segments.push({
      ...base,
      ...(typeof entry.privateBinding.effectId === 'string' ? { effect_id: entry.privateBinding.effectId } : {}),
    })
    else if (entry.kind === 'sticker') projected.sticker_segments.push(base)
    else if (entry.kind === 'animation' && Number.isSafeInteger(entry.privateBinding.durationUs)) projected.animation_segments.push({ ...base, duration_us: entry.privateBinding.durationUs })
    else if (entry.kind === 'mask' && entry.privateBinding.commonMaskTemplate) projected.mask_segments.push({ ...base, common_mask_template: entry.privateBinding.commonMaskTemplate, center_x: 0, center_y: 0, size: 0.5, rotation: 0, feather: 0, invert: false })
    else if (entry.kind === 'blend') projected.blend_segments.push(base)
    else throw new Error('JY136_WRITER_FAMILY_UNSUPPORTED')
  }
  return Object.freeze(Object.fromEntries(Object.entries(projected).map(([key, entries]) => [key, Object.freeze(entries)])))
}

export const PRIVATE_BATCH_LIMITS = Object.freeze({ maxBatch: MAX_BATCH })

/** @param {{writerPlan: ReadonlyArray<Record<string, any>>, summary: ReadonlyArray<Record<string, any>>}} batch */
export const summarizePrivatePackagingBatch = (batch) => {
  const skippedByReason = /** @type {Record<string, number>} */ ({})
  for (const item of batch.summary) {
    if (item.status !== 'skipped' || typeof item.reason !== 'string') continue
    skippedByReason[item.reason] = (skippedByReason[item.reason] ?? 0) + 1
  }
  return Object.freeze({
    accepted: batch.writerPlan.length,
    skipped: Object.freeze(Object.entries(skippedByReason)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([reason, count]) => Object.freeze({ reason, count }))),
  })
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} range @param {number} startUs @param {number} durationUs */
const matchesTargetRange = (range, startUs, durationUs) =>
  isRecord(range) && (range.start === undefined ? 0 : range.start) === startUs && range.duration === durationUs

/** @param {unknown} value @returns {Record<string, any>[]} */
const asArrayOfRecords = (value) => Array.isArray(value)
  ? value.filter((entry) => isRecord(entry))
  : []

/** @param {Record<string, any>} content */
const findPrimaryVideoTrack = (content) => {
  const primaryTracks = asArrayOfRecords(content?.tracks)
    .filter((track) => track.name === 'video-primary' && track.type === 'video')
  return primaryTracks.length === 1 ? primaryTracks[0] : null
}

/**
 * Convert already-admitted opaque bindings back into the exact bounded writer
 * plan shape. The discovery index remains immutable; this helper only proves
 * that the admitted binding still maps to the current controlled writer.
 * @param {any} index
 * @param {unknown} admittedBindings
 * @returns {ReadonlyArray<Record<string, any>> | null}
 */
export const buildPrivateBatchWriterCompatibilityPlan = (index, admittedBindings) => {
  if (!index || !Array.isArray(index.entries) || !Array.isArray(admittedBindings) || admittedBindings.length === 0) return null
  const entries = new Map(/** @type {Array<Record<string, any>>} */ (index.entries)
    .filter((entry) => isRecord(entry) && typeof entry.packaging_token === 'string')
    .map((entry) => [entry.packaging_token, entry]))
  try {
    const plan = admittedBindings.map((binding) => {
      if (!isRecord(binding) || Object.keys(binding).sort().join('|') !== 'binding_fingerprint|family|packaging_token|target_duration_us|target_start_us') {
        throw new Error('JY150_BATCH_BINDING_INVALID')
      }
      const entry = entries.get(binding.packaging_token)
      if (!entry || entry.family !== binding.family || !isRecord(entry.private_binding)) {
        throw new Error('JY150_BATCH_BINDING_INVALID')
      }
      assertPackagingWriterBinding(entry.family, entry.private_binding)
      const bindingFingerprint = computePackagingEntryBindingFingerprint({
        family: entry.family,
        privateBinding: entry.private_binding,
      })
      if (binding.binding_fingerprint !== bindingFingerprint) {
        throw new Error('JY150_BATCH_BINDING_INVALID')
      }
      const kind = familyKind[entry.family]
      if (!supportedKinds.has(kind)) {
        throw new Error('JY150_BATCH_BINDING_INVALID')
      }
      return Object.freeze({
        packagingToken: binding.packaging_token,
        placementId: `${binding.packaging_token}:${binding.target_start_us}:${binding.target_duration_us}`,
        family: entry.family,
        kind,
        privateBinding: structuredClone(entry.private_binding),
        bindingFingerprint,
        targetStartUs: binding.target_start_us,
        targetDurationUs: binding.target_duration_us,
      })
    })
    return /** @type {ReadonlyArray<Record<string, any>>} */ (assertPrivateBatchPlanForWriter(plan))
  } catch {
    return null
  }
}

/**
 * Validate that the decrypted draft content still contains every admitted
 * private writer segment with the exact controlled structure that the generic
 * batch writer projects.
 * @param {unknown} content
 * @param {unknown} projected
 * @returns {boolean}
 */
export const verifyPrivateBatchDraftContent = (content, projected) => {
  if (!isRecord(content) || !isRecord(projected)) return false
  const materials = isRecord(content.materials) ? content.materials : {}
  const tracks = asArrayOfRecords(content.tracks)
  const videoTrack = findPrimaryVideoTrack(content)
  const usedMaterialIds = new Set()
  const usedSegmentKeys = new Set()

  /**
   * @param {'effect' | 'sticker'} trackType
   * @param {Record<string, any>[]} projectedSegments
   * @param {Record<string, any>[]} bucket
   */
  const verifyTrackMaterials = (trackType, projectedSegments, bucket) => {
    const candidateTracks = tracks.filter((track) => track.type === trackType)
    for (const segment of projectedSegments) {
      const matches = []
      for (const track of candidateTracks) {
        for (const candidate of asArrayOfRecords(track.segments)) {
          if (!matchesTargetRange(candidate.target_timerange, segment.target_start_us, segment.target_duration_us)) continue
          const materialId = candidate.material_id
          if (typeof materialId !== 'string') continue
          const material = bucket.find((entry) =>
            entry.id === materialId &&
            String(entry.resource_id ?? entry.effect_id ?? entry.sticker_id ?? '') === segment.resource_id &&
            (trackType !== 'effect' || !Object.hasOwn(segment, 'effect_id') || entry.effect_id === segment.effect_id))
          if (material) {
            matches.push({
              materialId,
              segmentKey: `${track.name}:${materialId}:${segment.target_start_us}:${segment.target_duration_us}`,
            })
          }
        }
      }
      if (matches.length !== 1 || usedMaterialIds.has(matches[0].materialId) || usedSegmentKeys.has(matches[0].segmentKey)) return false
      usedMaterialIds.add(matches[0].materialId)
      usedSegmentKeys.add(matches[0].segmentKey)
    }
    return true
  }

  /**
   * @param {Record<string, any>[]} projectedSegments
   * @param {(videoSegment: Record<string, any>, projectedSegment: Record<string, any>) => string[]} selector
   */
  const verifyVideoAttachments = (projectedSegments, selector) => {
    if (!videoTrack) return projectedSegments.length === 0
    const videoSegments = asArrayOfRecords(videoTrack.segments)
    for (const segment of projectedSegments) {
      const matches = videoSegments.filter((candidate) =>
        matchesTargetRange(candidate.target_timerange, segment.target_start_us, segment.target_duration_us) &&
        Array.isArray(candidate.extra_material_refs))
      if (matches.length !== 1) return false
      const materialIds = selector(matches[0], segment)
      if (!Array.isArray(materialIds) || materialIds.length !== 1) return false
      const materialId = materialIds[0]
      const segmentKey = `video-primary:${materialId}:${segment.target_start_us}:${segment.target_duration_us}`
      if (usedMaterialIds.has(materialId) || usedSegmentKeys.has(segmentKey)) return false
      usedMaterialIds.add(materialId)
      usedSegmentKeys.add(segmentKey)
    }
    return true
  }

  const effectSegments = asArrayOfRecords(projected.effect_segments)
  const stickerSegments = asArrayOfRecords(projected.sticker_segments)
  const animationSegments = asArrayOfRecords(projected.animation_segments)
  const maskSegments = asArrayOfRecords(projected.mask_segments)
  const blendSegments = asArrayOfRecords(projected.blend_segments)

  const effectMaterials = asArrayOfRecords(materials.video_effects)
  const blendMaterials = asArrayOfRecords(materials.effects)
  const stickerMaterials = asArrayOfRecords(materials.stickers)
  const animationMaterials = asArrayOfRecords(materials.material_animations)
  const commonMaskMaterials = asArrayOfRecords(materials.common_mask)
  const maskMaterials = asArrayOfRecords(materials.masks)

  return verifyTrackMaterials('effect', effectSegments, effectMaterials) &&
    verifyTrackMaterials('sticker', stickerSegments, stickerMaterials) &&
    verifyVideoAttachments(animationSegments, (videoSegment, projectedSegment) =>
      animationMaterials
        .filter((material) =>
          typeof material.id === 'string' &&
          videoSegment.extra_material_refs.includes(material.id) &&
          Array.isArray(material.animations) &&
          material.animations.some((animation) =>
            String(animation?.resource_id ?? '') === projectedSegment.resource_id &&
            Number.isSafeInteger(animation?.duration) &&
            animation.duration > 0 && animation.duration <= projectedSegment.target_duration_us))
        .map((material) => material.id)) &&
    verifyVideoAttachments(maskSegments, (videoSegment, projectedSegment) => {
      const expectedResourceId = projectedSegment.common_mask_template?.resource_id
      const bucket = typeof expectedResourceId === 'string' ? commonMaskMaterials : maskMaterials
      const resourceId = typeof expectedResourceId === 'string' ? expectedResourceId : projectedSegment.resource_id
      return bucket
        .filter((material) =>
          typeof material.id === 'string' &&
          videoSegment.extra_material_refs.includes(material.id) &&
          material.resource_id === resourceId)
        .map((material) => material.id)
    }) &&
    verifyVideoAttachments(blendSegments, (videoSegment, projectedSegment) =>
      blendMaterials
        .filter((material) =>
          typeof material.id === 'string' &&
          videoSegment.extra_material_refs.includes(material.id) &&
          material.type === 'mix_mode' &&
          material.resource_id === projectedSegment.resource_id)
        .map((material) => material.id))
}

/**
 * Reuse the exact generic planner + writer projection as a private admission
 * harness. Callers can then validate the decrypted draft content against the
 * same bounded structure without exposing private bindings publicly.
 * @param {any} index
 * @param {unknown} admittedBindings
 */
export const createPrivateBatchWriterCompatibilityHarness = (index, admittedBindings) => {
  const writerPlan = buildPrivateBatchWriterCompatibilityPlan(index, admittedBindings)
  if (!writerPlan) return null
  try {
    const projected = projectPrivatePackagingBatchForWriter(writerPlan)
    return Object.freeze({
      writerPlan,
      projected,
      /** @param {unknown} content */
      verifyDraftContent: (content) => verifyPrivateBatchDraftContent(content, projected),
    })
  } catch {
    return null
  }
}
