import { fingerprintCanonical } from './editor-agent-contracts.mjs'

const registryVersion = 2

const promotionReceiptIdPattern = /^ovjypromotion_v1_[a-z0-9_-]{8,160}$/iu
const safeProfileIdPattern = /^jianying-[a-z0-9-]{1,80}$/u
const safeCapabilityIdPattern = /^[a-z][a-z0-9._-]{0,80}$/u

/**
 * A promotion receipt is deliberately a small, path-free summary. It is not
 * evidence by itself; it is the server-side projection of independently
 * verified exact-profile evidence. Every gate must be explicit so a partial
 * probe can never promote a writer or Agent capability.
 *
 * @param {unknown} receipt
 * @param {string | null} profileId
 * @param {string} capabilityId
 */
export const isCapabilityPromotionReceiptReady = (receipt, profileId, capabilityId) => {
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt) ||
      typeof profileId !== 'string' || !safeProfileIdPattern.test(profileId) ||
      typeof capabilityId !== 'string' || !safeCapabilityIdPattern.test(capabilityId)) return false
  const candidate = /** @type {Record<string, unknown>} */ (receipt)
  return candidate.capabilityId === capabilityId &&
    typeof candidate.profileId === 'string' && safeProfileIdPattern.test(candidate.profileId) &&
    candidate.profileId === profileId &&
    typeof candidate.receiptId === 'string' &&
    promotionReceiptIdPattern.test(candidate.receiptId) &&
    candidate.exactProfileMatch === true &&
    candidate.writerReady === true &&
    candidate.catalogReady === true &&
    candidate.openEvidence === true &&
    candidate.editEvidence === true &&
    candidate.saveEvidence === true &&
    candidate.reopenEvidence === true
}

/**
 * SFX promotion admits Jianying writing and Agent use. Preview stays
 * degraded: 成片 never mixes SFX. The server may project these fields
 * only after rebinding the private receipt to the live desktop and catalog.
 */
/** @param {unknown} receipt @param {string | null} profileId */
export const isSfxCapabilityPromotionReceiptReady = (receipt, profileId) => {
  if (!isCapabilityPromotionReceiptReady(receipt, profileId, 'audio.sfx.local')) return false
  const candidate = /** @type {Record<string, unknown>} */ (receipt)
  return candidate.previewReady === true &&
    candidate.dualOutputReady === true &&
    candidate.stableReceiptCount === 3 &&
    candidate.automaticPlacementReady === true &&
    typeof candidate.catalogFingerprint === 'string' &&
    /^[a-f0-9]{64}$/u.test(candidate.catalogFingerprint)
}

/**
 * preview, jianying, degradationCode, agentAuthorizationOverride
 * Agent override keeps UI-010 exclusive: writer can be degraded while Agent stays denied.
 * @type {ReadonlyArray<readonly [string, string, string, string | null, 'allowed' | 'denied' | null]>}
 */
const definitions = Object.freeze([
  ['transition.cut', 'implemented', 'implemented', null, null],
  ['transition.none', 'implemented', 'implemented', null, null],
  // VID-004: Preview approximates dissolve as hard-cut (degraded). JY-026
  // proves persistence only for the explicitly scoped 11.1 desktop profile.
  // Unbound and other profiles remain degraded and are rejected by the writer gate.
  ['transition.dissolve', 'degraded', 'degraded', 'DISSOLVE_PREVIEW_DEGRADED', 'denied'],
  ['transition.wipe', 'unsupported', 'unsupported', null, null],
  ['transition.match_cut', 'unsupported', 'unsupported', null, null],
  ['audio.voiceover.edge_tts', 'implemented', 'implemented', null, null],
  ['audio.bgm.local', 'implemented', 'implemented', null, null],
  ['audio.bgm.library', 'unsupported', 'unsupported', null, null],
  ['audio.sfx.local', 'degraded', 'implemented', 'SFX_PREVIEW_DEGRADED', 'denied'],
  // JY-013: persisted fade curves are confirmed editable in the current
  // supported Jianying draft; Preview remains unsupported and Agent denied.
  // JY-020: writer persistence exists, but no bound real same-draft manual
  // evidence is present in the private runtime; keep Jianying degraded.
  ['audio.fade', 'unsupported', 'degraded', 'AUDIO_FADE_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  ['audio.volume.keyframe', 'unsupported', 'unsupported', null, 'denied'],
  // JY-033: upstream exposes private AudioScene/Tone/SpeechToSong metadata,
  // but no private catalog or current-version same-draft evidence is admitted.
  ['audio.effect.named', 'unsupported', 'unsupported', null, 'denied'],
  ['caption.basic', 'implemented', 'implemented', null, null],
  ['caption.bottom_safe', 'implemented', 'implemented', null, null],
  ['title.card', 'implemented', 'implemented', null, null],
  ['text.rich', 'implemented', 'implemented', null, 'denied'],
  ['text.flower.private', 'unsupported', 'degraded', 'FLOWER_TEXT_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  ['text.bubble.private', 'unsupported', 'degraded', 'BUBBLE_TEXT_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  // TPL-008: Jianying writer resolves opaque packaging tokens → resource_id.
  // Preview has no real sticker/effect compositor → unsupported (honest 降级复刻).
  ['effect.video.named', 'unsupported', 'implemented', 'EFFECT_PREVIEW_UNSUPPORTED', 'denied'],
  // JY-034: segment-local VideoEffect metadata is not admitted without a
  // private catalog and current-version same-draft evidence.
  ['effect.video.segment_named', 'unsupported', 'unsupported', null, 'denied'],
  ['animation.video.named', 'unsupported', 'unsupported', null, 'denied'],
  ['mask.video.named', 'unsupported', 'degraded', 'MASK_VIDEO_PROFILE_EVIDENCE_REQUIRED', 'denied'],
  ['blend.video.named', 'unsupported', 'unsupported', 'BLEND_VIDEO_PRIVATE_CATALOG_REQUIRED', 'denied'],
  ['chroma.video', 'unsupported', 'unsupported', null, 'denied'],
  ['audio.video.fade', 'unsupported', 'unsupported', null, 'denied'],
  ['background.video', 'unsupported', 'unsupported', 'BACKGROUND_VIDEO_PRIVATE_CATALOG_REQUIRED', 'denied'],
  ['animation.text.named', 'unsupported', 'unsupported', null, 'denied'],
  ['transform.text.keyframe', 'unsupported', 'unsupported', null, 'denied'],
  ['transform.sticker.keyframe', 'unsupported', 'unsupported', null, 'denied'],
  ['track.insert', 'unsupported', 'unsupported', null, 'denied'],
  ['track.insert_many', 'unsupported', 'degraded', 'TRACK_INSERT_MANY_PROFILE_EVIDENCE_REQUIRED', 'denied'],
  // JY-011: both upstream filter entry points remain fail-closed until a private
  // opaque resolver and current-version editable-draft evidence exist.
  ['filter.video.track_named', 'unsupported', 'unsupported', null, 'denied'],
  ['filter.video.named', 'unsupported', 'unsupported', null, 'denied'],
  ['sticker.named', 'unsupported', 'degraded', 'STICKER_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  ['transform.scale', 'degraded', 'degraded', 'TRANSFORM_SCALE_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  ['transform.position', 'degraded', 'degraded', 'TRANSFORM_POSITION_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  // JY-010: current-version Jianying 11.1 manually opened/edited the persisted rotation keyframe.
  // Preview remains degraded, so effective status and Agent authorization stay conservative.
  ['transform.rotation', 'degraded', 'implemented', 'TRANSFORM_ROTATION_PREVIEW_DEGRADED', 'denied'],
  ['opacity', 'degraded', 'degraded', 'OPACITY_MANUAL_EVIDENCE_REQUIRED', 'denied'],
  // JY-068: the exact 11.1 profile persisted a bounded constant speed after
  // a same-draft manual edit/save/reopen check. Preview is still unsupported
  // and Agent remains denied because neither has independent evidence.
  ['speed.constant', 'unsupported', 'unsupported', null, 'denied'],
  ['speed.curve', 'unsupported', 'unsupported', null, null],
])

/** @type {Readonly<Record<string, Record<string, unknown>>>} */
const allowedParameters = Object.freeze({
  'transition.cut': { durationUs: { minimum: 0, maximum: 0 } },
  'transition.none': { durationUs: { minimum: 0, maximum: 0 } },
  'transition.dissolve': { durationUs: { minimum: 1, maximum: 5_000_000 } },
  'audio.voiceover.edge_tts': { audioToken: { type: 'opaque_id' }, volume: { minimum: 0, maximum: 1 } },
  'audio.bgm.local': { audioToken: { type: 'opaque_id' }, volume: { minimum: 0, maximum: 1 } },
  'audio.sfx.local': { audioToken: { type: 'opaque_id' }, volume: { minimum: 0, maximum: 1 } },
  'audio.fade': {},
  'audio.volume.keyframe': {},
  // Parameter schema remains intentionally absent while the capability is
  // unsupported; promotion must add executable bounded-array validation.
  'audio.effect.named': { effectToken: { type: 'opaque_id' } },
  'caption.basic': { styleToken: { type: 'opaque_id' } },
  'caption.bottom_safe': { styleToken: { type: 'opaque_id' } },
  'title.card': { styleToken: { type: 'opaque_id' } },
  'text.rich': { styleToken: { type: 'opaque_id' } },
  'text.flower.private': { templateToken: { type: 'opaque_id' } },
  'text.bubble.private': { templateToken: { type: 'opaque_id' } },
  'effect.video.named': { packagingToken: { type: 'opaque_id' } },
  'effect.video.segment_named': { effectToken: { type: 'opaque_id' } },
  'animation.video.named': { animationToken: { type: 'opaque_id' } },
  'mask.video.named': { maskToken: { type: 'opaque_id' } },
  'blend.video.named': { blendToken: { type: 'opaque_id' } },
  'chroma.video': {
    color: { type: 'rgba_hex' },
    intensity: { minimum: 0, maximum: 100 },
    shadow: { minimum: 0, maximum: 100 },
    edgeSmooth: { minimum: 0, maximum: 100 },
    spill: { minimum: 0, maximum: 100 },
  },
  'audio.video.fade': { fadeInUs: { minimum: 0, maximum: 10_000_000 }, fadeOutUs: { minimum: 0, maximum: 10_000_000 } },
  'background.video': { fillToken: { type: 'opaque_id' } },
  'animation.text.named': { animationToken: { type: 'opaque_id' } },
  'transform.text.keyframe': {},
  'transform.sticker.keyframe': {},
  'track.insert': {},
  'track.insert_many': {},
  'filter.video.track_named': {
    packagingToken: { type: 'opaque_id' },
    intensity: { minimum: 0, maximum: 1 },
  },
  'filter.video.named': {
    packagingToken: { type: 'opaque_id' },
    intensity: { minimum: 0, maximum: 1 },
  },
  'sticker.named': { packagingToken: { type: 'opaque_id' } },
  'transform.scale': {},
  'transform.position': {},
  'transform.rotation': {},
  'opacity': {},
})
/** @param {string} preview @param {string} jianying */
const effectiveStatus = (preview, jianying) => {
  if (preview === 'unsupported' || jianying === 'unsupported') return 'unsupported'
  if (preview === 'degraded' || jianying === 'degraded') return 'degraded'
  return 'implemented'
}

const capabilities = definitions.map(([
  capabilityId,
  preview,
  jianying,
  degradationCode,
  agentAuthorizationOverride,
]) => {
  const effective = effectiveStatus(preview, jianying)
  const derivedAgent = effective === 'unsupported' ? 'denied' : 'allowed'
  return {
    capabilityId,
    targets: {
      preview: {
        status: preview,
        degradationCode: preview === 'degraded' ? degradationCode : null,
      },
      jianying: {
        status: jianying,
        degradationCode: jianying === 'degraded' ? degradationCode : null,
      },
    },
    effectiveStatus: effective,
    agentAuthorization: agentAuthorizationOverride ?? derivedAgent,
    allowedParameters: allowedParameters[capabilityId] ?? {},
  }
})

/**
 * Evidence for an exact desktop profile may promote a writer target, but must
 * never become a global version-agnostic capability claim.
 * @type {Readonly<Record<string, Readonly<Record<string, 'implemented'>>>>}
 */
const profileScopedJianyingCapabilities = Object.freeze({
  'jianying-11-1-provisional': Object.freeze({
    'transition.dissolve': 'implemented',
    'transform.scale': 'implemented',
    'transform.position': 'implemented',
    opacity: 'implemented',
    'audio.fade': 'implemented',
    'audio.volume.keyframe': 'implemented',
    'filter.video.named': 'implemented',
    'filter.video.track_named': 'implemented',
    'animation.video.named': 'implemented',
    'mask.video.named': 'implemented',
    'blend.video.named': 'implemented',
    'background.video': 'implemented',
    'sticker.named': 'implemented',
    'text.flower.private': 'implemented',
    'text.bubble.private': 'implemented',
    'track.insert_many': 'implemented',
    'audio.effect.named': 'implemented',
    'speed.constant': 'implemented',
    'audio.video.fade': 'implemented',
    'chroma.video': 'implemented',
    'animation.text.named': 'implemented',
    'transform.text.keyframe': 'implemented',
  }),
  // JY-084 evidence is independently bound to the signed 11.2 desktop. Do
  // not inherit the 11.1 promotion set to this newer provisional profile.
  'jianying-11-2-provisional': Object.freeze({
    // JY-130 batch text evidence promotes only the families present in the
    // admitted private catalog; capabilitiesForProfile still requires the
    // matching catalog admission before applying these profile-scoped states.
    'text.flower.private': 'implemented',
    'text.bubble.private': 'implemented',
    'track.insert': 'implemented',
    'transform.text.keyframe': 'implemented',
    'transform.sticker.keyframe': 'implemented',
    // JY-128 admits named audio effects on 11.2 only after the exact
    // catalog-bound same-draft evidence is loaded by the server.
    'audio.effect.named': 'implemented',
    // JY-143 admitted one exact video-animation binding through the signed
    // private registry. The server still supplies the catalog capability only
    // after that binding has passed live-draft verification.
    'animation.video.named': 'implemented',
  }),
})

/** @type {Readonly<Record<string, string>>} */
const profileEvidenceCodes = Object.freeze({
  'transition.dissolve': 'DISSOLVE_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'transform.scale': 'TRANSFORM_SCALE_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'transform.position': 'TRANSFORM_POSITION_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  opacity: 'OPACITY_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'audio.fade': 'AUDIO_FADE_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'audio.volume.keyframe': 'AUDIO_VOLUME_KEYFRAME_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'filter.video.named': 'FILTER_VIDEO_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'filter.video.track_named': 'FILTER_VIDEO_TRACK_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'animation.video.named': 'ANIMATION_VIDEO_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'mask.video.named': 'MASK_VIDEO_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'blend.video.named': 'BLEND_VIDEO_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'background.video': 'BACKGROUND_VIDEO_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'sticker.named': 'STICKER_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'text.flower.private': 'FLOWER_TEXT_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'text.bubble.private': 'BUBBLE_TEXT_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'track.insert_many': 'TRACK_INSERT_MANY_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'audio.effect.named': 'AUDIO_EFFECT_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'speed.constant': 'SPEED_CONSTANT_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'audio.video.fade': 'AUDIO_VIDEO_FADE_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'chroma.video': 'CHROMA_VIDEO_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'animation.text.named': 'ANIMATION_TEXT_NAMED_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'transform.text.keyframe': 'TRANSFORM_TEXT_KEYFRAME_JIANYING_PROFILE_EVIDENCE_REQUIRED',
  'transform.sticker.keyframe': 'TRANSFORM_STICKER_KEYFRAME_JIANYING_PROFILE_EVIDENCE_REQUIRED',
})

/** @param {string | null} jianyingProfileId @param {string[]} [privateCatalogCapabilities] @param {string[]} [evidencedCapabilities] @param {ReadonlyArray<Record<string, unknown>>} [promotionReceipts] */
const capabilitiesForProfile = (jianyingProfileId, privateCatalogCapabilities = [], evidencedCapabilities = [], promotionReceipts = []) => {
  const promotions = typeof jianyingProfileId === 'string'
    ? profileScopedJianyingCapabilities[jianyingProfileId] ?? {}
    : {}
  return capabilities.map((entry) => {
    const catalogRequired = ['blend.video.named', 'background.video', 'sticker.named', 'text.flower.private', 'text.bubble.private', 'audio.effect.named', 'audio.video.fade', 'chroma.video', 'animation.video.named', 'mask.video.named', 'animation.text.named', 'transform.text.keyframe', 'transform.sticker.keyframe', 'filter.video.named', 'filter.video.track_named'].includes(entry.capabilityId)
    const exactEvidenceRequired = entry.capabilityId === 'transform.sticker.keyframe'
    const catalogAdmitted = catalogRequired && privateCatalogCapabilities.includes(entry.capabilityId)
    const promotionReceipt = promotionReceipts.find((receipt) => receipt.capabilityId === entry.capabilityId)
    if (entry.capabilityId === 'audio.sfx.local' &&
        isSfxCapabilityPromotionReceiptReady(promotionReceipt, jianyingProfileId)) {
      return {
        ...entry,
        targets: {
          preview: { status: 'degraded', degradationCode: 'SFX_PREVIEW_DEGRADED' },
          jianying: { status: 'implemented', degradationCode: null },
        },
        effectiveStatus: 'degraded',
        agentAuthorization: 'allowed',
      }
    }
    // A current runtime may have a detected profile that is not present in the
    // historical compatibility matrix. The server-created receipt is already
    // bound to the live executable, DLL fingerprint, catalog and same-draft
    // lifecycle, so it is the authoritative promotion for that profile.
    const dynamicPromotionReady = catalogAdmitted && isCapabilityPromotionReceiptReady(
      promotionReceipt,
      jianyingProfileId,
      entry.capabilityId,
    )
    if (catalogRequired && !privateCatalogCapabilities.includes(entry.capabilityId)) {
      return {
        ...entry,
        targets: {
          ...entry.targets,
          jianying: {
            status: 'unsupported',
            degradationCode: null,
          },
        },
        effectiveStatus: 'unsupported',
        agentAuthorization: 'denied',
      }
    }
    const promotedStatus = (catalogRequired && !catalogAdmitted) ||
      (exactEvidenceRequired && !evidencedCapabilities.includes(entry.capabilityId))
      ? undefined
      : dynamicPromotionReady
        ? 'implemented'
        : promotions[entry.capabilityId]
    const promotionReady = (Object.hasOwn(profileScopedJianyingCapabilities, jianyingProfileId ?? '') || dynamicPromotionReady) &&
      entry.targets.jianying.status === 'implemented' &&
      entry.effectiveStatus === 'implemented' &&
      isCapabilityPromotionReceiptReady(promotionReceipt, jianyingProfileId, entry.capabilityId)
    if (promotedStatus !== 'implemented') {
      const profileEvidenceCode = profileEvidenceCodes[entry.capabilityId]
      if (!profileEvidenceCode) return entry
      return {
        ...entry,
        targets: {
          ...entry.targets,
          jianying: {
            ...entry.targets.jianying,
            degradationCode: profileEvidenceCode,
          },
        },
        agentAuthorization: promotionReady ? 'allowed' : entry.agentAuthorization,
      }
    }
    return {
      ...entry,
      targets: {
        ...entry.targets,
        jianying: {
          status: promotedStatus,
          degradationCode: null,
        },
      },
      agentAuthorization: promotionReady ? 'allowed' : entry.agentAuthorization,
    }
  })
}

export class EditorCapabilityRegistryError extends Error {
  /** @param {string} code @param {number} [status] @param {string | null} [capabilityId] */
  constructor(code, status = 409, capabilityId = null) {
    super(code)
    this.name = 'EditorCapabilityRegistryError'
    this.code = code
    this.status = status
    this.capabilityId = capabilityId
  }
}

/** @param {string} capabilityId @returns {never} */
const denied = (capabilityId) => {
  throw new EditorCapabilityRegistryError(
    'EDITOR_CAPABILITY_UNAUTHORIZED',
    409,
    capabilityId,
  )
}

/**
 * @param {{jianyingProfileId?: string | null, privateCatalogCapabilities?: unknown, evidencedCapabilities?: unknown, promotionReceipts?: unknown}} [options]
 */
export const createEditorCapabilityRegistry = (options = {}) => {
  const jianyingProfileId = typeof options.jianyingProfileId === 'string'
    ? options.jianyingProfileId
    : null
  const privateCatalogCapabilities = Array.isArray(options.privateCatalogCapabilities)
    ? options.privateCatalogCapabilities.filter((value) => typeof value === 'string')
    : []
  const evidencedCapabilities = Array.isArray(options.evidencedCapabilities)
    ? options.evidencedCapabilities.filter((value) => typeof value === 'string')
    : []
  const promotionReceipts = Array.isArray(options.promotionReceipts)
    ? options.promotionReceipts.filter((value) => value && typeof value === 'object' && !Array.isArray(value))
    : []
  const profileCapabilities = capabilitiesForProfile(jianyingProfileId, privateCatalogCapabilities, evidencedCapabilities, promotionReceipts)
  /** @param {string} capabilityId */
  const dynamicPromotionReady = (capabilityId) => {
    const entry = profileCapabilities.find((candidate) => candidate.capabilityId === capabilityId)
    return privateCatalogCapabilities.includes(capabilityId) && isCapabilityPromotionReceiptReady(
      promotionReceipts.find((receipt) => receipt.capabilityId === capabilityId),
      jianyingProfileId,
      capabilityId,
    ) && entry?.targets?.jianying?.status === 'implemented'
  }
  const promotionReceiptSummary = promotionReceipts
    .filter((receipt) => typeof receipt.capabilityId === 'string' &&
      safeCapabilityIdPattern.test(receipt.capabilityId) &&
      typeof receipt.profileId === 'string' && safeProfileIdPattern.test(receipt.profileId) &&
      typeof receipt.receiptId === 'string' && promotionReceiptIdPattern.test(receipt.receiptId))
    .map((receipt) => ({
      capabilityId: receipt.capabilityId,
      profileId: receipt.profileId,
      receiptId: receipt.receiptId,
      ready: receipt.capabilityId === 'audio.sfx.local'
        ? isSfxCapabilityPromotionReceiptReady(receipt, jianyingProfileId)
        : isCapabilityPromotionReceiptReady(receipt, jianyingProfileId, receipt.capabilityId),
    }))
    .sort((left, right) => `${left.capabilityId}:${left.receiptId}`.localeCompare(`${right.capabilityId}:${right.receiptId}`))
  const registryFingerprint = fingerprintCanonical({
    version: registryVersion,
    jianyingProfileId,
    privateCatalogCapabilities,
    evidencedCapabilities,
    promotionReceiptSummary,
    capabilities: profileCapabilities,
  })
  const byId = new Map(profileCapabilities.map((entry) => [entry.capabilityId, entry]))

  /** @param {unknown} capabilityId */
  const requireAllowed = (capabilityId) => {
    if (typeof capabilityId !== 'string') denied(String(capabilityId ?? ''))
    const entry = byId.get(capabilityId)
    if (
      !entry ||
      entry.agentAuthorization !== 'allowed' ||
      entry.effectiveStatus === 'unsupported'
    ) {
      denied(capabilityId)
    }
    return structuredClone(entry)
  }

  /**
   * Writer-target gate: checks only the named target status (not effectiveStatus / Agent).
   * @param {unknown} capabilityId
   * @param {'preview' | 'jianying'} target
   */
  const assertWriterCapability = (capabilityId, target) => {
    if (typeof capabilityId !== 'string' || (target !== 'preview' && target !== 'jianying')) {
      denied(String(capabilityId ?? ''))
    }
    const entry = byId.get(capabilityId)
    const status = entry?.targets?.[target]?.status
    const requiredProfiles = target === 'jianying'
      ? Object.entries(profileScopedJianyingCapabilities)
        .filter(([, scopedCapabilities]) => Object.hasOwn(scopedCapabilities, capabilityId))
        .map(([profileId]) => profileId)
      : []
    if (
      !entry ||
      status === 'unsupported' ||
      (requiredProfiles.length > 0 &&
        !requiredProfiles.includes(jianyingProfileId ?? '') &&
        !dynamicPromotionReady(capabilityId))
    ) {
      throw new EditorCapabilityRegistryError(
        'EDITOR_CAPABILITY_UNAUTHORIZED',
        409,
        capabilityId,
      )
    }
    return structuredClone(entry)
  }

  /**
   * @param {string} capabilityId
   * @param {Record<string, unknown>} parameters
   * @param {{writerTarget?: 'preview' | 'jianying'}} [options]
   */
  const assertAllowedParameters = (capabilityId, parameters, options = {}) => {
    const entry = options.writerTarget
      ? assertWriterCapability(capabilityId, options.writerTarget)
      : requireAllowed(capabilityId)
    const allowed = entry.allowedParameters ?? {}
    const keys = Object.keys(parameters ?? {}).sort()
    const expected = Object.keys(allowed).sort()
    if (keys.join('\u0000') !== expected.join('\u0000')) {
      throw new EditorCapabilityRegistryError(
        'EDITOR_CAPABILITY_PARAMETERS_INVALID',
        400,
        capabilityId,
      )
    }
    for (const [key, rule] of Object.entries(allowed)) {
      const value = parameters[key]
      if (!rule || typeof rule !== 'object') continue
      const spec = /** @type {Record<string, unknown>} */ (rule)
      if (spec.type === 'opaque_id') {
        if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)) {
          throw new EditorCapabilityRegistryError(
            'EDITOR_CAPABILITY_PARAMETERS_INVALID',
            400,
            capabilityId,
          )
        }
        continue
      }
      if (spec.type === 'rgba_hex') {
        if (typeof value !== 'string' || !/^#[0-9A-Fa-f]{8}$/u.test(value)) {
          throw new EditorCapabilityRegistryError(
            'EDITOR_CAPABILITY_PARAMETERS_INVALID',
            400,
            capabilityId,
          )
        }
        continue
      }
      if (
        typeof value !== 'number' ||
        !Number.isFinite(value) ||
        (typeof spec.minimum === 'number' && value < spec.minimum) ||
        (typeof spec.maximum === 'number' && value > spec.maximum)
      ) {
        throw new EditorCapabilityRegistryError(
          'EDITOR_CAPABILITY_PARAMETERS_INVALID',
          400,
          capabilityId,
        )
      }
    }
    return entry
  }

  /** @param {unknown} timeline */
  const assertTimelineCapabilities = (timeline) => {
    if (!timeline || typeof timeline !== 'object') {
      throw new EditorCapabilityRegistryError('EDITOR_CAPABILITY_TIMELINE_INVALID', 400)
    }
    const candidate = /** @type {Record<string, any>} */ (timeline)
    if (!Array.isArray(candidate.capabilityRequirements)) {
      throw new EditorCapabilityRegistryError('EDITOR_CAPABILITY_TIMELINE_INVALID', 400)
    }
    for (const requirement of candidate.capabilityRequirements) {
      requireAllowed(requirement?.capabilityId)
    }
    return timeline
  }

  return {
    registryFingerprint,
    list: () => ({
      registryFingerprint,
      promotionReceipts: structuredClone(promotionReceiptSummary),
      capabilities: structuredClone(profileCapabilities),
    }),
    requireAllowed,
    assertWriterCapability,
    assertAllowedParameters,
    assertTimelineCapabilities,
  }
}
