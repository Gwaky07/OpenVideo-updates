import { readFile } from 'node:fs/promises'
import { createServer } from 'node:http'

import { loadGatewayConfig } from './config.mjs'
import { createGateway } from './gateway.mjs'
import { createOllamaBridgeHandler } from './ollama-bridge.mjs'

const privateConfigPath = process.env.OPENVIDEO_LLM_PRIVATE_CONFIG
const modelAlias = process.env.OPENVIDEO_OLLAMA_MODEL_ALIAS
const port = Number(process.env.OPENVIDEO_OLLAMA_BRIDGE_PORT ?? '11434')
if (!privateConfigPath || !modelAlias || !Number.isInteger(port) || port < 1 || port > 65_535) {
  throw new Error('OPENVIDEO_OLLAMA_BRIDGE_CONFIG_INVALID')
}

const privateConfig = JSON.parse(await readFile(privateConfigPath, 'utf8'))
const key = privateConfig.api_key
const config = loadGatewayConfig({
  OPENVIDEO_LLM_PROVIDER: privateConfig.provider,
  OPENVIDEO_LLM_BASE_URL: privateConfig.base_url,
  OPENVIDEO_LLM_API_KEY: key,
  OPENVIDEO_LLM_TEXT_MODEL: privateConfig.text_model,
  OPENVIDEO_LLM_VISION_MODEL: privateConfig.vision_model,
  OPENVIDEO_LLM_JSON_MODEL: privateConfig.json_model,
})
const handler = createOllamaBridgeHandler({
  modelAlias,
  gateway: createGateway({ config }),
})

createServer(async (incoming, outgoing) => {
  try {
    const chunks = []
    let size = 0
    for await (const chunk of incoming) {
      size += chunk.length
      if (size > 1_048_576) throw new Error('request_too_large')
      chunks.push(chunk)
    }
    const request = new Request(`http://ollama-bridge${incoming.url ?? '/'}`, {
      method: incoming.method ?? 'GET',
      body: chunks.length > 0 ? Buffer.concat(chunks) : undefined,
    })
    const response = await handler(request)
    outgoing.writeHead(response.status, Object.fromEntries(response.headers.entries()))
    outgoing.end(Buffer.from(await response.arrayBuffer()))
  } catch {
    outgoing.writeHead(400, { 'content-type': 'application/json' })
    outgoing.end('{"error":"invalid_request"}')
  }
}).listen(port, '0.0.0.0', () => {
  console.log(`OpenVideo Ollama bridge listening on port ${port}`)
})
