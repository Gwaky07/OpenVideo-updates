import { randomUUID } from 'node:crypto'
import { lstat, mkdir, open, realpath, rename, rm } from 'node:fs/promises'
import path from 'node:path'

import { securePrivateRuntimeRoot } from './local-runtime.mjs'

const schemaVersion = 1
const fileName = 'jianying-writer-publications.json'
const terminalStates = new Set(['committed', 'rolled_back'])
const states = new Set(['claimed', 'publishing', 'published', 'settling', 'rollback_failed', ...terminalStates])
const activeLockTokens = new Set()
/** @type {Map<string, {opened: BoundStateFile, token: string}>} */
const pendingCreatedLocks = new Map()
const identifier = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}$/u
const fingerprint = /^[a-f0-9]{32,128}$/u

/** @typedef {{path: string, identity: string, parent: string, parentIdentity: string, testIoHook?: (event: {phase: 'read_opened'|'write_opened'|'after_rename'|'lock_written'|'lock_release_verified'|'lock_cleanup_started'|'lock_tombstoned', path: string}) => Promise<void>}} PublicationRootBinding */

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} error */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error
  ? String(/** @type {{code?: unknown}} */ (error).code)
  : ''
/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 500) => {
  const error = /** @type {Error & {code: string, status: number}} */ (new Error(code))
  error.code = code
  error.status = status
  throw error
}
/** @param {unknown} value */
const validId = (value) => typeof value === 'string' && identifier.test(value)
/** @param {unknown} value */
const validFingerprint = (value) => typeof value === 'string' && fingerprint.test(value)
/** @param {unknown} value */
const validTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @param {string} parent @param {string} candidate */
const inside = (parent, candidate) => {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}
/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)
/** @param {import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`
/**
 * Windows may return a short 8.3 alias from realpath for an existing long path.
 * Accept that alias only when both names resolve to the exact same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}
/** @param {string} target */
const bindRepositoryRoot = async (target) => {
  const resolved = path.resolve(target)
  const parent = path.dirname(resolved)
  const [metadata, parentMetadata, actual, actualParent] = await Promise.all([
    lstat(resolved, { bigint: true }),
    lstat(parent, { bigint: true }),
    realpath(resolved),
    realpath(parent),
  ])
  const [sameRoot, sameParent] = await Promise.all([
    sameResolvedObject(resolved, actual, metadata),
    sameResolvedObject(parent, actualParent, parentMetadata),
  ])
  if (!metadata.isDirectory() || metadata.isSymbolicLink() || !sameRoot ||
      !parentMetadata.isDirectory() || parentMetadata.isSymbolicLink() || !sameParent) {
    fail('JY200_WRITER_PUBLICATION_ROOT_UNSAFE')
  }
  return Object.freeze({
    path: resolved,
    identity: objectIdentity(metadata),
    parent,
    parentIdentity: objectIdentity(parentMetadata),
  })
}
/** @param {PublicationRootBinding} binding */
const assertRepositoryRootBinding = async (binding) => {
  const current = await bindRepositoryRoot(binding.path).catch(() => null)
  if (!current || current.identity !== binding.identity || current.parent !== binding.parent ||
      current.parentIdentity !== binding.parentIdentity) fail('JY200_WRITER_PUBLICATION_ROOT_REPLACED')
}
/** @typedef {{handle: import('node:fs/promises').FileHandle, identity: string, path: string}} BoundStateFile */
/** @param {string} target @param {PublicationRootBinding} binding */
const resolveStatePath = (target, binding) => {
  const resolved = path.resolve(target)
  if (!inside(binding.path, resolved) || path.dirname(resolved) !== binding.path) {
    fail('JY200_WRITER_PUBLICATION_PATH_UNSAFE')
  }
  return resolved
}
/** @param {import('node:fs').BigIntStats} metadata */
const assertOrdinaryStateMetadata = (metadata) => {
  if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.nlink !== 1n) {
    fail('JY200_WRITER_PUBLICATION_REPARSE_REJECTED')
  }
}
/** @param {BoundStateFile} opened @param {PublicationRootBinding} binding */
const assertBoundStateFile = async (opened, binding) => {
  await assertRepositoryRootBinding(binding)
  const [openedMetadata, pathMetadata, actual] = await Promise.all([
    opened.handle.stat({ bigint: true }),
    lstat(opened.path, { bigint: true }),
    realpath(opened.path),
  ])
  assertOrdinaryStateMetadata(openedMetadata)
  assertOrdinaryStateMetadata(pathMetadata)
  if (objectIdentity(openedMetadata) !== opened.identity || objectIdentity(pathMetadata) !== opened.identity ||
      !await sameResolvedObject(opened.path, actual, pathMetadata)) {
    fail('JY200_WRITER_PUBLICATION_FILE_REPLACED')
  }
  await assertRepositoryRootBinding(binding)
}
/** @param {string} target @param {string} identity @param {PublicationRootBinding} binding */
const assertStatePathIdentity = async (target, identity, binding) => {
  await assertRepositoryRootBinding(binding)
  const resolved = resolveStatePath(target, binding)
  const [metadata, actual] = await Promise.all([lstat(resolved, { bigint: true }), realpath(resolved)])
  assertOrdinaryStateMetadata(metadata)
  if (objectIdentity(metadata) !== identity || !await sameResolvedObject(resolved, actual, metadata)) {
    fail('JY200_WRITER_PUBLICATION_FILE_REPLACED')
  }
  await assertRepositoryRootBinding(binding)
}
/** @param {string} target @param {PublicationRootBinding} binding @param {boolean} [allowMissing] */
const openBoundStateFile = async (target, binding, allowMissing = false) => {
  await assertRepositoryRootBinding(binding)
  const resolved = resolveStatePath(target, binding)
  let pathMetadata
  try { pathMetadata = await lstat(resolved, { bigint: true }) } catch (error) {
    if (allowMissing && errorCode(error) === 'ENOENT') return null
    throw error
  }
  assertOrdinaryStateMetadata(pathMetadata)
  let actual
  let handle
  try {
    actual = await realpath(resolved)
    handle = await open(resolved, 'r')
  } catch (error) {
    if (allowMissing && errorCode(error) === 'ENOENT') return null
    throw error
  }
  if (!await sameResolvedObject(resolved, actual, pathMetadata)) {
    await handle.close()
    fail('JY200_WRITER_PUBLICATION_REPARSE_REJECTED')
  }
  const opened = { handle, identity: objectIdentity(pathMetadata), path: resolved }
  try {
    await binding.testIoHook?.({ phase: 'read_opened', path: resolved })
    await assertBoundStateFile(opened, binding)
    return opened
  } catch (error) {
    await handle.close().catch(() => {})
    throw error
  }
}
/** @param {string} target @param {PublicationRootBinding} binding */
const createBoundStateFile = async (target, binding) => {
  await assertRepositoryRootBinding(binding)
  const resolved = resolveStatePath(target, binding)
  const handle = await open(resolved, 'wx', 0o600)
  try {
    const metadata = await handle.stat({ bigint: true })
    assertOrdinaryStateMetadata(metadata)
    const opened = { handle, identity: objectIdentity(metadata), path: resolved }
    await binding.testIoHook?.({ phase: 'write_opened', path: resolved })
    await assertBoundStateFile(opened, binding)
    return opened
  } catch (error) {
    await handle.close().catch(() => {})
    throw error
  }
}
/** @param {string} target @param {PublicationRootBinding} binding @param {boolean} [allowMissing] */
const readBoundStateFile = async (target, binding, allowMissing = false) => {
  const opened = await openBoundStateFile(target, binding, allowMissing)
  if (!opened) return null
  try {
    const content = await opened.handle.readFile('utf8')
    await assertBoundStateFile(opened, binding)
    return content
  } finally {
    await opened.handle.close()
  }
}
/** @param {number} milliseconds */
const delay = (milliseconds) => new Promise((resolveDelay) => setTimeout(resolveDelay, milliseconds))

/** @param {unknown} value */
const validPublication = (value) => isRecord(value) &&
  validId(value.publicationId) &&
  validId(value.providerId) &&
  typeof value.draftName === 'string' && value.draftName.length > 0 && value.draftName.length <= 200 &&
  path.isAbsolute(value.liveRoot) &&
  path.isAbsolute(value.liveParent) &&
  validId(value.liveRootIdentity) &&
  validId(value.liveParentGeneration) &&
  validId(value.artifactIdentity) &&
  (value.destinationIdentity === null || validId(value.destinationIdentity)) &&
  (value.destinationGeneration === null || validId(value.destinationGeneration)) &&
  (value.tombstoneName === null || (typeof value.tombstoneName === 'string' && /^\.openvideo-delete-[a-f0-9]{32}$/u.test(value.tombstoneName)))

/** @param {unknown} value */
const validRecord = (value) => isRecord(value) &&
  validId(value.jobId) && validId(value.requestId) && validId(value.ownerId) &&
  (value.providerCommit === null || (typeof value.providerCommit === 'string' && /^[a-f0-9]{40}$/u.test(value.providerCommit))) &&
  (value.buildDigest === null || validFingerprint(value.buildDigest)) &&
  (value.adapterRevision === null || validId(value.adapterRevision)) &&
  (value.evidenceFingerprint === null || validFingerprint(value.evidenceFingerprint)) &&
  validFingerprint(value.timelineFingerprint) && states.has(value.state) &&
  (value.publication === null || validPublication(value.publication)) &&
  validTimestamp(value.createdAt) && validTimestamp(value.updatedAt) &&
  (value.settledAt === null || validTimestamp(value.settledAt)) &&
  (value.ownerCompletedAt === null || validTimestamp(value.ownerCompletedAt)) &&
  (value.lastFailure === null || (typeof value.lastFailure === 'string' && /^JY200_[A-Z0-9_]{1,120}$/u.test(value.lastFailure))) &&
  (value.state === 'claimed' || value.state === 'rolled_back' || value.publication !== null ||
    value.ownerId === 'native-writer') &&
  (!terminalStates.has(value.state) || value.settledAt !== null)

/** @param {unknown} value */
const validDocument = (value) => isRecord(value) && value.schema_version === schemaVersion &&
  Array.isArray(value.records) && value.records.every(validRecord) &&
  new Set(value.records.map((entry) => entry.jobId)).size === value.records.length

/** @param {BoundStateFile} source @param {string} destination @param {PublicationRootBinding} binding */
const renameWithRetries = async (source, destination, binding) => {
  await assertBoundStateFile(source, binding)
  await source.handle.close()
  for (let attempt = 0; attempt < 20; attempt += 1) {
    try {
      await rename(source.path, destination)
      source.path = path.resolve(destination)
      await binding.testIoHook?.({ phase: 'after_rename', path: source.path })
      await assertStatePathIdentity(source.path, source.identity, binding)
      return
    } catch (error) {
      if (!['EPERM', 'EBUSY', 'EACCES'].includes(errorCode(error)) || attempt === 19) throw error
      await delay(10)
    }
  }
}

/** @param {string} target @param {unknown} document @param {PublicationRootBinding} binding */
const writeAtomic = async (target, document, binding) => {
  const temporary = `${target}.${randomUUID()}.tmp`
  const backup = `${target}.bak`
  /** @type {BoundStateFile | null} */
  let primary = null
  /** @type {BoundStateFile | null} */
  let next = null
  try {
    primary = await openBoundStateFile(target, binding, true)
    next = await createBoundStateFile(temporary, binding)
    await next.handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await next.handle.sync()
    await assertBoundStateFile(next, binding)
    if (primary) {
      const existingBackup = await openBoundStateFile(backup, binding, true)
      await existingBackup?.handle.close().catch(() => {})
      const backupTemporary = `${backup}.${randomUUID()}.tmp`
      const backupNext = await createBoundStateFile(backupTemporary, binding)
      try {
        const primaryBytes = await primary.handle.readFile()
        await assertBoundStateFile(primary, binding)
        await backupNext.handle.writeFile(primaryBytes)
        await backupNext.handle.sync()
        await assertBoundStateFile(backupNext, binding)
        await primary.handle.close()
        await renameWithRetries(backupNext, backup, binding)
      } finally {
        await backupNext.handle.close().catch(() => {})
        await rm(backupTemporary, { force: true }).catch(() => {})
      }
    }
    await renameWithRetries(next, target, binding)
  } catch (error) {
    throw error
  } finally {
    await primary?.handle.close().catch(() => {})
    await next?.handle.close().catch(() => {})
    await rm(temporary, { force: true }).catch(() => {})
  }
}

/** @param {string} target @param {unknown} document @param {PublicationRootBinding} binding */
const repairPrimary = async (target, document, binding) => {
  const temporary = `${target}.${randomUUID()}.repair`
  const next = await createBoundStateFile(temporary, binding)
  try {
    await next.handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await next.handle.sync()
    await assertBoundStateFile(next, binding)
    await renameWithRetries(next, target, binding)
  } finally {
    await next.handle.close().catch(() => {})
    await rm(temporary, { force: true }).catch(() => {})
  }
}

/** @param {string} target @param {PublicationRootBinding} binding @param {boolean} [allowCreate] */
const readDocument = async (target, binding, allowCreate = false) => {
  try {
    const primaryText = await readBoundStateFile(target, binding, true)
    if (primaryText === null) {
      const missing = /** @type {NodeJS.ErrnoException} */ (new Error('missing_primary'))
      missing.code = 'ENOENT'
      throw missing
    }
    const primary = JSON.parse(primaryText)
    if (!validDocument(primary)) throw new Error('invalid_primary')
    return primary
  } catch (primaryError) {
    if (errorCode(primaryError).startsWith('JY200_WRITER_PUBLICATION_')) throw primaryError
    try {
      const backupText = await readBoundStateFile(`${target}.bak`, binding, true)
      if (backupText === null) {
        const missing = /** @type {NodeJS.ErrnoException} */ (new Error('missing_backup'))
        missing.code = 'ENOENT'
        throw missing
      }
      const backup = JSON.parse(backupText)
      if (!validDocument(backup)) throw new Error('invalid_backup')
      await repairPrimary(target, backup, binding)
      return backup
    } catch (backupError) {
      if (errorCode(backupError).startsWith('JY200_WRITER_PUBLICATION_')) throw backupError
      if (allowCreate && errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') {
        return { schema_version: schemaVersion, records: [] }
      }
      fail('JY200_WRITER_PUBLICATION_STORAGE_CORRUPT')
    }
  }
}

/** @param {string} lockPath @param {string} expected @param {PublicationRootBinding} binding */
const removeOwnedLock = async (lockPath, expected, binding) => {
  const opened = await openBoundStateFile(lockPath, binding, true)
  if (!opened) return true
  try {
    const current = await opened.handle.readFile('utf8')
    await assertBoundStateFile(opened, binding)
    if (current !== expected) fail('JY200_WRITER_PUBLICATION_LOCK_OWNER_MISMATCH', 503)
    await binding.testIoHook?.({ phase: 'lock_release_verified', path: opened.path })
    if (!await discardCreatedStateFile(opened, binding)) {
      fail('JY200_WRITER_PUBLICATION_LOCK_RELEASE_FAILED', 503)
    }
    return true
  } catch (error) {
    if (errorCode(error) === 'ENOENT') return true
    throw error
  } finally {
    await opened.handle.close().catch(() => {})
  }
}

/** @param {BoundStateFile} opened @param {PublicationRootBinding} binding */
const discardCreatedStateFile = async (opened, binding) => {
  const originalPath = opened.path
  const tombstone = `${originalPath}.${randomUUID()}.discard`
  try {
    await assertRepositoryRootBinding(binding)
    const [openedMetadata, pathMetadata, actual] = await Promise.all([
      opened.handle.stat({ bigint: true }),
      lstat(originalPath, { bigint: true }),
      realpath(originalPath),
    ])
    if (!openedMetadata.isFile() || openedMetadata.isSymbolicLink() ||
        !pathMetadata.isFile() || pathMetadata.isSymbolicLink() ||
        objectIdentity(openedMetadata) !== opened.identity ||
        objectIdentity(pathMetadata) !== opened.identity ||
        !await sameResolvedObject(originalPath, actual, pathMetadata)) return false
    let renamed = false
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        await binding.testIoHook?.({ phase: 'lock_cleanup_started', path: originalPath })
        await rename(originalPath, tombstone)
        renamed = true
        break
      } catch (error) {
        if (!['EACCES', 'EBUSY', 'EPERM'].includes(errorCode(error)) || attempt === 4) return false
        await delay(10 * (attempt + 1))
      }
    }
    if (!renamed) return false
    opened.path = tombstone
    await binding.testIoHook?.({ phase: 'lock_tombstoned', path: tombstone })
    const [retainedMetadata, retainedActual] = await Promise.all([
      lstat(tombstone, { bigint: true }),
      realpath(tombstone),
    ])
    if (!retainedMetadata.isFile() || retainedMetadata.isSymbolicLink() ||
        objectIdentity(retainedMetadata) !== opened.identity ||
        !await sameResolvedObject(tombstone, retainedActual, retainedMetadata)) return false
    await rm(tombstone)
    await assertRepositoryRootBinding(binding)
    return true
  } catch {
    return false
  }
}

/** @param {string} lockPath @param {PublicationRootBinding} binding */
const recoverPendingCreatedLock = async (lockPath, binding) => {
  const key = path.resolve(lockPath)
  const pending = pendingCreatedLocks.get(key)
  if (!pending) return false
  const removed = await discardCreatedStateFile(pending.opened, binding)
  if (!removed) return false
  await pending.opened.handle.close().catch(() => {})
  pendingCreatedLocks.delete(key)
  activeLockTokens.delete(pending.token)
  return true
}

/** @param {string} lockPath @param {PublicationRootBinding} binding */
const acquireLock = async (lockPath, binding) => {
  const token = randomUUID()
  const owner = `${JSON.stringify({ pid: process.pid, token })}\n`
  for (let attempt = 0; attempt < 500; attempt += 1) {
    if (pendingCreatedLocks.has(path.resolve(lockPath))) {
      if (await recoverPendingCreatedLock(lockPath, binding)) continue
      await delay(10)
      continue
    }
    /** @type {import('node:fs/promises').FileHandle | null} */
    let handle = null
    /** @type {BoundStateFile | null} */
    let createdLock = null
    try {
      await assertRepositoryRootBinding(binding)
      handle = await open(lockPath, 'wx', 0o600)
      const metadata = await handle.stat({ bigint: true })
      assertOrdinaryStateMetadata(metadata)
      const opened = { handle, identity: objectIdentity(metadata), path: path.resolve(lockPath) }
      createdLock = opened
      await binding.testIoHook?.({ phase: 'write_opened', path: opened.path })
      await assertBoundStateFile(opened, binding)
      activeLockTokens.add(token)
      await handle.writeFile(owner, 'utf8')
      await binding.testIoHook?.({ phase: 'lock_written', path: opened.path })
      await handle.sync()
      await assertBoundStateFile(opened, binding)
      return { handle, owner, token }
    } catch (error) {
      let retainedForRecovery = false
      try {
        if (handle) {
          if (!createdLock) {
            const metadata = await handle.stat({ bigint: true }).catch(() => null)
            if (metadata?.isFile() && !metadata.isSymbolicLink()) {
              createdLock = { handle, identity: objectIdentity(metadata), path: path.resolve(lockPath) }
            }
          }
          if (createdLock && !await discardCreatedStateFile(createdLock, binding) &&
              samePath(createdLock.path, path.resolve(lockPath))) {
            pendingCreatedLocks.set(path.resolve(lockPath), { opened: createdLock, token })
            activeLockTokens.add(token)
            retainedForRecovery = true
          }
          if (!retainedForRecovery) await handle.close().catch(() => {})
        }
      } finally {
        if (!retainedForRecovery) activeLockTokens.delete(token)
      }
      if (errorCode(error) !== 'EEXIST') throw error
      let existingFile
      try {
        existingFile = await openBoundStateFile(lockPath, binding, true)
      } catch (lockReadError) {
        // The current owner may release the lock between our EEXIST result and
        // the bound read. Retry acquisition instead of surfacing that race.
        if (['ENOENT', 'EBADF'].includes(errorCode(lockReadError))) continue
        throw lockReadError
      }
      if (!existingFile) continue
      let existing = null
      let metadata = null
      let releasedDuringRead = false
      try {
        existing = await existingFile.handle.readFile('utf8')
        metadata = await existingFile.handle.stat()
        await assertBoundStateFile(existingFile, binding)
      } catch (lockReadError) {
        // A valid owner can atomically tombstone its lock after this contender
        // opens the old object. Re-open and fully validate on the next bounded
        // attempt; a persistent replacement still exhausts the lock budget.
        if (['ENOENT', 'EBADF', 'JY200_WRITER_PUBLICATION_FILE_REPLACED'].includes(errorCode(lockReadError))) {
          releasedDuringRead = true
        }
        else throw lockReadError
      } finally {
        await existingFile.handle.close()
      }
      if (releasedDuringRead) continue
      let parsed = null
      let processAlive = true
      try {
        parsed = JSON.parse(existing ?? '')
        if (!Number.isSafeInteger(parsed?.pid) || typeof parsed?.token !== 'string') throw new Error('invalid')
        process.kill(parsed.pid, 0)
      } catch (processError) {
        processAlive = errorCode(processError) !== 'ESRCH'
      }
      const orphanedHere = parsed?.pid === process.pid && !activeLockTokens.has(parsed?.token)
      const abandoned = metadata && Date.now() - metadata.mtimeMs > 5 * 60_000 && (!parsed || !processAlive)
      if (existing !== null && (orphanedHere || abandoned) && await removeOwnedLock(lockPath, existing, binding)) continue
      await delay(10)
    }
  }
  fail('JY200_WRITER_PUBLICATION_STORAGE_LOCKED', 503)
}

/** @param {string} lockPath @param {{handle: import('node:fs/promises').FileHandle, owner: string, token: string}} lock @param {PublicationRootBinding} binding */
const releaseLock = async (lockPath, lock, binding) => {
  try {
    await lock.handle.close().catch(() => {})
    if (!await removeOwnedLock(lockPath, lock.owner, binding)) {
      fail('JY200_WRITER_PUBLICATION_LOCK_RELEASE_FAILED', 503)
    }
  } finally {
    activeLockTokens.delete(lock.token)
  }
}

/** @param {Record<string, any>} record */
const ownerProjection = (record) => Object.freeze({
  jobId: record.jobId,
  requestId: record.requestId,
  ownerId: record.ownerId,
  providerCommit: record.providerCommit,
  buildDigest: record.buildDigest,
  adapterRevision: record.adapterRevision,
  evidenceFingerprint: record.evidenceFingerprint,
  timelineFingerprint: record.timelineFingerprint,
})

/**
 * A single private durable state machine owns both Writer selection and live
 * publication recovery, preventing split-brain between two repositories.
 * @param {{dataRoot: string, repositoryRoot: string, securePrivateRoot?: (root: string) => Promise<void>, now?: () => Date, testIoHook?: (event: {phase: 'read_opened'|'write_opened'|'after_rename'|'lock_written'|'lock_release_verified'|'lock_cleanup_started'|'lock_tombstoned', path: string}) => Promise<void>}} options
 */
export const createJianyingWriterPublicationRepository = async ({
  dataRoot,
  repositoryRoot,
  securePrivateRoot = securePrivateRuntimeRoot,
  now = () => new Date(),
  testIoHook = undefined,
}) => {
  if (!path.isAbsolute(dataRoot) || !path.isAbsolute(repositoryRoot) ||
      inside(repositoryRoot, dataRoot) || inside(dataRoot, repositoryRoot)) fail('JY200_WRITER_PUBLICATION_DATA_ROOT_UNSAFE', 400)
  const root = path.join(path.resolve(dataRoot), 'jianying-external-writers')
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRoot(root)
  const rootBinding = Object.freeze({ ...await bindRepositoryRoot(root), testIoHook })
  const storePath = path.join(root, fileName)
  const lockPath = `${storePath}.lock`
  /** @type {Promise<unknown>} */
  let queue = Promise.resolve()

  /** @template T @param {(document: Record<string, any>) => T | Promise<T>} operation */
  const mutate = (operation) => {
    const run = async () => {
      const lock = await acquireLock(lockPath, rootBinding)
      try {
        const document = clone(await readDocument(storePath, rootBinding, true))
        const result = await operation(document)
        if (!validDocument(document)) fail('JY200_WRITER_PUBLICATION_DOCUMENT_INVALID')
        await writeAtomic(storePath, document, rootBinding)
        return clone(result)
      } finally {
        await releaseLock(lockPath, lock, rootBinding)
      }
    }
    const result = queue.then(run, run)
    queue = result.then(() => undefined, () => undefined)
    return result
  }
  const read = async () => clone(await readDocument(storePath, rootBinding, true))
  await mutate((document) => document.records.length)

  const repository = {
    storePath,
    ownerRepository: {
      /** @param {Record<string, any>} input */
      async claim(input) {
        if (!isRecord(input) || !validId(input.jobId) || !validId(input.requestId) || !validId(input.ownerId) ||
            !validFingerprint(input.timelineFingerprint)) return false
        return mutate((document) => {
          const existing = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
          if (existing) {
            if (existing.state === 'rolled_back' && existing.ownerCompletedAt !== null) {
              const timestamp = now().toISOString()
              Object.assign(existing, {
                requestId: input.requestId,
                ownerId: input.ownerId,
                providerCommit: input.providerCommit ?? null,
                buildDigest: input.buildDigest ?? null,
                adapterRevision: input.adapterRevision ?? null,
                evidenceFingerprint: input.evidenceFingerprint ?? null,
                timelineFingerprint: input.timelineFingerprint,
                state: 'claimed',
                publication: null,
                updatedAt: timestamp,
                settledAt: null,
                ownerCompletedAt: null,
                lastFailure: null,
              })
              return ownerProjection(existing)
            }
            const expected = ownerProjection(existing)
            const replay = Object.entries(expected).every(([key, value]) => input[key] === value)
            return replay && existing.ownerCompletedAt === null ? expected : false
          }
          const timestamp = now().toISOString()
          const record = {
            jobId: input.jobId,
            requestId: input.requestId,
            ownerId: input.ownerId,
            providerCommit: input.providerCommit ?? null,
            buildDigest: input.buildDigest ?? null,
            adapterRevision: input.adapterRevision ?? null,
            evidenceFingerprint: input.evidenceFingerprint ?? null,
            timelineFingerprint: input.timelineFingerprint,
            state: 'claimed',
            publication: null,
            createdAt: timestamp,
            updatedAt: timestamp,
            settledAt: null,
            ownerCompletedAt: null,
            lastFailure: null,
          }
          document.records.push(record)
          return ownerProjection(record)
        })
      },
      /** @param {string} jobId */
      async get(jobId) {
        const record = (await read()).records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === jobId)
        return record && record.ownerCompletedAt === null ? ownerProjection(record) : null
      },
      /** @param {string} jobId */
      async getTerminal(jobId) {
        const record = (await read()).records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === jobId)
        if (!record || record.ownerCompletedAt === null || !terminalStates.has(record.state)) return null
        return Object.freeze({ ownerId: record.ownerId, state: record.state })
      },
      /** @param {{jobId: string, ownerId: string, action: string}} input */
      async complete(input) {
        return mutate((document) => {
          const record = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
          const expectedState = input.action === 'commit' ? 'committed' : input.action === 'cleanup' ? 'rolled_back' : null
          if (!record || record.ownerId !== input.ownerId || !expectedState) return false
          if (record.ownerCompletedAt !== null) return true
          const timestamp = now().toISOString()
          if (record.ownerId === 'native-writer' && record.state === 'claimed') {
            record.state = expectedState
            record.settledAt = timestamp
          }
          if (record.state !== expectedState) return false
          record.ownerCompletedAt = timestamp
          record.updatedAt = record.ownerCompletedAt
          return true
        })
      },
    },
    /** @param {string} jobId */
    async getPrivate(jobId) {
      const record = (await read()).records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === jobId)
      return record ? clone(record) : null
    },
    /** @param {Record<string, any>} input */
    async preparePublication(input) {
      return mutate((document) => {
        const record = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
        if (!record || record.ownerId !== input.providerId || record.state !== 'claimed' || record.publication !== null ||
            record.timelineFingerprint !== input.timelineFingerprint || !validPublication(input.publication)) return false
        record.publication = clone(input.publication)
        record.state = 'publishing'
        record.updatedAt = now().toISOString()
        return true
      })
    },
    /** @param {{jobId: string, publicationId: string, destinationIdentity: string, destinationGeneration: string}} input */
    async markPublished(input) {
      return mutate((document) => {
        const record = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
        if (!record?.publication || record.state !== 'publishing' || record.publication.publicationId !== input.publicationId ||
            !validId(input.destinationIdentity) || !validId(input.destinationGeneration)) return false
        record.publication.destinationIdentity = input.destinationIdentity
        record.publication.destinationGeneration = input.destinationGeneration
        record.state = 'published'
        record.updatedAt = now().toISOString()
        return true
      })
    },
    /** @param {{jobId: string, publicationId: string, tombstoneName: string}} input */
    async beginRollback(input) {
      return mutate((document) => {
        const record = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
        if (!record?.publication || !['publishing', 'published', 'rollback_failed'].includes(record.state) ||
            record.publication.publicationId !== input.publicationId || !/^\.openvideo-delete-[a-f0-9]{32}$/u.test(input.tombstoneName)) return false
        record.publication.tombstoneName = input.tombstoneName
        record.state = 'settling'
        record.updatedAt = now().toISOString()
        record.lastFailure = null
        return true
      })
    },
    /** @param {{jobId: string, publicationId?: string, state: 'committed'|'rolled_back'}} input */
    async settle(input) {
      return mutate((document) => {
        const record = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
        if (!record || terminalStates.has(record.state)) return record?.state === input.state
        if (input.publicationId && record.publication?.publicationId !== input.publicationId) return false
        if (input.state === 'committed' && record.state !== 'published') return false
        if (input.state === 'rolled_back' && !['claimed', 'publishing', 'settling', 'rollback_failed'].includes(record.state)) return false
        record.state = input.state
        record.settledAt = now().toISOString()
        record.updatedAt = record.settledAt
        record.lastFailure = null
        return true
      })
    },
    /** @param {{jobId: string, code: string}} input */
    async markRollbackFailed(input) {
      return mutate((document) => {
        const record = document.records.find((/** @type {Record<string, any>} */ entry) => entry.jobId === input.jobId)
        if (!record || terminalStates.has(record.state) || !/^JY200_[A-Z0-9_]{1,120}$/u.test(input.code)) return false
        record.state = 'rollback_failed'
        record.lastFailure = input.code
        record.updatedAt = now().toISOString()
        return true
      })
    },
    async listPending() {
      return (await read()).records
        .filter((/** @type {Record<string, any>} */ entry) => !terminalStates.has(entry.state))
        .map((/** @type {Record<string, any>} */ entry) => clone(entry))
    },
  }
  return Object.freeze(repository)
}
