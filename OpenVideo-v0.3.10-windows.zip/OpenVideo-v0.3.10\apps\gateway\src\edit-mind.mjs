import { execFile } from 'node:child_process'
import { createHash, createHmac, randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import {
  chmod,
  copyFile,
  lstat,
  mkdir,
  mkdtemp,
  open,
  opendir,
  readFile,
  realpath,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { dirname, extname, isAbsolute, relative, resolve } from 'node:path'
import { promisify } from 'node:util'

export const EDIT_MIND_REPOSITORY = 'https://github.com/IliasHad/edit-mind.git'
export const EDIT_MIND_PINNED_COMMIT = '4cfed9470e77f3552afdbc464f36caf1386dc990'

const execFileAsync = promisify(execFile)
const schemaVersion = 1
const containerMaterialRoot = '/media/videos'
const videoExtensions = new Set(['.avi', '.m4v', '.mkv', '.mov', '.mp4', '.webm', '.wmv'])
const pinnedMaterialImages = new Map([
  ['background-jobs', 'ghcr.io/iliashad/edit-mind-background-jobs:latest@sha256:692a2a1534c7d13927dae5af2be89c7f1edcb47b1e4b13b328db3c3877fb7e50'],
  ['web', 'ghcr.io/iliashad/edit-mind-web:latest@sha256:e00145d32b300aad38438059eb0fe52737948014b8abe52122d3dea9770fae68'],
  ['ml', 'ghcr.io/iliashad/edit-mind-ml:latest@sha256:c7b4625e542264c826841fd850362739f2de0bc97a445e68a1d8e128c3d040ea'],
])
const requiredMaterialServices = new Set(pinnedMaterialImages.keys())
/** @typedef {{schema_version: number, records: Record<string, any>[]}} AnalysisIndex */

export class EditMindError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'EditMindError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} value */
export const containsLocalPath = (value) => {
  if (value.includes(String.fromCharCode(92, 92))) return true
  for (let index = 0; index <= value.length - 3; index += 1) {
    const character = value.charCodeAt(index)
    const isAsciiLetter =
      (character >= 65 && character <= 90) ||
      (character >= 97 && character <= 122)
    if (
      isAsciiLetter &&
      value.charCodeAt(index + 1) === 58 &&
      [47, 92].includes(value.charCodeAt(index + 2))
    ) return true
  }
  return false
}
/** @param {unknown} value @param {number} [maximum] */
const safeText = (value, maximum = 1000) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maximum &&
  !value.includes('\u0000') &&
  !value.toLowerCase().includes('file://') &&
  !containsLocalPath(value) &&
  !/\/(?:home|users|private|var|tmp|mnt|volumes)\//iu.test(value)
/** @param {unknown} value @param {number} [maximum] */
const safeIdentifier = (value, maximum = 200) =>
  typeof value === 'string' &&
  /^[A-Za-z0-9._@+-]+$/u.test(value) &&
  value.length <= maximum
/** @param {unknown} value */
const timestampValid = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {number} milliseconds */
const sleepDefault = (milliseconds) => new Promise((resolveSleep) => setTimeout(resolveSleep, milliseconds))
/** @param {string} prefix @param {...string} parts */
const hashId = (prefix, ...parts) =>
  `${prefix}-${createHash('sha256').update(parts.join('\u0000')).digest('hex').slice(0, 24)}`
/** @param {unknown} error */
const nodeErrorCode = (error) =>
  error && typeof error === 'object' && 'code' in error
    ? /** @type {{code?: unknown}} */ (error).code
    : undefined
/** @param {number} pid */
const processIsAlive = (pid) => {
  try {
    process.kill(pid, 0)
    return true
  } catch (error) {
    return nodeErrorCode(error) !== 'ESRCH'
  }
}
/** @param {string} content @param {number} ageMilliseconds @param {number} staleMilliseconds */
export const shouldReclaimIndexLock = (content, ageMilliseconds, staleMilliseconds) => {
  if (ageMilliseconds <= staleMilliseconds) return false
  try {
    const parsedOwner = JSON.parse(content)
    if (
      isRecord(parsedOwner) &&
      Number.isSafeInteger(parsedOwner.pid) &&
      parsedOwner.pid > 0
    ) {
      return !processIsAlive(parsedOwner.pid)
    }
  } catch {}
  return true
}

/** @param {string} parent @param {string} candidate */
const isInside = (parent, candidate) => {
  const child = relative(parent, candidate)
  return child === '' || (!child.startsWith('..') && !isAbsolute(child))
}

/** @param {string} value */
const base64Url = (value) => Buffer.from(value).toString('base64url')
/** @param {Record<string, string>} provider */
const createInternalToken = (provider) => {
  const now = Math.floor(Date.now() / 1000)
  const header = base64Url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))
  const payload = base64Url(JSON.stringify({
    userId: provider.internal_user_id,
    email: provider.internal_user_email,
    iat: now,
    exp: now + 300,
  }))
  const signature = createHmac('sha256', provider.internal_session_secret)
    .update(`${header}.${payload}`)
    .digest('base64url')
  return `${header}.${payload}.${signature}`
}

/** @param {unknown} value */
const validAdmission = (value) => {
  if (
    !isRecord(value) ||
    value.schema_version !== schemaVersion ||
    value.decision !== 'approved' ||
    !timestampValid(value.confirmed_at) ||
    !safeIdentifier(value.confirmed_by) ||
    !safeIdentifier(value.evidence_reference)
  ) {
    return false
  }
  if (value.basis === 'eligibility') {
    return value.organization_size_eligible === true && value.direct_competition_reviewed === true
  }
  return value.basis === 'written_authorization' && value.written_authorization_confirmed === true
}

/** @param {unknown} value */
const validProvider = (value) => {
  if (
    !isRecord(value) ||
    value.schema_version !== schemaVersion ||
    !isAbsolute(value.upstream_root) ||
    !safeIdentifier(value.authorization_id) ||
    !isAbsolute(value.material_root) ||
    !Array.isArray(value.material_container_ids) ||
    value.material_container_ids.length !== 3 ||
    new Set(value.material_container_ids).size !== 3 ||
    value.material_container_ids.some((id) => !safeIdentifier(id)) ||
    !safeText(value.access_token, 4096) ||
    !safeText(value.internal_session_secret, 4096) ||
    !safeIdentifier(value.internal_user_id) ||
    !safeIdentifier(value.internal_user_email) ||
    !safeIdentifier(value.folder_id) ||
    !Number.isInteger(value.poll_interval_ms) ||
    value.poll_interval_ms < 0 ||
    value.poll_interval_ms > 60_000 ||
    !Number.isInteger(value.max_poll_attempts) ||
    value.max_poll_attempts < 1 ||
    value.max_poll_attempts > 10_000
  ) {
    return false
  }
  try {
    const apiUrl = new URL(value.api_base_url)
    const internalUrl = new URL(value.internal_base_url)
    const trustedHosts = new Set(['127.0.0.1', 'localhost', '[::1]'])
    return (
      apiUrl.protocol === 'http:' &&
      internalUrl.protocol === 'http:' &&
      trustedHosts.has(apiUrl.hostname.toLowerCase()) &&
      trustedHosts.has(internalUrl.hostname.toLowerCase()) &&
      apiUrl.origin === internalUrl.origin &&
      Number.isInteger(Number(apiUrl.port || '80')) &&
      Number(apiUrl.port || '80') >= 1 &&
      Number(apiUrl.port || '80') <= 65_535 &&
      apiUrl.pathname.replace(/\/$/u, '') === '/api/v0' &&
      internalUrl.pathname.replace(/\/$/u, '') === '/internal'
    )
  } catch {
    return false
  }
}

/** @param {string} path */
const readJson = async (path) => JSON.parse(await readFile(path, 'utf8'))

/** @param {string} path @param {unknown} value @param {{preserveBackup?: boolean}} [options] */
const writeJsonAtomic = async (path, value, { preserveBackup = true } = {}) => {
  const temporaryPath = `${path}.${randomUUID()}.tmp`
  const backupPath = `${path}.bak`
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  await writeFile(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
  if (preserveBackup) {
    try {
      await copyFile(path, backupPath)
      await chmod(backupPath, 0o600).catch(() => {})
    } catch (error) {
      if (nodeErrorCode(error) !== 'ENOENT') {
        await rm(temporaryPath, { force: true })
        throw error
      }
    }
  }
  try {
    await rename(temporaryPath, path)
  } catch (error) {
    await rm(temporaryPath, { force: true })
    throw error
  }
  await chmod(path, 0o600).catch(() => {})
}

/** @param {unknown} value */
const validPrivateAsset = (value) => {
  if (
    !isRecord(value) ||
    !isRecord(value.public) ||
    !safeIdentifier(value.public.id) ||
    !safeText(value.public.label, 160) ||
    value.public.status !== 'ready' ||
    value.public.analyzedPercent !== 100 ||
    typeof value.public.durationSeconds !== 'number' ||
    !Number.isFinite(value.public.durationSeconds) ||
    value.public.durationSeconds < 0 ||
    !Number.isSafeInteger(value.public.sceneCount) ||
    value.public.sceneCount < 0 ||
    !safeIdentifier(value.upstream_video_id) ||
    !safeText(value.upstream_source, 2000) ||
    !isAbsolute(value.host_source) ||
    !Number.isSafeInteger(value.source_size) ||
    value.source_size < 0 ||
    typeof value.source_mtime_ms !== 'number' ||
    !Number.isFinite(value.source_mtime_ms) ||
    !Array.isArray(value.scenes) ||
    value.public.sceneCount !== value.scenes.length
  ) {
    return false
  }
  try {
    sourceSegments(value.upstream_source)
  } catch {
    return false
  }
  return value.scenes.every((scene) =>
    isRecord(scene) &&
    safeIdentifier(scene.upstream_scene_id) &&
    typeof scene.start === 'number' &&
    Number.isFinite(scene.start) &&
    scene.start >= 0 &&
    typeof scene.end === 'number' &&
    Number.isFinite(scene.end) &&
    scene.end > scene.start &&
    scene.end <= value.public.durationSeconds &&
    safeText(scene.summary, 1000))
}

/** @param {unknown} record */
const validIndexRecord = (record) =>
  isRecord(record) &&
  safeIdentifier(record.authorization_id) &&
  isAbsolute(record.material_root) &&
  safeIdentifier(record.folder_id) &&
  record.upstream_commit === EDIT_MIND_PINNED_COMMIT &&
  typeof record.manifest_fingerprint === 'string' &&
  /^[a-f0-9]{64}$/u.test(record.manifest_fingerprint) &&
  safeText(record.folder_label, 100) &&
  timestampValid(record.updated_at) &&
  Array.isArray(record.assets) &&
  record.assets.every(validPrivateAsset)

/** @param {string} path @returns {Promise<AnalysisIndex>} */
const readIndex = async (path) => {
  let foundDocument = false
  for (const [position, candidate] of [path, `${path}.bak`].entries()) {
    try {
      const value = await readJson(candidate)
      foundDocument = true
      if (
        !isRecord(value) ||
        value.schema_version !== schemaVersion ||
        !Array.isArray(value.records) ||
        !value.records.every(validIndexRecord)
      ) {
        throw new Error('invalid_index')
      }
      if (position === 1) await writeJsonAtomic(path, value, { preserveBackup: false })
      return /** @type {AnalysisIndex} */ (value)
    } catch (error) {
      if (nodeErrorCode(error) === 'ENOENT') continue
      foundDocument = true
    }
  }
  if (foundDocument) throw new EditMindError('EDIT_MIND_STORAGE_CORRUPT', 500)
  return { schema_version: schemaVersion, records: [] }
}

/** @param {string[]} args @param {{cwd: string}} options */
const defaultExecGit = async (args, options) => {
  const { stdout } = await execFileAsync('git', args, {
    cwd: options.cwd,
    encoding: 'utf8',
    windowsHide: true,
    maxBuffer: 1024 * 1024,
  })
  return stdout.trim()
}

/** @param {{service: unknown, image: unknown, revision: unknown, project: unknown, running: unknown, apiPublished: unknown}[]} evidence */
export const assertPinnedMaterialContainerEvidence = (evidence) => {
  if (!Array.isArray(evidence) || evidence.length !== requiredMaterialServices.size) {
    throw new EditMindError('EDIT_MIND_IMAGE_BINDING_INVALID')
  }
  const services = new Set()
  const projects = new Set()
  for (const entry of evidence) {
    const service = typeof entry.service === 'string' ? entry.service : ''
    const project = typeof entry.project === 'string' ? entry.project : ''
    if (
      !safeIdentifier(service) ||
      services.has(service) ||
      !safeIdentifier(project) ||
      entry.running !== true ||
      entry.image !== pinnedMaterialImages.get(service) ||
      entry.revision !== EDIT_MIND_PINNED_COMMIT ||
      (service === 'background-jobs' ? entry.apiPublished !== true : entry.apiPublished !== false)
    ) {
      throw new EditMindError('EDIT_MIND_IMAGE_BINDING_INVALID')
    }
    services.add(service)
    projects.add(project)
  }
  if (services.size !== requiredMaterialServices.size ||
      projects.size !== 1 ||
      [...requiredMaterialServices].some((service) => !services.has(service))) {
    throw new EditMindError('EDIT_MIND_IMAGE_BINDING_INVALID')
  }
}

/** @param {Record<string, any>} provider */
const defaultVerifyMaterialMounts = async (provider) => {
  const expectedRoot = await realpath(provider.material_root)
  const providerUrl = new URL(provider.api_base_url)
  const expectedHostPort = String(Number(providerUrl.port || '80'))
  const containerEvidence = []
  for (const containerId of provider.material_container_ids) {
    const { stdout: inspectionJson } = await execFileAsync(
      'docker',
      ['inspect', '--format', '{{json .}}', containerId],
      { encoding: 'utf8', windowsHide: true, maxBuffer: 1024 * 1024 },
    )
    const inspection = JSON.parse(inspectionJson)
    const mounts = isRecord(inspection) ? inspection.Mounts : null
    const config = isRecord(inspection) ? inspection.Config : null
    const state = isRecord(inspection) ? inspection.State : null
    const networkSettings = isRecord(inspection) ? inspection.NetworkSettings : null
    const service = isRecord(config) && isRecord(config.Labels)
      ? config.Labels['com.docker.compose.service']
      : null
    const project = isRecord(config) && isRecord(config.Labels)
      ? config.Labels['com.docker.compose.project']
      : null
    const imageRevision = isRecord(config) && isRecord(config.Labels)
      ? config.Labels['org.opencontainers.image.revision']
      : null
    const portBindings = isRecord(networkSettings) && isRecord(networkSettings.Ports)
      ? networkSettings.Ports['4000/tcp']
      : null
    const apiPublished = service === 'background-jobs' &&
      Array.isArray(portBindings) &&
      portBindings.length === 1 &&
      isRecord(portBindings[0]) &&
      portBindings[0].HostIp === '127.0.0.1' &&
      portBindings[0].HostPort === expectedHostPort
    containerEvidence.push({
      service,
      project,
      image: isRecord(config) ? config.Image : null,
      revision: imageRevision,
      running: isRecord(state) &&
        state.Running === true &&
        state.Paused === false &&
        state.Restarting === false &&
        state.Dead === false,
      apiPublished,
    })
    const materialMount = Array.isArray(mounts)
      ? mounts.find((mount) =>
          isRecord(mount) &&
          mount.Destination === containerMaterialRoot &&
          mount.RW === false &&
          typeof mount.Source === 'string' &&
          isAbsolute(mount.Source))
      : null
    if (!materialMount || (await realpath(materialMount.Source)) !== expectedRoot) {
      throw new EditMindError('EDIT_MIND_MOUNT_BINDING_INVALID')
    }
  }
  assertPinnedMaterialContainerEvidence(containerEvidence)
}

/** @param {string} privateRoot @param {(args: string[], options: {cwd: string}) => Promise<string>} execGit @param {(provider: Record<string, any>) => Promise<void>} verifyMaterialMounts */
const loadVerifiedProvider = async (privateRoot, execGit, verifyMaterialMounts) => {
  const admissionPath = resolve(privateRoot, 'license-admission.json')
  if (!existsSync(admissionPath)) throw new EditMindError('EDIT_MIND_LICENSE_ADMISSION_REQUIRED')
  const admission = await readJson(admissionPath)
  if (!validAdmission(admission)) throw new EditMindError('EDIT_MIND_LICENSE_ADMISSION_INVALID')
  const providerPath = resolve(privateRoot, 'provider.json')
  if (!existsSync(providerPath)) throw new EditMindError('EDIT_MIND_PROVIDER_CONFIG_REQUIRED')
  const configuredProvider = await readJson(providerPath)
  if (!validProvider(configuredProvider)) throw new EditMindError('EDIT_MIND_PROVIDER_CONFIG_INVALID')
  const upstreamRoot = resolve(configuredProvider.upstream_root)
  const remote = (await execGit(['remote', 'get-url', 'origin'], { cwd: upstreamRoot })).replace(/\/$/u, '')
  if (![EDIT_MIND_REPOSITORY, EDIT_MIND_REPOSITORY.replace(/\.git$/u, '')].includes(remote)) {
    throw new EditMindError('EDIT_MIND_UPSTREAM_REMOTE_MISMATCH')
  }
  const commit = await execGit(['rev-parse', 'HEAD'], { cwd: upstreamRoot })
  if (commit !== EDIT_MIND_PINNED_COMMIT) throw new EditMindError('EDIT_MIND_UPSTREAM_COMMIT_MISMATCH')
  const dirty = await execGit(['status', '--porcelain', '--untracked-files=all'], { cwd: upstreamRoot })
  if (dirty.trim()) throw new EditMindError('EDIT_MIND_UPSTREAM_DIRTY')
  await verifyMaterialMounts(/** @type {Record<string, any>} */ (configuredProvider))
  return /** @type {Record<string, any>} */ (configuredProvider)
}

/** @param {unknown} error @param {string} fallback */
const fixedError = (error, fallback) => {
  if (error instanceof EditMindError) return error
  return new EditMindError(fallback)
}

/** @param {string} source */
const sourceSegments = (source) => {
  const prefix = '/media/videos/'
  if (!source.startsWith(prefix)) throw new EditMindError('EDIT_MIND_SOURCE_OUTSIDE_AUTHORIZATION', 502)
  const segments = source.slice(prefix.length).split('/')
  if (
    segments.length === 0 ||
    segments.some((segment) => !segment || segment === '.' || segment === '..' || segment.includes('\\') || segment.includes('\u0000'))
  ) {
    throw new EditMindError('EDIT_MIND_SOURCE_OUTSIDE_AUTHORIZATION', 502)
  }
  return segments
}

/** @param {string} materialRoot */
const readMaterialManifest = async (materialRoot) => {
  const root = await realpath(materialRoot)
  /** @type {{source: string, size: number, mtime_ms: number}[]} */
  const entries = []
  /** @param {string} current */
  const walk = async (current) => {
    const directory = await opendir(current)
    for await (const entry of directory) {
      if (entry.isSymbolicLink()) continue
      const entryPath = resolve(current, entry.name)
      if (entry.isDirectory()) await walk(entryPath)
      else if (entry.isFile() && videoExtensions.has(extname(entry.name).toLowerCase())) {
        const metadata = await stat(entryPath)
        const relativeSource = relative(root, entryPath).split('\\').join('/')
        entries.push({
          source: `${containerMaterialRoot}/${relativeSource}`,
          size: metadata.size,
          mtime_ms: metadata.mtimeMs,
        })
      }
    }
  }
  await walk(root)
  entries.sort((left, right) => left.source.localeCompare(right.source))
  return {
    entries,
    fingerprint: createHash('sha256').update(JSON.stringify(entries)).digest('hex'),
  }
}

/** @param {string} materialRoot @param {string} upstreamSource */
const resolveAuthorizedSource = async (materialRoot, upstreamSource) => {
  const configuredRoot = resolve(materialRoot)
  const rootEntry = await lstat(configuredRoot)
  if (rootEntry.isSymbolicLink()) throw new EditMindError('EDIT_MIND_SOURCE_OUTSIDE_AUTHORIZATION', 502)
  let unresolvedCandidate = configuredRoot
  for (const segment of sourceSegments(upstreamSource)) {
    unresolvedCandidate = resolve(unresolvedCandidate, segment)
    const entry = await lstat(unresolvedCandidate).catch(() => {
      throw new EditMindError('EDIT_MIND_SOURCE_UNAVAILABLE', 502)
    })
    if (entry.isSymbolicLink()) throw new EditMindError('EDIT_MIND_SOURCE_OUTSIDE_AUTHORIZATION', 502)
  }
  const root = await realpath(configuredRoot)
  const candidate = unresolvedCandidate
  const resolvedCandidate = await realpath(candidate).catch(() => {
    throw new EditMindError('EDIT_MIND_SOURCE_UNAVAILABLE', 502)
  })
  if (!isInside(root, resolvedCandidate)) {
    throw new EditMindError('EDIT_MIND_SOURCE_OUTSIDE_AUTHORIZATION', 502)
  }
  const candidateStat = await stat(resolvedCandidate)
  if (!candidateStat.isFile()) throw new EditMindError('EDIT_MIND_SOURCE_UNAVAILABLE', 502)
  return resolvedCandidate
}

/** @param {unknown} video @param {unknown[]} scenes @param {string} authorizationId @param {string} materialRoot @param {string} folderId @param {number} ordinal */
const privateAsset = async (video, scenes, authorizationId, materialRoot, folderId, ordinal) => {
  if (
    !isRecord(video) ||
    !safeIdentifier(video.id) ||
    video.folderId !== folderId ||
    !safeText(video.source, 2000) ||
    typeof video.duration !== 'number' ||
    !Number.isSafeInteger(video.duration) ||
    video.duration <= 0 ||
    !Array.isArray(scenes)
  ) {
    throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
  }
  const hostSource = await resolveAuthorizedSource(materialRoot, video.source)
  const sourceStat = await stat(hostSource)
  const label = `素材 ${String(ordinal + 1).padStart(3, '0')}`
  let maximumSceneEnd = 0
  const logicalScenes = scenes.map((scene) => {
    if (
      !isRecord(scene) ||
      scene.source !== video.source ||
      typeof scene.startTime !== 'number' ||
      !Number.isFinite(scene.startTime) ||
      scene.startTime < 0 ||
      typeof scene.endTime !== 'number' ||
      !Number.isFinite(scene.endTime) ||
      scene.endTime <= scene.startTime ||
      // Edit Mind tiles integer-second scenes to duration+1 on the final clip.
      scene.endTime > video.duration + 1
    ) {
      throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
    }
    maximumSceneEnd = Math.max(maximumSceneEnd, scene.endTime)
    return {
      upstream_scene_id: safeIdentifier(scene.id) ? scene.id : hashId('scene', video.source, `${scene.startTime}`, `${scene.endTime}`),
      start: scene.startTime,
      end: scene.endTime,
      summary: safeText(scene.description, 1000) ? scene.description.trim() : 'Edit Mind 已索引逻辑场景',
    }
  })
  const logicalDuration = Math.max(video.duration, maximumSceneEnd)
  const id = hashId('asset', authorizationId, video.source)
  return {
    public: {
      id,
      label,
      status: 'ready',
      analyzedPercent: 100,
      durationSeconds: logicalDuration,
      sceneCount: logicalScenes.length,
    },
    upstream_video_id: video.id,
    upstream_source: video.source,
    host_source: hostSource,
    source_size: sourceStat.size,
    source_mtime_ms: sourceStat.mtimeMs,
    scenes: logicalScenes,
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   authorizationRepository: {get: (id: string) => any},
 *   execGit?: (args: string[], options: {cwd: string}) => Promise<string>,
 *   securePrivateRoot?: (root: string) => Promise<void>,
 *   verifyMaterialMounts?: (provider: Record<string, any>) => Promise<void>,
 *   fetcher?: typeof fetch,
 *   sleep?: (milliseconds: number) => Promise<void>,
 *   lockStaleMilliseconds?: number,
 * }} options
 */
export const createEditMindCapability = async ({
  dataRoot,
  authorizationRepository,
  execGit = defaultExecGit,
  securePrivateRoot = async (root) => chmod(root, 0o700),
  verifyMaterialMounts = defaultVerifyMaterialMounts,
  fetcher = fetch,
  sleep = sleepDefault,
  lockStaleMilliseconds = 60_000,
}) => {
  if (!Number.isInteger(lockStaleMilliseconds) || lockStaleMilliseconds < 0) {
    throw new EditMindError('EDIT_MIND_CONFIG_INVALID', 500)
  }
  const privateRoot = resolve(dataRoot, 'edit-mind')
  const temporaryRoot = resolve(privateRoot, 'tmp')
  const indexPath = resolve(privateRoot, 'analysis-index.json')
  await mkdir(temporaryRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(privateRoot)

  /** @type {string | null} */
  let blockedCode = null
  /** @type {Record<string, any> | null} */
  let provider = null
  try {
    provider = await loadVerifiedProvider(privateRoot, execGit, verifyMaterialMounts)
  } catch (error) {
    blockedCode = fixedError(error, 'EDIT_MIND_UPSTREAM_UNAVAILABLE').code
    provider = null
  }

  /** @type {AnalysisIndex} */
  let index
  let storageHealthy = true
  try {
    index = await readIndex(indexPath)
  } catch (error) {
    blockedCode = fixedError(error, 'EDIT_MIND_STORAGE_CORRUPT').code
    provider = null
    storageHealthy = false
    index = { schema_version: schemaVersion, records: [] }
  }
  const getStatus = () => provider
    ? { available: true, state: 'ready', code: null }
    : { available: false, state: 'blocked', code: blockedCode ?? 'EDIT_MIND_PROVIDER_UNAVAILABLE' }
  const assertAvailable = async () => {
    if (!storageHealthy) throw new EditMindError(blockedCode ?? 'EDIT_MIND_STORAGE_CORRUPT')
    try {
      provider = await loadVerifiedProvider(privateRoot, execGit, verifyMaterialMounts)
      blockedCode = null
      return provider
    } catch (error) {
      const safeError = fixedError(error, 'EDIT_MIND_UPSTREAM_UNAVAILABLE')
      blockedCode = safeError.code
      provider = null
      throw safeError
    }
  }
  /** @param {string} authorizationId @param {Record<string, any>} activeProvider */
  const authorization = async (authorizationId, activeProvider) => {
    const record = authorizationRepository.get(authorizationId)
    if (
      !isRecord(record) ||
      record.id !== authorizationId ||
      record.status !== 'authorized' ||
      record.readOnly !== true ||
      !isAbsolute(record.absolutePath) ||
      !Number.isSafeInteger(record.total) ||
      record.total < 0
    ) {
      throw new EditMindError('EDIT_MIND_AUTHORIZATION_INVALID', 409)
    }
    if (activeProvider.authorization_id !== authorizationId) {
      throw new EditMindError('EDIT_MIND_AUTHORIZATION_MISMATCH', 409)
    }
    const [authorizationRoot, providerRoot] = await Promise.all([
      realpath(record.absolutePath),
      realpath(activeProvider.material_root),
    ]).catch(() => {
      throw new EditMindError('EDIT_MIND_AUTHORIZATION_MISMATCH', 409)
    })
    if (authorizationRoot !== providerRoot) {
      throw new EditMindError('EDIT_MIND_AUTHORIZATION_MISMATCH', 409)
    }
    return record
  }
  /** @param {string} url @param {RequestInit} requestOptions @param {number} [timeoutMs] */
  const requestJson = async (url, requestOptions, timeoutMs = 30_000) => {
    try {
      const response = await fetcher(url, {
        ...requestOptions,
        signal: AbortSignal.timeout(timeoutMs),
      })
      if (!response.ok) throw new Error('provider_response_not_ok')
      return await response.json()
    } catch (error) {
      throw fixedError(error, 'EDIT_MIND_SERVICE_UNAVAILABLE')
    }
  }
  /** @param {Record<string, any>} activeProvider @param {string} path */
  const publicGet = (activeProvider, path) => requestJson(
    `${activeProvider.api_base_url.replace(/\/$/u, '')}${path}`,
    { headers: { Authorization: `Bearer ${activeProvider.access_token}`, Accept: 'application/json' } },
  )
  /** @param {Record<string, any>} activeProvider @param {string} path @param {unknown} body @param {number} [timeoutMs] */
  const publicPost = (activeProvider, path, body, timeoutMs = 30_000) => requestJson(
    `${activeProvider.api_base_url.replace(/\/$/u, '')}${path}`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${activeProvider.access_token}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    },
    timeoutMs,
  )
  /** @param {Record<string, any>} activeProvider */
  const triggerScan = (activeProvider) => requestJson(
    `${activeProvider.internal_base_url.replace(/\/$/u, '')}/folders/${encodeURIComponent(activeProvider.folder_id)}/trigger`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${createInternalToken(activeProvider)}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: '{}',
    },
  )
  /** @param {Record<string, any>} activeProvider */
  const listVideos = async (activeProvider) => {
    /** @type {Record<string, any>[]} */
    const videos = []
    for (let offset = 0; offset < 100_000; offset += 100) {
      const page = await publicGet(activeProvider, `/videos?limit=100&offset=${offset}`)
      if (!isRecord(page) || !Array.isArray(page.videos)) throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
      videos.push(...page.videos)
      if (page.hasMore !== true) return videos
    }
    throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
  }
  /** @param {Record<string, any>} activeProvider @param {Record<string, any>} auth @param {{entries: {source: string, size: number, mtime_ms: number}[], fingerprint: string}} manifest @param {number} scanStartedAt */
  const collectAnalysis = async (activeProvider, auth, manifest, scanStartedAt) => {
    const expectedSources = new Set(manifest.entries.map((entry) => entry.source))
    for (let attempt = 0; attempt < activeProvider.max_poll_attempts; attempt += 1) {
      const videos = (await listVideos(activeProvider))
        .filter((video) =>
          isRecord(video) &&
          video.folderId === activeProvider.folder_id &&
          timestampValid(video.updatedAt) &&
          Date.parse(video.updatedAt) >= scanStartedAt)
        .sort((left, right) => String(left.source).localeCompare(String(right.source)))
      const videoIds = new Set(videos.map((video) => video.id))
      const videoSources = new Set(videos.map((video) => video.source))
      if (
        videos.length === auth.total &&
        videoIds.size === videos.length &&
        videoSources.size === videos.length &&
        videoSources.size === expectedSources.size &&
        [...videoSources].every((source) => expectedSources.has(source))
      ) {
        /** @type {Record<string, any>[]} */
        const assets = []
        let complete = true
        for (const [ordinal, video] of videos.entries()) {
          if (!isRecord(video) || !safeIdentifier(video.id)) throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
          const detail = await publicGet(activeProvider, `/videos/${encodeURIComponent(video.id)}`)
          if (
            !isRecord(detail) ||
            !isRecord(detail.video) ||
            detail.video.id !== video.id ||
            detail.video.source !== video.source ||
            !timestampValid(detail.video.updatedAt) ||
            Date.parse(detail.video.updatedAt) < scanStartedAt ||
            !Array.isArray(detail.scenes) ||
            detail.scenes.length === 0
          ) {
            complete = false
            break
          }
          assets.push(await privateAsset(
            detail.video,
            detail.scenes,
            auth.id,
            auth.absolutePath,
            activeProvider.folder_id,
            ordinal,
          ))
        }
        if (complete) return assets
      }
      await sleep(activeProvider.poll_interval_ms)
    }
    throw new EditMindError('EDIT_MIND_ANALYSIS_TIMEOUT', 504)
  }
  /** @param {Record<string, any>} record */
  const publicMaterials = (record) => ({
    authorizationId: record.authorization_id,
    authorized: true,
    readOnlyConfirmed: true,
    folderLabel: record.folder_label,
    total: record.assets.length,
    analyzed: record.assets.length,
    queued: 0,
    failed: 0,
    analysisStatus: 'ready',
    lastScanAt: record.updated_at,
    assets: record.assets.map((/** @type {Record<string, any>} */ asset) => clone(asset.public)),
  })
  /** @param {Record<string, any>} record @param {Record<string, any>} activeProvider */
  const assertSourcesUnchanged = async (record, activeProvider) => {
    const manifest = await readMaterialManifest(record.material_root)
    if (
      record.folder_id !== activeProvider.folder_id ||
      record.upstream_commit !== EDIT_MIND_PINNED_COMMIT ||
      record.manifest_fingerprint !== manifest.fingerprint
    ) {
      throw new EditMindError('EDIT_MIND_AUTHORIZATION_CHANGED', 409)
    }
    for (const asset of record.assets) {
      const entry = await lstat(asset.host_source).catch(() => null)
      const current = entry && !entry.isSymbolicLink() ? await stat(asset.host_source).catch(() => null) : null
      if (!current || current.size !== asset.source_size || current.mtimeMs !== asset.source_mtime_ms) {
        throw new EditMindError('EDIT_MIND_AUTHORIZATION_CHANGED', 409)
      }
    }
  }
  let writeQueue = Promise.resolve()
  const lockPath = `${indexPath}.lock`
  const acquireIndexLock = async () => {
    const owner = `${JSON.stringify({ owner: randomUUID(), pid: process.pid })}\n`
    for (let attempt = 0; attempt < 250; attempt += 1) {
      /** @type {import('node:fs/promises').FileHandle | null} */
      let handle = null
      try {
        handle = await open(lockPath, 'wx', 0o600)
        await handle.writeFile(owner, 'utf8')
        return { handle, owner }
      } catch (error) {
        if (handle) {
          await handle.close().catch(() => {})
          await rm(lockPath, { force: true })
        }
        if (nodeErrorCode(error) !== 'EEXIST') throw error
        const existingOwner = await readFile(lockPath, 'utf8').catch(() => null)
        const lockMetadata = await stat(lockPath).catch(() => null)
        if (
          existingOwner &&
          lockMetadata &&
          shouldReclaimIndexLock(existingOwner, Date.now() - lockMetadata.mtimeMs, lockStaleMilliseconds) &&
          await readFile(lockPath, 'utf8').catch(() => null) === existingOwner
        ) {
          await rm(lockPath, { force: true })
          continue
        }
        await sleep(20)
      }
    }
    throw new EditMindError('EDIT_MIND_STORAGE_LOCKED', 503)
  }
  /** @param {Record<string, any>} record */
  const persistRecord = async (record) => {
    const operation = writeQueue.then(async () => {
      const lock = await acquireIndexLock()
      try {
        const latest = await readIndex(indexPath)
        const next = clone(latest)
        const existing = next.records.findIndex((entry) => entry.authorization_id === record.authorization_id)
        if (existing === -1) next.records.push(record)
        else next.records[existing] = record
        await writeJsonAtomic(indexPath, next)
        index = next
      } finally {
        await lock.handle.close()
        if (await readFile(lockPath, 'utf8').catch(() => null) === lock.owner) {
          await rm(lockPath, { force: true })
        }
      }
    })
    writeQueue = operation.catch(() => {})
    await operation
  }

  return {
    getStatus,
    /** @param {{authorizationId: string}} input */
    async analyzeMaterials(input) {
      const activeProvider = await assertAvailable()
      const auth = await authorization(input?.authorizationId, activeProvider)
      const operationRoot = await mkdtemp(resolve(temporaryRoot, 'analysis-'))
      try {
        const manifest = await readMaterialManifest(auth.absolutePath)
        if (manifest.entries.length !== auth.total) {
          throw new EditMindError('EDIT_MIND_AUTHORIZATION_CHANGED', 409)
        }
        index = await readIndex(indexPath)
        const existingRecord = index.records.find((entry) => entry.authorization_id === auth.id)
        if (
          existingRecord &&
          existingRecord.folder_id === activeProvider.folder_id &&
          existingRecord.upstream_commit === EDIT_MIND_PINNED_COMMIT &&
          existingRecord.manifest_fingerprint === manifest.fingerprint &&
          existingRecord.material_root === await realpath(auth.absolutePath)
        ) {
          await assertSourcesUnchanged(existingRecord, activeProvider)
          return publicMaterials(existingRecord)
        }
        const scanStartedAt = Date.now()
        const triggered = await triggerScan(activeProvider)
        if (
          !isRecord(triggered) ||
          !isRecord(triggered.folder) ||
          triggered.folder.id !== activeProvider.folder_id ||
          triggered.folder.path?.replace(/\/+$/u, '') !== containerMaterialRoot
        ) {
          throw new EditMindError('EDIT_MIND_FOLDER_BINDING_INVALID', 409)
        }
        if (
          typeof triggered.queuedVideos !== 'number' ||
          !Number.isSafeInteger(triggered.queuedVideos) ||
          triggered.queuedVideos < 0
        ) {
          throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
        }
        if (triggered.queuedVideos !== manifest.entries.length) {
          throw new EditMindError('EDIT_MIND_FRESH_SCAN_REQUIRED', 409)
        }
        const assets = await collectAnalysis(activeProvider, auth, manifest, scanStartedAt)
        const record = {
          authorization_id: auth.id,
          material_root: await realpath(auth.absolutePath),
          folder_id: activeProvider.folder_id,
          upstream_commit: EDIT_MIND_PINNED_COMMIT,
          manifest_fingerprint: manifest.fingerprint,
          folder_label: safeText(auth.label, 100) ? auth.label.trim() : '已授权素材',
          updated_at: new Date().toISOString(),
          assets,
        }
        await persistRecord(record)
        return publicMaterials(record)
      } catch (error) {
        throw fixedError(error, 'EDIT_MIND_ANALYSIS_FAILED')
      } finally {
        await rm(operationRoot, { recursive: true, force: true })
      }
    },
    /** @param {{authorizationId: string}} input */
    async restoreAnalysis(input) {
      const activeProvider = await assertAvailable()
      const auth = await authorization(input?.authorizationId, activeProvider)
      index = await readIndex(indexPath)
      const record = index.records.find((entry) => entry.authorization_id === auth.id)
      if (!record) throw new EditMindError('EDIT_MIND_ANALYSIS_NOT_FOUND', 404)
      if ((await realpath(auth.absolutePath)) !== record.material_root) {
        throw new EditMindError('EDIT_MIND_AUTHORIZATION_CHANGED', 409)
      }
      await assertSourcesUnchanged(record, activeProvider)
      return publicMaterials(record)
    },
    /** @param {{authorizationId: string, query: string, limit?: number}} input */
    async searchCandidates(input) {
      const activeProvider = await assertAvailable()
      const auth = await authorization(input?.authorizationId, activeProvider)
      if (!safeText(input?.query, 8000)) throw new EditMindError('EDIT_MIND_QUERY_INVALID', 400)
      const limit = input?.limit === undefined ? 3 : input.limit
      if (!Number.isSafeInteger(limit) || limit < 1 || limit > 10) {
        throw new EditMindError('EDIT_MIND_QUERY_INVALID', 400)
      }
      index = await readIndex(indexPath)
      const record = index.records.find((entry) => entry.authorization_id === auth.id)
      if (!record) throw new EditMindError('EDIT_MIND_ANALYSIS_NOT_FOUND', 409)
      await assertSourcesUnchanged(record, activeProvider)
      const operationRoot = await mkdtemp(resolve(temporaryRoot, 'search-'))
      try {
        /** @type {Record<string, any>[]} */
        const candidates = []
        const candidateIds = new Set()
        const baseQuery = input.query.trim()
        const queryVariants = [baseQuery]
        if (baseQuery.length <= 7960) {
          queryVariants.push(
            `${baseQuery} close-up detail`,
            `${baseQuery} human interaction usage context`,
          )
        }
        const searchDeadline = Date.now() + 300_000
        for (const query of queryVariants) {
          const remainingMilliseconds = searchDeadline - Date.now()
          if (remainingMilliseconds <= 0) {
            throw new EditMindError('EDIT_MIND_SEARCH_TIMEOUT', 504)
          }
          const result = await publicPost(activeProvider, '/search', {
            query,
            limit: Math.min(3, limit),
            offset: 0,
          }, remainingMilliseconds)
          if (!isRecord(result) || !Array.isArray(result.videos)) {
            throw new EditMindError('EDIT_MIND_RESPONSE_INVALID', 502)
          }
          for (const video of result.videos) {
            if (
              !isRecord(video) ||
              !safeText(video.source, 2000) ||
              !Array.isArray(video.scenes)
            ) continue
            // The public search DTO intentionally omits private video/folder IDs.
            // Rebind it to the authorization-scoped persisted index by exact source,
            // then require every returned scene ID and time range to match that index.
            const indexedAsset = record.assets.find((/** @type {Record<string, any>} */ asset) =>
              asset.upstream_source === video.source)
            if (!indexedAsset) continue
            for (const scene of video.scenes) {
              const indexedScene = isRecord(scene) && scene.source === video.source
                ? indexedAsset.scenes.find((/** @type {Record<string, any>} */ candidate) =>
                    candidate.upstream_scene_id === scene.id &&
                    candidate.start === scene.startTime &&
                    candidate.end === scene.endTime)
                : null
              if (!indexedScene) continue
              const id = hashId('candidate', auth.id, indexedAsset.upstream_source, indexedScene.upstream_scene_id)
              if (candidateIds.has(id)) continue
              candidateIds.add(id)
              /** @type {number} */
              const rank = candidates.length
              candidates.push({
                id,
                assetLabel: indexedAsset.public.label,
                start: indexedScene.start,
                end: indexedScene.end,
                summary: indexedScene.summary,
                matchScore: Math.max(0, Number((1 - rank * 0.1).toFixed(6))),
                reason: `Edit Mind 语义搜索排序第 ${rank + 1} 位。`,
              })
              if (candidates.length === limit) return candidates
            }
          }
        }
        return candidates
      } catch (error) {
        throw fixedError(error, 'EDIT_MIND_SEARCH_FAILED')
      } finally {
        await rm(operationRoot, { recursive: true, force: true })
      }
    },
  }
}
