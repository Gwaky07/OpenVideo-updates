import { randomUUID } from 'node:crypto'
import { lstat, mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises'
import { isAbsolute, join } from 'node:path'

import {
  CREATIVE_AB_STABLE_RUN_COUNT,
  isCreativeAbEvaluation,
  isCreativeAbFailedAttempt,
} from './creative-ab-evaluation.mjs'

const receiptSchemaVersion = 2
const receiptNamePattern = /^run-v2-[0-9TZ.-]+\.json$/u

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {Record<string, any>} value @param {string[]} keys */
const hasExactKeys = (value, keys) => Object.keys(value).length === keys.length &&
  keys.every((key) => Object.hasOwn(value, key))

/** @param {unknown} value */
export const isCreativeAbReceipt = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, [
    'schema_version', 'created_at', 'evaluation', 'rollout_window', 'default_enablement_changed',
  ]) || value.schema_version !== receiptSchemaVersion || typeof value.created_at !== 'string' ||
      !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(value.created_at) ||
      value.default_enablement_changed !== false || !isRecord(value.evaluation) ||
      !isRecord(value.rollout_window)) return false
  const rollout = value.rollout_window
  if ((!isCreativeAbEvaluation(value.evaluation) && !isCreativeAbFailedAttempt(value.evaluation)) ||
      !hasExactKeys(rollout, [
    'verdict', 'reason', 'qualifying_run_count',
  ])) return false
  if (isCreativeAbFailedAttempt(value.evaluation)) {
    return rollout.verdict === 'HOLD' && rollout.reason === 'run_failed' &&
      rollout.qualifying_run_count === 0
  }
  if (rollout.verdict === 'ELIGIBLE') {
    return rollout.reason === 'stable_window_passed' &&
      rollout.qualifying_run_count === CREATIVE_AB_STABLE_RUN_COUNT
  }
  return rollout.verdict === 'HOLD' &&
    ['stable_window_incomplete', 'run_failed', 'identity_drift', 'receipt_invalid'].includes(rollout.reason) &&
    rollout.qualifying_run_count === 0
}

/** @param {string} evidenceRoot */
export const loadCreativeAbReceiptHistory = async (evidenceRoot) => {
  if (!isAbsolute(evidenceRoot)) throw new Error('CREATIVE_AB_EVIDENCE_ROOT_INVALID')
  let entries = []
  try {
    entries = await readdir(evidenceRoot)
  } catch (error) {
    if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
      return Object.freeze({ runs: Object.freeze([]), invalidReceiptCount: 0 })
    }
    throw error
  }
  const runs = []
  let invalidReceiptCount = 0
  for (const fileName of entries.filter((entry) => receiptNamePattern.test(entry)).sort()) {
    try {
      const receiptPath = join(evidenceRoot, fileName)
      const stats = await lstat(receiptPath)
      if (!stats.isFile() || stats.isSymbolicLink()) throw new Error('CREATIVE_AB_RECEIPT_UNSAFE')
      const receipt = /** @type {unknown} */ (JSON.parse(await readFile(receiptPath, 'utf8')))
      if (!isCreativeAbReceipt(receipt)) throw new Error('CREATIVE_AB_RECEIPT_INVALID')
      runs.push(/** @type {Record<string, any>} */ (receipt).evaluation)
    } catch {
      invalidReceiptCount += 1
    }
  }
  return Object.freeze({ runs: Object.freeze(runs), invalidReceiptCount })
}

/** @param {string} evidenceRoot @param {unknown} receipt */
export const publishCreativeAbReceipt = async (evidenceRoot, receipt) => {
  if (!isAbsolute(evidenceRoot) || !isCreativeAbReceipt(receipt)) {
    throw new Error('CREATIVE_AB_RECEIPT_INVALID')
  }
  const validatedReceipt = /** @type {Record<string, any>} */ (receipt)
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const fileName = `run-v2-${validatedReceipt.created_at.replace(/[:]/gu, '-')}.json`
  const receiptPath = join(evidenceRoot, fileName)
  const stagedPath = join(evidenceRoot, `.${fileName}.${randomUUID()}.tmp`)
  try {
    await writeFile(stagedPath, `${JSON.stringify(validatedReceipt, null, 2)}\n`, {
      encoding: 'utf8', mode: 0o600, flag: 'wx',
    })
    await rename(stagedPath, receiptPath)
  } finally {
    await rm(stagedPath, { force: true }).catch(() => {})
  }
  return receiptPath
}

/** @param {string} evidenceRoot @param {string} receiptPath @param {unknown} receipt */
export const replaceCreativeAbReceipt = async (evidenceRoot, receiptPath, receipt) => {
  if (!isAbsolute(evidenceRoot) || !isCreativeAbReceipt(receipt)) {
    throw new Error('CREATIVE_AB_RECEIPT_INVALID')
  }
  const validatedReceipt = /** @type {Record<string, any>} */ (receipt)
  const fileName = `run-v2-${validatedReceipt.created_at.replace(/[:]/gu, '-')}.json`
  if (receiptPath !== join(evidenceRoot, fileName)) {
    throw new Error('CREATIVE_AB_RECEIPT_REPLACEMENT_INVALID')
  }
  const stagedPath = join(evidenceRoot, `.${fileName}.${randomUUID()}.tmp`)
  try {
    await writeFile(stagedPath, `${JSON.stringify(validatedReceipt, null, 2)}\n`, {
      encoding: 'utf8', mode: 0o600, flag: 'wx',
    })
    await rename(stagedPath, receiptPath)
  } finally {
    await rm(stagedPath, { force: true }).catch(() => {})
  }
  return receiptPath
}
