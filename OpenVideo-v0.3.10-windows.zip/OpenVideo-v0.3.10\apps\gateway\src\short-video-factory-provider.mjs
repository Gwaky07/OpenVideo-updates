import { execFile, spawn } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { createReadStream, createWriteStream } from 'node:fs'
import {
  copyFile,
  lstat,
  mkdir,
  open,
  readFile,
  readdir,
  realpath,
  rename,
  rm,
  stat,
  utimes,
  writeFile,
} from 'node:fs/promises'
import { isAbsolute, relative, resolve } from 'node:path'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { setTimeout as delay } from 'node:timers/promises'
import { promisify } from 'node:util'

const maxPreviewSfxInputs = 96

import {
  normalizeBrief,
  normalizePackaging,
  resolvePreviewVoice,
} from './brief-packaging.mjs'
import { securePrivateRuntimeRoot } from './local-runtime.mjs'
import {
  shortVideoFactoryErrorCodes,
  validShortVideoFactoryRequest,
  validShortVideoFactoryResult,
  validShortVideoFactoryStatus,
} from './short-video-factory-contracts.mjs'
import {
  applyTemplateGuidanceToSelections,
  assertTemplateGuidanceExecutable,
} from './template-binding-consumption.mjs'
import { isRunningHubVoiceId } from './tts-studio.mjs'
import { isJianyingPresetVoiceId } from './jianying-tts-presets.mjs'

const execFileAsync = promisify(execFile)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const safeId = (value) =>
  typeof value === 'string' && /^[a-z0-9][a-z0-9._-]{0,199}$/iu.test(value)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}
/** @param {unknown} value */
const errorCode = (value) =>
  value && typeof value === 'object' && 'code' in value && typeof value.code === 'string'
    ? value.code
    : null

/** @typedef {(...args: any[]) => Promise<unknown>} RunFfmpeg */

/**
 * Read the playable duration of an uncompressed RIFF/WAVE file from its header.
 * Every narration this provider consumes is written as pcm_s16le WAV by the TTS
 * studio, the preset narration bundler, or `resolveNarrationFromAudioTokens`,
 * so the header carries an exact duration without spawning a probe process.
 * @param {string} path
 * @returns {Promise<number | null>} seconds, or null when the header is unreadable
 */
const probeWaveDurationSeconds = async (path) => {
  if (typeof path !== 'string' || !isAbsolute(path)) return null
  let handle = null
  try {
    const metadata = await lstat(path)
    if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size < 44) return null
    handle = await open(path, 'r')
    const header = Buffer.alloc(Math.min(4096, metadata.size))
    const { bytesRead } = await handle.read(header, 0, header.length, 0)
    if (
      bytesRead < 44 ||
      header.toString('latin1', 0, 4) !== 'RIFF' ||
      header.toString('latin1', 8, 12) !== 'WAVE'
    ) return null
    let byteRate = 0
    let dataSize = 0
    let offset = 12
    while (offset + 8 <= bytesRead) {
      const chunkId = header.toString('latin1', offset, offset + 4)
      const chunkSize = header.readUInt32LE(offset + 4)
      if (chunkId === 'fmt ' && offset + 8 + 16 <= bytesRead) {
        byteRate = header.readUInt32LE(offset + 8 + 8)
      } else if (chunkId === 'data') {
        // Streamed writers sometimes leave a placeholder size; fall back to the
        // real tail of the file so a valid duration is still recovered.
        dataSize = chunkSize > 0 && chunkSize !== 0xffffffff
          ? Math.min(chunkSize, metadata.size - (offset + 8))
          : metadata.size - (offset + 8)
        break
      }
      if (chunkSize <= 0) break
      offset += 8 + chunkSize + (chunkSize % 2)
    }
    if (!Number.isFinite(byteRate) || byteRate <= 0 || !Number.isFinite(dataSize) || dataSize <= 0) {
      return null
    }
    const seconds = dataSize / byteRate
    return Number.isFinite(seconds) && seconds > 0 ? seconds : null
  } catch {
    return null
  } finally {
    await handle?.close().catch(() => {})
  }
}

/** Probe encoded audio when a legacy/editor token is not a PCM WAV.
 * @param {string} path
 */
const probeAudioDurationSeconds = async (path) => {
  const wave = await probeWaveDurationSeconds(path)
  if (wave !== null) return wave
  try {
    const metadata = await lstat(path)
    if (!metadata.isFile() || metadata.isSymbolicLink()) return null
    const { stdout } = await execFileAsync('ffprobe', [
      '-v', 'error', '-show_entries', 'format=duration',
      '-of', 'default=nw=1:nk=1', path,
    ], { windowsHide: true, timeout: 30_000 })
    const seconds = Number(String(stdout).trim())
    return Number.isFinite(seconds) && seconds > 0 ? seconds : null
  } catch {
    return null
  }
}

/**
 * Measure the narration of each sentence in a resolved voiceover bundle.
 * Returns null when the legacy renderer did not provide per-sentence audio or
 * when the bundle does not line up with the shot list. Canonical RichTimeline
 * output always carries narration tokens and does not use this fallback.
 * @param {Record<string, any> | null} voiceoverBundle
 * @param {number} expectedCount
 * @returns {Promise<number[] | null>}
 */
const narrationSentenceDurations = async (voiceoverBundle, expectedCount) => {
  const segments = Array.isArray(voiceoverBundle?.segments) ? voiceoverBundle.segments : null
  if (!segments || segments.length !== expectedCount) return null
  const durations = []
  for (const segment of segments) {
    const seconds = await probeWaveDurationSeconds(segment?.path)
    if (seconds === null) return null
    durations.push(seconds)
  }
  return durations
}

/**
 * Retime every shot so it covers exactly the narration of its own sentence.
 *
 * The upstream renderer trims the voice track to `outputDuration`, so a shot
 * that is shorter than its sentence silently cuts the sentence off. Shots are
 * only ever stretched inside their detected scene bounds — material is never
 * looped or reused — and a scene that cannot cover its sentence is reported
 * instead of being quietly truncated.
 *
 * @param {Record<string, any>[]} clips
 * @param {number[]} sentenceDurations seconds, index-aligned with `clips`
 * @param {{minimumShotSeconds?: number}} [options]
 * @returns {Record<string, any>[]}
 */
const alignClipsToNarration = (clips, sentenceDurations, options = {}) => {
  const minimumShotSeconds = Number.isFinite(options.minimumShotSeconds)
    ? /** @type {number} */ (options.minimumShotSeconds)
    : 0.1
  return clips.map((clip, index) => {
    const desired = Math.max(minimumShotSeconds, Number(sentenceDurations[index]))
    const start = Number(clip.start)
    const end = Number(clip.end)
    const sceneStart = Number.isFinite(Number(clip.sceneStart)) ? Number(clip.sceneStart) : start
    const sceneEnd = Number.isFinite(Number(clip.sceneEnd)) ? Number(clip.sceneEnd) : end
    const sceneCapacity = sceneEnd - sceneStart
    if (!Number.isFinite(sceneCapacity) || sceneCapacity + 1e-6 < desired) {
      throw new ShortVideoFactoryError(
        shortVideoFactoryErrorCodes.materialDurationInsufficient,
        409,
      )
    }
    // Prefer keeping the chosen in-point; only slide earlier when the tail of
    // the scene cannot supply the remaining time.
    const nextStart = Math.max(sceneStart, Math.min(start, sceneEnd - desired))
    return { ...clip, start: nextStart, end: nextStart + desired }
  })
}

/** @param {string} lockPath @param {AbortSignal | undefined} signal */
const acquireResourceLock = async (lockPath, signal) => {
  const deadline = Date.now() + 6 * 60_000
  while (Date.now() < deadline) {
    signal?.throwIfAborted()
    try {
      await mkdir(lockPath)
      const ownerToken = randomUUID()
      const ownerPath = resolve(lockPath, 'owner')
      try {
        await writeFile(ownerPath, ownerToken, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
      } catch (error) {
        await rm(lockPath, { recursive: true, force: true })
        throw error
      }
      const ownsLock = async () =>
        await readFile(ownerPath, 'utf8').then((value) => value === ownerToken).catch(() => false)
      const assertOwned = async () => {
        if (!await ownsLock()) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.processFailed, 409)
        }
      }
      const heartbeat = setInterval(() => {
        ownsLock().then((owned) => {
          if (!owned) return
          const now = new Date()
          return utimes(lockPath, now, now)
        }).catch(() => {})
      }, 10_000)
      heartbeat.unref?.()
      return {
        assertOwned,
        release: async () => {
          clearInterval(heartbeat)
          if (await ownsLock()) {
            await rm(lockPath, { recursive: true, force: true })
          }
        },
      }
    } catch (error) {
      if (errorCode(error) !== 'EEXIST') throw error
      try {
        const metadata = await lstat(lockPath)
        if (Date.now() - metadata.mtimeMs > 60_000) {
          const stalePath = `${lockPath}.stale-${randomUUID()}`
          await rename(lockPath, stalePath)
          await rm(stalePath, { recursive: true, force: true })
          continue
        }
      } catch (inspectionError) {
        const code = errorCode(inspectionError)
        if (!code || !['ENOENT', 'EACCES', 'EPERM'].includes(code)) {
          throw inspectionError
        }
        continue
      }
      await delay(100, undefined, { signal })
    }
  }
  throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.timedOut, 504)
}

export class ShortVideoFactoryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'ShortVideoFactoryError'
    this.code = code
    this.status = status
  }
}

/** @param {string} path */
const sha256File = async (path) =>
  {
    const hash = createHash('sha256')
    for await (const chunk of createReadStream(path)) hash.update(chunk)
    return hash.digest('hex')
  }

/** @param {string} root */
const sha256Tree = async (root) => {
  /** @type {{path: string, size: number, sha256: string}[]} */
  const files = []
  /** @param {string} directory @param {string} relativeDirectory */
  const visit = async (directory, relativeDirectory) => {
    const entries = await readdir(directory, { withFileTypes: true })
    entries.sort((left, right) => left.name.localeCompare(right.name, 'en'))
    for (const entry of entries) {
      const path = resolve(directory, entry.name)
      const relativePath = relativeDirectory ? `${relativeDirectory}/${entry.name}` : entry.name
      if (entry.isSymbolicLink()) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
      }
      if (entry.isDirectory()) {
        await visit(path, relativePath)
        continue
      }
      if (!entry.isFile()) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
      }
      const metadata = await lstat(path)
      files.push({ path: relativePath, size: metadata.size, sha256: await sha256File(path) })
    }
  }
  await visit(root, '')
  const hash = createHash('sha256')
  for (const file of files) {
    hash.update(file.path).update('\u0000')
      .update(String(file.size)).update('\u0000')
      .update(file.sha256).update('\n')
  }
  return {
    fileCount: files.length,
    size: files.reduce((total, file) => total + file.size, 0),
    sha256: hash.digest('hex'),
  }
}

/** @param {string} upstreamRoot */
export const inspectGitUpstream = async (upstreamRoot) => {
  /** @param {string[]} args */
  const run = async (args) => {
    const { stdout } = await execFileAsync('git', ['-C', upstreamRoot, ...args], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 30_000,
    })
    return stdout.trim()
  }
  const [commit, repository, status] = await Promise.all([
    run(['rev-parse', 'HEAD']),
    run(['remote', 'get-url', 'origin']),
    run(['status', '--porcelain', '--untracked-files=all']),
  ])
  return { commit, repository, clean: status === '' }
}

/** @param {any} value */
const validManifest = (value) =>
  value &&
  typeof value === 'object' &&
  !Array.isArray(value) &&
  Object.keys(value).sort().join('\u0000') ===
    ['artifacts', 'commit', 'interface', 'license', 'repository', 'runtimeTrees', 'version'].sort().join('\u0000') &&
  value.repository === 'https://github.com/YILS-LIN/short-video-factory.git' &&
  typeof value.commit === 'string' &&
  /^[a-f0-9]{40}$/u.test(value.commit) &&
  value.license === 'AGPL-3.0' &&
  value.interface === 'electron-preload-ipc' &&
  value.version === '1.2.2' &&
  Array.isArray(value.artifacts) &&
  value.artifacts.length > 0 &&
  value.artifacts.every((/** @type {any} */ artifact) =>
    artifact &&
    typeof artifact === 'object' &&
    !Array.isArray(artifact) &&
    Object.keys(artifact).sort().join('\u0000') ===
      ['path', 'sha256', 'size'].sort().join('\u0000') &&
    typeof artifact.path === 'string' &&
    artifact.path.length > 0 &&
    !isAbsolute(artifact.path) &&
    !artifact.path.split(/[\\/]/u).includes('..') &&
    Number.isSafeInteger(artifact.size) &&
    artifact.size > 0 &&
    typeof artifact.sha256 === 'string' &&
    /^[a-f0-9]{64}$/u.test(artifact.sha256)) &&
  Array.isArray(value.runtimeTrees) &&
  value.runtimeTrees.length > 0 &&
  value.runtimeTrees.every((/** @type {any} */ tree) =>
    tree &&
    typeof tree === 'object' &&
    !Array.isArray(tree) &&
    Object.keys(tree).sort().join('\u0000') ===
      ['fileCount', 'path', 'sha256', 'size'].sort().join('\u0000') &&
    typeof tree.path === 'string' &&
    tree.path.length > 0 &&
    !isAbsolute(tree.path) &&
    !tree.path.split(/[\\/]/u).includes('..') &&
    Number.isSafeInteger(tree.fileCount) &&
    tree.fileCount > 0 &&
    Number.isSafeInteger(tree.size) &&
    tree.size > 0 &&
    typeof tree.sha256 === 'string' &&
    /^[a-f0-9]{64}$/u.test(tree.sha256))

/**
 * @param {{
 *   dataRoot: string,
 *   upstreamRoot: string,
 *   manifest: Record<string, any>,
 *   inspectUpstream?: (root: string) => Promise<{commit: string, repository: string, clean: boolean}>,
 *   bridge?: (input: Record<string, any>) => Promise<void>,
 *   securePrivateRoot?: (root: string) => Promise<void>,
 *   voice?: string | null,
 *   voiceRate?: number,
 *   bgmPath?: string | null,
 *   acquireBgmLease?: ((input: {projectId: string, authorizationId: string}) => Promise<{extension: string, sha256: string, size: number, acquireFileDescriptor: () => number, createStream: () => import('node:stream').Readable, verifyIntegrity: () => Promise<boolean>, release: () => Promise<void>} | null>) | null,
 *   resolveVoiceoverAudio?: ((input: {projectId: string, voiceId: string, rate: number, segments: Array<{sentenceId: string, text: string}>, signal?: AbortSignal, onProgress?: Function}) => Promise<Record<string, any>>) | null,
 *   resolveAudioToken?: ((input: {audioToken: string, projectId: string}) => Promise<string | null>) | null,
 *   ffmpegPath?: string | null,
 *   executeFfmpeg?: ((path: string, args: string[], options: Record<string, any>) => Promise<unknown>) | null,
 *   mixBgmIntoPreview?: ((input: {inputPath: string, outputPath: string, bgmPath?: string | null, bgmFileDescriptor?: number | null, volume: number, durationSeconds: number, sfxInputs?: Array<{path: string, volume: number, startSeconds: number, durationSeconds: number}>, signal?: AbortSignal}) => Promise<void>) | null,
 *   resolveSfxAudio?: ((input: {audioToken: string, projectId: string}) => Promise<string | {path?: string, extension?: string, sha256?: string, size?: number, createStream?: () => import('node:stream').Readable, verifyIntegrity?: () => Promise<boolean>, release?: () => Promise<void>} | null>) | null,
 *   spawnFfmpeg?: typeof spawn,
 *   isProcessAlive?: (pid: number) => boolean,
 * }} options
 */
export const createShortVideoFactoryProvider = async ({
  dataRoot,
  upstreamRoot,
  manifest,
  inspectUpstream = inspectGitUpstream,
  bridge,
  securePrivateRoot = securePrivateRuntimeRoot,
  voice = null,
  voiceRate = 0,
  bgmPath = null,
  acquireBgmLease = null,
  resolveVoiceoverAudio = null,
  resolveAudioToken = null,
  ffmpegPath = null,
  executeFfmpeg = null,
  mixBgmIntoPreview = null,
  resolveSfxAudio = null,
  spawnFfmpeg = spawn,
  isProcessAlive = (pid) => {
    try {
      process.kill(pid, 0)
      return true
    } catch (error) {
      return errorCode(error) !== 'ESRCH'
    }
  },
}) => {
  if (
    typeof dataRoot !== 'string' ||
    !isAbsolute(dataRoot) ||
    typeof upstreamRoot !== 'string' ||
    !isAbsolute(upstreamRoot) ||
    !validManifest(manifest) ||
    typeof inspectUpstream !== 'function' ||
    typeof bridge !== 'function' ||
    typeof securePrivateRoot !== 'function' ||
    typeof isProcessAlive !== 'function' ||
    (acquireBgmLease !== null && typeof acquireBgmLease !== 'function') ||
    (resolveVoiceoverAudio !== null && typeof resolveVoiceoverAudio !== 'function') ||
    (resolveAudioToken !== null && typeof resolveAudioToken !== 'function') ||
    (executeFfmpeg !== null && typeof executeFfmpeg !== 'function') ||
    (mixBgmIntoPreview !== null && typeof mixBgmIntoPreview !== 'function') ||
    (resolveSfxAudio !== null && typeof resolveSfxAudio !== 'function') ||
    typeof spawnFfmpeg !== 'function' ||
    (ffmpegPath !== null && (typeof ffmpegPath !== 'string' || !isAbsolute(ffmpegPath))) ||
    (voice !== null && !safeId(voice)) ||
    !Number.isSafeInteger(voiceRate) ||
    voiceRate < -100 ||
    voiceRate > 100 ||
    (bgmPath !== null && (typeof bgmPath !== 'string' || !isAbsolute(bgmPath)))
  ) {
    throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
  }

  let canonicalRoot
  let inspection
  try {
    canonicalRoot = await realpath(upstreamRoot)
    inspection = await inspectUpstream(canonicalRoot)
  } catch {
    throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
  }
  if (
    inspection.commit !== manifest.commit ||
    inspection.repository !== manifest.repository ||
    inspection.clean !== true
  ) {
    throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
  }

  const verifyRuntimeIntegrity = async () => {
    try {
      const latestInspection = await inspectUpstream(canonicalRoot)
      if (
        latestInspection.commit !== manifest.commit ||
        latestInspection.repository !== manifest.repository ||
        latestInspection.clean !== true
      ) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
      }
      for (const artifact of manifest.artifacts) {
        const artifactPath = await realpath(resolve(canonicalRoot, artifact.path))
        if (!inside(canonicalRoot, artifactPath)) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
        }
        const metadata = await lstat(artifactPath)
        if (
          !metadata.isFile() ||
          metadata.size !== artifact.size ||
          await sha256File(artifactPath) !== artifact.sha256
        ) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
        }
      }
      for (const tree of manifest.runtimeTrees) {
        const treePath = await realpath(resolve(canonicalRoot, tree.path))
        if (!inside(canonicalRoot, treePath) || !(await lstat(treePath)).isDirectory()) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
        }
        const actual = await sha256Tree(treePath)
        if (
          actual.fileCount !== tree.fileCount ||
          actual.size !== tree.size ||
          actual.sha256 !== tree.sha256
        ) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
        }
      }
    } catch (error) {
      if (error instanceof ShortVideoFactoryError) throw error
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
    }
  }
  try {
    await verifyRuntimeIntegrity()
  } catch (error) {
    if (error instanceof ShortVideoFactoryError) throw error
    throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
  }

  const bundledFfmpegArtifact = manifest.artifacts.find(
    (/** @type {Record<string, any>} */ artifact) =>
      artifact.path.replace(/\\/gu, '/') === 'node_modules/ffmpeg-static/ffmpeg.exe',
  ) ?? null
  const bundledFfmpegPath = bundledFfmpegArtifact
    ? resolve(canonicalRoot, bundledFfmpegArtifact.path)
    : null
  const previewMixerPath = executeFfmpeg
    ? (ffmpegPath ?? bundledFfmpegPath)
    : bundledFfmpegPath
  const runFfmpeg = executeFfmpeg ?? execFileAsync
  let verifiedBgmPath = null
  if (bgmPath !== null) {
    try {
      const originalMetadata = await lstat(bgmPath)
      const canonicalBgmPath = await realpath(bgmPath)
      const canonicalMetadata = await lstat(canonicalBgmPath)
      if (
        originalMetadata.isSymbolicLink() ||
        !originalMetadata.isFile() ||
        !canonicalMetadata.isFile()
      ) throw new Error('invalid_bgm')
      verifiedBgmPath = canonicalBgmPath
    } catch {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
  }

  const privateRoot = resolve(dataRoot, 'short-video-factory')
  const workRoot = resolve(privateRoot, 'work')
  const resourceRoot = resolve(privateRoot, 'resources')
  await mkdir(workRoot, { recursive: true })
  await mkdir(resourceRoot, { recursive: true })
  await securePrivateRoot(privateRoot)

  /** @param {string[]} args @param {number} fileDescriptor @param {AbortSignal | undefined} signal */
  const runFfmpegWithFileDescriptor = async (args, fileDescriptor, signal) => {
    if (typeof previewMixerPath !== 'string' || !isAbsolute(previewMixerPath)) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    if (!Number.isSafeInteger(fileDescriptor) || fileDescriptor < 0) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    signal?.throwIfAborted()
    const child = spawnFfmpeg(previewMixerPath, args, {
      stdio: ['ignore', 'ignore', 'pipe', fileDescriptor],
      windowsHide: true,
      signal,
    })
    let stderrBytes = 0
    child.stderr?.on('data', (chunk) => {
      stderrBytes += Buffer.byteLength(chunk)
      if (stderrBytes > 65_536) child.stderr?.destroy()
    })
    let closedSettled = false
    const closed = new Promise((resolve, reject) => {
      child.once('error', (error) => {
        closedSettled = true
        reject(error)
      })
      child.once('close', (code, terminationSignal) => {
        closedSettled = true
        if (code === 0 && terminationSignal === null) resolve(undefined)
        else reject(new Error('ffmpeg-stream-failed'))
      })
    })
    const timeout = setTimeout(() => child.kill('SIGKILL'), 120_000)
    try {
      await closed
    } finally {
      clearTimeout(timeout)
      if (!closedSettled && child.exitCode === null && child.signalCode === null) {
        child.kill('SIGKILL')
      }
    }
  }

  const mixPreviewBgm = mixBgmIntoPreview ?? (async ({
    inputPath,
    outputPath,
    bgmPath: selectedBgmPath = null,
    bgmFileDescriptor = null,
    volume,
    durationSeconds,
    sfxInputs = [],
    signal,
  }) => {
    if (typeof previewMixerPath !== 'string' || !isAbsolute(previewMixerPath)) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    const inputSource = bgmFileDescriptor !== null ? 'fd:' : selectedBgmPath
    if (typeof inputSource !== 'string' && sfxInputs.length === 0) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    if (!Array.isArray(sfxInputs) || sfxInputs.length > maxPreviewSfxInputs || sfxInputs.some((item) =>
      !item || typeof item.path !== 'string' || !isAbsolute(item.path) ||
      !Number.isFinite(item.volume) || item.volume < 0 || item.volume > 1 ||
      !Number.isFinite(item.startSeconds) || item.startSeconds < 0 ||
      !Number.isFinite(item.durationSeconds) || item.durationSeconds <= 0)) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }
    const args = [
      '-hide_banner',
      '-loglevel',
      'error',
      '-y',
      '-i',
      inputPath,
      ...(typeof inputSource === 'string' ? [
        '-stream_loop', '-1',
        ...(bgmFileDescriptor !== null ? ['-fd', '3'] : []),
        '-i', inputSource,
      ] : []),
    ]
    for (const item of sfxInputs) args.push('-i', item.path)
    const audioLabels = []
    const filters = []
    if (typeof inputSource === 'string') {
      filters.push(`[1:a]volume=${Number(volume).toFixed(6)}[bgm]`)
      audioLabels.push('[bgm]')
    }
    for (const [index, item] of sfxInputs.entries()) {
      const inputIndex = typeof inputSource === 'string' ? index + 2 : index + 1
      const delayMs = Math.max(0, Math.round(item.startSeconds * 1_000))
      const duration = Math.max(0.001, item.durationSeconds)
      filters.push(`[${inputIndex}:a]atrim=duration=${duration.toFixed(6)},asetpts=PTS-STARTPTS,volume=${Number(item.volume).toFixed(6)},adelay=${delayMs}:all=1[sfx${index}]`)
      audioLabels.push(`[sfx${index}]`)
    }
    if (audioLabels.length === 0) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    filters.push(`[0:a]${audioLabels.join('')}amix=inputs=${audioLabels.length + 1}:duration=first:dropout_transition=0:normalize=0[aout]`)
    args.push(
      '-filter_complex',
      filters.join(';'),
      '-map',
      '0:v:0',
      '-map',
      '[aout]',
      '-c:v',
      'copy',
      '-c:a',
      'aac',
      '-t',
      String(durationSeconds),
      outputPath,
    )
    signal?.throwIfAborted()
    if (bgmFileDescriptor !== null) {
      await runFfmpegWithFileDescriptor(args, bgmFileDescriptor, signal)
    }
    else await runFfmpeg(previewMixerPath, args, { timeout: 120_000, windowsHide: true, signal })
  })

  const staleWorkDeadline = Date.now() - 60 * 60_000
  const workEntries = await readdir(workRoot, { withFileTypes: true })
  for (const entry of workEntries) {
    if (
      !entry.isDirectory() ||
      entry.isSymbolicLink() ||
      !/^[a-z0-9][a-z0-9._-]{0,199}-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/iu.test(entry.name)
    ) continue
    const entryPath = resolve(workRoot, entry.name)
    const ownerPath = resolve(entryPath, '.openvideo-owner.json')
    const ownerMetadata = await lstat(ownerPath).catch(() => null)
    const owner = await readFile(ownerPath, 'utf8')
      .then((value) => JSON.parse(value))
      .catch(() => null)
    if (
      ownerMetadata?.isFile() &&
      !ownerMetadata.isSymbolicLink() &&
      Number.isSafeInteger(owner?.pid) &&
      owner.pid > 0 &&
      typeof owner?.token === 'string' &&
      /^[a-f0-9-]{36}$/iu.test(owner.token) &&
      ownerMetadata.mtimeMs < staleWorkDeadline &&
      isProcessAlive(owner.pid) === false
    ) {
      await rm(entryPath, { recursive: true, force: true })
    }
  }

  const status = {
    available: true,
    state: 'ready',
    code: null,
    provider: 'short-video-factory',
    commit: manifest.commit,
    license: manifest.license,
  }
  if (!validShortVideoFactoryStatus(status)) {
    throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.integrityMismatch, 503)
  }

  /** @param {Record<string, any>} input */
  const generatePreview = async (/** @type {Record<string, any>} */ input) => {
    const {
      signal,
      onProgress,
      onStarted,
      bgmLease: requestBgmLease = null,
      sfxInputs: rawSfxInputs,
      ...requestInput
    } = input ?? {}
    /** @type {Record<string, any>} */
    const request = {
      ...requestInput,
      bgmVolume: requestInput.bgmVolume ?? 0.12,
      // Scene bounds are planning-only metadata used to retime shots; the
      // upstream render contract accepts nothing beyond the four clip keys.
      ...(Array.isArray(requestInput.clips)
        ? {
            clips: requestInput.clips.map((/** @type {Record<string, any>} */ clip) => ({
              candidateId: clip.candidateId,
              sourcePath: clip.sourcePath,
              start: clip.start,
              end: clip.end,
            })),
          }
        : {}),
    }
    if (
      !validShortVideoFactoryRequest(request) ||
      (signal !== undefined && !(signal instanceof AbortSignal)) ||
      (onProgress !== undefined && typeof onProgress !== 'function') ||
      (onStarted !== undefined && typeof onStarted !== 'function') ||
      (requestBgmLease !== null && (
        typeof requestBgmLease.acquireFileDescriptor !== 'function' ||
        typeof requestBgmLease.createStream !== 'function' ||
        typeof requestBgmLease.verifyIntegrity !== 'function' ||
        typeof requestBgmLease.release !== 'function'
      ))
    ) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }
    const sfxInputs = rawSfxInputs === undefined ? [] : rawSfxInputs
    if (
      !Array.isArray(sfxInputs) ||
      sfxInputs.length > maxPreviewSfxInputs ||
      sfxInputs.some((item) =>
        !isRecord(item) ||
        !Number.isFinite(item.volume) || item.volume < 0 || item.volume > 1 ||
        !Number.isFinite(item.startSeconds) || item.startSeconds < 0 ||
        !Number.isFinite(item.durationSeconds) || item.durationSeconds <= 0 ||
        item.startSeconds + item.durationSeconds > request.outputDurationSeconds + 0.000001 ||
        !(
          (typeof item.source === 'string' && isAbsolute(item.source) && !item.source.includes('\u0000')) ||
          (isRecord(item.source) && (
            (typeof item.source.path === 'string' && isAbsolute(item.source.path) && !item.source.path.includes('\u0000')) ||
            (
              typeof item.source.extension === 'string' &&
              /^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(item.source.extension) &&
              typeof item.source.sha256 === 'string' && /^[a-f0-9]{64}$/u.test(item.source.sha256) &&
              Number.isSafeInteger(item.source.size) && item.source.size > 0 &&
              typeof item.source.createStream === 'function' &&
              typeof item.source.release === 'function'
            )
          ))
        ))
    ) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }
    if (signal?.aborted) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.cancelled, 409)
    }
    const captionsEnabled = request.captions?.enabled === true

    const hasBgm = (request.bgmPath !== null || requestBgmLease !== null) && request.bgmVolume > 0
    const resourceId = `preview-${request.jobId}`
    const jobWorkRoot = resolve(workRoot, `${request.jobId}-${randomUUID()}`)
    const projectResourceRoot = resolve(resourceRoot, request.projectId)
    const stagedOutputPath = resolve(jobWorkRoot, 'preview.mp4')
    const outputPath = resolve(projectResourceRoot, `${resourceId}.mp4`)
    const lockPath = resolve(projectResourceRoot, `${resourceId}.lock`)
    await mkdir(jobWorkRoot, { recursive: true })
    await writeFile(
      resolve(jobWorkRoot, '.openvideo-owner.json'),
      `${JSON.stringify({ pid: process.pid, token: randomUUID() })}\n`,
      { encoding: 'utf8', flag: 'wx', mode: 0o600 },
    )
    await mkdir(projectResourceRoot, { recursive: true })
    /** @type {{assertOwned: () => Promise<void>, release: () => Promise<void>} | null} */
    let lock = null
    try {
      lock = await acquireResourceLock(lockPath, signal)
      await verifyRuntimeIntegrity()
      const existing = await getResource({
        projectId: request.projectId,
        resourceId,
      })
      if (existing) {
        return {
          resourceId,
          durationSeconds: request.outputDurationSeconds,
          provider: hasBgm
            ? 'short-video-factory+openvideo-bgm-mixer'
            : 'short-video-factory',
          features: {
            voiceover: request.voiceover.enabled,
            captions: captionsEnabled,
            bgm: hasBgm,
          },
        }
      }
      await rm(outputPath, { force: true })
      const materializedSfxInputs = []
      try {
        for (const [index, item] of sfxInputs.entries()) {
          signal?.throwIfAborted()
          const source = item.source
          let sourcePath
          if (typeof source === 'string' || typeof source.path === 'string') {
            const requestedPath = typeof source === 'string' ? source : source.path
            const requestedMetadata = await lstat(requestedPath)
            sourcePath = await realpath(requestedPath)
            const canonicalMetadata = await lstat(sourcePath)
            if (
              requestedMetadata.isSymbolicLink() ||
              !requestedMetadata.isFile() ||
              !canonicalMetadata.isFile() ||
              canonicalMetadata.isSymbolicLink()
            ) throw new Error('invalid_sfx_path')
          } else {
            sourcePath = resolve(jobWorkRoot, `sfx-${index + 1}${source.extension}`)
            await pipeline(
              source.createStream(),
              createWriteStream(sourcePath, { flags: 'wx', mode: 0o600 }),
              { signal },
            )
            const metadata = await stat(sourcePath)
            if (
              !metadata.isFile() ||
              metadata.size !== source.size ||
              await sha256File(sourcePath) !== source.sha256
            ) throw new Error('invalid_sfx_lease')
          }
          materializedSfxInputs.push({
            path: sourcePath,
            volume: item.volume,
            startSeconds: item.startSeconds,
            durationSeconds: item.durationSeconds,
          })
        }
      } catch (error) {
        if (signal?.aborted || errorCode(error) === 'ABORT_ERR') throw error
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
      }
      await bridge({
        request: hasBgm ? { ...request, bgmPath: null } : request,
        upstreamRoot: canonicalRoot,
        workRoot: jobWorkRoot,
        outputPath: stagedOutputPath,
        signal,
        onProgress: (/** @type {number} */ progress) => {
          if (Number.isFinite(progress)) {
            // Reserve the first 20% for source preparation and leave the last
            // 10% for post-processing and publication checkpoints.
            onProgress?.(Math.max(20, Math.min(90, Math.round(20 + Number(progress) * 0.7))))
          }
        },
        onStarted,
      })
      if (hasBgm || materializedSfxInputs.length > 0) {
        const mixedOutputPath = resolve(jobWorkRoot, 'preview-with-audio.mp4')
        let mixed = false
        try {
          await mixPreviewBgm({
            inputPath: stagedOutputPath,
            outputPath: mixedOutputPath,
            bgmPath: request.bgmPath,
            bgmFileDescriptor: requestBgmLease?.acquireFileDescriptor() ?? null,
            volume: request.bgmVolume,
            durationSeconds: request.outputDurationSeconds,
            sfxInputs: materializedSfxInputs,
            signal,
          })
          mixed = true
        } catch (error) {
          if (signal?.aborted || errorCode(error) === 'ABORT_ERR') throw error
          await rm(mixedOutputPath, { force: true })
          if (materializedSfxInputs.length > 0) {
            throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
          }
          if (hasBgm) throw error
        }
        if (hasBgm && requestBgmLease && !await requestBgmLease.verifyIntegrity()) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
        }
        if (mixed) {
          await rm(stagedOutputPath, { force: true })
          await rename(mixedOutputPath, stagedOutputPath)
        }
      }
      signal?.throwIfAborted()
      const metadata = await stat(stagedOutputPath)
      if (!metadata.isFile() || metadata.size < 12) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.outputInvalid, 502)
      }
      const header = Buffer.alloc(Math.min(64, metadata.size))
      const output = await open(stagedOutputPath, 'r')
      try {
        await output.read(header, 0, header.length, 0)
      } finally {
        await output.close()
      }
      if (!header.includes(Buffer.from('ftyp'))) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.outputInvalid, 502)
      }
      const result = {
        resourceId,
        durationSeconds: request.outputDurationSeconds,
        provider: hasBgm
          ? 'short-video-factory+openvideo-bgm-mixer'
          : 'short-video-factory',
        features: {
          voiceover: request.voiceover.enabled,
          captions: captionsEnabled,
          bgm: hasBgm,
        },
      }
      if (!validShortVideoFactoryResult(result)) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.outputInvalid, 502)
      }
      await lock.assertOwned()
      await rename(stagedOutputPath, outputPath)
      return result
    } catch (error) {
      if (signal?.aborted || errorCode(error) === 'ABORT_ERR') {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.cancelled, 409)
      }
      if (error instanceof ShortVideoFactoryError) throw error
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.renderFailed, 502)
    } finally {
      await lock?.release()
      await rm(jobWorkRoot, { recursive: true, force: true })
    }
  }

  /** @param {string | null} authorizationId @param {string} projectId */
  const acquireAuthorizedBgm = async (authorizationId, projectId) => {
    if (!authorizationId || typeof acquireBgmLease !== 'function') return null
    const lease = await acquireBgmLease({ projectId, authorizationId })
    if (!lease) return null
    if (
      typeof lease.extension !== 'string' || !/^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(lease.extension) ||
      typeof lease.sha256 !== 'string' || !/^[a-f0-9]{64}$/u.test(lease.sha256) ||
      !Number.isSafeInteger(lease.size) || lease.size <= 0 ||
      typeof lease.acquireFileDescriptor !== 'function' ||
      typeof lease.createStream !== 'function' ||
      typeof lease.verifyIntegrity !== 'function' ||
      typeof lease.release !== 'function'
    ) {
      if (typeof lease.release === 'function') await lease.release().catch(() => {})
      return null
    }
    return lease
  }

  /** @param {Record<string, any>} brief @param {ReturnType<typeof normalizePackaging>} packaging */
  const scriptForPreview = (brief, packaging) => {
    const titleText = typeof brief.title === 'string' && brief.title.trim()
      ? brief.title.trim().slice(0, 160)
      : ''
    // Packaging keyword highlights are reserved for Jianying rich-text slots.
    // Do not append them to the narration script, otherwise the upstream
    // caption renderer turns FlowerText intent into a plain preview subtitle.
    let script = brief.script
    // Preview title cards are represented as auditable caption lines; Jianying draft
    // writes dedicated title text tracks. Avoid injecting synthetic video clips into
    // short-video-factory because upstream render is sensitive to non-material sources.
    if (titleText && packaging.intro === 'title_card') {
      script = `【片头】${titleText}\n${script}`
    }
    if (titleText && packaging.outro === 'title_card') {
      script = `${script}\n【片尾】${titleText}`
    }
    return script
  }

  /**
   * Concatenate opaque timeline audio token paths into one narration file.
   * @param {{projectId: string, jobId: string, audioTokens: string[], signal?: AbortSignal}} input
   */
  const resolveNarrationFromAudioTokens = async (input) => {
    if (typeof resolveAudioToken !== 'function') {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    if (
      !safeId(input.projectId) ||
      !safeId(input.jobId) ||
      !Array.isArray(input.audioTokens) ||
      input.audioTokens.length === 0 ||
      input.audioTokens.some((token) => !safeId(token))
    ) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }
    /** @type {string[]} */
    const paths = []
    for (const token of input.audioTokens) {
      input.signal?.throwIfAborted()
      const resolved = await resolveAudioToken({
        audioToken: token,
        projectId: input.projectId,
      })
      if (typeof resolved !== 'string' || !isAbsolute(resolved)) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
      }
      paths.push(resolved)
    }
    if (paths.length === 1) {
      return { narrationPath: paths[0], assetId: input.audioTokens[0] }
    }
    if (typeof previewMixerPath !== 'string' || !isAbsolute(previewMixerPath)) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    const jobWorkRoot = resolve(workRoot, `${input.jobId}-voice-${randomUUID()}`)
    await mkdir(jobWorkRoot, { recursive: true })
    const narrationPath = resolve(jobWorkRoot, 'narration-from-tokens.wav')
    const labels = paths.map((_, index) => `[${index}:a]`).join('')
    const audioFilter = paths.length === 1
      ? '[0:a]anull[outa]'
      : `${labels}concat=n=${paths.length}:v=0:a=1[outa]`
    try {
      await runFfmpeg(
        previewMixerPath,
        [
          '-hide_banner',
          '-loglevel',
          'error',
          '-y',
          ...paths.flatMap((path) => ['-i', path]),
          '-filter_complex',
          audioFilter,
          '-map',
          '[outa]',
          '-c:a',
          'pcm_s16le',
          narrationPath,
        ],
        { timeout: 120_000, windowsHide: true, signal: input.signal },
      )
      const metadata = await stat(narrationPath)
      if (!metadata.isFile() || metadata.size < 44) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
      }
      return {
        narrationPath,
        assetId: `tokens_${input.audioTokens[0]}`,
        cleanupRoot: jobWorkRoot,
      }
    } catch (error) {
      await rm(jobWorkRoot, { recursive: true, force: true }).catch(() => {})
      if (error instanceof ShortVideoFactoryError) throw error
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
  }

  /** @param {Record<string, any>} input */
  const renderPreview = async (input) => {
    if (
      !input ||
      typeof input !== 'object' ||
      Array.isArray(input) ||
      !safeId(input.projectId) ||
      !safeId(input.jobId) ||
      !input.brief ||
      typeof input.brief !== 'object' ||
      !['portrait', 'landscape', 'square'].includes(input.brief.orientation) ||
      !['none', 'required'].includes(input.brief.voiceover) ||
      !['none', 'auto'].includes(input.brief.captions) ||
      typeof input.brief.script !== 'string' ||
      !Array.isArray(input.clips)
    ) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }

    const editorBound = input.editorBound === true
    const timelinePackaging = isRecord(input.timelinePackaging) ? input.timelinePackaging : null
    if (editorBound && !timelinePackaging) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }

    const brief = normalizeBrief(input.brief)
    if (brief.voiceover === 'required' && !brief.voiceId) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    const resolvedVoice = resolvePreviewVoice(brief, { fallbackVoice: voice })
    if (resolvedVoice.enabled && !resolvedVoice.voice) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
    }
    const templateGuidance = editorBound
      ? null
      : input.templateGuidance &&
        typeof input.templateGuidance === 'object' &&
        !Array.isArray(input.templateGuidance)
        ? structuredClone(input.templateGuidance)
        : null
    if (!editorBound) {
      assertTemplateGuidanceExecutable(templateGuidance)
      if (
        templateGuidance &&
        (
          !['portrait', 'landscape', 'square'].includes(templateGuidance.orientation) ||
          templateGuidance.orientation !== brief.orientation
        )
      ) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
      }
    }

    /** @type {string | null} */
    let cleanupRoot = null
    /** @type {{extension: string, sha256: string, size: number, acquireFileDescriptor: () => number, createStream: () => import('node:stream').Readable, verifyIntegrity: () => Promise<boolean>, release: () => Promise<void>} | null} */
    let bgmLease = null
    /** @type {Array<Record<string, any>>} */
    const resolvedSfxResources = []
    try {
      let sharedVoiceover = null
      /** @type {string | null} */
      let requestBgmPath = verifiedBgmPath
      let requestBgmVolume = 0.12
      const requestSfxInputs = []
      let script = brief.script
      // The governed upstream Preview contract exposes only a boolean and no
      // caption safe-area/style coordinates. Do not burn automatic captions
      // into an MP4 when their placement cannot be verified. The Jianying
      // draft path still honors brief.captions with its controlled text style.
      let captionsEnabled = false
      // Both branches below derive the runtime themselves: an edited timeline
      // reports its own length, and an automatic cut follows the narration.
      let durationSeconds = 0
      let clips = input.clips

      if (editorBound && timelinePackaging) {
        if (
          timelinePackaging.kind !== 'preview_timeline_packaging' ||
          !Array.isArray(timelinePackaging.voiceoverAudioTokens) ||
          typeof timelinePackaging.durationUs !== 'number' ||
          !Number.isFinite(timelinePackaging.durationUs) ||
          timelinePackaging.durationUs <= 0 ||
          typeof input.script !== 'string' ||
          !input.script.trim()
        ) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
        }
        if (timelinePackaging.voiceoverAudioTokens.length > 0) {
          try {
            const narration = await resolveNarrationFromAudioTokens({
              projectId: input.projectId,
              jobId: input.jobId,
              audioTokens: timelinePackaging.voiceoverAudioTokens,
              signal: input.signal,
            })
            sharedVoiceover = {
              narrationPath: narration.narrationPath,
              assetId: narration.assetId,
            }
            cleanupRoot = narration.cleanupRoot ?? null
          } catch (error) {
            throw error
          }
        } else if (brief.voiceover === 'required') {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
        }
        script = input.script.trim().slice(0, 8000)
        // Preview subtitles remain omitted until the upstream renderer exposes
        // an auditable safe-area contract; canonical captions are retained for
        // the Jianying writer.
        captionsEnabled = false
        durationSeconds = timelinePackaging.durationUs / 1_000_000
        requestBgmVolume = timelinePackaging.bgm?.volume ?? 0.12
        // Product rule: Preview MP4 keeps voiceover and BGM only. Canonical
        // SFX remain on the timeline for the Jianying writer and must not be
        // mixed, resolved, or allowed to fail this render.
        const sfxSegments = []
        if (
          !Array.isArray(sfxSegments) ||
          sfxSegments.length > maxPreviewSfxInputs ||
          sfxSegments.some((segment) =>
            !isRecord(segment) ||
            !safeId(segment.segmentId) ||
            !safeId(segment.audioToken) ||
            !Number.isFinite(segment.volume) || segment.volume < 0 || segment.volume > 1 ||
            !Number.isSafeInteger(segment.targetStartUs) || segment.targetStartUs < 0 ||
            !Number.isSafeInteger(segment.targetDurationUs) || segment.targetDurationUs <= 0 ||
            segment.targetStartUs + segment.targetDurationUs > timelinePackaging.durationUs)
        ) {
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
        }
        if (sfxSegments.length > 0) {
          if (typeof resolveSfxAudio !== 'function') {
            throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
          }
          for (const segment of sfxSegments) {
            input.signal?.throwIfAborted()
            let resolvedSfx = null
            try {
              resolvedSfx = await resolveSfxAudio({
                audioToken: segment.audioToken,
                projectId: input.projectId,
              })
            } catch (error) {
              if (input.signal?.aborted || errorCode(error) === 'ABORT_ERR') throw error
              throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
            }
            if (
              !(
                (typeof resolvedSfx === 'string' && isAbsolute(resolvedSfx) && !resolvedSfx.includes('\u0000')) ||
                (isRecord(resolvedSfx) && (
                  (typeof resolvedSfx.path === 'string' && isAbsolute(resolvedSfx.path) && !resolvedSfx.path.includes('\u0000')) ||
                  (
                    typeof resolvedSfx.extension === 'string' &&
                    /^\.(?:aac|flac|m4a|mp3|ogg|wav)$/u.test(resolvedSfx.extension) &&
                    typeof resolvedSfx.sha256 === 'string' && /^[a-f0-9]{64}$/u.test(resolvedSfx.sha256) &&
                    Number.isSafeInteger(resolvedSfx.size) && Number(resolvedSfx.size) > 0 &&
                    typeof resolvedSfx.createStream === 'function' &&
                    typeof resolvedSfx.release === 'function'
                  )
                ))
              )
            ) {
              if (isRecord(resolvedSfx) && typeof resolvedSfx.release === 'function') {
                resolvedSfxResources.push(resolvedSfx)
              }
              throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
            }
            if (isRecord(resolvedSfx)) resolvedSfxResources.push(resolvedSfx)
            requestSfxInputs.push({
              source: resolvedSfx,
              volume: segment.volume,
              startSeconds: segment.targetStartUs / 1_000_000,
              durationSeconds: segment.targetDurationUs / 1_000_000,
            })
          }
        }
        if (timelinePackaging.bgm?.audioToken) {
          if (
            timelinePackaging.bgm.capabilityId === 'audio.bgm.local' ||
            timelinePackaging.bgm.sourceKind === 'authorization'
          ) {
            bgmLease = await acquireAuthorizedBgm(
              timelinePackaging.bgm.audioToken,
              input.projectId,
            )
            requestBgmPath = null
          } else if (typeof resolveAudioToken === 'function') {
            const resolvedBgm = await resolveAudioToken({
              audioToken: timelinePackaging.bgm.audioToken,
              projectId: input.projectId,
            })
            requestBgmPath =
              typeof resolvedBgm === 'string' && isAbsolute(resolvedBgm) ? resolvedBgm : null
          }
          if (!bgmLease && !requestBgmPath) {
            throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
          }
        }
        clips = input.clips
      } else {
        const guidancePackaging = templateGuidance?.rules?.packaging
        const packaging = normalizePackaging({
          ...brief.packaging,
          ...(typeof guidancePackaging?.intro === 'string'
            ? { intro: guidancePackaging.intro }
            : {}),
          ...(typeof guidancePackaging?.outro === 'string'
            ? { outro: guidancePackaging.outro }
            : {}),
          ...(typeof guidancePackaging?.subtitleStyle === 'string'
            ? { subtitleStyle: guidancePackaging.subtitleStyle }
            : {}),
        })
        if (
          resolvedVoice.enabled &&
          (isRunningHubVoiceId(resolvedVoice.voice) || isJianyingPresetVoiceId(resolvedVoice.voice))
        ) {
          if (
            typeof resolveVoiceoverAudio !== 'function' ||
            !Array.isArray(input.voiceoverSegments) ||
            input.voiceoverSegments.length === 0 ||
            input.voiceoverSegments.some((segment) =>
              !segment ||
              typeof segment !== 'object' ||
              !safeId(segment.sentenceId) ||
              typeof segment.text !== 'string' ||
              !segment.text.trim())
          ) {
            throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
          }
          try {
            sharedVoiceover = await resolveVoiceoverAudio({
              projectId: input.projectId,
              voiceId: resolvedVoice.voice,
              rate: resolvedVoice.rate,
              segments: input.voiceoverSegments,
              signal: input.signal,
              onProgress: (/** @type {{completed: number, total: number}} */ { completed, total }) => {
                if (Number.isFinite(completed) && Number.isFinite(total) && total > 0) {
                  input.onProgress?.(Math.min(18, Math.max(1, Math.round(completed / total * 18))))
                }
              },
            })
          } catch (error) {
            throw new ShortVideoFactoryError(
              error && typeof error === 'object' && 'status' in error && error.status === 409
                ? shortVideoFactoryErrorCodes.cancelled
                : shortVideoFactoryErrorCodes.unavailable,
              error && typeof error === 'object' && 'status' in error &&
                typeof error.status === 'number' && Number.isInteger(error.status)
                ? error.status
                : 503,
            )
          }
          if (!sharedVoiceover || typeof sharedVoiceover.narrationPath !== 'string' || !isAbsolute(sharedVoiceover.narrationPath)) {
            throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
          }
        }
        if (packaging.bgm === 'local_authorized') {
          bgmLease = await acquireAuthorizedBgm(packaging.bgmAuthorizationId, input.projectId)
          requestBgmPath = null
          if (!bgmLease && !requestBgmPath) {
            throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
          }
        }
        requestBgmVolume = packaging.bgmVolume
        script = scriptForPreview(brief, packaging)
        // Same safe-area boundary for automatic/template preview requests.
        captionsEnabled = false
        clips = applyTemplateGuidanceToSelections(input.clips, templateGuidance)
        // The script decides the runtime: measure each sentence's narration and
        // give its shot exactly that long. Legacy renderer-owned voices without
        // per-sentence assets retain their authored material length.
        const sentenceDurations = await narrationSentenceDurations(sharedVoiceover, clips.length)
        if (sentenceDurations) {
          clips = alignClipsToNarration(clips, sentenceDurations)
        }
        durationSeconds = clips.reduce(
          (total, clip) => total + (Number(clip.end) - Number(clip.start)),
          0,
        )
        if (durationSeconds > 180) {
          // The upstream render contract stops at 180s. Say so plainly instead of
          // letting request validation reject this as a malformed input.
          throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.scriptTooLong, 409)
        }
        const dimensions = /** @type {Record<string, {width: number, height: number}>} */ ({
          portrait: { width: 720, height: 1280 },
          landscape: { width: 1280, height: 720 },
          square: { width: 1080, height: 1080 },
        })
        return await generatePreview({
          projectId: input.projectId,
          jobId: input.jobId,
          outputDurationSeconds: durationSeconds,
          outputSize: dimensions[brief.orientation],
          script,
          voiceover: {
            enabled: resolvedVoice.enabled,
            voice: sharedVoiceover ? null : resolvedVoice.voice,
            rate: sharedVoiceover ? 0 : resolvedVoice.enabled ? resolvedVoice.rate : 0,
            audioPath: sharedVoiceover?.narrationPath ?? null,
            assetId: sharedVoiceover?.assetId ?? null,
          },
          captions: {
            enabled: captionsEnabled,
          },
          bgmPath: requestBgmPath,
          bgmLease,
          bgmVolume: requestBgmVolume,
          // The published MP4 stays text-free. Ordinary captions are rendered
          // by the Workbench player's toggle; titles and Jianying-only rich
          // packaging remain editable in the canonical timeline and draft.
          clips,
          templateGuidance,
          signal: input.signal,
          onProgress: input.onProgress,
          onStarted: input.onStarted,
        })
      }

      const dimensions = /** @type {Record<string, {width: number, height: number}>} */ ({
        portrait: { width: 720, height: 1280 },
        landscape: { width: 1280, height: 720 },
        square: { width: 1080, height: 1080 },
      })
      const orientation = typeof input.orientation === 'string' &&
        ['portrait', 'landscape', 'square'].includes(input.orientation)
        ? input.orientation
        : brief.orientation
      const clipDuration = clips.reduce(
        (total, clip) => total + (Number(clip.end) - Number(clip.start)),
        0,
      )
      // An edited timeline is an explicit user decision, so shots are left as
      // authored. Still refuse to ship a cut-off sentence: if the narration
      // outruns the picture, say so instead of trimming the voice track.
      const narrationSeconds = sharedVoiceover
        ? await probeAudioDurationSeconds(sharedVoiceover.narrationPath)
        : null
      const pictureSeconds = Math.min(
        Math.max(durationSeconds, 0.1),
        Math.max(clipDuration, 0.1),
      )
      if (brief.voiceover === 'required' && sharedVoiceover && narrationSeconds === null) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.unavailable, 503)
      }
      if (narrationSeconds !== null && narrationSeconds > pictureSeconds + 0.05) {
        throw new ShortVideoFactoryError(
          shortVideoFactoryErrorCodes.materialDurationInsufficient,
          409,
        )
      }
      if (pictureSeconds > 180) {
        throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.scriptTooLong, 409)
      }
      const outputDurationSeconds = pictureSeconds
      return await generatePreview({
        projectId: input.projectId,
        jobId: input.jobId,
        outputDurationSeconds,
        outputSize: dimensions[orientation],
        script,
        voiceover: {
          enabled: Boolean(sharedVoiceover) || resolvedVoice.enabled,
          voice: sharedVoiceover ? null : resolvedVoice.voice,
          rate: sharedVoiceover ? 0 : resolvedVoice.enabled ? resolvedVoice.rate : 0,
          audioPath: sharedVoiceover?.narrationPath ?? null,
          assetId: sharedVoiceover?.assetId ?? null,
        },
        captions: {
          enabled: captionsEnabled,
        },
        bgmPath: requestBgmPath,
        bgmLease,
        bgmVolume: requestBgmVolume,
        sfxInputs: requestSfxInputs,
        // Keep the final MP4 clean so the Workbench caption toggle remains
        // authoritative and private Jianying packaging is never flattened into
        // a plain-text approximation.
        clips,
        templateGuidance: null,
        signal: input.signal,
        onProgress: input.onProgress,
        onStarted: input.onStarted,
      })
    } finally {
      await bgmLease?.release()
      for (const resource of resolvedSfxResources.reverse()) {
        await resource.release?.().catch(() => {})
      }
      if (cleanupRoot) {
        await rm(cleanupRoot, { recursive: true, force: true }).catch(() => {})
      }
    }
  }

  /** @param {{projectId: string, resourceId: string}} input */
  const getResource = async ({ projectId, resourceId }) => {
    if (!safeId(projectId) || !safeId(resourceId)) return null
    const resourcePath = resolve(resourceRoot, projectId, `${resourceId}.mp4`)
    if (!inside(resolve(resourceRoot, projectId), resourcePath)) return null
    try {
      const metadata = await lstat(resourcePath)
      if (!metadata.isFile() || metadata.isSymbolicLink()) return null
      if (metadata.size < 12) return null
      const handle = await open(resourcePath, 'r')
      const probe = Buffer.alloc(Math.min(64, metadata.size))
      try {
        await handle.read(probe, 0, probe.length, 0)
      } finally {
        await handle.close()
      }
      if (!probe.includes(Buffer.from('ftyp'))) return null
      /** @param {{start: number, end: number}} range */
      const createStream = ({ start, end }) =>
        Readable.toWeb(createReadStream(resourcePath, { start, end }))
      return {
        size: metadata.size,
        contentType: 'video/mp4',
        etag: `"${await sha256File(resourcePath)}"`,
        createStream,
      }
    } catch {
      return null
    }
  }

  /** @param {{projectId: string, previewResourceId: string}} input */
  const publishFinal = async ({ projectId, previewResourceId }) => {
    if (
      !safeId(projectId) ||
      !safeId(previewResourceId) ||
      !previewResourceId.startsWith('preview-')
    ) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.inputInvalid, 400)
    }
    const preview = await getResource({ projectId, resourceId: previewResourceId })
    if (!preview) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.outputInvalid, 409)
    }
    const previewDigest = /^"([a-f0-9]{64})"$/u.exec(preview.etag)?.[1]
    if (!previewDigest) {
      throw new ShortVideoFactoryError(shortVideoFactoryErrorCodes.outputInvalid, 409)
    }
    const resourceId = `final-${previewDigest.slice(0, 32)}`
    const projectRoot = resolve(resourceRoot, projectId)
    const previewPath = resolve(projectRoot, `${previewResourceId}.mp4`)
    const outputPath = resolve(projectRoot, `${resourceId}.mp4`)
    const stagedPath = resolve(projectRoot, `${resourceId}.${randomUUID()}.tmp`)
    const lock = await acquireResourceLock(
      resolve(projectRoot, `${resourceId}.lock`),
      undefined,
    )
    try {
      const existing = await getResource({ projectId, resourceId })
      if (!existing) {
        await copyFile(previewPath, stagedPath)
        await lock.assertOwned()
        await rename(stagedPath, outputPath)
      }
      return { resourceId, contentType: 'video/mp4' }
    } finally {
      await rm(stagedPath, { force: true })
      await lock.release()
    }
  }

  /** @param {{projectId: string, resourceId: string}} input */
  const deleteResource = async ({ projectId, resourceId }) => {
    if (!safeId(projectId) || !safeId(resourceId)) return false
    const projectRoot = resolve(resourceRoot, projectId)
    const resourcePath = resolve(projectRoot, `${resourceId}.mp4`)
    if (!inside(projectRoot, resourcePath)) return false
    await rm(resourcePath, { force: true })
    return true
  }

  return {
    getStatus: () => structuredClone(status),
    // Admission performs a complete integrity check, and every render repeats it before
    // touching user media. Readiness must stay lightweight or large pinned runtime trees
    // can exceed the aggregate health timeout and report a false outage.
    probeAvailability: async () => structuredClone(status),
    generatePreview,
    renderPreview,
    getResource,
    publishFinal,
    deleteResource,
  }
}
