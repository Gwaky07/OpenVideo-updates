[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$QueryManifestPath,
    [Parameter(Mandatory)][string]$SearchResultsPath,
    [Parameter(Mandatory)][string]$AnalysisResultsPath,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [double]$MinimumAvailabilityRatio = 0.8
)

$ErrorActionPreference = 'Stop'
$pathComparison = [StringComparison]::OrdinalIgnoreCase
$utf8 = New-Object Text.UTF8Encoding($false)
$videoExtensions = @('.mp4', '.mov', '.mkv', '.avi', '.m4v', '.webm', '.mts', '.m2ts')

function Get-FullPath {
    param([string]$Path, [string]$Name, [bool]$MustExist)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "$Name is required." }
    if ([IO.Path]::GetInvalidPathChars() | Where-Object { $Path.Contains($_) }) { throw "$Name contains invalid path characters." }
    if (-not [IO.Path]::IsPathRooted($Path) -or $Path -match '^[A-Za-z]:[^\\/]') { throw "$Name must be an absolute path." }
    $full = [IO.Path]::GetFullPath($Path)
    if ($MustExist -and -not (Test-Path -LiteralPath $full)) { throw "$Name does not exist: $full" }
    $root = [IO.Path]::GetPathRoot($full)
    if ($full.Equals($root, $pathComparison)) { return $root }
    return $full.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
}

function Test-Within {
    param([string]$Root, [string]$Candidate)
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($Root, $pathComparison) -or $Candidate.StartsWith($prefix, $pathComparison)
}

function Assert-NoReparseBoundary {
    param([string]$Root, [string]$Candidate)
    $cursor = $Candidate
    while ($true) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "Path crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        if ($cursor.Equals($Root, $pathComparison)) { break }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor -or -not (Test-Within -Root $Root -Candidate $parent)) {
            throw 'Private search evidence must be inside RuntimeDataRoot.'
        }
        $cursor = $parent
    }
}

function Assert-NoReparseAncestors {
    param([string]$Path, [string]$Name)
    $cursor = $Path
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw "$Name crosses a symbolic-link or reparse-point boundary: $cursor"
        }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-NotReparsePath {
    param([string]$Path, [string]$Name)
    $item = Get-Item -LiteralPath $Path -Force
    $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw "$Name must not be a symbolic link or reparse point: $Path"
    }
}

function Assert-PrivateFile {
    param([string]$Path, [string]$Name, [string]$RuntimeRoot)
    $full = Get-FullPath -Path $Path -Name $Name -MustExist $true
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "$Name must be an existing file." }
    if (-not (Test-Within -Root $RuntimeRoot -Candidate $full)) { throw "$Name must be inside RuntimeDataRoot." }
    Assert-NoReparseBoundary -Root $RuntimeRoot -Candidate $full
    return $full
}

function ConvertTo-FiniteScore {
    param([object]$Value)
    if ($Value -is [string]) { throw 'Search candidate score must be numeric and finite.' }
    $isNumeric = $Value -is [byte] -or $Value -is [sbyte] -or $Value -is [int16] -or $Value -is [uint16] -or
        $Value -is [int32] -or $Value -is [uint32] -or $Value -is [int64] -or $Value -is [uint64] -or
        $Value -is [single] -or $Value -is [double] -or $Value -is [decimal]
    if (-not $isNumeric) { throw 'Search candidate score must be numeric and finite.' }
    try {
        $score = [double]$Value
    } catch {
        throw 'Search candidate score must be finite.'
    }
    if ($score.GetType() -ne [double]) { throw 'Search candidate score cast failed.' }
    if ([double]::IsNaN($score) -or [double]::IsInfinity($score) -or $score -lt 0 -or $score -gt 1) {
        throw 'Search candidate score must be finite and between 0 and 1.'
    }
    return $score
}

$repositoryPath = Get-FullPath -Path (Split-Path -Parent $PSScriptRoot) -Name 'RepositoryRoot' -MustExist $true
$runtimePath = Get-FullPath -Path $RuntimeDataRoot -Name 'RuntimeDataRoot' -MustExist $true
Assert-NotReparsePath -Path $repositoryPath -Name 'RepositoryRoot'
if ((Test-Within -Root $repositoryPath -Candidate $runtimePath) -or (Test-Within -Root $runtimePath -Candidate $repositoryPath)) {
    throw 'RuntimeDataRoot and the repository must be separate and must not contain one another.'
}
Assert-NoReparseAncestors -Path $runtimePath -Name 'RuntimeDataRoot'

$queryManifestPathFull = Assert-PrivateFile -Path $QueryManifestPath -Name 'QueryManifestPath' -RuntimeRoot $runtimePath
$searchResultsPathFull = Assert-PrivateFile -Path $SearchResultsPath -Name 'SearchResultsPath' -RuntimeRoot $runtimePath
$analysisResultsPathFull = Assert-PrivateFile -Path $AnalysisResultsPath -Name 'AnalysisResultsPath' -RuntimeRoot $runtimePath

$querySnapshotPath = Join-Path $runtimePath 'evidence/em-003/private/search-query-snapshot.json'
$queryVerificationPath = Join-Path $runtimePath 'evidence/em-003/search-query-verification.json'
foreach ($requiredEvidence in @($querySnapshotPath, $queryVerificationPath)) {
    if (-not (Test-Path -LiteralPath $requiredEvidence -PathType Leaf)) { throw 'Search query preflight evidence is required before result validation.' }
    Assert-NoReparseBoundary -Root $runtimePath -Candidate $requiredEvidence
}

$sourceVerificationPath = Join-Path $runtimePath 'evidence/em-002/source-verification.json'
$analysisVerificationPath = Join-Path $runtimePath 'evidence/em-002/analysis-verification.json'
foreach ($requiredEvidence in @($sourceVerificationPath, $analysisVerificationPath)) {
    if (-not (Test-Path -LiteralPath $requiredEvidence -PathType Leaf)) { throw 'EM-002 verified analysis evidence is required before scene search validation.' }
    Assert-NoReparseBoundary -Root $runtimePath -Candidate $requiredEvidence
}
$sourceVerification = Get-Content -LiteralPath $sourceVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
if ($sourceVerification.unchanged -ne $true -or [int]$sourceVerification.sample_count -ne 5) {
    throw 'EM-002 source verification must confirm five unchanged files.'
}
$analysisVerification = Get-Content -LiteralPath $analysisVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
if ([int]$analysisVerification.sample_count -ne 5 -or [int]$analysisVerification.indexed_count -ne 5) {
    throw 'EM-002 analysis verification must confirm five indexed samples.'
}
if ([string]$analysisVerification.scene_representation -ne 'source+start+end' -or [int]$analysisVerification.permanent_scene_clips -ne 0) {
    throw 'EM-002 analysis verification must confirm logical scenes and zero permanent clips.'
}

$queryManifest = Get-Content -LiteralPath $queryManifestPathFull -Raw -Encoding utf8 | ConvertFrom-Json
$querySnapshot = Get-Content -LiteralPath $querySnapshotPath -Raw -Encoding utf8 | ConvertFrom-Json
if ($queryManifest.schema_version -ne 1 -or $queryManifest.authorization -ne 'read_only_search') {
    throw 'Search manifest authorization contract is invalid.'
}
$sentences = @($queryManifest.sentences | ForEach-Object { ([string]$_).Trim() })
if ($sentences.Count -ne 8) { throw 'Search manifest must contain exactly eight sentences.' }
$snapshotSentences = @($querySnapshot.sentences | ForEach-Object { ([string]$_).Trim() })
if (($sentences | ConvertTo-Json -Compress) -ne ($snapshotSentences | ConvertTo-Json -Compress)) {
    throw 'Search query snapshot does not match the manifest.'
}

$analysisResults = Get-Content -LiteralPath $analysisResultsPathFull -Raw -Encoding utf8 | ConvertFrom-Json
if ($analysisResults.schema_version -ne 1) { throw 'Analysis results schema_version must be 1.' }
$analysisSamples = @($analysisResults.samples)
if ($analysisSamples.Count -ne 5) { throw 'Analysis results must contain exactly five samples.' }

$durationBySource = @{}
$sceneBoundsBySource = @{}
foreach ($sample in $analysisSamples) {
    $source = Get-FullPath -Path ([string]$sample.source) -Name 'Analysis source' -MustExist $false
    if ($durationBySource.ContainsKey($source)) { throw 'Analysis results contain duplicate sources.' }
    if ([string]$sample.status -ne 'indexed') { throw 'Analysis source must be indexed before search validation.' }
    $duration = [double]$sample.duration
    if ($duration -le 0) { throw 'Analysis source duration must be positive.' }
    $durationBySource[$source] = $duration
    $sceneBoundsBySource[$source] = @()
    foreach ($scene in @($sample.scenes)) {
        $sceneProperties = @($scene.PSObject.Properties.Name | Sort-Object)
        if (($sceneProperties -join ',') -ne 'end,source,start') { throw 'Indexed scenes may only contain source, start and end.' }
        $sceneSource = Get-FullPath -Path ([string]$scene.source) -Name 'Indexed scene source' -MustExist $false
        if ($sceneSource -ne $source) { throw 'Indexed scene source must match its analysis source.' }
        $start = [double]$scene.start
        $end = [double]$scene.end
        if ($start -lt 0 -or $end -le $start -or $end -gt $duration) { throw 'Indexed scene timecode exceeds the source duration.' }
        $sceneBoundsBySource[$source] += [pscustomobject]@{ start = $start; end = $end }
    }
}

$searchResults = Get-Content -LiteralPath $searchResultsPathFull -Raw -Encoding utf8 | ConvertFrom-Json
if ($searchResults.schema_version -ne 1) { throw 'Search results schema_version must be 1.' }
$queryResults = @($searchResults.queries)
if ($queryResults.Count -ne 8) { throw 'Search results must contain exactly eight query results.' }

$usableCount = 0
for ($index = 0; $index -lt 8; $index++) {
    $queryResult = $queryResults[$index]
    $queryProperties = @($queryResult.PSObject.Properties.Name | Sort-Object)
    if (($queryProperties -join ',') -ne 'sentence,status,top_candidates,usable_in_top3') {
        throw 'Search result entries may only contain sentence, status, usable_in_top3 and top_candidates.'
    }
    if (([string]$queryResult.sentence).Trim() -ne $sentences[$index]) { throw 'Search result sentence order must match the query manifest.' }
    if ([string]$queryResult.status -ne 'searched') { throw 'Every query result must have searched status.' }
    $topCandidates = @($queryResult.top_candidates)
    if ($topCandidates.Count -gt 3) { throw 'Search results may include at most three top candidates per sentence.' }
    if ($queryResult.usable_in_top3 -isnot [bool]) { throw 'usable_in_top3 must be a boolean.' }
    $usable = [bool]$queryResult.usable_in_top3
    if ($usable -and $topCandidates.Count -eq 0) { throw 'Usable top-three search result must include at least one candidate.' }
    if ($usable) { $usableCount++ }

    foreach ($candidate in $topCandidates) {
        $candidateProperties = @($candidate.PSObject.Properties.Name | Sort-Object)
        if (($candidateProperties -join ',') -ne 'scene,score') { throw 'Top candidates may only contain scene and score.' }
        $score = ConvertTo-FiniteScore -Value $candidate.score
        $sceneProperties = @($candidate.scene.PSObject.Properties.Name | Sort-Object)
        if (($sceneProperties -join ',') -ne 'end,source,start') { throw 'Search candidate scenes may only contain source, start and end.' }
        $candidateSource = Get-FullPath -Path ([string]$candidate.scene.source) -Name 'Search candidate source' -MustExist $false
        if (-not $durationBySource.ContainsKey($candidateSource)) { throw 'Search candidate source must be one of the five EM-002 verified samples.' }
        $start = [double]$candidate.scene.start
        $end = [double]$candidate.scene.end
        if ($start -lt 0 -or $end -le $start -or $end -gt $durationBySource[$candidateSource]) {
            throw 'Search candidate timecode exceeds the source duration.'
        }
        $contained = $false
        foreach ($indexedScene in $sceneBoundsBySource[$candidateSource]) {
            if ($start -ge $indexedScene.start -and $end -le $indexedScene.end) {
                $contained = $true
                break
            }
        }
        if (-not $contained) { throw 'Search candidate timecode must be contained in an indexed scene.' }
    }
}

$availabilityRatio = $usableCount / 8.0
if ($availabilityRatio -lt $MinimumAvailabilityRatio) {
    throw 'Top-three usable scene availability is below the required threshold.'
}

$permanentClips = @(
    Get-ChildItem -LiteralPath $runtimePath -Recurse -File -Filter 'Scene-*' -ErrorAction SilentlyContinue |
        Where-Object { [IO.Path]::GetExtension($_.Name).ToLowerInvariant() -in $videoExtensions }
)
if ($permanentClips.Count -gt 0) { throw 'Permanent scene clip files are forbidden.' }
$tmpPath = Join-Path $runtimePath 'tmp'
if (Test-Path -LiteralPath $tmpPath -PathType Container) {
    $temporaryFiles = @(Get-ChildItem -LiteralPath $tmpPath -Recurse -File -Force -ErrorAction SilentlyContinue)
    if ($temporaryFiles.Count -gt 0) { throw 'Runtime temporary files must be cleaned before verification.' }
}

$evidenceDir = Join-Path $runtimePath 'evidence/em-003'
New-Item -ItemType Directory -Path $evidenceDir -Force | Out-Null
$evidence = [ordered]@{
    schema_version = 1
    query_count = 8
    top_k = 3
    usable_in_top3_count = $usableCount
    availability_ratio = [math]::Round($availabilityRatio, 4)
    minimum_availability_ratio = $MinimumAvailabilityRatio
    source_count = 5
    scene_representation = 'source+start+end'
    permanent_scene_clips = 0
}
$evidencePath = Join-Path $evidenceDir 'search-verification.json'
[IO.File]::WriteAllText($evidencePath, ($evidence | ConvertTo-Json -Depth 6), $utf8)
[pscustomobject]@{ query_count = 8; usable_in_top3_count = $usableCount; evidence_path = $evidencePath }
