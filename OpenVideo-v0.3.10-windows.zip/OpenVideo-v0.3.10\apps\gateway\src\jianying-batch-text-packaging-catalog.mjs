import { lstat, realpath } from 'node:fs/promises'
import { isAbsolute, relative, resolve } from 'node:path'

import { fingerprintCanonical } from './editor-agent-contracts.mjs'
import { readFileNoReparse } from './jianying-native-safe-file.mjs'

const schemaVersion = 1
const catalogKind = 'jy130_batch_text_packaging_catalog'
const pinnedUpstreamCommit = 'c3318066d964744e2bfc66f75c71745fe8cea52a'
const tokenPattern = /^ovjpack_v1_[A-Za-z0-9_-]{12,160}$/u
const resourcePattern = /^[A-Za-z0-9_-]{4,80}$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const draftNamePattern = /^OpenVideo-JY130-batch-text-[0-9]{10,20}$/u
const safeLabelPattern = /^[\p{L}\p{N}][\p{L}\p{N} ._()（）·-]{0,79}$/u
const kinds = new Set(['sticker', 'flower', 'bubble'])
const capabilitiesByKind = Object.freeze({
  sticker: 'sticker.named',
  flower: 'text.flower.private',
  bubble: 'text.bubble.private',
})

/** @typedef {{packaging_token: string, kind: 'sticker'|'flower'|'bubble', text: string, target_start_us: number, target_duration_us: number}} JianyingBatchEvidenceBinding */

export class JianyingBatchTextPackagingCatalogError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingBatchTextPackagingCatalogError'
    this.code = code
  }
}

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
const isSafeTags = (value) =>
  Array.isArray(value) &&
  value.length > 0 &&
  value.length <= 12 &&
  new Set(value).size === value.length &&
  value.every((tag) => typeof tag === 'string' && /^[\p{L}\p{N}][\p{L}\p{N}._-]{0,31}$/u.test(tag))

/** @param {unknown} value @param {string[]} expected */
const exactKeys = (value, expected) =>
  isRecord(value) &&
  Object.keys(/** @type {Record<string, unknown>} */ (value)).length === expected.length &&
  Object.keys(/** @type {Record<string, unknown>} */ (value)).every((key) => expected.includes(key))

const entryKeys = [
  'kind',
  'capability_id',
  'packaging_token',
  'label',
  'semantic_tags',
  'resource_id',
  'effect_id',
]

/**
 * Parse an owner-private catalog. The returned object is intentionally
 * private-boundary data; callers must use public projections for API output.
 * @param {unknown} value
 */
export const parseJianyingBatchTextPackagingCatalog = (value) => {
  /** @type {any} */
  const candidate = value
  if (!exactKeys(candidate, ['schema_version', 'kind', 'catalog_version', 'upstream_commit', 'profile_id', 'evidence_profile', 'entries', 'catalog_fingerprint']) ||
    candidate.schema_version !== schemaVersion ||
    candidate.kind !== catalogKind ||
    typeof candidate.catalog_version !== 'string' ||
    !/^\d+\.\d+\.\d+$/u.test(candidate.catalog_version) ||
    candidate.upstream_commit !== pinnedUpstreamCommit ||
    typeof candidate.profile_id !== 'string' ||
    !/^jianying-[0-9a-z-]{3,80}$/u.test(candidate.profile_id) ||
    !isRecord(candidate.evidence_profile) ||
    !exactKeys(candidate.evidence_profile, ['manual_verified', 'scheme', 'app_version', 'draft_fingerprint']) ||
    typeof candidate.evidence_profile.manual_verified !== 'boolean' ||
    candidate.evidence_profile.scheme !== 'encrypt_v2' ||
    typeof candidate.evidence_profile.app_version !== 'string' ||
    candidate.evidence_profile.app_version.length < 3 ||
    typeof candidate.evidence_profile.draft_fingerprint !== 'string' ||
    !fingerprintPattern.test(candidate.evidence_profile.draft_fingerprint) ||
    !Array.isArray(candidate.entries) ||
    candidate.entries.length < 2 ||
    typeof candidate.catalog_fingerprint !== 'string' ||
    !fingerprintPattern.test(candidate.catalog_fingerprint)) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_INVALID')
  }

  const entries = candidate.entries.map((/** @type {any} */ entry) => {
    if (!exactKeys(entry, entryKeys) ||
      !kinds.has(entry.kind) ||
      entry.capability_id !== /** @type {any} */ (capabilitiesByKind)[entry.kind] ||
      typeof entry.packaging_token !== 'string' ||
      !tokenPattern.test(entry.packaging_token) ||
      typeof entry.label !== 'string' ||
      !safeLabelPattern.test(entry.label) ||
      !isSafeTags(entry.semantic_tags) ||
      typeof entry.resource_id !== 'string' ||
      !resourcePattern.test(entry.resource_id) ||
      (entry.kind !== 'sticker' && (typeof entry.effect_id !== 'string' || !resourcePattern.test(entry.effect_id))) ||
      (entry.kind === 'sticker' && entry.effect_id !== null)) {
      throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_ENTRY_INVALID')
    }
    return Object.freeze({
      kind: entry.kind,
      capability_id: entry.capability_id,
      packaging_token: entry.packaging_token,
      label: entry.label,
      semantic_tags: Object.freeze([...entry.semantic_tags]),
      resource_id: entry.resource_id,
      effect_id: entry.effect_id,
    })
  })

  if (new Set(entries.map((/** @type {any} */ entry) => entry.packaging_token)).size !== entries.length) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_DUPLICATE_TOKEN')
  }

  const body = {
    schema_version: candidate.schema_version,
    kind: candidate.kind,
    catalog_version: candidate.catalog_version,
    upstream_commit: candidate.upstream_commit,
    profile_id: candidate.profile_id,
    evidence_profile: candidate.evidence_profile,
    entries: entries.map((/** @type {any} */ entry) => ({ ...entry, semantic_tags: [...entry.semantic_tags] })),
  }
  if (fingerprintCanonical(body) !== candidate.catalog_fingerprint) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_FINGERPRINT_INVALID')
  }
  return Object.freeze({
    ...body,
    evidence_profile: Object.freeze({ ...body.evidence_profile }),
    entries: Object.freeze(entries),
    catalog_fingerprint: candidate.catalog_fingerprint,
  })
}

const evidenceKeys = [
  'schema_version',
  'manual_evidence_verified',
  'manual_attestation',
  'profile_id',
  'app_version',
  'catalog_fingerprint',
  'scheme',
  'opened',
  'edited',
  'saved',
  'reopened',
  'draft_id',
  'pre_open_fingerprint',
  'post_save_fingerprint',
  'selected_bindings',
  'admitted_tokens',
  'temporary_media_cleaned',
]

/**
 * Parse same-draft manual evidence without exposing private resource IDs.
 * The evidence is intentionally separate from the intake catalog: a catalog
 * can describe user-owned resources, but only this exact draft proof can
 * admit them to the production writer.
 * @param {unknown} value
 * @param {string} catalogFingerprint
 * @param {{profileId: string, version: string}} desktop
 */
export const parseJianyingBatchTextPackagingEvidence = (value, catalogFingerprint, desktop) => {
  /** @type {any} */
  const candidate = value
  if (
    !exactKeys(candidate, evidenceKeys) ||
    candidate.schema_version !== schemaVersion ||
    candidate.manual_evidence_verified !== true ||
    candidate.manual_attestation !== 'opened-edited-saved-reopened' ||
    candidate.profile_id !== desktop?.profileId ||
    candidate.app_version !== desktop?.version ||
    candidate.catalog_fingerprint !== catalogFingerprint ||
    candidate.scheme !== 'encrypt_v2' ||
    candidate.opened !== true ||
    candidate.edited !== true ||
    candidate.saved !== true ||
    candidate.reopened !== true ||
    candidate.temporary_media_cleaned !== true ||
    typeof candidate.draft_id !== 'string' ||
    !draftNamePattern.test(candidate.draft_id) ||
    typeof candidate.pre_open_fingerprint !== 'string' ||
    !fingerprintPattern.test(candidate.pre_open_fingerprint) ||
    typeof candidate.post_save_fingerprint !== 'string' ||
    !fingerprintPattern.test(candidate.post_save_fingerprint) ||
    candidate.pre_open_fingerprint === candidate.post_save_fingerprint ||
    !Array.isArray(candidate.selected_bindings) ||
    candidate.selected_bindings.length < 2
  ) return null
  /** @type {JianyingBatchEvidenceBinding[]} */
  const selectedBindings = candidate.selected_bindings.map((/** @type {Record<string, unknown>} */ binding) => {
    if (
      !exactKeys(binding, ['packaging_token', 'kind', 'text', 'target_start_us', 'target_duration_us']) ||
      !tokenPattern.test(/** @type {string} */ (binding.packaging_token)) ||
      !kinds.has(/** @type {string} */ (binding.kind)) ||
      typeof binding.text !== 'string' ||
      binding.text.length < 1 ||
      binding.text.length > 500 ||
      !Number.isSafeInteger(binding.target_start_us) ||
      /** @type {number} */ (binding.target_start_us) < 0 ||
      !Number.isSafeInteger(binding.target_duration_us) ||
      /** @type {number} */ (binding.target_duration_us) <= 0
    ) throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_EVIDENCE_INVALID')
    return /** @type {JianyingBatchEvidenceBinding} */ (Object.freeze({
      packaging_token: /** @type {string} */ (binding.packaging_token),
      kind: /** @type {'sticker'|'flower'|'bubble'} */ (binding.kind),
      text: /** @type {string} */ (binding.text),
      target_start_us: /** @type {number} */ (binding.target_start_us),
      target_duration_us: /** @type {number} */ (binding.target_duration_us),
    }))
  })
  if (new Set(selectedBindings.map((binding) => binding.packaging_token)).size !== selectedBindings.length) return null
  if (!Array.isArray(candidate.admitted_tokens) || candidate.admitted_tokens.length !== selectedBindings.length) return null
  /** @type {(string|null)[]} */
  const admittedTokens = candidate.admitted_tokens.map((/** @type {unknown} */ token) => {
    if (typeof token !== 'string' || !tokenPattern.test(token)) return null
    return token
  })
  if (admittedTokens.some((/** @type {string|null} */ token) => token === null) || new Set(admittedTokens).size !== admittedTokens.length) return null
  const selectedTokens = new Set(selectedBindings.map((binding) => binding.packaging_token))
  if (admittedTokens.some((/** @type {string|null} */ token) => !selectedTokens.has(/** @type {string} */ (token)))) return null
  return Object.freeze({
    schema_version: schemaVersion,
    manual_evidence_verified: true,
    manual_attestation: candidate.manual_attestation,
    profile_id: candidate.profile_id,
    app_version: candidate.app_version,
    catalog_fingerprint: candidate.catalog_fingerprint,
    scheme: candidate.scheme,
    opened: true,
    edited: true,
    saved: true,
    reopened: true,
    draft_id: candidate.draft_id,
    pre_open_fingerprint: candidate.pre_open_fingerprint,
    post_save_fingerprint: candidate.post_save_fingerprint,
    selected_bindings: Object.freeze(selectedBindings),
    admitted_tokens: Object.freeze(/** @type {string[]} */ (admittedTokens)),
    temporary_media_cleaned: true,
  })
}

/**
 * Restrict a user-owned catalog to exactly the resources proved by the
 * same-draft evidence. Entries outside this set remain private intake data
 * and are never writer eligible.
 * @param {ReturnType<typeof parseJianyingBatchTextPackagingCatalog>} catalog
 * @param {ReturnType<typeof parseJianyingBatchTextPackagingEvidence>} evidence
 */
export const admitJianyingBatchTextPackagingCatalog = (catalog, evidence) => {
  if (!catalog || !evidence || evidence.catalog_fingerprint !== catalog.catalog_fingerprint) return null
  const admitted = new Set(evidence.admitted_tokens)
  const entries = catalog.entries.filter((/** @type {Record<string, unknown>} */ entry) => admitted.has(/** @type {string} */ (entry.packaging_token)))
  if (entries.length !== admitted.size || entries.length < 2) return null
  for (const binding of evidence.selected_bindings) {
    const entry = entries.find((/** @type {Record<string, unknown>} */ candidate) => candidate.packaging_token === binding.packaging_token)
    if (!entry || entry.kind !== binding.kind) return null
  }
  return createJianyingBatchTextPackagingCatalog(entries, {
    catalogVersion: catalog.catalog_version,
    upstreamCommit: catalog.upstream_commit,
    profileId: catalog.profile_id,
    evidenceProfile: {
      manual_verified: true,
      scheme: evidence.scheme,
      app_version: evidence.app_version,
      draft_fingerprint: evidence.post_save_fingerprint,
    },
  })
}

/**
 * Resolve one admitted private token for the server-to-writer boundary.
 * Public callers must continue using safe search/recommendation projections.
 * @param {{entries: readonly any[]}|null} catalog
 * @param {string} packagingToken
 */
export const resolveJianyingBatchTextPackagingToken = (catalog, packagingToken) => {
  if (!catalog?.entries || typeof packagingToken !== 'string' || !tokenPattern.test(packagingToken)) return null
  const entry = catalog.entries.find((candidate) => candidate.packaging_token === packagingToken)
  if (!entry) return null
  if (entry.kind === 'sticker') return Object.freeze({ kind: 'sticker', resourceId: entry.resource_id })
  return Object.freeze({
    kind: entry.kind,
    resourceId: entry.resource_id,
    effectId: entry.effect_id,
  })
}

/** @param {Array<Record<string, unknown>>} entries @param {{catalogVersion?: string, upstreamCommit?: string, profileId?: string, evidenceProfile?: Record<string, unknown>}} [options] */
export const createJianyingBatchTextPackagingCatalog = (entries, options = {}) => {
  const body = {
    schema_version: schemaVersion,
    kind: catalogKind,
    catalog_version: options.catalogVersion ?? '1.0.0',
    upstream_commit: options.upstreamCommit ?? pinnedUpstreamCommit,
    profile_id: options.profileId ?? 'jianying-11-1-provisional',
    evidence_profile: options.evidenceProfile ?? {
      manual_verified: true,
      scheme: 'encrypt_v2',
      app_version: '11.1.0.14287',
      draft_fingerprint: 'a'.repeat(64),
    },
    entries: entries.map((entry) => ({ ...entry })),
  }
  return parseJianyingBatchTextPackagingCatalog({
    ...body,
    catalog_fingerprint: fingerprintCanonical(body),
  })
}

/**
 * Build a bounded evidence set without letting catalog ordering starve an
 * available packaging family. The evidence generator projects text and
 * stickers to their respective writer tracks after this selection.
 * @param {{entries: readonly any[]}} catalog
 * @param {number} [limitPerKind]
 */
export const selectJianyingBatchTextEvidenceEntries = (catalog, limitPerKind = 3) => {
  if (!catalog?.entries || !Number.isSafeInteger(limitPerKind) || limitPerKind < 1 || limitPerKind > 10) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_EVIDENCE_SELECTION_INVALID')
  }
  const selected = ['flower', 'bubble', 'sticker'].flatMap((kind) =>
    catalog.entries.filter((entry) => entry.kind === kind).slice(0, limitPerKind),
  )
  if (selected.length < 2) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_EVIDENCE_NEEDS_TWO_RESOURCES')
  }
  return Object.freeze(selected)
}

/**
 * Search uses only safe labels/tags. It returns no resource IDs, paths, or
 * draft material fields.
 * @param {{entries: readonly any[], profile_id: string, evidence_profile: Record<string, unknown>}} catalog
 * @param {{kind: 'sticker'|'flower'|'bubble', intentTags?: string[], limit?: number, noRepeatTokens?: string[], profileId?: string, appVersion?: string, requireEvidence?: boolean}} query
 */
export const searchJianyingBatchTextPackaging = (catalog, query) => {
  if (!catalog?.entries || !kinds.has(query?.kind)) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_SEARCH_INVALID')
  }
  /** @type {any} */
  const rawLimit = query.limit
  const limit = Number.isSafeInteger(rawLimit) ? Math.max(1, Math.min(20, rawLimit)) : 5
  const intentTags = Array.isArray(query.intentTags)
    ? [...new Set(query.intentTags.filter((tag) => typeof tag === 'string'))]
    : []
  const excluded = new Set(Array.isArray(query.noRepeatTokens) ? query.noRepeatTokens : [])
  const profileMatches = !query.profileId || query.profileId === catalog.profile_id
  const versionMatches = !query.appVersion || query.appVersion === catalog.evidence_profile.app_version
  const evidenceMatches = query.requireEvidence === false || catalog.evidence_profile.manual_verified === true
  if (!profileMatches || !versionMatches || !evidenceMatches) return []

  return catalog.entries
    .filter((entry) => entry.kind === query.kind && !excluded.has(entry.packaging_token))
    .map((entry) => {
      const overlap = intentTags.filter((tag) => entry.semantic_tags.includes(tag)).length
      return {
        entry,
        score: overlap,
      }
    })
    .sort((left, right) =>
      right.score - left.score ||
      left.entry.packaging_token.localeCompare(right.entry.packaging_token),
    )
    .slice(0, limit)
    .map(({ entry, score }) => ({
      packagingToken: entry.packaging_token,
      kind: entry.kind,
      capabilityId: entry.capability_id,
      label: entry.label,
      semanticTags: [...entry.semantic_tags],
      score,
    }))
}

/**
 * Choose one candidate while rotating through the ranked result set. A
 * caller may pass the prior selection history but never a raw resource ID.
 * @param {ReturnType<typeof searchJianyingBatchTextPackaging>} candidates
 * @param {{rotation?: number, noRepeatTokens?: string[]}} [options]
 */
export const selectJianyingTextPackagingCandidate = (candidates, options = {}) => {
  if (!Array.isArray(candidates) || candidates.length === 0) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_NO_ELIGIBLE_CANDIDATE')
  }
  const excluded = new Set(options.noRepeatTokens ?? [])
  const eligible = candidates.filter((candidate) => !excluded.has(candidate.packagingToken))
  if (eligible.length === 0) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_NO_ELIGIBLE_CANDIDATE')
  }
  /** @type {any} */
  const rawRotation = options.rotation
  const rotation = Number.isSafeInteger(rawRotation) ? Math.max(0, rawRotation) : 0
  return Object.freeze({ ...eligible[rotation % eligible.length], semanticTags: [...eligible[rotation % eligible.length].semanticTags] })
}

/** @param {ReturnType<typeof searchJianyingBatchTextPackaging>[number]} candidate */
export const toJianyingBatchTextPackagingBinding = (candidate) => {
  if (!candidate || !tokenPattern.test(candidate.packagingToken) || !kinds.has(candidate.kind) ||
    candidate.capabilityId !== /** @type {any} */ (capabilitiesByKind)[candidate.kind]) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_BINDING_INVALID')
  }
  return Object.freeze({
    packagingToken: candidate.packagingToken,
    capabilityId: candidate.capabilityId,
    kind: candidate.kind,
  })
}

/** @param {string} candidate @param {string} root */
const validatePrivateCatalogPath = async (candidate, root) => {
  if (typeof candidate !== 'string' || !isAbsolute(candidate) ||
    typeof root !== 'string' || !isAbsolute(root)) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_PATH_INVALID')
  }
  const rootAbs = resolve(root)
  const candidateAbs = resolve(candidate)
  const relativePath = relative(rootAbs, candidateAbs)
  if (relativePath.startsWith('..') || isAbsolute(relativePath)) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_OUTSIDE_RUNTIME_ROOT')
  }
  try {
    const [rootStat, rootReal, candidateStat, candidateReal] = await Promise.all([
      lstat(rootAbs),
      realpath(rootAbs),
      lstat(candidateAbs),
      realpath(candidateAbs),
    ])
    if (rootStat.isSymbolicLink() || candidateStat.isSymbolicLink()) {
      throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_REPARSE_REJECTED')
    }
    const realRelative = relative(rootReal, candidateReal)
    if (realRelative.startsWith('..') || isAbsolute(realRelative)) {
      throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_REPARSE_REJECTED')
    }
    return candidateReal
  } catch (error) {
    if (error instanceof JianyingBatchTextPackagingCatalogError) throw error
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_PATH_MISSING')
  }
}

/**
 * Intake an owner-private catalog from the runtime root. The returned catalog
 * is writer-private and must never cross a public/API/model boundary.
 * @param {{runtimeRoot: string, catalogPath: string, desktopVersion: string, profileId?: string, readCatalogNoReparse?: (path: string, root: string) => Promise<string>}} input
 */
export const intakeJianyingBatchTextPackagingCatalog = async (input) => {
  if (!isRecord(input) || typeof input.desktopVersion !== 'string') {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_DESKTOP_PROFILE_REQUIRED')
  }
  const path = await validatePrivateCatalogPath(input.catalogPath, input.runtimeRoot)
  let source
  try {
    source = await (input.readCatalogNoReparse ?? readFileNoReparse)(path, input.runtimeRoot)
  } catch {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_READ_FAILED')
  }
  let parsed
  try {
    parsed = parseJianyingBatchTextPackagingCatalog(JSON.parse(source))
  } catch (error) {
    if (error instanceof JianyingBatchTextPackagingCatalogError) throw error
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_CATALOG_READ_FAILED')
  }
  if (parsed.evidence_profile.app_version !== input.desktopVersion ||
    (input.profileId !== undefined && parsed.profile_id !== input.profileId)) {
    throw new JianyingBatchTextPackagingCatalogError('JY130_BATCH_PROFILE_MISMATCH')
  }
  return parsed
}

/**
 * Planner-facing recommendation. The result is intentionally shaped as an
 * existing template-bound packaging slot, so callers can pass it to
 * `templateConstraints` and let the canonical EditPlan adapter create the
 * RichTimeline segment.
 * @param {{entries: readonly any[], profile_id: string, evidence_profile: Record<string, unknown>}} catalog
 * @param {{kind: 'sticker'|'flower'|'bubble', intentTags?: string[], rotation?: number, noRepeatTokens?: string[], profileId?: string, appVersion?: string, requireEvidence?: boolean}} query
 */
export const recommendJianyingBatchTextPackaging = (catalog, query) => {
  const candidates = searchJianyingBatchTextPackaging(catalog, {
    ...query,
    limit: 20,
  })
  const selected = selectJianyingTextPackagingCandidate(candidates, {
    rotation: query.rotation,
    noRepeatTokens: query.noRepeatTokens,
  })
  const binding = toJianyingBatchTextPackagingBinding(selected)
  return Object.freeze({
    ...binding,
    label: selected.label,
    semanticTags: [...selected.semanticTags],
    score: selected.score,
  })
}
