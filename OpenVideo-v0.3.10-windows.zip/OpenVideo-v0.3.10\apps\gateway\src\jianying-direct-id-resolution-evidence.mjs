import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { mkdir, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'

import { loadPackagingResourceEvidenceIntegrityKey } from './jianying-packaging-resource-evidence.mjs'
import { computePackagingEntryBindingFingerprint, createJianyingDesktopBinding } from './jianying-packaging-resource-index.mjs'
import { readFileNoReparse } from './jianying-native-safe-file.mjs'

const integrityRevision = 'packaging-catalog-direct-id-resolution-v1'
const adapterRevision = 'capcut-mate-direct-id-v2'
const writerRevision = 'pyjianying-draft-c3318066-v1'
const fingerprintPattern = /^[a-f0-9]{64}$/u
const signaturePattern = /^[A-Za-z0-9_-]{43}$/u
const safeFailureCodePattern = /^PACKAGING_DIRECT_ID_[A-Z0-9_]{3,80}$/u
const statuses = new Set(['resolved', 'failed'])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {string} */
const canonical = (value) => {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`
  if (!isRecord(value)) return JSON.stringify(value)
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`
}

/** @param {Record<string, any>} receipt */
const unsignedReceipt = (receipt) => {
  const { integrity_signature: _signature, ...unsigned } = receipt
  return unsigned
}

/** @param {Record<string, any>} receipt @param {string} key */
export const signDirectIdResolutionEvidence = (receipt, key) =>
  createHmac('sha256', key).update(canonical(unsignedReceipt(receipt))).digest('base64url')

/** @param {Record<string, any>} receipt @param {string} key */
export const verifyDirectIdResolutionEvidenceSignature = (receipt, key) => {
  if (!fingerprintPattern.test(key) || !signaturePattern.test(receipt?.integrity_signature ?? '')) return false
  const expected = signDirectIdResolutionEvidence(receipt, key)
  return timingSafeEqual(Buffer.from(expected), Buffer.from(receipt.integrity_signature))
}

/**
 * Bind real visual observations to the already independently verified draft.
 * Raw resource identities and screenshot bytes never enter this receipt.
 * @param {{sourceCatalogFingerprint: string, desktop: Record<string, any>, evidence: Record<string, any>, observations: unknown}} input
 */
export const createDirectIdResolutionEvidence = ({ sourceCatalogFingerprint, desktop, evidence, observations }) => {
  if (!fingerprintPattern.test(sourceCatalogFingerprint ?? '') ||
      evidence?.kind !== 'jy132_packaging_resource_evidence_registry' ||
      evidence?.manual_evidence_verified !== true || evidence?.same_draft !== true ||
      !fingerprintPattern.test(evidence?.bundle_fingerprint ?? '') ||
      !fingerprintPattern.test(evidence?.content_fingerprint ?? '') ||
      !Array.isArray(evidence?.admitted_bindings) || evidence.admitted_bindings.length === 0 ||
      !Array.isArray(observations) || observations.length !== evidence.admitted_bindings.length) {
    throw new Error('PACKAGING_DIRECT_ID_EVIDENCE_INPUT_INVALID')
  }
  const desktopBinding = createJianyingDesktopBinding(desktop)
  const expected = new Map(evidence.admitted_bindings.map((binding) => [binding.binding_fingerprint, binding]))
  const seen = new Set()
  const results = observations.map((observation) => {
    const binding = expected.get(observation?.binding_fingerprint)
    if (!binding || seen.has(observation.binding_fingerprint) || observation.family !== binding.family ||
        observation.target_start_us !== binding.target_start_us ||
        observation.target_duration_us !== binding.target_duration_us ||
        !statuses.has(observation.status) ||
        (observation.status === 'resolved' && !fingerprintPattern.test(observation.visual_fingerprint ?? '')) ||
        (observation.status === 'failed' && !safeFailureCodePattern.test(observation.failure_code ?? ''))) {
      throw new Error('PACKAGING_DIRECT_ID_EVIDENCE_OBSERVATION_INVALID')
    }
    seen.add(observation.binding_fingerprint)
    return Object.freeze({
      family: binding.family,
      binding_fingerprint: binding.binding_fingerprint,
      target_start_us: binding.target_start_us,
      target_duration_us: binding.target_duration_us,
      status: observation.status,
      visual_fingerprint: observation.status === 'resolved' ? observation.visual_fingerprint : null,
      failure_code: observation.status === 'failed' ? observation.failure_code : null,
    })
  })
  if (seen.size !== expected.size) throw new Error('PACKAGING_DIRECT_ID_EVIDENCE_OBSERVATION_INVALID')
  return Object.freeze({
    schema_version: 1,
    kind: 'packaging_catalog_direct_id_resolution',
    evidence_id: `ovdirectid_v1_${Date.now()}_${randomBytes(6).toString('hex')}`,
    source_catalog_fingerprint: sourceCatalogFingerprint,
    profile_id: desktop.profileId,
    app_version: desktop.version,
    desktop_binding_fingerprint: desktopBinding.binding_fingerprint,
    draft_id: evidence.draft_id,
    bundle_fingerprint: evidence.bundle_fingerprint,
    content_fingerprint: evidence.content_fingerprint,
    adapter_revision: adapterRevision,
    writer_revision: writerRevision,
    lifecycle: 'opened-edited-saved-closed-reopened',
    results: Object.freeze(results),
    integrity_revision: integrityRevision,
  })
}

/** @param {unknown} value @param {{sourceCatalogFingerprint: string, desktop: Record<string, any>, integrityKey: string}} current */
export const parseDirectIdResolutionEvidence = (value, { sourceCatalogFingerprint, desktop, integrityKey }) => {
  const candidate = /** @type {any} */ (value)
  const keys = [
    'schema_version', 'kind', 'evidence_id', 'source_catalog_fingerprint', 'profile_id', 'app_version',
    'desktop_binding_fingerprint', 'draft_id', 'bundle_fingerprint', 'content_fingerprint',
    'adapter_revision', 'writer_revision', 'lifecycle', 'results', 'integrity_revision', 'integrity_signature',
  ]
  if (!isRecord(candidate) || Object.keys(candidate).sort().join('|') !== keys.sort().join('|') ||
      candidate.schema_version !== 1 || candidate.kind !== 'packaging_catalog_direct_id_resolution' ||
      !/^ovdirectid_v1_[A-Za-z0-9_-]{8,160}$/u.test(candidate.evidence_id ?? '') ||
      candidate.source_catalog_fingerprint !== sourceCatalogFingerprint ||
      candidate.profile_id !== desktop?.profileId || candidate.app_version !== desktop?.version ||
      candidate.desktop_binding_fingerprint !== createJianyingDesktopBinding(desktop).binding_fingerprint ||
      !fingerprintPattern.test(candidate.bundle_fingerprint ?? '') ||
      !fingerprintPattern.test(candidate.content_fingerprint ?? '') ||
      candidate.adapter_revision !== adapterRevision || candidate.writer_revision !== writerRevision ||
      candidate.lifecycle !== 'opened-edited-saved-closed-reopened' ||
      candidate.integrity_revision !== integrityRevision || !Array.isArray(candidate.results) ||
      candidate.results.length === 0 || candidate.results.length > 24 ||
      !verifyDirectIdResolutionEvidenceSignature(candidate, integrityKey)) return null
  const fingerprints = new Set()
  for (const result of candidate.results) {
    if (!isRecord(result) || Object.keys(result).sort().join('|') !== [
      'binding_fingerprint', 'failure_code', 'family', 'status', 'target_duration_us', 'target_start_us', 'visual_fingerprint',
    ].sort().join('|') || !['flower', 'sticker', 'video_effect'].includes(result.family) ||
        !fingerprintPattern.test(result.binding_fingerprint ?? '') || fingerprints.has(result.binding_fingerprint) ||
        !Number.isSafeInteger(result.target_start_us) || result.target_start_us < 0 ||
        !Number.isSafeInteger(result.target_duration_us) || result.target_duration_us <= 0 ||
        !statuses.has(result.status) ||
        (result.status === 'resolved' && (!fingerprintPattern.test(result.visual_fingerprint ?? '') || result.failure_code !== null)) ||
        (result.status === 'failed' && (result.visual_fingerprint !== null || !safeFailureCodePattern.test(result.failure_code ?? '')))) return null
    fingerprints.add(result.binding_fingerprint)
  }
  return Object.freeze({ ...candidate, results: Object.freeze(candidate.results.map((result) => Object.freeze({ ...result }))) })
}

/** @param {{evidenceRoot: string, receipt: Record<string, any>}} input */
export const publishDirectIdResolutionEvidence = async ({ evidenceRoot, receipt }) => {
  if (!isRecord(receipt) || receipt.integrity_revision !== integrityRevision ||
      !signaturePattern.test(receipt.integrity_signature ?? '')) throw new Error('PACKAGING_DIRECT_ID_EVIDENCE_PUBLICATION_INVALID')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const outputPath = path.join(evidenceRoot, 'resolution.json')
  const temporary = `${outputPath}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
  try {
    await writeFile(temporary, `${JSON.stringify(receipt)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await rename(temporary, outputPath)
  } finally {
    await rm(temporary, { force: true })
  }
  return receipt
}

/** @param {{dataRoot: string, capCutCatalogService: Record<string, any>, detectDesktop: Function}} input */
export const loadCurrentDirectIdResolutionEvidence = async ({ dataRoot, capCutCatalogService, detectDesktop }) => {
  try {
    const evidenceRoot = path.join(dataRoot, 'evidence', 'packaging-catalog-001-direct-id')
    const [sourceIdentity, desktop, integrityKey, raw] = await Promise.all([
      capCutCatalogService.currentPrivateIdentity(),
      detectDesktop(),
      loadPackagingResourceEvidenceIntegrityKey({ evidenceRoot }),
      readFileNoReparse(path.join(evidenceRoot, 'resolution.json'), dataRoot),
    ])
    if (desktop?.available !== true) return null
    return parseDirectIdResolutionEvidence(JSON.parse(raw), {
      sourceCatalogFingerprint: sourceIdentity.manifestFingerprint,
      desktop,
      integrityKey,
    })
  } catch { return null }
}

/**
 * Resolved evidence strengthens a normal request. Failed evidence excludes the
 * exact binding. Unknown bindings retain the ordinary static written path.
 * @param {{dataRoot: string, capCutCatalogService: Record<string, any>, detectDesktop: Function, fallbackProbe: Function, loadEvidence?: Function}} input
 */
export const createDirectIdResolutionProbe = ({ dataRoot, capCutCatalogService, detectDesktop, fallbackProbe, loadEvidence = loadCurrentDirectIdResolutionEvidence }) =>
  async (/** @type {Record<string, any>} */ input) => {
    const bindingFingerprint = computePackagingEntryBindingFingerprint({
      family: input?.family,
      privateBinding: input?.privateBinding,
    })
    const evidence = await loadEvidence({ dataRoot, capCutCatalogService, detectDesktop }).catch(() => null)
    const result = evidence?.results?.find((/** @type {Record<string, any>} */ entry) => entry.binding_fingerprint === bindingFingerprint)
    if (result?.status === 'failed') return { passed: false, failureCode: result.failure_code }
    if (result?.status === 'resolved') return {
      passed: true,
      readbackKind: 'jianying_resolved',
      readbackFingerprint: createHash('sha256').update(canonical({
        evidence_id: evidence.evidence_id,
        source_catalog_fingerprint: evidence.source_catalog_fingerprint,
        profile_id: evidence.profile_id,
        app_version: evidence.app_version,
        binding_fingerprint: result.binding_fingerprint,
        visual_fingerprint: result.visual_fingerprint,
        adapter_revision: evidence.adapter_revision,
      })).digest('hex'),
    }
    return fallbackProbe(input)
  }

export const DIRECT_ID_RESOLUTION_EVIDENCE_REVISION = integrityRevision
