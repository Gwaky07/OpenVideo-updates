[CmdletBinding()]
param(
    [string]$RepositoryRoot = ''
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $scriptPath = $MyInvocation.MyCommand.Path
    if ([string]::IsNullOrWhiteSpace($scriptPath)) { throw 'Unable to resolve the repository root.' }
    $RepositoryRoot = (Resolve-Path (Join-Path (Split-Path -Parent $scriptPath) '..')).Path
}
$pnpmCommand = Get-Command pnpm.cmd -ErrorAction SilentlyContinue
$pnpm = if ($pnpmCommand) { $pnpmCommand.Source } else { $null }
$corepack = if ($pnpm) { $null } else { (Get-Command corepack.cmd -ErrorAction Stop).Source }
function Invoke-Pnpm {
    if ($pnpm) { & $pnpm @args } else { & $corepack pnpm @args }
}
$git = (Get-Command git.exe -ErrorAction Stop).Source
$python = (Get-Command python.exe -ErrorAction Stop).Source
$null = Get-Command ffmpeg.exe -ErrorAction Stop

Push-Location $RepositoryRoot
try {
    $commonGitDirectory = (& $git rev-parse --git-common-dir).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Unable to resolve the OpenVideo common Git directory.' }
    $totalProjectRoot = Split-Path -Parent ([IO.Path]::GetFullPath($commonGitDirectory))
    $pythonModuleRoot = Join-Path $totalProjectRoot 'upstream/pyJianYingDraft'
    if (-not (Test-Path -LiteralPath $pythonModuleRoot -PathType Container)) {
        throw 'The governed pyJianYingDraft checkout is unavailable.'
    }
    $upstreamCommit = (& $git -C $pythonModuleRoot rev-parse HEAD).Trim()
    if ($LASTEXITCODE -ne 0 -or $upstreamCommit -ne 'c3318066d964744e2bfc66f75c71745fe8cea52a') {
        throw "Unexpected pyJianYingDraft baseline: $upstreamCommit"
    }
    $upstreamStatus = (& $git -C $pythonModuleRoot status --porcelain --untracked-files=all) -join "`n"
    if ($LASTEXITCODE -ne 0 -or -not [string]::IsNullOrWhiteSpace($upstreamStatus)) {
        throw 'The governed pyJianYingDraft checkout must be clean.'
    }
    Invoke-Pnpm --filter '@openvideo/gateway' exec node --test test/jianying-draft-adapter.test.mjs
    if ($LASTEXITCODE -ne 0) { throw 'JY-002 Jianying adapter tests failed.' }
    $previousPythonRoot = $env:OPENVIDEO_JY002_PYTHON_MODULE_ROOT
    $previousPythonExecutable = $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE
    try {
        $env:OPENVIDEO_JY002_PYTHON_MODULE_ROOT = $pythonModuleRoot
        $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE = $python
        Invoke-Pnpm --filter '@openvideo/gateway' exec node --test test/jianying-draft-writer.integration.mjs
        if ($LASTEXITCODE -ne 0) { throw 'JY-002 pyJianYingDraft integration tests failed.' }
    }
    finally {
        $env:OPENVIDEO_JY002_PYTHON_MODULE_ROOT = $previousPythonRoot
        $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE = $previousPythonExecutable
    }
}
finally {
    Pop-Location
}

Write-Host 'OpenVideo JY-002 Jianying adapter checks passed.' -ForegroundColor Green
