[CmdletBinding()]
param(
    [string]$RepositoryRoot
)

$ErrorActionPreference = 'Stop'
$RepositoryRoot = if ($RepositoryRoot) {
    (Resolve-Path -LiteralPath $RepositoryRoot).Path
} else {
    (Resolve-Path -LiteralPath (Join-Path (Split-Path -Parent $PSCommandPath) '..')).Path
}
$validator = Join-Path $RepositoryRoot 'scripts/Test-Governance.ps1'
$utf8 = [Text.UTF8Encoding]::new($false)
$tempRoot = [IO.Path]::GetFullPath($env:TEMP)
$temp = Join-Path $tempRoot ('openvideo-governance-' + [guid]::NewGuid())
$inheritedDiffBase = [Environment]::GetEnvironmentVariable('GOVERNANCE_DIFF_BASE', 'Process')
$inheritedDiffHead = [Environment]::GetEnvironmentVariable('GOVERNANCE_DIFF_HEAD', 'Process')
Remove-Item Env:GOVERNANCE_DIFF_BASE -ErrorAction SilentlyContinue
Remove-Item Env:GOVERNANCE_DIFF_HEAD -ErrorAction SilentlyContinue

function Write-Status([hashtable]$Status) {
    [IO.File]::WriteAllText((Join-Path $temp 'docs/tasks/STATUS.json'), ($Status | ConvertTo-Json -Depth 10), $utf8)
    $taskDocumentPath = Join-Path $temp ('docs/tasks/{0}.md' -f $Status.current_task)
    $taskDocument = @(
        ('# {0} / Fixture' -f $Status.current_task),
        '',
        '## Status',
        '',
        ('- Status: `{0}`' -f $Status.current_status),
        '',
        '## Evidence',
        '',
        '- Synthetic governance fixture'
    ) -join [Environment]::NewLine
    [IO.File]::WriteAllText($taskDocumentPath, $taskDocument, $utf8)
    & git -c core.safecrlf=false -C $temp add -- . | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Unable to stage governance fixture status' }
}

function Expect-Failure([string]$Name, [string]$ExpectedText) {
    $log = Join-Path $temp "$Name.log"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $temp 'scripts/Test-Governance.ps1') -RepositoryRoot $temp *> $log
    if ($LASTEXITCODE -eq 0) { throw "$Name unexpectedly passed" }
    $content = Get-Content -LiteralPath $log -Raw -Encoding UTF8
    if ($content -notmatch [regex]::Escape($ExpectedText)) { throw "$Name failed for an unexpected reason" }
    Write-Host "$Name rejected: PASS"
}

function Expect-Success([string]$Name) {
    $log = Join-Path $temp "$Name.log"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $temp 'scripts/Test-Governance.ps1') -RepositoryRoot $temp *> $log
    if ($LASTEXITCODE -ne 0) {
        $content = Get-Content -LiteralPath $log -Raw -Encoding UTF8
        throw "$Name unexpectedly failed: $content"
    }
    Write-Host "$Name accepted: PASS"
}

try {
    New-Item -ItemType Directory -Path (Join-Path $temp 'docs/tasks') -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $temp 'scripts') -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $temp '.github/workflows') -Force | Out-Null
    Copy-Item -LiteralPath $validator -Destination (Join-Path $temp 'scripts/Test-Governance.ps1')
    New-Item -ItemType File -Path (Join-Path $temp 'scripts/Test-Governance-Negative.ps1') -Force | Out-Null
    New-Item -ItemType File -Path (Join-Path $temp 'scripts/Test-LocalAcceptance.ps1') -Force | Out-Null
    $manualWorkflow = @('name: Governance', 'on:', '  workflow_dispatch:') -join [Environment]::NewLine
    [IO.File]::WriteAllText((Join-Path $temp '.github/workflows/governance.yml'), $manualWorkflow, $utf8)
    foreach ($relativePath in @('AGENTS.md','.gitignore','docs/tasks/ROADMAP.md','docs/tasks/TASK-TEMPLATE.md','docs/tasks/REVIEW-CHECKLIST.md','docs/tasks/HANDOFF-TEMPLATE.md')) {
        New-Item -ItemType File -Path (Join-Path $temp $relativePath) -Force | Out-Null
    }
    & git -C $temp init -q

    $governanceTask = @{ id='GOV-001'; status='in_progress'; status_history=@('planned','in_progress'); depends_on=@(); handoff_thread_id=$null }
    $editMindTask = @{ id='EM-001'; status='planned'; status_history=@('planned'); depends_on=@('GOV-001'); handoff_thread_id=$null }
    $initialStatus = @{schema_version=1;project='test';current_task='GOV-001';current_status='in_progress';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task='EM-001';tasks=@($governanceTask,$editMindTask)}
    Write-Status $initialStatus

    $currentTaskDocumentPath = Join-Path $temp 'docs/tasks/GOV-001.md'
    [IO.File]::AppendAllText($currentTaskDocumentPath, ([Environment]::NewLine + [Environment]::NewLine + '## Status' + [Environment]::NewLine + [Environment]::NewLine + '- Status: `in_progress`'), $utf8)
    & git -c core.safecrlf=false -C $temp add -- $currentTaskDocumentPath | Out-Null
    Expect-Failure 'task-record-duplicate-section-gate' 'contains duplicate ## Status section'
    Write-Status $initialStatus

    $mismatchedTaskDocument = @(
        '# GOV-001 / Fixture',
        '',
        '## Status',
        '',
        '- Status: `reviewed`',
        '',
        '## Evidence',
        '',
        '- Synthetic governance fixture'
    ) -join [Environment]::NewLine
    [IO.File]::WriteAllText($currentTaskDocumentPath, $mismatchedTaskDocument, $utf8)
    & git -c core.safecrlf=false -C $temp add -- $currentTaskDocumentPath | Out-Null
    Expect-Failure 'task-record-status-gate' 'status reviewed does not match STATUS.json current_status in_progress'
    Write-Status $initialStatus

    $leak = 'C:' + '\Users\Example\secret'
    [IO.File]::WriteAllText((Join-Path $temp 'LEAK.md'), $leak, $utf8)
    & git -c core.safecrlf=false -C $temp add -- LEAK.md | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Unable to stage machine-path fixture' }
    Expect-Failure 'machine-path-gate' 'Machine-specific absolute path detected in LEAK.md'
    Remove-Item -LiteralPath (Join-Path $temp 'LEAK.md') -Force
    & git -C $temp rm --cached -q LEAK.md

    [IO.File]::WriteAllText((Join-Path $temp 'SECRET.txt'), "TOKEN=Abcd1234`nOPENAI_API_KEY=Abcd1234", $utf8)
    & git -c core.safecrlf=false -C $temp add -- SECRET.txt | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Unable to stage secret fixture' }
    Expect-Failure 'generic-secret-gate' 'Potential secret detected in SECRET.txt'
    Remove-Item -LiteralPath (Join-Path $temp 'SECRET.txt') -Force
    & git -C $temp rm --cached -q SECRET.txt

    [IO.File]::WriteAllText((Join-Path $temp 'UNTRACKED-LEAK.md'), $leak, $utf8)
    Expect-Failure 'untracked-machine-path-gate' 'Machine-specific absolute path detected in UNTRACKED-LEAK.md'
    Remove-Item -LiteralPath (Join-Path $temp 'UNTRACKED-LEAK.md') -Force

    [IO.File]::WriteAllText((Join-Path $temp 'UNTRACKED-SECRET.txt'), 'OPENAI_API_KEY=Untracked1234', $utf8)
    Expect-Failure 'untracked-secret-gate' 'Potential secret detected in UNTRACKED-SECRET.txt'
    Remove-Item -LiteralPath (Join-Path $temp 'UNTRACKED-SECRET.txt') -Force

    $safeCodeDirectory = Join-Path $temp 'apps/gateway/test'
    New-Item -ItemType Directory -Path $safeCodeDirectory -Force | Out-Null
    $safeCodePath = Join-Path $safeCodeDirectory 'governance-code-expression.test.mjs'
    $safeCode = @(
        'const leaseToken = attempt.lease.token',
        'const parsedToken = parsed.token'
    ) -join [Environment]::NewLine
    [IO.File]::WriteAllText($safeCodePath, $safeCode, $utf8)
    Expect-Success 'code-expression-secret-gate'
    Remove-Item -LiteralPath $safeCodePath -Force

    & git -C $temp config user.name 'Governance Test'
    & git -C $temp config user.email 'governance@example.invalid'

    $automaticWorkflow = @('name: Governance', 'on:', '  push:', '  workflow_dispatch:') -join [Environment]::NewLine
    [IO.File]::WriteAllText((Join-Path $temp '.github/workflows/governance.yml'), $automaticWorkflow, $utf8)
    & git -c core.safecrlf=false -C $temp add -- .github/workflows/governance.yml | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Unable to stage automatic workflow fixture' }
    Expect-Failure 'automatic-actions-gate' 'must not run automatically on push or pull_request'
    [IO.File]::WriteAllText((Join-Path $temp '.github/workflows/governance.yml'), $manualWorkflow, $utf8)
    & git -c core.safecrlf=false -C $temp add -- .github/workflows/governance.yml | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Unable to stage manual workflow fixture' }

    & git -C $temp commit -q -m 'baseline in progress'

    $jumpedTask = @{ id='GOV-001'; status='reviewed'; status_history=@('planned','in_progress','implemented','verified','reviewed'); depends_on=@(); handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='reviewed';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task='EM-001';tasks=@($jumpedTask,$editMindTask)}
    Expect-Failure 'status-jump-gate' 'must append at most one lifecycle state per change'

    & git -C $temp reset --hard -q HEAD
    $rangeBase = (& git -C $temp rev-parse HEAD).Trim()
    $implementedTask = @{ id='GOV-001'; status='implemented'; status_history=@('planned','in_progress','implemented'); depends_on=@(); handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='implemented';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task='EM-001';tasks=@($implementedTask,$editMindTask)}
    & git -C $temp commit -q -m 'implemented'
    $verifiedTask = @{ id='GOV-001'; status='verified'; status_history=@('planned','in_progress','implemented','verified'); depends_on=@(); handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='verified';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task='EM-001';tasks=@($verifiedTask,$editMindTask)}
    & git -C $temp commit -q -m 'verified'
    $env:GOVERNANCE_DIFF_BASE = $rangeBase
    $env:GOVERNANCE_DIFF_HEAD = (& git -C $temp rev-parse HEAD).Trim()
    Expect-Success 'multi-commit-range-gate'
    Remove-Item Env:GOVERNANCE_DIFF_BASE -ErrorAction SilentlyContinue
    Remove-Item Env:GOVERNANCE_DIFF_HEAD -ErrorAction SilentlyContinue
    & git -C $temp reset --hard -q $rangeBase

    $invalidVerifiedTask = @{ id='GOV-001'; status='verified'; status_history=@('planned','in_progress','implemented','verified'); depends_on=@(); handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='verified';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task='EM-001';tasks=@($invalidVerifiedTask,$editMindTask)}
    & git -C $temp commit -q -m 'invalid jump to verified'
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='implemented';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task='EM-001';tasks=@($implementedTask,$editMindTask)}
    & git -C $temp commit -q -m 'restore final implemented state'
    $env:GOVERNANCE_DIFF_BASE = $rangeBase
    $env:GOVERNANCE_DIFF_HEAD = (& git -C $temp rev-parse HEAD).Trim()
    Expect-Failure 'multi-commit-range-jump-gate' 'must append at most one lifecycle state per change'
    Remove-Item Env:GOVERNANCE_DIFF_BASE -ErrorAction SilentlyContinue
    Remove-Item Env:GOVERNANCE_DIFF_HEAD -ErrorAction SilentlyContinue
    & git -C $temp reset --hard -q $rangeBase
    $handoffTask = @{ id='GOV-001'; status='handed_off'; status_history=@('planned','in_progress','implemented','verified','reviewed','documented','committed','pushed','handed_off'); depends_on=@(); handoff_thread_id='x' }
    $env:GOVERNANCE_DIFF_BASE = $null
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='handed_off';remote_repository='https://github.com/example/fake.git';default_branch='main';last_pushed_commit='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';next_task='EM-001';tasks=@($handoffTask,$editMindTask)}
    Expect-Failure 'handoff-id-gate' 'requires a UUID-format handoff_thread_id'

    $invalidCursorHandoffTask = @{ id='GOV-001'; status='handed_off'; status_history=@('planned','in_progress','implemented','verified','reviewed','documented','committed','pushed','handed_off'); depends_on=@(); handoff_kind='cursor'; handoff_id='x'; handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='handed_off';remote_repository='https://github.com/example/fake.git';default_branch='main';last_pushed_commit='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';next_task='EM-001';tasks=@($invalidCursorHandoffTask,$editMindTask)}
    Expect-Failure 'cursor-handoff-id-gate' 'requires a UUID-format handoff_id'

    $startedEditMindTask = @{ id='EM-001'; status='in_progress'; status_history=@('planned','in_progress'); depends_on=@('GOV-001'); handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='EM-001';current_status='in_progress';remote_repository=$null;default_branch='main';last_pushed_commit=$null;next_task=$null;tasks=@($governanceTask,$startedEditMindTask)}
    Expect-Failure 'dependency-gate' 'started before dependency GOV-001 was handed off'

    $pushedTask = @{ id='GOV-001'; status='pushed'; status_history=@('planned','in_progress','implemented','verified','reviewed','documented','committed','pushed'); depends_on=@(); handoff_thread_id=$null }
    Write-Status @{schema_version=1;project='test';current_task='GOV-001';current_status='pushed';remote_repository='https://github.com/example/fake.git';default_branch='main';last_pushed_commit='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';next_task='EM-001';tasks=@($pushedTask,$editMindTask)}
    Expect-Failure 'push-evidence-gate' 'Pushed state requires a configured origin remote'
} finally {
    if ($null -eq $inheritedDiffBase) { Remove-Item Env:GOVERNANCE_DIFF_BASE -ErrorAction SilentlyContinue }
    else { $env:GOVERNANCE_DIFF_BASE = $inheritedDiffBase }
    if ($null -eq $inheritedDiffHead) { Remove-Item Env:GOVERNANCE_DIFF_HEAD -ErrorAction SilentlyContinue }
    else { $env:GOVERNANCE_DIFF_HEAD = $inheritedDiffHead }
    $resolved = [IO.Path]::GetFullPath($temp)
    if (-not $resolved.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe temp cleanup target' }
    if (Test-Path -LiteralPath $resolved) { Remove-Item -LiteralPath $resolved -Recurse -Force }
}

Write-Host 'All governance negative tests passed.' -ForegroundColor Green
exit 0
