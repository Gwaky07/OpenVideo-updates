import { spawn } from 'node:child_process'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

import { isEncryptedDraftContent } from './jianying-draft-decrypt.mjs'
import { createReplicationRecipeFromJianyingDraft } from './replication-recipe.mjs'

const maxOutputBytes = 4 * 1024 * 1024
const knownCodes = new Set([
  'JY_TEMPLATE_FALLBACK_REQUIRED',
  'JY_TEMPLATE_DECRYPT_UNSUPPORTED_VERSION',
  'JY_TEMPLATE_DECRYPT_FAILED',
  'JY_TEMPLATE_DECRYPT_HELPER_MISSING',
  'JY_TEMPLATE_DECRYPT_INSTALL_MISSING',
  'JY_TEMPLATE_INPUT_INVALID',
  'JY_TEMPLATE_READ_FAILED',
  'JY_TEMPLATE_SOURCE_INVALID',
  'JY_TEMPLATE_STRUCTURE_INVALID',
  'JY_TEMPLATE_UPSTREAM_INVALID',
])

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

export class JianyingTemplateReaderError extends Error {
  /**
   * @param {string} code
   * @param {number} [status]
   * @param {unknown} [diagnostic]
   */
  constructor(code, status = 409, diagnostic = null) {
    super(code)
    this.name = 'JianyingTemplateReaderError'
    this.code = code
    this.status = status
    this.diagnostic = diagnostic
  }
}

/**
 * @param {{
 *   pythonModuleRoot: string,
 *   expectedCommit: string,
 *   pythonExecutable?: string,
 *   bridgePath?: string,
 *   timeoutMs?: number,
 *   decryptHelperPath?: string | null,
 *   jianyingInstallDir?: string | null,
 *   jianyingAppVersion?: string | null,
 * }} options
 */
export const createJianyingTemplateReader = ({
  pythonModuleRoot,
  expectedCommit,
  pythonExecutable = 'python',
  bridgePath = fileURLToPath(new URL('./jianying-template-reader.py', import.meta.url)),
  timeoutMs = 30_000,
  decryptHelperPath = null,
  jianyingInstallDir = null,
  jianyingAppVersion = null,
}) => {
  if (
    !path.isAbsolute(pythonModuleRoot) ||
    !path.isAbsolute(bridgePath) ||
    typeof expectedCommit !== 'string' ||
    !/^[a-f0-9]{40}$/u.test(expectedCommit) ||
    timeoutMs < 1_000
  ) throw new JianyingTemplateReaderError('JY_TEMPLATE_UPSTREAM_INVALID', 503)

  /** @param {Record<string, any>} payload */
  const runBridge = (payload) => new Promise((resolve, reject) => {
    const child = spawn(pythonExecutable, [bridgePath], {
      env: {
        ...process.env,
        PYTHONPATH: [pythonModuleRoot, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter),
        PYTHONDONTWRITEBYTECODE: '1',
      },
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    })
    /** @type {Buffer[]} */
    const chunks = []
    let byteCount = 0
    let settled = false
    /** @param {Error | null} error @param {any} [value] */
    const finish = (error, value) => {
      if (settled) return
      settled = true
      clearTimeout(timeout)
      if (error) reject(error)
      else resolve(value)
    }
    const timeout = setTimeout(() => {
      child.kill('SIGKILL')
      finish(new JianyingTemplateReaderError('JY_TEMPLATE_READ_FAILED', 504))
    }, timeoutMs)
    child.stdout.on('data', (chunk) => {
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
      byteCount += bytes.length
      if (byteCount <= maxOutputBytes) chunks.push(bytes)
    })
    child.stderr.resume()
    child.on('error', () => {
      finish(new JianyingTemplateReaderError('JY_TEMPLATE_READ_FAILED', 503))
    })
    child.on('close', (code, signal) => {
      if (settled) return
      if (code !== 0 || signal !== null || byteCount > maxOutputBytes) {
        finish(new JianyingTemplateReaderError('JY_TEMPLATE_READ_FAILED', 502))
        return
      }
      try {
        const response = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        if (!record(response) || typeof response.ok !== 'boolean') {
          finish(new JianyingTemplateReaderError('JY_TEMPLATE_READ_FAILED', 502))
        } else if (!response.ok) {
          const codeValue = knownCodes.has(response.code)
            ? response.code
            : 'JY_TEMPLATE_READ_FAILED'
          const bridgeError = new JianyingTemplateReaderError(
            codeValue,
            codeValue === 'JY_TEMPLATE_UPSTREAM_INVALID'
              ? 503
              : codeValue === 'JY_TEMPLATE_DECRYPT_HELPER_MISSING' ||
                  codeValue === 'JY_TEMPLATE_DECRYPT_INSTALL_MISSING'
                ? 503
                : codeValue === 'JY_TEMPLATE_DECRYPT_FAILED'
                  ? 502
                  : 409,
          )
          if (
            record(response.diagnostic) &&
            typeof response.diagnostic.stage === 'string' &&
            typeof response.diagnostic.exception_type === 'string'
          ) {
            bridgeError.diagnostic = {
              stage: response.diagnostic.stage,
              exceptionType: response.diagnostic.exception_type,
            }
          }
          finish(bridgeError)
        } else {
          finish(null, response)
        }
      } catch {
        finish(new JianyingTemplateReaderError('JY_TEMPLATE_READ_FAILED', 502))
      }
    })
    child.stdin.end(`${JSON.stringify(payload)}\n`)
  })

  return {
    /**
     * @param {{
     *   draftFolder: string,
     *   blueprintId: string,
     *   fingerprint: string,
     * }} input
     */
    async inspect(input) {
      if (!path.isAbsolute(input?.draftFolder)) {
        throw new JianyingTemplateReaderError('JY_TEMPLATE_SOURCE_INVALID', 400)
      }
      const response = /** @type {Record<string, any>} */ (await runBridge({
        action: 'inspect',
        draft_folder: input.draftFolder,
        python_module_root: pythonModuleRoot,
        expected_upstream_commit: expectedCommit,
        ...(typeof decryptHelperPath === 'string' && decryptHelperPath
          ? { decrypt_helper: decryptHelperPath }
          : {}),
        ...(typeof jianyingInstallDir === 'string' && jianyingInstallDir
          ? { jianying_install_dir: jianyingInstallDir }
          : {}),
        ...(typeof jianyingAppVersion === 'string' && jianyingAppVersion
          ? { jianying_app_version: jianyingAppVersion }
          : {}),
      }))
      // Prefer plaintext blueprint draft_content.json: the Python bridge sanitizer
      // strips text content/styles needed to classify FlowerText vs captions.
      let content = response.content
      try {
        const draftPath = path.join(input.draftFolder, 'draft_content.json')
        const raw = await readFile(draftPath)
        if (!isEncryptedDraftContent(raw)) {
          const parsed = JSON.parse(raw.toString('utf8'))
          if (record(parsed)) content = parsed
        }
      } catch {
        // Keep bridge content when the private snapshot is unavailable.
      }
      return {
        recipe: createReplicationRecipeFromJianyingDraft({
          blueprintId: input.blueprintId,
          fingerprint: input.fingerprint,
          content,
        }),
      }
    },
  }
}
