import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { parseJianyingTextPackagingCatalog } from '../apps/gateway/src/jianying-text-packaging-catalog.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { createScaleEvidenceTimeline, projectScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const main = async () => {
  const dataRoot = loadLocalRuntimeConfig().dataRoot
  let catalog
  try {
    catalog = parseJianyingTextPackagingCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy063-text-packaging-catalog.json'), 'utf8')))
  } catch {
    throw new Error('JY063_PRIVATE_CATALOG_REQUIRED')
  }
  if (!catalog) throw new Error('JY063_PRIVATE_CATALOG_REQUIRED')
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== 'jianying-11-1-provisional') throw new Error('JY063_PROFILE_UNSUPPORTED')
  const entries = Object.fromEntries(catalog.entries.map((entry) => [entry.kind, entry]))
  for (const kind of ['sticker', 'flower', 'bubble']) if (!entries[kind]) throw new Error('JY063_CATALOG_ENTRY_MISSING')
  const evidenceRoot = path.join(dataRoot, 'evidence', 'jy063-text-packaging')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(evidenceRoot)
  try {
    await readFile(path.join(evidenceRoot, 'pending.json'), 'utf8')
    throw new Error('JY063_PENDING_EVIDENCE_CLEANUP_REQUIRED')
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  let pythonModuleRoot = process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (!pythonModuleRoot && process.env.LOCALAPPDATA) {
    try {
      const localConfig = JSON.parse(await readFile(path.join(process.env.LOCALAPPDATA, 'OpenVideo', 'config.json'), 'utf8'))
      if (typeof localConfig.pyjianyingdraft_root === 'string' && path.isAbsolute(localConfig.pyjianyingdraft_root)) pythonModuleRoot = localConfig.pyjianyingdraft_root
    } catch { /* writer will fail closed below */ }
  }
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy063-text-packaging-'))
  const video = path.join(mediaRoot, 'video.mp4')
  const audio = path.join(mediaRoot, 'voice.wav')
  const { execFile } = await import('node:child_process')
  const run = (args) => new Promise((resolve, reject) => execFile('ffmpeg', args, { windowsHide: true }, (error) => error ? reject(error) : resolve()))
  await run(['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', video])
  await run(['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audio])
  const projected = projectScaleEvidenceTimeline(desktop.profileId, createScaleEvidenceTimeline())
  const draftId = `OpenVideo-JY063-text-packaging-${Date.now()}`
  const writer = createPyJianyingDraftWriter({ draftRoot: desktop.draftRoot, pythonModuleRoot, getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', captionSegments: [], keywordHighlights: [], titleSegments: [
    { text: 'JY063 花字', target_start_us: 0, target_duration_us: 2_000_000, flower_effect_id: entries.flower.effect_id },
    { text: 'JY063 气泡', target_start_us: 2_000_000, target_duration_us: 2_000_000, bubble_effect_id: entries.bubble.effect_id, bubble_resource_id: entries.bubble.resource_id },
  ], timelinePackaging: { ...projected.packaging, sticker_segments: [{ resource_id: entries.sticker.resource_id, target_start_us: 0, target_duration_us: 4_000_000 }], sfx_segments: [], effect_segments: [], filter_segments: [], animation_segments: [], mask_segments: [], blend_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } } }) })
  const request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: video }], voiceovers: [{ path: audio }] }
  const result = await writer.writeDraft(request)
  if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY063_VERIFY_FAILED')
  if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY063_RELEASE_FAILED')
  await writeFile(path.join(evidenceRoot, 'pending.json'), `${JSON.stringify({ schema_version: 1, draft_id: draftId, profile_id: desktop.profileId, app_version: desktop.version, draft_root: desktop.draftRoot, media_root: mediaRoot, catalog_fingerprint: catalog.fingerprint, capabilities: ['sticker.named', 'text.flower.private', 'text.bubble.private'] })}\n`, { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(`${JSON.stringify({ ok: true, manual_open_required: true, draft_prefix: 'OpenVideo-JY063-text-packaging-', sticker_name: entries.sticker.display_name ?? 'sticker', flower_name: entries.flower.display_name ?? 'flower', bubble_name: entries.bubble.display_name ?? 'bubble', profile: desktop.profileId, version: desktop.version })}\n`)
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.message ?? 'JY063_GENERATE_FAILED' })}\n`); process.exitCode = 1 })
