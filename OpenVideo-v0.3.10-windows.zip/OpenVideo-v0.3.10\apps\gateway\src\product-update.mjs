import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  installFrontendZipBuffer,
  isAllowedPublicUpdateUrl,
  parsePublicFrontendManifest,
  PublicFrontendUpdateError,
} from './public-frontend-update.mjs'

const STATUSES = new Set(['current', 'available', 'check_failed'])
const REASONS = new Set([
  'offline',
  'auth_required',
  'source_unavailable',
  'dirty_tree',
  'not_fast_forward',
  'apply_failed',
])

const SAFE_NOTE = /^[\p{L}\p{N}\p{P}\p{Zs}]{1,160}$/u
const CHINESE_NOTE = /[\u3400-\u9fff]/u
const UNSAFE_NOTE = /https?:\/\/|github\.com|[A-Za-z]:\\|sk-|api[_-]?key|token=/iu
const COMMIT_SHA = /^[a-f0-9]{40}$/u
const COMMIT_LIKE = /^[a-f0-9]{7,40}$/iu
const HUMAN_VERSION = /^v?\d[\w.+-]{0,30}$/u

class ProductUpdateError extends Error {
  /** @param {string} code @param {string} [reason] */
  constructor(code, reason) {
    super(code)
    this.name = 'ProductUpdateError'
    this.code = code
    this.reason = reason
  }
}

const emptySnapshot = () => ({
  status: 'check_failed',
  checking: false,
  currentLabel: null,
  latestLabel: null,
  latestVersion: null,
  releasedAt: null,
  summary: '尚未检查更新',
  notes: [],
  checkedAt: null,
  canApply: false,
  reason: null,
  scope: null,
})

const summarize = (status, reason) => {
  if (status === 'current') return '已是最新版本'
  if (status === 'available') return '有新的产品更新'
  if (reason === 'offline') return '暂时无法检查更新，请检查网络后重试'
  if (reason === 'auth_required') return '这台电脑还不能检查更新，稍后可重试'
  if (reason === 'dirty_tree') return '本地文件有未保存改动，更新已暂停'
  if (reason === 'not_fast_forward') return '无法安全套用更新，未改动当前版本'
  return '暂时无法检查更新，可重试'
}

const shortLabel = (value) => {
  if (typeof value !== 'string' || !value.trim()) return null
  const trimmed = value.trim()
  if (COMMIT_SHA.test(trimmed)) return trimmed.slice(0, 12)
  return trimmed.slice(0, 32)
}

const toIsoTime = (value) => {
  if (typeof value !== 'string' || !value.trim()) return null
  const time = Date.parse(value)
  return Number.isNaN(time) ? null : new Date(time).toISOString()
}

export const humanProductVersion = (version, releasedAt, fallbackVersion = null) => {
  const pick = (value) => {
    const text = typeof value === 'string' ? value.trim() : ''
    if (text && HUMAN_VERSION.test(text) && !COMMIT_LIKE.test(text) && !UNSAFE_NOTE.test(text)) {
      return text.slice(0, 32)
    }
    return null
  }
  return pick(version) || pick(fallbackVersion) || (() => {
    const iso = toIsoTime(releasedAt)
    if (!iso) return null
    const date = new Date(iso)
    const month = String(date.getUTCMonth() + 1).padStart(2, '0')
    const day = String(date.getUTCDate()).padStart(2, '0')
    return `${date.getUTCFullYear()}.${month}.${day}`
  })()
}

const readManifestPayload = async (fetchPublic, url) => {
  const raw = await fetchPublic(url, false)
  if (typeof raw === 'string') {
    return { text: raw, publishedAt: null }
  }
  if (raw && typeof raw === 'object' && typeof raw.text === 'string') {
    return { text: raw.text, publishedAt: toIsoTime(raw.publishedAt ?? raw.lastModified) }
  }
  return { text: String(raw ?? ''), publishedAt: null }
}

// Windows PowerShell 5.1 may emit UTF-8 JSON with a leading BOM.  The public
// update feed is downloaded as text, so normalize that marker before parsing
// instead of treating an otherwise valid manifest as a failed check.
const parseManifestJson = (text) => JSON.parse(String(text ?? '').replace(/^\uFEFF/u, ''))

const NOTE_ZH = new Map([
  ['sidebar update without login', '不用登录也能更新'],
])

const sanitizeNotes = (notes) => {
  if (!Array.isArray(notes)) return []
  const cleaned = []
  for (const note of notes) {
    if (typeof note !== 'string') continue
    const raw = note.replace(/\s+/gu, ' ').trim()
    const text = NOTE_ZH.get(raw.toLowerCase()) || raw
    if (!text || !CHINESE_NOTE.test(text) || UNSAFE_NOTE.test(text) || !SAFE_NOTE.test(text)) continue
    cleaned.push(text)
    if (cleaned.length >= 8) break
  }
  return cleaned
}

export const sanitizeProductUpdateSnapshot = (value) => {
  const record = value && typeof value === 'object' ? value : {}
  const status = STATUSES.has(record.status) ? record.status : 'check_failed'
  const reason = REASONS.has(record.reason) ? record.reason : null
  const checkedAt = typeof record.checkedAt === 'string' && !Number.isNaN(Date.parse(record.checkedAt))
    ? record.checkedAt
    : null
  const releasedAt = toIsoTime(record.releasedAt)
  return {
    status,
    checking: record.checking === true,
    currentLabel: shortLabel(record.currentLabel),
    latestLabel: shortLabel(record.latestLabel),
    latestVersion: humanProductVersion(record.latestVersion ?? record.version, releasedAt),
    releasedAt,
    summary: typeof record.summary === 'string' && record.summary.trim()
      ? record.summary.trim().slice(0, 80)
      : summarize(status, reason),
    notes: sanitizeNotes(record.notes),
    checkedAt,
    canApply: record.canApply === true && status === 'available',
    reason: status === 'check_failed' || status === 'available' ? reason : null,
    scope: record.scope === 'full' || record.scope === 'frontend' ? record.scope : null,
  }
}

const classifyProbeError = (error) => {
  const text = `${error?.message ?? ''} ${error?.stderr ?? ''} ${error?.code ?? ''}`.toLowerCase()
  if (/auth|401|403|denied|username|password|could not read from remote|repository not found|permission|fatal: could not read/u.test(text)) {
    return 'auth_required'
  }
  if (/enotfound|eai_again|timed out|timeout|could not resolve|failed to connect|offline|network|econnreset|enotconn/u.test(text)) {
    return 'offline'
  }
  return 'source_unavailable'
}

const readJsonIfPresent = async (path) => {
  try {
    return JSON.parse(await readFile(path, 'utf8'))
  } catch {
    return null
  }
}

const defaultRunGit = async (args, cwd, timeoutMs = 20_000) => {
  const { execFile } = await import('node:child_process')
  const { promisify } = await import('node:util')
  const execFileAsync = promisify(execFile)
  try {
    const { stdout } = await execFileAsync('git', args, {
      cwd,
      timeout: timeoutMs,
      windowsHide: true,
      encoding: 'utf8',
    })
    return String(stdout ?? '').trim()
  } catch (error) {
    const wrapped = new Error(error?.message ?? 'git_failed')
    wrapped.stderr = error?.stderr ?? ''
    wrapped.code = error?.code
    throw wrapped
  }
}

const FETCH_TIMEOUT_MS = 25_000
const MAX_FRONTEND_BYTES = 20 * 1024 * 1024
const MAX_UPDATE_BYTES = 500 * 1024 * 1024

const defaultFetchPublic = async (url, asBuffer = false) => {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS)
  try {
    const response = await fetch(url, {
      cache: 'no-store',
      redirect: 'error',
      signal: controller.signal,
      headers: { accept: asBuffer ? 'application/octet-stream' : 'application/json' },
    })
    if (!response.ok) {
      throw new ProductUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
    }
    const declared = Number(response.headers.get('content-length') ?? 0)
    if (declared > MAX_UPDATE_BYTES) {
      throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
    }
    const lastModified = toIsoTime(response.headers.get('last-modified') ?? '')
    if (asBuffer) {
      const buffer = Buffer.from(await response.arrayBuffer())
      if (buffer.length > MAX_UPDATE_BYTES) {
        throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
      }
      return buffer
    }
    return {
      text: await response.text(),
      lastModified,
    }
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new ProductUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'offline')
    }
    throw error
  } finally {
    clearTimeout(timer)
  }
}

const defaultInstallFrontendPackage = installFrontendZipBuffer

const sha256Hex = (buffer) => createHash('sha256').update(buffer).digest('hex')

const defaultRestart = (repositoryRoot) => {
  const script = join(repositoryRoot, 'scripts', 'Start-OpenVideo.ps1')
  if (!existsSync(script)) {
    throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
  }
  const child = spawn('powershell.exe', [
    '-NoProfile',
    '-ExecutionPolicy',
    'Bypass',
    '-File',
    script,
    '-Replace',
  ], {
    cwd: repositoryRoot,
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  })
  child.unref()
}

const defaultApplyFullPackage = async ({ buffer, repositoryRoot }) => {
  const updater = join(repositoryRoot, 'scripts', 'Apply-OpenVideoFullUpdate.mjs')
  if (!existsSync(updater)) throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
  const stage = await mkdtemp(join(tmpdir(), 'ov-full-'))
  const packagePath = join(stage, 'update.zip')
  const updaterCopy = join(stage, 'Apply-OpenVideoFullUpdate.mjs')
  await writeFile(packagePath, buffer)
  await writeFile(updaterCopy, await readFile(updater))
  const child = spawn(process.execPath, [updaterCopy, packagePath, repositoryRoot], {
    cwd: repositoryRoot, detached: true, stdio: 'ignore', windowsHide: true,
  })
  child.unref()
  return { restarting: true, summary: '正在更新全部产品能力并重启工作台' }
}

/**
 * @param {{
 *   repositoryRoot: string,
 *   runGit?: (args: string[], cwd: string, timeoutMs?: number) => Promise<string>,
 *   restart?: (root: string) => void,
 *   now?: () => Date,
 *   configPath?: string,
 *   fetchPublic?: (url: string, asBuffer?: boolean) => Promise<string | Buffer>,
 *   installFrontendPackage?: (input: { buffer: Buffer, destDir: string }) => Promise<void>,
 *   applyFullPackage?: (input: { buffer: Buffer, repositoryRoot: string }) => Promise<{ restarting: boolean, summary: string }>,
 *   allowUnsafeFullRootForTests?: boolean,
 * }} options
 */
export const createProductUpdateService = ({
  repositoryRoot,
  runGit = defaultRunGit,
  restart = defaultRestart,
  now = () => new Date(),
  configPath = join(repositoryRoot, 'config', 'product-update.json'),
  fetchPublic = defaultFetchPublic,
  installFrontendPackage = defaultInstallFrontendPackage,
  applyFullPackage: applyFullPackageImpl = defaultApplyFullPackage,
  allowUnsafeFullRootForTests = false,
}) => {
  let snapshot = emptySnapshot()
  /** @type {Promise<ReturnType<typeof sanitizeProductUpdateSnapshot>> | null} */
  let inFlight = null

  const readConfig = async () => {
    // REL-017 / cold-start safety net: if configPath is not yet readable
    // (e.g. Bootstrap-OpenVideo is still unzipping runtime.zip onto program\),
    // also try the legacy relative layout once before declaring the manifest
    // unavailable.  This is what made v0.3.5 / v0.3.9 cold-start checks fail
    // intermittently with reason='source_unavailable'.
    const primary = await readJsonIfPresent(configPath)
    const fallback = primary ?? await readJsonIfPresent(
      join(repositoryRoot, 'config', 'product-update.json')
    )
    const raw = fallback ?? primary
    return {
      defaultBranch: typeof raw?.defaultBranch === 'string' && raw.defaultBranch.trim()
        ? raw.defaultBranch.trim()
        : 'main',
      remoteName: typeof raw?.remoteName === 'string' && raw.remoteName.trim()
        ? raw.remoteName.trim()
        : 'origin',
      fallbackRemote: typeof raw?.fallbackRemote === 'string' && raw.fallbackRemote.trim()
        ? raw.fallbackRemote.trim()
        : '',
      publicManifestUrl: typeof raw?.publicManifestUrl === 'string' && raw.publicManifestUrl.trim()
        ? raw.publicManifestUrl.trim()
        : '',
      productVersion: typeof raw?.productVersion === 'string' && raw.productVersion.trim()
        ? raw.productVersion.trim().slice(0, 32)
        : '',
      fullUpdateEnabled: raw?.fullUpdateEnabled === true,
    }
  }

  const hasGit = () => existsSync(join(repositoryRoot, '.git'))
  const isSafeFullInstallRoot = () => {
    if (allowUnsafeFullRootForTests) return !hasGit() && existsSync(join(repositoryRoot, 'OpenVideo.exe'))
    if (hasGit()) return false
    if (!existsSync(join(repositoryRoot, 'OpenVideo.exe'))) return false
    const localAppData = process.env.LOCALAPPDATA
    if (!localAppData) return false
    const root = repositoryRoot.replace(/[\\/]+$/u, '').toLowerCase()
    const allowed = join(localAppData, 'OpenVideo', 'program').replace(/[\\/]+$/u, '').toLowerCase()
    return root === allowed
  }
  const frontendIdentityPath = join(repositoryRoot, 'apps', 'web', 'dist', '.openvideo-frontend.json')
  /** @type {ReturnType<typeof parsePublicFrontendManifest> | null} */
  let publicManifest = null

  const readLocalCommit = async ({ preferFrontend = false } = {}) => {
    if (preferFrontend) {
      const frontend = await readJsonIfPresent(frontendIdentityPath)
      if (frontend && COMMIT_SHA.test(String(frontend.commit ?? '').trim())) {
        return String(frontend.commit).trim().toLowerCase()
      }
    }
    if (hasGit()) {
      const head = await runGit(['rev-parse', 'HEAD'], repositoryRoot)
      if (COMMIT_SHA.test(head)) return head
    }
    for (const identityPath of [
      join(repositoryRoot, 'release-identity.json'),
      join(repositoryRoot, 'openvideo-full-package.json'),
    ]) {
      const identity = await readJsonIfPresent(identityPath)
      if (identity && COMMIT_SHA.test(String(identity.commit ?? '').trim())) {
        return String(identity.commit).trim()
      }
    }
    return null
  }

  const readRemoteCommit = async (config) => {
    if (hasGit()) {
      await runGit(['fetch', '--quiet', config.remoteName, config.defaultBranch], repositoryRoot, 25_000)
      const remote = await runGit(['rev-parse', `${config.remoteName}/${config.defaultBranch}`], repositoryRoot)
      if (COMMIT_SHA.test(remote)) return remote
    }
    if (!config.fallbackRemote) {
      throw new ProductUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
    }
    const line = await runGit([
      'ls-remote',
      config.fallbackRemote,
      `refs/heads/${config.defaultBranch}`,
    ], repositoryRoot, 25_000)
    const sha = line.split(/\s+/u)[0]
    if (!COMMIT_SHA.test(sha)) {
      throw new ProductUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
    }
    return sha
  }

  const readNotes = async (localCommit, remoteCommit) => {
    if (!hasGit() || !localCommit || !remoteCommit || localCommit === remoteCommit) return []
    const log = await runGit([
      'log',
      '--format=%s',
      '--max-count=8',
      `${localCommit}..${remoteCommit}`,
    ], repositoryRoot)
    return sanitizeNotes(log.split(/\r?\n/u))
  }

  const fail = (reason) => sanitizeProductUpdateSnapshot({
    status: 'check_failed',
    checking: false,
    currentLabel: snapshot.currentLabel,
    latestLabel: null,
    latestVersion: snapshot.latestVersion,
    releasedAt: snapshot.releasedAt,
    summary: summarize('check_failed', reason),
    notes: [],
    checkedAt: now().toISOString(),
    canApply: false,
    reason,
  })

  const writeFrontendIdentity = async (manifest) => {
    await mkdir(join(repositoryRoot, 'apps', 'web', 'dist'), { recursive: true })
    await writeFile(frontendIdentityPath, `${JSON.stringify({
      schema_version: 1,
      commit: manifest.commit,
      version: manifest.version,
      appliedAt: now().toISOString(),
    })}\n`)
  }

  const performPublicCheck = async (config) => {
    if (!isAllowedPublicUpdateUrl(config.publicManifestUrl)) {
      throw new ProductUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
    }
    const payload = await readManifestPayload(fetchPublic, config.publicManifestUrl)
    const parsed = parseManifestJson(payload.text)
    const manifest = parsePublicFrontendManifest(parsed, config.publicManifestUrl)
    publicManifest = manifest
    const releasedAt = manifest.publishedAt || payload.publishedAt || now().toISOString()
    const latestVersion = humanProductVersion(manifest.version, releasedAt, config.productVersion)
    const localCommit = await readLocalCommit({ preferFrontend: true })
    if (localCommit && localCommit === manifest.commit) {
      snapshot = sanitizeProductUpdateSnapshot({
        status: 'current',
        checking: false,
        currentLabel: shortLabel(localCommit),
        latestLabel: shortLabel(manifest.commit),
        latestVersion,
        releasedAt,
        summary: summarize('current'),
        notes: [],
        checkedAt: now().toISOString(),
        canApply: false,
        reason: null,
        scope: manifest.scope,
      })
      return snapshot
    }
    snapshot = sanitizeProductUpdateSnapshot({
      status: 'available',
      checking: false,
      currentLabel: shortLabel(localCommit),
      latestLabel: shortLabel(manifest.commit),
      latestVersion,
      releasedAt,
      summary: manifest.scope === 'frontend' ? '有新的界面更新' : summarize('available'),
      notes: sanitizeNotes(manifest.notes),
      checkedAt: now().toISOString(),
      canApply: manifest.scope === 'frontend' || (manifest.scope === 'full' && config.fullUpdateEnabled && isSafeFullInstallRoot() && existsSync(join(repositoryRoot, 'scripts', 'Apply-OpenVideoFullUpdate.mjs'))),
      reason: null,
      scope: manifest.scope,
    })
    return snapshot
  }

  const applyFrontendPackage = async (config) => {
    const manifest = publicManifest ?? parsePublicFrontendManifest(
      parseManifestJson((await readManifestPayload(fetchPublic, config.publicManifestUrl)).text),
      config.publicManifestUrl,
    )
    if (manifest.scope !== 'frontend') {
      throw new ProductUpdateError('PRODUCT_UPDATE_NOT_AVAILABLE', 'source_unavailable')
    }
    const buffer = await fetchPublic(manifest.packageUrl, true)
    if (!Buffer.isBuffer(buffer) || buffer.length > MAX_FRONTEND_BYTES || sha256Hex(buffer) !== manifest.sha256) {
      snapshot = fail('apply_failed')
      throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
    }
    const destDir = join(repositoryRoot, 'apps', 'web', 'dist')
    await installFrontendPackage({ buffer, destDir })
    await writeFrontendIdentity(manifest)
    publicManifest = manifest
    restart(repositoryRoot)
    return {
      restarting: true,
      summary: '正在更新界面并重启工作台',
    }
  }

  const applyFullPackageFromFeed = async (config) => {
    if (!isSafeFullInstallRoot()) {
      throw new ProductUpdateError('PRODUCT_UPDATE_NOT_AVAILABLE', 'source_unavailable')
    }
    const manifest = publicManifest ?? parsePublicFrontendManifest(
      parseManifestJson((await readManifestPayload(fetchPublic, config.publicManifestUrl)).text),
      config.publicManifestUrl,
    )
    if (manifest.scope !== 'full') throw new ProductUpdateError('PRODUCT_UPDATE_NOT_AVAILABLE', 'source_unavailable')
    const buffer = await fetchPublic(manifest.packageUrl, true)
    if (!Buffer.isBuffer(buffer) || buffer.length > MAX_UPDATE_BYTES || sha256Hex(buffer) !== manifest.sha256) {
      snapshot = fail('apply_failed')
      throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
    }
    return applyFullPackageImpl({ buffer, repositoryRoot })
  }

  const performCheck = async () => {
    snapshot = sanitizeProductUpdateSnapshot({
      ...snapshot,
      checking: true,
      summary: '正在检查更新',
    })
    try {
      const config = await readConfig()
      if (config.publicManifestUrl) {
        try {
          return await performPublicCheck(config)
        } catch (error) {
          if (error instanceof PublicFrontendUpdateError || error instanceof SyntaxError) {
            snapshot = fail(error.reason ?? 'source_unavailable')
            return snapshot
          }
          throw error
        }
      }
      const localCommit = await readLocalCommit()
      if (!localCommit) {
        snapshot = fail('source_unavailable')
        return snapshot
      }
      const remoteCommit = await readRemoteCommit(config)
      if (localCommit === remoteCommit) {
        const checkedAt = now().toISOString()
        snapshot = sanitizeProductUpdateSnapshot({
          status: 'current',
          checking: false,
          currentLabel: shortLabel(localCommit),
          latestLabel: shortLabel(remoteCommit),
          latestVersion: humanProductVersion(null, checkedAt, config.productVersion),
          releasedAt: checkedAt,
          summary: summarize('current'),
          notes: [],
          checkedAt,
          canApply: false,
          reason: null,
        })
        return snapshot
      }
      if (hasGit()) {
        try {
          await runGit(['merge-base', '--is-ancestor', localCommit, remoteCommit], repositoryRoot)
        } catch {
          snapshot = fail('not_fast_forward')
          return snapshot
        }
      }
      const checkedAt = now().toISOString()
      snapshot = sanitizeProductUpdateSnapshot({
        status: 'available',
        checking: false,
        currentLabel: shortLabel(localCommit),
        latestLabel: shortLabel(remoteCommit),
        latestVersion: humanProductVersion(null, checkedAt, config.productVersion),
        releasedAt: checkedAt,
        summary: summarize('available'),
        notes: await readNotes(localCommit, remoteCommit),
        checkedAt,
        canApply: hasGit(),
        reason: null,
      })
      return snapshot
    } catch (error) {
      const reason = error instanceof ProductUpdateError
        ? error.reason
        : classifyProbeError(error)
      snapshot = fail(reason)
      return snapshot
    }
  }

  const check = async ({ force = false } = {}) => {
    if (
      !force
      && snapshot.checkedAt
      && snapshot.status !== 'check_failed'
      && !snapshot.checking
    ) {
      return snapshot
    }
    if (inFlight) return inFlight
    inFlight = performCheck().finally(() => {
      inFlight = null
    })
    return inFlight
  }

  const apply = async () => {
    const current = await check({ force: true })
    if (current.status !== 'available') {
      throw new ProductUpdateError('PRODUCT_UPDATE_NOT_AVAILABLE', current.reason ?? 'source_unavailable')
    }
    const config = await readConfig()
    if (config.publicManifestUrl) {
      const manifest = publicManifest ?? parsePublicFrontendManifest(
        parseManifestJson((await readManifestPayload(fetchPublic, config.publicManifestUrl)).text),
        config.publicManifestUrl,
      )
      return manifest.scope === 'full' ? applyFullPackageFromFeed(config) : applyFrontendPackage(config)
    }
    if (!hasGit()) {
      throw new ProductUpdateError('PRODUCT_UPDATE_SOURCE_UNAVAILABLE', 'source_unavailable')
    }
    const porcelain = await runGit(['status', '--porcelain'], repositoryRoot)
    if (porcelain) {
      snapshot = fail('dirty_tree')
      throw new ProductUpdateError('PRODUCT_UPDATE_DIRTY_TREE', 'dirty_tree')
    }
    try {
      const config = await readConfig()
      const remoteRef = `${config.remoteName}/${config.defaultBranch}`
      await runGit(['merge', '--ff-only', remoteRef], repositoryRoot)
      const after = await runGit(['rev-parse', 'HEAD'], repositoryRoot)
      const expected = await runGit(['rev-parse', remoteRef], repositoryRoot)
      if (!COMMIT_SHA.test(after) || after !== expected) {
        snapshot = fail('apply_failed')
        throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', 'apply_failed')
      }
    } catch (error) {
      if (error instanceof ProductUpdateError) throw error
      const reason = /not possible to fast-forward|refusing to merge/iu.test(`${error?.message ?? ''} ${error?.stderr ?? ''}`)
        ? 'not_fast_forward'
        : classifyProbeError(error) === 'auth_required'
          ? 'auth_required'
          : 'apply_failed'
      snapshot = fail(reason)
      throw new ProductUpdateError('PRODUCT_UPDATE_APPLY_FAILED', reason)
    }
    restart(repositoryRoot)
    return {
      restarting: true,
      summary: '正在更新并重启工作台',
    }
  }

  return {
    getSnapshot: () => sanitizeProductUpdateSnapshot(snapshot),
    check,
    apply,
    startBackgroundCheck: () => {
      void check({ force: true })
    },
  }
}

/**
 * @param {{ service: ReturnType<typeof createProductUpdateService> }} options
 */
export const createProductUpdateHandler = ({ service }) => {
  const json = (body, status = 200) => new Response(JSON.stringify(body), {
    status,
    headers: {
      'cache-control': 'no-store',
      'content-type': 'application/json; charset=utf-8',
      'x-content-type-options': 'nosniff',
    },
  })

  return async (request) => {
    const pathname = new URL(request.url).pathname
    if (pathname === '/api/product-update' && request.method === 'GET') {
      const snapshot = service.getSnapshot()
      if (!snapshot.checkedAt && !snapshot.checking) {
        void service.check({ force: true })
        return json(sanitizeProductUpdateSnapshot({
          ...snapshot,
          checking: true,
          summary: '正在检查更新',
        }))
      }
      return json(snapshot.checking ? snapshot : await service.check())
    }
    if (pathname === '/api/product-update/check' && request.method === 'POST') {
      return json(await service.check({ force: true }))
    }
    if (pathname === '/api/product-update/apply' && request.method === 'POST') {
      try {
        return json(await service.apply())
      } catch (error) {
        const reason = error instanceof ProductUpdateError ? error.reason : 'apply_failed'
        const status = reason === 'dirty_tree' || reason === 'not_fast_forward' ? 409 : 503
        return json({
          error: {
            code: error instanceof ProductUpdateError ? error.code : 'PRODUCT_UPDATE_APPLY_FAILED',
          },
          ...service.getSnapshot(),
          reason,
          summary: summarize('check_failed', reason),
        }, status)
      }
    }
    if (pathname.startsWith('/api/product-update')) {
      return json({ error: { code: 'METHOD_NOT_ALLOWED' } }, 405)
    }
    return json({ error: { code: 'NOT_FOUND' } }, 404)
  }
}
