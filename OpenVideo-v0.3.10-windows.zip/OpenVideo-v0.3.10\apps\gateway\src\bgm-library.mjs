import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import { copyFile, lstat, mkdir, open, readdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { basename, dirname, extname, isAbsolute, parse, relative, resolve } from 'node:path'
import { Readable, Transform } from 'node:stream'
import { promisify } from 'node:util'

import { ensureWindowsNativePickerHost, securePrivateRuntimeRoot } from './local-runtime.mjs'
import { createPreviewMediaResponse } from './workbench-preview.mjs'

const execFileAsync = promisify(execFile)
const schemaVersion = 1
const maxTracksPerProject = 200
const maxAudioBytes = 512 * 1024 * 1024
const probeTimeoutMs = 10_000
const probeOutputBytes = 64 * 1024
const trackIdPattern = /^bgm_[a-f0-9]{24}$/u
const legacyAuthorizationIdPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/iu
const opaqueIdPattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,179}$/u
const shaPattern = /^[a-f0-9]{64}$/u
const mediaFilePattern = /^(?:bgm|legacy)_[a-f0-9]{24}\.(?:aac|flac|m4a|mp3|ogg|wav)$/u
const audioTypes = new Map([
  ['.aac', 'audio/aac'],
  ['.flac', 'audio/flac'],
  ['.m4a', 'audio/mp4'],
  ['.mp3', 'audio/mpeg'],
  ['.ogg', 'audio/ogg'],
  ['.wav', 'audio/wav'],
])

/**
 * @typedef {{
 *   trackId: string,
 *   projectId: string,
 *   authorizationId: string,
 *   label: string,
 *   extension: string,
 *   mediaFile?: string,
 *   size: number,
 *   mtimeMs: number,
 *   sha256: string,
 *   createdAt: string,
 *   updatedAt: string,
 * }} BgmTrackRecord
 */

export class BgmLibraryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'BgmLibraryError'
    this.code = code
    this.status = status
  }
}
const expectedProbeFormats = new Map([
  ['.aac', new Set(['aac'])],
  ['.flac', new Set(['flac'])],
  ['.m4a', new Set(['mov', 'mp4', 'm4a', '3gp', '3g2', 'mj2'])],
  ['.mp3', new Set(['mp3'])],
  ['.ogg', new Set(['ogg'])],
  ['.wav', new Set(['wav'])],
])

/** @param {{ffprobePath: string, runner?: typeof execFileAsync}} options */
export const createFfprobeAudioProbe = ({ ffprobePath, runner = execFileAsync }) => {
  if (
    typeof ffprobePath !== 'string' || !isAbsolute(ffprobePath) || !existsSync(ffprobePath) ||
    typeof runner !== 'function'
  ) {
    throw new BgmLibraryError('BGM_LIBRARY_PROBE_UNAVAILABLE', 503)
  }
  return async (/** @type {{path: string, extension: string}} */ input) => {
    try {
      /** @type {Record<string, string>} */
      const environment = { PATH: dirname(ffprobePath) }
      for (const key of ['SystemRoot', 'WINDIR', 'TEMP', 'TMP']) {
        if (typeof process.env[key] === 'string') environment[key] = process.env[key]
      }
      const { stdout } = await runner(ffprobePath, [
        '-v', 'error',
        '-protocol_whitelist', 'file,pipe',
        '-max_alloc', '67108864',
        '-probesize', '1048576',
        '-analyzeduration', '5000000',
        '-show_entries', 'format=format_name,duration:stream=codec_type,codec_name,sample_rate,channels',
        '-of', 'json',
        input.path,
      ], {
        cwd: dirname(ffprobePath),
        encoding: 'utf8',
        env: environment,
        windowsHide: true,
        maxBuffer: probeOutputBytes,
        timeout: probeTimeoutMs,
      })
      const parsed = /** @type {Record<string, any>} */ (JSON.parse(stdout))
      const formats = typeof parsed?.format?.format_name === 'string'
        ? parsed.format.format_name.split(',').map((/** @type {string} */ value) => value.trim())
        : []
      const expectedFormats = expectedProbeFormats.get(input.extension)
      const duration = Number(parsed?.format?.duration)
      const streams = Array.isArray(parsed?.streams) ? parsed.streams : []
      return Boolean(
        expectedFormats &&
        formats.some((/** @type {string} */ format) => expectedFormats.has(format)) &&
        Number.isFinite(duration) && duration > 0 && duration <= 86_400 &&
        streams.length > 0 &&
        streams.every((/** @type {Record<string, any>} */ stream) =>
          stream?.codec_type === 'audio' &&
          typeof stream.codec_name === 'string' && stream.codec_name.length > 0 &&
          Number(stream.sample_rate) > 0 &&
          Number(stream.channels) > 0),
      )
    } catch {
      return false
    }
  }
}
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {number} max */
const safeLabel = (value, max) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.trim().length <= max &&
  !/[\u0000-\u001f\u007f]/u.test(value) &&
  !/(?:file:\/\/|[A-Za-z]:[\\/]|\\\\|\/(?:home|users|private|var|tmp|mnt|volumes)\/)/iu.test(value)
const GENERIC_AUDIO_LABEL = /^已授权本机音频/u
/** @param {unknown} absolutePath */
const safeFileNameLabel = (absolutePath) => {
  if (typeof absolutePath !== 'string' || !isAbsolute(absolutePath)) return null
  const fileName = basename(absolutePath)
  return safeLabel(fileName, 100) ? fileName : null
}
/** @param {unknown} label @param {unknown} absolutePath */
const displayLabelFor = (label, absolutePath) => {
  if (typeof label === 'string' && !GENERIC_AUDIO_LABEL.test(label) && safeLabel(label, 100)) {
    return label
  }
  return safeFileNameLabel(absolutePath) ?? (
    typeof label === 'string' && safeLabel(label, 100) ? label : null
  )
}
/** @param {unknown} value */
const opaqueId = (value) => typeof value === 'string' && opaqueIdPattern.test(value)
/** @param {unknown} error */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error
  ? String(error.code)
  : null
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}
/** @param {string | Buffer} value */
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
/** @param {import('node:fs/promises').FileHandle} handle @param {number} size */
const sha256Handle = async (handle, size) => {
  const hash = createHash('sha256')
  const buffer = Buffer.allocUnsafe(1024 * 1024)
  let position = 0
  while (position < size) {
    const length = Math.min(buffer.length, size - position)
    const chunk = await handle.read(buffer, 0, length, position)
    if (chunk.bytesRead <= 0) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
    hash.update(buffer.subarray(0, chunk.bytesRead))
    position += chunk.bytesRead
  }
  if (position !== size) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
  return hash.digest('hex')
}
/** @param {string} trackId @param {string} extension */
const privateMediaFile = (trackId, extension) => trackIdPattern.test(trackId)
  ? `${trackId}${extension}`
  : `legacy_${sha256(trackId).slice(0, 24)}${extension}`
/** @param {string} projectId @param {string} authorizationId */
const modernTrackIdFor = (projectId, authorizationId) =>
  `bgm_${sha256(`${projectId}\u0000${authorizationId}`).slice(0, 24)}`
/** @param {BgmTrackRecord} track */
const publicAliasIds = (track) => {
  const aliases = []
  const modernId = modernTrackIdFor(track.projectId, track.authorizationId)
  if (modernId !== track.trackId && trackIdPattern.test(modernId)) aliases.push(modernId)
  if (
    legacyAuthorizationIdPattern.test(track.authorizationId) &&
    track.authorizationId !== track.trackId
  ) aliases.push(track.authorizationId)
  return aliases
}
/** @param {Buffer} header @param {string} extension */
const validAudioMagic = (header, extension) => {
  if (extension === '.mp3') {
    return header.subarray(0, 3).toString('ascii') === 'ID3' ||
      (header[0] === 0xff && (header[1] & 0xe0) === 0xe0)
  }
  if (extension === '.wav') {
    return header.subarray(0, 4).toString('ascii') === 'RIFF' &&
      header.subarray(8, 12).toString('ascii') === 'WAVE'
  }
  if (extension === '.flac') return header.subarray(0, 4).toString('ascii') === 'fLaC'
  if (extension === '.ogg') return header.subarray(0, 4).toString('ascii') === 'OggS'
  if (extension === '.m4a') return header.subarray(4, 8).toString('ascii') === 'ftyp'
  if (extension === '.aac') return header[0] === 0xff && (header[1] & 0xf6) === 0xf0
  return false
}
/** @param {import('node:fs').Stats} left @param {import('node:fs').Stats} right */
const sameFileIdentity = (left, right) => {
  if (left.dev && left.ino && right.dev && right.ino) {
    return left.dev === right.dev && left.ino === right.ino
  }
  return left.size === right.size && left.birthtimeMs === right.birthtimeMs
}
/** @param {import('node:fs').Stats} left @param {import('node:fs').Stats} right */
const sameStableMetadata = (left, right) => sameFileIdentity(left, right) &&
  left.size === right.size &&
  left.mtimeMs === right.mtimeMs &&
  left.ctimeMs === right.ctimeMs &&
  left.nlink === right.nlink
/** @param {import('node:fs').Stats} metadata */
const verificationIdentity = (metadata) => [
  metadata.dev,
  metadata.ino,
  metadata.size,
  metadata.mtimeMs,
  metadata.ctimeMs,
  metadata.birthtimeMs,
  metadata.nlink,
].join(':')

/** @param {string} path */
const assertNoLinkedAncestors = async (path) => {
  const absolute = resolve(path)
  const root = parse(absolute).root
  let current = dirname(absolute)
  while (current && current !== root) {
    const metadata = await lstat(current)
    if (metadata.isSymbolicLink()) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNSAFE', 400)
    current = dirname(current)
  }
}
/** @param {unknown} value @returns {value is BgmTrackRecord} */
const validTrack = (value) => isRecord(value) &&
  typeof value.trackId === 'string' &&
  (trackIdPattern.test(value.trackId) || legacyAuthorizationIdPattern.test(value.trackId)) &&
  opaqueId(value.projectId) &&
  opaqueId(value.authorizationId) &&
  safeLabel(value.label, 100) &&
  typeof value.extension === 'string' && audioTypes.has(value.extension) &&
  (value.mediaFile === undefined || (typeof value.mediaFile === 'string' && mediaFilePattern.test(value.mediaFile))) &&
  Number.isSafeInteger(value.size) && value.size > 0 && value.size <= maxAudioBytes &&
  typeof value.mtimeMs === 'number' && Number.isFinite(value.mtimeMs) && value.mtimeMs >= 0 &&
  typeof value.sha256 === 'string' && shaPattern.test(value.sha256) &&
  typeof value.createdAt === 'string' &&
  typeof value.updatedAt === 'string'

/** @param {string} path @returns {Promise<BgmTrackRecord[]>} */
const readStoreFile = async (path) => {
  const document = /** @type {unknown} */ (JSON.parse(await readFile(path, 'utf8')))
  if (
    !isRecord(document) ||
    document.schema_version !== schemaVersion ||
    !Array.isArray(document.records) ||
    !document.records.every(validTrack)
  ) throw new BgmLibraryError('BGM_LIBRARY_STORAGE_INVALID')
  return /** @type {BgmTrackRecord[]} */ (document.records)
}

/**
 * @param {string} path
 * @param {{schema_version: number, records: BgmTrackRecord[]}} document
 * @param {{preservePrimaryAsBackup?: boolean}} [options]
 */
const writeStore = async (path, document, { preservePrimaryAsBackup = true } = {}) => {
  const temporaryPath = `${path}.${randomUUID()}.tmp`
  await writeFile(temporaryPath, `${JSON.stringify(document, null, 2)}\n`, {
    encoding: 'utf8', flag: 'wx', mode: 0o600,
  })
  let seedBackup = false
  try {
    if (preservePrimaryAsBackup) {
      // Keep the previous primary as .bak so logical corruption can roll back.
      // On the first write there is no previous primary, so seed .bak from the new baseline.
      try {
        await copyFile(path, `${path}.bak`)
      } catch (error) {
        if (errorCode(error) !== 'ENOENT') throw error
        seedBackup = true
      }
    }
    await rename(temporaryPath, path)
    if (seedBackup) await copyFile(path, `${path}.bak`)
  } finally {
    await rm(temporaryPath, { force: true })
  }
}

/** @param {string} path @param {(event: Record<string, unknown>) => void} warn @returns {Promise<BgmTrackRecord[]>} */
const readStore = async (path, warn) => {
  try {
    return await readStoreFile(path)
  } catch (primaryError) {
    try {
      const backup = await readStoreFile(`${path}.bak`)
      await writeStore(path, { schema_version: schemaVersion, records: backup }, {
        preservePrimaryAsBackup: false,
      })
      warn({ event: 'bgm_library_storage_recovered', code: 'BGM_LIBRARY_STORAGE_RECOVERED' })
      return backup
    } catch (backupError) {
      if (errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') return []
      // Wipe private media BEFORE quarantining the store. If wipe fails, keep the broken
      // primary in place so the next boot cannot treat missing store as a clean empty library.
      const mediaDir = resolve(dirname(path), 'media')
      try {
        const entries = await readdir(mediaDir)
        await Promise.all(entries.map(async (entry) => {
          const mediaPath = resolve(mediaDir, entry)
          if (inside(mediaDir, mediaPath)) await rm(mediaPath, { force: true, recursive: true })
        }))
      } catch (mediaError) {
        if (errorCode(mediaError) !== 'ENOENT') {
          throw new BgmLibraryError('BGM_LIBRARY_STORAGE_INVALID')
        }
      }
      warn({
        event: 'bgm_library_storage_reset',
        code: 'BGM_LIBRARY_STORAGE_INVALID',
        primaryCode: errorCode(primaryError),
        backupCode: errorCode(backupError),
      })
      await rename(path, `${path}.corrupt.${Date.now()}`).catch(() => {})
      await rename(`${path}.bak`, `${path}.bak.corrupt.${Date.now()}`).catch(() => {})
      return []
    }
  }
}

/** @param {BgmTrackRecord} track */
const publicTrack = (track) => ({
  id: track.trackId,
  label: track.label,
  format: track.extension.slice(1).toUpperCase(),
  size: track.size,
  createdAt: track.createdAt,
  contentUrl: `/api/bgm-library/projects/${encodeURIComponent(track.projectId)}/tracks/${encodeURIComponent(track.trackId)}/content`,
  aliasIds: publicAliasIds(track),
})

/**
 * @param {{
 *   dataRoot: string,
 *   authorizationRepository: {
 *     get: (authorizationId: string) => Promise<Record<string, any> | null> | Record<string, any> | null,
 *     remove: (authorizationId: string) => Promise<unknown> | unknown,
 *     list?: () => Promise<Record<string, any>[]> | Record<string, any>[],
 *   },
 *   authorizeBgm: (input: {projectId: string, readOnlyConfirmed: true, absolutePath?: string}) => Promise<{authorizationId: string, bgmLabel: string}>,
 *   securePrivateRoot?: (path: string) => Promise<unknown>,
 *   audioProbe: (input: {path: string, extension: string}) => Promise<boolean>,
 *   maximumAudioBytes?: number,
 *   removeFile?: (path: string) => Promise<unknown>,
 *   hashHandle?: (handle: import('node:fs/promises').FileHandle, size: number) => Promise<string>,
 *   now?: () => string,
 *   warn?: (event: Record<string, unknown>) => void,
 * }} options
 */
export const createBgmLibrary = async ({
  dataRoot,
  authorizationRepository,
  authorizeBgm,
  securePrivateRoot = securePrivateRuntimeRoot,
  audioProbe,
  maximumAudioBytes = maxAudioBytes,
  removeFile = (path) => rm(path, { force: true }),
  hashHandle = sha256Handle,
  now = () => new Date().toISOString(),
  warn = () => {},
}) => {
  if (
    typeof dataRoot !== 'string' || !isAbsolute(dataRoot) ||
    typeof authorizationRepository?.get !== 'function' ||
    typeof authorizationRepository?.remove !== 'function' ||
    typeof authorizeBgm !== 'function' ||
    typeof securePrivateRoot !== 'function' || typeof audioProbe !== 'function' ||
    !Number.isSafeInteger(maximumAudioBytes) || maximumAudioBytes <= 0 || maximumAudioBytes > maxAudioBytes ||
    typeof removeFile !== 'function' || typeof hashHandle !== 'function' ||
    typeof now !== 'function' || typeof warn !== 'function'
  ) throw new BgmLibraryError('BGM_LIBRARY_CONFIGURATION_INVALID')

  const libraryRoot = resolve(dataRoot, 'bgm-library')
  const mediaRoot = resolve(libraryRoot, 'media')
  if (!inside(dataRoot, libraryRoot) || !inside(libraryRoot, mediaRoot)) {
    throw new BgmLibraryError('BGM_LIBRARY_STORAGE_INVALID')
  }
  await mkdir(mediaRoot, { recursive: true, mode: 0o700 })
  const [libraryMetadata, mediaMetadata] = await Promise.all([lstat(libraryRoot), lstat(mediaRoot)])
  if (
    libraryMetadata.isSymbolicLink() || !libraryMetadata.isDirectory() ||
    mediaMetadata.isSymbolicLink() || !mediaMetadata.isDirectory()
  ) throw new BgmLibraryError('BGM_LIBRARY_STORAGE_INVALID')
  await securePrivateRoot(libraryRoot)
  await securePrivateRoot(mediaRoot)
  const storePath = resolve(libraryRoot, 'tracks.json')
  /** @type {Map<string, BgmTrackRecord>} */
  const records = new Map((await readStore(storePath, warn)).map((record) => [record.trackId, record]))
  /** @type {Map<string, string>} */
  const verifiedTracks = new Map()
  /** @type {Promise<void>} */
  let writeQueue = Promise.resolve()

  const persist = async () => {
    const snapshot = [...records.values()].sort((left, right) => left.createdAt.localeCompare(right.createdAt))
    const pending = writeQueue.then(() => writeStore(storePath, {
      schema_version: schemaVersion,
      records: snapshot,
    }))
    writeQueue = pending.catch(() => {})
    await pending
  }

  /** @param {string} projectId @param {string} trackId */
  const findRecord = (projectId, trackId) => {
    const direct = records.get(trackId)
    if (direct?.projectId === projectId) return direct
    for (const track of records.values()) {
      if (track.projectId !== projectId) continue
      if (modernTrackIdFor(projectId, track.authorizationId) === trackId) return track
      if (track.authorizationId === trackId) return track
    }
    return null
  }

  /** @param {string} projectId @param {Record<string, any>} authorization @param {string} sourceSha */
  const findDuplicateTrack = async (projectId, authorization, sourceSha) => {
    const sourcePath = typeof authorization.absolutePath === 'string' ? authorization.absolutePath : ''
    for (const track of records.values()) {
      if (track.projectId !== projectId) continue
      if (track.authorizationId === authorization.id || track.sha256 === sourceSha) return track
      const existingAuthorization = await authorizationRepository.get(track.authorizationId)
      if (
        sourcePath &&
        typeof existingAuthorization?.absolutePath === 'string' &&
        existingAuthorization.absolutePath === sourcePath
      ) return track
    }
    return null
  }

  /** @param {BgmTrackRecord} track */
  const mediaPathFor = (track) => {
    if (typeof track.mediaFile !== 'string' || !mediaFilePattern.test(track.mediaFile)) return null
    const path = resolve(mediaRoot, track.mediaFile)
    return inside(mediaRoot, path) ? path : null
  }

  /** @param {string} path */
  const removePrivateMedia = async (path) => {
    try {
      await removeFile(path)
    } catch (error) {
      if (errorCode(error) !== 'ENOENT') {
        const failure = new BgmLibraryError('BGM_LIBRARY_CLEANUP_FAILED', 503)
        failure.cause = error
        throw failure
      }
    }
  }

  /** @param {string} authorizationId */
  const removeAuthorization = async (authorizationId) => {
    try {
      if (!await authorizationRepository.get(authorizationId)) return
      await Promise.resolve(authorizationRepository.remove(authorizationId))
      if (await authorizationRepository.get(authorizationId)) {
        throw new Error('authorization-not-removed')
      }
    } catch (error) {
      const failure = new BgmLibraryError('BGM_LIBRARY_CLEANUP_FAILED', 503)
      failure.cause = error
      throw failure
    }
  }

  /** @param {BgmTrackRecord} track @param {{removeTrackAuthorization?: boolean, persistChange?: boolean}} [options] */
  const discardTrack = async (track, { removeTrackAuthorization = false, persistChange = true } = {}) => {
    const mediaPath = mediaPathFor(track)
    if (removeTrackAuthorization) await removeAuthorization(track.authorizationId)
    if (mediaPath) await removePrivateMedia(mediaPath)
    const verifiedIdentity = verifiedTracks.get(track.trackId)
    records.delete(track.trackId)
    verifiedTracks.delete(track.trackId)
    if (persistChange) {
      try {
        await persist()
      } catch (error) {
        records.set(track.trackId, track)
        if (verifiedIdentity) verifiedTracks.set(track.trackId, verifiedIdentity)
        throw error
      }
    }
  }

  /** @param {{sourcePath: string, trackId: string, extension: string}} input */
  const importPrivateAudio = async ({ sourcePath, trackId, extension }) => {
    let sourceHandle = null
    let destinationHandle = null
    let temporaryPath = null
    try {
      await assertNoLinkedAncestors(sourcePath)
      const linkMetadata = await lstat(sourcePath)
      if (
        linkMetadata.isSymbolicLink() || !linkMetadata.isFile() || linkMetadata.nlink !== 1
      ) {
        throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNSAFE', 400)
      }
      sourceHandle = await open(sourcePath, 'r')
      const sourceMetadata = await sourceHandle.stat()
      const currentMetadata = await lstat(sourcePath)
      if (
        currentMetadata.isSymbolicLink() || !currentMetadata.isFile() ||
        currentMetadata.nlink !== 1 || sourceMetadata.nlink !== 1 ||
        !sameFileIdentity(sourceMetadata, currentMetadata)
      ) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNSAFE', 400)
      if (sourceMetadata.size <= 0 || sourceMetadata.size > maximumAudioBytes) {
        throw new BgmLibraryError(
          sourceMetadata.size > maximumAudioBytes ? 'BGM_LIBRARY_AUDIO_TOO_LARGE' : 'BGM_LIBRARY_AUDIO_INVALID',
          sourceMetadata.size > maximumAudioBytes ? 413 : 400,
        )
      }
      const header = Buffer.alloc(Math.min(16, sourceMetadata.size))
      const headerRead = await sourceHandle.read(header, 0, header.length, 0)
      if (headerRead.bytesRead !== header.length || !validAudioMagic(header, extension)) {
        throw new BgmLibraryError('BGM_LIBRARY_AUDIO_INVALID', 400)
      }
      const mediaFile = privateMediaFile(trackId, extension)
      const destinationPath = resolve(mediaRoot, mediaFile)
      if (!inside(mediaRoot, destinationPath)) throw new BgmLibraryError('BGM_LIBRARY_STORAGE_INVALID')
      temporaryPath = `${destinationPath}.${randomUUID()}.tmp`
      destinationHandle = await open(temporaryPath, 'wx', 0o600)
      const digest = createHash('sha256')
      const buffer = Buffer.allocUnsafe(1024 * 1024)
      let position = 0
      while (position < sourceMetadata.size) {
        const length = Math.min(buffer.length, sourceMetadata.size - position)
        const chunk = await sourceHandle.read(buffer, 0, length, position)
        if (chunk.bytesRead <= 0) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
        digest.update(buffer.subarray(0, chunk.bytesRead))
        let written = 0
        while (written < chunk.bytesRead) {
          const result = await destinationHandle.write(
            buffer,
            written,
            chunk.bytesRead - written,
            position + written,
          )
          if (result.bytesWritten <= 0) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
          written += result.bytesWritten
        }
        position += chunk.bytesRead
      }
      if (position !== sourceMetadata.size) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
      await destinationHandle.sync()
      await destinationHandle.close()
      destinationHandle = null
      if (await audioProbe({ path: temporaryPath, extension }) !== true) {
        throw new BgmLibraryError('BGM_LIBRARY_AUDIO_INVALID', 400)
      }
      await removePrivateMedia(destinationPath)
      await rename(temporaryPath, destinationPath)
      temporaryPath = null
      const privateMetadata = await stat(destinationPath)
      return {
        mediaFile,
        path: destinationPath,
        size: privateMetadata.size,
        mtimeMs: privateMetadata.mtimeMs,
        sha256: digest.digest('hex'),
      }
    } finally {
      await destinationHandle?.close().catch(() => {})
      await sourceHandle?.close().catch(() => {})
      if (temporaryPath) await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }

  /** @param {BgmTrackRecord} track @param {Record<string, any>} authorization */
  const ensurePrivateCopy = async (track, authorization) => {
    const existingPath = mediaPathFor(track)
    if (existingPath) {
      try {
        const metadata = await lstat(existingPath)
        if (!metadata.isSymbolicLink() && metadata.isFile()) return existingPath
      } catch {
        // Missing or unreadable private copy — fall through to re-import from authorization.
      }
    }
    if (typeof authorization.absolutePath !== 'string' || !isAbsolute(authorization.absolutePath)) return null
    try {
      const imported = await importPrivateAudio({
        sourcePath: authorization.absolutePath,
        trackId: track.trackId,
        extension: track.extension,
      })
      Object.assign(track, {
        mediaFile: imported.mediaFile,
        size: imported.size,
        mtimeMs: imported.mtimeMs,
        sha256: imported.sha256,
        updatedAt: now(),
      })
      await persist()
      return imported.path
    } catch {
      return null
    }
  }

  /** @param {string} projectId @param {string} authorizationId */
  const registerLegacyTrack = async (projectId, authorizationId) => {
    if (!opaqueId(projectId) || !legacyAuthorizationIdPattern.test(authorizationId)) return null
    const modern = [...records.values()].find((track) =>
      track.projectId === projectId &&
      track.authorizationId === authorizationId &&
      trackIdPattern.test(track.trackId))
    const existing = records.get(authorizationId)
    if (modern) {
      if (existing && existing.projectId === projectId) {
        await discardTrack(existing)
      }
      return modern
    }
    if (existing) return existing.projectId === projectId ? existing : null
    const authorization = await authorizationRepository.get(authorizationId)
    if (
      !authorization || authorization.projectId !== projectId ||
      authorization.status !== 'authorized' ||
      typeof authorization.absolutePath !== 'string' || !isAbsolute(authorization.absolutePath) ||
      !safeLabel(authorization.label, 100)
    ) return null
    const extension = extname(authorization.absolutePath).toLowerCase()
    if (!audioTypes.has(extension)) return null
    const projectTracks = await Promise.all(
      [...records.values()].filter((track) => track.projectId === projectId)
        .map(async (track) => Boolean(await resolveTrack({ projectId, trackId: track.trackId }))),
    )
    if (projectTracks.filter(Boolean).length >= maxTracksPerProject) return null
    try {
      const imported = await importPrivateAudio({
        sourcePath: authorization.absolutePath,
        trackId: authorizationId,
        extension,
      })
      const createdAt = typeof authorization.createdAt === 'string' ? authorization.createdAt : now()
      /** @type {BgmTrackRecord} */
      const track = {
        trackId: authorizationId,
        projectId,
        authorizationId,
        label: displayLabelFor(authorization.label, authorization.absolutePath) ?? authorization.label,
        extension,
        mediaFile: imported.mediaFile,
        size: imported.size,
        mtimeMs: imported.mtimeMs,
        sha256: imported.sha256,
        createdAt,
        updatedAt: now(),
      }
      records.set(track.trackId, track)
      try {
        await persist()
        return track
      } catch {
        await discardTrack(track, { persistChange: false })
        return null
      }
    } catch {
      return null
    }
  }

  /** @param {{projectId: string, trackId: string, verifyDigest?: boolean, persistDiscard?: boolean, retainHandle?: boolean}} input */
  const resolveTrack = async ({ projectId, trackId, verifyDigest = false, persistDiscard = true, retainHandle = false }) => {
    if (
      !opaqueId(projectId) ||
      !(trackIdPattern.test(String(trackId)) || legacyAuthorizationIdPattern.test(String(trackId)))
    ) return null
    const track = findRecord(projectId, String(trackId)) ?? await registerLegacyTrack(projectId, String(trackId))
    if (!track || track.projectId !== projectId) return null
    const authorization = await authorizationRepository.get(track.authorizationId)
    if (!authorization || authorization.projectId !== projectId || authorization.status !== 'authorized') {
      await discardTrack(track, { persistChange: persistDiscard })
      return null
    }
    const nextLabel = displayLabelFor(track.label, authorization.absolutePath)
    if (nextLabel && nextLabel !== track.label) {
      track.label = nextLabel
      track.updatedAt = now()
    }
    const privatePath = await ensurePrivateCopy(track, authorization)
    if (!privatePath) {
      await discardTrack(track, { persistChange: persistDiscard })
      return null
    }
    /** @type {import('node:fs/promises').FileHandle | null} */
    let handle = null
    try {
      handle = await open(privatePath, 'r')
      const [openedMetadata, pathMetadata] = await Promise.all([
        handle.stat(),
        lstat(privatePath),
      ])
      if (
        pathMetadata.isSymbolicLink() || !pathMetadata.isFile() ||
        !openedMetadata.isFile() || openedMetadata.size !== track.size ||
        !sameStableMetadata(openedMetadata, pathMetadata)
      ) {
        await handle.close()
        handle = null
        await discardTrack(track, { persistChange: persistDiscard })
        return null
      }
      const identity = verificationIdentity(openedMetadata)
      if (verifyDigest && verifiedTracks.get(track.trackId) !== identity) {
        if (await hashHandle(handle, openedMetadata.size) !== track.sha256) {
          await handle.close()
          handle = null
          await discardTrack(track, { persistChange: persistDiscard })
          return null
        }
        const [afterRead, currentPath] = await Promise.all([handle.stat(), lstat(privatePath)])
        if (
          currentPath.isSymbolicLink() || !currentPath.isFile() ||
          !sameStableMetadata(openedMetadata, afterRead) ||
          !sameStableMetadata(afterRead, currentPath)
        ) {
          await handle.close()
          handle = null
          await discardTrack(track, { persistChange: persistDiscard })
          return null
        }
        verifiedTracks.set(track.trackId, verificationIdentity(afterRead))
      }
      if (!retainHandle) {
        await handle.close()
        handle = null
        return { track, path: privatePath, metadata: openedMetadata }
      }
      return { track, path: privatePath, metadata: openedMetadata, handle }
    } catch (error) {
      await handle?.close().catch(() => {})
      if (error instanceof BgmLibraryError && error.code === 'BGM_LIBRARY_CLEANUP_FAILED') throw error
      try {
        await discardTrack(track, { persistChange: persistDiscard })
      } catch (cleanupError) {
        if (cleanupError instanceof BgmLibraryError) throw cleanupError
      }
      return null
    }
  }

  return {
    async describeTrack(/** @type {{projectId: string, trackId: string}} */ input) {
      const resolved = await resolveTrack({
        projectId: input?.projectId,
        trackId: input?.trackId,
        verifyDigest: true,
      })
      if (!resolved) return null
      return Object.freeze({
        trackId: resolved.track.trackId,
        label: resolved.track.label,
        extension: resolved.track.extension,
        size: resolved.track.size,
        sha256: resolved.track.sha256,
      })
    },
    getBackingAuthorizationId(/** @type {{projectId: string, trackId: string}} */ input) {
      if (!opaqueId(input?.projectId) || typeof input?.trackId !== 'string') return null
      const track = findRecord(input.projectId, input.trackId)
      return track?.authorizationId ?? null
    },
    async authorizeTrack(/** @type {{projectId: string, readOnlyConfirmed: true, sessionId?: string, nodeId?: string, absolutePath?: string}} */ input) {
      if (!opaqueId(input?.projectId) || input?.readOnlyConfirmed !== true) {
        throw new BgmLibraryError('BGM_LIBRARY_INPUT_INVALID', 400)
      }
      const rawProjectCount = [...records.values()].filter((track) => track.projectId === input.projectId).length
      if (rawProjectCount >= maxTracksPerProject) {
        const liveTracks = await this.listTracks(input.projectId)
        if (liveTracks.length >= maxTracksPerProject) {
          throw new BgmLibraryError('BGM_LIBRARY_TRACK_LIMIT_REACHED', 409)
        }
      }
      const authorized = await authorizeBgm(input)
      if (!opaqueId(authorized?.authorizationId) || !safeLabel(authorized?.bgmLabel, 100)) {
        throw new BgmLibraryError('BGM_LIBRARY_AUTHORIZATION_INVALID', 502)
      }
      const authorization = await authorizationRepository.get(authorized.authorizationId)
      if (
        !authorization || authorization.projectId !== input.projectId ||
        authorization.status !== 'authorized' ||
        typeof authorization.absolutePath !== 'string' || !isAbsolute(authorization.absolutePath)
      ) throw new BgmLibraryError('BGM_LIBRARY_AUTHORIZATION_INVALID', 502)
      const extension = extname(authorization.absolutePath).toLowerCase()
      if (!audioTypes.has(extension)) {
        await removeAuthorization(authorized.authorizationId)
        throw new BgmLibraryError('BGM_LIBRARY_AUDIO_INVALID', 400)
      }
      let sourceSha = ''
      try {
        const sourceHandle = await open(authorization.absolutePath, 'r')
        try {
          const sourceMetadata = await sourceHandle.stat()
          sourceSha = await hashHandle(sourceHandle, sourceMetadata.size)
        } finally {
          await sourceHandle.close().catch(() => {})
        }
      } catch {
        await removeAuthorization(authorized.authorizationId)
        throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
      }
      if (await findDuplicateTrack(input.projectId, authorization, sourceSha)) {
        await removeAuthorization(authorized.authorizationId)
        throw new BgmLibraryError('BGM_LIBRARY_TRACK_ALREADY_EXISTS', 409)
      }
      const createdAt = now()
      const trackId = modernTrackIdFor(input.projectId, authorized.authorizationId)
      let imported = null
      try {
        imported = await importPrivateAudio({
          sourcePath: authorization.absolutePath,
          trackId,
          extension,
        })
        /** @type {BgmTrackRecord} */
        const track = {
          trackId,
          projectId: input.projectId,
          authorizationId: authorized.authorizationId,
          label: displayLabelFor(authorized.bgmLabel, authorization.absolutePath) ?? authorized.bgmLabel,
          extension,
          mediaFile: imported.mediaFile,
          size: imported.size,
          mtimeMs: imported.mtimeMs,
          sha256: imported.sha256,
          createdAt,
          updatedAt: createdAt,
        }
        records.set(trackId, track)
        try {
          await persist()
        } catch (error) {
          records.delete(trackId)
          verifiedTracks.delete(trackId)
          await removePrivateMedia(imported.path).catch(() => {})
          throw error
        }
        return { authorizationId: trackId, bgmLabel: track.label, track: publicTrack(track) }
      } catch (error) {
        await removeAuthorization(authorized.authorizationId)
        if (error instanceof BgmLibraryError) throw error
        throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
      }
    },
    async listTracks(/** @type {string} */ projectId) {
      if (!opaqueId(projectId)) throw new BgmLibraryError('BGM_LIBRARY_INPUT_INVALID', 400)
      if (typeof authorizationRepository.list === 'function') {
        const authorizations = await authorizationRepository.list()
        if (Array.isArray(authorizations)) {
          for (const authorization of authorizations) {
            if (
              authorization?.projectId === projectId &&
              typeof authorization.id === 'string' &&
              legacyAuthorizationIdPattern.test(authorization.id)
            ) await registerLegacyTrack(projectId, authorization.id)
          }
        }
      }
      /** @type {Map<string, BgmTrackRecord>} */
      const uniqueTracks = new Map()
      const recordCountBeforeValidation = records.size
      let healedLabels = false
      for (const track of [...records.values()]) {
        const labelBefore = track.label
        if (
          track.projectId !== projectId ||
          !await resolveTrack({ projectId, trackId: track.trackId, persistDiscard: false })
        ) continue
        if (track.label !== labelBefore) healedLabels = true
        const current = uniqueTracks.get(track.authorizationId)
        if (
          !current ||
          (trackIdPattern.test(track.trackId) && !trackIdPattern.test(current.trackId))
        ) uniqueTracks.set(track.authorizationId, track)
      }
      if (records.size !== recordCountBeforeValidation || healedLabels) await persist()
      return [...uniqueTracks.values()]
        .map((track) => publicTrack(track))
        .sort((left, right) => right.createdAt.localeCompare(left.createdAt))
        .slice(0, maxTracksPerProject)
    },
    async isAuthorizedTrack(/** @type {{projectId: string, trackId: string}} */ input) {
      return Boolean(await resolveTrack({ ...input, verifyDigest: true }))
    },
    async acquireTrackLease(/** @type {{projectId: string, trackId: string}} */ input) {
      const resolvedTrack = await resolveTrack({ ...input, verifyDigest: true, retainHandle: true })
      if (!resolvedTrack?.handle) return null
      let consumed = false
      let released = false
      const consume = () => {
        if (consumed || released) {
          throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
        }
        consumed = true
      }
      return {
        extension: resolvedTrack.track.extension,
        sha256: resolvedTrack.track.sha256,
        size: resolvedTrack.metadata.size,
        acquireFileDescriptor: () => {
          consume()
          return resolvedTrack.handle.fd
        },
        createStream: () => {
          consume()
          const digest = createHash('sha256')
          let bytesRead = 0
          const verifier = new Transform({
            transform(chunk, _encoding, callback) {
              bytesRead += chunk.length
              digest.update(chunk)
              callback(null, chunk)
            },
            flush(callback) {
              if (
                bytesRead !== resolvedTrack.metadata.size ||
                digest.digest('hex') !== resolvedTrack.track.sha256
              ) {
                callback(new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503))
                return
              }
              callback()
            },
          })
          const source = resolvedTrack.handle.createReadStream({ autoClose: true })
          source.on('error', (error) => verifier.destroy(error))
          return source.pipe(verifier)
        },
        verifyIntegrity: async () => {
          if (!consumed || released) return false
          try {
            const metadata = await resolvedTrack.handle.stat()
            return metadata.isFile() &&
              sameStableMetadata(resolvedTrack.metadata, metadata) &&
              await hashHandle(resolvedTrack.handle, metadata.size) === resolvedTrack.track.sha256
          } catch {
            return false
          }
        },
        release: async () => {
          if (released) return
          released = true
          await resolvedTrack.handle.close().catch(() => {})
        },
      }
    },
    async getTrackResource(/** @type {{projectId: string, trackId: string}} */ input) {
      const resolvedTrack = await resolveTrack({ ...input, verifyDigest: true, retainHandle: true })
      if (!resolvedTrack?.handle) return null
      const contentType = audioTypes.get(resolvedTrack.track.extension)
      if (!contentType) {
        await resolvedTrack.handle.close().catch(() => {})
        return null
      }
      let consumed = false
      const close = async () => {
        if (consumed) return
        consumed = true
        await resolvedTrack.handle.close().catch(() => {})
      }
      return {
        contentType,
        etag: JSON.stringify(resolvedTrack.track.sha256),
        size: resolvedTrack.metadata.size,
        close,
        createStream: ({ start = 0, end = resolvedTrack.metadata.size - 1 } = {}) => {
          if (consumed) throw new BgmLibraryError('BGM_LIBRARY_AUDIO_UNAVAILABLE', 503)
          consumed = true
          return /** @type {ReadableStream} */ (
            /** @type {unknown} */ (Readable.toWeb(resolvedTrack.handle.createReadStream({ start, end, autoClose: true })))
          )
        },
      }
    },
    async deleteTrack(/** @type {{projectId: string, trackId: string}} */ input) {
      if (!opaqueId(input?.projectId) || !opaqueId(input?.trackId)) {
        throw new BgmLibraryError('BGM_LIBRARY_INPUT_INVALID', 400)
      }
      const track = findRecord(input.projectId, input.trackId)
      if (!track) return false
      await discardTrack(track, { removeTrackAuthorization: true })
      return true
    },
    async deleteProjectTracks(/** @type {{projectId: string}} */ input) {
      if (!opaqueId(input?.projectId)) throw new BgmLibraryError('BGM_LIBRARY_INPUT_INVALID', 400)
      const removed = [...records.values()].filter((track) => track.projectId === input.projectId)
      for (const track of removed) {
        await discardTrack(track, { removeTrackAuthorization: true })
      }
      return true
    },
  }
}
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) => isRecord(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')

/**
 * Fail-closed project BGM cleanup when createBgmLibrary did not start (e.g. ffprobe missing).
 * Returns false when residuals cannot be confirmed removed.
 * @param {{
 *   dataRoot: string,
 *   projectId: string,
 *   authorizationRepository: {
 *     get: (authorizationId: string) => Promise<Record<string, any> | null> | Record<string, any> | null,
 *     remove: (authorizationId: string) => Promise<unknown> | unknown,
 *   },
 *   removeFile?: (path: string) => Promise<unknown>,
 * }} options
 */
export const purgeBgmProjectResiduals = async ({
  dataRoot,
  projectId,
  authorizationRepository,
  removeFile = (path) => rm(path, { force: true }),
}) => {
  if (
    typeof dataRoot !== 'string' || !isAbsolute(dataRoot) ||
    !opaqueId(projectId) ||
    typeof authorizationRepository?.get !== 'function' ||
    typeof authorizationRepository?.remove !== 'function'
  ) return false
  const libraryRoot = resolve(dataRoot, 'bgm-library')
  const mediaRoot = resolve(libraryRoot, 'media')
  const storePath = resolve(libraryRoot, 'tracks.json')
  if (!inside(dataRoot, libraryRoot) || !inside(libraryRoot, mediaRoot)) return false
  let records
  try {
    records = await readStoreFile(storePath)
  } catch (error) {
    if (errorCode(error) === 'ENOENT') {
      try {
        records = await readStoreFile(`${storePath}.bak`)
      } catch (backupError) {
        if (errorCode(backupError) === 'ENOENT') return true
        return false
      }
    } else {
      return false
    }
  }
  const remaining = []
  for (const track of records) {
    if (track.projectId !== projectId) {
      remaining.push(track)
      continue
    }
    const mediaFile = typeof track.mediaFile === 'string' && mediaFilePattern.test(track.mediaFile)
      ? track.mediaFile
      : privateMediaFile(track.trackId, track.extension)
    const mediaPath = resolve(mediaRoot, mediaFile)
    if (!inside(mediaRoot, mediaPath)) return false
    try {
      await removeFile(mediaPath)
    } catch (error) {
      if (errorCode(error) !== 'ENOENT') return false
    }
    try {
      if (await authorizationRepository.get(track.authorizationId)) {
        await Promise.resolve(authorizationRepository.remove(track.authorizationId))
        if (await authorizationRepository.get(track.authorizationId)) return false
      }
    } catch {
      return false
    }
  }
  try {
    await writeStore(storePath, { schema_version: schemaVersion, records: remaining })
  } catch {
    return false
  }
  return true
}

/** @param {unknown} body @param {number} [status] */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  },
})

/**
 * @param {{
 *   library: Awaited<ReturnType<typeof createBgmLibrary>>,
 *   onTrackImported?: (input: {projectId: string, trackId: string, purpose: 'bgm' | 'sfx', rightsConfirmed: boolean}) => Promise<unknown> | unknown,
 *   onTrackDeleted?: (input: {projectId: string, trackId: string}) => Promise<unknown> | unknown,
 * }} options
 */
export const createBgmLibraryHandler = ({ library, onTrackImported, onTrackDeleted }) => async (/** @type {Request} */ request) => {
  const pathname = new URL(request.url).pathname
  try {
    const tracksMatch = pathname.match(/^\/api\/bgm-library\/projects\/([^/]+)\/tracks$/u)
    if (tracksMatch && request.method === 'GET') {
      void ensureWindowsNativePickerHost()
      const projectId = decodeURIComponent(tracksMatch[1])
      return jsonResponse({ schema_version: 1, tracks: await library.listTracks(projectId) })
    }
    if (tracksMatch && request.method === 'POST') {
      const projectId = decodeURIComponent(tracksMatch[1])
      const body = await request.json()
      const pickerOk = exactKeys(body, ['nodeId', 'readOnlyConfirmed', 'sessionId'])
      const legacyOk = exactKeys(body, ['readOnlyConfirmed'])
      const sfxPickerOk = exactKeys(body, [
        'nodeId', 'purpose', 'readOnlyConfirmed', 'rightsConfirmed', 'sessionId',
      ])
      const sfxLegacyOk = exactKeys(body, [
        'purpose', 'readOnlyConfirmed', 'rightsConfirmed',
      ])
      const sfxImport = (sfxPickerOk || sfxLegacyOk) &&
        body.purpose === 'sfx' && body.rightsConfirmed === true
      if ((!pickerOk && !legacyOk && !sfxImport) || body.readOnlyConfirmed !== true) {
        throw new BgmLibraryError('BGM_LIBRARY_INPUT_INVALID', 400)
      }
      const result = await library.authorizeTrack({
        projectId,
        readOnlyConfirmed: true,
        ...((pickerOk || sfxPickerOk)
          ? { sessionId: body.sessionId, nodeId: body.nodeId }
          : {}),
      })
      try {
        await onTrackImported?.({
          projectId,
          trackId: result.track.id,
          purpose: sfxImport ? 'sfx' : 'bgm',
          rightsConfirmed: sfxImport,
        })
      } catch (error) {
        await library.deleteTrack({ projectId, trackId: result.track.id }).catch(() => {})
        throw error
      }
      return jsonResponse({ schema_version: 1, track: result.track }, 201)
    }
    const contentMatch = pathname.match(/^\/api\/bgm-library\/projects\/([^/]+)\/tracks\/([^/]+)\/content$/u)
    if (contentMatch && ['GET', 'HEAD'].includes(request.method)) {
      const resource = await library.getTrackResource({
        projectId: decodeURIComponent(contentMatch[1]),
        trackId: decodeURIComponent(contentMatch[2]),
      })
      if (!resource) return jsonResponse({ error: { code: 'BGM_LIBRARY_TRACK_NOT_FOUND', message: 'BGM track not found.' } }, 404)
      return createPreviewMediaResponse({
        resource,
        rangeHeader: request.headers.get('range'),
        method: request.method,
      })
    }
    const trackMatch = pathname.match(/^\/api\/bgm-library\/projects\/([^/]+)\/tracks\/([^/]+)$/u)
    if (trackMatch && request.method === 'DELETE') {
      const projectId = decodeURIComponent(trackMatch[1])
      const trackId = decodeURIComponent(trackMatch[2])
      const deleted = await library.deleteTrack({
        projectId,
        trackId,
      })
      if (!deleted) return jsonResponse({ error: { code: 'BGM_LIBRARY_TRACK_NOT_FOUND', message: 'BGM track not found.' } }, 404)
      await onTrackDeleted?.({ projectId, trackId })
      return jsonResponse({ schema_version: 1, deletedTrackId: trackId })
    }
    return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  } catch (error) {
    const candidate = /** @type {{status?: unknown, code?: unknown}} */ (error)
    const status = Number.isSafeInteger(candidate?.status) ? Number(candidate.status) : 500
    const code = typeof candidate?.code === 'string' ? candidate.code : 'BGM_LIBRARY_UNAVAILABLE'
    return jsonResponse({ error: { code, message: 'BGM library operation failed safely.' } }, status)
  }
}
