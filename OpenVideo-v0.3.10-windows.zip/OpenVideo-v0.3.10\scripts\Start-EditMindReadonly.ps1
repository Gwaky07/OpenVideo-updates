[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$MaterialRoot,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [ValidateSet('cpu','cuda')][string]$Profile = 'cpu',
    [ValidateSet('Up','Down','Config')][string]$Action = 'Up',
    [string]$RepositoryRoot,
    [string]$UpstreamRoot,
    [string]$ProjectName
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $RepositoryRoot) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
if (-not $UpstreamRoot) { $UpstreamRoot = Join-Path $RepositoryRoot 'upstream/edit-mind' }

$pin = Get-Content -LiteralPath (Join-Path $RepositoryRoot 'config/edit-mind-upstream.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$actualSha = (& git -C $UpstreamRoot rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $actualSha -ne $pin.commit) { throw "Edit Mind checkout must be exactly $($pin.commit); found $actualSha" }
$actualRemote = (& git -C $UpstreamRoot remote get-url origin).Trim().TrimEnd('/')
if ($LASTEXITCODE -ne 0 -or $actualRemote -ne ([string]$pin.repository).TrimEnd('/')) {
    throw 'Edit Mind checkout remote does not match the pinned repository.'
}
$upstreamChanges = @(& git -C $UpstreamRoot status --porcelain --untracked-files=all)
if ($LASTEXITCODE -ne 0 -or $upstreamChanges.Count -ne 0) {
    throw 'Edit Mind checkout must be clean before Docker Compose is evaluated.'
}
$runtime = & (Join-Path $PSScriptRoot 'Initialize-EditMindReadonlyRuntime.ps1') -MaterialRoot $MaterialRoot -RuntimeDataRoot $RuntimeDataRoot -RepositoryRoot $RepositoryRoot -UpstreamRoot $UpstreamRoot -PassThru

if (-not $ProjectName) {
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        $runtimeBytes = [Text.Encoding]::UTF8.GetBytes($runtime.RuntimeDataRoot.ToLowerInvariant())
        $runtimeHash = -join ($sha256.ComputeHash($runtimeBytes) | ForEach-Object { $_.ToString('x2') })
    } finally { $sha256.Dispose() }
    $ProjectName = 'openvideo-edit-mind-' + $runtimeHash.Substring(0,12)
}
if ($ProjectName -notmatch '^[a-z0-9][a-z0-9_-]+$') { throw "Invalid Docker Compose project name: $ProjectName" }

$composeVersionText = (& docker compose version --short).Trim().TrimStart('v')
if ($LASTEXITCODE -ne 0) { throw 'Docker Compose is unavailable.' }
$composeVersionMatch = [regex]::Match($composeVersionText, '^\d+\.\d+\.\d+')
if (-not $composeVersionMatch.Success) { throw "Unrecognized Docker Compose version: $composeVersionText" }
$composeVersion = [version]$composeVersionMatch.Value
if ($composeVersion -lt [version]'2.24.4') { throw "Docker Compose 2.24.4 or newer is required for !override; found $composeVersionText" }

$composeName = if ($Profile -eq 'cuda') { 'docker-compose.cuda.yml' } else { 'docker-compose.yml' }
$composePath = Join-Path $runtime.UpstreamRoot $composeName
$overridePath = Join-Path $runtime.RepositoryRoot 'deploy/edit-mind/docker-compose.readonly.yml'
$arguments = @('compose','--env-file',$runtime.ComposeEnvironmentPath,'--project-name',$ProjectName,'-f',$composePath,'-f',$overridePath)

$previousMaterialRoot = $env:OPENVIDEO_MATERIAL_ROOT
$previousRuntimeRoot = $env:OPENVIDEO_RUNTIME_DATA_ROOT
$previousOllamaModelAlias = $env:OPENVIDEO_OLLAMA_MODEL_ALIAS
$modelAliasEntry = @(Get-Content -LiteralPath $runtime.ComposeEnvironmentPath -Encoding UTF8 | Where-Object { $_ -match '^OPENVIDEO_OLLAMA_MODEL_ALIAS=' })
if ($modelAliasEntry.Count -ne 1) { throw 'compose.env must contain exactly one OPENVIDEO_OLLAMA_MODEL_ALIAS.' }
$env:OPENVIDEO_MATERIAL_ROOT = $runtime.MaterialRoot
$env:OPENVIDEO_RUNTIME_DATA_ROOT = $runtime.RuntimeDataRoot
$env:OPENVIDEO_OLLAMA_MODEL_ALIAS = $modelAliasEntry[0].Substring('OPENVIDEO_OLLAMA_MODEL_ALIAS='.Length)
$auditLog = Join-Path $runtime.RuntimeDataRoot "logs/compose-$($Action.ToLowerInvariant())-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"

try {
    Start-Transcript -LiteralPath $auditLog | Out-Null
    switch ($Action) {
        'Config' { & docker @arguments config --format json }
        'Down' { & docker @arguments down --remove-orphans }
        'Up' {
            & docker @arguments up
        }
    }
    if ($LASTEXITCODE -ne 0) { throw "docker compose $Action failed with exit code $LASTEXITCODE" }
} finally {
    try { Stop-Transcript | Out-Null } catch {}
    $env:OPENVIDEO_MATERIAL_ROOT = $previousMaterialRoot
    $env:OPENVIDEO_RUNTIME_DATA_ROOT = $previousRuntimeRoot
    $env:OPENVIDEO_OLLAMA_MODEL_ALIAS = $previousOllamaModelAlias
}
