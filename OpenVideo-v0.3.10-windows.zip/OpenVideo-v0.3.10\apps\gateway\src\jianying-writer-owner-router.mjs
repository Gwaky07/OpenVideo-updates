const ID = /^[a-z][a-z0-9_-]{2,63}$/
const CAPABILITY = /^[a-z][a-z0-9_.-]{2,95}$/
/** @typedef {{id: string, priority: number, capabilities: ReadonlyArray<string>, writer: unknown, identity: Readonly<Record<string, unknown>> | null, providerCommit: string | null}} WriterCandidate */

/** @param {string} code @returns {never} */
const fail = (code) => {
  const error = /** @type {Error & {code: string}} */ (new Error(code))
  error.code = code
  throw error
}

/** @param {unknown} values @returns {ReadonlyArray<string>} */
const normalizeCapabilities = (values) => {
  if (!Array.isArray(values) || values.length === 0 || values.length > 64) fail('JY200_CAPABILITY_SET_INVALID')
  const capabilities = /** @type {unknown[]} */ (values).map((value) => {
    if (typeof value !== 'string' || !CAPABILITY.test(value)) fail('JY200_CAPABILITY_SET_INVALID')
    return value
  })
  if (new Set(capabilities).size !== capabilities.length) fail('JY200_CAPABILITY_SET_INVALID')
  return Object.freeze([...capabilities].sort())
}

/**
 * Select one owner for the entire export before any runtime registration or
 * draft mutation. Providers that cannot cover the complete set are skipped;
 * their partial capabilities are never combined.
 * @param {{requiredCapabilities: unknown, providers: unknown, admissionRegistry: unknown, preferredProvider?: unknown}} input
 */
export const selectJianyingWriterOwner = async ({ requiredCapabilities, providers, admissionRegistry, preferredProvider = null }) => {
  const required = normalizeCapabilities(requiredCapabilities)
  if (!admissionRegistry || typeof admissionRegistry !== 'object' ||
      typeof /** @type {Record<string, unknown>} */ (admissionRegistry).describe !== 'function') fail('JY200_ADMISSION_REGISTRY_REQUIRED')
  const registry = /** @type {{describe: (handle: unknown) => Promise<Record<string, any> | null>|Record<string, any>|null}} */ (admissionRegistry)
  if (!Array.isArray(providers) || providers.length === 0 || providers.length > 16) fail('JY200_PROVIDER_SET_INVALID')
  const normalized = await Promise.all(/** @type {unknown[]} */ (providers).map(async (candidate) => {
    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) fail('JY200_PROVIDER_SET_INVALID')
    const provider = /** @type {Record<string, unknown>} */ (candidate)
    if (typeof provider.id !== 'string' || !ID.test(provider.id)) fail('JY200_PROVIDER_SET_INVALID')
    if (typeof provider.priority !== 'number' || !Number.isSafeInteger(provider.priority)) fail('JY200_PROVIDER_SET_INVALID')
    const trusted = await registry.describe(provider.admissionHandle)
    if (!trusted || trusted.provider !== provider.id) {
      return /** @type {WriterCandidate} */ ({ id: provider.id, priority: provider.priority, capabilities: [], writer: provider.writer, identity: null, providerCommit: null })
    }
    let identity
    try { identity = Object.freeze(JSON.parse(JSON.stringify(trusted.identity))) } catch { fail('JY200_PROVIDER_IDENTITY_REQUIRED') }
    return /** @type {WriterCandidate} */ ({
      id: provider.id,
      priority: provider.priority,
      capabilities: normalizeCapabilities(trusted.capabilities),
      writer: provider.writer,
      identity,
      providerCommit: typeof trusted.commit === 'string' ? trusted.commit : null,
    })
  }))
  if (new Set(normalized.map((provider) => provider.id)).size !== normalized.length) fail('JY200_PROVIDER_SET_INVALID')
  if (preferredProvider !== null && (typeof preferredProvider !== 'string' || !ID.test(preferredProvider))) fail('JY200_PROVIDER_PREFERENCE_INVALID')
  const eligible = normalized.filter((provider) => required.every((capability) => provider.capabilities.includes(capability)))
  eligible.sort((left, right) => {
    if (left.id === preferredProvider) return -1
    if (right.id === preferredProvider) return 1
    return right.priority - left.priority || left.id.localeCompare(right.id)
  })
  const owner = eligible[0]
  if (!owner) fail('JY200_NO_COMPLETE_WRITER_OWNER')
  if (!owner.writer || typeof owner.writer !== 'object') fail('JY200_WRITER_OWNER_INVALID')
  return Object.freeze({
    ownerId: owner.id,
    requiredCapabilities: required,
    writer: owner.writer,
    ownerIdentity: owner.identity,
    providerCommit: owner.providerCommit,
  })
}
