import { createHash } from 'node:crypto'

const resourcePattern = /^[A-Za-z0-9_-]{4,80}$/u
const tokenPattern = /^ovjanim_v1_[a-f0-9]{64}$/u
const admittedProfileId = 'jianying-11-1-provisional'
const admittedVersion = '11.1.0.14287'
/** @param {unknown} body */
const fingerprint = (body) => createHash('sha256').update(JSON.stringify(body)).digest('hex')

/** @param {unknown} value @param {readonly string[]} keys */
const hasExactKeys = (value, keys) => Boolean(value) && typeof value === 'object' &&
  Object.keys(/** @type {Record<string, unknown>} */ (value)).sort().join('\0') === [...keys].sort().join('\0')

/** Parse the owner-private JY-044 catalog without exposing its resource IDs. */
/** @param {unknown} value */
export const parseJianyingVideoAnimationCatalog = (value) => {
  /** @type {any} */ const candidate = value
  if (!hasExactKeys(candidate, ['schema_version', 'kind', 'catalog_version', 'entries', 'catalog_fingerprint']) ||
    candidate.schema_version !== 1 || candidate.kind !== 'jy044_animation_catalog' ||
    candidate.catalog_version !== '1.0.0' || !Array.isArray(candidate.entries) || candidate.entries.length !== 1 ||
    typeof candidate.catalog_fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(candidate.catalog_fingerprint)) return null
  const [entry] = candidate.entries
  if (!hasExactKeys(entry, ['capability_id', 'animation_token', 'display_name', 'resource_id', 'duration_us']) ||
    entry.capability_id !== 'animation.video.named' || typeof entry.animation_token !== 'string' ||
    !tokenPattern.test(entry.animation_token) || typeof entry.display_name !== 'string' || entry.display_name.length === 0 ||
    typeof entry.resource_id !== 'string' || !resourcePattern.test(entry.resource_id) ||
    entry.animation_token !== `ovjanim_v1_${createHash('sha256').update(entry.resource_id).digest('hex')}` ||
    !Number.isSafeInteger(entry.duration_us) || entry.duration_us <= 0 || entry.duration_us > 10_000_000) return null
  const body = { schema_version: candidate.schema_version, kind: candidate.kind, catalog_version: candidate.catalog_version, entries: candidate.entries }
  if (candidate.catalog_fingerprint !== fingerprint(body)) return null
  return Object.freeze({ fingerprint: candidate.catalog_fingerprint, entries: Object.freeze([Object.freeze({ animationToken: entry.animation_token, resourceId: entry.resource_id, durationUs: entry.duration_us })]) })
}

/** @param {unknown} value @param {{fingerprint: string, entries: readonly {durationUs: number}[]}} catalog @param {{profileId: string, version: string}} desktop */
export const parseJianyingVideoAnimationEvidence = (value, catalog, desktop) => {
  /** @type {any} */ const candidate = value
  const keys = ['schema_version', 'manual_evidence_verified', 'manual_attestation', 'profile_id', 'app_version', 'catalog_fingerprint', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'matching_animation_count', 'attached', 'persisted_duration_us', 'temporary_media_cleaned']
  const [entry] = catalog.entries
  if (!hasExactKeys(candidate, keys) || candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.manual_attestation !== 'opened-edited-saved-reopened' || desktop.profileId !== admittedProfileId || desktop.version !== admittedVersion ||
    candidate.profile_id !== admittedProfileId || candidate.app_version !== admittedVersion || candidate.catalog_fingerprint !== catalog.fingerprint ||
    candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true ||
    candidate.matching_animation_count !== 1 || candidate.attached !== true || candidate.persisted_duration_us !== entry?.durationUs ||
    candidate.temporary_media_cleaned !== true) return null
  return Object.freeze({ ...candidate })
}

/** @param {{entries: readonly {animationToken: string, resourceId: string, durationUs: number}[]} | null} catalog @param {unknown} token */
export const resolveJianyingVideoAnimationToken = (catalog, token) => {
  if (typeof token !== 'string' || !tokenPattern.test(token)) return null
  const entry = catalog?.entries?.find((candidate) => candidate.animationToken === token)
  return entry ? { resourceId: entry.resourceId, durationUs: entry.durationUs } : null
}

/** Side-effect-free production admission gate for the private JY-044 artifacts. */
/** @param {{dataRoot: string, desktop: {profileId: string, version: string}, readFile: (...args: any[]) => Promise<any>, joinPath: (...parts: string[]) => string}} input */
export const loadJianyingVideoAnimationCapability = async ({ dataRoot, desktop, readFile, joinPath }) => {
  try {
    const catalog = parseJianyingVideoAnimationCatalog(JSON.parse(await readFile(joinPath(dataRoot, 'catalogs', 'jy044-animation-catalog.json'), 'utf8')))
    const evidence = JSON.parse(await readFile(joinPath(dataRoot, 'evidence', 'jy044-animation', 'post-save.json'), 'utf8'))
    return catalog && parseJianyingVideoAnimationEvidence(evidence, catalog, desktop) ? catalog : null
  } catch {
    return null
  }
}
