import { createHash } from 'node:crypto'
import { existsSync, realpathSync } from 'node:fs'
import { readdir, readFile } from 'node:fs/promises'
import { dirname, extname, isAbsolute, join, relative, resolve, delimiter as pathDelimiter } from 'node:path'

/** @param {string} materialId @param {number} startUs @param {number} durationUs */
const textSlotId = (materialId, startUs, durationUs) =>
  `txt-${createHash('sha256').update(`${materialId}\u0000${startUs}\u0000${durationUs}`).digest('hex').slice(0, 24)}`

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const timerange = (value) =>
  record(value) &&
  (value.start === undefined ||
    (Number.isSafeInteger(value.start) && /** @type {number} */ (value.start) >= 0)) &&
  Number.isSafeInteger(value.duration) &&
  value.duration > 0

/** @param {Record<string, any>} value */
const timerangeStart = (value) =>
  Number.isSafeInteger(value.start) && value.start >= 0 ? value.start : 0

const audioExtensions = new Set(['.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg'])

/**
 * Allow auto-ingest for files already present under Jianying/CapCut User Data Cache.
 * @param {string} absolutePath
 */
/**
 * Trusted Jianying/CapCut cache roots (LOCALAPPDATA) plus optional test/override roots.
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {string[]}
 */
export const resolveJianyingCacheRoots = (env = process.env) => {
  /** @type {string[]} */
  const roots = []
  const localAppData = typeof env.LOCALAPPDATA === 'string' ? env.LOCALAPPDATA.trim() : ''
  if (localAppData && isAbsolute(localAppData)) {
    roots.push(join(localAppData, 'JianyingPro', 'User Data', 'Cache'))
    roots.push(join(localAppData, 'CapCut', 'User Data', 'Cache'))
    roots.push(join(localAppData, 'CapCut Draft', 'User Data', 'Cache'))
  }
  const override = typeof env.OPENVIDEO_JY_CACHE_ROOTS === 'string'
    ? env.OPENVIDEO_JY_CACHE_ROOTS
    : ''
  for (const part of override.split(pathDelimiter)) {
    const trimmed = part.trim()
    if (trimmed && isAbsolute(trimmed)) roots.push(resolve(trimmed))
  }
  return roots
}

/**
 * Jianying/CapCut draft project trees are a second trusted audio source.
 * Uploaded templates often keep SFX/BGM paths pointing at the original
 * draft folder instead of Cache or the blueprint copy.
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {string[]}
 */
export const resolveJianyingDraftAudioRoots = (env = process.env) => {
  /** @type {string[]} */
  const roots = []
  const localAppData = typeof env.LOCALAPPDATA === 'string' ? env.LOCALAPPDATA.trim() : ''
  if (localAppData && isAbsolute(localAppData)) {
    for (const product of ['JianyingPro', 'CapCut', 'CapCut Draft']) {
      roots.push(join(localAppData, product, 'User Data', 'Projects', 'com.lveditor.draft'))
    }
  }
  const override = typeof env.OPENVIDEO_JY_DRAFT_ROOTS === 'string'
    ? env.OPENVIDEO_JY_DRAFT_ROOTS
    : ''
  for (const part of override.split(pathDelimiter)) {
    const trimmed = part.trim()
    if (trimmed && isAbsolute(trimmed)) roots.push(resolve(trimmed))
  }
  return roots
}

/**
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {string[]}
 */
export const resolveJianyingTrustedAudioRoots = (env = process.env) => [
  ...resolveJianyingCacheRoots(env),
  ...resolveJianyingDraftAudioRoots(env),
]

/**
 * Allow auto-ingest only under trusted Jianying/CapCut cache roots.
 * @param {string} absolutePath
 * @param {string[]} [cacheRoots]
 */
/**
 * @param {string} absolutePath
 * @param {string[]} [trustedRoots]
 */
export const isJianyingTrustedAudioPath = (absolutePath, trustedRoots = resolveJianyingTrustedAudioRoots()) => {
  if (typeof absolutePath !== 'string' || !absolutePath || !isAbsolute(absolutePath)) return false
  if (!existsSync(absolutePath)) return false
  let candidate
  try {
    candidate = realpathSync.native(absolutePath)
  } catch {
    return false
  }
  for (const root of trustedRoots) {
    if (typeof root !== 'string' || !root || !existsSync(root)) continue
    try {
      const rootReal = realpathSync.native(root)
      const fragment = relative(rootReal, candidate)
      if (fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))) return true
    } catch {
      // ignore unreadable roots
    }
  }
  return false
}

/**
 * Allow auto-ingest only under trusted Jianying/CapCut cache roots.
 * @param {string} absolutePath
 * @param {string[]} [cacheRoots]
 */
export const isJianyingCacheAudioPath = (absolutePath, cacheRoots = resolveJianyingCacheRoots()) =>
  isJianyingTrustedAudioPath(absolutePath, cacheRoots)

/** @typedef {{type?: unknown, category_name?: unknown}} BlueprintMaterial */

/**
 * @param {string} trackName
 * @param {string} materialName
 * @param {BlueprintMaterial} [material]
 */
const inferAudioRole = (trackName, materialName, material = {}) => {
  const type = typeof material.type === 'string' ? material.type.toLowerCase() : ''
  const category = typeof material.category_name === 'string'
    ? material.category_name.toLowerCase()
    : ''
  if (type === 'music' || /\u97f3\u4e50\u5e93|\u66f2\u5e93/.test(category)) return 'bgm'
  if (type === 'extract_music') {
    const value = `${trackName}\u0000${materialName}`.toLowerCase()
    if (/(?:bgm|\u80cc\u666f|\u97f3\u4e50|music)/u.test(value)) return 'bgm'
    return 'sfx'
  }
  const value = `${trackName}\u0000${materialName}`.toLowerCase()
  if (/(?:bgm|\u80cc\u666f|\u97f3\u4e50|music)/u.test(value)) return 'bgm'
  if (/(?:\u97f3\u6548|sfx|effect|foley|\u53ee|\u63d0\u793a\u97f3)/u.test(value)) return 'sfx'
  return 'voiceover'
}

/** @param {Record<string, any>} entry */
const isAutoIngestibleAudio = (entry) =>
  entry.sourceKind === 'local' &&
  typeof entry.absolutePath === 'string' &&
  (entry.inDraftTree === true || entry.inJianyingCache === true)

/**
 * Trusted server-only extraction from an immutable blueprint draft folder.
 * Public Recipe never receives absolute paths or raw Jianying resource IDs.
 * @param {{ draftFolder: string, env?: NodeJS.ProcessEnv }} input
 */
export const extractBlueprintAssets = async ({ draftFolder, env = process.env }) => {
  if (typeof draftFolder !== 'string' || !isAbsolute(draftFolder)) {
    throw new Error('BLUEPRINT_ASSETS_FOLDER_INVALID')
  }
  const root = resolve(draftFolder)
  const contentPath = resolve(root, 'draft_content.json')
  if (!existsSync(contentPath)) throw new Error('BLUEPRINT_ASSETS_DRAFT_MISSING')
  const content = JSON.parse(await readFile(contentPath, 'utf8'))
  if (!record(content) || !Array.isArray(content.tracks)) {
    throw new Error('BLUEPRINT_ASSETS_STRUCTURE_INVALID')
  }

  const materials = record(content.materials) ? content.materials : {}
  /** @type {Map<string, Record<string, any>>} */
  const byId = new Map()
  for (const bucket of ['audios', 'effects', 'video_effects', 'stickers', 'flowers', 'videos', 'material_animations']) {
    const entries = Array.isArray(materials[bucket]) ? materials[bucket] : []
    for (const entry of entries) {
      if (record(entry) && typeof entry.id === 'string') byId.set(entry.id, entry)
    }
  }

  /** @type {Array<Record<string, any>>} */
  const audioCandidates = []
  /** @type {Array<Record<string, any>>} */
  const packagingPrivate = []
  /**
   * Animation materials attached to authored text. These are deliberately
   * kept outside packagingPrivate: nested sticker_animation resource IDs do
   * not prove a current Flower/Bubble writer binding and must stay in the
   * blueprint overlay path.
   * @type {Array<Record<string, any>>}
   */
  const templateTextAnimations = []

  for (const track of content.tracks) {
    if (!record(track) || !Array.isArray(track.segments)) continue
    const trackName = typeof track.name === 'string' ? track.name : ''
    const trackType = typeof track.type === 'string' ? track.type : ''

    for (const segment of track.segments) {
      if (!record(segment) || !timerange(segment.target_timerange)) continue
      const materialId = typeof segment.material_id === 'string' ? segment.material_id : null
      const material = materialId ? byId.get(materialId) ?? {} : {}

      if (trackType === 'audio') {
        const materialName = typeof material.name === 'string' ? material.name : ''
        const role = inferAudioRole(trackName, materialName, material)
        const sourcePlatform = Number.isFinite(material.source_platform)
          ? Number(material.source_platform)
          : null
        const rawPath = typeof material.path === 'string' ? material.path : null
        let absolutePath = null
        let inDraftTree = false
        let inJianyingCache = false
        if (rawPath && isAbsolute(rawPath) && existsSync(rawPath)) {
          try {
            const candidate = realpathSync.native(rawPath)
            const extension = extname(candidate).toLowerCase()
            if (audioExtensions.has(extension)) {
              absolutePath = candidate
              const rootReal = existsSync(root) ? realpathSync.native(root) : root
              const fragment = relative(rootReal, candidate)
              inDraftTree = fragment === '' ||
                (!fragment.startsWith('..') && !isAbsolute(fragment))
              inJianyingCache = isJianyingTrustedAudioPath(
                candidate,
                resolveJianyingTrustedAudioRoots(env),
              )
            }
          } catch {
            absolutePath = null
            inDraftTree = false
            inJianyingCache = false
          }
        }
        const libraryLike = sourcePlatform !== null && sourcePlatform !== 0
        audioCandidates.push({
          role,
          startUs: timerangeStart(segment.target_timerange),
          durationUs: segment.target_timerange.duration,
          volume: typeof segment.volume === 'number' && Number.isFinite(segment.volume)
            ? Math.max(0, Math.min(1, segment.volume))
            : 1,
          absolutePath,
          inDraftTree,
          inJianyingCache,
          sourceKind: absolutePath && (inDraftTree || inJianyingCache || !libraryLike)
            ? 'local'
            : 'library',
          musicId: typeof material.music_id === 'string' ? material.music_id : null,
        })
      }

      if (trackType === 'sticker') {
        const resourceId = typeof material.resource_id === 'string'
          ? material.resource_id
          : typeof material.sticker_id === 'string'
            ? material.sticker_id
            : null
        if (resourceId && /^[A-Za-z0-9_-]{4,80}$/u.test(resourceId)) {
          packagingPrivate.push({
            kind: 'sticker',
            startUs: timerangeStart(segment.target_timerange),
            durationUs: segment.target_timerange.duration,
            resourceId,
          })
        }
      }

      // Text effects/shapes are stored as extra materials on text segments.
      // Keep their raw IDs private; the recipe receives an opaque token later.
      if (trackType === 'text' && Array.isArray(segment.extra_material_refs)) {
        for (const ref of segment.extra_material_refs) {
          if (typeof ref !== 'string') continue
          const linked = byId.get(ref)
          if (!linked) continue
          const type = typeof linked.type === 'string' ? linked.type : ''
          if (type === 'sticker_animation') {
            const animations = Array.isArray(linked.animations) ? linked.animations : []
            const authored = animations.find((animation) =>
              record(animation) &&
              typeof animation.resource_id === 'string' &&
              /^[A-Za-z0-9_-]{4,80}$/u.test(animation.resource_id),
            )
            templateTextAnimations.push({
              ...(materialId ? { slotId: textSlotId(materialId, timerangeStart(segment.target_timerange), segment.target_timerange.duration) } : {}),
              startUs: timerangeStart(segment.target_timerange),
              durationUs: segment.target_timerange.duration,
              animationMaterialId: ref,
              animationType: type,
              animationCount: animations.length,
              ...(authored ? {
                animationId: typeof authored.id === 'string' ? authored.id : null,
                animationResourceId: authored.resource_id,
                animationName: typeof authored.name === 'string' ? authored.name : null,
                animationDurationUs: Number.isSafeInteger(authored.duration) && authored.duration > 0
                  ? authored.duration
                  : null,
              } : {}),
            })
            continue
          }
          const resourceId = typeof linked.resource_id === 'string'
            ? linked.resource_id
            : typeof linked.effect_id === 'string' ? linked.effect_id : null
          if (!resourceId || !/^[A-Za-z0-9_-]{4,80}$/u.test(resourceId)) continue
          if (type === 'text_effect') {
            packagingPrivate.push({
              kind: 'flower',
              ...(materialId ? { slotId: textSlotId(materialId, timerangeStart(segment.target_timerange), segment.target_timerange.duration) } : {}),
              startUs: timerangeStart(segment.target_timerange),
              durationUs: segment.target_timerange.duration,
              resourceId,
              effectId: typeof linked.effect_id === 'string' ? linked.effect_id : resourceId,
            })
          } else if (type === 'text_shape') {
            const effectId = typeof linked.effect_id === 'string' ? linked.effect_id : resourceId
            packagingPrivate.push({
              kind: 'bubble',
              ...(materialId ? { slotId: textSlotId(materialId, timerangeStart(segment.target_timerange), segment.target_timerange.duration) } : {}),
              startUs: timerangeStart(segment.target_timerange),
              durationUs: segment.target_timerange.duration,
              resourceId,
              effectId,
            })
          }
        }
      }

      if (trackType === 'effect') {
        const resourceId = typeof material.resource_id === 'string'
          ? material.resource_id
          : typeof material.effect_id === 'string'
            ? material.effect_id
            : null
        if (resourceId && /^[A-Za-z0-9_-]{4,80}$/u.test(resourceId)) {
          packagingPrivate.push({
            kind: 'effect',
            startUs: timerangeStart(segment.target_timerange),
            durationUs: segment.target_timerange.duration,
            resourceId,
            ...(typeof material.effect_id === 'string'
              ? { effectId: material.effect_id }
              : {}),
          })
        }
      }

      // Video-attached scene effects referenced via extra_material_refs.
      if (trackType === 'video' && Array.isArray(segment.extra_material_refs)) {
        for (const ref of segment.extra_material_refs) {
          if (typeof ref !== 'string') continue
          const linked = byId.get(ref)
          if (!linked) continue
          const resourceId = typeof linked.resource_id === 'string'
            ? linked.resource_id
            : typeof linked.effect_id === 'string'
              ? linked.effect_id
              : null
          const isEffect = Array.isArray(materials.effects) &&
            materials.effects.some((entry) => record(entry) && entry.id === ref)
          if (isEffect && resourceId && /^[A-Za-z0-9_-]{4,80}$/u.test(resourceId)) {
            packagingPrivate.push({
              kind: 'effect',
              startUs: timerangeStart(segment.target_timerange),
              durationUs: segment.target_timerange.duration,
              resourceId,
              ...(typeof linked.effect_id === 'string'
                ? { effectId: linked.effect_id }
                : {}),
            })
          }
        }
      }
    }
  }

  // Some Jianying drafts preserve user-provided SFX alongside the draft but
  // omit their paths from the audio materials.  The files are still part of
  // the authorized immutable draft tree, so pair them deterministically with
  // otherwise-unresolved SFX cue windows instead of forcing the user to
  // select the same files again.
  const unresolvedSfx = audioCandidates
    // A stale external path is not trusted either. Prefer the matching file
    // explicitly carried inside the authorized draft tree when it exists.
    .filter((entry) => entry.role === 'sfx' && !isAutoIngestibleAudio(entry))
    .sort((left, right) => left.startUs - right.startUs || left.durationUs - right.durationUs)
  if (unresolvedSfx.length > 0) {
    try {
      const fallbackRoots = [join(root, 'auto_cut_sfx'), join(root, 'Resources', 'auto_cut_sfx')]
      const fallbackRoot = fallbackRoots.find((candidate) => existsSync(candidate))
      if (!fallbackRoot) throw new Error('BLUEPRINT_SFX_FALLBACK_MISSING')
      const files = (await readdir(fallbackRoot, { withFileTypes: true }))
        .filter((entry) => entry.isFile() && audioExtensions.has(extname(entry.name).toLowerCase()))
        .map((entry) => entry.name)
        .sort((left, right) => left.localeCompare(right, 'en'))
      const fileSet = new Set(files.map((fileName) => fileName.toLocaleLowerCase()))
      for (const [index, cue] of unresolvedSfx.entries()) {
        // Prefer the authored basename when the source path points at a
        // sibling/older draft. This preserves the exact template sound while
        // moving the trusted path into the immutable blueprint copy.
        const authoredName = typeof cue.absolutePath === 'string'
          ? cue.absolutePath.split(/[\\/]/u).at(-1)
          : null
        const fileName = authoredName && fileSet.has(authoredName.toLocaleLowerCase())
          ? files.find((candidateName) => candidateName.toLocaleLowerCase() === authoredName.toLocaleLowerCase())
          : files[index % files.length]
        if (!fileName) continue
        const candidate = join(fallbackRoot, fileName)
        if (!existsSync(candidate)) continue
        cue.absolutePath = realpathSync.native(candidate)
        cue.inDraftTree = true
        cue.inJianyingCache = false
        cue.sourceKind = 'local'
      }
    } catch {
      // The conventional sibling folder is optional; unresolved SFX remain
      // fail-closed and retain the explicit one-time binding path.
    }
  }

  return {
    audioCandidates,
    packagingPrivate,
    templateTextAnimations,
    fingerprintSeed: createHash('sha256')
      .update(JSON.stringify({
        audio: audioCandidates.map((entry) => ({
          role: entry.role,
          startUs: entry.startUs,
          durationUs: entry.durationUs,
          sourceKind: entry.sourceKind,
          inDraftTree: entry.inDraftTree,
          inJianyingCache: entry.inJianyingCache,
        })),
        packaging: packagingPrivate,
        templateTextAnimations,
      }))
      .digest('hex'),
  }
}

/**
 * Prefer draft-tree or Jianying Cache local audio. Arbitrary outside paths stay blocked.
 * @param {Array<Record<string, any>>} audioCandidates
 * @param {'bgm' | 'sfx'} role
 */
export const pickIngestibleAudio = (audioCandidates, role) => {
  const matches = audioCandidates.filter((entry) => entry.role === role)
  return matches.find((entry) => isAutoIngestibleAudio(entry)) || null
}

/**
 * All auto-ingestible local audio candidates for a role (multi-SFX safe).
 * @param {Array<Record<string, any>>} audioCandidates
 * @param {'bgm' | 'sfx'} role
 */
export const listIngestibleAudio = (audioCandidates, role) =>
  audioCandidates.filter((entry) => entry.role === role && isAutoIngestibleAudio(entry))
