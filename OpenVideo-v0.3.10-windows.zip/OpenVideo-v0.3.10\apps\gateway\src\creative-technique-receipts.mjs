import { randomUUID } from 'node:crypto'
import { lstat, mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises'
import { isAbsolute, join } from 'node:path'

import {
  CREATIVE_TECHNIQUE_STABLE_RUN_COUNT,
  isCreativeTechniqueEvaluation,
} from './creative-technique-benchmark.mjs'

const receiptNamePattern = /^run-v1-[0-9TZ.-]+\.json$/u

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {Record<string, any>} value @param {readonly string[]} keys */
const exactKeys = (value, keys) => Object.keys(value).length === keys.length &&
  keys.every((key) => Object.hasOwn(value, key))

/** @param {unknown} value @returns {value is Record<string, any>} */
export const isCreativeTechniqueReceipt = (value) => {
  if (!isRecord(value) || !exactKeys(value, [
    'schema_version', 'created_at', 'evaluation', 'rollout_window',
  ]) || value.schema_version !== 1 || typeof value.created_at !== 'string' ||
      !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(value.created_at) ||
      !isCreativeTechniqueEvaluation(value.evaluation) || !isRecord(value.rollout_window) ||
      !exactKeys(value.rollout_window, ['verdict', 'reason', 'qualifying_run_count'])) return false
  const window = value.rollout_window
  return window.verdict === 'ELIGIBLE'
    ? window.reason === 'stable_window_passed' &&
      window.qualifying_run_count === CREATIVE_TECHNIQUE_STABLE_RUN_COUNT
    : window.verdict === 'HOLD' &&
      ['stable_window_incomplete', 'run_failed', 'identity_drift', 'receipt_invalid'].includes(window.reason) &&
      window.qualifying_run_count === 0
}

/** @param {unknown} runs @param {{invalidReceiptCount?: number}} [options] */
export const evaluateCreativeTechniqueRolloutWindow = (runs, { invalidReceiptCount = 0 } = {}) => {
  if (!Number.isSafeInteger(invalidReceiptCount) || invalidReceiptCount < 0) {
    throw new Error('CREATIVE_TECHNIQUE_RECEIPT_HISTORY_INVALID')
  }
  if (invalidReceiptCount > 0) return Object.freeze({ verdict: 'HOLD', reason: 'receipt_invalid', qualifying_run_count: 0 })
  if (!Array.isArray(runs) || runs.length < CREATIVE_TECHNIQUE_STABLE_RUN_COUNT) {
    return Object.freeze({ verdict: 'HOLD', reason: 'stable_window_incomplete', qualifying_run_count: 0 })
  }
  const window = runs.slice(-CREATIVE_TECHNIQUE_STABLE_RUN_COUNT)
  if (window.some((run) => !isCreativeTechniqueEvaluation(run))) {
    return Object.freeze({ verdict: 'HOLD', reason: 'receipt_invalid', qualifying_run_count: 0 })
  }
  const first = window[0]
  const identityMatches = window.every((run) =>
    run.benchmark_id === first.benchmark_id &&
    run.benchmark_fingerprint === first.benchmark_fingerprint &&
    run.knowledge_fingerprint === first.knowledge_fingerprint &&
    run.capability_registry_fingerprint === first.capability_registry_fingerprint &&
    run.adapter_revision === first.adapter_revision)
  const passed = identityMatches && window.every((run) => run.verdict === 'PASS')
  return Object.freeze({
    verdict: passed ? 'ELIGIBLE' : 'HOLD',
    reason: passed ? 'stable_window_passed' : identityMatches ? 'run_failed' : 'identity_drift',
    qualifying_run_count: passed ? CREATIVE_TECHNIQUE_STABLE_RUN_COUNT : 0,
  })
}

/** @param {string} evidenceRoot */
export const loadCreativeTechniqueReceiptHistory = async (evidenceRoot) => {
  if (!isAbsolute(evidenceRoot)) throw new Error('CREATIVE_TECHNIQUE_EVIDENCE_ROOT_INVALID')
  let entries
  try { entries = await readdir(evidenceRoot) } catch (error) {
    if (/** @type {NodeJS.ErrnoException} */ (error)?.code === 'ENOENT') {
      return Object.freeze({ runs: Object.freeze([]), invalidReceiptCount: 0 })
    }
    throw error
  }
  const runs = []
  let invalidReceiptCount = 0
  for (const name of entries.filter((entry) => receiptNamePattern.test(entry)).sort()) {
    try {
      const path = join(evidenceRoot, name)
      const metadata = await lstat(path)
      if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size > 256 * 1024) throw new Error('unsafe')
      const receipt = JSON.parse(await readFile(path, 'utf8'))
      if (!isCreativeTechniqueReceipt(receipt)) throw new Error('invalid')
      runs.push(receipt.evaluation)
    } catch {
      invalidReceiptCount += 1
    }
  }
  return Object.freeze({ runs: Object.freeze(runs), invalidReceiptCount })
}

/** @param {string} evidenceRoot @param {unknown} receipt */
export const publishCreativeTechniqueReceipt = async (evidenceRoot, receipt) => {
  if (!isAbsolute(evidenceRoot) || !isCreativeTechniqueReceipt(receipt)) {
    throw new Error('CREATIVE_TECHNIQUE_RECEIPT_INVALID')
  }
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  const fileName = `run-v1-${receipt.created_at.replace(/:/gu, '-')}.json`
  const output = join(evidenceRoot, fileName)
  const temporary = join(evidenceRoot, `.${fileName}.${randomUUID()}.tmp`)
  try {
    await writeFile(temporary, `${JSON.stringify(receipt)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await rename(temporary, output)
  } finally {
    await rm(temporary, { force: true }).catch(() => {})
  }
  return output
}
