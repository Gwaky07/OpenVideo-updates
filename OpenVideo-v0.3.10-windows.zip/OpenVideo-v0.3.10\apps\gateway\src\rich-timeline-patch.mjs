import { randomUUID } from 'node:crypto'

import { assertTimelinePatchOperations } from './editor-agent-contracts.mjs'
import {
  assertRichTimeline,
  computeCapabilityRequirements,
  sealRichTimeline,
} from './rich-timeline-contracts.mjs'
import { PackagingTextLayoutError, solvePackagingTextLayouts } from './packaging-text-layout.mjs'

export class RichTimelinePatchError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'RichTimelinePatchError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  throw new RichTimelinePatchError(code, status)
}

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {Record<string, any>} track */
const isInheritedPackagingTrack = (track) =>
  track.kind === 'title' ||
  track.kind === 'effect' ||
  (track.kind === 'audio' && track.role === 'sfx')

/**
 * Apply whitelist patch operations to a draft timeline and return a new sealed draft revision.
 * Does not persist; caller performs CAS via rich-timeline-repository.
 *
 * @param {{
 *   base: unknown,
 *   operations: unknown,
 *   instructionFingerprint?: string | null,
 *   jobOperationsUsed?: number,
 *   candidateReferences?: Record<string, {assetId: string, sceneId: string, authorizationId?: string}>,
 * }} input
 */
export const applyRichTimelinePatch = (input) => {
  const base = assertRichTimeline(input.base)
  if (base.status !== 'draft') fail('EDITOR_PATCH_BASE_NOT_DRAFT')
  const operations = assertTimelinePatchOperations(input.operations, {
    jobOperationsUsed: input.jobOperationsUsed,
  })

  const next = clone(base)
  next.revision = base.revision + 1
  next.parentRevision = base.revision
  next.parentRevisionFingerprint = base.revisionFingerprint
  next.status = 'draft'
  next.createdAt = new Date().toISOString()
  next.source = {
    ...next.source,
    kind: 'agent',
    instructionFingerprint: input.instructionFingerprint ?? next.source.instructionFingerprint,
  }
  delete next.contentFingerprint
  delete next.revisionFingerprint

  /** @type {Map<string, {track: any, index: number}>} */
  const segmentIndex = new Map()
  const rebuildIndex = () => {
    segmentIndex.clear()
    for (const track of next.tracks) {
      track.segments.forEach((/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => {
        segmentIndex.set(segment.segmentId, { track, index })
      })
    }
  }
  rebuildIndex()
  let titleTrackMutated = false

  for (const operation of operations) {
    if (operation.op === 'replace_candidate') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || located.track.kind !== 'video') fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      const segment = /** @type {Record<string, any>} */ (located.track.segments[located.index])
      const sourceRange = /** @type {{startUs: number, durationUs: number}} */ (operation.sourceRange)
      const candidateReference = input.candidateReferences?.[operation.candidateId]
      if (
        !candidateReference ||
        typeof candidateReference.assetId !== 'string' ||
        typeof candidateReference.sceneId !== 'string'
      ) {
        fail('EDITOR_PATCH_CANDIDATE_REFERENCE_REQUIRED', 403)
      }
      segment.asset = {
        ...segment.asset,
        assetId: candidateReference.assetId,
        sceneId: candidateReference.sceneId,
        ...(typeof candidateReference.authorizationId === 'string' &&
          candidateReference.authorizationId.length > 0
          ? { authorizationId: candidateReference.authorizationId }
          : {}),
      }
      segment.sourceRange = clone(sourceRange)
      const speed = segment.speed ?? { numerator: 1, denominator: 1 }
      const targetDuration =
        (sourceRange.durationUs * speed.denominator) / speed.numerator
      if (!Number.isInteger(targetDuration) || targetDuration < 1) {
        fail('EDITOR_PATCH_TARGET_DURATION_INVALID')
      }
      segment.targetRange = {
        startUs: segment.targetRange.startUs,
        durationUs: targetDuration,
      }
      segment.audit = {
        ...segment.audit,
        origin: 'agent',
        candidateId: operation.candidateId,
        instructionFingerprint: input.instructionFingerprint ?? segment.audit.instructionFingerprint,
      }
    } else if (operation.op === 'trim_source') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || located.track.kind !== 'video') fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      const segment = /** @type {Record<string, any>} */ (located.track.segments[located.index])
      const sourceRange = /** @type {{startUs: number, durationUs: number}} */ (operation.sourceRange)
      const trustedSourceRange = /** @type {{startUs: number, durationUs: number}} */ (
        segment.sourceRange
      )
      const startOffsetUs = sourceRange.startUs - trustedSourceRange.startUs
      if (
        startOffsetUs < 0 ||
        startOffsetUs > trustedSourceRange.durationUs ||
        sourceRange.durationUs > trustedSourceRange.durationUs - startOffsetUs
      ) {
        fail('EDITOR_PATCH_SOURCE_RANGE_OUTSIDE_TRUSTED_RANGE')
      }
      segment.sourceRange = clone(sourceRange)
      const speed = segment.speed ?? { numerator: 1, denominator: 1 }
      const targetDuration =
        (sourceRange.durationUs * speed.denominator) / speed.numerator
      if (!Number.isInteger(targetDuration) || targetDuration < 1) {
        fail('EDITOR_PATCH_TARGET_DURATION_INVALID')
      }
      segment.targetRange = {
        startUs: segment.targetRange.startUs,
        durationUs: targetDuration,
      }
      segment.audit = {
        ...segment.audit,
        origin: 'agent',
        instructionFingerprint: input.instructionFingerprint ?? segment.audit.instructionFingerprint,
      }
    } else if (operation.op === 'remove_segment') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located) fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      if (located.track.kind === 'title') titleTrackMutated = true
      located.track.segments.splice(located.index, 1)
      rebuildIndex()
    } else if (operation.op === 'move_segment') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located) fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      if (located.track.kind === 'title') titleTrackMutated = true
      const moved = located.track.segments.splice(located.index, 1)[0]
      if (!moved) fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      rebuildIndex()
      if (operation.afterSegmentId === null) {
        located.track.segments.unshift(moved)
      } else {
        const after = segmentIndex.get(operation.afterSegmentId)
        if (!after || after.track.trackId !== located.track.trackId) {
          fail('EDITOR_PATCH_MOVE_TARGET_INVALID')
        }
        after.track.segments.splice(after.index + 1, 0, moved)
      }
      rebuildIndex()
    } else if (operation.op === 'set_transition') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || located.track.kind !== 'video' || located.track.role !== 'primary') {
        fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      }
      const segment = located.track.segments[located.index]
      segment.transitionOut = {
        capabilityId: operation.capabilityId ?? 'transition.none',
        durationUs: operation.durationUs ?? 0,
        parameters: {},
      }
    } else if (operation.op === 'insert_segment') {
      const track = next.tracks.find(
        (/** @type {Record<string, any>} */ entry) => entry.trackId === operation.trackId,
      )
      if (!track) fail('EDITOR_PATCH_TRACK_NOT_FOUND')
      const segment = /** @type {Record<string, any>} */ (clone(operation.segment))
      if (track.kind === 'title') titleTrackMutated = true
      if (!segment.segmentId) segment.segmentId = `seg-${randomUUID().slice(0, 8)}`
      if (operation.afterSegmentId === null) {
        track.segments.unshift(segment)
      } else {
        const after = segmentIndex.get(operation.afterSegmentId)
        if (!after || after.track.trackId !== track.trackId) fail('EDITOR_PATCH_INSERT_TARGET_INVALID')
        track.segments.splice(after.index + 1, 0, segment)
      }
      rebuildIndex()
    } else if (operation.op === 'set_text') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || !['caption', 'title'].includes(located.track.kind)) {
        fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      }
      const segment = located.track.segments[located.index]
      if (located.track.kind === 'title') titleTrackMutated = true
      segment.text = operation.text
      segment.styleToken = operation.styleToken
    } else if (operation.op === 'set_audio') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || located.track.kind !== 'audio') {
        fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      }
      const segment = located.track.segments[located.index]
      segment.source = {
        kind: 'generated',
        generatedAudioId: operation.audioToken,
      }
      segment.sourceRange = {
        startUs: 0,
        durationUs: segment.sourceRange.durationUs,
      }
      segment.volume = operation.volume
    } else if (operation.op === 'set_effect') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || located.track.kind !== 'video') {
        fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      }
      const segment = located.track.segments[located.index]
      if (operation.binding === null) {
        segment.effects = []
      } else {
        const binding = clone(operation.binding)
        segment.effects = [
          ...segment.effects.filter((/** @type {Record<string, any>} */ effect) =>
            effect.capabilityId !== binding.capabilityId),
          binding,
        ]
      }
    } else if (operation.op === 'set_keyframes') {
      const located = segmentIndex.get(operation.segmentId)
      if (!located || located.track.kind !== 'video') {
        fail('EDITOR_PATCH_SEGMENT_NOT_FOUND')
      }
      const segment = located.track.segments[located.index]
      /** @type {Array<Record<string, any>>} */
      const replacement = /** @type {Array<Record<string, any>>} */ (operation.keyframes)
        .map((keyframe) => ({
          ...clone(keyframe),
          capabilityId: operation.capabilityId,
        }))
        .sort((
          /** @type {Record<string, any>} */ left,
          /** @type {Record<string, any>} */ right,
        ) => left.offsetUs - right.offsetUs)
      segment.keyframes = [
        ...segment.keyframes.filter((/** @type {Record<string, any>} */ keyframe) =>
          keyframe.capabilityId !== operation.capabilityId),
        ...replacement,
      ]
    } else {
      fail('EDITOR_PATCH_OP_UNSUPPORTED')
    }
  }

  // Retarget primary video timeline duration from contiguous target ranges.
  const primary = next.tracks.find(
    (/** @type {Record<string, any>} */ track) => track.kind === 'video' && track.role === 'primary',
  )
  if (primary) {
    const basePrimaryById = new Map(
      base.tracks
        .filter((/** @type {Record<string, any>} */ track) => track.kind === 'video' && track.role === 'primary')
        .flatMap((/** @type {Record<string, any>} */ track) => track.segments)
        .map((/** @type {Record<string, any>} */ segment) => [segment.segmentId, segment]),
    )
    const basePrimaryByRange = new Map(
      [...basePrimaryById.values()].map((/** @type {Record<string, any>} */ segment) => [
        `${segment.targetRange.startUs}:${segment.targetRange.durationUs}`,
        segment.segmentId,
      ]),
    )
    /**
     * Bind secondary segments to the immutable primary shot they belonged to
     * before applying any Agent operation. This prevents a move/swap from
     * matching a secondary segment against a range that was already rewritten.
     */
    const secondaryBindings = new Map()
    /** @type {Map<string, {primarySegmentId: string, offsetUs: number, durationUs: number, shotDurationUs: number}>} */
    const packagingBindings = new Map()
    for (const track of next.tracks) {
      if (track.kind !== 'caption' && !(track.kind === 'audio' && track.role === 'voiceover')) continue
      for (const secondary of track.segments) {
        const primarySegmentId = basePrimaryByRange.get(
          `${secondary.targetRange.startUs}:${secondary.targetRange.durationUs}`,
        )
        if (primarySegmentId) secondaryBindings.set(secondary.segmentId, primarySegmentId)
      }
    }
    for (const track of next.tracks) {
      if (!isInheritedPackagingTrack(track)) continue
      for (const secondary of track.segments) {
        const startUs = secondary.targetRange?.startUs
        const container = [...basePrimaryById.values()].find((/** @type {Record<string, any>} */ shot) =>
          Number.isSafeInteger(startUs) &&
          startUs >= shot.targetRange.startUs &&
          startUs < shot.targetRange.startUs + shot.targetRange.durationUs)
        if (!container) continue
        packagingBindings.set(secondary.segmentId, {
          primarySegmentId: container.segmentId,
          offsetUs: startUs - container.targetRange.startUs,
          durationUs: secondary.targetRange.durationUs,
          shotDurationUs: container.targetRange.durationUs,
        })
      }
    }
    let cursor = 0
    for (const [index, segment] of primary.segments.entries()) {
      const nextRange = {
        startUs: cursor,
        durationUs: segment.targetRange.durationUs,
      }
      segment.targetRange = {
        ...nextRange,
      }
      if (index === primary.segments.length - 1) {
        segment.transitionOut = {
          capabilityId: 'transition.none',
          durationUs: 0,
          parameters: {},
        }
      } else if (segment.transitionOut?.capabilityId === 'transition.none') {
        segment.transitionOut = {
          capabilityId: 'transition.cut',
          durationUs: 0,
          parameters: {},
        }
      }
      // Captions and narration are authored per primary shot. Keep their
      // canonical ranges aligned after an Agent changes a source duration or
      // causes the primary track to be retimed contiguously.
      cursor += segment.targetRange.durationUs
    }
    const finalPrimaryById = new Map(primary.segments.map((/** @type {Record<string, any>} */ segment) => [segment.segmentId, segment]))
    for (const track of next.tracks) {
      if (track.kind !== 'caption' && !(track.kind === 'audio' && track.role === 'voiceover')) continue
      track.segments = track.segments.filter((/** @type {Record<string, any>} */ secondary) => {
        const primarySegmentId = secondaryBindings.get(secondary.segmentId)
        const finalPrimary = primarySegmentId ? finalPrimaryById.get(primarySegmentId) : null
        if (!finalPrimary) return !primarySegmentId
        secondary.targetRange = clone(finalPrimary.targetRange)
        return true
      })
    }
    for (const track of next.tracks) {
      if (!isInheritedPackagingTrack(track)) continue
      for (const secondary of track.segments) {
        const binding = packagingBindings.get(secondary.segmentId)
        if (!binding) continue
        const finalPrimary = finalPrimaryById.get(binding.primarySegmentId)
        if (!finalPrimary || binding.shotDurationUs < 1) {
          fail('EDITOR_PATCH_INHERITED_PACKAGING_UNBOUND')
        }
        const mappedOffset = Math.floor(
          (binding.offsetUs * finalPrimary.targetRange.durationUs) / binding.shotDurationUs,
        )
        const mappedDuration = Math.max(1, Math.floor(
          (binding.durationUs * finalPrimary.targetRange.durationUs) / binding.shotDurationUs,
        ))
        const startUs = finalPrimary.targetRange.startUs + Math.min(
          Math.max(0, mappedOffset),
          Math.max(0, finalPrimary.targetRange.durationUs - 1),
        )
        const durationUs = Math.min(
          mappedDuration,
          finalPrimary.targetRange.startUs + finalPrimary.targetRange.durationUs - startUs,
        )
        if (durationUs < 1) fail('EDITOR_PATCH_INHERITED_PACKAGING_OUT_OF_RANGE')
        secondary.targetRange = { startUs, durationUs }
      }
    }
    next.durationUs = Math.max(1, cursor)
    for (const track of next.tracks) {
      if (track.kind !== 'audio' || track.role !== 'bgm') continue
      for (const segment of track.segments) {
        const coveredFullBase = segment.targetRange?.startUs === 0 &&
          segment.targetRange?.durationUs === base.durationUs
        const startedAtZero = segment.targetRange?.startUs === 0
        if (coveredFullBase || startedAtZero) {
          segment.targetRange = { startUs: 0, durationUs: next.durationUs }
          if (Number.isSafeInteger(segment.sourceRange?.durationUs)) {
            segment.sourceRange = {
              startUs: 0,
              durationUs: Math.max(segment.sourceRange.durationUs, next.durationUs),
            }
          }
        } else if (
          Number.isSafeInteger(segment.targetRange?.startUs) &&
          Number.isSafeInteger(segment.targetRange?.durationUs) &&
          segment.targetRange.startUs + segment.targetRange.durationUs > next.durationUs
        ) {
          fail('EDITOR_PATCH_INHERITED_PACKAGING_OUT_OF_RANGE')
        }
      }
    }
  }
  for (const track of next.tracks) {
    if (!isInheritedPackagingTrack(track)) continue
    for (const segment of track.segments) {
      const range = segment?.targetRange
      if (
        !Number.isSafeInteger(range?.startUs) ||
        !Number.isSafeInteger(range?.durationUs) ||
        range.startUs + range.durationUs > next.durationUs
      ) {
        fail('EDITOR_PATCH_INHERITED_PACKAGING_OUT_OF_RANGE')
      }
    }
  }
  const titleTrack = next.tracks.find(
    (/** @type {Record<string, any>} */ track) => track.kind === 'title' && track.enabled !== false,
  )
  if (titleTrack?.segments?.length > 0 && titleTrackMutated) {
    try {
      titleTrack.segments = solvePackagingTextLayouts({ orientation: next.orientation, segments: titleTrack.segments })
    } catch (error) {
      if (error instanceof PackagingTextLayoutError) fail(error.code)
      throw error
    }
  }
  const inheritedRequirements = new Map(
    base.capabilityRequirements.map(
      (/** @type {Record<string, any>} */ requirement) =>
        [requirement.capabilityId, requirement],
    ),
  )
  next.capabilityRequirements = computeCapabilityRequirements(next.tracks).map(
    (/** @type {Record<string, any>} */ requirement) =>
      inheritedRequirements.has(requirement.capabilityId)
        ? clone(inheritedRequirements.get(requirement.capabilityId))
        : requirement,
  )
  return sealRichTimeline(next)
}
