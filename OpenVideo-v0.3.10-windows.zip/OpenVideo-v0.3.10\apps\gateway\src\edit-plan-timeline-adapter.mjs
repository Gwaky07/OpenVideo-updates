import { createHash } from 'node:crypto'

import {
  RichTimelineContractError,
  assertOpaqueTimelineId,
  computeCapabilityRequirements,
  sealRichTimeline,
  secondsToMicroseconds,
} from './rich-timeline-contracts.mjs'
import {
  assertTimelineTemplateConstraints,
  usesUploadedDraftInventory,
} from './timeline-template-constraints.mjs'
import { projectRecommendationToRichTimeline } from './jianying-packaging-recommender.mjs'
import {
  PackagingTextLayoutError,
  derivePackagingEmphasisText,
  solvePackagingTextLayouts,
} from './packaging-text-layout.mjs'
import { isCreativeTechniqueDecision } from './creative-technique-policy.mjs'
import { assignTemplateSfxPoolByIntent } from './template-sfx-intent.mjs'
import {
  clampSpokenWindows,
  extendWindowsToCoverRange,
  placeWindowInGaps,
  selectReadableFlowerWindows,
  serializeOverlappingWindows,
  scoreSpokenCue,
  spokenWindowForCue,
  splitVoiceoverCaptionCards,
  timeAlignTextSpans,
} from './voiceover-packaging-timing.mjs'

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {value is any[]} */
const isDenseArray = (value) =>
  Array.isArray(value) &&
  Object.keys(value).length === value.length &&
  Object.keys(value).every((key, index) => key === String(index))

/**
 * @typedef {{
 *   packagingToken: string,
 *   family: string,
 *   label: string,
 *   targetSegmentId: string,
 * }} PackagingSelection
 */

export class EditPlanTimelineAdapterError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'EditPlanTimelineAdapterError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 400) => {
  throw new EditPlanTimelineAdapterError(code, status)
}

/** @param {any} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value)
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) fail('non_json_canonical_value')
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) {
    if (!isDenseArray(value)) fail('non_json_canonical_value')
    return `[${value.map(stableStringify).join(',')}]`
  }
  if (isRecord(value)) {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`
  }
  fail('non_json_canonical_value')
}

/** @param {unknown} value */
const sha256Hex = (value) => createHash('sha256').update(stableStringify(value)).digest('hex')

const PACKAGING_HIT_MERGE_US = 80_000
const SFX_HIT_MAX_US = 400_000

/**
 * Every flower keeps its own hit. Stickers/effects only add a beat when they
 * are not already sitting on a flower, so two nearby flowers never lose SFX.
 * @param {readonly {targetRange: {startUs: number, durationUs: number}, text?: string, kind?: string}[]} hits
 */
const uniquePackagingHits = (hits) => {
  const valid = hits.filter((hit) =>
    isRecord(hit?.targetRange) && Number.isSafeInteger(hit.targetRange.startUs))
  const flowers = valid.filter((hit) => hit.kind === 'flower')
  const extras = valid.filter((hit) => hit.kind !== 'flower')
  const kept = [...flowers]
  for (const hit of extras) {
    const duplicate = kept.some((entry) =>
      Math.abs(entry.targetRange.startUs - hit.targetRange.startUs) <= PACKAGING_HIT_MERGE_US)
    if (!duplicate) kept.push(hit)
  }
  return kept.sort((left, right) =>
    left.targetRange.startUs - right.targetRange.startUs)
}

/**
 * Template / creation SFX is only a sound pool. Each flower starts a short
 * hit at the same instant the flower appears. Long authored files are capped
 * so the transient is not heard halfway through the on-screen text.
 * @param {readonly any[]} cues
 * @param {readonly {targetRange: {startUs: number, durationUs: number}, text?: string}[]} hits
 * @param {string} [notes]
 */
const placeSfxPoolOnPackagingHits = (cues, hits, notes = '') => {
  const pool = cues.filter((cue) => isRecord(cue))
  const packagingHits = uniquePackagingHits(hits)
  if (pool.length === 0 || packagingHits.length === 0) return []
  const assigned = pool.length === packagingHits.length
    ? pool
    : assignTemplateSfxPoolByIntent(
      pool,
      packagingHits.map((hit) => typeof hit.text === 'string' && hit.text.trim()
        ? hit.text
        : (hit.kind === 'sticker' ? '贴纸卡点' : hit.kind === 'effect' ? '特效卡点' : '包装卡点')),
      notes,
    )
  return packagingHits.map((hit, index) => {
    const cue = assigned[index] ?? assigned[assigned.length - 1]
    const authoredDurationUs = Number(cue.durationUs)
    const nextStartUs = packagingHits[index + 1]?.targetRange.startUs
    const gapUs = Number.isSafeInteger(nextStartUs)
      ? Math.max(1, nextStartUs - hit.targetRange.startUs)
      : hit.targetRange.durationUs
    const rawDurationUs = Number.isSafeInteger(authoredDurationUs) && authoredDurationUs > 0
      ? authoredDurationUs
      : SFX_HIT_MAX_US
    const durationUs = Math.min(
      rawDurationUs,
      SFX_HIT_MAX_US,
      gapUs,
      hit.targetRange.durationUs,
    )
    return {
      audioToken: cue.audioToken,
      volume: cue.volume,
      startUs: hit.targetRange.startUs,
      durationUs: Math.max(1, durationUs),
    }
  })
}

/** @param {string} prefix @param {unknown} material */
const opaqueFromHash = (prefix, material) => `${prefix}-${sha256Hex(material).slice(0, 24)}`

/** @param {Array<{ segments?: Array<{ segmentId?: string }> }>} tracks */
const ensureUniqueSegmentIds = (tracks) => {
  const seen = new Set()
  for (const track of tracks) {
    const segments = Array.isArray(track?.segments) ? track.segments : []
    for (const segment of segments) {
      const original = typeof segment.segmentId === 'string' ? segment.segmentId : ''
      if (!original || !seen.has(original)) {
        if (original) seen.add(original)
        continue
      }
      let n = 1
      let next = original
      do {
        next = opaqueFromHash('seg', { duplicateOf: original, n })
        n += 1
      } while (seen.has(next))
      segment.segmentId = next
      seen.add(next)
    }
  }
}

/**
 * @param {unknown} bounds
 * @returns {Map<string, {startUs: number, durationUs: number}>}
 */
const normalizeSceneBounds = (bounds) => {
  /** @type {Map<string, {startUs: number, durationUs: number}>} */
  const map = new Map()
  if (bounds == null) return map
  /** @type {[string, any][] | null} */
  const entries =
    bounds instanceof Map
      ? [...bounds.entries()]
      : isRecord(bounds)
        ? Object.entries(bounds)
        : null
  if (!entries) fail('invalid_scene_bounds')
  for (const [key, value] of /** @type {[string, any][]} */ (entries)) {
    if (typeof key !== 'string' || !isRecord(value)) fail('invalid_scene_bounds')
    if (
      Number.isSafeInteger(value.startUs) &&
      Number.isSafeInteger(value.durationUs)
    ) {
      map.set(key, {
        startUs: /** @type {number} */ (value.startUs),
        durationUs: /** @type {number} */ (value.durationUs),
      })
      continue
    }
    if (
      typeof value.start === 'number' &&
      typeof value.end === 'number'
    ) {
      const startUs = secondsToMicroseconds(value.start)
      const endUs = secondsToMicroseconds(value.end)
      map.set(key, { startUs, durationUs: endUs - startUs })
      continue
    }
    if (
      typeof value.start === 'number' &&
      typeof value.duration === 'number'
    ) {
      map.set(key, {
        startUs: secondsToMicroseconds(value.start),
        durationUs: secondsToMicroseconds(value.duration),
      })
      continue
    }
    fail('invalid_scene_bounds')
  }
  return map
}

/**
 * Technique policy is deliberately limited to one decision per already-selected
 * sentence. It cannot introduce media, tracks, paths or a second timeline.
 * @param {unknown} values
 * @param {Record<string, any>[]} selectedItems
 */
const normalizeTechniqueDecisions = (values, selectedItems) => {
  if (values == null) return new Map()
  if (!isDenseArray(values) || values.length !== selectedItems.length ||
      !values.every(isCreativeTechniqueDecision)) {
    fail('invalid_technique_decisions')
  }
  const expected = selectedItems.map((item) => item.sentence_id)
  const received = values.map((value) => value.beat_id)
  if (new Set(received).size !== received.length ||
      received.some((beatId, index) => beatId !== expected[index])) {
    fail('technique_decision_sentence_mismatch')
  }
  return new Map(values.map((value) => [value.beat_id, clone(value)]))
}

/**
 * @param {unknown} guidance
 * @returns {Record<string, any> | null}
 */
const assertTemplateGuidance = (guidance) => {
  if (guidance == null) return null
  if (!isRecord(guidance) || !isDenseArray(guidance.slots)) {
    fail('invalid_template_guidance')
  }
  for (const slot of guidance.slots) {
    if (!isRecord(slot)) fail('invalid_template_guidance')
    if (
      !Number.isSafeInteger(slot.recommendedDurationMs) ||
      slot.recommendedDurationMs <= 0
    ) {
      fail('invalid_template_guidance')
    }
    if (typeof slot.transitionOut !== 'string') fail('invalid_template_guidance')
    if (!['cut', 'none'].includes(slot.transitionOut)) {
      fail('WORKBENCH_TEMPLATE_TRANSITION_UNSUPPORTED', 409)
    }
  }
  return guidance
}

/** @param {Record<string, any>} identity */
const templateTokenFor = (identity) => {
  const readable = `tpl-${identity.libraryTemplateId}-${identity.revision}-${identity.fingerprint.slice(0, 12)}`
  return readable.length <= 200
    ? readable
    : opaqueFromHash('tpl', identity)
}

/** @param {Record<string, unknown>} item */
const selectedCandidate = (item) => {
  if (!isDenseArray(item.candidates)) fail('invalid_edit_plan_item')
  const selectedId = item.selected_candidate_id
  const match = item.candidates.find(
    (candidate) => isRecord(candidate) && candidate.candidate_id === selectedId,
  )
  if (!isRecord(match)) fail('selected_candidate_missing')
  return match
}

/**
 * Converts bounded policy proposals into the exact decisions that may affect
 * canonical timing. Unsafe hold budgets degrade to zero and never block the
 * existing visual chain.
 * @param {{editPlan: unknown, templateGuidance?: unknown, templateConstraints?: unknown, sceneBounds?: unknown, narrationSegments?: unknown, techniqueDecisions?: unknown}} input
 */
export const realizeCreativeTechniqueDecisions = (input) => {
  if (!isRecord(input?.editPlan) || !isDenseArray(input.editPlan.items)) fail('invalid_edit_plan')
  const selectedItems = input.editPlan.items
    .filter((item) => isRecord(item) && item.status === 'selected')
    .sort((left, right) => Number(left.order) - Number(right.order))
  const decisions = normalizeTechniqueDecisions(input.techniqueDecisions, selectedItems)
  if (decisions.size === 0) return []
  const guidance = assertTemplateGuidance(input.templateGuidance ?? null)
  const constraints = input.templateConstraints == null
    ? null
    : assertTimelineTemplateConstraints(input.templateConstraints)
  const bounds = normalizeSceneBounds(input.sceneBounds)
  const hasNarration = Array.isArray(input.narrationSegments) && input.narrationSegments.length > 0
  const conflictReason = hasNarration ? 'technique_narration_conflict' : null
  return selectedItems.map((item) => {
    const decision = clone(decisions.get(item.sentence_id))
    if (conflictReason && (decision.hold_budget_us > 0 || decision.rhythm_class !== 'steady')) {
      decision.hold_budget_us = 0
      decision.degradation_reason = conflictReason
    } else if (decision.hold_budget_us > 0) {
      const candidate = selectedCandidate(item)
      const assetId = assertOpaqueTimelineId(candidate.asset_id, 'invalid_asset_id')
      const sceneId = assertOpaqueTimelineId(candidate.scene_id, 'invalid_scene_id')
      const bound = bounds.get(`${assetId}\u0000${sceneId}`)
      if (!bound) {
        decision.hold_budget_us = 0
        decision.degradation_reason = 'hold_source_bound_unavailable'
      } else {
        const candidateEndUs = secondsToMicroseconds(candidate.end)
        const availableUs = Math.max(0, bound.startUs + bound.durationUs - candidateEndUs)
        const requestedUs = decision.hold_budget_us
        decision.hold_budget_us = Math.min(requestedUs, availableUs)
        if (decision.hold_budget_us === 0) {
          decision.degradation_reason = 'hold_source_budget_unavailable'
        } else if (decision.hold_budget_us < requestedUs) {
          decision.degradation_reason = 'hold_source_budget_limited'
        }
      }
    }
    if (!isCreativeTechniqueDecision(decision)) fail('invalid_technique_decisions')
    return Object.freeze(decision)
  })
}

/**
 * @param {{
 *   editPlan: unknown,
 *   templateGuidance?: unknown,
 *   templateConstraints?: unknown,
 *   authorizationId?: string | null,
 *   authorizationByCandidateId?: Record<string, string> | null,
 *   timelineId?: string,
 *   projectId?: string,
 *   createdAt?: string,
 *   orientation?: 'portrait' | 'landscape' | 'square',
 *   captions?: 'none' | 'auto',
 *   fps?: {numerator: number, denominator: number},
 *   sceneBounds?: Map<string, any> | Record<string, any>,
 *   bgm?: {audioToken: string, volume: number} | null,
 *   sfx?: Array<{audioToken: string, volume: number, startUs: number, durationUs: number}> | null,
 *   sfxIntentAligned?: boolean,
 *   narrationSegments?: Array<{sentenceId: string, audioToken: string, durationUs: number}> | null,
 *   techniqueDecisions?: readonly Record<string, any>[] | null,
 *   packagingRecommendation?: unknown,
 *   packagingCatalog?: unknown,
 *   automaticPackaging?: boolean,
 * }} input
 */
export const adaptEditPlanToTimeline = (input) => {
  if (!isRecord(input)) fail('invalid_adapter_input')
  const authorizationByCandidateId = isRecord(input.authorizationByCandidateId)
    ? input.authorizationByCandidateId
    : null
  if (input.authorizationId != null) {
    assertOpaqueTimelineId(input.authorizationId, 'invalid_authorization_id')
  } else if (!authorizationByCandidateId) {
    fail('invalid_authorization_id')
  }
  const fallbackAuthorizationId = input.authorizationId == null ? null : input.authorizationId
  const editPlan = input.editPlan
  if (!isRecord(editPlan) || !isDenseArray(editPlan.items)) fail('invalid_edit_plan')

  if (input.templateGuidance != null && input.templateConstraints != null) {
    fail('template_constraints_conflict')
  }
  const guidance = assertTemplateGuidance(input.templateGuidance ?? null)
  const constraints = input.templateConstraints == null
    ? null
    : assertTimelineTemplateConstraints(input.templateConstraints)
  const selectedItems = editPlan.items
    .filter((item) => isRecord(item) && item.status === 'selected')
    .sort((left, right) => Number(left.order) - Number(right.order))

  if (selectedItems.length === 0) fail('no_selected_items')
  const sceneBounds = normalizeSceneBounds(input.sceneBounds)
  const narrationSegments = input.narrationSegments == null
    ? null
    : Array.isArray(input.narrationSegments)
      ? input.narrationSegments.map((segment) => ({
          sentenceId: assertOpaqueTimelineId(segment?.sentenceId, 'invalid_narration_sentence_id'),
          audioToken: assertOpaqueTimelineId(segment?.audioToken, 'invalid_narration_audio_token'),
          durationUs: Number(segment?.durationUs),
        }))
      : fail('invalid_narration_segments')
  if (
    narrationSegments &&
    (
      narrationSegments.length !== selectedItems.length ||
      narrationSegments.some((segment) => !Number.isSafeInteger(segment.durationUs) || segment.durationUs <= 0)
    )
  ) fail('invalid_narration_segments')
  const realizedTechniqueDecisions = input.techniqueDecisions == null
    ? null
    : realizeCreativeTechniqueDecisions({
        editPlan,
        templateGuidance: guidance,
        templateConstraints: constraints,
        sceneBounds,
        narrationSegments,
        techniqueDecisions: input.techniqueDecisions,
      })
  const techniqueDecisions = normalizeTechniqueDecisions(realizedTechniqueDecisions, selectedItems)
  const editPlanFingerprint = sha256Hex(editPlan)
  const templateFingerprint = constraints
    ? constraints.identity.fingerprint
    : guidance
      ? sha256Hex(guidance)
      : null
  const projectId = assertOpaqueTimelineId(
    input.projectId ?? editPlan.project_id ?? 'project-migrated',
    'invalid_project_id',
  )
  const timelineId = assertOpaqueTimelineId(
    input.timelineId ?? opaqueFromHash('tl', {
      projectId,
      editPlanFingerprint,
      templateFingerprint,
    }),
    'invalid_timeline_id',
  )
  const createdAt =
    typeof input.createdAt === 'string' && Number.isFinite(Date.parse(input.createdAt))
      ? input.createdAt
      : typeof editPlan.created_at === 'string' && Number.isFinite(Date.parse(editPlan.created_at))
        ? editPlan.created_at
        : new Date().toISOString()
  const orientation = input.orientation ?? 'portrait'
  const fps = input.fps ?? { numerator: 30, denominator: 1 }
  const constraintBgm = constraints?.bgm ?? null
  const hasExplicitBgm = Object.prototype.hasOwnProperty.call(input, 'bgm')
  const bgm = !hasExplicitBgm && constraintBgm
    ? {
        audioToken: assertOpaqueTimelineId(constraintBgm.audioToken, 'invalid_bgm_audio_token'),
        volume: Number(constraintBgm.volume),
      }
    : !hasExplicitBgm || input.bgm == null
      ? null
      : {
          audioToken: assertOpaqueTimelineId(input.bgm.audioToken, 'invalid_bgm_audio_token'),
          volume: Number(input.bgm.volume),
        }
  if (bgm && (!Number.isFinite(bgm.volume) || bgm.volume < 0 || bgm.volume > 1)) {
    fail('invalid_bgm_volume')
  }
  // Preserve authored template cues unless the project explicitly supplies an
  // SFX list (including null to suppress all SFX). Template cue times are
  // remapped to the finalized project duration below.
  const hasExplicitSfx = Object.prototype.hasOwnProperty.call(input, 'sfx')
  const inheritedTemplateSfx = !hasExplicitSfx && Array.isArray(constraints?.sfx)
  const sfxCues = hasExplicitSfx
    ? (Array.isArray(input.sfx) ? input.sfx : [])
    : (constraints?.sfx ?? [])
  const templatePackagingSegments = Array.isArray(constraints?.packagingSegments)
    ? constraints.packagingSegments
    : []
  const ignoreCatalogRecommendation = usesUploadedDraftInventory(constraints)
  const packagingRecommendationSelections =
    !ignoreCatalogRecommendation &&
    isRecord(input.packagingRecommendation) &&
    Array.isArray(input.packagingRecommendation.selected)
      ? input.packagingRecommendation.selected
      : null
  const authoredFlowerSlots = (Array.isArray(constraints?.richTextSlots) ? constraints.richTextSlots : [])
    .some((slot) => slot?.decorationKind === 'flower')
  const authoredBubbleSlots = (Array.isArray(constraints?.richTextSlots) ? constraints.richTextSlots : [])
    .some((slot) => slot?.decorationKind === 'bubble')
  const templateRichTextFamilies = new Set([
    ...(authoredFlowerSlots ? ['flower'] : []),
    ...(authoredBubbleSlots ? ['bubble'] : []),
    ...(Array.isArray(constraints?.richTextSegments) ? constraints.richTextSegments : [])
      .map((segment) => segment?.capabilityId === 'text.flower.private'
        ? 'flower'
        : segment?.capabilityId === 'text.bubble.private'
          ? 'bubble'
          : segment?.capabilityId === 'text.rich'
            ? (authoredBubbleSlots && !authoredFlowerSlots ? 'bubble' : 'flower')
            : null)
      .filter((family) => family !== null),
  ])
  const recommendationSelected = !ignoreCatalogRecommendation &&
    isRecord(input.packagingRecommendation) &&
    Array.isArray(input.packagingRecommendation.selected)
    ? input.packagingRecommendation.selected.filter((item) =>
      !templateRichTextFamilies.has(item?.family))
    : null
  const recommendationPackagingSegments = input.packagingRecommendation == null ||
    recommendationSelected === null ||
    recommendationSelected.length === 0
    ? []
    : projectRecommendationToRichTimeline({
        ...input.packagingRecommendation,
        selected: recommendationSelected,
      }, {
        index: input.packagingCatalog,
        allowedTargetSegmentIds: new Set(selectedItems.map((item) => item.sentence_id)),
      }).map((/** @type {Record<string, any>} */ patch) => ({
        isAutomaticRecommendation: true,
        packagingToken: patch.parameters.packagingToken ?? patch.parameters.templateToken ?? patch.parameters.animationToken ?? patch.parameters.maskToken ?? patch.parameters.blendToken ?? patch.parameters.effectToken,
        capabilityId: patch.capabilityId,
        family: patch.family,
        targetSegmentId: patch.targetSegmentId,
        startUs: patch.targetRange.startUs,
        durationUs: patch.targetRange.durationUs,
        parameters: patch.parameters,
        role: patch.capabilityId === 'sticker.named' ? 'sticker' : null,
      })).filter((segment) => !templateRichTextFamilies.has(segment.family))
  const templatePackagingFamilies = new Set(
    templatePackagingSegments
      .map((segment) => segment?.role === 'sticker' ? 'sticker' : segment?.role === 'effect' ? 'video_effect' : null)
      .filter((family) => family !== null),
  )
  // Template-bound visual resources are authoritative. Automatic selections
  // may fill a missing family, but never replace or duplicate an authored
  // sticker/effect family from the selected template.
  const packagingSegments = [
    ...templatePackagingSegments,
    ...recommendationPackagingSegments.filter((segment) => !templatePackagingFamilies.has(segment.family)),
  ]
  const richTextEntries = Array.isArray(constraints?.richTextSegments)
    ? constraints.richTextSegments
    : []
  const hasEmphasisRichText = richTextEntries.some((entry) =>
    isRecord(entry) && typeof entry.text === 'string' && entry.text.trim().length > 0)

  /** @type {Record<string, any>[]} */
  const videoSegments = []
  /** @type {Record<string, any>[]} */
  const voiceoverSegments = []
  /** @type {Record<string, any>[]} */
  const captionSegments = []
  /** @type {Array<Array<{ text: string, startUs: number, durationUs: number }>>} */
  const captionSpansByShot = []
  /** @type {Record<string, any>[]} */
  const titleSegments = []
  /** @type {Record<string, any>[]} */
  const tracks = []
  const usedSceneKeys = new Set()
  let cursor = 0
  /** @type {Array<{startUs: number, durationUs: number}>} */
  const projectShotRanges = []
  /** @type {Record<string, any>[]} */
  const markers = []

  for (let index = 0; index < selectedItems.length; index += 1) {
    const item = /** @type {Record<string, any>} */ (selectedItems[index])
    const candidate = selectedCandidate(item)
    if (typeof candidate.start !== 'number' || typeof candidate.end !== 'number') {
      fail('invalid_candidate_range')
    }
    let sourceStartUs = secondsToMicroseconds(candidate.start)
    let sourceEndUs = secondsToMicroseconds(candidate.end)
    const narration = narrationSegments?.[index] ?? null
    const technique = techniqueDecisions.get(item.sentence_id) ?? null
    if (narration && narration.sentenceId !== item.sentence_id) {
      fail('narration_sentence_mismatch')
    }
    if (narration) {
      const boundKey = `${item.candidates.find((/** @type {Record<string, any>} */ entry) => entry.candidate_id === item.selected_candidate_id)?.asset_id ?? candidate.asset_id}\u0000${candidate.scene_id}`
      const bound = sceneBounds.get(boundKey)
      if (!bound) fail('WORKBENCH_NARRATION_SCENE_BOUND_REQUIRED', 409)
      const sceneStartUs = bound.startUs
      const sceneEndUs = bound.startUs + bound.durationUs
      if (sceneEndUs - sceneStartUs < narration.durationUs) {
        fail('WORKBENCH_NARRATION_MATERIAL_DURATION_INSUFFICIENT', 409)
      }
      sourceStartUs = Math.max(sceneStartUs, Math.min(sourceStartUs, sceneEndUs - narration.durationUs))
      sourceEndUs = sourceStartUs + narration.durationUs
    }

    const assetId = assertOpaqueTimelineId(candidate.asset_id, 'invalid_asset_id')
    const sceneId = assertOpaqueTimelineId(candidate.scene_id, 'invalid_scene_id')
    const candidateId = assertOpaqueTimelineId(candidate.candidate_id, 'invalid_candidate_id')
    const authorizationId = assertOpaqueTimelineId(
      authorizationByCandidateId?.[candidateId] ?? fallbackAuthorizationId,
      'invalid_authorization_id',
    )
    const boundKey = `${assetId}\u0000${sceneId}`
    if (usedSceneKeys.has(boundKey)) {
      fail('WORKBENCH_NARRATION_SCENE_REUSE_FORBIDDEN', 409)
    }
    usedSceneKeys.add(boundKey)
    const bound = sceneBounds.get(boundKey)
    if (bound) {
      const boundEnd = bound.startUs + bound.durationUs
      if (sourceStartUs < bound.startUs || sourceEndUs > boundEnd) {
        fail('source_range_outside_scene')
      }
    }

    // Narration owns timing. Template metadata never does; a content-derived
    // technique may extend a normal source range inside its trusted boundary.
    if (technique && !narration && bound) {
      const boundEnd = bound.startUs + bound.durationUs
      const availableUs = boundEnd - sourceEndUs
      const originalDurationUs = sourceEndUs - sourceStartUs
      const rhythmExtraUs = technique.rhythm_class === 'rest'
        ? Math.min(750_000, Math.round(originalDurationUs * 0.15))
        : technique.rhythm_class === 'decelerate'
          ? Math.min(500_000, Math.round(originalDurationUs * 0.1))
          : 0
      const holdUs = Math.min(technique.hold_budget_us, Math.max(0, availableUs))
      const rhythmUs = Math.min(rhythmExtraUs, Math.max(0, availableUs - holdUs))
      sourceEndUs += holdUs + rhythmUs
      if (sourceEndUs > boundEnd) fail('source_range_outside_scene')
    }
    const sourceDurationUs = sourceEndUs - sourceStartUs
    if (!(sourceDurationUs > 0)) fail('invalid_candidate_duration')

    const isLast = index === selectedItems.length - 1
    const techniqueTransition = technique &&
      (technique.transition_capability_id === 'transition.cut' || technique.transition_capability_id === 'transition.none')
      ? technique.transition_capability_id
      : null
    const transitionOut = techniqueTransition
        ? { capabilityId: isLast ? 'transition.none' : techniqueTransition, durationUs: 0, parameters: {} }
        : isLast
          ? { capabilityId: 'transition.none', durationUs: 0, parameters: {} }
          : { capabilityId: 'transition.cut', durationUs: 0, parameters: {} }

    const targetRange = { startUs: cursor, durationUs: sourceDurationUs }
    projectShotRanges.push(clone(targetRange))
    if (technique) {
      markers.push({
        markerId: opaqueFromHash('mark', {
          sentenceId: item.sentence_id,
          offsetUs: cursor,
          rhythmClass: technique.rhythm_class,
        }),
        offsetUs: cursor,
        kind: 'beat',
        label: `semantic_cadence:${technique.rhythm_class}`,
      })
    }
    const segmentMaterial = {
      kind: 'video',
      asset: { authorizationId, assetId, sceneId },
      sourceRange: { startUs: sourceStartUs, durationUs: sourceDurationUs },
      targetRange,
      fit: 'cover',
      volume: 1,
      speed: { numerator: 1, denominator: 1 },
      keyframes: [],
      effects: [],
      transitionOut,
      order: item.order,
      sentenceId: item.sentence_id,
      candidateId,
    }
    const segmentId = opaqueFromHash('seg', segmentMaterial)
    videoSegments.push({
      segmentId,
      kind: 'video',
      asset: { authorizationId, assetId, sceneId },
      sourceRange: { startUs: sourceStartUs, durationUs: sourceDurationUs },
      targetRange: clone(targetRange),
      fit: 'cover',
      volume: 1,
      speed: { numerator: 1, denominator: 1 },
      keyframes: [],
      effects: [],
      audit: {
        origin: 'migration',
        candidateId,
        instructionFingerprint: null,
      },
      transitionOut,
    })

    if (narration) {
      const audioMaterial = {
        kind: 'voiceover',
        audioToken: narration.audioToken,
        sentenceId: narration.sentenceId,
        targetRange,
      }
      voiceoverSegments.push({
        segmentId: opaqueFromHash('seg', audioMaterial),
        kind: 'voiceover',
        capabilityId: 'audio.voiceover.edge_tts',
        source: { kind: 'generated', generatedAudioId: narration.audioToken },
        sourceRange: { startUs: 0, durationUs: narration.durationUs },
        targetRange: clone(targetRange),
        volume: 1,
        fadeInUs: 0,
        fadeOutUs: 0,
        keyframes: [],
        ducking: 'none',
      })
    }

    const titleCard = index === 0
      ? constraints?.titleCards?.intro
      : index === selectedItems.length - 1
        ? constraints?.titleCards?.outro
        : null
    const hasCanonicalText =
      typeof item.voiceover_text === 'string' && item.voiceover_text.trim().length > 0
    if (titleCard && !hasCanonicalText) {
      fail('WORKBENCH_TEMPLATE_TITLE_TEXT_UNAVAILABLE', 409)
    }
    if (hasCanonicalText) {
      const templateToken = constraints ? templateTokenFor(constraints.identity) : null
      // Auto captions stay on when requested. A bound Jianying draft owns the
      // finished subtitle size/position; otherwise use the default caption token.
      if (input.captions !== 'none' && (!constraints || constraints.caption)) {
        const captionCapabilityId = constraints?.caption?.capabilityId ?? 'caption.basic'
        const captionStyleToken = constraints?.caption?.styleToken ?? 'caption-basic'
        const maxChars = Number.isSafeInteger(constraints?.caption?.cadence?.maxCharsPerCard)
          ? constraints.caption.cadence.maxCharsPerCard
          : 12
        const cards = splitVoiceoverCaptionCards(item.voiceover_text, { maxChars })
        const spans = timeAlignTextSpans(
          cards.length > 0 ? cards : [item.voiceover_text.trim()],
          targetRange,
        )
        captionSpansByShot[index] = spans
        for (const [cardIndex, span] of spans.entries()) {
          const captionMaterial = {
            kind: 'caption',
            capabilityId: captionCapabilityId,
            targetRange: { startUs: span.startUs, durationUs: span.durationUs },
            text: span.text,
            styleToken: captionStyleToken,
            order: item.order,
            sentenceId: item.sentence_id,
            cardIndex,
          }
          captionSegments.push({
            segmentId: opaqueFromHash('seg', captionMaterial),
            kind: 'caption',
            capabilityId: captionCapabilityId,
            targetRange: { startUs: span.startUs, durationUs: span.durationUs },
            text: span.text,
            styleToken: captionStyleToken,
            animationIn: null,
            animationOut: null,
            templateToken,
          })
        }
      } else {
        captionSpansByShot[index] = timeAlignTextSpans(
          splitVoiceoverCaptionCards(item.voiceover_text),
          targetRange,
        )
      }

      if (titleCard) {
        const titleMaterial = {
          kind: 'title',
          capabilityId: titleCard.capabilityId,
          targetRange: clone(targetRange),
          text: item.voiceover_text,
          order: item.order,
          templateToken,
        }
        titleSegments.push({
          segmentId: opaqueFromHash('seg', titleMaterial),
          kind: 'title',
          capabilityId: titleCard.capabilityId,
          targetRange: clone(targetRange),
          text: item.voiceover_text,
          styleToken: 'title-card',
          animationIn: null,
          animationOut: null,
          templateToken,
        })
      }
    }

    cursor += sourceDurationUs
    if (!Number.isSafeInteger(cursor)) fail('timeline_duration_overflow')
  }

  const targetRangesBySentence = new Map(selectedItems.map((item, index) => [
    item.sentence_id,
    videoSegments[index]?.targetRange,
  ]))
  /** @param {Record<string, any>} entry @param {number} index */
  const packagingTargetRange = (entry, index) => {
    if (typeof entry.targetSegmentId === 'string') {
      const targetRange = targetRangesBySentence.get(entry.targetSegmentId)
      if (!targetRange) fail('JY132_TARGET_SEGMENT_UNRESOLVED', 409)
      return clone(targetRange)
    }
    const targetRange = projectShotRanges[index % Math.max(1, projectShotRanges.length)]
    if (!targetRange) return { startUs: 0, durationUs: 0 }
    const requestedDurationUs = Number(entry.durationUs)
    const durationUs = Number.isSafeInteger(requestedDurationUs) && requestedDurationUs > 0
      ? Math.min(requestedDurationUs, targetRange.durationUs)
      : targetRange.durationUs
    return {
      startUs: targetRange.startUs + Math.floor((targetRange.durationUs - durationUs) / 2),
      durationUs,
    }
  }

  // Template rich-text slots encode the authored cadence and must remain the
  // source of truth even when the automatic provider also returns a flower or
  // bubble recommendation.  The previous suppression made one recommendation
  // replace the entire template rhythm, leaving only a single flower in the
  // finalized timeline.
  const richTextSlotsByShot = new Map()
  const narrationDrivenRichText = Array.isArray(narrationSegments) && narrationSegments.length > 0
  const projectDurationUs = projectShotRanges.reduce(
    (maximum, range) => Math.max(maximum, range.startUs + range.durationUs),
    0,
  )
  /** @param {unknown} value */
  const normalizedCueText = (value) => typeof value === 'string'
    ? value.toLocaleLowerCase().replace(/[\s\p{P}\p{S}]+/gu, '')
    : ''
  // Cycled style-pool copies of the same brief keyword are not extra beats.
  // Keep the first instance so semantic voiceover matching stays enabled.
  const uniqueRichTextEntries = []
  const seenRichTextKeys = new Set()
  for (const entry of richTextEntries) {
    const key = normalizedCueText(entry?.text)
    if (!key || seenRichTextKeys.has(key)) continue
    seenRichTextKeys.add(key)
    uniqueRichTextEntries.push(clone(entry))
  }
  // Cycled style-pool copies inherit the long template's timestamps. After
  // collapsing them to unique copy, those times no longer describe the
  // current voiceover and would compress every leftover highlight into the
  // opening seconds. Semantic matching plus even shot fallback place them.
  if (uniqueRichTextEntries.length < richTextEntries.length) {
    for (const entry of uniqueRichTextEntries) {
      delete entry.templateStartUs
    }
  }
  const richTextCount = uniqueRichTextEntries.length
  // When the authored template exposes one FlowerText slot per current
  // sentence, the sentence order is the only unambiguous binding. Semantic
  // matching is useful for stale/partial templates, but it can map two
  // summary phrases to the same sentence and leave another sentence empty.
  const strictSentenceRichTextMapping = richTextCount === selectedItems.length &&
    richTextCount >= 8
  const allowSemanticRichTextMapping = true
  /** @param {string} cue @param {string} narration */
  const cueMatchesNarration = (cue, narration) => scoreSpokenCue(narration, cue) > 0
  /** @param {Record<string, any>} entry @param {number} index */
  const shotBindingForEntry = (entry, index) => {
    if (strictSentenceRichTextMapping) return { shotIndex: index, mapping: 'sentence' }
    if (typeof entry.targetSegmentId === 'string') {
      const targetIndex = selectedItems.findIndex((item) => item.sentence_id === entry.targetSegmentId)
      if (targetIndex >= 0) return { shotIndex: targetIndex, mapping: 'target' }
      // Template bindings can outlive a storyboard regeneration. Rebind a
      // stale target only when the authored cue has one unique semantic match
      // in the current narration; ambiguous or unmatched cues still fail
      // closed below.
      if (!narrationDrivenRichText) fail('WORKBENCH_TEMPLATE_RICH_TEXT_TARGET_UNRESOLVED', 409)
    }
    if (narrationDrivenRichText && allowSemanticRichTextMapping) {
      const entryText = normalizedCueText(entry.text)
      if (entryText.length >= 2) {
        const semanticMatches = selectedItems.flatMap((item, itemIndex) => {
          const cueText = normalizedCueText(item.voiceover_text)
          return cueMatchesNarration(entryText, cueText)
            ? [itemIndex]
            : []
        })
        if (semanticMatches.length === 1) return { shotIndex: semanticMatches[0], mapping: 'semantic' }
      }
      // Explicitly targeted slots must never drift to another sentence. A
      // template-owned untargeted slot, however, may contain project-authored
      // summary copy rather than a verbatim narration phrase. Preserve its
      // authored cadence by mapping the template time proportionally onto the
      // current finalized project duration.
      if (typeof entry.targetSegmentId === 'string') {
        fail('WORKBENCH_TEMPLATE_RICH_TEXT_TARGET_UNRESOLVED', 409)
      }
      const templateDurationUs = constraints?.targetDurationUs
      if (
        !usesUploadedDraftInventory(constraints) &&
        Number.isSafeInteger(entry.templateStartUs) &&
        entry.templateStartUs >= 0 &&
        Number.isSafeInteger(templateDurationUs) &&
        templateDurationUs > 0 &&
        projectDurationUs > 0
      ) {
        const templateCenterUs = Math.min(
          templateDurationUs - 1,
          entry.templateStartUs + Math.floor(entry.durationUs / 2),
        )
        const projectCueUs = Math.floor(
          templateCenterUs * projectDurationUs / templateDurationUs,
        )
        const cadenceIndex = projectShotRanges.findIndex((range) =>
          projectCueUs >= range.startUs && projectCueUs < range.startUs + range.durationUs)
        if (cadenceIndex >= 0) return { shotIndex: cadenceIndex, mapping: 'cadence' }
      }
      if (projectShotRanges.length <= 1 || richTextCount <= 1) return { shotIndex: 0, mapping: 'spread' }
      return {
        shotIndex: Math.round(index * (projectShotRanges.length - 1) / (richTextCount - 1)),
        mapping: 'spread',
      }
    }
    if (projectShotRanges.length <= 1 || richTextCount <= 1) return { shotIndex: 0, mapping: 'spread' }
    return {
      shotIndex: Math.floor(index * projectShotRanges.length / richTextCount),
      mapping: 'spread',
    }
  }
  for (let index = 0; index < richTextCount; index += 1) {
    const shotIndex = shotBindingForEntry(uniqueRichTextEntries[index], index).shotIndex
    richTextSlotsByShot.set(shotIndex, (richTextSlotsByShot.get(shotIndex) ?? 0) + 1)
  }
  /** @type {Array<{ entry: Record<string, any>, shotIndex: number, mapping: string, spoken: { startUs: number, durationUs: number } | null, aligned: boolean }>} */
  const richTextPlans = []
  for (let richTextIndex = 0; richTextIndex < richTextCount; richTextIndex += 1) {
    const entry = uniqueRichTextEntries[richTextIndex]
    if (
      typeof entry.text !== 'string' || !entry.text.trim() ||
      !Number.isSafeInteger(entry.durationUs) ||
      entry.durationUs <= 0
    ) fail('WORKBENCH_TEMPLATE_RICH_TEXT_INVALID', 409)
    const { shotIndex, mapping } = shotBindingForEntry(entry, richTextIndex)
    const shot = projectShotRanges[shotIndex]
    if (!shot) break
    let spokenShotIndex = shotIndex
    let spoken = spokenWindowForCue({
      cue: entry.text,
      voiceoverText: selectedItems[shotIndex]?.voiceover_text,
      range: shot,
      captionSpans: captionSpansByShot[shotIndex] ?? [],
    })
    if (!spoken) {
      for (const [searchIndex, item] of selectedItems.entries()) {
        spoken = spokenWindowForCue({
          cue: entry.text,
          voiceoverText: item.voiceover_text,
          range: projectShotRanges[searchIndex],
          captionSpans: captionSpansByShot[searchIndex] ?? [],
        })
        if (spoken) {
          spokenShotIndex = searchIndex
          break
        }
      }
    }
    richTextPlans.push({
      entry,
      shotIndex: spokenShotIndex,
      mapping,
      spoken,
      aligned: Boolean(spoken),
    })
  }
  const spokenAnchors = richTextPlans
    .map((plan, index) => ({ plan, index, window: plan.spoken }))
    .filter((item) => item.window)
  const clampedAnchors = clampSpokenWindows(
    spokenAnchors.map((item) => item.window),
    { startUs: 0, durationUs: Math.max(1, projectDurationUs) },
  )
  spokenAnchors.forEach((item, index) => {
    item.plan.spoken = clampedAnchors[index]
  })
  const occupiedByShot = new Map()
  const usedCaptionStarts = new Set()
  const reservedSpokenStarts = new Set(
    richTextPlans
      .filter((plan) => plan.aligned && plan.spoken)
      .map((plan) => plan.spoken.startUs),
  )
  const bindToLaterCaption = (plan, floorUs) => {
    let best = null
    for (const [shotIndex, spans] of captionSpansByShot.entries()) {
      if (!Array.isArray(spans)) continue
      for (const card of spans) {
        if (!Number.isSafeInteger(card.startUs) || card.startUs < floorUs) continue
        if (usedCaptionStarts.has(card.startUs)) continue
        if (
          reservedSpokenStarts.has(card.startUs) &&
          plan.spoken?.startUs !== card.startUs
        ) continue
        const score = scoreSpokenCue(card.text, plan.entry.text)
        if (score <= 0) continue
        if (
          !best ||
          score > best.score ||
          (score === best.score && card.startUs < best.card.startUs)
        ) {
          best = { card, shotIndex, score }
        }
      }
    }
    if (!best) return null
    const placed = {
      startUs: best.card.startUs,
      durationUs: Math.max(1, best.card.durationUs),
    }
    usedCaptionStarts.add(best.card.startUs)
    const occupied = occupiedByShot.get(best.shotIndex) ?? []
    occupied.push(placed)
    occupiedByShot.set(best.shotIndex, occupied)
    return { placed, placedShotIndex: best.shotIndex }
  }
  const laterSpokenExists = () =>
    richTextPlans.some((other) => other.aligned && other.spoken)
  const nextSpokenStartAfter = (floorUs) => {
    let next = Number.POSITIVE_INFINITY
    for (const other of richTextPlans) {
      if (other.aligned && other.spoken && other.spoken.startUs > floorUs) {
        next = Math.min(next, other.spoken.startUs)
      }
    }
    return next
  }
  const placeUnmatchedAfter = (plan, floorUs) => {
    const ceilingUs = nextSpokenStartAfter(floorUs)
    const candidates = projectShotRanges
      .map((shot, index) => ({ shot, index }))
      .filter(({ shot }) =>
        shot &&
        shot.startUs < ceilingUs &&
        shot.startUs + shot.durationUs > floorUs)
      .sort((left, right) => {
        if (left.index === plan.shotIndex) return -1
        if (right.index === plan.shotIndex) return 1
        return left.shot.startUs - right.shot.startUs
      })
    for (const { shot, index: shotIndex } of candidates) {
      const searchStartUs = Math.max(shot.startUs, floorUs)
      const searchEndUs = Math.min(shot.startUs + shot.durationUs, ceilingUs)
      const searchDurationUs = searchEndUs - searchStartUs
      if (searchDurationUs < 300_000) continue
      const occupied = occupiedByShot.get(shotIndex) ?? []
      const wantUs = Math.min(Math.max(plan.entry.durationUs, 400_000), searchDurationUs)
      let placed = placeWindowInGaps({
        startUs: searchStartUs,
        durationUs: searchDurationUs,
      }, occupied, wantUs)
      if (!placed && occupied.length === 0) {
        placed = { startUs: searchStartUs, durationUs: wantUs }
      }
      if (
        !placed ||
        placed.startUs < floorUs ||
        placed.startUs + placed.durationUs > ceilingUs
      ) continue
      occupied.push(placed)
      occupiedByShot.set(shotIndex, occupied)
      return { placed, placedShotIndex: shotIndex }
    }
    return null
  }
  let previousBriefStartUs = -1
  for (const plan of richTextPlans) {
    const orderFloorUs = previousBriefStartUs >= 0 ? previousBriefStartUs : 0
    if (plan.spoken && plan.spoken.startUs >= orderFloorUs) {
      const shotIndex = Number.isSafeInteger(plan.shotIndex) ? plan.shotIndex : 0
      const occupied = occupiedByShot.get(shotIndex) ?? []
      occupied.push(plan.spoken)
      occupiedByShot.set(shotIndex, occupied)
      usedCaptionStarts.add(plan.spoken.startUs)
      previousBriefStartUs = plan.spoken.startUs
      continue
    }
    const later = bindToLaterCaption(
      plan,
      previousBriefStartUs >= 0 ? previousBriefStartUs + 1 : 0,
    )
    if (later) {
      plan.spoken = later.placed
      plan.shotIndex = later.placedShotIndex
      plan.aligned = true
      previousBriefStartUs = later.placed.startUs
      continue
    }
    if (previousBriefStartUs < 0 && laterSpokenExists()) {
      plan.spoken = null
      plan.aligned = false
      continue
    }
    const unmatched = placeUnmatchedAfter(
      plan,
      previousBriefStartUs >= 0 ? previousBriefStartUs + 400_000 : 0,
    )
    if (!unmatched) {
      plan.spoken = null
      plan.aligned = false
      continue
    }
    plan.spoken = unmatched.placed
    plan.shotIndex = unmatched.placedShotIndex
    plan.aligned = false
    previousBriefStartUs = unmatched.placed.startUs
  }
  const placedPlans = richTextPlans.filter((plan) => plan.spoken)
  const placedByShot = new Map()
  for (const plan of placedPlans) {
    const group = placedByShot.get(plan.shotIndex) ?? []
    group.push(plan)
    placedByShot.set(plan.shotIndex, group)
  }
  for (const [shotIndex, plans] of placedByShot) {
    const shot = projectShotRanges[shotIndex]
    const ordered = [...plans].sort((left, right) =>
      (left.spoken?.startUs ?? 0) - (right.spoken?.startUs ?? 0))
    const readable = selectReadableFlowerWindows(
      ordered.map((plan) => ({
        startUs: plan.spoken.startUs,
        durationUs: plan.spoken.durationUs,
        aligned: plan.aligned !== false,
      })),
      { range: shot, preserveAlignedStarts: true },
    )
    const serialized = serializeOverlappingWindows(readable)
    ordered.forEach((plan, index) => {
      plan.spoken = serialized[index]
    })
  }
  const holdPlans = richTextPlans.filter((plan) => plan.spoken)
  if (holdPlans.length > 1) {
    const heldWindows = extendWindowsToCoverRange(
      holdPlans.map((plan) => plan.spoken),
      { startUs: 0, durationUs: Math.max(1, projectDurationUs) },
    )
    holdPlans.forEach((plan, index) => {
      plan.spoken = heldWindows[index]
    })
  }
  for (const [slotIndex, plan] of richTextPlans.entries()) {
    if (!plan.spoken) continue
    const usesPrivateTextToken =
      (plan.entry.capabilityId === 'text.flower.private' || plan.entry.capabilityId === 'text.bubble.private') &&
      typeof plan.entry.packagingToken === 'string' && plan.entry.packagingToken.trim().length > 0
    const sentenceText = plan.entry.text.trim()
    const material = {
      kind: 'rich_text',
      capabilityId: usesPrivateTextToken
        ? plan.entry.capabilityId
        : 'text.rich',
      targetRange: { startUs: plan.spoken.startUs, durationUs: plan.spoken.durationUs },
      text: sentenceText,
      styleToken: plan.entry.styleToken,
      templateToken: usesPrivateTextToken ? plan.entry.packagingToken : null,
      ...(typeof plan.entry.slotId === 'string' ? { templateSlotId: plan.entry.slotId } : {}),
    }
    titleSegments.push({
      segmentId: opaqueFromHash('seg', { ...material, slotIndex }),
      ...material,
      animationIn: null,
      animationOut: null,
    })
  }
  /** @param {Record<string, any>} entry @param {number} index */
  const spokenPackagingRange = (entry, index) => {
    const shotIndex = index % Math.max(1, projectShotRanges.length)
    const shot = projectShotRanges[shotIndex]
    if (!shot) return packagingTargetRange(entry, index)
    const flowerWindows = titleSegments
      .filter((segment) =>
        segment.kind === 'rich_text' &&
        segment.targetRange.startUs >= shot.startUs &&
        segment.targetRange.startUs < shot.startUs + shot.durationUs)
      .sort((left, right) => left.targetRange.startUs - right.targetRange.startUs)
      .map((segment) => segment.targetRange)
    const captionWindows = (captionSpansByShot[shotIndex] ?? []).map((span) => ({
      startUs: span.startUs,
      durationUs: span.durationUs,
    }))
    const hits = flowerWindows.length > 0 ? flowerWindows : captionWindows
    if (hits.length === 0) return packagingTargetRange(entry, index)
    const pick = hits[index % hits.length]
    const requested = Number(entry.durationUs)
    if (Number.isSafeInteger(requested) && requested > 0 && requested < pick.durationUs) {
      return {
        startUs: pick.startUs + Math.floor((pick.durationUs - requested) / 2),
        durationUs: requested,
      }
    }
    const durationUs = Number.isSafeInteger(requested) && requested > 0
      ? Math.min(requested, pick.durationUs)
      : pick.durationUs
    return { startUs: pick.startUs, durationUs: Math.max(1, durationUs) }
  }

  // Flower/bubble highlights replace ordinary auto-captions. Writers still
  // place both layers independently when a caption track is explicitly present.

  // Flower and bubble recommendations are title-track rich text, not generic effects.
  for (const [index, entry] of packagingSegments.entries()) {
    if (entry.family !== 'flower' && entry.family !== 'bubble') continue
    // A template-authored rich-text family already has its own multi-slot
    // cadence above. Do not append a second, one-off recommendation for the
    // same family; recommendations remain additive only for missing families.
    if (templateRichTextFamilies.has(entry.family)) continue
    const { startUs, durationUs } = packagingTargetRange(entry, index)
    if (!Number.isSafeInteger(startUs) || startUs < 0 || !Number.isSafeInteger(durationUs) || durationUs <= 0) continue
    const sourceItem = selectedItems.find((item) => item.sentence_id === entry.targetSegmentId)
    const text = derivePackagingEmphasisText(
      sourceItem?.voiceover_text,
      entry.family === 'flower' ? '重点' : '提示',
    )
    const material = {
      kind: 'rich_text',
      capabilityId: entry.capabilityId,
      targetRange: { startUs, durationUs },
      text,
      styleToken: 'rich_emphasis',
      templateToken: entry.parameters?.templateToken,
    }
    titleSegments.push({
      segmentId: opaqueFromHash('seg', { ...material, cueIndex: index }),
      ...material,
      animationIn: null,
      animationOut: null,
    })
  }

  tracks.push({
    trackId: opaqueFromHash('trk', { kind: 'video', role: 'primary', timelineId }),
    order: 0,
    enabled: true,
    locked: false,
    kind: 'video',
    role: 'primary',
    segments: videoSegments,
  })
  if (voiceoverSegments.length > 0) {
    tracks.push({
      trackId: opaqueFromHash('trk', { kind: 'audio', role: 'voiceover', timelineId }),
      order: tracks.length,
      enabled: true,
      locked: false,
      kind: 'audio',
      role: 'voiceover',
      segments: voiceoverSegments,
    })
  }
  if (captionSegments.length > 0) {
    tracks.push({
      trackId: opaqueFromHash('trk', { kind: 'caption', timelineId }),
      order: tracks.length,
      enabled: true,
      locked: false,
      kind: 'caption',
      segments: captionSegments,
    })
  }
  if (titleSegments.length > 0) {
    tracks.push({
      trackId: opaqueFromHash('trk', { kind: 'title', timelineId }),
      order: tracks.length,
      enabled: true,
      locked: false,
      kind: 'title',
      segments: titleSegments,
    })
  }
  if (bgm && cursor > 0) {
    const segmentMaterial = {
      kind: 'bgm',
      audioToken: bgm.audioToken,
      durationUs: cursor,
      volume: bgm.volume,
    }
    tracks.push({
      trackId: opaqueFromHash('trk', { kind: 'audio', role: 'bgm', timelineId }),
      order: tracks.length,
      enabled: true,
      locked: false,
      kind: 'audio',
      role: 'bgm',
      segments: [{
        segmentId: opaqueFromHash('seg', segmentMaterial),
        kind: 'bgm',
        capabilityId: 'audio.bgm.local',
        source: { kind: 'generated', generatedAudioId: bgm.audioToken },
        sourceRange: { startUs: 0, durationUs: cursor },
        targetRange: { startUs: 0, durationUs: cursor },
        volume: bgm.volume,
        fadeInUs: 0,
        fadeOutUs: 0,
        keyframes: [],
        ducking: 'under_voiceover',
      }],
    })
  }

  const flowerHits = titleSegments
    .filter((segment) => segment.kind === 'rich_text' && isRecord(segment.targetRange))
    .map((segment) => ({
      targetRange: segment.targetRange,
      text: typeof segment.text === 'string' ? segment.text : '',
      kind: 'flower',
    }))
  const firstSpokenFlowerUs = richTextPlans.reduce((first, plan) => {
    if (plan.aligned !== true || !plan.spoken) return first
    return first < 0 ? plan.spoken.startUs : Math.min(first, plan.spoken.startUs)
  }, -1)
  const flowerHitsForSfx = firstSpokenFlowerUs >= 0
    ? flowerHits.filter((hit) => hit.targetRange.startUs >= firstSpokenFlowerUs)
    : flowerHits
  const visualPackagingHits = packagingSegments
    .map((segment, index) => {
      if (!isRecord(segment) || segment.family === 'flower' || segment.family === 'bubble') return null
      const targetRange = spokenPackagingRange(segment, index)
      if (firstSpokenFlowerUs >= 0 && targetRange.startUs < firstSpokenFlowerUs) return null
      return {
        targetRange,
        text: segment.role === 'sticker' ? '贴纸卡点' : '特效卡点',
        kind: segment.role === 'sticker' ? 'sticker' : 'effect',
      }
    })
    .filter((hit) => hit !== null)
  const packagingHits = uniquePackagingHits([...flowerHitsForSfx, ...visualPackagingHits])
  const resolvedSfxCues = packagingHits.length > 0 && sfxCues.length > 0
    ? placeSfxPoolOnPackagingHits(sfxCues, packagingHits)
    : inheritedTemplateSfx
      ? []
      : sfxCues
  if (resolvedSfxCues.length > 0 && cursor > 0) {
    /** @type {Record<string, any>[]} */
    const sfxSegments = []
    for (const [cueIndex, cue] of resolvedSfxCues.entries()) {
      if (!isRecord(cue)) continue
      const audioToken = assertOpaqueTimelineId(cue.audioToken, 'invalid_sfx_audio_token')
      const volume = Number(cue.volume)
      const startUs = Number(cue.startUs)
      const durationUs = Number(cue.durationUs)
      if (
        !Number.isFinite(volume) || volume < 0 || volume > 1 ||
        !Number.isSafeInteger(startUs) || startUs < 0 ||
        !Number.isSafeInteger(durationUs) || durationUs <= 0
      ) {
        fail('invalid_sfx_cue')
      }
      const clampedDuration = Math.min(durationUs, Math.max(1, cursor - startUs))
      if (clampedDuration <= 0 || startUs >= cursor) continue
      const segmentMaterial = {
        kind: 'sfx',
        audioToken,
        startUs,
        durationUs: clampedDuration,
        volume,
        cueIndex,
      }
      sfxSegments.push({
        segmentId: opaqueFromHash('seg', segmentMaterial),
        kind: 'sfx',
        capabilityId: 'audio.sfx.local',
        source: { kind: 'generated', generatedAudioId: audioToken },
        sourceRange: { startUs: 0, durationUs: clampedDuration },
        targetRange: { startUs, durationUs: clampedDuration },
        volume,
        fadeInUs: 0,
        fadeOutUs: 0,
        keyframes: [],
        ducking: 'none',
      })
    }
    if (sfxSegments.length > 0) {
      tracks.push({
        trackId: opaqueFromHash('trk', { kind: 'audio', role: 'sfx', timelineId }),
        order: tracks.length,
        enabled: true,
        locked: false,
        kind: 'audio',
        role: 'sfx',
        segments: sfxSegments,
      })
    }
  }

  if (packagingSegments.length > 0 && cursor > 0) {
    /** @type {Record<string, any>[]} */
    const effectSegments = []
    for (const [index, segment] of packagingSegments.entries()) {
      if (!isRecord(segment)) continue
      const packagingToken = assertOpaqueTimelineId(
        segment.packagingToken,
        'invalid_packaging_token',
      )
      const { startUs, durationUs } = spokenPackagingRange(segment, index)
      if (
        !Number.isSafeInteger(startUs) || startUs < 0 ||
        !Number.isSafeInteger(durationUs) || durationUs <= 0
      ) continue
      const clampedDuration = Math.min(durationUs, Math.max(1, cursor - startUs))
      if (clampedDuration <= 0 || startUs >= cursor) continue
      if (segment.family === 'flower' || segment.family === 'bubble') continue
      const capabilityId = typeof segment.capabilityId === 'string'
        ? segment.capabilityId
        : segment.role === 'sticker' ? 'sticker.named' : 'effect.video.named'
      const segmentMaterial = {
        kind: 'effect',
        capabilityId,
        packagingToken,
        startUs,
        durationUs: clampedDuration,
        cueIndex: index,
      }
      effectSegments.push({
        segmentId: opaqueFromHash('seg', segmentMaterial),
        kind: 'effect',
        targetRange: { startUs, durationUs: clampedDuration },
        capabilityId,
        intensity: 1,
        parameters: {
          ...(isRecord(segment.parameters) ? clone(segment.parameters) : {}),
          packagingToken,
        },
      })
    }
    if (effectSegments.length > 0) {
      tracks.push({
        trackId: opaqueFromHash('trk', { kind: 'effect', timelineId }),
        order: tracks.length,
        enabled: true,
        locked: false,
        kind: 'effect',
        segments: effectSegments,
      })
    }
  }

  if (titleSegments.length > 0 && constraints?.templateSourceKind !== 'jianying_draft') {
    try {
      const laidOut = solvePackagingTextLayouts({ orientation, segments: titleSegments })
      titleSegments.splice(0, titleSegments.length, ...laidOut)
    } catch (error) {
      if (error instanceof PackagingTextLayoutError) fail(error.code)
      throw error
    }
  }

  const capabilityRequirements = computeCapabilityRequirements(tracks)
  if (constraints) {
    const byId = new Map(
      constraints.capabilityRequirements.map(
        (/** @type {Record<string, any>} */ requirement) => [
          requirement.capabilityId,
          requirement,
        ],
      ),
    )
    for (let index = 0; index < capabilityRequirements.length; index += 1) {
      const constrained = byId.get(capabilityRequirements[index].capabilityId)
      if (constrained) capabilityRequirements[index] = clone(constrained)
    }
  }
  const packagingCatalog = isRecord(input.packagingCatalog) ? input.packagingCatalog : null

  const draft = {
    schemaVersion: 1,
    timelineId,
    projectId,
    revision: 1,
    parentRevision: null,
    parentRevisionFingerprint: null,
    status: 'draft',
    createdAt,
    durationUs: cursor,
    orientation,
    fps,
    source: {
      kind: 'migration',
      editPlanFingerprint,
      templateFingerprint,
      ...(constraints ? { templateIdentity: clone(constraints.identity) } : {}),
      ...(input.automaticPackaging === true ? { automaticPackaging: true } : {}),
      ...(input.automaticPackaging === true && constraints
        ? {
            templatePackagingCoverage: ignoreCatalogRecommendation
              ? {
                  flower: (Array.isArray(constraints.richTextSegments) ? constraints.richTextSegments : [])
                    .filter((segment) =>
                      segment?.capabilityId === 'text.flower.private' ||
                      segment?.capabilityId === 'text.rich').length,
                  bubble: (Array.isArray(constraints.richTextSegments) ? constraints.richTextSegments : [])
                    .filter((segment) => segment?.capabilityId === 'text.bubble.private').length,
                }
              : {
                  flower: constraints.richTextSlots.filter((/** @type {Record<string, any>} */ slot) => slot.decorationKind === 'flower').length,
                  bubble: constraints.richTextSlots.filter((/** @type {Record<string, any>} */ slot) => slot.decorationKind === 'bubble').length,
                },
          }
        : {}),
      ...(input.automaticPackaging === true &&
        !ignoreCatalogRecommendation &&
        packagingCatalog &&
        typeof packagingCatalog.catalogFingerprint === 'string'
        ? { packagingCatalogFingerprint: packagingCatalog.catalogFingerprint }
        : {}),
      ...(input.automaticPackaging === true && Array.isArray(packagingRecommendationSelections)
        ? {
            packagingSelections: packagingRecommendationSelections.map((/** @type {PackagingSelection} */ selection) => ({
              packagingToken: selection.packagingToken,
              family: selection.family,
              label: selection.label,
              targetSegmentId: selection.targetSegmentId,
            })),
          }
        : {}),
      instructionFingerprint: null,
    },
    tracks,
    markers,
    capabilityRequirements,
  }

  ensureUniqueSegmentIds(tracks)

  try {
    return sealRichTimeline(draft)
  } catch (error) {
    if (error instanceof RichTimelineContractError) {
      fail(error.code)
    }
    throw error
  }
}
