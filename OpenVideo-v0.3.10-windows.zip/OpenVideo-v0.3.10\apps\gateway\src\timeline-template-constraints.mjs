import {
  buildStyleSummaryFromArtifact,
  getTemplateDemoCapabilities,
  isStyleSummary,
} from './template-style-profile.mjs'
import { encodeRecipeTextStyleToken } from './jianying-packaging-resolver.mjs'
import { buildPackagingResourceIntent, redactBriefText, resolvePackagingForExecution } from './brief-packaging.mjs'
import { recommendJianyingBatchTextPackaging } from './jianying-batch-text-packaging-catalog.mjs'
import { searchPackagingResourceCandidates } from './jianying-packaging-resource-index.mjs'
import { selectNonOverlappingPackagingItems } from './jianying-template-packaging-select.mjs'
import {
  assignTemplateStyleInventory,
  createTemplateStyleInventory,
  resolveAssignmentHighlights,
} from './template-style-inventory-assign.mjs'

const fingerprintPattern = /^[a-f0-9]{64}$/u
const opaquePattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u
const orientations = new Set(['portrait', 'landscape', 'square'])
const pacingValues = new Set(['calm', 'balanced', 'dynamic'])
const captionModes = new Set(['none', 'steady', 'burst'])
const implementedFallbacks = new Set([
  'transition.cut',
  'transition.none',
  'caption.basic',
])

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const opaque = (value) => typeof value === 'string' && opaquePattern.test(value)
/** @param {string} code @param {string | null} [capabilityId] @returns {never} */
const fail = (code, capabilityId = null) => {
  throw new TimelineTemplateConstraintsError(code, 409, capabilityId)
}

const currentPackagingCapabilities = Object.freeze({
  flower: 'text.flower.private',
  bubble: 'text.bubble.private',
  sticker: 'sticker.named',
  video_effect: 'effect.video.named',
})

/** Uploaded Jianying draft = writable inventory. No-template = model/catalog planning. */
export const usesUploadedDraftInventory = (value) => {
  if (!record(value)) return false
  if (value.templateSourceKind === 'jianying_draft') return true
  if (value.sourceKind === 'jianying_draft') return true
  if (record(value.source) && value.source.kind === 'jianying_draft') return true
  if (record(value.replicationRecipe) && record(value.replicationRecipe.source) &&
    value.replicationRecipe.source.kind === 'jianying_draft') {
    return true
  }
  return false
}

/** Rotate a template capability pool from current-project content, not source order.
 * @param {Record<string, any>[]} items @param {string} seed
 */
const rotateByContent = (items, seed) => {
  if (!Array.isArray(items) || items.length < 2) return items
  let hash = 2166136261
  for (const character of String(seed)) {
    hash ^= character.codePointAt(0) ?? 0
    hash = Math.imul(hash, 16777619) >>> 0
  }
  const offset = hash % items.length
  return [...items.slice(offset), ...items.slice(0, offset)]
}

/**
 * Derive bounded, project-specific emphasis copy when the user did not enter
 * explicit highlights. The script is guidance input only: it never supplies a
 * packaging token or a placement time, and the current project's shots still
 * own the final ranges.
 * @param {unknown} script
 * @returns {string[]}
 */
const scriptHighlights = (script) => {
  if (typeof script !== 'string') return []
  return script
    .split(/[\r\n。！？!?；;]+/u)
    .map((value) => redactBriefText(value).trim().slice(0, 32))
    .filter((value) => Boolean(value) && !value.startsWith('[已移除'))
    .slice(0, 12)
}

/**
 * Select only a structurally writable entry from the current admitted index.
 * The returned projection contains no private binding fields.
 * @param {unknown} index
 * @param {'flower'|'bubble'|'sticker'|'video_effect'} family
 * @param {{rotation?: number, noRepeatTokens?: string[], preferredToken?: string | null, query?: string}} [options]
 */
const recommendCurrentPackagingResource = (index, family, options = {}) => {
  if (index === null) return null
  try {
    const excluded = new Set(options.noRepeatTokens ?? [])
    /** @param {string} query */
    const search = (query) => searchPackagingResourceCandidates(index, query, {
      family,
      writerEligibleOnly: true,
      limit: 100,
    }).filter((candidate) => !excluded.has(candidate.packagingToken))
    const semanticQuery = typeof options.query === 'string' ? options.query.trim() : ''
    const candidates = semanticQuery ? search(semanticQuery) : search('')
    const eligibleCandidates = candidates.length > 0 ? candidates : search('')
    if (eligibleCandidates.length === 0) return null
    const rotation = Number.isSafeInteger(options.rotation) ? Math.max(0, Number(options.rotation)) : 0
    const candidate = eligibleCandidates.find((item) => item.packagingToken === options.preferredToken) ??
      eligibleCandidates[rotation % eligibleCandidates.length]
    return {
      packagingToken: candidate.packagingToken,
      capabilityId: currentPackagingCapabilities[family],
    }
  } catch {
    return null
  }
}

export class TimelineTemplateConstraintsError extends Error {
  /**
   * @param {string} code
   * @param {number} [status]
   * @param {string | null} [capabilityId]
   */
  constructor(code, status = 409, capabilityId = null) {
    super(code)
    this.name = 'TimelineTemplateConstraintsError'
    this.code = code
    this.status = status
    this.capabilityId = capabilityId
  }
}

/** @param {Record<string, any>} guidance */
const assertGuidance = (guidance) => {
  if (
    guidance.schemaVersion !== 1 ||
    guidance.source !== 'project_template_binding' ||
    !opaque(guidance.libraryTemplateId) ||
    !Number.isSafeInteger(guidance.revision) ||
    guidance.revision < 1 ||
    typeof guidance.fingerprint !== 'string' ||
    !fingerprintPattern.test(guidance.fingerprint) ||
    !orientations.has(guidance.orientation) ||
    !pacingValues.has(guidance.pacing) ||
    !Number.isSafeInteger(guidance.targetDurationMs) ||
    guidance.targetDurationMs < 1 ||
    !Array.isArray(guidance.slots) ||
    guidance.slots.length < 1 ||
    !record(guidance.rules) ||
    !record(guidance.rules.captionCadence) ||
    !record(guidance.rules.packaging) ||
    (
      guidance.styleProfile !== undefined &&
      !isStyleSummary(guidance.styleProfile)
    )
  ) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
}

/**
 * @param {Record<string, any>} styleProfile
 * @param {string} capabilityId
 */
const capabilityDecision = (styleProfile, capabilityId) => {
  if (capabilityId === 'transition.none') {
    return { acceptance: 'implemented', degradationCode: null }
  }
  const declared = getTemplateDemoCapabilities(styleProfile).find(
    (/** @type {Record<string, any>} */ entry) => entry.id === capabilityId,
  )
  // Template constraints accept StyleProfile demo declarations for binding-time
  // packaging decisions. Formal Preview/Jianying writers still fail closed via
  // editor-capability-registry and must not treat this list as writer truth.
  const status = declared?.status ??
    (implementedFallbacks.has(capabilityId) ? 'implemented' : 'unsupported')
  if (status === 'unsupported') {
    fail('WORKBENCH_TEMPLATE_CAPABILITY_UNSUPPORTED', capabilityId)
  }
  if (status === 'degraded') {
    if (capabilityId === 'title.card') {
      return {
        acceptance: /** @type {const} */ ('implemented'),
        degradationCode: null,
      }
    }
    return {
      acceptance: /** @type {const} */ ('degraded'),
      degradationCode: capabilityId === 'title.card'
        ? 'TEMPLATE_TITLE_CARD_PREVIEW_DEGRADED'
        : 'TEMPLATE_CAPABILITY_DEGRADED',
    }
  }
  return {
    acceptance: /** @type {const} */ ('implemented'),
    degradationCode: null,
  }
}

/** @param {string} transitionOut */
const transitionCapability = (transitionOut) => {
  if (transitionOut === 'none') return 'transition.none'
  if (transitionOut === 'cut') return 'transition.cut'
  if (transitionOut === 'dissolve') return 'transition.dissolve'
  if (transitionOut === 'wipe') return 'transition.wipe'
  if (transitionOut === 'match_cut') return 'transition.match_cut'
  fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
}

/** @param {Record<string, any>} guidance @param {Record<string, any>} styleProfile */
const captionConstraint = (guidance, styleProfile) => {
  const cadence = guidance.rules.captionCadence
  if (!captionModes.has(cadence.mode)) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  if (cadence.mode === 'none') return null
  const recipe = record(guidance.replicationRecipe) ? guidance.replicationRecipe : null
  const recipeCaption = Array.isArray(recipe?.textSegments)
    ? recipe.textSegments.find((segment) => record(segment) && segment.role === 'caption')
    : null
  const capabilityId = guidance.rules.packaging.subtitleStyle === 'bottom_safe'
    ? 'caption.bottom_safe'
    : 'caption.basic'
  capabilityDecision(styleProfile, capabilityId)
  let styleToken = capabilityId === 'caption.bottom_safe'
    ? 'caption-bottom-safe'
    : 'caption-basic'
  if (recipe?.source?.kind === 'jianying_draft' && record(recipeCaption?.style)) {
    const learnedSize = Number(recipeCaption.style.size)
    // Bound Jianying Subtitles own size and position. Do not invent a larger
    // display caption when the authored draft already has a finished look.
    styleToken = encodeRecipeTextStyleToken({
      size: Number.isFinite(learnedSize) && learnedSize > 0 ? learnedSize : 7.8,
      color: recipeCaption.style.color,
      transformY: Number.isFinite(Number(recipeCaption.style.transformY))
        ? Number(recipeCaption.style.transformY)
        : -0.88,
    })
  }
  return {
    capabilityId,
    styleToken,
    cadence: {
      mode: cadence.mode,
      ...(Number.isSafeInteger(cadence.maxCharsPerCard)
        ? { maxCharsPerCard: cadence.maxCharsPerCard }
        : {}),
      ...(Number.isSafeInteger(cadence.cardsPerMinute)
        ? { cardsPerMinute: cadence.cardsPerMinute }
        : {}),
    },
  }
}

/** @param {unknown} input @returns {Record<string, any>} */
export const assertTimelineTemplateConstraints = (input) => {
  if (!record(input)) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  const value = /** @type {Record<string, any>} */ (input)
  if (
    value.schemaVersion !== 1 ||
    !record(value.identity) ||
    !opaque(value.identity.libraryTemplateId) ||
    !Number.isSafeInteger(value.identity.revision) ||
    value.identity.revision < 1 ||
    typeof value.identity.fingerprint !== 'string' ||
    !fingerprintPattern.test(value.identity.fingerprint) ||
    !orientations.has(value.orientation) ||
    !pacingValues.has(value.pacing) ||
    !Number.isSafeInteger(value.targetDurationUs) ||
    value.targetDurationUs < 1 ||
    !Array.isArray(value.slots) ||
    value.slots.length < 1 ||
    !Array.isArray(value.capabilityRequirements) ||
    !record(value.titleCards)
  ) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  for (let index = 0; index < value.slots.length; index += 1) {
    const slot = value.slots[index]
    if (
      !record(slot) ||
      slot.order !== index + 1 ||
      !opaque(slot.role) ||
      !Number.isSafeInteger(slot.durationUs) ||
      slot.durationUs < 1 ||
      !record(slot.transitionOut) ||
      typeof slot.transitionOut.capabilityId !== 'string' ||
      !Number.isSafeInteger(slot.transitionOut.durationUs) ||
      !record(slot.transitionOut.parameters)
    ) {
      fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
    }
  }
  if (
    value.slots.reduce(
      (total, /** @type {Record<string, any>} */ slot) => total + slot.durationUs,
      0,
    ) !== value.targetDurationUs
  ) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  if (
    value.caption !== null &&
    (
      !record(value.caption) ||
      !['caption.basic', 'caption.bottom_safe'].includes(value.caption.capabilityId) ||
      !opaque(value.caption.styleToken) ||
      !record(value.caption.cadence) ||
      !captionModes.has(value.caption.cadence.mode)
    )
  ) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  for (const key of ['intro', 'outro']) {
    const card = value.titleCards[key]
    if (
      card !== null &&
      (
        !record(card) ||
        card.capabilityId !== 'title.card' ||
        !['implemented', 'degraded'].includes(card.acceptance) ||
        !(
          card.degradationCode === null ||
          typeof card.degradationCode === 'string'
        )
      )
    ) {
      fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
    }
  }
  const requirementIds = new Set()
  for (const requirement of value.capabilityRequirements) {
    if (
      !record(requirement) ||
      typeof requirement.capabilityId !== 'string' ||
      requirementIds.has(requirement.capabilityId) ||
      !['implemented', 'degraded'].includes(requirement.acceptance) ||
      !(
        requirement.degradationCode === null ||
        typeof requirement.degradationCode === 'string'
      )
    ) {
      fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
    }
    requirementIds.add(requirement.capabilityId)
  }
  if (value.bgm !== undefined && value.bgm !== null) {
    if (
      !record(value.bgm) ||
      !opaque(value.bgm.audioToken) ||
      typeof value.bgm.volume !== 'number' ||
      !Number.isFinite(value.bgm.volume) ||
      value.bgm.volume < 0 ||
      value.bgm.volume > 1
    ) {
      fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
    }
  }
  if (value.sfx !== undefined) {
    if (!Array.isArray(value.sfx)) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
    for (const cue of value.sfx) {
      if (
        !record(cue) ||
        !opaque(cue.audioToken) ||
        typeof cue.volume !== 'number' ||
        !Number.isFinite(cue.volume) ||
        cue.volume < 0 ||
        cue.volume > 1 ||
        !Number.isSafeInteger(cue.startUs) ||
        cue.startUs < 0 ||
        !Number.isSafeInteger(cue.durationUs) ||
        cue.durationUs <= 0
      ) {
        fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
      }
    }
  }
  if (value.packagingSegments !== undefined) {
    if (!Array.isArray(value.packagingSegments)) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
    for (const segment of value.packagingSegments) {
      if (
        !record(segment) ||
        !opaque(segment.packagingToken) ||
        !['sticker', 'effect'].includes(segment.role) ||
        !Number.isSafeInteger(segment.startUs) ||
        segment.startUs < 0 ||
        !Number.isSafeInteger(segment.durationUs) ||
        segment.durationUs <= 0
      ) {
        fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
      }
    }
  }
  if (
    (value.richTextSlots !== undefined && !Array.isArray(value.richTextSlots)) ||
    (value.richTextSegments !== undefined && !Array.isArray(value.richTextSegments))
  ) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  for (const slot of value.richTextSlots ?? []) {
    if (
      !record(slot) ||
      !Number.isSafeInteger(slot.startUs) || slot.startUs < 0 ||
      !Number.isSafeInteger(slot.durationUs) || slot.durationUs <= 0 ||
      !opaque(slot.styleToken) ||
      (slot.slotId !== undefined && !opaque(slot.slotId)) ||
      !(slot.packagingToken === null || opaque(slot.packagingToken)) ||
      !(slot.decorationKind === null || ['flower', 'bubble'].includes(slot.decorationKind))
    ) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  for (const segment of value.richTextSegments ?? []) {
    if (
      !record(segment) ||
      typeof segment.text !== 'string' || !segment.text.trim() || segment.text.length > 160 ||
      !Number.isSafeInteger(segment.durationUs) || segment.durationUs <= 0 ||
      !(
        segment.anchor === 'project_shot' ||
        (Number.isSafeInteger(segment.startUs) && segment.startUs >= 0 && segment.startUs + segment.durationUs <= value.targetDurationUs)
      ) ||
      (segment.templateStartUs !== undefined &&
        (!Number.isSafeInteger(segment.templateStartUs) || segment.templateStartUs < 0)) ||
      !opaque(segment.styleToken) ||
      (segment.slotId !== undefined && !opaque(segment.slotId)) ||
      (segment.targetSegmentId !== undefined && !opaque(segment.targetSegmentId)) ||
      !(segment.packagingToken === null || opaque(segment.packagingToken))
    ) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  return value
}

/**
 * Converts an immutable binding guidance snapshot into the only template
 * constraints accepted by RichTimeline draft construction.
 * @param {unknown} input
 */
export const createTimelineTemplateConstraints = (input) => {
  if (!record(input)) fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  const guidance = /** @type {Record<string, any>} */ (input)
  assertGuidance(guidance)
  const styleProfile = guidance.styleProfile ?? buildStyleSummaryFromArtifact({
    draft: {
      slots: guidance.slots.map((/** @type {Record<string, any>} */ slot) => ({
        transition_out: slot.transitionOut,
      })),
      rules: {
        pacing: guidance.pacing,
        caption_cadence: {
          mode: guidance.rules.captionCadence.mode,
        },
        packaging: {
          intro: guidance.rules.packaging.intro,
          outro: guidance.rules.packaging.outro,
          subtitle_style: guidance.rules.packaging.subtitleStyle,
        },
      },
    },
    analysis: {},
  })
  const recipe = record(guidance.replicationRecipe) ? guidance.replicationRecipe : null
  const recipeSlots = Array.isArray(recipe?.videoSlots)
    ? recipe.videoSlots.filter((slot) =>
      record(slot) &&
      Number.isSafeInteger(slot.durationUs) &&
      slot.durationUs > 0)
    : []
  const slots = [...guidance.slots]
    .sort((left, right) => left.order - right.order)
    .map((slot, index, all) => {
      if (
        !record(slot) ||
        slot.order !== index + 1 ||
        !opaque(slot.role) ||
        !Number.isSafeInteger(slot.recommendedDurationMs) ||
        slot.recommendedDurationMs < 1
      ) {
        fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
      }
      const capabilityId = transitionCapability(slot.transitionOut)
      if (
        (index === all.length - 1 && capabilityId !== 'transition.none') ||
        (index < all.length - 1 && capabilityId === 'transition.none')
      ) {
        fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
      }
      capabilityDecision(styleProfile, capabilityId)
      // Prefer structural recipe slot durations when the slot count matches.
      const recipeDurationUs = recipeSlots.length === all.length
        ? recipeSlots[index].durationUs
        : null
      return {
        order: slot.order,
        role: slot.role,
        durationUs: recipeDurationUs ?? slot.recommendedDurationMs * 1_000,
        transitionOut: {
          capabilityId,
          durationUs: 0,
          parameters: {},
        },
      }
    })
  const targetDurationUs = recipeSlots.length === slots.length
    ? slots.reduce((total, slot) => total + slot.durationUs, 0)
    : guidance.targetDurationMs * 1_000
  if (!Number.isSafeInteger(targetDurationUs) || targetDurationUs < 1) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }
  if (
    slots.some((slot) => !Number.isSafeInteger(slot.durationUs) || slot.durationUs < 1) ||
    slots.reduce((total, slot) => total + slot.durationUs, 0) !== targetDurationUs
  ) {
    fail('WORKBENCH_TEMPLATE_CONSTRAINTS_INVALID')
  }

  const caption = captionConstraint(guidance, styleProfile)
  const packaging = guidance.rules.packaging
  const titleCards = {
    intro: packaging.intro === 'title_card'
      ? {
          capabilityId: 'title.card',
          ...capabilityDecision(styleProfile, 'title.card'),
        }
      : null,
    outro: packaging.outro === 'title_card'
      ? {
          capabilityId: 'title.card',
          ...capabilityDecision(styleProfile, 'title.card'),
        }
      : null,
  }
  const capabilityIds = new Set(slots.map((slot) => slot.transitionOut.capabilityId))
  if (caption) capabilityIds.add(caption.capabilityId)
  if (titleCards.intro || titleCards.outro) capabilityIds.add('title.card')

  /** @type {{ audioToken: string, volume: number } | null} */
  let bgm = null
  /** @type {Array<{ audioToken: string, volume: number, startUs: number, durationUs: number }>} */
  const sfx = []
  /** @type {Array<{ packagingToken: string, role: 'sticker' | 'effect', startUs: number, durationUs: number }>} */
  const packagingSegments = []
  const recipeRichTextSegments = Array.isArray(recipe?.textSegments)
    ? recipe.textSegments.filter((segment) => record(segment) && segment.role === 'rich_text')
    : []
  // Older template recipes recorded only aggregate flower coverage. Preserve
  // that authored intent for unannotated rich-text slots, without treating a
  // recipe token as writer authorization.
  const recipeFlowerTextCount = recipe?.packaging?.flowerTextCount
  let inferredFlowerSlotsRemaining = Number.isSafeInteger(recipeFlowerTextCount)
    ? Math.max(0, Number(recipeFlowerTextCount))
    : 0
  // `flowerTextCount` is the authored style-pool size, while the extracted
  // recipe may contain fewer representative segments (older drafts commonly
  // expose only one segment per visual variant). Expand the pool by cycling
  // those real authored segments so later packaging can reuse the actual
  // template materials instead of falling back to plain text.
  const authoredRichSlotCount = Math.max(
    recipeRichTextSegments.length,
    Number.isSafeInteger(recipeFlowerTextCount) ? Math.max(0, Number(recipeFlowerTextCount)) : 0,
  )
  const richTextSourceSegments = authoredRichSlotCount > 0 && recipeRichTextSegments.length > 0
    ? Array.from({ length: authoredRichSlotCount }, (_, index) => recipeRichTextSegments[index % recipeRichTextSegments.length])
    : recipeRichTextSegments
  const richTextSlots = richTextSourceSegments.map((segment, segmentIndex) => {
    const explicitDecorationKind = ['flower', 'bubble'].includes(segment.decorationKind)
      ? segment.decorationKind
      : null
    const decorationKind = explicitDecorationKind ??
      (inferredFlowerSlotsRemaining > 0 ? 'flower' : null)
    if (explicitDecorationKind === null && decorationKind === 'flower') {
      inferredFlowerSlotsRemaining -= 1
    }
    return {
      startUs: segment.startUs,
      durationUs: segment.durationUs,
      styleToken: record(segment.style)
        ? encodeRecipeTextStyleToken(segment.style)
        : 'rich-emphasis',
      packagingToken: typeof segment.packagingToken === 'string'
        ? segment.packagingToken
        : null,
      decorationKind,
      // Keep the distinction between a decoration explicitly authored in the
      // source draft and one inferred from the aggregate flowerTextCount.
      // Inferred slots still need a current admitted catalog binding; only an
      // explicitly authored decoration may bypass catalog substitution.
      authoredDecorationKind: explicitDecorationKind,
      style: record(segment.style) ? segment.style : null,
      ...(typeof segment.slotId === 'string'
        ? { slotId: segmentIndex < recipeRichTextSegments.length ? segment.slotId : `${segment.slotId}-${segmentIndex + 1}` }
        : { slotId: `template-rich-${segmentIndex + 1}` }),
    }
  })

  if (recipe) {
    const bgmCue = Array.isArray(recipe.audioCues)
      ? recipe.audioCues.find((cue) =>
        record(cue) &&
        cue.role === 'bgm' &&
        typeof cue.audioToken === 'string' &&
        opaque(cue.audioToken))
      : null
    if (bgmCue) {
      bgm = {
        audioToken: bgmCue.audioToken,
        volume: typeof bgmCue.volume === 'number' && Number.isFinite(bgmCue.volume)
          ? Math.max(0, Math.min(1, bgmCue.volume))
          : 0.18,
      }
      capabilityIds.add('audio.bgm.local')
    }
    for (const cue of Array.isArray(recipe.audioCues) ? recipe.audioCues : []) {
      if (
        !record(cue) ||
        cue.role !== 'sfx' ||
        typeof cue.audioToken !== 'string' ||
        !opaque(cue.audioToken) ||
        !Number.isSafeInteger(cue.startUs) ||
        !Number.isSafeInteger(cue.durationUs) ||
        cue.durationUs <= 0
      ) continue
      // startUs/durationUs describe the original sound file window, not a
      // project placement. The adapter treats this list as a reusable pool.
      sfx.push({
        audioToken: cue.audioToken,
        volume: typeof cue.volume === 'number' && Number.isFinite(cue.volume)
          ? Math.max(0, Math.min(1, cue.volume))
          : 1,
        startUs: cue.startUs,
        durationUs: cue.durationUs,
      })
      capabilityIds.add('audio.sfx.local')
    }
    for (const segment of Array.isArray(recipe.packagingSegments) ? recipe.packagingSegments : []) {
      if (
        !record(segment) ||
        typeof segment.packagingToken !== 'string' ||
        !opaque(segment.packagingToken) ||
        !['sticker', 'effect'].includes(segment.role) ||
        !Number.isSafeInteger(segment.startUs) ||
        !Number.isSafeInteger(segment.durationUs) ||
        segment.durationUs <= 0
      ) continue
      packagingSegments.push({
        packagingToken: segment.packagingToken,
        role: segment.role,
        startUs: segment.startUs,
        durationUs: segment.durationUs,
      })
      capabilityIds.add(segment.role === 'sticker' ? 'sticker.named' : 'effect.video.named')
    }
  }

  const capabilityRequirements = [...capabilityIds]
    .sort((left, right) => left.localeCompare(right))
    .map((capabilityId) => {
      if (
        capabilityId === 'audio.bgm.local' ||
        capabilityId === 'audio.sfx.local' ||
        capabilityId === 'effect.video.named' ||
        capabilityId === 'sticker.named'
      ) {
        const recipeEntry = Array.isArray(recipe?.capabilities)
          ? recipe.capabilities.find((entry) => record(entry) && entry.id === capabilityId)
          : null
        if (
          recipeEntry &&
          (
            recipeEntry.previewStatus === 'degraded' ||
            (
              recipeEntry.jianyingStatus === 'implemented' &&
              recipeEntry.previewStatus !== 'implemented'
            )
          )
        ) {
          return {
            capabilityId,
            acceptance: /** @type {const} */ ('degraded'),
            degradationCode: capabilityId === 'audio.sfx.local'
              ? 'SFX_PREVIEW_DEGRADED'
              : capabilityId === 'sticker.named'
                ? 'STICKER_PREVIEW_UNSUPPORTED'
                : capabilityId === 'effect.video.named'
                  ? 'EFFECT_PREVIEW_UNSUPPORTED'
                  : 'TEMPLATE_CAPABILITY_DEGRADED',
          }
        }
        if (capabilityId === 'audio.bgm.local') {
          return {
            capabilityId,
            acceptance: /** @type {const} */ ('implemented'),
            degradationCode: null,
          }
        }
        if (capabilityId === 'audio.sfx.local') {
          return {
            capabilityId,
            acceptance: /** @type {const} */ ('implemented'),
            degradationCode: null,
          }
        }
        return {
          capabilityId,
          acceptance: /** @type {const} */ ('degraded'),
          degradationCode: 'TEMPLATE_CAPABILITY_DEGRADED',
        }
      }
      return {
        capabilityId,
        ...capabilityDecision(styleProfile, capabilityId),
      }
    })

  return assertTimelineTemplateConstraints({
    schemaVersion: 1,
    identity: {
      libraryTemplateId: guidance.libraryTemplateId,
      revision: guidance.revision,
      fingerprint: guidance.fingerprint,
    },
    // Keep the source provenance available to the packaging pass. A real
    // Jianying blueprint can preserve authored resources through the private
    // overlay; synthetic/legacy recipes retain the historical catalog path.
    templateSourceKind: recipe?.source?.kind ?? null,
    orientation: guidance.orientation,
    pacing: guidance.pacing,
    targetDurationUs,
    slots,
    caption,
    titleCards,
    capabilityRequirements,
    bgm,
    sfx,
    packagingSegments,
    richTextSlots,
    richTextSegments: [],
  })
}

/**
 * Apply only planner choices that can be expressed with already-authorized,
 * template-bound tokens. It never invents a private resource token.
 * @param {unknown} input
 * @param {unknown} packagingInput
 * @param {unknown} briefInput
 * @param {{entries: readonly any[], profile_id: string, evidence_profile: Record<string, unknown>} | null} [batchTextCatalog]
 * @param {Record<string, any> | null} [packagingResourceIndex]
 */
export const applyPackagingPlanToTimelineTemplateConstraints = (
  input,
  packagingInput,
  briefInput = null,
  batchTextCatalog = null,
  packagingResourceIndex = null,
) => {
  const constraints = structuredClone(assertTimelineTemplateConstraints(input))
  constraints.richTextSlots = Array.isArray(constraints.richTextSlots) ? constraints.richTextSlots : []
  constraints.richTextSegments = Array.isArray(constraints.richTextSegments) ? constraints.richTextSegments : []
  const packaging = resolvePackagingForExecution(packagingInput)
  const styleAssignments = record(packagingInput) && Array.isArray(packagingInput.styleAssignments)
    ? packagingInput.styleAssignments
    : []
  const packagingResourceIntent = buildPackagingResourceIntent(packaging)
  const followsAuthoredBlueprint = constraints.templateSourceKind === 'jianying_draft'

  const explicitHighlights = packaging.keywordHighlights
    .map((value) => redactBriefText(value).trim().slice(0, 32))
    .filter((value) => Boolean(value) && !value.startsWith('[已移除'))
  const brief = record(briefInput) ? briefInput : {}
  const fallbackTitleAndSelling = [
    brief.title,
    ...(Array.isArray(brief.sellingPoints) ? brief.sellingPoints : []),
  ]
    .filter((value) => typeof value === 'string')
    .map((value) => redactBriefText(value).trim().slice(0, 32))
    .filter((value) => Boolean(value) && !value.startsWith('[已移除'))
  const fallbackHighlights = explicitHighlights.length > 0 || packaging.enabled === false
    ? []
    : fallbackTitleAndSelling.length > 0
      ? fallbackTitleAndSelling
      : scriptHighlights(brief.script)
        .filter((value) => typeof value === 'string')
        .map((value) => redactBriefText(value).trim().slice(0, 32))
        .filter((value) => Boolean(value) && !value.startsWith('[已移除'))
  const seenHighlights = new Set()
  const keywordHighlights = [...explicitHighlights, ...fallbackHighlights].filter((value) => {
    const key = value.toLocaleLowerCase()
    if (seenHighlights.has(key)) return false
    seenHighlights.add(key)
    return true
  })
  const contentSeed = [
    brief.title,
    brief.script,
    packaging.packagingNotes,
    ...keywordHighlights,
  ].filter((value) => typeof value === 'string').join('|')

  // A learned template may contain authored flower/bubble slots even when the
  // brief has no explicit keyword list. Fill those slots from the current
  // selected-shot copy so the template's decoration/style is retained rather
  // than silently collapsing to a generic or empty text track.
  const selectedShotCopy = typeof brief.script === 'string'
    ? brief.script
      .split(/[。！？!?；;\n]+/u)
      .map((value) => redactBriefText(value).trim().slice(0, 80))
      .filter((value) => value && !value.startsWith('[已移除'))
    : []
  const richTextHighlights = (keywordHighlights.length > 0 ? keywordHighlights : selectedShotCopy).filter((value, index, values) =>
    values.findIndex((candidate) => candidate.toLocaleLowerCase() === value.toLocaleLowerCase()) === index)

  if (packaging.transitionStyle === 'cut') {
    constraints.slots = constraints.slots.map((
      /** @type {Record<string, any>} */ slot,
      /** @type {number} */ index,
      /** @type {Record<string, any>[]} */ slots,
    ) => ({
      ...slot,
      transitionOut: index === slots.length - 1
        ? { capabilityId: 'transition.none', durationUs: 0, parameters: {} }
        : { capabilityId: 'transition.cut', durationUs: 0, parameters: {} },
    }))
    constraints.capabilityRequirements = constraints.capabilityRequirements
      .filter((/** @type {Record<string, any>} */ requirement) => !requirement.capabilityId.startsWith('transition.'))
    for (const capabilityId of ['transition.cut', 'transition.none']) {
      if (constraints.slots.some((/** @type {Record<string, any>} */ slot) => slot.transitionOut.capabilityId === capabilityId)) {
        constraints.capabilityRequirements.push({
          capabilityId,
          acceptance: 'implemented',
          degradationCode: null,
        })
      }
    }
  }

  let packagingSegments = Array.isArray(constraints.packagingSegments)
    ? constraints.packagingSegments
    : []
  // An uploaded Jianying draft is the only writable visual inventory.
  // Catalog tokens must not replace or extend that inventory after learning.
  if (followsAuthoredBlueprint) {
    packagingSegments = []
  }
  if (packaging.stickerMode === 'none') {
    packagingSegments = packagingSegments.filter((segment) => segment.role !== 'sticker')
  }
  const densityLimit = packaging.packagingDensity === 'light'
    ? 1
    : packaging.packagingDensity === 'balanced'
      ? 2
      : Number.POSITIVE_INFINITY
  if (Number.isFinite(densityLimit)) {
    const retainedByRole = new Map()
    packagingSegments = packagingSegments.filter((segment) => {
      const retained = retainedByRole.get(segment.role) ?? 0
      if (retained >= densityLimit) return false
      retainedByRole.set(segment.role, retained + 1)
      return true
    })
  }
  packagingSegments = rotateByContent(packagingSegments, contentSeed)
  const familyRotations = new Map()
  packagingSegments = packagingSegments.flatMap((segment) => {
    const family = segment.role === 'sticker' ? 'sticker' : 'video_effect'
    // Authored sticker/effect tracks are copied from the private blueprint
    // overlay when the request follows the selected template. Their `pkg_*`
    // recipe tokens are intentionally not allowed into canonical packaging,
    // where they could be mistaken for current catalog bindings.
    if (
      followsAuthoredBlueprint &&
      (
        (family === 'sticker' && packaging.stickerMode === 'follow_template') ||
        (family === 'video_effect' && packaging.visualStyle === 'follow_template')
      )
    ) return []
    const rotation = familyRotations.get(family) ?? 0
    familyRotations.set(family, rotation + 1)
    let recommendation = recommendCurrentPackagingResource(packagingResourceIndex, family, {
      rotation,
      preferredToken: segment.packagingToken,
    })
    if (
      recommendation === null &&
      packagingResourceIndex === null &&
      family === 'sticker' &&
      batchTextCatalog !== null
    ) {
      try {
        recommendation = recommendJianyingBatchTextPackaging(batchTextCatalog, {
          kind: 'sticker',
          intentTags: [packaging.visualStyle, packaging.packagingDensity],
          rotation,
          requireEvidence: true,
        })
      } catch { /* no admitted sticker remains fail-closed */ }
    }
    return recommendation === null
      ? []
      : [{ ...segment, packagingToken: recommendation.packagingToken }]
  })
  constraints.packagingSegments = packagingSegments

  const desiredDecoration = packaging.emphasisStyle === 'flower_text'
    ? 'flower'
    : packaging.emphasisStyle === 'bubble'
      ? 'bubble'
      : null
  const followsTemplateDecorations = packaging.emphasisStyle === 'follow_template'
  if (desiredDecoration !== null || followsTemplateDecorations) {
    /** @type {string[]} */
    const noRepeatTokens = []
    // Inventory looks stay writable. Current copy, not draft ordinal, decides
    // which highlight receives which authored style.
    constraints.richTextSlots = constraints.richTextSlots
      .map((/** @type {Record<string, any>} */ slot, /** @type {number} */ index) => {
      const decorationKind = desiredDecoration ?? slot.decorationKind
      if (!decorationKind || slot.decorationKind !== decorationKind) {
        // A recipe token alone is never a writer authorization. It may remain
        // as style guidance, but cannot cross into a RichTimeline segment.
        return { ...slot, packagingToken: null, capabilityId: 'text.rich' }
      }
      if (followsAuthoredBlueprint) {
        // Select from the uploaded draft only. Never invent a catalog look
        // after the draft has become the project template.
        return { ...slot, packagingToken: null, capabilityId: 'text.rich' }
      }
      let currentRecommendation = recommendCurrentPackagingResource(
        packagingResourceIndex,
        decorationKind,
        {
          rotation: index,
          noRepeatTokens,
          preferredToken: slot.packagingToken,
          query: [richTextHighlights[index], packaging.visualStyle, packaging.packagingNotes]
            .filter((value) => typeof value === 'string' && value.trim())
            .join(' '),
        },
      ) ??
        // A template can contain more cadence slots than the currently
        // admitted catalog has distinct variants. Reuse an admitted variant
        // after the unique pool is exhausted so authored flower-text rhythm
        // is preserved; never fall back to an unaudited token.
        recommendCurrentPackagingResource(
          packagingResourceIndex,
          decorationKind,
          { rotation: index, preferredToken: slot.packagingToken },
        )
      if (currentRecommendation !== null) {
        noRepeatTokens.push(currentRecommendation.packagingToken)
        return {
          ...slot,
          packagingToken: currentRecommendation.packagingToken,
          capabilityId: currentRecommendation.capabilityId,
        }
      }
      if (packagingResourceIndex !== null) {
        return { ...slot, packagingToken: null, capabilityId: 'text.rich' }
      }
      if (batchTextCatalog === null) return { ...slot, packagingToken: null, capabilityId: 'text.rich' }
      try {
        const recommendation = recommendJianyingBatchTextPackaging(batchTextCatalog, {
          kind: decorationKind,
          intentTags: [packaging.visualStyle, packaging.packagingDensity, 'emphasis'],
          rotation: index,
          noRepeatTokens,
          requireEvidence: true,
        })
        noRepeatTokens.push(recommendation.packagingToken)
        return {
          ...slot,
          packagingToken: recommendation.packagingToken,
          capabilityId: recommendation.capabilityId,
        }
      } catch {
        // No recipe token may substitute for a current, evidenced private
        // catalog entry when the catalog is missing, stale, or exhausted.
        return { ...slot, packagingToken: null, capabilityId: 'text.rich' }
      }
      })
  }
  const candidateRichSlots = packaging.emphasisStyle === 'caption'
    ? []
    : constraints.richTextSlots.filter((/** @type {Record<string, any>} */ slot) =>
        desiredDecoration === null
          ? followsAuthoredBlueprint
            ? ['flower', 'bubble'].includes(slot.decorationKind)
            : true
          : slot.decorationKind === desiredDecoration && (
              typeof slot.packagingToken === 'string' || followsAuthoredBlueprint)
      )
  // Authored FlowerText / Bubble cards are a style pool, not a placement
  // quota. A Jianying draft also owns the on-screen cadence: overlapping
  // companion cards are one designed beat, so a second brief keyword must
  // not share that frame.
  const cadenceSlots = followsAuthoredBlueprint
    ? selectNonOverlappingPackagingItems(candidateRichSlots, (slot) =>
      Number.isSafeInteger(slot.startUs) && Number.isSafeInteger(slot.durationUs) && slot.durationUs > 0
        ? { start: slot.startUs, duration: slot.durationUs }
        : null)
    : candidateRichSlots
  const sharedAssignmentHighlights = followsAuthoredBlueprint
    ? resolveAssignmentHighlights({ packaging, brief })
    : []
  const assignmentCopy = sharedAssignmentHighlights.length > 0
    ? sharedAssignmentHighlights
    : richTextHighlights
  const richLimit = followsAuthoredBlueprint
    ? assignmentCopy.length
    : ['follow_template', 'flower_text', 'bubble'].includes(packaging.emphasisStyle)
      ? richTextHighlights.length
      : packaging.packagingDensity === 'light'
        ? Math.min(1, richTextHighlights.length)
        : packaging.packagingDensity === 'balanced'
          ? Math.min(2, richTextHighlights.length)
          : richTextHighlights.length
  const slotHighlights = (followsAuthoredBlueprint ? assignmentCopy : richTextHighlights)
    .slice(0, Math.max(0, richLimit))
  const styleInventory = createTemplateStyleInventory(
    followsAuthoredBlueprint ? cadenceSlots : candidateRichSlots,
  )
  const assignedStyles = slotHighlights.length > 0 && styleInventory.length > 0
    ? assignTemplateStyleInventory({
      highlights: slotHighlights,
      inventory: styleInventory,
      assignments: styleAssignments,
    })
    : []
  const slotsById = new Map(
    (followsAuthoredBlueprint ? cadenceSlots : candidateRichSlots)
      .filter((slot) => typeof slot.slotId === 'string')
      .map((slot) => [slot.slotId, slot]),
  )
  constraints.richTextSegments = assignedStyles
    .map((assignment) => {
      const slot = slotsById.get(assignment.slotId) ?? assignment.item
      const capabilityId = slot.capabilityId === 'text.flower.private' || slot.capabilityId === 'text.bubble.private'
        ? slot.capabilityId
        : 'text.rich'
      return {
        // Current copy picks a look from the draft inventory. Draft order
        // never decides which highlight receives the first authored style.
        text: assignment.text,
        anchor: 'project_shot',
        templateStartUs: slot.startUs,
        durationUs: slot.durationUs,
        styleToken: capabilityId === 'text.rich' ? slot.styleToken : 'rich-emphasis',
        ...(typeof slot.slotId === 'string' ? { slotId: slot.slotId } : {}),
        ...(typeof slot.targetSegmentId === 'string' ? { targetSegmentId: slot.targetSegmentId } : {}),
        packagingToken: capabilityId === 'text.rich' ? null : slot.packagingToken,
        capabilityId,
      }
    })
  // Explicit Brief keywords must still reach Jianying as editable emphasis
  // when the bound template has no authored flower/bubble slots. Script or
  // title fallback copy stays slot-bound so we never invent decoration.
  if (
    !followsAuthoredBlueprint &&
    packaging.enabled !== false &&
    packaging.emphasisStyle !== 'caption' &&
    !packagingResourceIntent.families.includes('flower') &&
    explicitHighlights.length > 0 &&
    constraints.richTextSegments.length === 0
  ) {
    const leftoverLimit = packaging.packagingDensity === 'light'
      ? 1
      : packaging.packagingDensity === 'balanced'
        ? Math.min(2, explicitHighlights.length)
        : explicitHighlights.length
    constraints.richTextSegments = explicitHighlights
      .slice(0, leftoverLimit)
      .map((text) => ({
        text,
        anchor: 'project_shot',
        templateStartUs: 0,
        durationUs: 800_000,
        styleToken: 'rich-emphasis',
        packagingToken: null,
        capabilityId: 'text.rich',
      }))
  }
  constraints.capabilityRequirements = constraints.capabilityRequirements
    .filter((/** @type {Record<string, any>} */ requirement) =>
      !['text.rich', 'text.flower.private', 'text.bubble.private'].includes(requirement.capabilityId))
  if (constraints.richTextSegments.length > 0) {
    for (const richCapabilityId of new Set(
      constraints.richTextSegments.map((/** @type {Record<string, any>} */ segment) =>
        segment.capabilityId === 'text.flower.private' || segment.capabilityId === 'text.bubble.private'
          ? segment.capabilityId
          : 'text.rich'),
    )) {
      constraints.capabilityRequirements.push({
        capabilityId: richCapabilityId,
        acceptance: richCapabilityId === 'text.rich' ? 'implemented' : 'degraded',
        degradationCode: richCapabilityId === 'text.flower.private'
          ? 'FLOWER_TEXT_PREVIEW_DEGRADED'
          : richCapabilityId === 'text.bubble.private'
            ? 'BUBBLE_TEXT_PREVIEW_DEGRADED'
            : null,
      })
    }
  }

  for (const [role, capabilityId] of [
    ['sticker', 'sticker.named'],
    ['effect', 'effect.video.named'],
  ]) {
    if (!packagingSegments.some((segment) => segment.role === role)) {
      constraints.capabilityRequirements = constraints.capabilityRequirements
        .filter((/** @type {Record<string, any>} */ requirement) => requirement.capabilityId !== capabilityId)
    }
  }
  constraints.capabilityRequirements.sort((/** @type {Record<string, any>} */ left, /** @type {Record<string, any>} */ right) =>
    left.capabilityId.localeCompare(right.capabilityId))
  return assertTimelineTemplateConstraints(constraints)
}
