import { createHash } from 'node:crypto'

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

const capabilityStatuses = new Set(['implemented', 'degraded', 'unsupported'])
const runtimeStatuses = new Set(['implemented', 'degraded', 'unsupported', 'unavailable'])
export const STYLE_PROFILE_ANALYZER_VERSION = 'tpl006-style-analyzer-v1'

/**
 * 读取模板演示能力列表。正式 writer 状态只允许来自 editor-capability-registry。
 * 兼容旧字段 `capabilities`（只读迁移），新写入一律用 `templateDemoCapabilities`。
 * @param {unknown} styleSummary
 * @returns {Array<Record<string, any>>}
 */
export const getTemplateDemoCapabilities = (styleSummary) => {
  if (!record(styleSummary)) return []
  const preferred = styleSummary.templateDemoCapabilities
  if (Array.isArray(preferred)) {
    return preferred.filter((entry) =>
      record(entry) &&
      typeof entry.id === 'string' &&
      capabilityStatuses.has(entry.status))
  }
  if (Array.isArray(styleSummary.capabilities)) {
    return styleSummary.capabilities.filter((entry) =>
      record(entry) &&
      typeof entry.id === 'string' &&
      capabilityStatuses.has(entry.status))
  }
  return []
}

/**
 * @param {string} id
 * @param {'implemented' | 'degraded' | 'unsupported'} status
 * @param {string} [note]
 */
const capability = (id, status, note = '') => ({
  id,
  status,
  ...(note ? { note } : {}),
})

/**
 * @param {{
 *   detected: boolean,
 *   confidence: number,
 *   evidenceRanges?: Array<Record<string, any>>,
 *   previewStatus: string,
 *   jianyingStatus: string,
 *   degradationCode?: string,
 *   [key: string]: unknown,
 * }} fields
 */
const dimension = (fields) => {
  const evidenceRanges = Array.isArray(fields.evidenceRanges)
    ? fields.evidenceRanges.filter((entry) => record(entry)
      && Number.isFinite(entry.startMs)
      && Number.isFinite(entry.endMs)
      && entry.endMs >= entry.startMs)
      .map((entry) => ({
        startMs: Math.max(0, Math.round(entry.startMs)),
        endMs: Math.max(0, Math.round(entry.endMs)),
        ...(typeof entry.kind === 'string' ? { kind: entry.kind } : {}),
      }))
    : []
  const base = {
    detected: Boolean(fields.detected),
    confidence: Math.max(0, Math.min(1, Number(fields.confidence) || 0)),
    evidenceRanges,
    previewStatus: runtimeStatuses.has(fields.previewStatus) ? fields.previewStatus : 'unavailable',
    jianyingStatus: runtimeStatuses.has(fields.jianyingStatus) ? fields.jianyingStatus : 'unavailable',
  }
  const rest = { ...fields }
  for (const key of ['detected', 'confidence', 'evidenceRanges', 'previewStatus', 'jianyingStatus', 'degradationCode']) {
    if (Object.prototype.hasOwnProperty.call(rest, key)) {
      delete /** @type {Record<string, unknown>} */ (rest)[key]
    }
  }
  const degradationCode = typeof fields.degradationCode === 'string' && fields.degradationCode
    ? fields.degradationCode
    : undefined
  return {
    ...base,
    ...rest,
    ...(base.previewStatus === 'degraded' || base.jianyingStatus === 'degraded'
      ? { degradationCode: degradationCode || 'capability_degraded' }
      : {}),
  }
}

/** @param {unknown} value */
const isEvidenceRange = (value) =>
  record(value) &&
  Number.isFinite(value.startMs) &&
  Number.isFinite(value.endMs) &&
  value.endMs >= value.startMs

/** @param {unknown} value */
const isDimension = (value) =>
  record(value) &&
  typeof value.detected === 'boolean' &&
  typeof value.confidence === 'number' &&
  value.confidence >= 0 &&
  value.confidence <= 1 &&
  Array.isArray(value.evidenceRanges) &&
  value.evidenceRanges.every(isEvidenceRange) &&
  runtimeStatuses.has(value.previewStatus) &&
  runtimeStatuses.has(value.jianyingStatus) &&
  (
    (value.previewStatus !== 'degraded' && value.jianyingStatus !== 'degraded') ||
    typeof value.degradationCode === 'string'
  )

/**
 * @param {string[]} palette
 */
const sanitizePalette = (palette) =>
  palette
    .filter((entry) => typeof entry === 'string' && /^#[0-9a-f]{6}$/iu.test(entry))
    .map((entry) => entry.toLowerCase())
    .slice(0, 5)

/**
 * Derive a public StyleProfile v4 summary from a reusable template artifact.
 * Detection is evidence-backed; missing evidence stays unavailable — never invent palettes.
 * @param {Record<string, any>} artifact
 * @param {{
 *   palette?: string[],
 *   brightnessLabel?: string | null,
 *   contrastLabel?: string | null,
 *   saturationLabel?: string | null,
 *   colorTempLabel?: string | null,
 *   motionLabel?: string | null,
 *   voiceStyle?: string | null,
 *   speechRateLabel?: string | null,
 *   bgmBpm?: number | null,
 *   frameFingerprints?: string[],
 *   textEvidence?: Array<Record<string, any>>,
 *   analysisComplete?: boolean,
 *   analyzerVersion?: string,
 *   migratedFromV3?: boolean,
 * }} [extras]
 */
export const buildStyleSummaryFromArtifact = (artifact, extras = {}) => {
  if (!record(artifact) || !record(artifact.draft)) {
    throw new Error('STYLE_PROFILE_ARTIFACT_INVALID')
  }
  const slots = Array.isArray(artifact.draft.slots) ? artifact.draft.slots : []
  const rules = record(artifact.draft.rules) ? artifact.draft.rules : {}
  const packaging = record(rules.packaging) ? rules.packaging : {}
  const caption = record(rules.caption_cadence) ? rules.caption_cadence : { mode: 'none' }
  const analysis = record(artifact.analysis) ? artifact.analysis : {}
  const analysisShots = Array.isArray(analysis.shots) ? analysis.shots : []
  const captionCapabilityId = packaging.subtitle_style === 'bottom_safe'
    ? 'caption.bottom_safe'
    : 'caption.basic'
  const audioEmphasis = Array.isArray(rules.audio_emphasis) ? rules.audio_emphasis : []
  const transitionCount = slots.filter((slot) => record(slot) && slot.transition_out !== 'none').length
  const palette = sanitizePalette(Array.isArray(extras.palette) ? extras.palette : [])
  const brightnessLabel = typeof extras.brightnessLabel === 'string' && extras.brightnessLabel
    ? extras.brightnessLabel
    : null
  const contrastLabel = typeof extras.contrastLabel === 'string' ? extras.contrastLabel : null
  const saturationLabel = typeof extras.saturationLabel === 'string' ? extras.saturationLabel : null
  const colorTempLabel = typeof extras.colorTempLabel === 'string' ? extras.colorTempLabel : null
  const motionLabel = typeof extras.motionLabel === 'string' && extras.motionLabel
    ? extras.motionLabel
    : null
  const voiceStyle = typeof extras.voiceStyle === 'string' && extras.voiceStyle
    ? extras.voiceStyle
    : null
  const speechRateLabel = typeof extras.speechRateLabel === 'string' ? extras.speechRateLabel : null
  const bgmBpm = Number.isFinite(extras.bgmBpm) ? Number(extras.bgmBpm) : null
  const frameFingerprints = Array.isArray(extras.frameFingerprints)
    ? extras.frameFingerprints.filter((entry) => typeof entry === 'string' && /^[a-f0-9]{16,64}$/iu.test(entry))
    : []
  const textEvidence = Array.isArray(extras.textEvidence) ? extras.textEvidence.filter(record) : []
  const analysisComplete = extras.analysisComplete === true
  const migratedFromV3 = extras.migratedFromV3 === true
  const analyzerVersion = typeof extras.analyzerVersion === 'string' && extras.analyzerVersion
    ? extras.analyzerVersion
    : STYLE_PROFILE_ANALYZER_VERSION

  const editingRanges = /** @type {Array<Record<string, any>>} */ ((analysisShots.length > 0 ? analysisShots : slots).map((shot, index) => {
    if (!record(shot)) return null
    const startMs = Number.isFinite(shot.start_ms)
      ? shot.start_ms
      : index === 0 ? 0 : null
    const endMs = Number.isFinite(shot.end_ms)
      ? shot.end_ms
      : Number.isFinite(shot.recommended_duration_ms)
        ? (startMs || 0) + shot.recommended_duration_ms
        : null
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) return null
    return {
      startMs,
      endMs,
      kind: typeof shot.role === 'string' ? shot.role : 'slot',
    }
  }).filter(Boolean))

  const editingDetected = slots.length > 0 && editingRanges.length > 0
  const visualDetected = palette.length > 0 && frameFingerprints.length > 0
  const textDetected = caption.mode !== 'none' || textEvidence.length > 0
  const packagingDetected = packaging.intro !== 'none' || packaging.outro !== 'none'
  const audioDetected = audioEmphasis.length > 0 || voiceStyle !== null || bgmBpm !== null

  return {
    schemaVersion: 4,
    analyzerVersion,
    analysisComplete,
    ...(migratedFromV3 ? { migratedFromV3: true } : {}),
    editing: dimension({
      detected: editingDetected,
      confidence: editingDetected ? (analysisComplete ? 0.92 : 0.75) : 0,
      evidenceRanges: editingRanges,
      previewStatus: editingDetected ? 'implemented' : 'unavailable',
      jianyingStatus: editingDetected ? 'implemented' : 'unavailable',
      slotCount: slots.length,
      transitionCount,
      pacing: typeof rules.pacing === 'string' ? rules.pacing : 'balanced',
      roles: slots
        .map((slot) => (record(slot) && typeof slot.role === 'string' ? slot.role : null))
        .filter(Boolean),
    }),
    visual: dimension({
      detected: visualDetected,
      confidence: visualDetected ? (analysisComplete ? 0.8 : 0.55) : 0,
      evidenceRanges: visualDetected
        ? editingRanges.slice(0, Math.min(5, editingRanges.length || 1))
        : [],
      previewStatus: visualDetected ? 'degraded' : 'unavailable',
      jianyingStatus: visualDetected ? 'degraded' : 'unavailable',
      degradationCode: visualDetected ? 'color_grade_numeric_only' : undefined,
      palette,
      brightnessLabel,
      contrastLabel,
      saturationLabel,
      colorTempLabel,
      motionLabel,
      frameFingerprints,
    }),
    text: dimension({
      detected: textDetected,
      confidence: textDetected ? (textEvidence.length > 0 ? 0.85 : 0.6) : 0,
      evidenceRanges: textEvidence.length > 0
        ? textEvidence.map((entry) => ({
          startMs: Number(entry.startMs) || 0,
          endMs: Number(entry.endMs) || 1_000,
          kind: typeof entry.kind === 'string' ? entry.kind : 'caption',
        }))
        : (textDetected && editingRanges[0] ? [editingRanges[0]] : []),
      previewStatus: caption.mode === 'none' ? 'unavailable' : 'implemented',
      jianyingStatus: caption.mode === 'none' ? 'unavailable' : 'implemented',
      captionMode: typeof caption.mode === 'string' ? caption.mode : 'none',
      titleCard: packaging.intro === 'title_card' || packaging.outro === 'title_card',
      subtitleStyle: typeof packaging.subtitle_style === 'string'
        ? packaging.subtitle_style
        : 'default',
      ocrSamples: textEvidence
        .map((entry) => (typeof entry.text === 'string' ? entry.text.slice(0, 40) : null))
        .filter(Boolean)
        .slice(0, 5),
    }),
    packaging: dimension({
      detected: packagingDetected,
      confidence: packagingDetected ? 0.7 : 0,
      evidenceRanges: packagingDetected && editingRanges.length > 0
        ? [
          editingRanges[0],
          ...(packaging.outro !== 'none' && editingRanges.length > 1
            ? [editingRanges[editingRanges.length - 1]]
            : []),
        ]
        : [],
      previewStatus: packagingDetected ? 'degraded' : 'unavailable',
      jianyingStatus: packagingDetected ? 'degraded' : 'unavailable',
      degradationCode: packagingDetected ? 'packaging_metadata_only' : undefined,
      intro: typeof packaging.intro === 'string' ? packaging.intro : 'none',
      outro: typeof packaging.outro === 'string' ? packaging.outro : 'none',
    }),
    audio: dimension({
      detected: audioDetected,
      confidence: audioDetected ? 0.65 : 0,
      evidenceRanges: /** @type {Array<Record<string, any>>} */ (audioEmphasis
        .map((entry) => (record(entry) && Number.isFinite(entry.at_ms)
          ? { startMs: entry.at_ms, endMs: entry.at_ms + 200, kind: 'emphasis' }
          : null))
        .filter(Boolean)),
      previewStatus: audioDetected ? 'degraded' : 'unavailable',
      jianyingStatus: audioDetected ? 'degraded' : 'unavailable',
      degradationCode: audioDetected ? 'audio_style_mapping_only' : undefined,
      emphasisCount: audioEmphasis.length,
      voiceStyle,
      speechRateLabel,
      bgmBpm,
      cloneForbidden: true,
    }),
    templateDemoCapabilities: [
      capability('transition.cut', transitionCount > 0 || slots.length > 1 ? 'implemented' : 'unsupported'),
      capability(
        'transition.fade',
        transitionCount > 0 ? 'degraded' : 'unsupported',
        '仅模板演示淡入淡出近似；正式 writer registry 投影为 unsupported',
      ),
      capability(captionCapabilityId, caption.mode === 'none' ? 'unsupported' : 'implemented'),
      capability(
        'title.card',
        packaging.intro === 'title_card' || packaging.outro === 'title_card'
          ? 'degraded'
          : 'unsupported',
        '模板演示以字幕卡呈现；非 writer registry 状态',
      ),
      capability(
        'text.rich',
        'unsupported',
        '模板演示不写花字；正式 Preview/Jianying 状态见 editor-capability-registry',
      ),
      capability(
        'color.grade.numeric',
        visualDetected ? 'degraded' : 'unsupported',
        visualDetected ? '仅模板演示数值化色彩；正式 registry 投影 unsupported' : '缺少采样色板证据',
      ),
      capability(
        'transform.opacity',
        'degraded',
        '仅模板演示片段透明度近似；正式 writer registry 不包含此 ID',
      ),
      capability('filter.video.named', 'unsupported'),
      capability('sticker.named', 'unsupported'),
      capability(
        'audio.voiceover.edge_tts',
        'unsupported',
        '模板演示不合成配音；正式 TTS 状态见 editor-capability-registry',
      ),
      capability(
        'audio.bgm.style_map',
        audioDetected ? 'degraded' : 'unsupported',
        audioDetected ? '仅模板演示风格标签；正式 registry 投影 unsupported' : undefined,
      ),
    ],
  }
}

/** @param {unknown} value */
export const isStyleSummaryV4 = (value) => {
  if (!record(value) || value.schemaVersion !== 4) return false
  if (typeof value.analyzerVersion !== 'string' || !value.analyzerVersion) return false
  if (typeof value.analysisComplete !== 'boolean') return false
  if (!isDimension(value.editing) || !isDimension(value.visual) || !isDimension(value.text)) return false
  if (!isDimension(value.packaging) || !isDimension(value.audio)) return false
  const demoCapabilities = getTemplateDemoCapabilities(value)
  if (demoCapabilities.length === 0 &&
    !Array.isArray(value.templateDemoCapabilities) &&
    !Array.isArray(value.capabilities)) return false
  if (value.audio.cloneForbidden !== true) return false
  if (Array.isArray(value.visual.palette) === false) return false
  // Zero-placeholder rule: undetected visual must not claim a decorative palette.
  if (value.visual.detected !== true && value.visual.palette.length !== 0) return false
  return demoCapabilities.every((entry) =>
    record(entry) &&
    typeof entry.id === 'string' &&
    capabilityStatuses.has(entry.status))
}

/**
 * Read-only migration for TPL-004 v3 summaries. Never marks analysisComplete.
 * @param {unknown} value
 */
export const migrateStyleSummaryV3ToV4 = (value) => {
  if (isStyleSummaryV4(value)) return /** @type {Record<string, any>} */ (value)
  if (!record(value) || value.schemaVersion !== 3) return null
  if (!record(value.editing) || !record(value.visual) || !record(value.text)) return null
  if (!record(value.packaging) || !record(value.audio)) return null
  if (!Array.isArray(value.capabilities) && !Array.isArray(value.templateDemoCapabilities)) return null
  if (value.audio.cloneForbidden !== true) return null

  const placeholderPalettes = new Set([
    JSON.stringify(['#1f2937', '#f8fafc', '#f59e0b']),
  ])
  const rawPalette = Array.isArray(value.visual.palette) ? value.visual.palette : []
  const looksPlaceholder = placeholderPalettes.has(JSON.stringify(rawPalette))
    || value.visual.detected !== true
  const palette = looksPlaceholder ? [] : sanitizePalette(rawPalette)
  const legacyCapabilities = getTemplateDemoCapabilities(value)

  return {
    schemaVersion: 4,
    analyzerVersion: 'migrated-from-v3',
    analysisComplete: false,
    migratedFromV3: true,
    editing: dimension({
      detected: Boolean(value.editing.detected),
      confidence: Number(value.editing.confidence) || 0,
      evidenceRanges: [],
      previewStatus: value.editing.detected ? 'degraded' : 'unavailable',
      jianyingStatus: value.editing.detected ? 'degraded' : 'unavailable',
      degradationCode: value.editing.detected ? 'migrated_v3_no_evidence' : undefined,
      slotCount: Number(value.editing.slotCount) || 0,
      transitionCount: Number(value.editing.transitionCount) || 0,
      pacing: typeof value.editing.pacing === 'string' ? value.editing.pacing : 'balanced',
      roles: [],
    }),
    visual: dimension({
      detected: palette.length > 0,
      confidence: palette.length > 0 ? Math.min(0.4, Number(value.visual.confidence) || 0) : 0,
      evidenceRanges: [],
      previewStatus: palette.length > 0 ? 'degraded' : 'unavailable',
      jianyingStatus: palette.length > 0 ? 'degraded' : 'unavailable',
      degradationCode: 'migrated_v3_no_evidence',
      palette,
      brightnessLabel: null,
      contrastLabel: null,
      saturationLabel: null,
      colorTempLabel: null,
      motionLabel: null,
      frameFingerprints: [],
    }),
    text: dimension({
      detected: Boolean(value.text.detected),
      confidence: Number(value.text.confidence) || 0,
      evidenceRanges: [],
      previewStatus: value.text.detected ? 'degraded' : 'unavailable',
      jianyingStatus: value.text.detected ? 'degraded' : 'unavailable',
      degradationCode: value.text.detected ? 'migrated_v3_no_evidence' : undefined,
      captionMode: typeof value.text.captionMode === 'string' ? value.text.captionMode : 'none',
      titleCard: Boolean(value.text.titleCard),
      subtitleStyle: typeof value.text.subtitleStyle === 'string' ? value.text.subtitleStyle : 'default',
      ocrSamples: [],
    }),
    packaging: dimension({
      detected: Boolean(value.packaging.detected),
      confidence: Number(value.packaging.confidence) || 0,
      evidenceRanges: [],
      previewStatus: value.packaging.detected ? 'degraded' : 'unavailable',
      jianyingStatus: value.packaging.detected ? 'degraded' : 'unavailable',
      degradationCode: value.packaging.detected ? 'migrated_v3_no_evidence' : undefined,
      intro: typeof value.packaging.intro === 'string' ? value.packaging.intro : 'none',
      outro: typeof value.packaging.outro === 'string' ? value.packaging.outro : 'none',
    }),
    audio: dimension({
      detected: Boolean(value.audio.detected),
      confidence: Number(value.audio.confidence) || 0,
      evidenceRanges: [],
      previewStatus: value.audio.detected ? 'degraded' : 'unavailable',
      jianyingStatus: value.audio.detected ? 'degraded' : 'unavailable',
      degradationCode: value.audio.detected ? 'migrated_v3_no_evidence' : undefined,
      emphasisCount: Number(value.audio.emphasisCount) || 0,
      voiceStyle: typeof value.audio.voiceStyle === 'string' ? value.audio.voiceStyle : null,
      speechRateLabel: null,
      bgmBpm: null,
      cloneForbidden: true,
    }),
    templateDemoCapabilities: legacyCapabilities
      .map((entry) => capability(entry.id, entry.status, typeof entry.note === 'string' ? entry.note : '')),
  }
}

/** @param {unknown} value */
export const isStyleSummary = (value) =>
  isStyleSummaryV4(value) || Boolean(migrateStyleSummaryV3ToV4(value))

/** @param {unknown} value */
export const normalizeStyleSummary = (value) => {
  if (isStyleSummaryV4(value)) {
    const current = /** @type {Record<string, any>} */ (value)
    if (Array.isArray(current.templateDemoCapabilities)) return current
    const migratedCaps = getTemplateDemoCapabilities(current)
    return {
      ...current,
      templateDemoCapabilities: migratedCaps.map((entry) =>
        capability(entry.id, entry.status, typeof entry.note === 'string' ? entry.note : '')),
    }
  }
  return migrateStyleSummaryV3ToV4(value)
}

/** @param {unknown} value */
export const isPreviewAvailability = (value) =>
  record(value) &&
  typeof value.referencePlayable === 'boolean' &&
  typeof value.demoPlayable === 'boolean' &&
  ['ready', 'pending', 'failed', 'unavailable'].includes(value.demoStatus) &&
  value.demoPlayable === (value.demoStatus === 'ready') &&
  (
    value.demoRenderer === undefined ||
    value.demoRenderer === null ||
    ['template_demo_renderer', 'reference_trim'].includes(value.demoRenderer)
  ) &&
  (
    value.demoAuthentic === undefined ||
    typeof value.demoAuthentic === 'boolean'
  ) &&
  (
    value.styleAnalysisComplete === undefined ||
    typeof value.styleAnalysisComplete === 'boolean'
  ) &&
  (
    value.approveReady === undefined ||
    typeof value.approveReady === 'boolean'
  )

/**
 * @param {Record<string, any>} styleSummary
 * @param {Record<string, any>} previewAvailability
 */
export const styleProfileFingerprint = (styleSummary, previewAvailability) =>
  createHash('sha256')
    .update(JSON.stringify({ styleSummary, previewAvailability }))
    .digest('hex')

/**
 * @param {Record<string, any>} styleSummary
 * @param {Record<string, any>} previewAvailability
 */
export const buildApproveChecklist = (styleSummary, previewAvailability) => {
  const normalized = normalizeStyleSummary(styleSummary) || styleSummary
  const analysisComplete = normalized?.analysisComplete === true && normalized?.migratedFromV3 !== true
  const demoAuthentic = previewAvailability?.demoAuthentic === true
    && previewAvailability?.demoRenderer === 'template_demo_renderer'
  const demoPlayable = previewAvailability?.demoPlayable === true
  const referencePlayable = previewAvailability?.referencePlayable === true
  const coreCapabilities = getTemplateDemoCapabilities(normalized).filter((entry) =>
    ['transition.cut', 'caption.basic', 'caption.bottom_safe', 'color.grade.numeric', 'transform.opacity']
      .includes(entry.id) &&
    entry.status !== 'unsupported')
  const hasCoreExecutable = coreCapabilities.some((entry) =>
    entry.id === 'transition.cut' || entry.id.startsWith('caption.'))
  const degraded = getTemplateDemoCapabilities(normalized)
    .filter((entry) => entry.status === 'degraded')
  return {
    referencePlayable,
    analysisComplete,
    demoPlayable,
    demoAuthentic,
    hasCoreExecutable,
    degradedCount: degraded.length,
    approveReady: referencePlayable && analysisComplete && demoPlayable && demoAuthentic && hasCoreExecutable,
    degradedNotes: degraded.map((entry) => `${entry.id}: ${entry.note || entry.status}`),
  }
}
