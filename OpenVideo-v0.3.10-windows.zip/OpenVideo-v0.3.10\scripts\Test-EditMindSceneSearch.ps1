[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$utf8 = New-Object Text.UTF8Encoding($false)
$repositoryPath = [IO.Path]::GetFullPath($RepositoryRoot)
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ("openvideo-em003-" + [Guid]::NewGuid().ToString('N'))
$materialRoot = Join-Path $testRoot 'authorized-material'
$runtimeRoot = Join-Path $testRoot 'runtime'
$privateEvidenceRoot = Join-Path $runtimeRoot 'evidence/em-003/private'
$em002EvidenceRoot = Join-Path $runtimeRoot 'evidence/em-002'
$queryScript = Join-Path $RepositoryRoot 'scripts/Protect-EditMindSceneSearchQueries.ps1'
$searchScript = Join-Path $RepositoryRoot 'scripts/Invoke-EditMindSceneSearch.ps1'
$resultScript = Join-Path $RepositoryRoot 'scripts/Test-EditMindSceneSearchResults.ps1'

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Write-Json {
    param([string]$Path, [object]$Value)
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 16), $utf8)
}

function Assert-Fails {
    param([scriptblock]$Action, [string]$Pattern)
    $failed = $false
    try {
        $ErrorActionPreference = 'Stop'
        & $Action
    } catch {
        $failed = $true
        if ($_.Exception.Message -notmatch $Pattern) { throw }
    }
    if (-not $failed) { throw "Expected failure matching: $Pattern" }
}

try {
    New-Item -ItemType Directory -Path $materialRoot, $privateEvidenceRoot, $em002EvidenceRoot -Force | Out-Null
    $sources = @()
    foreach ($index in 1..5) {
        $source = Join-Path $materialRoot ("sample-$index.mp4")
        [IO.File]::WriteAllText($source, "synthetic-source-$index", $utf8)
        $sources += $source
    }

    $sentences = @(
        'Cup body shows clean texture in natural light.',
        'Show the cup opening and rim details.',
        'A hand carries the cup across the desk for a lifestyle shot.',
        'Place the cup in the center of the table as the hero subject.',
        'Move close to the lid to highlight the seal design.',
        'Show the cup with packaging in a purchase scenario.',
        'Pouring water from the cup shows daily use.',
        ([string][char]0x676F)
    )
    $queryManifestPath = Join-Path $privateEvidenceRoot 'search-queries.json'
    Write-Json $queryManifestPath ([ordered]@{
        schema_version = 1
        authorization = 'read_only_search'
        sentences = $sentences
    })

    Assert-True (Test-Path -LiteralPath $queryScript -PathType Leaf) 'Search query preflight script is missing.'
    Assert-True (Test-Path -LiteralPath $searchScript -PathType Leaf) 'Scene search adapter script is missing.'
    Assert-True (Test-Path -LiteralPath $resultScript -PathType Leaf) 'Search result validation script is missing.'

    & $queryScript -ManifestPath $queryManifestPath -RuntimeDataRoot $runtimeRoot | Out-Null
    $queryVerificationPath = Join-Path $runtimeRoot 'evidence/em-003/search-query-verification.json'
    $queryVerification = Get-Content -LiteralPath $queryVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
    Assert-True ($queryVerification.sentence_count -eq 8) 'Search query verification must report eight sentences.'
    $queryVerificationText = Get-Content -LiteralPath $queryVerificationPath -Raw -Encoding utf8
    Assert-True (-not $queryVerificationText.Contains($sentences[0])) 'Sanitized query verification leaked private text.'

    $badCountManifest = Join-Path $privateEvidenceRoot 'bad-count.json'
    Write-Json $badCountManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_search'; sentences = $sentences[0..6] })
    Assert-Fails { & $queryScript -ManifestPath $badCountManifest -RuntimeDataRoot $runtimeRoot } 'exactly eight'

    $duplicateManifest = Join-Path $privateEvidenceRoot 'duplicate.json'
    Write-Json $duplicateManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_search'; sentences = @($sentences[0..6] + $sentences[0]) })
    Assert-Fails { & $queryScript -ManifestPath $duplicateManifest -RuntimeDataRoot $runtimeRoot } 'unique'

    $blankManifest = Join-Path $privateEvidenceRoot 'blank.json'
    Write-Json $blankManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_search'; sentences = @($sentences[0..6] + '   ') })
    Assert-Fails { & $queryScript -ManifestPath $blankManifest -RuntimeDataRoot $runtimeRoot } 'non-empty'

    $outsideManifest = Join-Path $testRoot 'search-queries-outside-runtime.json'
    Write-Json $outsideManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_search'; sentences = $sentences })
    Assert-Fails { & $queryScript -ManifestPath $outsideManifest -RuntimeDataRoot $runtimeRoot } 'inside RuntimeDataRoot'
    Assert-Fails { & $queryScript -ManifestPath $queryScript -RuntimeDataRoot $repositoryPath } 'repository'

    $analysisResultsPath = Join-Path $em002EvidenceRoot 'private-analysis-results.json'
    $analysisResults = [ordered]@{
        schema_version = 1
        samples = @()
    }
    $summaries = @(
        ('Clean cup texture in natural light with a clear body color. ' + [string][char]0x676F + [string][char]0x5B50),
        'Close cup opening, rim, lid and seal details.',
        'A hand carries the cup across a desk in a lifestyle scene.',
        'The cup is centered on a table with packaging for a hero purchase shot.',
        'Pouring water shows daily use with a slow push-in on the cup color.'
    )
    for ($index = 0; $index -lt 5; $index++) {
        $analysisResults.samples += [ordered]@{
            source = $sources[$index]
            status = 'indexed'
            summary = $summaries[$index]
            tags = @('cup', 'synthetic')
            duration = 12.0
            scenes = @(
                [ordered]@{ source = $sources[$index]; start = 0.0; end = 6.0 },
                [ordered]@{ source = $sources[$index]; start = 6.0; end = 12.0 }
            )
        }
    }
    Write-Json $analysisResultsPath $analysisResults
    New-Item -ItemType Directory -Path (Join-Path $runtimeRoot 'evidence/em-002') -Force | Out-Null
    $sourceVerificationPath = Join-Path $runtimeRoot 'evidence/em-002/source-verification.json'
    $analysisVerificationPath = Join-Path $runtimeRoot 'evidence/em-002/analysis-verification.json'
    Write-Json $sourceVerificationPath ([ordered]@{
        schema_version = 1
        unchanged = $true
        sample_count = 5
        compared_fields = @('path', 'name', 'length', 'last_write_time_utc', 'sha256')
    })
    Write-Json $analysisVerificationPath ([ordered]@{
        schema_version = 1
        sample_count = 5
        indexed_count = 5
        all_timecodes_within_duration = $true
        scene_representation = 'source+start+end'
        permanent_scene_clips = 0
    })

    $resultsPath = Join-Path $privateEvidenceRoot 'scene-search-results.json'
    $adapterOutsideOutput = Join-Path $testRoot 'scene-search-results-outside-runtime.json'
    Assert-Fails { & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $adapterOutsideOutput } 'inside RuntimeDataRoot'
    Assert-Fails { & $searchScript -QueryManifestPath $outsideManifest -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath } 'inside RuntimeDataRoot'
    $adapterOutsideAnalysis = Join-Path $testRoot 'private-analysis-results-outside-runtime.json'
    Write-Json $adapterOutsideAnalysis $analysisResults
    Assert-Fails { & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $adapterOutsideAnalysis -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath } 'inside RuntimeDataRoot'
    Assert-Fails { & $searchScript -QueryManifestPath 'C:relative-query.json' -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath } 'absolute path'
    Assert-Fails { & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $queryManifestPath } 'must not overwrite'
    $sourceVerificationTextForAdapter = Get-Content -LiteralPath $sourceVerificationPath -Raw -Encoding utf8
    Remove-Item -LiteralPath $sourceVerificationPath -Force
    Assert-Fails { & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath } 'preflight evidence'
    [IO.File]::WriteAllText($sourceVerificationPath, $sourceVerificationTextForAdapter, $utf8)
    $analysisVerificationTextForAdapter = Get-Content -LiteralPath $analysisVerificationPath -Raw -Encoding utf8
    Remove-Item -LiteralPath $analysisVerificationPath -Force
    Assert-Fails { & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath } 'preflight evidence'
    [IO.File]::WriteAllText($analysisVerificationPath, $analysisVerificationTextForAdapter, $utf8)
    $querySnapshotPathForAdapter = Join-Path $runtimeRoot 'evidence/em-003/private/search-query-snapshot.json'
    $querySnapshotTextForAdapter = Get-Content -LiteralPath $querySnapshotPathForAdapter -Raw -Encoding utf8
    $querySnapshotForAdapter = $querySnapshotTextForAdapter | ConvertFrom-Json
    $querySnapshotForAdapter.sentences[0] = 'A different private sentence.'
    Write-Json $querySnapshotPathForAdapter $querySnapshotForAdapter
    Assert-Fails { & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath } 'snapshot does not match'
    [IO.File]::WriteAllText($querySnapshotPathForAdapter, $querySnapshotTextForAdapter, $utf8)
    & $searchScript -QueryManifestPath $queryManifestPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot -OutputPath $resultsPath | Out-Null
    $searchResults = Get-Content -LiteralPath $resultsPath -Raw -Encoding utf8 | ConvertFrom-Json
    $validSearchResultsJson = $searchResults | ConvertTo-Json -Depth 16
    Assert-True (@($searchResults.queries).Count -eq 8) 'Scene search adapter must return eight query results.'
    Assert-True ($searchResults.queries[1].top_candidates[0].scene.source -eq $sources[1]) 'Opening and rim term overlap must rank the rim sample first.'
    Assert-True ($searchResults.queries[6].top_candidates[0].scene.source -eq $sources[4]) 'Pouring and daily-use term overlap must rank the daily-use sample first.'
    Assert-True ($searchResults.queries[7].top_candidates[0].scene.source -eq $sources[0]) 'A single CJK character must match the same character inside a longer document term.'

    & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot | Out-Null
    $searchEvidencePath = Join-Path $runtimeRoot 'evidence/em-003/search-verification.json'
    $searchEvidence = Get-Content -LiteralPath $searchEvidencePath -Raw -Encoding utf8 | ConvertFrom-Json
    Assert-True ($searchEvidence.query_count -eq 8) 'Search verification must report eight query results.'
    Assert-True ($searchEvidence.usable_in_top3_count -eq 8) 'Search verification must count usable top-three results.'
    $searchEvidenceText = Get-Content -LiteralPath $searchEvidencePath -Raw -Encoding utf8
    Assert-True (-not $searchEvidenceText.Contains($materialRoot)) 'Sanitized search verification leaked the material root.'
    Assert-True (-not $searchEvidenceText.Contains($sentences[0])) 'Sanitized search verification leaked query text.'

    $querySnapshotPath = Join-Path $runtimeRoot 'evidence/em-003/private/search-query-snapshot.json'
    $querySnapshotText = Get-Content -LiteralPath $querySnapshotPath -Raw -Encoding utf8
    Move-Item -LiteralPath $querySnapshotPath -Destination "$querySnapshotPath.bak"
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'preflight evidence'
    Move-Item -LiteralPath "$querySnapshotPath.bak" -Destination $querySnapshotPath
    [IO.File]::WriteAllText($querySnapshotPath, $querySnapshotText, $utf8)

    $analysisVerificationText = Get-Content -LiteralPath $analysisVerificationPath -Raw -Encoding utf8
    Remove-Item -LiteralPath $analysisVerificationPath -Force
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'EM-002 verified analysis evidence'
    [IO.File]::WriteAllText($analysisVerificationPath, $analysisVerificationText, $utf8)

    $resultsOutsideRuntime = Join-Path $testRoot 'scene-search-results-outside-runtime.json'
    Write-Json $resultsOutsideRuntime $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsOutsideRuntime -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'inside RuntimeDataRoot'
    Assert-Fails { & $resultScript -QueryManifestPath $outsideManifest -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'inside RuntimeDataRoot'

    $outsideAnalysisResults = Join-Path $testRoot 'private-analysis-results-outside-runtime.json'
    Write-Json $outsideAnalysisResults $analysisResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $outsideAnalysisResults -RuntimeDataRoot $runtimeRoot } 'inside RuntimeDataRoot'

    $searchResults.queries[0].top_candidates += [ordered]@{ scene = [ordered]@{ source = $sources[0]; start = 0.0; end = 4.0 }; score = 0.1 }
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'at most three'
    $searchResults.queries[0].top_candidates = @($searchResults.queries[0].top_candidates[0..2])

    $outsideSource = Join-Path $testRoot 'outside.mp4'
    [IO.File]::WriteAllText($outsideSource, 'outside', $utf8)
    $searchResults.queries[0].top_candidates[0].scene.source = $outsideSource
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'five EM-002 verified samples'
    $searchResults.queries[0].top_candidates[0].scene.source = $sources[0]

    $searchResults.queries[0].top_candidates[0].scene.end = 13.0
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'duration'
    $searchResults.queries[0].top_candidates[0].scene.end = 4.0

    $searchResults.queries[0].top_candidates[0].scene.start = 5.0
    $searchResults.queries[0].top_candidates[0].scene.end = 7.0
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'indexed scene'
    $searchResults.queries[0].top_candidates[0].scene.start = 0.0
    $searchResults.queries[0].top_candidates[0].scene.end = 4.0

    $searchResults.queries[0].top_candidates[0].score = 'not-a-score'
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'score'
    $searchResults.queries[0].top_candidates[0].score = '0.5'
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'numeric'
    $searchResults.queries[0].top_candidates[0].score = 0.9

    $searchResults.queries[0].usable_in_top3 = 'false'
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'boolean'
    $searchResults.queries[0].usable_in_top3 = $true

    $searchResults.queries[0].top_candidates[0].scene | Add-Member -NotePropertyName note -NotePropertyValue 'extra field'
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'source, start and end'
    $searchResults.queries[0].top_candidates[0].scene.PSObject.Properties.Remove('note')

    foreach ($query in $searchResults.queries) { $query.usable_in_top3 = $false }
    $usableQueries = @($searchResults.queries | Where-Object { @($_.top_candidates).Count -gt 0 } | Select-Object -First 6)
    foreach ($query in $usableQueries) { $query.usable_in_top3 = $true }
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'availability'
    $searchResults = $validSearchResultsJson | ConvertFrom-Json

    $temporaryFrame = Join-Path $runtimeRoot 'tmp/search/frame-001.jpg'
    New-Item -ItemType Directory -Path (Split-Path -Parent $temporaryFrame) -Force | Out-Null
    [IO.File]::WriteAllText($temporaryFrame, 'temporary', $utf8)
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'temporary files'
    Remove-Item -LiteralPath $temporaryFrame -Force

    $sceneFile = Join-Path $runtimeRoot 'Scene-001.mp4'
    [IO.File]::WriteAllText($sceneFile, 'forbidden', $utf8)
    Write-Json $resultsPath $searchResults
    Assert-Fails { & $resultScript -QueryManifestPath $queryManifestPath -SearchResultsPath $resultsPath -AnalysisResultsPath $analysisResultsPath -RuntimeDataRoot $runtimeRoot } 'Permanent scene clip'

    Write-Host 'Edit Mind scene search synthetic tests passed.' -ForegroundColor Green
} finally {
    if (Test-Path -LiteralPath $testRoot) {
        $resolved = [IO.Path]::GetFullPath($testRoot)
        $temp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
        if (-not $resolved.StartsWith($temp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe synthetic test cleanup target.' }
        $item = Get-Item -LiteralPath $resolved -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Test cleanup target became a reparse point.' }
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
