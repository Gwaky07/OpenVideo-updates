// @ts-nocheck -- Gateway's legacy JS typecheck currently requires full JSDoc
// object modelling for untyped private JSON. Runtime validation below is the
// authoritative security boundary; focused tests exercise every public entry.
import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { lstat, mkdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import { basename, dirname, extname, isAbsolute, join, resolve } from 'node:path'

const receiptRevision = 'qa010-jianying-manual-export-receipt-v1'
const fingerprintPattern = /^[a-f0-9]{64}$/u
const receiptIdPattern = /^ovjexport_v1_[a-z0-9_-]{8,160}$/iu
const signaturePattern = /^[A-Za-z0-9_-]{43}$/u

/** @typedef {Record<string, any>} AnyRecord */

/** @param {unknown} value */
/** @returns {value is AnyRecord} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {readonly string[]} keys */
const exactKeys = (value, keys) => record(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key))
/** @param {unknown} value */
/** @returns {string} */
const canonical = (value) => Array.isArray(value)
  ? `[${value.map(canonical).join(',')}]`
  : !record(value)
    ? JSON.stringify(value)
    : `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`
/** @param {Record<string, any>} receipt */
const unsignedReceipt = (receipt) => {
  const { integrity_revision: _revision, integrity_signature: _signature, ...unsigned } = receipt
  return unsigned
}

export const manualExportAttestation = 'opened-edited-saved-reopened-exported'

/** @param {Record<string, any>} receipt @param {string} integrityKey */
export const signManualExportReceipt = (receipt, integrityKey) =>
  createHmac('sha256', integrityKey).update(canonical(unsignedReceipt(receipt))).digest('base64url')

/** @param {Record<string, any>} receipt @param {string} integrityKey */
export const verifyManualExportReceiptSignature = (receipt, integrityKey) => {
  if (!fingerprintPattern.test(integrityKey ?? '') || !signaturePattern.test(receipt?.integrity_signature ?? '')) return false
  const expected = signManualExportReceipt(receipt, integrityKey)
  return timingSafeEqual(Buffer.from(expected), Buffer.from(receipt.integrity_signature))
}

/**
 * The writer has two owner schemas: legacy (six fields) and RenderBundle-bound
 * (seven fields). A manual export receipt accepts only the latter.
 * @param {unknown} owner
 */
export const parseBoundDraftOwner = (owner) => {
  const keys = ['bundle_fingerprint', 'draft_id', 'output_fingerprint', 'owner_id', 'phase', 'request_id', 'schema_version']
  if (!exactKeys(owner, keys) || owner.schema_version !== 2 || owner.phase !== 'committed' ||
      typeof owner.draft_id !== 'string' || !/^OpenVideo-JY(?:132-packaging|138-private-batch)-[0-9]{10,20}$/u.test(owner.draft_id) ||
      typeof owner.owner_id !== 'string' || owner.owner_id.length === 0 ||
      typeof owner.request_id !== 'string' || owner.request_id.length === 0 ||
      !fingerprintPattern.test(owner.output_fingerprint ?? '') || !fingerprintPattern.test(owner.bundle_fingerprint ?? '')) return null
  return Object.freeze({ ...owner })
}

/** @param {unknown} probe @returns {{container: 'mp4', video_codec: string, audio_codec: string | null, duration_us: number} | null} */
export const parseMp4Probe = (probe) => {
  if (!record(probe) || !record(probe.format) || !Array.isArray(probe.streams) ||
      typeof probe.format.format_name !== 'string' || !probe.format.format_name.split(',').includes('mp4')) return null
  const durationSeconds = Number(probe.format.duration)
  if (!Number.isFinite(durationSeconds) || durationSeconds <= 0 || durationSeconds > 86_400) return null
  const streams = /** @type {unknown[]} */ (probe.streams)
  const video = streams.find((stream) => record(stream) && stream.codec_type === 'video' && typeof stream.codec_name === 'string' && stream.codec_name.length <= 32)
  if (!video) return null
  const audio = streams.find((stream) => record(stream) && stream.codec_type === 'audio' && typeof stream.codec_name === 'string' && stream.codec_name.length <= 32)
  return Object.freeze({
    container: 'mp4', video_codec: video.codec_name, audio_codec: audio?.codec_name ?? null,
    duration_us: Math.round(durationSeconds * 1_000_000),
  })
}

/** @param {Buffer} bytes */
export const fingerprintExportBytes = (bytes) => createHash('sha256').update(bytes).digest('hex')

/**
 * Construct a private receipt only after callers separately verify both the
 * signed live same-draft registry and the current bound owner metadata.
 * Export file names are deliberately absent: a name never proves provenance.
 */
/** @param {{evidence: AnyRecord, owner: unknown, media: AnyRecord, now?: number, nonce?: string}} input */
export const createManualExportReceipt = ({ evidence, owner, media, now = Date.now(), nonce = randomBytes(6).toString('hex') }) => {
  const parsedOwner = parseBoundDraftOwner(owner)
  if (!record(evidence) || !parsedOwner || !record(media) ||
      evidence.manual_evidence_verified !== true || evidence.manual_attestation !== 'opened-edited-saved-reopened' ||
      evidence.same_draft !== true || typeof evidence.draft_id !== 'string' || evidence.draft_id !== parsedOwner.draft_id ||
      evidence.bundle_fingerprint !== parsedOwner.bundle_fingerprint || !fingerprintPattern.test(evidence.bundle_fingerprint ?? '') ||
      !fingerprintPattern.test(evidence.post_save_fingerprint ?? '') || !fingerprintPattern.test(evidence.content_fingerprint ?? '') ||
      !fingerprintPattern.test(evidence.evidence_fingerprint ?? '') || !fingerprintPattern.test(parsedOwner.bundle_fingerprint) ||
      !fingerprintPattern.test(media.sha256 ?? '') || !Number.isSafeInteger(media.byte_length) || media.byte_length <= 0 ||
      media.container !== 'mp4' || typeof media.video_codec !== 'string' || media.video_codec.length === 0 || media.video_codec.length > 32 ||
      !(media.audio_codec === null || (typeof media.audio_codec === 'string' && media.audio_codec.length > 0 && media.audio_codec.length <= 32)) ||
      !Number.isSafeInteger(media.duration_us) || media.duration_us <= 0 || media.duration_us > 86_400_000_000 ||
      typeof evidence.evidence_id !== 'string' || !/^ovjevidence_v1_[a-z0-9_-]{8,160}$/iu.test(evidence.evidence_id) ||
      typeof evidence.profile_id !== 'string' || typeof evidence.app_version !== 'string' ||
      !Number.isSafeInteger(now) || now < 0 || typeof nonce !== 'string' || !/^[a-f0-9]{8,64}$/u.test(nonce)) {
    throw new Error('QA010_MANUAL_EXPORT_RECEIPT_INVALID')
  }
  return Object.freeze({
    schema_version: 1,
    kind: 'qa010_jianying_manual_export_receipt',
    receipt_id: `ovjexport_v1_${now}_${nonce}`,
    manual_export_attested: true,
    manual_attestation: manualExportAttestation,
    same_draft: true,
    draft_id: parsedOwner.draft_id,
    bundle_fingerprint: parsedOwner.bundle_fingerprint,
    evidence_id: evidence.evidence_id,
    evidence_fingerprint: evidence.evidence_fingerprint,
    post_save_fingerprint: evidence.post_save_fingerprint,
    content_fingerprint: evidence.content_fingerprint,
    profile_id: evidence.profile_id,
    app_version: evidence.app_version,
    export_sha256: media.sha256,
    export_bytes: media.byte_length,
    container: media.container,
    video_codec: media.video_codec,
    audio_codec: media.audio_codec,
    duration_us: media.duration_us,
    integrity_revision: receiptRevision,
  })
}

const receiptKeys = Object.freeze([
  'schema_version', 'kind', 'receipt_id', 'manual_export_attested', 'manual_attestation', 'same_draft', 'draft_id',
  'bundle_fingerprint', 'evidence_id', 'evidence_fingerprint', 'post_save_fingerprint', 'content_fingerprint',
  'profile_id', 'app_version', 'export_sha256', 'export_bytes', 'container', 'video_codec', 'audio_codec', 'duration_us',
  'integrity_revision', 'integrity_signature',
])

/** @param {unknown} receipt @param {string} integrityKey @returns {Readonly<AnyRecord> | null} */
export const parseManualExportReceipt = (receipt, integrityKey) => {
  if (!exactKeys(receipt, receiptKeys) || receipt.schema_version !== 1 || receipt.kind !== 'qa010_jianying_manual_export_receipt' ||
      !receiptIdPattern.test(receipt.receipt_id ?? '') || receipt.manual_export_attested !== true || receipt.manual_attestation !== manualExportAttestation ||
      receipt.same_draft !== true || typeof receipt.draft_id !== 'string' || !/^OpenVideo-JY(?:132-packaging|138-private-batch)-[0-9]{10,20}$/u.test(receipt.draft_id) ||
      !['bundle_fingerprint', 'evidence_fingerprint', 'post_save_fingerprint', 'content_fingerprint', 'export_sha256'].every((key) => fingerprintPattern.test(receipt[key] ?? '')) ||
      typeof receipt.evidence_id !== 'string' || !/^ovjevidence_v1_[a-z0-9_-]{8,160}$/iu.test(receipt.evidence_id) ||
      typeof receipt.profile_id !== 'string' || typeof receipt.app_version !== 'string' || !Number.isSafeInteger(receipt.export_bytes) || receipt.export_bytes <= 0 ||
      receipt.container !== 'mp4' || typeof receipt.video_codec !== 'string' || receipt.video_codec.length === 0 ||
      !(receipt.audio_codec === null || (typeof receipt.audio_codec === 'string' && receipt.audio_codec.length > 0)) ||
      !Number.isSafeInteger(receipt.duration_us) || receipt.duration_us <= 0 || receipt.integrity_revision !== receiptRevision ||
      !verifyManualExportReceiptSignature(receipt, integrityKey)) return null
  return Object.freeze({ ...receipt })
}

/** @param {AnyRecord} receipt */
export const publicManualExportReceipt = (receipt) => Object.freeze({
  ok: true,
  status: 'verified',
  artifact_id: receipt.receipt_id,
  receipt_fingerprint: createHash('sha256').update(canonical(receipt)).digest('hex'),
})

/**
 * Read a user-selected export candidate without allowing a file name to act as
 * a draft binding. On Windows callers may pass readNoReparse to ensure native
 * handle inspection; all callers additionally reject links and non-files.
 */
/** @param {{exportFile: string, readNoReparse?: ((file: string, root: string) => Promise<Buffer>) | null, read?: ((file: string) => Promise<Buffer>) | null, inspect?: typeof lstat, inspectStat?: typeof stat}} input */
export const readOrdinaryExportCandidate = async ({ exportFile, readNoReparse = null, read = null, inspect = lstat, inspectStat = stat }) => {
  if (typeof exportFile !== 'string' || !isAbsolute(exportFile) || extname(exportFile).toLowerCase() !== '.mp4') throw new Error('QA010_EXPORT_CANDIDATE_INVALID')
  const resolved = resolve(exportFile)
  const metadata = await inspect(resolved).catch(() => null)
  const stable = await inspectStat(resolved).catch(() => null)
  if (!metadata?.isFile?.() || metadata.isSymbolicLink?.() || !stable?.isFile?.() || stable.size <= 0 || stable.size > 8 * 1024 * 1024 * 1024) {
    throw new Error('QA010_EXPORT_CANDIDATE_INVALID')
  }
  let bytes
  if (typeof readNoReparse === 'function') bytes = await readNoReparse(resolved, dirname(resolved))
  else if (typeof read === 'function') bytes = await read(resolved)
  else bytes = await (await import('node:fs/promises')).readFile(resolved)
  if (!Buffer.isBuffer(bytes) || bytes.length !== stable.size || bytes.length === 0) throw new Error('QA010_EXPORT_CANDIDATE_INVALID')
  return Object.freeze({ bytes, byte_length: bytes.length, filename: basename(resolved) })
}

/** @param {{receiptRoot: string, receipt: Record<string, any>, filename?: string}} input */
export const publishManualExportReceipt = async ({ receiptRoot, receipt, filename = 'receipt.json' }) => {
  if (typeof receiptRoot !== 'string' || !isAbsolute(receiptRoot) || !record(receipt) || !/^[a-z0-9][a-z0-9-]{0,80}\.json$/u.test(filename)) {
    throw new Error('QA010_MANUAL_EXPORT_RECEIPT_INVALID')
  }
  await mkdir(receiptRoot, { recursive: true, mode: 0o700 })
  const output = join(receiptRoot, filename)
  const temporary = `${output}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`
  try {
    await writeFile(temporary, `${JSON.stringify(receipt)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await rename(temporary, output)
  } finally {
    await rm(temporary, { force: true })
  }
}

export { receiptRevision }
