import { fingerprintCanonical } from './editor-agent-contracts.mjs'

const tokenPattern = /^ovjtxtanim_v1_[A-Za-z0-9_-]{12,160}$/u
const resourcePattern = /^[A-Za-z0-9_-]{4,80}$/u
const admittedProfileId = 'jianying-11-1-provisional'
const admittedVersion = '11.1.0.14287'

export class JianyingTextAnimationCatalogError extends Error {
  /** @param {string} code */
  constructor(code) { super(code); this.code = code }
}

/** @param {unknown} value */
export const parseJianyingTextAnimationCatalog = (value) => {
  /** @type {any} */ const candidate = value
  if (!candidate || typeof candidate !== 'object' || candidate.schema_version !== 1 || candidate.kind !== 'jy083_text_animation_catalog' || !Array.isArray(candidate.entries) || typeof candidate.fingerprint !== 'string') return null
  const entries = candidate.entries.map((/** @type {any} */ entry) => {
    if (!entry || entry.capability_id !== 'animation.text.named' || typeof entry.animation_token !== 'string' || !tokenPattern.test(entry.animation_token) || typeof entry.resource_id !== 'string' || !resourcePattern.test(entry.resource_id) || !Number.isSafeInteger(entry.duration_us) || entry.duration_us <= 0 || entry.duration_us > 10_000_000) {
      throw new JianyingTextAnimationCatalogError('JY083_TEXT_ANIMATION_CATALOG_INVALID')
    }
    return Object.freeze({ animationToken: entry.animation_token, resourceId: entry.resource_id, durationUs: entry.duration_us })
  })
  if (entries.length === 0 || new Set(entries.map((/** @type {{animationToken: string}} */ entry) => entry.animationToken)).size !== entries.length) throw new JianyingTextAnimationCatalogError('JY083_TEXT_ANIMATION_CATALOG_INVALID')
  const body = { schema_version: 1, kind: 'jy083_text_animation_catalog', entries: candidate.entries }
  if (fingerprintCanonical(body) !== candidate.fingerprint) throw new JianyingTextAnimationCatalogError('JY083_TEXT_ANIMATION_CATALOG_FINGERPRINT_INVALID')
  return Object.freeze({ fingerprint: candidate.fingerprint, entries: Object.freeze(entries) })
}

/** @param {unknown} value @param {string} fingerprint @param {{profileId: string, version: string}} desktop */
export const parseJianyingTextAnimationEvidence = (value, fingerprint, desktop) => {
  /** @type {any} */ const candidate = value
  const keys = ['schema_version', 'manual_evidence_verified', 'manual_attestation', 'profile_id', 'app_version', 'catalog_fingerprint', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'matching_animation_count', 'attached', 'temporary_media_cleaned']
  if (!candidate || Object.keys(candidate).sort().join('\0') !== keys.sort().join('\0') || candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true || candidate.manual_attestation !== 'opened-edited-saved-reopened' || desktop.profileId !== admittedProfileId || desktop.version !== admittedVersion || candidate.profile_id !== admittedProfileId || candidate.app_version !== admittedVersion || candidate.catalog_fingerprint !== fingerprint || candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true || candidate.matching_animation_count !== 1 || candidate.attached !== true || candidate.temporary_media_cleaned !== true) return null
  return Object.freeze({ ...candidate })
}

/** @param {{entries: readonly {animationToken: string, resourceId: string, durationUs: number}[]}} catalog @param {unknown} token */
export const resolveJianyingTextAnimationToken = (catalog, token) => {
  if (typeof token !== 'string' || !tokenPattern.test(token)) throw new JianyingTextAnimationCatalogError('JY083_TEXT_ANIMATION_TOKEN_UNRESOLVED')
  const entry = catalog?.entries?.find((candidate) => candidate.animationToken === token)
  if (!entry) throw new JianyingTextAnimationCatalogError('JY083_TEXT_ANIMATION_TOKEN_UNRESOLVED')
  return { resourceId: entry.resourceId, durationUs: entry.durationUs }
}
