import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const expectedSpeed = 1.5
const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY068_MANUAL_ATTESTATION_REQUIRED')
  const root = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy068-speed')
  const pendingPath = path.join(root, 'pending.json')
  const pending = JSON.parse(await readFile(pendingPath, 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8')) })
  if (desktop.profileId !== pending.profile_id || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root)) throw new Error('JY068_EVIDENCE_BINDING_INVALID')
  const mediaRoot = path.resolve(pending.media_root)
  let mediaStillOwned = false
  try {
    const canonicalTemp = await realpath(tmpdir()); const canonicalMedia = await realpath(mediaRoot); const relative = path.relative(canonicalTemp, canonicalMedia); const metadata = await lstat(mediaRoot)
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative) || !path.basename(canonicalMedia).startsWith('openvideo-jy068-speed-') || !metadata.isDirectory() || metadata.isSymbolicLink()) throw new Error('JY068_TEMP_OWNERSHIP_INVALID')
    mediaStillOwned = true
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
    // A prior verified run may have completed only the owned-media cleanup.
    // The draft content and post-save fingerprint are rechecked below before
    // allowing this idempotent recovery to remove the pending lease.
  }
  const tempRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy068-verify-'))
  try {
    const encryptedPath = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json'); const encrypted = await readFile(encryptedPath)
    const postFingerprint = createHash('sha256').update(encrypted).digest('hex'); if (postFingerprint === pending.pre_open_fingerprint) throw new Error('JY068_MANUAL_EDIT_NOT_PERSISTED')
    const plain = path.join(tempRoot, 'draft_content.json'); const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(encryptedPath, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY068_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8'))
    const primaryTracks = (content.tracks ?? []).filter((track) => track?.name === 'video-primary')
    const segments = primaryTracks[0]?.segments ?? []
    // Jianying rewrites the target duration to the speed-adjusted value and may
    // round the source duration by one microsecond. Bind on the unique segment
    // range and persisted speed, not on the pre-edit target duration.
    const matching = segments.filter((segment) =>
      Math.abs((segment?.source_timerange?.duration ?? 0) - 4_000_000) <= 2 &&
      typeof segment?.speed === 'number' && Math.abs(segment.speed - expectedSpeed) <= 1e-9)
    if (primaryTracks.length !== 1 || segments.length !== 1 || matching.length !== 1) throw new Error('JY068_SPEED_PERSISTENCE_INVALID')
    const record = { schema_version: 1, manual_evidence_verified: true, profile_id: pending.profile_id, app_version: pending.app_version, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, persisted_speed: expectedSpeed, pre_open_fingerprint: pending.pre_open_fingerprint, post_save_fingerprint: postFingerprint }
    await securePrivateRuntimeRoot(root); await writeFile(path.join(root, 'post-save.json'), `${JSON.stringify(record)}\n`, { encoding: 'utf8', mode: 0o600 })
    if (mediaStillOwned) await rm(mediaRoot, { recursive: true, force: true })
    await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, capability: 'speed.constant', profile: pending.profile_id, version: pending.app_version, persisted_speed: expectedSpeed, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, temporaryMediaCleaned: true })}\n`)
  } finally { await rm(tempRoot, { recursive: true, force: true }) }
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.message ?? 'JY068_VERIFY_FAILED' })}\n`); process.exitCode = 1 })
