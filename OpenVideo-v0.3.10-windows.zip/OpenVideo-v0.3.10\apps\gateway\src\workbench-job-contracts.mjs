const jobTypes = new Set([
  'material_analysis',
  'storyboard_generation',
  'preview_generation',
  'reference_template_generation',
  'jianying_draft_export',
  'editor_agent',
])
const jobStatuses = new Set([
  'queued',
  'running',
  'cancelling',
  'succeeded',
  'failed',
  'cancelled',
  'timed_out',
])
const attemptStatuses = new Set([
  'queued',
  'running',
  'succeeded',
  'failed',
  'cancelled',
  'timed_out',
])
const terminalStatuses = new Set(['succeeded', 'failed', 'cancelled', 'timed_out'])

const leaseKeys = ['acquiredAt', 'expiresAt', 'generation', 'ownerId', 'token']
const checkpointKeys = ['data', 'generation', 'progressPercent', 'stage', 'updatedAt']
const attemptKeys = [
  'attemptId',
  'deadlineAt',
  'error',
  'finishedAt',
  'generation',
  'lease',
  'startedAt',
  'status',
]
const jobKeys = [
  'attempts',
  'cancelRequestedAt',
  'checkpoint',
  'createdAt',
  'error',
  'idempotencyKey',
  'jobId',
  'privateInput',
  'projectId',
  'result',
  'status',
  'type',
  'updatedAt',
]
const publicAttemptKeys = ['deadlineAt', 'generation', 'status']
const publicJobKeys = [
  'attempt',
  'cancelRequested',
  'createdAt',
  'detail',
  'error',
  'jobId',
  'progressPercent',
  'projectId',
  'result',
  'status',
  'type',
  'updatedAt',
]

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const isTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @param {unknown} value */
const isCanonicalTimestamp = (value) =>
  isTimestamp(value) && new Date(/** @type {string} */ (value)).toISOString() === value
/** @param {unknown} value @param {number} [maximum] */
const isIdentifier = (value, maximum = 200) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= maximum &&
  !value.includes('\u0000')
/** @param {unknown} value */
const isPublicResourceId = (value) =>
  isIdentifier(value) &&
  /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u.test(/** @type {string} */ (value))
/** @param {unknown} value */
const isSafeVisibleDraftResourceId = (value) =>
  typeof value === 'string' &&
  value === value.trim() &&
  value.length > 0 &&
  value.length <= 100 &&
  value !== '.' &&
  value !== '..' &&
  !/[\\/\u0000-\u001f]/u.test(value) &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value)
/** @param {unknown} value */
const isProgress = (value) =>
  Number.isSafeInteger(value) && Number(value) >= 0 && Number(value) <= 100
/** @param {unknown} value @param {string[]} keys @returns {value is Record<string, any>} */
const hasExactKeys = (value, keys) =>
  isRecord(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} value @returns {boolean} */
const isJsonValue = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true
  if (typeof value === 'number') return Number.isFinite(value)
  if (Array.isArray(value)) return value.length <= 10_000 && value.every(isJsonValue)
  if (!isRecord(value) || Object.keys(value).length > 10_000) return false
  return Object.entries(value).every(([key, item]) =>
    key.length > 0 && key.length <= 200 && !key.includes('\u0000') && isJsonValue(item))
}
const writerDegradationCapabilities = new Set(['text.flower.private', 'text.bubble.private'])
/** @param {unknown} value */
const isWriterDegradation = (value) =>
  hasExactKeys(value, ['segmentId', 'from', 'to', 'reason']) &&
  isPublicResourceId(value.segmentId) &&
  writerDegradationCapabilities.has(value.from) &&
  value.to === 'text.rich' &&
  value.reason === 'PRIVATE_TEXT_CAPABILITY_UNAVAILABLE'
/** @param {any} value @param {unknown} [jobType] */
const isPublicResult = (value, jobType) => {
  if (value === null) return true
  if (!isRecord(value)) return false
  const auditedKeys = [
    'outputFingerprint',
    'resourceId',
    'summary',
    'templateFingerprint',
    'templateRevision',
  ]
  const hasWriterProjection = Object.hasOwn(value, 'writerProjectionFingerprint')
  const hasWriterDegradations = Object.hasOwn(value, 'writerDegradations')
  const hasPreviewStatus = jobType === 'preview_generation' && Object.hasOwn(value, 'previewStatus')
  const validPreviewStatus = !hasPreviewStatus || (
    ['ready', 'preview_degraded'].includes(value.previewStatus) &&
    Array.isArray(value.degradationCodes) && value.degradationCodes.length <= 32 &&
    value.degradationCodes.every((code) => typeof code === 'string' && /^[A-Z][A-Z0-9_]{2,95}$/u.test(code)) &&
    (value.previewStatus === 'preview_degraded' ? value.degradationCodes.length > 0 : value.degradationCodes.length === 0)
  )
  const audited =
      ((hasExactKeys(value, auditedKeys) ||
        (hasPreviewStatus && hasExactKeys(value, [...auditedKeys, 'previewStatus', 'degradationCodes']))) ||
        (jobType === 'jianying_draft_export' && hasWriterProjection &&
          hasExactKeys(value, [
            ...auditedKeys,
            'writerProjectionFingerprint',
            ...(hasWriterDegradations ? ['writerDegradations'] : []),
          ]))) && validPreviewStatus &&
      typeof value.outputFingerprint === 'string' &&
      /^[a-f0-9]{64}$/u.test(value.outputFingerprint) &&
      (!hasWriterProjection || (
        typeof value.writerProjectionFingerprint === 'string' &&
        /^[a-f0-9]{64}$/u.test(value.writerProjectionFingerprint)
      )) &&
      (!hasWriterDegradations || (
        hasWriterProjection &&
        Array.isArray(value.writerDegradations) &&
        value.writerDegradations.length > 0 &&
        value.writerDegradations.length <= 100 &&
        value.writerDegradations.every(isWriterDegradation)
      )) &&
      (
        (
          value.templateFingerprint === null &&
          value.templateRevision === null
        ) ||
        (
          typeof value.templateFingerprint === 'string' &&
          /^[a-f0-9]{64}$/u.test(value.templateFingerprint) &&
          Number.isSafeInteger(value.templateRevision) &&
          value.templateRevision >= 1
        )
      )
  const legacy = hasExactKeys(value, ['resourceId', 'summary'])
  const editor = jobType === 'editor_agent' && hasExactKeys(value, [
    'resourceId',
    'summary',
    'timelineId',
    'timelineRevision',
    'timelineRevisionFingerprint',
  ]) &&
    isPublicResourceId(value.timelineId) &&
    Number.isSafeInteger(value.timelineRevision) &&
    value.timelineRevision >= 1 &&
    typeof value.timelineRevisionFingerprint === 'string' &&
    /^[a-f0-9]{64}$/u.test(value.timelineRevisionFingerprint)
  const validResourceId = isPublicResourceId(value.resourceId) ||
    (jobType === 'jianying_draft_export' && isSafeVisibleDraftResourceId(value.resourceId))
  return (
    (['storyboard_generation', 'preview_generation'].includes(String(jobType))
      ? audited
      : editor || legacy || audited) &&
    validResourceId &&
    typeof value.summary === 'string' &&
    value.summary.length <= 1000 &&
    !containsPrivateReference(value.summary)
  )
}
/** @param {any} value */
const isPublicError = (value) =>
  value === null ||
  (hasExactKeys(value, ['code', 'recoverable']) &&
    isIdentifier(value.code, 160) &&
    typeof value.recoverable === 'boolean')
/** @param {unknown} value */
const isPublicDetail = (value) =>
  value === null ||
  (typeof value === 'string' &&
    value.trim().length > 0 &&
    value.length <= 300 &&
    !value.includes('\u0000') &&
    !containsPrivateReference(value))
/** @param {string} value */
const containsPrivateReference = (value) => {
  const backslash = String.fromCharCode(92)
  const lower = value.toLowerCase()
  const windowsDrive =
    value.length >= 3 &&
    /[a-z]/iu.test(value[0]) &&
    value[1] === ':' &&
    (value[2] === backslash || value[2] === '/')
  return windowsDrive ||
    value.startsWith(backslash.repeat(2)) ||
    lower.includes('file://') ||
    /\/(?:home|users|private|var|tmp|mnt|volumes)\//iu.test(value)
}

export class WorkbenchJobContractError extends Error {
  constructor() {
    super('WORKBENCH_JOB_CONTRACT_INVALID')
    this.name = 'WorkbenchJobContractError'
    this.code = 'WORKBENCH_JOB_CONTRACT_INVALID'
    this.status = 500
  }
}

/** @param {unknown} valid */
const assertValid = (valid) => {
  if (!valid) throw new WorkbenchJobContractError()
}

/** @param {any} value @returns {Record<string, any>} */
export const assertLease = (value) => {
  assertValid(
    hasExactKeys(value, leaseKeys) &&
    isIdentifier(value.token) &&
    Number.isSafeInteger(value.generation) &&
    value.generation > 0 &&
    isIdentifier(value.ownerId) &&
    isTimestamp(value.acquiredAt) &&
    isTimestamp(value.expiresAt) &&
    Date.parse(value.expiresAt) > Date.parse(value.acquiredAt),
  )
  return clone(value)
}

/** @param {any} value @returns {Record<string, any>} */
export const assertCheckpoint = (value) => {
  assertValid(
    hasExactKeys(value, checkpointKeys) &&
    Number.isSafeInteger(value.generation) &&
    value.generation > 0 &&
    isIdentifier(value.stage, 160) &&
    isProgress(value.progressPercent) &&
    isTimestamp(value.updatedAt) &&
    isJsonValue(value.data),
  )
  return clone(value)
}

/** @param {any} value @param {{allowNoDeadline?: boolean}} [options] @returns {Record<string, any>} */
export const assertAttempt = (value, options = {}) => {
  const deadlineRequired = options.allowNoDeadline !== true
  const validBase =
    hasExactKeys(value, attemptKeys) &&
    isIdentifier(value.attemptId) &&
    Number.isSafeInteger(value.generation) &&
    value.generation > 0 &&
    (value.deadlineAt === null || isCanonicalTimestamp(value.deadlineAt)) &&
    attemptStatuses.has(value.status) &&
    (value.startedAt === null || isTimestamp(value.startedAt)) &&
    (value.finishedAt === null || isTimestamp(value.finishedAt)) &&
    (value.lease === null || (() => {
      try {
        return assertLease(value.lease).generation === value.generation
      } catch {
        return false
      }
    })()) &&
    isPublicError(value.error)
  const validState =
    (
      value.status === 'queued' &&
      value.finishedAt === null &&
      value.lease === null &&
      (
        (value.startedAt === null && value.deadlineAt === null) ||
        (value.startedAt !== null && (!deadlineRequired || value.deadlineAt !== null))
      )
    ) ||
    (
      value.status === 'running' &&
      value.startedAt !== null &&
      (!deadlineRequired || value.deadlineAt !== null) &&
      value.finishedAt === null &&
      value.lease !== null
    ) ||
    (
      terminalStatuses.has(value.status) &&
      value.startedAt !== null &&
      value.finishedAt !== null &&
      value.lease === null &&
      (!deadlineRequired || value.deadlineAt !== null || value.status === 'cancelled')
    )
  assertValid(validBase && validState)
  return clone(value)
}

/** @param {any} value @returns {Record<string, any>} */
export const assertJobRecord = (value) => {
  let attemptsValid = false
  if (hasExactKeys(value, jobKeys) && Array.isArray(value.attempts) && value.attempts.length > 0) {
    try {
      value.attempts.forEach((attempt) => assertAttempt(attempt, {
        allowNoDeadline: value.type === 'material_analysis',
      }))
      attemptsValid = value.attempts.every((/** @type {Record<string, any>} */ attempt, /** @type {number} */ index) =>
        attempt.generation === index + 1 &&
        (index === 0 || attempt.generation > value.attempts[index - 1].generation))
    } catch {
      attemptsValid = false
    }
  }
  let checkpointValid = value?.checkpoint === null
  if (isRecord(value) && value.checkpoint !== null) {
    try {
      checkpointValid =
        assertCheckpoint(value.checkpoint).generation === value.attempts?.at(-1)?.generation
    } catch {
      checkpointValid = false
    }
  }
  const latest = isRecord(value) && Array.isArray(value.attempts) ? value.attempts.at(-1) : null
  const stateMatches =
    (value?.status === 'queued' && latest?.status === 'queued') ||
    (value?.status === 'running' && latest?.status === 'running') ||
    (value?.status === 'cancelling' && ['queued', 'running'].includes(latest?.status)) ||
    (terminalStatuses.has(value?.status) && latest?.status === value.status)
  const outcomeMatches =
    (value?.status === 'succeeded' && value.result !== null && value.error === null) ||
    (['failed', 'timed_out'].includes(value?.status) && value.result === null && value.error !== null) ||
    (!terminalStatuses.has(value?.status) && value.result === null && value.error === null) ||
    (value?.status === 'cancelled' && value.result === null)
  assertValid(
    hasExactKeys(value, jobKeys) &&
    isIdentifier(value.jobId) &&
    isIdentifier(value.projectId) &&
    isIdentifier(value.idempotencyKey) &&
    jobTypes.has(value.type) &&
    jobStatuses.has(value.status) &&
    isTimestamp(value.createdAt) &&
    isTimestamp(value.updatedAt) &&
    (value.cancelRequestedAt === null || isTimestamp(value.cancelRequestedAt)) &&
    isRecord(value.privateInput) &&
    typeof value.privateInput.inputFingerprint === 'string' &&
    /^[a-f0-9]{64}$/u.test(value.privateInput.inputFingerprint) &&
    isJsonValue(value.privateInput) &&
    attemptsValid &&
    checkpointValid &&
    isPublicResult(value.result, value.type) &&
    isPublicError(value.error) &&
    stateMatches &&
    outcomeMatches,
  )
  return clone(value)
}

/** @param {any} value @returns {Record<string, any>} */
export const assertPublicJobDto = (value) => {
  const validAttempt =
    hasExactKeys(value?.attempt, publicAttemptKeys) &&
    Number.isSafeInteger(value.attempt.generation) &&
    value.attempt.generation > 0 &&
    attemptStatuses.has(value.attempt.status) &&
    (value.attempt.deadlineAt === null || isCanonicalTimestamp(value.attempt.deadlineAt))
  assertValid(
    hasExactKeys(value, publicJobKeys) &&
    isIdentifier(value.jobId) &&
    isIdentifier(value.projectId) &&
    jobTypes.has(value.type) &&
    jobStatuses.has(value.status) &&
    isProgress(value.progressPercent) &&
    isTimestamp(value.createdAt) &&
    isTimestamp(value.updatedAt) &&
    typeof value.cancelRequested === 'boolean' &&
    validAttempt &&
    isPublicDetail(value.detail) &&
    isPublicResult(value.result, value.type) &&
    isPublicError(value.error),
  )
  return clone(value)
}

/** @param {unknown} value */
export const toPublicJobDto = (value) => {
  const job = assertJobRecord(value)
  const latestAttempt = job.attempts.at(-1)
  const checkpointDetail = job.checkpoint?.data?.detail
  const active = ['queued', 'running', 'cancelling'].includes(job.status)
  return assertPublicJobDto({
    jobId: job.jobId,
    projectId: job.projectId,
    type: job.type,
    status: job.status,
    progressPercent: job.status === 'succeeded'
      ? 100
      : (job.checkpoint?.progressPercent ?? 0),
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    cancelRequested: job.cancelRequestedAt !== null,
    detail: active && isPublicDetail(checkpointDetail)
      ? checkpointDetail
      : job.status === 'succeeded' && job.result?.summary && isPublicDetail(job.result.summary)
        ? job.result.summary
        : null,
    attempt: {
      generation: latestAttempt.generation,
      status: latestAttempt.status,
      deadlineAt: latestAttempt.deadlineAt,
    },
    result: job.result,
    error: job.error,
  })
}
