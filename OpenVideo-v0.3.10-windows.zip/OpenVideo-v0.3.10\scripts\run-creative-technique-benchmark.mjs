import { readFile } from 'node:fs/promises'
import { dirname, isAbsolute, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  evaluateCreativeTechniqueBenchmark,
  validateCreativeTechniqueBenchmark,
} from '../apps/gateway/src/creative-technique-benchmark.mjs'
import { loadCreativeKnowledge } from '../apps/gateway/src/creative-knowledge-loader.mjs'
import {
  evaluateCreativeTechniqueRolloutWindow,
  loadCreativeTechniqueReceiptHistory,
  publishCreativeTechniqueReceipt,
} from '../apps/gateway/src/creative-technique-receipts.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'

const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const defaultBenchmarkPath = resolve(repositoryRoot, 'config', 'creative-knowledge', 'technique-benchmark-v1.json')
const arguments_ = process.argv.slice(2)
if (arguments_.length < 1 || arguments_.length > 2 || !arguments_.every(isAbsolute)) {
  throw new Error('CREATIVE_TECHNIQUE_ARGUMENTS_INVALID')
}
const runtime = loadLocalRuntimeConfig(
  { OPENVIDEO_RUNTIME_DATA_ROOT: arguments_[0] },
  { repositoryRoot },
)
const benchmark = validateCreativeTechniqueBenchmark(JSON.parse(await readFile(
  arguments_[1] ?? defaultBenchmarkPath,
  'utf8',
)))
const knowledge = await loadCreativeKnowledge({ release: 'v2' })
const evaluation = evaluateCreativeTechniqueBenchmark({ benchmark, knowledge })
const evidenceRoot = join(runtime.dataRoot, 'evidence', 'creative-technique', 'benchmark-v1')
const history = await loadCreativeTechniqueReceiptHistory(evidenceRoot)
const rolloutWindow = evaluateCreativeTechniqueRolloutWindow([...history.runs, evaluation], history)
const receipt = {
  schema_version: 1,
  created_at: new Date().toISOString(),
  evaluation,
  rollout_window: rolloutWindow,
}
await publishCreativeTechniqueReceipt(evidenceRoot, receipt)
process.stdout.write(`${JSON.stringify({
  event: 'CREATIVE_TECHNIQUE_BENCHMARK_EVALUATED',
  evaluation_verdict: evaluation.verdict,
  rollout_verdict: rolloutWindow.verdict,
  rollout_reason: rolloutWindow.reason,
  qualifying_run_count: rolloutWindow.qualifying_run_count,
  benchmark_fingerprint: evaluation.benchmark_fingerprint,
  knowledge_fingerprint: evaluation.knowledge_fingerprint,
  capability_registry_fingerprint: evaluation.capability_registry_fingerprint,
  timeline_fingerprint: evaluation.timeline_fingerprints.active,
  preview_projection_fingerprint: evaluation.projection_fingerprints.preview,
  jianying_projection_fingerprint: evaluation.projection_fingerprints.jianying,
  flag_off_output_difference_count: evaluation.metrics.flag_off_output_difference_count,
})}\n`)
