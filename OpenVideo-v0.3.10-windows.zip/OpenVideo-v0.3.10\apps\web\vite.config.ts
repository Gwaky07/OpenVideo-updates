import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { loadEnv, type ProxyOptions } from 'vite'
import { defineConfig } from 'vitest/config'

const createProxy = (target: string | undefined) =>
  target
    ? {
        target,
        changeOrigin: true,
        rewrite: () => '/health',
      }
    : undefined

const createSameOriginProxy = (target: string | undefined): ProxyOptions | undefined =>
  target
    ? {
        target,
        changeOrigin: true,
        configure: (proxy) => {
          proxy.on('proxyReq', (proxyRequest, request) => {
            if (request.headers.origin) {
              proxyRequest.setHeader('origin', new URL(target).origin)
            }
          })
        },
      }
    : undefined

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const proxy: Record<string, ProxyOptions> = {}
  const openVideoProxy = createProxy(env.OPENVIDEO_API_TARGET)
  const workbenchProxy = createSameOriginProxy(env.OPENVIDEO_API_TARGET)

  if (openVideoProxy) {
    proxy['/api/status/openvideo'] = openVideoProxy
  }
  if (workbenchProxy) {
    proxy['/api/workbench'] = workbenchProxy
    proxy['/api/settings'] = workbenchProxy
    proxy['/api/tts-studio'] = workbenchProxy
    proxy['/api/live'] = workbenchProxy
    proxy['/api/llm'] = workbenchProxy
  }

  return {
    plugins: [react(), tailwindcss()],
    envDir: mode === 'production' ? false : undefined,
    define: mode === 'production'
      ? {
          'import.meta.env.VITE_OPENVIDEO_LIBRARY_PATH': JSON.stringify(''),
          'import.meta.env.VITE_OPENVIDEO_LIBRARY_ASSET_PATH': JSON.stringify(''),
          'import.meta.env.VITE_OPENVIDEO_STORYBOARD_PATH': JSON.stringify(''),
          'import.meta.env.VITE_OPENVIDEO_STORYBOARD_REPLACEMENT_PATH': JSON.stringify(''),
        }
      : undefined,
    server: {
      host: '127.0.0.1',
      port: 4173,
      strictPort: true,
      proxy,
    },
    preview: { host: '127.0.0.1', port: 4174, strictPort: true },
    test: {
      environment: 'jsdom',
      setupFiles: './src/test/setup.ts',
      css: true,
      include: ['src/**/*.test.{ts,tsx}'],
      // Large jsdom page suites are CPU-bound on hosted Windows runners. One
      // worker keeps async UI deadlines meaningful and prevents cross-file
      // resource starvation while preserving each test's own cleanup.
      fileParallelism: false,
      maxWorkers: 1,
    },
  }
})
