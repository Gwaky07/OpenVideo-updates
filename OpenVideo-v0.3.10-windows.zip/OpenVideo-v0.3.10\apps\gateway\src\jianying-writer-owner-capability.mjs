import { selectJianyingWriterOwner } from './jianying-writer-owner-router.mjs'
import { readTimelinePackagingSelections } from './jianying-timeline-packaging-selections.mjs'

const CAPABILITY = /^[a-z][a-z0-9_.-]{2,95}$/
const packagingCapabilityByFamily = Object.freeze({
  flower: 'text.flower.private',
  sticker: 'sticker.named',
  video_effect: 'effect.video.named',
})

/** @param {unknown} value */
const isCapability = (value) => {
  if (!value || typeof value !== 'object') return false
  const candidate = /** @type {Record<string, unknown>} */ (value)
  return ['exportDraft', 'cleanupDraft', 'commitDraft'].every((method) => typeof candidate[method] === 'function')
}

/** @param {unknown} values */
const normalizeNativeCapabilities = (values) => {
  if (values === null) return null
  if (!Array.isArray(values) || values.length > 64 ||
      values.some((value) => typeof value !== 'string' || !CAPABILITY.test(value)) ||
      new Set(values).size !== values.length) {
    throw new TypeError('JY200_NATIVE_CAPABILITY_SET_INVALID')
  }
  return Object.freeze([...values].sort())
}

/**
 * Keep the primary Writer usable while one optional Writer finishes strict
 * startup verification. Each job is pinned to the capability active when its
 * export begins, so a late activation cannot split one draft across Writers.
 * Activation is intentionally one-way for the lifetime of the Gateway.
 * @template {Record<string, any>} T
 * @param {{nativeCapability: T, ownerRepository: {claim: Function, get: Function, getTerminal?: Function, complete: Function}}} input
 * @returns {{capability: T, activate: (capability: T) => boolean}}
 */
export const createRecoverableJianyingWriterOwnerCapability = ({ nativeCapability, ownerRepository }) => {
  if (!isCapability(nativeCapability)) throw new TypeError('JY200_WRITER_OWNER_CAPABILITY_INVALID')
  if (!ownerRepository || typeof ownerRepository.claim !== 'function' ||
      typeof ownerRepository.get !== 'function' || typeof ownerRepository.complete !== 'function') {
    throw new TypeError('JY200_WRITER_OWNER_REPOSITORY_REQUIRED')
  }
  /** @type {T} */
  let activeCapability = nativeCapability
  /** @type {T | null} */
  let recoveredCapability = null
  /** @type {Map<string, T>} */
  const jobs = new Map()
  const pendingExports = new Set()

  /** @param {Record<string, any>} input */
  const jobId = (input) => {
    if (typeof input?.jobId !== 'string' || input.jobId.length === 0) {
      throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
    }
    return input.jobId
  }

  const nativePersistedCapability = /** @type {T} */ (Object.freeze({
    ...nativeCapability,
    /** @param {Record<string, any>} input */
    async cleanupDraft(input) {
      const id = jobId(input)
      const result = await nativeCapability.cleanupDraft(input)
      if (result === true && await ownerRepository.complete({ jobId: id, ownerId: 'native-writer', action: 'cleanup' }) !== true) {
        throw new Error('JY200_WRITER_OWNER_COMPLETION_FAILED')
      }
      return result
    },
    /** @param {Record<string, any>} input */
    async commitDraft(input) {
      const id = jobId(input)
      const result = await nativeCapability.commitDraft(input)
      if (result === true && await ownerRepository.complete({ jobId: id, ownerId: 'native-writer', action: 'commit' }) !== true) {
        throw new Error('JY200_WRITER_OWNER_COMPLETION_FAILED')
      }
      return result
    },
  }))

  /** @param {string} id */
  const resolveJobCapability = async (id) => {
    const pinned = jobs.get(id)
    if (pinned) return { selected: pinned, pinned: true, persisted: null }
    const persisted = await ownerRepository.get(id)
    if (!persisted) return { selected: activeCapability, pinned: false, persisted: null }
    if (persisted.ownerId === 'native-writer') return { selected: nativePersistedCapability, pinned: false, persisted }
    if (recoveredCapability) return { selected: recoveredCapability, pinned: false, persisted }
    throw new Error('JY200_WRITER_OWNER_RECOVERY_PENDING')
  }

  const capability = /** @type {T} */ (Object.freeze({
    ...nativeCapability,
    /** @param {Record<string, any>} input */
    async exportDraft(input) {
      const id = jobId(input)
      if (jobs.has(id) || pendingExports.has(id)) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
      pendingExports.add(id)
      try {
        const resolved = await resolveJobCapability(id)
        let selected = resolved.selected
        const timelineFingerprint = input.richTimeline?.revisionFingerprint ?? input.timeline_fingerprint
        if (resolved.persisted) {
          if (resolved.persisted.timelineFingerprint !== timelineFingerprint ||
              await ownerRepository.claim(resolved.persisted) === false) {
            throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
          }
        } else if (selected === nativeCapability) {
          const claimed = await ownerRepository.claim(Object.freeze({
            jobId: id,
            requestId: id,
            ownerId: 'native-writer',
            timelineFingerprint,
          }))
          if (!claimed) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
          selected = nativePersistedCapability
        }
        jobs.set(id, selected)
        return await selected.exportDraft(input)
      } catch (error) {
        // Keep the pin when the selected Writer may have mutated staging; its
        // cleanup must go back to that same Writer.
        throw error
      } finally {
        pendingExports.delete(id)
      }
    },
    /** @param {Record<string, any>} input */
    async cleanupDraft(input) {
      const id = jobId(input)
      if (pendingExports.has(id)) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
      const terminal = typeof ownerRepository.getTerminal === 'function'
        ? await ownerRepository.getTerminal(id)
        : null
      if (terminal?.state === 'rolled_back') return true
      const { selected } = await resolveJobCapability(id)
      const result = await selected.cleanupDraft(input)
      if (result === true) jobs.delete(id)
      return result
    },
    /** @param {Record<string, any>} input */
    async commitDraft(input) {
      const id = jobId(input)
      if (pendingExports.has(id)) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
      const { selected } = await resolveJobCapability(id)
      const result = await selected.commitDraft(input)
      if (result === true) jobs.delete(id)
      return result
    },
  }))

  return Object.freeze({
    capability,
    /** @param {T} nextCapability */
    activate(nextCapability) {
      if (!isCapability(nextCapability)) throw new TypeError('JY200_WRITER_OWNER_CAPABILITY_INVALID')
      if (recoveredCapability === nextCapability) return false
      if (recoveredCapability) throw new Error('JY200_WRITER_OWNER_RECOVERY_ALREADY_ACTIVE')
      recoveredCapability = nextCapability
      activeCapability = nextCapability
      return true
    },
  })
}

/**
 * Bind one Writer owner to the whole export before any provider mutation.
 * Native remains the fallback when no current external admitted handle covers
 * the complete finalized RichTimeline capability set.
 * @template {Record<string, any>} T
 * @param {{nativeCapability: T, nativeCapabilities?: readonly string[] | null, externalProviders?: readonly Record<string, any>[], admissionRegistry?: Record<string, any> | null, preferredProvider?: string | null, ownerRepository?: {claim: Function, get: Function, getTerminal?: Function, complete: Function} | null}} input
 * @returns {T}
 */
export const createJianyingWriterOwnerCapability = ({
  nativeCapability,
  nativeCapabilities = null,
  externalProviders = [],
  admissionRegistry = null,
  preferredProvider = null,
  ownerRepository = null,
}) => {
  if (!isCapability(nativeCapability) || !Array.isArray(externalProviders) ||
      externalProviders.some((provider) => !provider || typeof provider.routingCandidate !== 'function' || !isCapability(provider))) {
    throw new TypeError('JY200_WRITER_OWNER_CAPABILITY_INVALID')
  }
  const trustedNativeCapabilities = normalizeNativeCapabilities(nativeCapabilities)
  if (externalProviders.length > 0 && (!admissionRegistry || typeof admissionRegistry.describe !== 'function')) {
    throw new TypeError('JY200_ADMISSION_REGISTRY_REQUIRED')
  }
  if (externalProviders.length === 0) return nativeCapability
  if (!ownerRepository || typeof ownerRepository.claim !== 'function' ||
      typeof ownerRepository.get !== 'function' || typeof ownerRepository.complete !== 'function') {
    throw new TypeError('JY200_WRITER_OWNER_REPOSITORY_REQUIRED')
  }
  const providersById = new Map(externalProviders.map((provider) => [provider.id, provider]))
  providersById.set('native-writer', nativeCapability)

  /** @param {Record<string, any>} input @returns {Promise<{ownerId: string, writer: Record<string, any>, ownerRecord: Record<string, unknown>}>} */
  const chooseOwner = async (input) => {
    // Writer ownership is Jianying-target specific. A capability may be
    // degraded only because Preview cannot render it; the selected Jianying
    // owner must still cover every capability present in the canonical
    // timeline rather than inheriting Preview's conservative acceptance.
    const requiredCapabilities = Array.isArray(input?.richTimeline?.capabilityRequirements)
      ? [...new Set(input.richTimeline.capabilityRequirements
        .map((/** @type {Record<string, any>} */ entry) => entry?.capabilityId)
        .filter((/** @type {unknown} */ capabilityId) => typeof capabilityId === 'string'))]
      : []
    if (requiredCapabilities.length === 0) return { ownerId: 'native-writer', writer: nativeCapability, ownerRecord: { ownerId: 'native-writer' } }
    const packagingSelections = readTimelinePackagingSelections(input?.richTimeline)
    const selectedPackagingCapabilities = new Set(packagingSelections
      .map((/** @type {Record<string, any>} */ selection) => packagingCapabilityByFamily[/** @type {keyof typeof packagingCapabilityByFamily} */ (selection?.family)])
      .filter(Boolean))
    let nativeCoversExport = false
    if (typeof nativeCapability.canExportRichTimeline === 'function') {
      try {
        nativeCoversExport = await nativeCapability.canExportRichTimeline(input.richTimeline, input.projectId) === true
      } catch { nativeCoversExport = false }
    } else {
      const nativePackagingCovers = packagingSelections.length === 0 ||
        (typeof nativeCapability.canExportPackagingSelections === 'function' &&
          await nativeCapability.canExportPackagingSelections(input.richTimeline, input.projectId) === true)
      nativeCoversExport = trustedNativeCapabilities !== null && nativePackagingCovers &&
        requiredCapabilities.every((capabilityId) =>
          selectedPackagingCapabilities.has(capabilityId) || trustedNativeCapabilities.includes(capabilityId))
    }
    if (nativeCoversExport && preferredProvider === null) {
      return { ownerId: 'native-writer', writer: nativeCapability, ownerRecord: { ownerId: 'native-writer' } }
    }
    const providers = await Promise.all(externalProviders.map(async (provider) => {
      try {
        if (packagingSelections.length > 0 &&
            (typeof provider.canExportPackagingSelections !== 'function' ||
              await provider.canExportPackagingSelections(input.richTimeline) !== true)) return null
        return await provider.routingCandidate()
      } catch { return null }
    }))
    const current = providers.filter(Boolean)
    if (current.length === 0) {
      if (trustedNativeCapabilities !== null && !nativeCoversExport) throw new Error('JY200_NO_COMPLETE_WRITER_OWNER')
      return { ownerId: 'native-writer', writer: nativeCapability, ownerRecord: { ownerId: 'native-writer' } }
    }
    try {
      const selected = await selectJianyingWriterOwner({
        requiredCapabilities,
        providers: current,
        admissionRegistry,
        preferredProvider,
      })
      const ownerIdentity = selected.ownerIdentity
      if (!ownerIdentity || typeof selected.providerCommit !== 'string' ||
          typeof ownerIdentity.build_digest !== 'string' ||
          typeof ownerIdentity.adapter_revision !== 'string' ||
          typeof ownerIdentity.evidence_fingerprint !== 'string') {
        throw new Error('JY200_WRITER_OWNER_IDENTITY_INVALID')
      }
      return {
        ownerId: selected.ownerId,
        writer: /** @type {Record<string, any>} */ (selected.writer),
        ownerRecord: Object.freeze({
          ownerId: selected.ownerId,
          providerCommit: selected.providerCommit,
          buildDigest: ownerIdentity.build_digest,
          adapterRevision: ownerIdentity.adapter_revision,
          evidenceFingerprint: ownerIdentity.evidence_fingerprint,
        }),
      }
    } catch (error) {
      if (error && typeof error === 'object' && /** @type {{code?: string}} */ (error).code === 'JY200_NO_COMPLETE_WRITER_OWNER') {
        if (trustedNativeCapabilities !== null && !nativeCoversExport) throw error
        return { ownerId: 'native-writer', writer: nativeCapability, ownerRecord: { ownerId: 'native-writer' } }
      }
      throw error
    }
  }

  /** @param {Record<string, any>} input */
  const resolveClaimedOwner = async (input) => {
    const jobId = typeof input?.jobId === 'string' ? input.jobId : null
    if (!jobId) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
    const record = await ownerRepository.get(jobId)
    const ownerId = record && typeof record === 'object' ? record.ownerId : null
    const owner = typeof ownerId === 'string' ? providersById.get(ownerId) : null
    if (!owner) throw new Error('JY200_WRITER_OWNER_UNAVAILABLE')
    return { jobId, ownerId, owner }
  }

  return /** @type {T} */ (Object.freeze({
    // Preserve the existing server-private Native admission inputs used by the
    // coordinator and packaging recommendation path.
    ...nativeCapability,
    /** @param {Record<string, any>} input */
    async exportDraft(input) {
      const jobId = typeof input?.jobId === 'string' ? input.jobId : null
      if (!jobId) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
      const timelineFingerprint = input.richTimeline?.revisionFingerprint ?? input.timeline_fingerprint
      const existing = await ownerRepository.get(jobId)
      if (existing) {
        const owner = providersById.get(existing.ownerId)
        if (!owner) throw new Error('JY200_WRITER_OWNER_UNAVAILABLE')
        if (existing.timelineFingerprint !== timelineFingerprint || await ownerRepository.claim(existing) === false) {
          throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
        }
        return owner.exportDraft(input)
      }
      const selected = await chooseOwner(input)
      const claimed = await ownerRepository.claim(Object.freeze({
        jobId,
        requestId: jobId,
        timelineFingerprint,
        ...selected.ownerRecord,
      }))
      if (!claimed) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
      return selected.writer.exportDraft(input)
    },
    /** @param {Record<string, any>} input */
    async cleanupDraft(input) {
      const requestedJobId = typeof input?.jobId === 'string' ? input.jobId : null
      if (!requestedJobId) throw new Error('JY200_WRITER_OWNER_JOB_INVALID')
      const terminal = typeof ownerRepository.getTerminal === 'function'
        ? await ownerRepository.getTerminal(requestedJobId)
        : null
      if (terminal?.state === 'rolled_back') return true
      const { jobId, ownerId, owner } = await resolveClaimedOwner(input)
      const result = await owner.cleanupDraft(input)
      if (result !== true) throw new Error('JY200_WRITER_OWNER_CLEANUP_INCOMPLETE')
      if (await ownerRepository.complete(Object.freeze({ jobId, ownerId, action: 'cleanup' })) !== true) {
        throw new Error('JY200_WRITER_OWNER_COMPLETION_FAILED')
      }
      return result
    },
    /** @param {Record<string, any>} input */
    async commitDraft(input) {
      const { jobId, ownerId, owner } = await resolveClaimedOwner(input)
      const result = await owner.commitDraft(input)
      if (result !== true) throw new Error('JY200_WRITER_OWNER_COMMIT_INCOMPLETE')
      if (await ownerRepository.complete(Object.freeze({ jobId, ownerId, action: 'commit' })) !== true) {
        throw new Error('JY200_WRITER_OWNER_COMPLETION_FAILED')
      }
      return result
    },
  }))
}
