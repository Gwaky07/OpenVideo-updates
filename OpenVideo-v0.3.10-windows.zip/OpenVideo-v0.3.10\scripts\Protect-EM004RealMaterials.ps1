[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$MaterialRoot,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [Parameter(Mandatory)][ValidateSet('Before','After')][string]$Phase,
    [ValidateRange(1,100)][int]$SampleCount = 5
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false)

function Get-SafeRoot {
    param([string]$Path, [string]$Name, [bool]$MustExist)
    if (-not [IO.Path]::IsPathRooted($Path)) { throw "$Name must be absolute." }
    $fullPath = [IO.Path]::GetFullPath($Path).TrimEnd('\','/')
    if ($fullPath -eq [IO.Path]::GetPathRoot($fullPath).TrimEnd('\','/')) { throw "$Name cannot be a filesystem root." }
    if ($MustExist -and -not (Test-Path -LiteralPath $fullPath -PathType Container)) { throw "$Name must exist." }
    $cursor = $fullPath
    while ($cursor -and (Test-Path -LiteralPath $cursor)) {
        $item = Get-Item -LiteralPath $cursor -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "$Name crosses a reparse point." }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
    return $fullPath
}

function Test-ContainsPath {
    param([string]$Parent, [string]$Child)
    $comparison = if ($env:OS -eq 'Windows_NT') { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
    return $Child.Equals($Parent, $comparison) -or $Child.StartsWith($Parent + [IO.Path]::DirectorySeparatorChar, $comparison)
}

function Write-JsonAtomic {
    param([string]$Path, [object]$Value)
    $temporaryPath = "$Path.$([Guid]::NewGuid().ToString('N')).tmp"
    [IO.File]::WriteAllText($temporaryPath, (($Value | ConvertTo-Json -Depth 12) + [Environment]::NewLine), $utf8)
    Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
}

function Get-MaterialSnapshot {
    param([string]$Root, [int]$HashSampleCount, [string[]]$RequiredSamples = @())
    $files = @(Get-ChildItem -LiteralPath $Root -File -Force -Recurse | Sort-Object FullName)
    $records = @($files | ForEach-Object {
        if (($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Material tree contains a reparse point.' }
        [ordered]@{
            relative_name = $_.FullName.Substring($Root.Length).TrimStart('\','/').Replace('\','/')
            length = [int64]$_.Length
            last_write_time_utc = $_.LastWriteTimeUtc.ToString('O')
        }
    })
    $sampleNames = if ($RequiredSamples.Count -gt 0) { $RequiredSamples } else { @($records | Select-Object -First $HashSampleCount | ForEach-Object { $_.relative_name }) }
    $hashes = @($sampleNames | ForEach-Object {
        $sampleName = $_
        $record = $records | Where-Object { $_.relative_name -ceq $sampleName } | Select-Object -First 1
        if (-not $record) { throw 'A required hash sample is missing.' }
        $samplePath = Join-Path $Root $record.relative_name.Replace('/', [IO.Path]::DirectorySeparatorChar)
        [ordered]@{
            relative_name = $record.relative_name
            sha256 = (Get-FileHash -LiteralPath $samplePath -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    })
    [int64]$totalBytes = 0
    foreach ($record in $records) { $totalBytes += [int64]$record.length }
    return [ordered]@{
        schema_version = 1
        file_count = $records.Count
        total_bytes = $totalBytes
        files = $records
        samples = $hashes
    }
}

$materialPath = Get-SafeRoot -Path $MaterialRoot -Name 'MaterialRoot' -MustExist $true
$runtimePath = Get-SafeRoot -Path $RuntimeDataRoot -Name 'RuntimeDataRoot' -MustExist ($Phase -eq 'After')
if ((Test-ContainsPath $materialPath $runtimePath) -or (Test-ContainsPath $runtimePath $materialPath)) {
    throw 'MaterialRoot and RuntimeDataRoot must be separate.'
}
New-Item -ItemType Directory -Path $runtimePath -Force | Out-Null
$evidenceRoot = Join-Path $runtimePath 'evidence/em-004'
$privateRoot = Join-Path $evidenceRoot 'private'
New-Item -ItemType Directory -Path $privateRoot -Force | Out-Null
$beforePath = Join-Path $privateRoot 'source-snapshot.before.json'

if ($Phase -eq 'Before') {
    $snapshot = Get-MaterialSnapshot -Root $materialPath -HashSampleCount $SampleCount
    Write-JsonAtomic -Path $beforePath -Value $snapshot
    Write-JsonAtomic -Path (Join-Path $evidenceRoot 'source-preflight.json') -Value ([ordered]@{
        schema_version = 1
        phase = 'before'
        file_count = $snapshot.file_count
        total_bytes = $snapshot.total_bytes
        sample_count = $snapshot.samples.Count
    })
    Write-Host "EM-004 material preflight recorded: $($snapshot.file_count) files."
    return
}

if (-not (Test-Path -LiteralPath $beforePath -PathType Leaf)) { throw 'Before snapshot is required.' }
$before = Get-Content -LiteralPath $beforePath -Raw -Encoding UTF8 | ConvertFrom-Json
$requiredSamples = @($before.samples | ForEach-Object { [string]$_.relative_name })
$after = Get-MaterialSnapshot -Root $materialPath -HashSampleCount $SampleCount -RequiredSamples $requiredSamples
Write-JsonAtomic -Path (Join-Path $privateRoot 'source-snapshot.after.json') -Value $after
$metadataUnchanged = (($before.files | ConvertTo-Json -Depth 6 -Compress) -ceq ($after.files | ConvertTo-Json -Depth 6 -Compress))
$hashesUnchanged = (($before.samples | ConvertTo-Json -Depth 6 -Compress) -ceq ($after.samples | ConvertTo-Json -Depth 6 -Compress))
$unchanged = $metadataUnchanged -and $hashesUnchanged
Write-JsonAtomic -Path (Join-Path $evidenceRoot 'source-verification.json') -Value ([ordered]@{
    schema_version = 1
    phase = 'after'
    unchanged = $unchanged
    file_count = $after.file_count
    total_bytes = $after.total_bytes
    sample_count = $after.samples.Count
    metadata_unchanged = $metadataUnchanged
    sample_hashes_unchanged = $hashesUnchanged
})
if (-not $unchanged) { throw 'Material count, names, sizes, mtimes, or sample SHA256 changed.' }
Write-Host "EM-004 material verification passed: $($after.file_count) files unchanged."
