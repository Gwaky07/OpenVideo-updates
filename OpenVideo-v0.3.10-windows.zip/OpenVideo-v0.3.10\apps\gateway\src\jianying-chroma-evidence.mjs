const fingerprintPattern = /^[a-f0-9]{64}$/u
const draftPattern = /^OpenVideo-JY082-chroma-[0-9]+$/u
const evidenceKeys = Object.freeze(['schema_version', 'manual_evidence_verified', 'manual_attestation', 'profile_id', 'app_version', 'draft_id', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'persisted', 'pre_open_fingerprint', 'post_save_fingerprint', 'temporary_media_cleaned'])
const fail = () => { throw new Error('JY082_CHROMA_PERSISTENCE_INVALID') }

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Validate the exact single-purpose JY-082 chroma material and attachment.
 * @param {unknown} value
 */
export const validateJianyingChromaContent = (value) => {
  if (!isRecord(value)) fail()
  const content = /** @type {Record<string, any>} */ (value)
  if (!isRecord(content.materials) || !Array.isArray(content.tracks)) fail()
  const chromas = Array.isArray(content.materials.chromas) ? content.materials.chromas : []
  const videoSegments = content.tracks
    .filter((/** @type {unknown} */ track) => isRecord(track) && /** @type {Record<string, any>} */ (track).type === 'video')
    .flatMap((/** @type {Record<string, any>} */ track) => Array.isArray(track.segments) ? track.segments : [])
    .filter(isRecord)
  if (chromas.length !== 1 || videoSegments.length !== 1) fail()
  const chroma = chromas[0]
  const refs = Array.isArray(videoSegments[0].extra_material_refs) ? videoSegments[0].extra_material_refs : []
  if (
    !isRecord(chroma) || typeof chroma.id !== 'string' || !refs.includes(chroma.id) ||
    chroma.type !== 'chroma' || chroma.version !== 'v2' || chroma.should_transfer_color !== true ||
    typeof chroma.color !== 'string' || !/^#[0-9A-Fa-f]{8}$/u.test(chroma.color) ||
    typeof chroma.intensity_value !== 'number' || !Number.isFinite(chroma.intensity_value) || chroma.intensity_value < 0 || chroma.intensity_value > 1 ||
    !['shadow_value', 'edge_smooth_value', 'spill_value'].every((key) =>
      chroma[key] === undefined || (typeof chroma[key] === 'number' && Number.isFinite(chroma[key]) && chroma[key] >= 0 && chroma[key] <= 1))
  ) fail()
  const referenceCount = videoSegments.reduce((/** @type {number} */ count, /** @type {Record<string, any>} */ segment) =>
    count + (Array.isArray(segment.extra_material_refs) ? segment.extra_material_refs.filter((/** @type {unknown} */ reference) => reference === chroma.id).length : 0), 0)
  if (referenceCount !== 1) fail()
  return {
    color: chroma.color.toUpperCase(),
    intensity: chroma.intensity_value * 100,
    shadow: (chroma.shadow_value ?? 0) * 100,
    edgeSmooth: (chroma.edge_smooth_value ?? 0) * 100,
    spill: (chroma.spill_value ?? 0) * 100,
  }
}

/** @param {unknown} value @param {{profileId: string, version: string}} desktop */
export const parseJianyingChromaEvidence = (value, desktop) => {
  if (!isRecord(value)) return null
  const candidate = /** @type {Record<string, any>} */ (value)
  const persisted = candidate.persisted
  if (Object.keys(candidate).sort().join('\0') !== [...evidenceKeys].sort().join('\0') ||
    candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.manual_attestation !== 'opened-edited-saved-reopened' ||
    candidate.profile_id !== 'jianying-11-1-provisional' || candidate.app_version !== '11.1.0.14287' ||
    desktop.profileId !== 'jianying-11-1-provisional' || desktop.version !== '11.1.0.14287' ||
    !draftPattern.test(candidate.draft_id) || candidate.scheme !== 'encrypt_v2' ||
    candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true ||
    candidate.temporary_media_cleaned !== true || !isRecord(persisted) ||
    Object.keys(persisted).sort().join('\0') !== ['color', 'edgeSmooth', 'intensity', 'shadow', 'spill'].sort().join('\0') ||
    persisted.color !== '#00FF00FF' || persisted.intensity !== 30 || persisted.shadow !== 0 || persisted.edgeSmooth !== 0 || persisted.spill !== 0 ||
    !fingerprintPattern.test(candidate.pre_open_fingerprint) || !fingerprintPattern.test(candidate.post_save_fingerprint) ||
    candidate.pre_open_fingerprint === candidate.post_save_fingerprint) return null
  return Object.freeze({ ...candidate, persisted: Object.freeze({ ...persisted }) })
}

/**
 * Side-effect-free private evidence loader for production bootstrap.
 * @param {{dataRoot: string, desktop: {profileId: string, version: string}, readEvidence: (filePath: string) => Promise<string>, joinPath: (...parts: string[]) => string}} input
 */
export const loadJianyingChromaEvidenceCapability = async ({ dataRoot, desktop, readEvidence, joinPath }) => {
  try {
    const evidence = JSON.parse(await readEvidence(joinPath(dataRoot, 'evidence', 'jy082-chroma', 'post-save.json')))
    return Boolean(parseJianyingChromaEvidence(evidence, desktop))
  } catch {
    return false
  }
}
