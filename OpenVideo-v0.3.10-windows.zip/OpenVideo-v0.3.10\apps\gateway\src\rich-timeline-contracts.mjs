import { createHash } from 'node:crypto'
import { readTimelinePackagingSelections } from './jianying-timeline-packaging-selections.mjs'
import { assertPackagingTextLayout } from './packaging-text-layout.mjs'

const opaqueIdPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const orientations = new Set(['portrait', 'landscape', 'square'])
const statuses = new Set(['draft', 'finalized'])
const sourceKinds = new Set(['director', 'agent', 'editor', 'migration'])
const fitModes = new Set(['cover', 'contain'])
const audioRoles = new Set(['voiceover', 'bgm', 'sfx'])
const audioKinds = new Set(['voiceover', 'bgm', 'sfx'])
const textKinds = new Set(['caption', 'title', 'rich_text'])
const markerKinds = new Set(['beat', 'chapter', 'comment'])
const auditOrigins = new Set(['director', 'agent', 'editor', 'migration'])
const acceptanceValues = new Set(['implemented', 'degraded'])
const duckingValues = new Set(['none', 'under_voiceover'])
const keyframeCapabilities = new Set([
  'transform.scale',
  'transform.position',
  'transform.rotation',
  'opacity',
  'audio.volume.keyframe',
  'transform.text.keyframe',
  'transform.sticker.keyframe',
])
const keyframeInterpolations = new Set([
  'linear',
  'ease_in',
  'ease_out',
  'ease_in_out',
  'hold',
])
const captionCapabilities = new Set(['caption.basic', 'caption.bottom_safe'])
const titleCapabilities = new Set(['title.card'])
const richTextCapabilities = new Set(['text.rich', 'text.flower.private', 'text.bubble.private'])
const builtinTransitions = new Set(['transition.cut', 'transition.none'])

const timelineKeys = [
  'schemaVersion',
  'timelineId',
  'projectId',
  'revision',
  'parentRevision',
  'parentRevisionFingerprint',
  'status',
  'createdAt',
  'durationUs',
  'orientation',
  'fps',
  'source',
  'tracks',
  'markers',
  'capabilityRequirements',
  'contentFingerprint',
  'revisionFingerprint',
]
const sourceKeys = [
  'kind',
  'editPlanFingerprint',
  'templateFingerprint',
  'instructionFingerprint',
]
const sourceKeysWithTemplateIdentity = [...sourceKeys, 'templateIdentity']
const sourceKeysWithAutomaticPackagingLegacy = [...sourceKeys, 'automaticPackaging']
const sourceKeysWithAutomaticPackagingLegacyCoverage = [
  ...sourceKeysWithAutomaticPackagingLegacy,
  'templatePackagingCoverage',
]
const sourceKeysWithAutomaticPackaging = [...sourceKeys, 'automaticPackaging', 'packagingCatalogFingerprint']
const sourceKeysWithAutomaticPackagingCoverage = [...sourceKeysWithAutomaticPackaging, 'templatePackagingCoverage']
const sourceKeysWithAutomaticPackagingSelections = [...sourceKeysWithAutomaticPackaging, 'packagingSelections']
const sourceKeysWithAutomaticPackagingSelectionsCoverage = [...sourceKeysWithAutomaticPackagingSelections, 'templatePackagingCoverage']
const sourceKeysWithTemplateIdentityAndAutomaticPackaging = [
  ...sourceKeys,
  'templateIdentity',
  'automaticPackaging',
  'packagingCatalogFingerprint',
]
const sourceKeysWithTemplateIdentityAndAutomaticPackagingLegacyCoverage = [
  ...sourceKeys,
  'templateIdentity',
  'automaticPackaging',
  'templatePackagingCoverage',
]
const sourceKeysWithTemplateIdentityAndAutomaticPackagingCoverage = [
  ...sourceKeysWithTemplateIdentityAndAutomaticPackaging,
  'templatePackagingCoverage',
]
const sourceKeysWithTemplateIdentityAndAutomaticPackagingSelections = [
  ...sourceKeysWithTemplateIdentityAndAutomaticPackaging,
  'packagingSelections',
]
const sourceKeysWithTemplateIdentityAndAutomaticPackagingSelectionsCoverage = [
  ...sourceKeysWithTemplateIdentityAndAutomaticPackagingSelections,
  'templatePackagingCoverage',
]
const packagingSelectionKeys = ['packagingToken', 'family', 'label', 'targetSegmentId']
const templateIdentityKeys = ['libraryTemplateId', 'revision', 'fingerprint']
const fpsKeys = ['numerator', 'denominator']
const timeRangeKeys = ['startUs', 'durationUs']
const speedKeys = ['numerator', 'denominator']
const assetKeys = ['authorizationId', 'assetId', 'sceneId']
const auditKeys = ['origin', 'candidateId', 'instructionFingerprint']
const capabilityRequirementKeys = ['capabilityId', 'acceptance', 'degradationCode']
const markerKeys = ['markerId', 'offsetUs', 'kind', 'label']
const transitionKeys = ['capabilityId', 'durationUs', 'parameters']
const effectBindingKeys = ['capabilityId', 'offsetRange', 'intensity', 'parameters']
const keyframeKeys = ['capabilityId', 'offsetUs', 'value', 'interpolation']
const primaryVideoSegmentKeys = [
  'segmentId',
  'kind',
  'asset',
  'sourceRange',
  'targetRange',
  'fit',
  'volume',
  'speed',
  'keyframes',
  'effects',
  'audit',
  'transitionOut',
]
const overlayVideoSegmentKeys = [
  'segmentId',
  'kind',
  'asset',
  'sourceRange',
  'targetRange',
  'fit',
  'volume',
  'speed',
  'keyframes',
  'effects',
  'audit',
]
const audioSegmentKeys = [
  'segmentId',
  'kind',
  'capabilityId',
  'source',
  'sourceRange',
  'targetRange',
  'volume',
  'fadeInUs',
  'fadeOutUs',
  'keyframes',
  'ducking',
]
const textSegmentKeys = [
  'segmentId',
  'kind',
  'capabilityId',
  'targetRange',
  'text',
  'styleToken',
  'keyframes',
  'animationIn',
  'animationOut',
  'templateToken',
  'templateSlotId',
  'layout',
]
const textSegmentKeysWithoutSlotId = textSegmentKeys.filter((key) => key !== 'templateSlotId')
const textSegmentKeysWithoutLayout = textSegmentKeys.filter((key) => key !== 'layout')
const textSegmentKeysWithoutLayoutOrSlotId = textSegmentKeysWithoutLayout.filter((key) => key !== 'templateSlotId')
const legacyTextSegmentKeys = textSegmentKeysWithoutLayoutOrSlotId.filter((key) => key !== 'keyframes')
const legacyTextSegmentKeysWithSlotId = textSegmentKeysWithoutLayout.filter((key) => key !== 'keyframes')
const layoutTextSegmentKeysWithoutKeyframes = textSegmentKeysWithoutSlotId.filter((key) => key !== 'keyframes')
const layoutTextSegmentKeysWithSlotIdWithoutKeyframes = textSegmentKeys.filter((key) => key !== 'keyframes')
const effectSegmentKeys = [
  'segmentId',
  'kind',
  'targetRange',
  'capabilityId',
  'intensity',
  'parameters',
  'keyframes',
]
const legacyEffectSegmentKeys = effectSegmentKeys.filter((key) => key !== 'keyframes')
const videoTrackBaseKeys = [
  'trackId',
  'order',
  'enabled',
  'locked',
  'kind',
  'role',
  'segments',
]
const audioTrackKeys = [
  'trackId',
  'order',
  'enabled',
  'locked',
  'kind',
  'role',
  'segments',
]
const captionTrackKeys = ['trackId', 'order', 'enabled', 'locked', 'kind', 'segments']
const titleTrackKeys = ['trackId', 'order', 'enabled', 'locked', 'kind', 'segments']
const effectTrackKeys = ['trackId', 'order', 'enabled', 'locked', 'kind', 'segments']
const publicSummaryKeys = [
  'timelineId',
  'revision',
  'contentFingerprint',
  'revisionFingerprint',
  'status',
  'durationUs',
  'createdAt',
  'sourceKind',
  'shotCount',
  'shots',
]
const publicSummaryKeysWithPackaging = [...publicSummaryKeys, 'packaging']

/**
 * @typedef {{
 *   packagingToken: string,
 *   family: string,
 *   label: string,
 *   targetSegmentId: string,
 * }} PackagingSelection
 */

const MAX_PUBLIC_SHOTS = 120

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value @returns {value is any[]} */
const isDenseArray = (value) =>
  Array.isArray(value) &&
  Object.keys(value).length === value.length &&
  Object.keys(value).every((key, index) => key === String(index))

/** @param {Record<string, unknown>} value @param {string[]} expected */
const hasExactKeys = (value, expected) =>
  Object.keys(value).length === expected.length &&
  expected.every((key) => Object.hasOwn(value, key)) &&
  Object.keys(value).every((key) => expected.includes(key))

export class RichTimelineContractError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'RichTimelineContractError'
    this.code = code
  }
}

/** @param {string} code @returns {never} */
const fail = (code) => {
  throw new RichTimelineContractError(code)
}

/** @param {any} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value)
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) fail('non_json_canonical_value')
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) {
    if (!isDenseArray(value)) fail('non_json_canonical_value')
    return `[${value.map(stableStringify).join(',')}]`
  }
  if (isRecord(value)) {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(',')}}`
  }
  fail('non_json_canonical_value')
}

/** @param {unknown} value */
const sha256Hex = (value) => createHash('sha256').update(stableStringify(value)).digest('hex')

/** @param {unknown} value */
export const isOpaqueTimelineId = (value) =>
  typeof value === 'string' &&
  opaqueIdPattern.test(value) &&
  !value.includes('/') &&
  !value.includes('\\') &&
  !value.includes(':')

/** @param {unknown} value @param {string} [code] */
export const assertOpaqueTimelineId = (value, code = 'invalid_opaque_id') => {
  if (!isOpaqueTimelineId(value)) fail(code)
  return /** @type {string} */ (value)
}

/** @param {unknown} seconds */
export const secondsToMicroseconds = (seconds) => {
  if (typeof seconds !== 'number' || !Number.isFinite(seconds)) {
    fail('invalid_seconds')
  }
  const value = Math.round(seconds * 1e6)
  if (!Number.isSafeInteger(value) || value < 0) fail('invalid_microseconds')
  return value
}

/** @param {unknown} value */
const isNonNegativeSafeInteger = (value) =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0

/** @param {unknown} value */
const isPositiveSafeInteger = (value) =>
  typeof value === 'number' && Number.isSafeInteger(value) && value > 0

/** @param {unknown} value */
const isUnitInterval = (value) =>
  typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1

/** @param {unknown} value */
const isTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))

/** @param {unknown} value */
const isFingerprint = (value) => typeof value === 'string' && fingerprintPattern.test(value)

/** @param {unknown} value */
const isNullableFingerprint = (value) => value === null || isFingerprint(value)

/** @param {unknown} value @returns {value is {startUs: number, durationUs: number}} */
const isTimeRange = (value, { allowZeroDuration = false } = {}) => {
  if (!isRecord(value) || !hasExactKeys(value, timeRangeKeys)) return false
  if (!isNonNegativeSafeInteger(value.startUs)) return false
  if (allowZeroDuration) {
    if (!isNonNegativeSafeInteger(value.durationUs)) return false
  } else if (!isPositiveSafeInteger(value.durationUs)) {
    return false
  }
  return Number.isSafeInteger(value.startUs + value.durationUs)
}

/** @param {unknown} value */
const isSpeed = (value) =>
  isRecord(value) &&
  hasExactKeys(value, speedKeys) &&
  isPositiveSafeInteger(value.numerator) &&
  isPositiveSafeInteger(value.denominator)

/** @param {unknown} value */
const isFps = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, fpsKeys)) return false
  if (!isPositiveSafeInteger(value.numerator) || !isPositiveSafeInteger(value.denominator)) {
    return false
  }
  const fps = value.numerator / value.denominator
  return fps >= 1 && fps <= 240
}

/** @param {unknown} value */
const isParameters = (value) => {
  if (!isRecord(value)) return false
  return Object.entries(value).every(
    ([key, entry]) =>
      typeof key === 'string' &&
      key.length > 0 &&
      key.length <= 200 &&
      (typeof entry === 'string' || typeof entry === 'boolean' ||
        (typeof entry === 'number' && Number.isFinite(entry))),
  )
}

/** @param {unknown} value */
const isEmptyParameters = (value) => isRecord(value) && Object.keys(value).length === 0

/** @param {unknown} value */
const isAssetReference = (value, { requireScene = false } = {}) => {
  if (!isRecord(value) || !hasExactKeys(value, assetKeys)) return false
  if (!isOpaqueTimelineId(value.authorizationId) || !isOpaqueTimelineId(value.assetId)) {
    return false
  }
  if (requireScene) return isOpaqueTimelineId(value.sceneId)
  return value.sceneId === null || isOpaqueTimelineId(value.sceneId)
}

/** @param {unknown} value */
const isAudit = (value) =>
  isRecord(value) &&
  hasExactKeys(value, auditKeys) &&
  typeof value.origin === 'string' &&
  auditOrigins.has(value.origin) &&
  (value.candidateId === null || isOpaqueTimelineId(value.candidateId)) &&
  isNullableFingerprint(value.instructionFingerprint)

/** @param {unknown} value */
const isTransitionSpec = (value) => {
  if (!isRecord(value) || !hasExactKeys(value, transitionKeys)) return false
  if (typeof value.capabilityId !== 'string' || value.capabilityId.length === 0) return false
  if (!isNonNegativeSafeInteger(value.durationUs)) return false
  if (builtinTransitions.has(value.capabilityId)) {
    return value.durationUs === 0 && isEmptyParameters(value.parameters)
  }
  return isPositiveSafeInteger(value.durationUs) && isParameters(value.parameters)
}

/** @param {string} capabilityId @param {unknown} value */
const isKeyframeValue = (capabilityId, value) => {
  if (capabilityId === 'transform.position') {
    return (
      isRecord(value) &&
      hasExactKeys(value, ['x', 'y']) &&
      typeof value.x === 'number' &&
      Number.isFinite(value.x) &&
      value.x >= -1 &&
      value.x <= 1 &&
      typeof value.y === 'number' &&
      Number.isFinite(value.y) &&
      value.y >= -1 &&
      value.y <= 1
    )
  }
  if (typeof value !== 'number' || !Number.isFinite(value)) return false
  if (capabilityId === 'transform.scale') return value >= 0.01 && value <= 20
  if (capabilityId === 'transform.rotation') return value >= -3600 && value <= 3600
  if (capabilityId === 'opacity') return value >= 0 && value <= 1
  if (capabilityId === 'audio.volume.keyframe') return value >= 0 && value <= 1
  if (capabilityId === 'transform.text.keyframe') return value >= 0.1 && value <= 10
  if (capabilityId === 'transform.sticker.keyframe') return value >= 0.1 && value <= 10
  return false
}

/** @param {unknown} value @param {number} segmentDurationUs */
const isKeyframe = (value, segmentDurationUs) => {
  if (!isRecord(value) || !hasExactKeys(value, keyframeKeys)) return false
  if (typeof value.capabilityId !== 'string' || !keyframeCapabilities.has(value.capabilityId)) {
    return false
  }
  if (!isNonNegativeSafeInteger(value.offsetUs) || value.offsetUs > segmentDurationUs) {
    return false
  }
  if (typeof value.interpolation !== 'string' || !keyframeInterpolations.has(value.interpolation)) {
    return false
  }
  return isKeyframeValue(value.capabilityId, value.value)
}

/** @param {unknown} value @param {number} segmentDurationUs */
const isEffectBinding = (value, segmentDurationUs) => {
  if (!isRecord(value) || !hasExactKeys(value, effectBindingKeys)) return false
  if (typeof value.capabilityId !== 'string' || value.capabilityId.length === 0) return false
  if (!isUnitInterval(value.intensity) || !isParameters(value.parameters)) return false
  if (!isTimeRange(value.offsetRange)) return false
  const end = value.offsetRange.startUs + value.offsetRange.durationUs
  return end <= segmentDurationUs
}

/** @param {unknown} value */
const isAudioSource = (value) => {
  if (!isRecord(value) || typeof value.kind !== 'string') return false
  if (value.kind === 'asset') {
    return hasExactKeys(value, ['kind', 'reference']) && isAssetReference(value.reference)
  }
  if (value.kind === 'generated') {
    return (
      hasExactKeys(value, ['kind', 'generatedAudioId']) &&
      isOpaqueTimelineId(value.generatedAudioId)
    )
  }
  return false
}

/** @param {string} kind @param {string} capabilityId */
const audioCapabilityMatchesKind = (kind, capabilityId) => {
  if (kind === 'voiceover') return capabilityId.startsWith('audio.voiceover.')
  if (kind === 'bgm') return capabilityId.startsWith('audio.bgm.')
  if (kind === 'sfx') return capabilityId.startsWith('audio.sfx.')
  return false
}

/** @param {string} kind @param {string} capabilityId */
const textCapabilityMatchesKind = (kind, capabilityId) => {
  if (kind === 'caption') return captionCapabilities.has(capabilityId)
  if (kind === 'title') return titleCapabilities.has(capabilityId)
  if (kind === 'rich_text') return richTextCapabilities.has(capabilityId)
  return false
}

/**
 * @param {unknown} segment
 * @param {'primary' | 'overlay'} role
 */
const assertVideoSegment = (segment, role) => {
  const expectedKeys = role === 'primary' ? primaryVideoSegmentKeys : overlayVideoSegmentKeys
  if (!isRecord(segment) || !hasExactKeys(segment, expectedKeys)) {
    fail(role === 'primary' ? 'invalid_primary_video_segment' : 'invalid_overlay_video_segment')
  }
  assertOpaqueTimelineId(segment.segmentId, 'invalid_segment_id')
  if (segment.kind !== 'video') fail('invalid_video_segment_kind')
  if (!isAssetReference(segment.asset, { requireScene: true })) fail('invalid_video_asset')
  if (!isTimeRange(segment.sourceRange) || !isTimeRange(segment.targetRange)) {
    fail('invalid_video_range')
  }
  if (typeof segment.fit !== 'string' || !fitModes.has(segment.fit)) fail('invalid_fit')
  if (!isUnitInterval(segment.volume)) fail('invalid_volume')
  if (!isSpeed(segment.speed)) fail('invalid_speed')
  const expectedTarget =
    (segment.sourceRange.durationUs * segment.speed.denominator) / segment.speed.numerator
  if (
    !Number.isInteger(expectedTarget) ||
    expectedTarget !== segment.targetRange.durationUs
  ) {
    fail('invalid_speed_target_duration')
  }
  if (!isDenseArray(segment.keyframes) || !isDenseArray(segment.effects)) {
    fail('invalid_video_segment_collections')
  }
  for (const keyframe of segment.keyframes) {
    if (!isKeyframe(keyframe, segment.targetRange.durationUs)) fail('invalid_keyframe')
  }
  const offsetsByCapability = new Map()
  for (const keyframe of segment.keyframes) {
    const previous = offsetsByCapability.get(keyframe.capabilityId) ?? -1
    if (!(keyframe.offsetUs > previous)) fail('invalid_keyframe_order')
    offsetsByCapability.set(keyframe.capabilityId, keyframe.offsetUs)
  }
  for (const effect of segment.effects) {
    if (!isEffectBinding(effect, segment.targetRange.durationUs)) fail('invalid_effect_binding')
  }
  if (!isAudit(segment.audit)) fail('invalid_segment_audit')
  if (role === 'primary') {
    if (!isTransitionSpec(segment.transitionOut)) fail('invalid_transition_out')
  }
  return segment
}

/** @param {unknown} segment @param {string} role */
const assertAudioSegment = (segment, role) => {
  if (!isRecord(segment) || !hasExactKeys(segment, audioSegmentKeys)) fail('invalid_audio_segment')
  assertOpaqueTimelineId(segment.segmentId, 'invalid_segment_id')
  if (typeof segment.kind !== 'string' || !audioKinds.has(segment.kind)) fail('invalid_audio_kind')
  if (segment.kind !== role) fail('audio_kind_role_mismatch')
  if (typeof segment.capabilityId !== 'string' || segment.capabilityId.length === 0) {
    fail('invalid_audio_capability')
  }
  if (!audioCapabilityMatchesKind(segment.kind, segment.capabilityId)) {
    fail('audio_capability_kind_mismatch')
  }
  if (!isAudioSource(segment.source)) fail('invalid_audio_source')
  if (!isTimeRange(segment.sourceRange) || !isTimeRange(segment.targetRange)) {
    fail('invalid_audio_range')
  }
  if (segment.source.kind === 'generated' && segment.sourceRange.startUs !== 0) {
    fail('invalid_generated_audio_source_range')
  }
  if (!isUnitInterval(segment.volume)) fail('invalid_volume')
  if (!isNonNegativeSafeInteger(segment.fadeInUs) || !isNonNegativeSafeInteger(segment.fadeOutUs)) {
    fail('invalid_fade')
  }
  if (segment.fadeInUs > segment.targetRange.durationUs || segment.fadeOutUs > segment.targetRange.durationUs) {
    fail('invalid_fade')
  }
  if (typeof segment.ducking !== 'string' || !duckingValues.has(segment.ducking)) {
    fail('invalid_ducking')
  }
  if (!isDenseArray(segment.keyframes)) fail('invalid_audio_segment_collections')
  let previousOffset = -1
  for (const keyframe of segment.keyframes) {
    if (!isKeyframe(keyframe, segment.targetRange.durationUs) || keyframe.capabilityId !== 'audio.volume.keyframe' || keyframe.offsetUs <= previousOffset) {
      fail('invalid_audio_keyframe')
    }
    previousOffset = keyframe.offsetUs
  }
  return segment
}

/** @param {unknown} segment @param {'caption' | 'title'} trackKind */
const assertTextSegment = (segment, trackKind) => {
  if (
    !isRecord(segment) ||
    !(
      hasExactKeys(segment, textSegmentKeys) ||
      hasExactKeys(segment, textSegmentKeysWithoutSlotId) ||
      hasExactKeys(segment, textSegmentKeysWithoutLayout) ||
      hasExactKeys(segment, textSegmentKeysWithoutLayoutOrSlotId) ||
      hasExactKeys(segment, legacyTextSegmentKeysWithSlotId) ||
      hasExactKeys(segment, legacyTextSegmentKeys) ||
      hasExactKeys(segment, layoutTextSegmentKeysWithSlotIdWithoutKeyframes) ||
      hasExactKeys(segment, layoutTextSegmentKeysWithoutKeyframes)
    )
  ) fail('invalid_text_segment')
  assertOpaqueTimelineId(segment.segmentId, 'invalid_segment_id')
  if (typeof segment.kind !== 'string' || !textKinds.has(segment.kind)) fail('invalid_text_kind')
  if (trackKind === 'caption' && segment.kind !== 'caption') fail('caption_kind_mismatch')
  if (trackKind === 'title' && segment.kind !== 'title' && segment.kind !== 'rich_text') {
    fail('title_kind_mismatch')
  }
  if (typeof segment.capabilityId !== 'string' || !textCapabilityMatchesKind(segment.kind, segment.capabilityId)) {
    fail('text_capability_kind_mismatch')
  }
  if (!isTimeRange(segment.targetRange)) fail('invalid_text_range')
  if (typeof segment.text !== 'string' || segment.text.length === 0 || segment.text.length > 20_000) {
    fail('invalid_text')
  }
  if (!isOpaqueTimelineId(segment.styleToken)) fail('invalid_style_token')
  if (segment.layout !== undefined) {
    try {
      assertPackagingTextLayout(segment.layout)
    } catch {
      fail('invalid_text_layout')
    }
  }
  const keyframes = segment.keyframes === undefined ? [] : segment.keyframes
  if (!isDenseArray(keyframes)) fail('invalid_text_keyframe_collection')
  if (segment.kind !== 'title' && keyframes.length > 0) fail('text_keyframes_require_title')
  let previousKeyframeOffset = -1
  for (const keyframe of keyframes) {
    if (
      !isKeyframe(keyframe, segment.targetRange.durationUs) ||
      keyframe.capabilityId !== 'transform.text.keyframe' ||
      typeof keyframe.value !== 'number' ||
      !Number.isFinite(keyframe.value) ||
      keyframe.value < 0.1 ||
      keyframe.value > 10 ||
      keyframe.interpolation !== 'linear' ||
      keyframe.offsetUs <= previousKeyframeOffset
    ) fail('invalid_text_keyframe')
    previousKeyframeOffset = keyframe.offsetUs
  }
  if (!(segment.animationIn === null || isOpaqueTimelineId(segment.animationIn))) {
    fail('invalid_animation_in')
  }
  if (!(segment.animationOut === null || isOpaqueTimelineId(segment.animationOut))) {
    fail('invalid_animation_out')
  }
  if (!(segment.templateToken === null || isOpaqueTimelineId(segment.templateToken))) {
    fail('invalid_template_token')
  }
  if (segment.templateSlotId !== undefined && !isOpaqueTimelineId(segment.templateSlotId)) {
    fail('invalid_template_slot_id')
  }
  if (['text.flower.private', 'text.bubble.private'].includes(segment.capabilityId) && segment.templateToken === null) {
    fail('private_text_template_token_required')
  }
  return segment
}

/** @param {unknown} segment */
const assertEffectSegment = (segment) => {
  if (!isRecord(segment) || !(hasExactKeys(segment, effectSegmentKeys) || hasExactKeys(segment, legacyEffectSegmentKeys))) fail('invalid_effect_segment')
  assertOpaqueTimelineId(segment.segmentId, 'invalid_segment_id')
  if (segment.kind !== 'effect') fail('invalid_effect_kind')
  if (!isTimeRange(segment.targetRange)) fail('invalid_effect_range')
  if (typeof segment.capabilityId !== 'string' || segment.capabilityId.length === 0) {
    fail('invalid_effect_capability')
  }
  if (!isUnitInterval(segment.intensity) || !isParameters(segment.parameters)) {
    fail('invalid_effect_parameters')
  }
  const keyframes = segment.keyframes ?? []
  if (!isDenseArray(keyframes)) fail('invalid_effect_keyframes')
  if (segment.capabilityId !== 'sticker.named' && keyframes.length > 0) {
    fail('effect_keyframes_not_supported')
  }
  let previousOffset = -1
  for (const keyframe of keyframes) {
    if (
      !isKeyframe(keyframe, segment.targetRange.durationUs) ||
      keyframe.capabilityId !== 'transform.sticker.keyframe' ||
      keyframe.interpolation !== 'linear' ||
      keyframe.offsetUs <= previousOffset
    ) {
      fail('invalid_sticker_keyframe')
    }
    previousOffset = keyframe.offsetUs
  }
  return segment
}

/** @param {unknown} track */
const assertTrack = (track) => {
  if (!isRecord(track) || typeof track.kind !== 'string') fail('invalid_track')
  assertOpaqueTimelineId(track.trackId, 'invalid_track_id')
  if (!isNonNegativeSafeInteger(track.order)) fail('invalid_track_order')
  if (typeof track.enabled !== 'boolean' || typeof track.locked !== 'boolean') {
    fail('invalid_track_flags')
  }
  if (!isDenseArray(track.segments)) fail('invalid_track_segments')

  if (track.kind === 'video') {
    if (!hasExactKeys(track, videoTrackBaseKeys)) fail('invalid_video_track')
    if (track.role !== 'primary' && track.role !== 'overlay') fail('invalid_video_role')
    for (const segment of track.segments) {
      assertVideoSegment(segment, track.role)
    }
    return track
  }
  if (track.kind === 'audio') {
    if (!hasExactKeys(track, audioTrackKeys)) fail('invalid_audio_track')
    if (typeof track.role !== 'string' || !audioRoles.has(track.role)) fail('invalid_audio_role')
    for (const segment of track.segments) assertAudioSegment(segment, track.role)
    return track
  }
  if (track.kind === 'caption') {
    if (!hasExactKeys(track, captionTrackKeys)) fail('invalid_caption_track')
    for (const segment of track.segments) assertTextSegment(segment, 'caption')
    return track
  }
  if (track.kind === 'title') {
    if (!hasExactKeys(track, titleTrackKeys)) fail('invalid_title_track')
    for (const segment of track.segments) assertTextSegment(segment, 'title')
    return track
  }
  if (track.kind === 'effect') {
    if (!hasExactKeys(track, effectTrackKeys)) fail('invalid_effect_track')
    for (const segment of track.segments) assertEffectSegment(segment)
    return track
  }
  fail('invalid_track_kind')
}

/** @param {unknown} marker */
const assertMarker = (marker) => {
  if (!isRecord(marker) || !hasExactKeys(marker, markerKeys)) fail('invalid_marker')
  assertOpaqueTimelineId(marker.markerId, 'invalid_marker_id')
  if (!isNonNegativeSafeInteger(marker.offsetUs)) fail('invalid_marker_offset')
  if (typeof marker.kind !== 'string' || !markerKinds.has(marker.kind)) fail('invalid_marker_kind')
  if (typeof marker.label !== 'string' || marker.label.length === 0 || marker.label.length > 500) {
    fail('invalid_marker_label')
  }
  return marker
}

/** @param {unknown} requirement */
const assertCapabilityRequirement = (requirement) => {
  if (!isRecord(requirement) || !hasExactKeys(requirement, capabilityRequirementKeys)) {
    fail('invalid_capability_requirement')
  }
  if (typeof requirement.capabilityId !== 'string' || requirement.capabilityId.length === 0) {
    fail('invalid_capability_id')
  }
  if (typeof requirement.acceptance !== 'string' || !acceptanceValues.has(requirement.acceptance)) {
    fail('invalid_capability_acceptance')
  }
  if (!(requirement.degradationCode === null || typeof requirement.degradationCode === 'string')) {
    fail('invalid_degradation_code')
  }
  if (requirement.acceptance === 'degraded' && requirement.degradationCode === null) {
    fail('missing_degradation_code')
  }
  if (requirement.acceptance === 'implemented' && requirement.degradationCode !== null) {
    fail('unexpected_degradation_code')
  }
  return requirement
}

/** @param {unknown} segment */
const projectSegmentForContent = (segment) => {
  if (!isRecord(segment)) fail('invalid_segment_projection')
  /** @type {Record<string, any>} */
  const projected = {}
  for (const key of Object.keys(segment).sort()) {
    if (key === 'segmentId' || key === 'audit') continue
    projected[key] = segment[key]
  }
  return projected
}

/** @param {unknown} track */
const projectTrackForContent = (track) => {
  if (!isRecord(track)) fail('invalid_track_projection')
  /** @type {Record<string, unknown>} */
  const projected = {
    kind: track.kind,
    order: track.order,
    enabled: track.enabled,
    segments: /** @type {unknown[]} */ (track.segments).map(projectSegmentForContent),
  }
  if (Object.hasOwn(track, 'role')) projected.role = track.role
  return projected
}

/** @param {unknown} marker */
const projectMarkerForContent = (marker) => {
  if (!isRecord(marker)) fail('invalid_marker_projection')
  return {
    offsetUs: marker.offsetUs,
    kind: marker.kind,
    label: marker.label,
  }
}

/** @param {Record<string, unknown>} timeline */
const projectContent = (timeline) => ({
  schemaVersion: timeline.schemaVersion,
  durationUs: timeline.durationUs,
  orientation: timeline.orientation,
  fps: timeline.fps,
  tracks: /** @type {unknown[]} */ (timeline.tracks).map(projectTrackForContent),
  markers: /** @type {unknown[]} */ (timeline.markers).map(projectMarkerForContent),
  capabilityRequirements: timeline.capabilityRequirements,
})

/**
 * @param {unknown} tracks
 * @returns {{capabilityId: string, acceptance: 'implemented', degradationCode: null}[]}
 */
export const computeCapabilityRequirements = (tracks) => {
  if (!isDenseArray(tracks)) fail('invalid_tracks')
  const ids = new Set()
  const insertedTrackCount = tracks.filter((track) =>
    isRecord(track) && track.kind !== 'video' && isDenseArray(track.segments) && track.segments.length > 0,
  ).length
  if (insertedTrackCount === 1) ids.add('track.insert')
  if (insertedTrackCount > 1) ids.add('track.insert_many')
  for (const track of tracks) {
    if (!isRecord(track) || !isDenseArray(track.segments)) fail('invalid_tracks')
    if (track.kind === 'video') {
      for (const segment of track.segments) {
        if (!isRecord(segment)) fail('invalid_tracks')
        if (
          isRecord(segment.speed) &&
          !(segment.speed.numerator === 1 && segment.speed.denominator === 1)
        ) {
          ids.add('speed.constant')
        }
        if (track.role === 'primary' && isRecord(segment.transitionOut)) {
          ids.add(segment.transitionOut.capabilityId)
        }
        if (isDenseArray(segment.effects)) {
          for (const effect of segment.effects) {
            if (isRecord(effect)) ids.add(effect.capabilityId)
          }
        }
        if (isDenseArray(segment.keyframes)) {
          for (const keyframe of segment.keyframes) {
            if (isRecord(keyframe)) ids.add(keyframe.capabilityId)
          }
        }
      }
      continue
    }
    for (const segment of track.segments) {
      if (!isRecord(segment)) fail('invalid_tracks')
      if (typeof segment.capabilityId === 'string') ids.add(segment.capabilityId)
      if (track.kind === 'effect' && isDenseArray(segment.keyframes)) {
        for (const keyframe of segment.keyframes) {
          if (isRecord(keyframe)) ids.add(keyframe.capabilityId)
        }
      }
      if (
        track.kind === 'title' &&
        (typeof segment.animationIn === 'string' || typeof segment.animationOut === 'string')
      ) {
        ids.add('animation.text.named')
      }
      if (track.kind === 'audio' && isDenseArray(segment.keyframes)) {
        for (const keyframe of segment.keyframes) {
          if (isRecord(keyframe)) ids.add(keyframe.capabilityId)
        }
      }
      if (
        track.kind === 'audio' &&
        ((Number.isSafeInteger(segment.fadeInUs) && segment.fadeInUs > 0) ||
          (Number.isSafeInteger(segment.fadeOutUs) && segment.fadeOutUs > 0))
      ) {
        ids.add('audio.fade')
      }
    }
  }
  return [...ids]
    .sort((left, right) => left.localeCompare(right))
    .map((capabilityId) => ({
      capabilityId,
      acceptance: /** @type {const} */ ('implemented'),
      degradationCode: null,
    }))
}

/** @param {Record<string, unknown>} timelineWithoutFingerprintsOrIdentity */
export const contentFingerprint = (timelineWithoutFingerprintsOrIdentity) => {
  if (!isRecord(timelineWithoutFingerprintsOrIdentity)) fail('invalid_content_projection')
  return sha256Hex(projectContent(timelineWithoutFingerprintsOrIdentity))
}

/** @param {Record<string, unknown>} timelineWithoutRevisionFingerprint */
export const revisionFingerprint = (timelineWithoutRevisionFingerprint) => {
  if (!isRecord(timelineWithoutRevisionFingerprint)) fail('invalid_revision_projection')
  if (Object.hasOwn(timelineWithoutRevisionFingerprint, 'revisionFingerprint')) {
    fail('revision_fingerprint_must_be_omitted')
  }
  return sha256Hex(timelineWithoutRevisionFingerprint)
}

/**
 * @param {unknown} value
 * @param {{sceneBoundsByKey?: Map<string, {startUs: number, durationUs: number}> | Record<string, {startUs: number, durationUs: number}>}} [options]
 */
export const assertRichTimeline = (value, options = {}) => {
  if (!isRecord(value) || !hasExactKeys(value, timelineKeys)) fail('invalid_timeline_keys')
  if (value.schemaVersion !== 1) fail('invalid_schema_version')
  assertOpaqueTimelineId(value.timelineId, 'invalid_timeline_id')
  assertOpaqueTimelineId(value.projectId, 'invalid_project_id')
  if (!isPositiveSafeInteger(value.revision)) fail('invalid_revision')
  if (!(value.parentRevision === null || isNonNegativeSafeInteger(value.parentRevision))) {
    fail('invalid_parent_revision')
  }
  if (!isNullableFingerprint(value.parentRevisionFingerprint)) {
    fail('invalid_parent_revision_fingerprint')
  }
  if (
    (value.parentRevision === null) !== (value.parentRevisionFingerprint === null)
  ) {
    fail('invalid_parent_binding')
  }
  if (typeof value.status !== 'string' || !statuses.has(value.status)) fail('invalid_status')
  if (!isTimestamp(value.createdAt)) fail('invalid_created_at')
  if (!isPositiveSafeInteger(value.durationUs)) fail('invalid_duration_us')
  if (typeof value.orientation !== 'string' || !orientations.has(value.orientation)) {
    fail('invalid_orientation')
  }
  if (!isFps(value.fps)) fail('invalid_fps')
  if (
    !isRecord(value.source) ||
    (
      !hasExactKeys(value.source, sourceKeys) &&
      !hasExactKeys(value.source, sourceKeysWithAutomaticPackagingLegacy) &&
      !hasExactKeys(value.source, sourceKeysWithAutomaticPackagingLegacyCoverage) &&
      !hasExactKeys(value.source, sourceKeysWithTemplateIdentity) &&
      !hasExactKeys(value.source, sourceKeysWithAutomaticPackaging) &&
      !hasExactKeys(value.source, sourceKeysWithAutomaticPackagingCoverage) &&
      !hasExactKeys(value.source, sourceKeysWithAutomaticPackagingSelections) &&
      !hasExactKeys(value.source, sourceKeysWithAutomaticPackagingSelectionsCoverage) &&
      !hasExactKeys(value.source, sourceKeysWithTemplateIdentityAndAutomaticPackaging) &&
      !hasExactKeys(value.source, sourceKeysWithTemplateIdentityAndAutomaticPackagingLegacyCoverage) &&
      !hasExactKeys(value.source, sourceKeysWithTemplateIdentityAndAutomaticPackagingCoverage) &&
      !hasExactKeys(value.source, sourceKeysWithTemplateIdentityAndAutomaticPackagingSelections) &&
      !hasExactKeys(value.source, sourceKeysWithTemplateIdentityAndAutomaticPackagingSelectionsCoverage)
    )
  ) fail('invalid_source')
  if (typeof value.source.kind !== 'string' || !sourceKinds.has(value.source.kind)) {
    fail('invalid_source_kind')
  }
  if (!isNullableFingerprint(value.source.editPlanFingerprint)) fail('invalid_edit_plan_fingerprint')
  if (!isNullableFingerprint(value.source.templateFingerprint)) fail('invalid_template_fingerprint')
  if (!isNullableFingerprint(value.source.instructionFingerprint)) {
    fail('invalid_instruction_fingerprint')
  }
  if (
    Object.hasOwn(value.source, 'automaticPackaging') &&
    typeof value.source.automaticPackaging !== 'boolean'
  ) {
    fail('invalid_automatic_packaging_marker')
  }
  if (
    Object.hasOwn(value.source, 'packagingCatalogFingerprint') &&
    !isNullableFingerprint(value.source.packagingCatalogFingerprint)
  ) {
    fail('invalid_packaging_catalog_fingerprint')
  }
  if (Object.hasOwn(value.source, 'templatePackagingCoverage')) {
    const coverage = value.source.templatePackagingCoverage
    if (
      !isRecord(coverage) ||
      !hasExactKeys(coverage, ['flower', 'bubble']) ||
      (!(isPositiveSafeInteger(coverage.flower) || coverage.flower === 0)) ||
      (!(isPositiveSafeInteger(coverage.bubble) || coverage.bubble === 0))
    ) {
      fail('invalid_template_packaging_coverage')
    }
  }
  if (Object.hasOwn(value.source, 'packagingSelections')) {
    if (value.source.automaticPackaging !== true || !Array.isArray(value.source.packagingSelections) ||
        value.source.packagingSelections.length < 1 || value.source.packagingSelections.length > 24) {
      fail('invalid_packaging_selections')
    }
    const tokens = new Set()
    for (const selection of value.source.packagingSelections) {
      if (!isRecord(selection) || !hasExactKeys(selection, packagingSelectionKeys) ||
          !isOpaqueTimelineId(selection.packagingToken) || !isOpaqueTimelineId(selection.family) ||
          !isOpaqueTimelineId(selection.targetSegmentId) || typeof selection.label !== 'string' ||
          selection.label !== selection.label.trim() || selection.label.length < 1 || selection.label.length > 160 ||
          /[\u0000-\u001f]/u.test(selection.label) || tokens.has(selection.packagingToken)) {
        fail('invalid_packaging_selections')
      }
      tokens.add(selection.packagingToken)
    }
  }
  if (Object.hasOwn(value.source, 'templateIdentity')) {
    const identity = value.source.templateIdentity
    if (
      identity !== null &&
      (
        !isRecord(identity) ||
        !hasExactKeys(identity, templateIdentityKeys) ||
        !isOpaqueTimelineId(identity.libraryTemplateId) ||
        !isPositiveSafeInteger(identity.revision) ||
        !isFingerprint(identity.fingerprint)
      )
    ) {
      fail('invalid_template_identity')
    }
    if (
      (identity === null) !== (value.source.templateFingerprint === null) ||
      (
        identity !== null &&
        identity.fingerprint !== value.source.templateFingerprint
      )
    ) {
      fail('template_identity_fingerprint_mismatch')
    }
  }
  if (!isDenseArray(value.tracks) || !isDenseArray(value.markers)) fail('invalid_collections')
  if (!isDenseArray(value.capabilityRequirements)) fail('invalid_capability_requirements')

  for (const track of value.tracks) assertTrack(track)
  for (const marker of value.markers) assertMarker(marker)
  for (const requirement of value.capabilityRequirements) {
    assertCapabilityRequirement(requirement)
  }

  const trackIds = new Set()
  const segmentIds = new Set()
  const markerIds = new Set()
  const orders = []
  /** @type {Record<string, any> | null} */
  let primaryTrack = null
  for (const track of /** @type {Record<string, any>[]} */ (value.tracks)) {
    if (trackIds.has(track.trackId)) fail('duplicate_track_id')
    trackIds.add(track.trackId)
    orders.push(track.order)
    for (const segment of track.segments) {
      if (segmentIds.has(segment.segmentId)) fail('duplicate_segment_id')
      segmentIds.add(segment.segmentId)
    }
    if (track.kind === 'video' && track.role === 'primary') {
      if (primaryTrack) fail('multiple_primary_tracks')
      primaryTrack = track
    }
  }
  for (const marker of /** @type {Record<string, any>[]} */ (value.markers)) {
    if (markerIds.has(marker.markerId)) fail('duplicate_marker_id')
    markerIds.add(marker.markerId)
    if (marker.offsetUs > value.durationUs) fail('marker_out_of_range')
  }
  if (!primaryTrack) fail('missing_primary_track')
  if (primaryTrack.segments.length === 0) fail('empty_primary_track')

  const sortedOrders = [...orders].sort((left, right) => left - right)
  if (
    sortedOrders.some((order, index) => order !== index) ||
    value.tracks.some((track, index) => track.order !== index)
  ) {
    fail('invalid_track_order_sequence')
  }

  let cursor = 0
  for (let index = 0; index < primaryTrack.segments.length; index += 1) {
    const segment = primaryTrack.segments[index]
    if (segment.targetRange.startUs !== cursor) fail('primary_target_gap_or_overlap')
    const isLast = index === primaryTrack.segments.length - 1
    const transition = segment.transitionOut
    if (isLast) {
      if (transition.capabilityId !== 'transition.none' || transition.durationUs !== 0) {
        fail('invalid_terminal_transition')
      }
    } else if (transition.capabilityId === 'transition.none') {
      fail('invalid_nonterminal_transition')
    } else if (builtinTransitions.has(transition.capabilityId)) {
      if (transition.capabilityId !== 'transition.cut' || transition.durationUs !== 0) {
        fail('invalid_cut_transition')
      }
    } else {
      const next = primaryTrack.segments[index + 1]
      const maxWindow = Math.floor(
        Math.min(segment.targetRange.durationUs, next.targetRange.durationUs) / 2,
      )
      if (!(transition.durationUs > 0) || transition.durationUs > maxWindow) {
        fail('invalid_transition_duration')
      }
    }
    cursor += segment.targetRange.durationUs
  }
  if (cursor !== value.durationUs) fail('duration_mismatch')

  /** @type {Map<string, {startUs: number, durationUs: number}>} */
  const sceneBounds = new Map()
  if (options.sceneBoundsByKey instanceof Map) {
    for (const [key, bound] of options.sceneBoundsByKey.entries()) {
      sceneBounds.set(key, bound)
    }
  } else if (isRecord(options.sceneBoundsByKey)) {
    for (const [key, bound] of Object.entries(options.sceneBoundsByKey)) {
      sceneBounds.set(key, /** @type {{startUs: number, durationUs: number}} */ (bound))
    }
  }

  for (const track of /** @type {Record<string, any>[]} */ (value.tracks)) {
    for (const segment of track.segments) {
      if (track.kind === 'video') {
        const end = segment.targetRange.startUs + segment.targetRange.durationUs
        if (end > value.durationUs) fail('video_target_out_of_range')
        if (track.role === 'overlay' && Object.hasOwn(segment, 'transitionOut')) {
          fail('overlay_transition_forbidden')
        }
        const boundKey = `${segment.asset.assetId}\u0000${segment.asset.sceneId}`
        const bound = sceneBounds.get(boundKey)
        if (bound) {
          if (
            !isNonNegativeSafeInteger(bound.startUs) ||
            !isPositiveSafeInteger(bound.durationUs)
          ) {
            fail('invalid_scene_bound')
          }
          const sourceEnd = segment.sourceRange.startUs + segment.sourceRange.durationUs
          const boundEnd = bound.startUs + bound.durationUs
          if (
            segment.sourceRange.startUs < bound.startUs ||
            sourceEnd > boundEnd
          ) {
            fail('source_range_outside_scene')
          }
        }
      } else if (track.kind === 'audio' || track.kind === 'caption' ||
        track.kind === 'title' || track.kind === 'effect') {
        const end = segment.targetRange.startUs + segment.targetRange.durationUs
        if (end > value.durationUs) fail('secondary_target_out_of_range')
      }
    }
  }

  const expectedRequirements = computeCapabilityRequirements(value.tracks)
  const expectedIds = expectedRequirements.map((entry) => entry.capabilityId)
  const actualIds = value.capabilityRequirements.map((entry) => entry.capabilityId)
  if (
    actualIds.length !== expectedIds.length ||
    actualIds.some((id, index) => id !== expectedIds[index])
  ) {
    fail('capability_requirements_mismatch')
  }

  const expectedContent = contentFingerprint(value)
  if (value.contentFingerprint !== expectedContent) fail('content_fingerprint_mismatch')
  const { revisionFingerprint: _ignored, ...withoutRevisionFingerprint } = value
  const expectedRevision = revisionFingerprint(withoutRevisionFingerprint)
  if (value.revisionFingerprint !== expectedRevision) fail('revision_fingerprint_mismatch')

  return /** @type {Record<string, any>} */ (clone(value))
}

/** @param {Record<string, any>} partial */
export const sealRichTimeline = (partial) => {
  if (!isRecord(partial)) fail('invalid_timeline')
  const draft = clone(partial)
  delete draft.contentFingerprint
  delete draft.revisionFingerprint
  draft.contentFingerprint = contentFingerprint(draft)
  const sealed = {
    ...draft,
    revisionFingerprint: revisionFingerprint(draft),
  }
  return assertRichTimeline(sealed)
}

/** @param {unknown} draft @param {{instructionFingerprint?: string}} [options] */
export const finalizeRichTimeline = (draft, options = {}) => {
  const current = assertRichTimeline(draft)
  if (current.status !== 'draft') fail('finalize_requires_draft')
  const next = clone(current)
  next.revision = current.revision + 1
  next.parentRevision = current.revision
  next.parentRevisionFingerprint = current.revisionFingerprint
  next.status = 'finalized'
  if (Object.hasOwn(options, 'instructionFingerprint')) {
    if (!isNullableFingerprint(options.instructionFingerprint)) {
      fail('invalid_instruction_fingerprint')
    }
    next.source = {
      ...next.source,
      kind: 'agent',
      instructionFingerprint: options.instructionFingerprint,
    }
  }
  delete next.revisionFingerprint
  next.contentFingerprint = current.contentFingerprint
  next.revisionFingerprint = revisionFingerprint(next)
  return assertRichTimeline(next)
}

/** @param {unknown} timeline */
export const toPublicTimelineSummary = (timeline) => {
  const value = assertRichTimeline(timeline)
  const packagingSelections = readTimelinePackagingSelections(value)
    .filter((selection) => typeof selection.label === 'string' && typeof selection.targetSegmentId === 'string')
  const primaryTrack = value.tracks.find((/** @type {Record<string, any>} */ track) =>
    track.enabled && track.kind === 'video' && track.role === 'primary')
  const primarySegments = primaryTrack?.segments ?? []
  const overlaps = (
    /** @type {{startUs: number, durationUs: number}} */ left,
    /** @type {{startUs: number, durationUs: number}} */ right,
  ) => {
    const leftEnd = left.startUs + left.durationUs
    const rightEnd = right.startUs + right.durationUs
    return left.startUs < rightEnd && right.startUs < leftEnd
  }
  const shots = primarySegments.slice(0, MAX_PUBLIC_SHOTS).map((
    /** @type {Record<string, any>} */ segment,
    /** @type {number} */ index,
  ) => {
    const captionKeys = new Set()
    const captions = value.tracks
      .filter((/** @type {Record<string, any>} */ track) => track.enabled && track.kind === 'caption')
      .flatMap((/** @type {Record<string, any>} */ track) => track.segments)
      .filter((/** @type {Record<string, any>} */ caption) => overlaps(caption.targetRange, segment.targetRange))
      .map((/** @type {Record<string, any>} */ caption) => ({
        text: caption.text.trim(),
        targetRange: caption.targetRange,
      }))
      .filter((/** @type {{text: string, targetRange: {startUs: number, durationUs: number}}} */ caption) => Boolean(caption.text))
      .filter((/** @type {{text: string, targetRange: {startUs: number, durationUs: number}}} */ caption) => {
        const { text, targetRange } = caption
        const key = `${text}\u0000${targetRange.startUs}:${targetRange.durationUs}`
        if (captionKeys.has(key)) return false
        captionKeys.add(key)
        return true
      })
    const audioRoles = [...new Set(value.tracks
      .filter((/** @type {Record<string, any>} */ track) => track.enabled && track.kind === 'audio')
      .filter((/** @type {Record<string, any>} */ track) => track.segments.some((
        /** @type {Record<string, any>} */ audio,
      ) =>
        overlaps(audio.targetRange, segment.targetRange)))
      .map((/** @type {Record<string, any>} */ track) => track.role))].slice(0, 4)
    return {
      order: index + 1,
      shotId: segment.segmentId,
      assetId: segment.asset.assetId,
      sceneId: segment.asset.sceneId,
      candidateId: segment.audit.candidateId,
      sourceRange: clone(segment.sourceRange),
      targetRange: clone(segment.targetRange),
      captions: captions.slice(0, 4).map((/** @type {{text: string}} */ caption) => caption.text.slice(0, 240)),
      audioRoles,
      transitionOut: {
        capabilityId: segment.transitionOut.capabilityId,
        durationUs: segment.transitionOut.durationUs,
      },
    }
  })
  const summary = {
    timelineId: value.timelineId,
    revision: value.revision,
    contentFingerprint: value.contentFingerprint,
    revisionFingerprint: value.revisionFingerprint,
    status: value.status,
    durationUs: value.durationUs,
    createdAt: value.createdAt,
    sourceKind: value.source.kind,
    shotCount: primarySegments.length,
    shots,
    ...(packagingSelections.length > 0
      ? { packaging: packagingSelections.map((selection) => ({
          feedbackHandle: `ovpkgfb_v1_${sha256Hex(stableStringify({
            revisionFingerprint: value.revisionFingerprint,
            packagingToken: selection.packagingToken,
          })).slice(0, 24)}`,
          label: /** @type {string} */ (selection.label),
          family: selection.family,
          targetSegmentId: /** @type {string} */ (selection.targetSegmentId),
        })) }
      : {}),
  }
  if (!hasExactKeys(summary, publicSummaryKeys) && !hasExactKeys(summary, publicSummaryKeysWithPackaging)) fail('invalid_public_summary')
  return summary
}

/** Resolve a public feedback handle only against the exact timeline revision that issued it. */
/** @param {unknown} timeline @param {unknown} feedbackHandle @returns {string | null} */
export const resolvePackagingFeedbackHandle = (timeline, feedbackHandle) => {
  const value = assertRichTimeline(timeline)
  const packagingSelections = readTimelinePackagingSelections(value)
  if (typeof feedbackHandle !== 'string' || !/^ovpkgfb_v1_[a-f0-9]{24}$/u.test(feedbackHandle)) return null
  for (const selection of packagingSelections) {
    const candidate = `ovpkgfb_v1_${sha256Hex(stableStringify({
      revisionFingerprint: value.revisionFingerprint,
      packagingToken: selection.packagingToken,
    })).slice(0, 24)}`
    if (candidate === feedbackHandle) return selection.packagingToken
  }
  return null
}

export const __testing = {
  stableStringify,
  sha256Hex,
  projectContent,
}
