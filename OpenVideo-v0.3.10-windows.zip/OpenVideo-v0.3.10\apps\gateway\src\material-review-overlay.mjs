import { randomUUID } from 'node:crypto'
import { copyFile, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { isAbsolute, resolve } from 'node:path'

const schemaVersion = 1
const opaqueIdPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u
const reviewStatuses = new Set(['confirmed', 'needsReview', 'unavailable'])
const correctionKeys = new Set([
  'summary',
  'ocrText',
  'asrSummary',
  'domainTags',
  'visualTags',
  'actionTags',
  'shotPurpose',
  'recommendedUse',
])

/** @typedef {'confirmed'|'needsReview'|'unavailable'} ReviewStatus */
/** @typedef {Record<string, string|string[]>} ReviewCorrection */
/** @typedef {{projectId: string, assetId: string, sceneId: string, status: ReviewStatus, correction: ReviewCorrection, updatedAt: string}} ReviewRecord */
/** @typedef {{schema_version: number, records: ReviewRecord[]}} ReviewStore */

export class MaterialReviewOverlayError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'MaterialReviewOverlayError'
    this.code = code
    this.status = status
  }
}

/**
 * Applies private review decisions at every material-consumption boundary.
 * The provider is mutated during server composition so all downstream
 * consumers, including Preview and Jianying, share the same fail-closed view.
 * @param {{provider: Record<string, any>, overlay: Awaited<ReturnType<typeof createMaterialReviewOverlay>>}} input
 */
export const applyMaterialReviewOverlayToProvider = ({ provider, overlay }) => {
  const assertAvailable = (/** @type {{projectId?: string, candidateId?: string}} */ input) => {
    if (typeof input?.projectId === 'string' && typeof input?.candidateId === 'string') {
      overlay.assertSceneAvailable(input.projectId, input.candidateId)
    }
  }

  const rawSearchCandidates = provider.searchCandidates.bind(provider)
  provider.searchCandidates = async (/** @type {Record<string, any>} */ input) =>
    overlay.applyCandidates(
      input.projectId,
      /** @type {Record<string, any>[]} */ (await rawSearchCandidates(input)),
    )

  const rawInspectCandidate = provider.inspectCandidate.bind(provider)
  provider.inspectCandidate = async (/** @type {Record<string, any>} */ input) => {
    assertAvailable(input)
    const result = await rawInspectCandidate(input)
    assertAvailable(input)
    return result
  }

  const rawResolveCandidateClipSource = provider.resolveCandidateClipSource.bind(provider)
  provider.resolveCandidateClipSource = async (/** @type {Record<string, any>} */ input) => {
    assertAvailable(input)
    const result = await rawResolveCandidateClipSource(input)
    assertAvailable(input)
    return result
  }

  const rawResolvePreviewSources = provider.resolvePreviewSources.bind(provider)
  provider.resolvePreviewSources = async (/** @type {Record<string, any>} */ input) => {
    for (const selection of Array.isArray(input?.selections) ? input.selections : []) {
      assertAvailable({ projectId: input.projectId, candidateId: selection?.candidateId })
    }
    const result = await rawResolvePreviewSources(input)
    for (const selection of Array.isArray(input?.selections) ? input.selections : []) {
      assertAvailable({ projectId: input.projectId, candidateId: selection?.candidateId })
    }
    return result
  }

  return provider
}

/** @param {unknown} value */
const safeId = (value) => typeof value === 'string' && opaqueIdPattern.test(value)
/** @param {unknown} value @param {number} maximum */
const safeText = (value, maximum) =>
  typeof value === 'string' && value.length <= maximum &&
  !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value) &&
  !/(?:[a-z]:[\\/]|\\\\|(?:file|https?):\/\/|\.(?:mp4|mov|mkv|avi|mp3|wav|aac|m4a)(?:\b|$))/iu.test(value)
/** @param {unknown} value */
const safeTags = (value) => Array.isArray(value) && value.length <= 12 && value.every((tag) => safeText(tag, 80) && tag.trim())

/** @param {unknown} value */
const validCorrection = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  if (Object.keys(value).some((key) => !correctionKeys.has(key))) return false
  return Object.entries(value).every(([key, entry]) =>
    ['domainTags', 'visualTags', 'actionTags'].includes(key)
      ? safeTags(entry)
      : safeText(entry, key === 'shotPurpose' ? 120 : 500) && /** @type {string} */ (entry).trim())
}

/** @param {unknown} value */
const validRecord = (value) =>
  value &&
  typeof value === 'object' &&
  !Array.isArray(value) &&
  safeId(/** @type {Record<string, unknown>} */ (value).projectId) &&
  safeId(/** @type {Record<string, unknown>} */ (value).assetId) &&
  safeId(/** @type {Record<string, unknown>} */ (value).sceneId) &&
  reviewStatuses.has(/** @type {any} */ (value).status) &&
  validCorrection(/** @type {Record<string, unknown>} */ (value).correction) &&
  typeof /** @type {Record<string, unknown>} */ (value).updatedAt === 'string' &&
  Number.isFinite(Date.parse(/** @type {Record<string, string>} */ (value).updatedAt))

/** @param {unknown} value */
const validStore = (value) =>
  value &&
  typeof value === 'object' &&
  !Array.isArray(value) &&
  /** @type {Record<string, unknown>} */ (value).schema_version === schemaVersion &&
  Array.isArray(/** @type {Record<string, unknown>} */ (value).records) &&
  /** @type {unknown[]} */ (/** @type {Record<string, unknown>} */ (value).records).length <= 100_000 &&
  /** @type {unknown[]} */ (/** @type {Record<string, unknown>} */ (value).records).every(validRecord)

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {string} projectId @param {string} assetId @param {string} sceneId */
const recordKey = (projectId, assetId, sceneId) => `${projectId}\u0000${assetId}\u0000${sceneId}`

/**
 * Private, review-only overlay. Machine analysis remains immutable and can be
 * regenerated; human corrections survive analyzer upgrades without being
 * represented as newly observed OCR or ASR evidence.
 * @param {{dataRoot: string, securePrivateRoot?: (dataRoot: string) => Promise<void>, renameImpl?: typeof rename}} options
 */
export const createMaterialReviewOverlay = async ({ dataRoot, securePrivateRoot = async (_dataRoot) => {}, renameImpl = rename }) => {
  if (!isAbsolute(dataRoot)) throw new MaterialReviewOverlayError('MATERIAL_REVIEW_DATA_ROOT_REQUIRED', 500)
  const root = resolve(dataRoot, 'material-analysis')
  const filePath = resolve(root, 'review-overlays.json')
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRoot(dataRoot)

  /** @type {ReviewStore} */
  let store = { schema_version: schemaVersion, records: [] }
  let primaryMissing = false
  try {
    const loaded = JSON.parse(await readFile(filePath, 'utf8'))
    if (!validStore(loaded)) throw new Error('invalid_store')
    store = /** @type {ReviewStore} */ (loaded)
  } catch (error) {
    primaryMissing = Boolean(error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT')
    try {
      const backup = JSON.parse(await readFile(`${filePath}.bak`, 'utf8'))
      if (!validStore(backup)) throw new Error('invalid_backup')
      store = /** @type {ReviewStore} */ (backup)
    } catch (backupError) {
      const backupMissing = Boolean(backupError && typeof backupError === 'object' && 'code' in backupError && backupError.code === 'ENOENT')
      if (!primaryMissing || !backupMissing) throw new MaterialReviewOverlayError('MATERIAL_REVIEW_STORAGE_CORRUPT')
    }
  }

  /** @type {Map<string, ReviewRecord>} */
  const records = new Map(store.records.map((record) => [recordKey(record.projectId, record.assetId, record.sceneId), record]))
  let writeChain = Promise.resolve()
  const persist = async () => {
    const snapshot = { schema_version: schemaVersion, records: [...records.values()].map(clone) }
    const temporaryPath = `${filePath}.${randomUUID()}.tmp`
    try {
      await writeFile(temporaryPath, `${JSON.stringify(snapshot, null, 2)}\n`, { encoding: 'utf8', flag: 'wx', mode: 0o600 })
      const backupPath = `${filePath}.bak`
      const backupTemporaryPath = `${backupPath}.${randomUUID()}.tmp`
      try {
        await copyFile(filePath, backupTemporaryPath)
        await renameImpl(backupTemporaryPath, backupPath)
      } catch (error) {
        if (!(error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT')) throw error
      } finally {
        await rm(backupTemporaryPath, { force: true }).catch(() => {})
      }
      await renameImpl(temporaryPath, filePath)
    } finally {
      await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }

  /** @param {string} projectId @param {any} project */
  const apply = (projectId, project) => {
    const result = clone(project)
    for (const asset of result?.materials?.assets ?? []) {
      for (const scene of asset?.scenes ?? []) {
        const record = records.get(recordKey(projectId, asset.id, scene.id))
        if (!record) {
          scene.reviewStatus = scene.needsReview === true ? 'needsReview' : 'confirmed'
          continue
        }
        Object.assign(scene, clone(record.correction), {
          reviewStatus: record.status,
          reviewUpdatedAt: record.updatedAt,
          needsReview: record.status !== 'confirmed',
        })
      }
    }
    return result
  }

  /** @param {{projectId: string, assetId: string, sceneId: string, status: ReviewStatus, correction: ReviewCorrection}} input */
  const save = async ({ projectId, assetId, sceneId, status, correction }) => {
    if (!safeId(projectId) || !safeId(assetId) || !safeId(sceneId) || !reviewStatuses.has(status) || !validCorrection(correction)) {
      throw new MaterialReviewOverlayError('MATERIAL_REVIEW_INPUT_INVALID', 400)
    }
    const record = { projectId, assetId, sceneId, status, correction: clone(correction), updatedAt: new Date().toISOString() }
    const operation = writeChain.then(async () => {
      const key = recordKey(projectId, assetId, sceneId)
      const previous = records.get(key)
      records.set(key, record)
      try {
        await persist()
      } catch (error) {
        if (previous) records.set(key, previous)
        else records.delete(key)
        throw error
      }
      return clone(record)
    })
    writeChain = operation.then(() => undefined, () => undefined)
    return operation
  }

  /** @param {string} projectId @param {string} assetId @param {string} sceneId */
  const get = (projectId, assetId, sceneId) =>
    clone(records.get(recordKey(projectId, assetId, sceneId)) ?? null)

  /** @param {string} projectId @param {Record<string, any>[]} candidates */
  const applyCandidates = (projectId, candidates) => candidates.flatMap((candidate) => {
    const record = records.get(recordKey(projectId, candidate.assetId, candidate.id))
    if (record?.status === 'unavailable') return []
    return [{ ...clone(candidate), ...(record ? clone(record.correction) : {}) }]
  })
  /** @param {string} projectId @param {string} sceneId */
  const isUnavailableScene = (projectId, sceneId) =>
    [...records.values()].some((record) => record.projectId === projectId && record.sceneId === sceneId && record.status === 'unavailable')
  /** @param {string} projectId @param {string} sceneId */
  const assertSceneAvailable = (projectId, sceneId) => {
    if (isUnavailableScene(projectId, sceneId)) {
      throw new MaterialReviewOverlayError('MATERIAL_REVIEW_SCENE_UNAVAILABLE', 409)
    }
  }

  return { apply, save, get, applyCandidates, isUnavailableScene, assertSceneAvailable }
}
