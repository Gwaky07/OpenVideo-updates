/**
 * Private, auditable Jianying filter resolver.
 *
 * Public timeline data carries only an opaque OpenVideo token.  A resolver may
 * return private resource identifiers to the writer, but only when the catalog
 * fingerprint and current editable-open evidence are present and valid.
 */

const resourceIdPattern = /^[A-Za-z0-9_-]{4,80}$/u
const semverPattern = /^\d+\.\d+\.\d+(?:\.\d+)?$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const tokenPatterns = Object.freeze({
  'filter.video.named': /^ovjflt_v1_segment_[A-Za-z0-9_-]{32,160}$/u,
  'filter.video.track_named': /^ovjflt_v1_track_[A-Za-z0-9_-]{32,160}$/u,
})

export class JianyingFilterResolverError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 409) {
    super(code)
    this.name = 'JianyingFilterResolverError'
    this.code = code
    this.status = status
  }
}

/**
 * @param {{
 *   resolveFilterToken?: (input: {filterToken: string, capabilityId: string}) =>
 *     Promise<{resourceId: string, filterId?: string, catalogFingerprint: string, catalogVersion: string,
 *       editableEvidence: {supportedVersion: string, draftFingerprint: string, opened: boolean, edited: boolean, saved: boolean}} | null>
 *     | {resourceId: string, filterId?: string, catalogFingerprint: string, catalogVersion: string,
 *       editableEvidence: {supportedVersion: string, draftFingerprint: string, opened: boolean, edited: boolean, saved: boolean}} | null,
 *   getTrustedEvidenceBinding?: (capabilityId?: string) =>
 *     {supportedVersion: string, catalogFingerprint: string, draftFingerprint: string} | null,
 * }} [options]
 */
export const createJianyingFilterResolver = (options = {}) => {
  const resolveFn = typeof options.resolveFilterToken === 'function'
    ? options.resolveFilterToken
    : null
  const getTrustedEvidenceBinding = typeof options.getTrustedEvidenceBinding === 'function'
    ? options.getTrustedEvidenceBinding
    : null

  /** @param {unknown} filterToken @param {unknown} capabilityId */
  const resolveFilterToken = async (filterToken, capabilityId) => {
    const tokenPattern = typeof capabilityId === 'string'
      ? Object.entries(tokenPatterns).find(([candidate]) => candidate === capabilityId)?.[1]
      : undefined
    if (
      typeof capabilityId !== 'string' ||
      !tokenPattern ||
      typeof filterToken !== 'string' || !tokenPattern.test(filterToken)
    ) {
      throw new JianyingFilterResolverError('JY012_FILTER_TOKEN_INVALID', 400)
    }
    if (!resolveFn) throw new JianyingFilterResolverError('JY012_FILTER_RESOURCE_UNRESOLVED')
    let trustedBinding
    let resolved
    try {
      trustedBinding = getTrustedEvidenceBinding?.(capabilityId) ?? null
      resolved = await resolveFn({ filterToken, capabilityId })
    } catch {
      throw new JianyingFilterResolverError('JY012_FILTER_RESOURCE_UNRESOLVED')
    }
    const evidence = resolved?.editableEvidence
    if (
      !trustedBinding ||
      typeof trustedBinding.supportedVersion !== 'string' || !semverPattern.test(trustedBinding.supportedVersion) ||
      typeof trustedBinding.catalogFingerprint !== 'string' || !fingerprintPattern.test(trustedBinding.catalogFingerprint) ||
      typeof trustedBinding.draftFingerprint !== 'string' || !fingerprintPattern.test(trustedBinding.draftFingerprint) ||
      !resolved ||
      typeof resolved.resourceId !== 'string' || !resourceIdPattern.test(resolved.resourceId) ||
      (resolved.filterId !== undefined &&
        (typeof resolved.filterId !== 'string' || !resourceIdPattern.test(resolved.filterId))) ||
      typeof resolved.catalogFingerprint !== 'string' || !fingerprintPattern.test(resolved.catalogFingerprint) ||
      typeof resolved.catalogVersion !== 'string' || !semverPattern.test(resolved.catalogVersion) ||
      !evidence ||
      typeof evidence.supportedVersion !== 'string' || !semverPattern.test(evidence.supportedVersion) ||
      typeof evidence.draftFingerprint !== 'string' || !fingerprintPattern.test(evidence.draftFingerprint) ||
      evidence.opened !== true || evidence.edited !== true || evidence.saved !== true ||
      evidence.supportedVersion !== trustedBinding.supportedVersion ||
      resolved.catalogFingerprint !== trustedBinding.catalogFingerprint ||
      evidence.draftFingerprint !== trustedBinding.draftFingerprint
    ) {
      throw new JianyingFilterResolverError('JY012_FILTER_EDITABLE_EVIDENCE_MISSING')
    }
    return {
      filterToken,
      capabilityId,
      resourceId: resolved.resourceId,
      ...(resolved.filterId ? { filterId: resolved.filterId } : {}),
      catalogFingerprint: resolved.catalogFingerprint,
      catalogVersion: resolved.catalogVersion,
      editableEvidence: structuredClone(evidence),
    }
  }

  return { resolveFilterToken }
}
