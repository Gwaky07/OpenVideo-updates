import { execFile as execFileCallback } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { lstat, mkdir, mkdtemp, open, readFile, readdir, realpath, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'

import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'

const execFile = promisify(execFileCallback)
const repositoryRoot = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const allowedModules = Object.freeze(['duo-server-base', 'duo-video-base', 'duo-video-jy'])
const excludedComponents = Object.freeze([
  'duo-video-api',
  'auto-jy/auto-jy-mac',
  'auto-jy/auto-jy-win',
])
const testArtifactPattern = /(?:^|[-.])(assertj|hamcrest|junit|mockito|objenesis|opentest4j)(?:[-.]|$)|json-path|jsonassert|spring-boot-test|xmlunit/u
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const errorCode = (error) => error && typeof error === 'object' && 'code' in error ? error.code : undefined
const normalizedPath = (value) => path.resolve(value).replace(/[\\/]+$/u, '')
const samePath = (left, right) => process.platform === 'win32'
  ? normalizedPath(left).toLowerCase() === normalizedPath(right).toLowerCase()
  : normalizedPath(left) === normalizedPath(right)
const inside = (root, candidate) => {
  const relative = path.relative(path.resolve(root), path.resolve(candidate))
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative))
}
const objectIdentity = (metadata) => {
  if ((typeof metadata?.dev !== 'number' && typeof metadata?.dev !== 'bigint') ||
      (typeof metadata?.ino !== 'number' && typeof metadata?.ino !== 'bigint')) return null
  return `${metadata.dev}:${metadata.ino}`
}
const sameResolvedObject = async (requested, actual, requestedMetadata = undefined) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const [expected, observed] = await Promise.all([
    requestedMetadata ?? lstat(requested, { bigint: true }),
    lstat(actual, { bigint: true }),
  ])
  const expectedIdentity = objectIdentity(expected)
  return expectedIdentity !== null && expectedIdentity === objectIdentity(observed)
}
const directoryIdentity = (metadata) => Object.freeze({
  dev: metadata.dev.toString(),
  ino: metadata.ino.toString(),
  birthtime_ns: metadata.birthtimeNs.toString(),
})

const observeOwnedDirectory = async ({ runtimeRoot, candidate }) => {
  const resolvedRoot = path.resolve(runtimeRoot)
  const resolved = path.resolve(candidate)
  if (!inside(resolvedRoot, resolved)) throw new Error('JY200_DUO_RUNTIME_STAGING_UNSAFE')
  const [rootMetadata, canonicalRoot, metadata, actual] = await Promise.all([
    lstat(resolvedRoot, { bigint: true }), realpath(resolvedRoot),
    lstat(resolved, { bigint: true }), realpath(resolved),
  ])
  if (!rootMetadata.isDirectory() || rootMetadata.isSymbolicLink() ||
      !await sameResolvedObject(resolvedRoot, canonicalRoot, rootMetadata) ||
      !metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameResolvedObject(resolved, actual, metadata) || !inside(canonicalRoot, actual)) {
    throw new Error('JY200_DUO_RUNTIME_STAGING_UNSAFE')
  }
  return Object.freeze({ path: resolved, ...directoryIdentity(metadata) })
}

const assertOwnedDirectoryCurrent = async ({ runtimeRoot, identity }) => {
  const current = await observeOwnedDirectory({ runtimeRoot, candidate: identity.path })
  if (current.dev !== identity.dev || current.ino !== identity.ino || current.birthtime_ns !== identity.birthtime_ns) {
    throw new Error('JY200_DUO_RUNTIME_STAGING_REPLACED')
  }
}

const ensureOwnedDirectoryTree = async ({ runtimeRoot, candidate }) => {
  const resolvedRoot = path.resolve(runtimeRoot)
  const resolved = path.resolve(candidate)
  if (samePath(resolvedRoot, resolved) || !inside(resolvedRoot, resolved)) {
    throw new Error('JY200_DUO_RUNTIME_STAGING_UNSAFE')
  }
  await observeOwnedDirectory({ runtimeRoot: resolvedRoot, candidate: resolvedRoot })
  let cursor = resolvedRoot
  for (const segment of path.relative(resolvedRoot, resolved).split(path.sep).filter(Boolean)) {
    assertSafeSegment(segment)
    cursor = path.join(cursor, segment)
    try {
      await mkdir(cursor, { mode: 0o700 })
    } catch (error) {
      if (errorCode(error) !== 'EEXIST') throw error
    }
    await observeOwnedDirectory({ runtimeRoot: resolvedRoot, candidate: cursor })
  }
  return observeOwnedDirectory({ runtimeRoot: resolvedRoot, candidate: resolved })
}

export const createOwnedRuntimeStaging = async ({ runtimeRoot, outputParent }) => {
  const parentIdentity = await ensureOwnedDirectoryTree({ runtimeRoot, candidate: outputParent })
  const stagingRoot = await mkdtemp(path.join(parentIdentity.path, 'build-'))
  await assertOwnedDirectoryCurrent({ runtimeRoot, identity: parentIdentity })
  const stagingIdentity = await observeOwnedDirectory({ runtimeRoot, candidate: stagingRoot })
  return Object.freeze({ runtimeRoot: path.resolve(runtimeRoot), parentIdentity, stagingIdentity, stagingRoot })
}

export const assertOwnedRuntimeStagingCurrent = async (lease) => {
  await assertOwnedDirectoryCurrent({ runtimeRoot: lease.runtimeRoot, identity: lease.parentIdentity })
  await assertOwnedDirectoryCurrent({ runtimeRoot: lease.runtimeRoot, identity: lease.stagingIdentity })
}

const assertNoReparseDescendants = async ({ runtimeRoot, stagingRoot }) => {
  let visited = 0
  const canonicalRoot = await realpath(runtimeRoot)
  const visit = async (candidate) => {
    visited += 1
    if (visited > 50_000) throw new Error('JY200_DUO_RUNTIME_STAGING_UNSAFE')
    const metadata = await lstat(candidate)
    const actual = await realpath(candidate)
    if (metadata.isSymbolicLink() || !await sameResolvedObject(candidate, actual, metadata) || !inside(canonicalRoot, actual)) {
      throw new Error('JY200_DUO_RUNTIME_STAGING_UNSAFE')
    }
    if (!metadata.isDirectory()) return
    for (const entry of await readdir(candidate, { withFileTypes: true })) {
      if (entry.isSymbolicLink()) throw new Error('JY200_DUO_RUNTIME_STAGING_UNSAFE')
      await visit(path.join(candidate, entry.name))
    }
  }
  await visit(stagingRoot)
}

const removeOwnedRuntimeStaging = async (lease) => {
  await assertOwnedRuntimeStagingCurrent(lease)
  const tombstone = path.join(lease.parentIdentity.path, `.delete-${randomUUID().replaceAll('-', '')}`)
  await rename(lease.stagingRoot, tombstone)
  await assertOwnedDirectoryCurrent({ runtimeRoot: lease.runtimeRoot, identity: lease.parentIdentity })
  const tombstoneIdentity = await observeOwnedDirectory({ runtimeRoot: lease.runtimeRoot, candidate: tombstone })
  if (tombstoneIdentity.dev !== lease.stagingIdentity.dev || tombstoneIdentity.ino !== lease.stagingIdentity.ino ||
      tombstoneIdentity.birthtime_ns !== lease.stagingIdentity.birthtime_ns) {
    throw new Error('JY200_DUO_RUNTIME_STAGING_REPLACED')
  }
  await rm(tombstone, { recursive: true, force: true })
}

export const createDuoToolEnvironment = (source = process.env) => {
  /** @type {NodeJS.ProcessEnv} */
  const output = {}
  for (const expected of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP', 'JAVA_HOME', 'MAVEN_HOME']) {
    const actual = Object.keys(source).find((key) => key.toLowerCase() === expected.toLowerCase())
    if (actual && typeof source[actual] === 'string') output[expected] = source[actual]
  }
  return output
}

const runMaven = async (args, options) => {
  const mavenHome = process.env.MAVEN_HOME
  const javaHome = process.env.JAVA_HOME
  if (!mavenHome || !javaHome || !path.isAbsolute(mavenHome) || !path.isAbsolute(javaHome)) {
    throw new Error('JY200_DUO_RUNTIME_TOOLCHAIN_INVALID')
  }
  const classworlds = (await readdir(path.join(mavenHome, 'boot')))
    .filter((entry) => /^plexus-classworlds-[\d.]+\.jar$/u.test(entry))
  if (classworlds.length !== 1) throw new Error('JY200_DUO_RUNTIME_TOOLCHAIN_INVALID')
  return execFile(path.join(javaHome, 'bin', 'java.exe'), [
    '-classpath', path.join(mavenHome, 'boot', classworlds[0]),
    `-Dclassworlds.conf=${path.join(mavenHome, 'bin', 'm2.conf')}`,
    `-Dmaven.home=${mavenHome}`,
    `-Dlibrary.jansi.path=${path.join(mavenHome, 'lib', 'jansi-native')}`,
    `-Dmaven.multiModuleProjectDirectory=${options.cwd}`,
    'org.codehaus.plexus.classworlds.launcher.Launcher',
    ...args,
  ], {
    ...options,
    env: createDuoToolEnvironment(),
    windowsHide: true,
    maxBuffer: 16 * 1024 * 1024,
  })
}

const assertSafeSegment = (value) => {
  if (value === '.' || value === '..' || value.length === 0 || /[\\/:\0-\x1f]/u.test(value)) {
    throw new Error('JY200_DUO_RUNTIME_PATH_INVALID')
  }
  return value
}

const loadPinnedTree = async ({ upstreamRoot, commit }) => {
  const { stdout } = await execFile('git.exe', [
    '-C', upstreamRoot, 'ls-tree', '-r', '-z', commit, '--',
    'LICENSE', 'pom.xml', '.gitmodules', ...allowedModules,
  ], {
    timeout: 10_000, windowsHide: true, maxBuffer: 16 * 1024 * 1024, encoding: 'buffer',
  })
  const entries = new Map()
  for (const raw of stdout.toString('utf8').split('\0').filter(Boolean)) {
    const match = /^(\d{6}) blob ([a-f0-9]{40,64})\t(.+)$/u.exec(raw)
    if (!match || match[1] !== '100644') throw new Error('JY200_DUO_RUNTIME_GIT_TREE_INVALID')
    const segments = match[3].split('/')
    segments.forEach(assertSafeSegment)
    entries.set(match[3], Object.freeze({ oid: match[2], segments }))
  }
  return entries
}

const readPinnedBlob = async ({ upstreamRoot, entry }) => {
  const { stdout } = await execFile('git.exe', ['-C', upstreamRoot, 'cat-file', 'blob', entry.oid], {
    timeout: 10_000, windowsHide: true, maxBuffer: 32 * 1024 * 1024, encoding: 'buffer',
  })
  return stdout
}

const exportPinnedModules = async ({ upstreamRoot, commit, stagingRoot }) => {
  const tree = await loadPinnedTree({ upstreamRoot, commit })
  const selected = [...tree.entries()].filter(([file]) => allowedModules.some((module) => file.startsWith(`${module}/`)))
  if (selected.length === 0) throw new Error('JY200_DUO_RUNTIME_GIT_TREE_INVALID')
  for (let offset = 0; offset < selected.length; offset += 8) {
    await Promise.all(selected.slice(offset, offset + 8).map(async ([, entry]) => {
      const destination = path.join(stagingRoot, ...entry.segments)
      await mkdir(path.dirname(destination), { recursive: true, mode: 0o700 })
      await writeFile(destination, await readPinnedBlob({ upstreamRoot, entry }), { mode: 0o600, flag: 'wx' })
    }))
  }
  return tree
}

const replaceExactlyOnce = (source, pattern, replacement, code) => {
  const matches = source.match(new RegExp(pattern.source, `${pattern.flags.replace('g', '')}g`)) ?? []
  if (matches.length !== 1) throw new Error(code)
  return source.replace(pattern, replacement)
}

export const createWriterOnlyPoms = ({ rootPom, basePom, writerPom }) => {
  const modules = allowedModules.map((module) => `        <module>${module}</module>`).join('\n')
  const patchedRootPom = replaceExactlyOnce(
    rootPom,
    /\s*<modules>[\s\S]*?<\/modules>/u,
    `\n    <modules>\n${modules}\n    </modules>`,
    'JY200_DUO_RUNTIME_ROOT_POM_INVALID',
  )
  const starterTest = /(<dependency>\s*<groupId>org\.springframework\.boot<\/groupId>\s*<artifactId>spring-boot-starter-test<\/artifactId>)(\s*<\/dependency>)/u
  let patchedWriterPom = replaceExactlyOnce(
    writerPom,
    starterTest,
    '<dependency>\n            <groupId>org.projectlombok</groupId>\n            <artifactId>lombok</artifactId>\n            <scope>provided</scope>\n        </dependency>\n\n        $1\n            <scope>test</scope>$2',
    'JY200_DUO_RUNTIME_TEST_SCOPE_PATCH_INVALID',
  )
  const lombok = /(<dependency>\s*<groupId>org\.projectlombok<\/groupId>\s*<artifactId>lombok<\/artifactId>)(\s*<\/dependency>)/u
  const patchedBasePom = replaceExactlyOnce(
    basePom,
    lombok,
    '$1\n            <scope>provided</scope>$2',
    'JY200_DUO_RUNTIME_LOMBOK_SCOPE_PATCH_INVALID',
  )
  return Object.freeze({ patchedRootPom, patchedBasePom, patchedWriterPom })
}

export const createWriterSourcePatches = ({ baseVisible, videoSegment, utils }) => {
  let patchedBaseVisible = replaceExactlyOnce(baseVisible, /import org\.assertj\.core\.util\.Lists;\r?\n/u, '', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedBaseVisible = replaceExactlyOnce(patchedBaseVisible, /import java\.io\.File;\r?\n/u, (match) => `${match}import java.util.ArrayList;\n`, 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedBaseVisible = replaceExactlyOnce(patchedBaseVisible, /Lists\.newArrayList\(\)/u, 'new ArrayList<>()', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')

  let patchedVideoSegment = replaceExactlyOnce(videoSegment, /import org\.assertj\.core\.util\.Lists;\r?\n/u, '', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedVideoSegment = replaceExactlyOnce(patchedVideoSegment, /import java\.io\.File;\r?\n/u, (match) => `${match}import java.util.ArrayList;\nimport java.util.Collections;\n`, 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedVideoSegment = replaceExactlyOnce(patchedVideoSegment, /Lists\.newArrayList\(materialData\.getCombinationDraftId\(\)\)/u, 'new ArrayList<>(Collections.singletonList(materialData.getCombinationDraftId()))', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedVideoSegment = replaceExactlyOnce(patchedVideoSegment, /Lists\.newArrayList\(segment, backgroundDto\.segment\)/u, 'new ArrayList<>(List.of(segment, backgroundDto.segment))', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')

  let patchedUtils = replaceExactlyOnce(utils, /import org\.assertj\.core\.util\.Lists;\r?\n/u, '', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedUtils = replaceExactlyOnce(patchedUtils, /import org\.assertj\.core\.util\.Sets;\r?\n/u, '', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedUtils = replaceExactlyOnce(patchedUtils, /import java\.util\.Comparator;\r?\n/u, (match) => `${match}import java.util.HashSet;\n`, 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedUtils = replaceExactlyOnce(patchedUtils, /Sets\.newHashSet\(\)/u, 'new HashSet<>()', 'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  patchedUtils = patchedUtils.replaceAll('Lists.newArrayList()', 'new ArrayList<>()')
  patchedUtils = replaceExactlyOnce(
    patchedUtils,
    /Lists\.newArrayList\(\s*draft\.getId\(\)\s*\)/u,
    'new ArrayList<>(List.of(draft.getId()))',
    'JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID',
  )
  if (/org\.assertj|Lists\.|Sets\./u.test(`${patchedBaseVisible}\n${patchedVideoSegment}\n${patchedUtils}`)) {
    throw new Error('JY200_DUO_RUNTIME_ASSERTJ_PATCH_INVALID')
  }
  return Object.freeze({ patchedBaseVisible, patchedVideoSegment, patchedUtils })
}

export const clearDeviceIdentityFields = (source) => {
  const parsed = JSON.parse(source)
  const visit = (value) => {
    if (!value || typeof value !== 'object') return
    if (Array.isArray(value)) {
      value.forEach(visit)
      return
    }
    for (const [key, child] of Object.entries(value)) {
      if (key === 'hard_disk_id' || key === 'device_id' || key === 'mac_address') value[key] = ''
      else visit(child)
    }
  }
  visit(parsed)
  return `${JSON.stringify(parsed, null, 2)}\n`
}

export const createOfflineWriterPatches = ({ builder, materialBuilder, resourceUtils, textTemplateAdapter, stickerBuilder, baseVisible }) => {
  let patchedBuilder = replaceExactlyOnce(builder, /import com\.duoec\.video\.jy\.service\.StorageService;\r?\n/u, '', 'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')
  patchedBuilder = replaceExactlyOnce(patchedBuilder, /\s*public static StorageService storageService;\r?\n/u, '\n', 'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')

  let patchedMaterialBuilder = replaceExactlyOnce(materialBuilder, /^        Long taskId = state\.getVideoProject\(\)\.getId\(\);\r?$/mu, '', 'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')
  patchedMaterialBuilder = replaceExactlyOnce(patchedMaterialBuilder, /^        JianyingBuilder\.storageService\.waitAsyncDownloadTask\(taskId\);\r?$/mu, '', 'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')
  patchedMaterialBuilder = replaceExactlyOnce(
    patchedMaterialBuilder,
    /    private static void downloadMaterials\([\s\S]*?\n    private static void addJianYingLocal/u,
    `    private static void downloadMaterials(JianyingProjectBuildState state, Long materialId, Map<Long, File> materialFileMap) {\n        BaseMaterial material = state.getMaterial(materialId);\n        if (material == null) {\n            return;\n        }\n        File file = material.getLocalFile();\n        if (file == null || !file.isFile()) {\n            throw new DuoServiceException("OpenVideo offline Writer requires a prepared local material");\n        }\n        materialFileMap.put(material.getId(), file);\n        if (material instanceof VideoMaterial videoMaterial) {\n            BaseVisibleMediaMaterial.GreenScreen background = videoMaterial.getGreenScreen();\n            if (background != null && background.getMediaId() != null) {\n                downloadMaterials(state, background.getMediaId(), materialFileMap);\n            }\n        }\n    }\n\n    private static void addJianYingLocal`,
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )

  patchedMaterialBuilder = replaceExactlyOnce(
    patchedMaterialBuilder,
    /        File file = material\.getLocalFile\(\);\r?\n        if \(file == null \|\| !file\.isFile\(\)\) \{/u,
    `        // Text and packaging materials are fully described by their resource binding;\n        // only media/audio segments need a prepared local file for offline publication.\n        if (!(material instanceof BaseVisibleMediaMaterial) && !(material instanceof AudioMaterial)) {\n            return;\n        }\n        File file = material.getLocalFile();\n        if (file == null || !file.isFile()) {`,
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )

  let patchedResourceUtils = resourceUtils
  for (const importPattern of [
    /import com\.duoec\.base\.core\.util\.JsonUtils;\r?\n/u,
    /import com\.duoec\.base\.dto\.response\.BaseResponse;\r?\n/u,
    /import com\.duoec\.video\.jy\.JianyingBuilder;\r?\n/u,
    /import com\.duoec\.video\.utils\.ZipUtils;\r?\n/u,
    /import com\.fasterxml\.jackson\.core\.type\.TypeReference;\r?\n/u,
    /import java\.nio\.charset\.StandardCharsets;\r?\n/u,
    /import java\.util\.Arrays;\r?\n/u,
  ]) patchedResourceUtils = replaceExactlyOnce(patchedResourceUtils, importPattern, '', 'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')
  patchedResourceUtils = replaceExactlyOnce(patchedResourceUtils, /\s*public static final String BASE_JY_RESOURCE_URL = "[^"]+";\r?\n/u, '\n', 'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')
  patchedResourceUtils = replaceExactlyOnce(
    patchedResourceUtils,
    /\s*if \(!jyResourceFontFile\.exists\(\)\) \{[\s\S]*?\r?\n        \}\r?\n        return jyResourceFontFile;/u,
    `\n        if (!jyResourceFontFile.isFile()) {\n            throw new DuoServiceException("OpenVideo offline Writer font payload is unavailable");\n        }\n        return jyResourceFontFile;`,
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )
  patchedResourceUtils = replaceExactlyOnce(
    patchedResourceUtils,
    /    public static JyResource getJyResource\([\s\S]*?\n    public static void downloadResources/u,
    `    public static JyResource getJyResource(String resourceType, long resourceId) {\n        requireSafeSegment(resourceType);\n        String rid = resourceType + DuoServerConsts.OBLIQUE_LINE_STR + resourceId + STR_JSON;\n        File resourceConfigFile = new File(JY_RS_DIR, rid);\n        if (!resourceConfigFile.isFile()) {\n            throw new DuoServiceException("OpenVideo offline Writer resource binding is unavailable");\n        }\n        return FileUtils.readJson(resourceConfigFile, JyResource.class);\n    }\n\n    private static String requireSafeSegment(String value) {\n        if (!StringUtils.hasLength(value) || ".".equals(value) || "..".equals(value) ||\n                value.contains("/") || value.contains("\\\\")) {\n            throw new DuoServiceException("OpenVideo offline Writer resource path is invalid");\n        }\n        return value;\n    }\n\n    public static void downloadResources`,
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )
  patchedResourceUtils = replaceExactlyOnce(
    patchedResourceUtils,
    /            String type = items\[items\.length - 2\];[\s\S]*?            if \(resourceUrl\.toLowerCase\(\)\.endsWith\(STR_ZIP\)\) \{[\s\S]*?            \} else \{\r?\n                String fileSuffix/u,
    `            if (items.length < 2) {\n                throw new DuoServiceException("OpenVideo offline Writer resource binding is invalid");\n            }\n            String type = requireSafeSegment(items[items.length - 2]);\n            String fileName = requireSafeSegment(items[items.length - 1]);\n            if (fileName.toLowerCase().endsWith(STR_ZIP)) {\n                throw new DuoServiceException("OpenVideo offline Writer requires pre-extracted resource payloads");\n            }\n            File resourceDir = new File(JY_RS_DIR, type);\n            File resourceFile = new File(resourceDir, fileName);\n            if (!resourceFile.isFile()) {\n                throw new DuoServiceException("OpenVideo offline Writer resource payload is unavailable");\n            }\n            {\n                String fileSuffix`,
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )

  let patchedTextTemplateAdapter = replaceExactlyOnce(
    textTemplateAdapter,
    /\s*String downloadUrl = JianyingResourceUtils\.BASE_JY_RESOURCE_URL \+ programName;[\s\S]*?\r?\n            \}\r?\n\r?\n            \/\/ 对于 Unix 系统/u,
    `\n            if (!targetFile.isFile()) {\n                throw new DuoServiceException("OpenVideo offline Writer text-template adapter is unavailable");\n            }\n\n            // 对于 Unix 系统`,
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )
  patchedTextTemplateAdapter = patchedTextTemplateAdapter.replace('logger.info("jy_text_template_adapter 下载成功: {}", targetFile.getAbsolutePath());', 'logger.info("jy_text_template_adapter is available");')

  const patchedStickerBuilder = replaceExactlyOnce(
    stickerBuilder,
    /\.setIconUrl\(JianyingResourceUtils\.BASE_JY_RESOURCE_URL \+ resource\.getCoverImg\(\)\)\s*\.setPreviewCoverUrl\(JianyingResourceUtils\.BASE_JY_RESOURCE_URL \+ resource\.getCoverImg\(\)\)/u,
    '.setIconUrl("")\n                .setPreviewCoverUrl("")',
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )

  const patchedBaseVisible = replaceExactlyOnce(
    baseVisible,
    /\s*if \(!lutFile\.exists\(\)\) \{\s*JianyingBuilder\.storageService\.download\(lutUrl, lutFile\);\s*\}/u,
    '',
    'JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID',
  )
  const combined = [patchedBuilder, patchedMaterialBuilder, patchedResourceUtils, patchedTextTemplateAdapter, patchedStickerBuilder, patchedBaseVisible].join('\n')
  if (/https?:\/\/|api\.duoec\.com|storageService|DuoApiUtils|BASE_JY_RESOURCE_URL/u.test(combined)) {
    throw new Error('JY200_DUO_RUNTIME_OFFLINE_PATCH_INVALID')
  }
  return Object.freeze({ patchedBuilder, patchedMaterialBuilder, patchedResourceUtils, patchedTextTemplateAdapter, patchedStickerBuilder, patchedBaseVisible })
}

export const parseMavenDependencyList = (source) => {
  const dependencies = source
    .split(/\r?\n/u)
    .map((line) => line.trim().replace(/^\[INFO\]\s+/u, ''))
    .map((line) => line.replace(/\s+--\s+module\s+.*$/u, ''))
    .filter((line) => /^[\w.-]+:[\w.-]+:[\w.-]+(?::[\w.-]+)?:[\w.+-]+:(?:compile|runtime)$/u.test(line))
    .map((line) => {
    const fields = line.split(':')
    const hasClassifier = fields.length === 6
    return Object.freeze({
      group: fields[0],
      artifact: fields[1],
      type: fields[2],
      ...(hasClassifier ? { classifier: fields[3] } : {}),
      version: fields[hasClassifier ? 4 : 3],
      scope: fields[hasClassifier ? 5 : 4],
    })
    })
  const unique = new Map(dependencies.map((dependency) => [
    `${dependency.group}:${dependency.artifact}:${dependency.type}:${dependency.classifier ?? ''}:${dependency.version}:${dependency.scope}`,
    dependency,
  ]))
  return Object.freeze([...unique.values()]
    .sort((left, right) => `${left.group}:${left.artifact}:${left.version}`.localeCompare(`${right.group}:${right.artifact}:${right.version}`)))
}

const noticeEntryFor = (dependency, noticeInventory) => noticeInventory.find((entry) =>
  (entry.group === dependency.group || (entry.group_prefix &&
    (dependency.group === entry.group_prefix || dependency.group.startsWith(`${entry.group_prefix}.`)))) &&
  (!entry.artifacts || entry.artifacts.includes(dependency.artifact)) &&
  typeof entry.license === 'string' && entry.license.length > 0)

export const validateRuntimeDependencies = ({ dependencies, noticeInventory }) => {
  if (dependencies.length === 0) throw new Error('JY200_DUO_RUNTIME_DEPENDENCIES_EMPTY')
  for (const dependency of dependencies) {
    const identity = `${dependency.group}:${dependency.artifact}`.toLowerCase()
    if (testArtifactPattern.test(identity)) throw new Error('JY200_DUO_RUNTIME_TEST_STACK_PRESENT')
    if (dependency.group === 'com.duoec.video' && !allowedModules.includes(dependency.artifact)) {
      throw new Error('JY200_DUO_RUNTIME_MODULE_NOT_ALLOWED')
    }
    if (!noticeEntryFor(dependency, noticeInventory)) {
      const error = new Error('JY200_DUO_RUNTIME_NOTICE_INCOMPLETE')
      Object.defineProperty(error, 'dependency', { value: identity, enumerable: false })
      throw error
    }
  }
  return true
}

const dependencyRelativePath = (dependency) => {
  if (dependency.type !== 'jar') throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_TYPE_UNSUPPORTED')
  const artifact = assertSafeSegment(dependency.artifact)
  const version = assertSafeSegment(dependency.version)
  const classifier = dependency.classifier ? `-${assertSafeSegment(dependency.classifier)}` : ''
  return `${artifact}-${version}${classifier}.jar`
}

const fileIdentity = (metadata) => Object.freeze({
  dev: metadata.dev.toString(),
  ino: metadata.ino.toString(),
  size: metadata.size.toString(),
  mtime_ns: metadata.mtimeNs.toString(),
  birthtime_ns: metadata.birthtimeNs.toString(),
})

const readOwnedFile = async ({ ownedRoot, candidate }) => {
  const resolvedRoot = path.resolve(ownedRoot)
  const resolved = path.resolve(candidate)
  if (!inside(resolvedRoot, resolved)) throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_PATH_UNSAFE')
  const [rootMetadata, canonicalRoot, pathMetadata, actual] = await Promise.all([
    lstat(resolvedRoot, { bigint: true }), realpath(resolvedRoot),
    lstat(resolved, { bigint: true }), realpath(resolved),
  ])
  if (!rootMetadata.isDirectory() || rootMetadata.isSymbolicLink() ||
      !await sameResolvedObject(resolvedRoot, canonicalRoot, rootMetadata) ||
      !pathMetadata.isFile() || pathMetadata.isSymbolicLink() ||
      !await sameResolvedObject(resolved, actual, pathMetadata) || !inside(canonicalRoot, actual)) {
    throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_PATH_UNSAFE')
  }
  const handle = await open(resolved, 'r')
  try {
    const before = await handle.stat({ bigint: true })
    const bytes = await handle.readFile()
    const [after, currentPath, currentActual] = await Promise.all([
      handle.stat({ bigint: true }), lstat(resolved, { bigint: true }), realpath(resolved),
    ])
    const expected = fileIdentity(before)
    if (JSON.stringify(fileIdentity(after)) !== JSON.stringify(expected) ||
        JSON.stringify(fileIdentity(currentPath)) !== JSON.stringify(expected) ||
        !await sameResolvedObject(resolved, currentActual, currentPath) || !inside(canonicalRoot, currentActual)) {
      throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_REPLACED')
    }
    return bytes
  } finally {
    await handle.close()
  }
}

const listFiles = async (root) => {
  const files = []
  const visit = async (candidate) => {
    for (const entry of await readdir(candidate, { withFileTypes: true })) {
      const child = path.join(candidate, entry.name)
      if (entry.isSymbolicLink()) throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_PATH_UNSAFE')
      if (entry.isDirectory()) await visit(child)
      else if (entry.isFile()) files.push(child)
      else throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_PATH_UNSAFE')
    }
  }
  await visit(root)
  return files
}

export const inspectExternalDependencyInventory = async ({ dependencyRoot, dependencies }) => {
  const external = dependencies.filter((dependency) => dependency.group !== 'com.duoec.video')
  const expectedRelativePaths = external.map(dependencyRelativePath)
  if (new Set(expectedRelativePaths).size !== expectedRelativePaths.length) {
    throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_SET_INVALID')
  }
  const actualFiles = await listFiles(dependencyRoot)
  const actualRelativePaths = actualFiles.map((file) => path.relative(dependencyRoot, file)).sort()
  if (JSON.stringify([...expectedRelativePaths].sort()) !== JSON.stringify(actualRelativePaths)) {
    const error = new Error('JY200_DUO_RUNTIME_DEPENDENCY_SET_INVALID')
    Object.defineProperty(error, 'actual', {
      value: Object.freeze({ expected: [...expectedRelativePaths].sort(), actual: actualRelativePaths }),
      enumerable: false,
    })
    throw error
  }
  const entries = await Promise.all(external.map(async (dependency) => {
    const relativeFile = dependencyRelativePath(dependency)
    const bytes = await readOwnedFile({ ownedRoot: dependencyRoot, candidate: path.join(dependencyRoot, relativeFile) })
    return Object.freeze({
      group: dependency.group,
      artifact: dependency.artifact,
      type: dependency.type,
      ...(dependency.classifier ? { classifier: dependency.classifier } : {}),
      version: dependency.version,
      file: relativeFile.replaceAll('\\', '/'),
      size: bytes.byteLength,
      sha256: sha256(bytes),
    })
  }))
  entries.sort((left, right) => left.file.localeCompare(right.file))
  const frozenEntries = Object.freeze(entries)
  return Object.freeze({
    count: frozenEntries.length,
    entries: frozenEntries,
    fingerprint: canonicalManifestFingerprint(frozenEntries),
  })
}

export const validateLockedRuntimeBuild = ({ dependencyInventory, artifacts, manifestFingerprint, expected }) => {
  const actual = Object.freeze({
    external_runtime_dependency_count: dependencyInventory.count,
    external_dependency_inventory_fingerprint: dependencyInventory.fingerprint,
    external_dependencies: dependencyInventory.entries,
    artifacts,
    manifest_fingerprint: manifestFingerprint,
  })
  const matches = expected &&
    expected.external_runtime_dependency_count === actual.external_runtime_dependency_count &&
    expected.external_dependency_inventory_fingerprint === actual.external_dependency_inventory_fingerprint &&
    (!expected.external_dependencies ||
      JSON.stringify(expected.external_dependencies) === JSON.stringify(actual.external_dependencies)) &&
    JSON.stringify(expected.artifacts) === JSON.stringify(actual.artifacts) &&
    expected.manifest_fingerprint === actual.manifest_fingerprint
  if (!matches) {
    const error = new Error('JY200_DUO_RUNTIME_LOCK_MISMATCH')
    Object.defineProperty(error, 'actual', { value: actual, enumerable: false })
    throw error
  }
  return true
}

export const validateInstalledDuoWriterRuntime = async ({ runtimeRoot, manifest }) => {
  const receiptPath = path.join(runtimeRoot, 'openvideo-duo-writer-runtime.json')
  const receiptBytes = await readOwnedFile({ ownedRoot: runtimeRoot, candidate: receiptPath })
  const receipt = JSON.parse(receiptBytes.toString('utf8'))
  const expected = manifest?.writer_only_runtime?.verified_build
  const { manifest_fingerprint: recordedFingerprint, ...unsignedReceipt } = receipt ?? {}
  if (!expected || receipt?.provider !== 'duo-video' || receipt.provider_commit !== manifest.commit ||
      receipt.admission !== 'deferred' || receipt.writer_eligible !== false || receipt.catalog_bound !== false ||
      recordedFingerprint !== canonicalManifestFingerprint(unsignedReceipt) ||
      recordedFingerprint !== expected.manifest_fingerprint ||
      !Array.isArray(receipt.runtime_dependencies) || !receipt.external_dependency_inventory) {
    throw new Error('JY200_DUO_RUNTIME_IDENTITY_INVALID')
  }
  const artifacts = await inspectArtifacts(runtimeRoot)
  const dependencyRoot = path.join(runtimeRoot, 'runtime-dependencies')
  const dependencyInventory = await inspectExternalDependencyInventory({
    dependencyRoot,
    dependencies: receipt.runtime_dependencies,
  })
  if (JSON.stringify(receipt.artifacts) !== JSON.stringify(artifacts) ||
      JSON.stringify(receipt.external_dependency_inventory) !== JSON.stringify(dependencyInventory)) {
    throw new Error('JY200_DUO_RUNTIME_IDENTITY_INVALID')
  }
  validateLockedRuntimeBuild({
    dependencyInventory,
    artifacts,
    manifestFingerprint: recordedFingerprint,
    expected,
  })
  return Object.freeze({
    runtimeManifest: Object.freeze(receipt),
    buildDigest: recordedFingerprint,
    classpathEntries: Object.freeze([
      ...artifacts.map((artifact) => path.join(runtimeRoot, artifact.module, 'target', artifact.file)),
      ...dependencyInventory.entries.map((entry) => path.join(dependencyRoot, entry.file)),
    ]),
  })
}

const verifyUpstream = async ({ manifest, upstreamRoot, tree }) => {
  const [{ stdout: head }, { stdout: status }] = await Promise.all([
    execFile('git.exe', ['-C', upstreamRoot, 'rev-parse', 'HEAD'], { timeout: 10_000, windowsHide: true }),
    execFile('git.exe', ['-C', upstreamRoot, 'status', '--porcelain'], { timeout: 10_000, windowsHide: true }),
  ])
  if (head.trim() !== manifest.commit || status.trim() !== '') throw new Error('JY200_DUO_UPSTREAM_IDENTITY_INVALID')
  for (const audit of manifest.audit_files ?? []) {
    const entry = tree.get(audit.path)
    if (!entry) throw new Error('JY200_DUO_UPSTREAM_AUDIT_INVALID')
    const bytes = await readPinnedBlob({ upstreamRoot, entry })
    if (bytes.byteLength !== audit.size || sha256(bytes) !== audit.sha256) throw new Error('JY200_DUO_UPSTREAM_AUDIT_INVALID')
  }
}

const verifyToolchain = async ({ manifest, cwd }) => {
  const expected = manifest.writer_only_runtime?.toolchain
  if (!expected || typeof expected.maven_version !== 'string' || typeof expected.java_version !== 'string' ||
      typeof expected.java_vendor !== 'string') throw new Error('JY200_DUO_RUNTIME_TOOLCHAIN_INVALID')
  const javaHome = process.env.JAVA_HOME
  if (!javaHome) throw new Error('JY200_DUO_RUNTIME_TOOLCHAIN_INVALID')
  const [java, maven] = await Promise.all([
    execFile(path.join(javaHome, 'bin', 'java.exe'), ['-version'], { timeout: 10_000, windowsHide: true }),
    runMaven(['--version'], { cwd, timeout: 10_000 }),
  ])
  const javaVersion = `${java.stdout}\n${java.stderr}`
  const mavenVersion = `${maven.stdout}\n${maven.stderr}`
  if (!javaVersion.includes(expected.java_version) || !javaVersion.includes(expected.java_vendor) ||
      !mavenVersion.includes(`Apache Maven ${expected.maven_version}`)) {
    throw new Error('JY200_DUO_RUNTIME_TOOLCHAIN_INVALID')
  }
  return Object.freeze({
    maven_version: expected.maven_version,
    java_version: expected.java_version,
    java_vendor: expected.java_vendor,
  })
}

const inspectArtifacts = async (stagingRoot) => {
  const artifacts = []
  for (const module of allowedModules) {
    const target = path.join(stagingRoot, module, 'target')
    for (const entry of await readdir(target, { withFileTypes: true })) {
      if (!entry.isFile() || !entry.name.endsWith('.jar') || entry.name.startsWith('original-')) continue
      const bytes = await readOwnedFile({ ownedRoot: stagingRoot, candidate: path.join(target, entry.name) })
      artifacts.push(Object.freeze({ module, file: entry.name, size: bytes.byteLength, sha256: sha256(bytes) }))
    }
  }
  if (artifacts.length !== allowedModules.length) throw new Error('JY200_DUO_RUNTIME_ARTIFACT_SET_INVALID')
  return Object.freeze(artifacts.sort((left, right) => left.module.localeCompare(right.module)))
}

const copyExternalRuntimeDependencies = async ({ stagingRoot, dependencies }) => {
  const dependencyRoot = path.join(stagingRoot, 'runtime-dependencies')
  await mkdir(dependencyRoot, { mode: 0o700 })
  await runMaven([
    '-B', '-o', '-Pdev', '-pl', 'duo-video-jy', '-am',
    'dependency:copy-dependencies', '-DincludeScope=runtime',
    '-DexcludeGroupIds=com.duoec.video',
    `-DoutputDirectory=${dependencyRoot}`,
  ], {
    cwd: stagingRoot,
    timeout: 120_000,
  })
  await assertNoReparseDescendants({ runtimeRoot: stagingRoot, stagingRoot: dependencyRoot })
  return inspectExternalDependencyInventory({ dependencyRoot, dependencies })
}

const verifyOfflineWriterArtifacts = async ({ stagingRoot, artifacts }) => {
  const jarTool = path.join(process.env.JAVA_HOME ?? '', 'bin', 'jar.exe')
  const inspectionRoot = path.join(stagingRoot, 'jar-inspection')
  await mkdir(inspectionRoot, { mode: 0o700 })
  const forbidden = [
    'DuoApiUtils', 'StorageServiceImpl', 'api.duoec.com',
    'DUO_API_KEY', 'DUO_SECRET_KEY', 'DUO_SERVER', 'BASE_JY_RESOURCE_URL',
  ].map((value) => Buffer.from(value))
  for (const artifact of artifacts) {
    const jarPath = path.join(stagingRoot, artifact.module, 'target', artifact.file)
    const { stdout } = await execFile(jarTool, ['tf', jarPath], {
      timeout: 30_000, windowsHide: true, maxBuffer: 16 * 1024 * 1024,
    })
    const entries = stdout.split(/\r?\n/u).filter(Boolean)
    if (entries.some((entry) => /(?:^|\/)DuoApiUtils\.class$|(?:^|\/)StorageServiceImpl\.class$/u.test(entry))) {
      throw new Error('JY200_DUO_RUNTIME_REMOTE_CODE_PRESENT')
    }
    for (const entry of entries) {
      const normalized = entry.replaceAll('/', path.sep)
      if (path.isAbsolute(normalized) || normalized.split(path.sep).some((segment) => segment === '..')) {
        throw new Error('JY200_DUO_RUNTIME_ARTIFACT_SET_INVALID')
      }
    }
    const artifactInspectionRoot = path.join(inspectionRoot, artifact.module)
    await mkdir(artifactInspectionRoot, { mode: 0o700 })
    await execFile(jarTool, ['xf', jarPath], {
      cwd: artifactInspectionRoot, timeout: 30_000, windowsHide: true, maxBuffer: 16 * 1024 * 1024,
    })
    await assertNoReparseDescendants({ runtimeRoot: stagingRoot, stagingRoot: artifactInspectionRoot })
    for (const file of await listFiles(artifactInspectionRoot)) {
      const bytes = await readOwnedFile({ ownedRoot: artifactInspectionRoot, candidate: file })
      if (forbidden.some((token) => bytes.includes(token))) {
        throw new Error('JY200_DUO_RUNTIME_REMOTE_CODE_PRESENT')
      }
    }
  }
  return true
}

const canonicalManifestFingerprint = (manifest) => sha256(Buffer.from(JSON.stringify(manifest)))

const collectStableRuntimeBytes = async ({ stagingRoot, artifacts, dependencyInventory, manifestPath }) => {
  await assertNoReparseDescendants({ runtimeRoot: stagingRoot, stagingRoot })
  const stableArtifacts = await Promise.all(artifacts.map(async (artifact) => {
    const bytes = await readOwnedFile({ ownedRoot: stagingRoot, candidate: path.join(stagingRoot, artifact.module, 'target', artifact.file) })
    return Object.freeze({ ...artifact, size: bytes.byteLength, sha256: sha256(bytes) })
  }))
  const stableDependencies = await Promise.all(dependencyInventory.entries.map(async (entry) => {
    const bytes = await readOwnedFile({ ownedRoot: path.join(stagingRoot, 'runtime-dependencies'), candidate: path.join(stagingRoot, 'runtime-dependencies', entry.file) })
    return Object.freeze({ ...entry, size: bytes.byteLength, sha256: sha256(bytes) })
  }))
  stableDependencies.sort((left, right) => left.file.localeCompare(right.file))
  const stableInventory = Object.freeze({
    count: stableDependencies.length,
    entries: Object.freeze(stableDependencies),
    fingerprint: canonicalManifestFingerprint(stableDependencies),
  })
  if (stableInventory.fingerprint !== dependencyInventory.fingerprint ||
      JSON.stringify(stableInventory.entries) !== JSON.stringify(dependencyInventory.entries)) {
    throw new Error('JY200_DUO_RUNTIME_DEPENDENCY_REPLACED')
  }
  const manifestBytes = await readOwnedFile({ ownedRoot: stagingRoot, candidate: manifestPath })
  return Object.freeze({ artifacts: Object.freeze(stableArtifacts), dependencyInventory: stableInventory, manifestBytes })
}

export const createPublicRuntimeSummary = (manifest) => Object.freeze({
  ok: true,
  provider: manifest.provider,
  providerCommit: manifest.provider_commit,
  moduleCount: manifest.modules.length,
  runtimeDependencyCount: manifest.runtime_dependencies.length,
  artifactCount: manifest.artifacts.length,
  testStackPresent: false,
  manifestFingerprint: manifest.manifest_fingerprint,
  admission: 'deferred',
  writerEligible: false,
  catalogBound: false,
})

export const buildJY200DuoWriterRuntime = async ({ root = repositoryRoot, runtimeDataRoot, outputParent } = {}) => {
  const manifest = JSON.parse(await readFile(path.join(root, 'config', 'duo-video-upstream.json'), 'utf8'))
  const upstreamRoot = path.join(root, 'upstream', 'duo-video')
  const runtimeConfig = manifest.writer_only_runtime
  if (!runtimeConfig || JSON.stringify(runtimeConfig.modules) !== JSON.stringify(allowedModules) ||
      JSON.stringify(runtimeConfig.excluded_components) !== JSON.stringify(excludedComponents) ||
      !runtimeDataRoot || !outputParent) {
    throw new Error('JY200_DUO_RUNTIME_BOUNDARY_INVALID')
  }
  const pinnedTree = await loadPinnedTree({ upstreamRoot, commit: manifest.commit })
  await verifyUpstream({ manifest, upstreamRoot, tree: pinnedTree })
  const toolchain = await verifyToolchain({ manifest, cwd: root })

  const lease = await createOwnedRuntimeStaging({ runtimeRoot: runtimeDataRoot, outputParent })
  const { stagingRoot } = lease
  try {
    await assertOwnedRuntimeStagingCurrent(lease)
    await exportPinnedModules({ upstreamRoot, commit: manifest.commit, stagingRoot })
    const readPinnedText = async (file) => {
      const entry = pinnedTree.get(file)
      if (!entry) throw new Error('JY200_DUO_RUNTIME_GIT_TREE_INVALID')
      return (await readPinnedBlob({ upstreamRoot, entry })).toString('utf8')
    }
    const sourceRootPom = await readPinnedText('pom.xml')
    const sourceBasePom = await readPinnedText('duo-video-base/pom.xml')
    const sourceWriterPom = await readPinnedText('duo-video-jy/pom.xml')
    const { patchedRootPom, patchedBasePom, patchedWriterPom } = createWriterOnlyPoms({
      rootPom: sourceRootPom,
      basePom: sourceBasePom,
      writerPom: sourceWriterPom,
    })
    await writeFile(path.join(stagingRoot, 'pom.xml'), patchedRootPom, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await writeFile(path.join(stagingRoot, 'duo-video-base', 'pom.xml'), patchedBasePom, { encoding: 'utf8', mode: 0o600 })
    await writeFile(path.join(stagingRoot, 'duo-video-jy', 'pom.xml'), patchedWriterPom, { encoding: 'utf8', mode: 0o600 })

    const patchIdentity = Object.freeze({
      root_source_sha256: sha256(Buffer.from(sourceRootPom)),
      root_patched_sha256: sha256(Buffer.from(patchedRootPom)),
      base_source_sha256: sha256(Buffer.from(sourceBasePom)),
      base_patched_sha256: sha256(Buffer.from(patchedBasePom)),
      writer_source_sha256: sha256(Buffer.from(sourceWriterPom)),
      writer_patched_sha256: sha256(Buffer.from(patchedWriterPom)),
    })
    const expectedPatch = manifest.writer_only_runtime?.staging_patch
    if (!expectedPatch || Object.entries(patchIdentity).some(([key, value]) => expectedPatch[key] !== value)) {
      throw new Error('JY200_DUO_RUNTIME_PATCH_IDENTITY_INVALID')
    }

    const sourcePatchFiles = Object.freeze({
      base_visible: 'duo-video-jy/src/main/java/com/duoec/video/jy/builder/segment/BaseVisibleMediaMaterialBuilder.java',
      video_segment: 'duo-video-jy/src/main/java/com/duoec/video/jy/builder/segment/VideoSegmentBuilder.java',
      utils: 'duo-video-jy/src/main/java/com/duoec/video/jy/utils/JianyingUtils.java',
      builder: 'duo-video-jy/src/main/java/com/duoec/video/jy/JianyingBuilder.java',
      material_builder: 'duo-video-jy/src/main/java/com/duoec/video/jy/builder/JianyingMaterialBuilder.java',
      resource_utils: 'duo-video-jy/src/main/java/com/duoec/video/jy/utils/JianyingResourceUtils.java',
      text_template_adapter: 'duo-video-jy/src/main/java/com/duoec/video/jy/utils/TextTemplateAdapter.java',
      sticker_builder: 'duo-video-jy/src/main/java/com/duoec/video/jy/builder/segment/StickerSegmentBuilder.java',
      duo_api: 'duo-video-jy/src/main/java/com/duoec/video/jy/utils/DuoApiUtils.java',
      storage_impl: 'duo-video-jy/src/main/java/com/duoec/video/jy/service/impl/StorageServiceImpl.java',
      font_map: 'duo-video-jy/src/main/resources/jy/font.json',
      draft_template: 'duo-video-jy/src/main/resources/tpl/empty_jy_draft.json',
      project_template: 'duo-video-jy/src/main/resources/tpl/empty_jy_project_info.json',
    })
    const sourceValues = Object.fromEntries(await Promise.all(Object.entries(sourcePatchFiles).map(async ([key, file]) => [key, await readPinnedText(file)])))
    const sourcePatches = createWriterSourcePatches({
      baseVisible: sourceValues.base_visible,
      videoSegment: sourceValues.video_segment,
      utils: sourceValues.utils,
    })
    const offlinePatches = createOfflineWriterPatches({
      builder: sourceValues.builder,
      materialBuilder: sourceValues.material_builder,
      resourceUtils: sourceValues.resource_utils,
      textTemplateAdapter: sourceValues.text_template_adapter,
      stickerBuilder: sourceValues.sticker_builder,
      baseVisible: sourcePatches.patchedBaseVisible,
    })
    const patchedValues = Object.freeze({
      base_visible: offlinePatches.patchedBaseVisible,
      video_segment: sourcePatches.patchedVideoSegment,
      utils: sourcePatches.patchedUtils,
      builder: offlinePatches.patchedBuilder,
      material_builder: offlinePatches.patchedMaterialBuilder,
      resource_utils: offlinePatches.patchedResourceUtils,
      text_template_adapter: offlinePatches.patchedTextTemplateAdapter,
      sticker_builder: offlinePatches.patchedStickerBuilder,
      duo_api: '',
      storage_impl: '',
      font_map: '{}\n',
      draft_template: clearDeviceIdentityFields(sourceValues.draft_template),
      project_template: clearDeviceIdentityFields(sourceValues.project_template),
    })
    const sourcePatchIdentity = Object.freeze(Object.fromEntries(Object.keys(sourcePatchFiles).map((key) => [key, Object.freeze({
      source_sha256: sha256(Buffer.from(sourceValues[key])),
      patched_sha256: sha256(Buffer.from(patchedValues[key])),
    })])))
    const expectedSourcePatches = manifest.writer_only_runtime?.source_patches
    if (!expectedSourcePatches || Object.entries(sourcePatchIdentity).some(([key, value]) =>
      expectedSourcePatches[key]?.source_sha256 !== value.source_sha256 ||
      expectedSourcePatches[key]?.patched_sha256 !== value.patched_sha256)) {
      throw new Error('JY200_DUO_RUNTIME_SOURCE_PATCH_IDENTITY_INVALID')
    }
    await Promise.all(Object.entries(sourcePatchFiles).map(([key, file]) =>
      writeFile(path.join(stagingRoot, file), patchedValues[key], { encoding: 'utf8', mode: 0o600 })))

    await assertOwnedRuntimeStagingCurrent(lease)
    await runMaven([
      '-B', '-o', '-Pdev', '-Dmaven.test.skip=true',
      `-Dproject.build.outputTimestamp=${manifest.writer_only_runtime.build_output_timestamp}`,
      'clean', 'package',
    ], {
      cwd: stagingRoot,
      timeout: 180_000,
    })
    const dependencyResult = await runMaven([
      '-B', '-o', '-Pdev', '-pl', 'duo-video-jy', '-am',
      'dependency:list', '-DincludeScope=runtime', '-Dsort=true',
    ], {
      cwd: stagingRoot,
      timeout: 120_000,
    })
    const dependencies = parseMavenDependencyList(dependencyResult.stdout)
    validateRuntimeDependencies({ dependencies, noticeInventory: manifest.writer_only_runtime?.notice_inventory ?? [] })
    const artifacts = await inspectArtifacts(stagingRoot)
    await verifyOfflineWriterArtifacts({ stagingRoot, artifacts })
    const dependencyInventory = await copyExternalRuntimeDependencies({ stagingRoot, dependencies })
    const unsignedManifest = Object.freeze({
      schema_version: 1,
      provider: 'duo-video',
      provider_commit: manifest.commit,
      source_license: manifest.root_license,
      toolchain,
      modules: allowedModules,
      excluded_components: excludedComponents,
      staging_patch: patchIdentity,
      source_patches: sourcePatchIdentity,
      runtime_dependencies: dependencies,
      external_dependency_inventory: dependencyInventory,
      artifacts,
      network_identity_boundary: manifest.network_identity_boundary,
      admission: 'deferred',
      writer_eligible: false,
      catalog_bound: false,
    })
    const manifestFingerprint = canonicalManifestFingerprint(unsignedManifest)
    validateLockedRuntimeBuild({
      dependencyInventory,
      artifacts,
      manifestFingerprint,
      expected: manifest.writer_only_runtime?.verified_build,
    })
    const runtimeManifest = Object.freeze({
      ...unsignedManifest,
      manifest_fingerprint: manifestFingerprint,
    })
    await writeFile(path.join(stagingRoot, 'openvideo-duo-writer-runtime.json'), `${JSON.stringify(runtimeManifest, null, 2)}\n`, {
      encoding: 'utf8', mode: 0o600, flag: 'wx',
    })
    await assertOwnedRuntimeStagingCurrent(lease)
    const stable = await collectStableRuntimeBytes({
      stagingRoot,
      artifacts,
      dependencyInventory,
      manifestPath: path.join(stagingRoot, 'openvideo-duo-writer-runtime.json'),
    })
    if (JSON.stringify(stable.artifacts) !== JSON.stringify(artifacts) ||
        stable.dependencyInventory.fingerprint !== dependencyInventory.fingerprint ||
        sha256(stable.manifestBytes) !== sha256(Buffer.from(`${JSON.stringify(runtimeManifest, null, 2)}\n`))) {
      throw new Error('JY200_DUO_RUNTIME_ARTIFACT_REPLACED')
    }
    return Object.freeze({ stagingRoot, runtimeManifest, publicSummary: createPublicRuntimeSummary(runtimeManifest) })
  } catch (error) {
    await removeOwnedRuntimeStaging(lease).catch(() => {})
    throw error
  }
}

const main = async () => {
  try {
    const runtime = await loadLauncherRuntimeConfig({ repositoryRoot })
    const result = await buildJY200DuoWriterRuntime({
      root: repositoryRoot,
      runtimeDataRoot: runtime.dataRoot,
      outputParent: path.join(runtime.dataRoot, 'providers', 'duo-video', 'audit-staging'),
    })
    process.stdout.write(`${JSON.stringify(result.publicSummary)}\n`)
  } catch (error) {
    const reason = error instanceof Error && /^JY200_[A-Z0-9_]+$/u.test(error.message)
      ? error.message
      : 'JY200_DUO_RUNTIME_BUILD_FAILED'
    process.stdout.write(`${JSON.stringify({ ok: false, admission: 'deferred', writerEligible: false, catalogBound: false, reason })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
