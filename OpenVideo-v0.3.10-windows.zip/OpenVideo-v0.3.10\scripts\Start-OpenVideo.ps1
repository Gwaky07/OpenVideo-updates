[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [string]$ConfigPath = (Join-Path $env:LOCALAPPDATA 'OpenVideo\config.json'),
    [switch]$CheckOnly,
    [switch]$NoBrowser,
    # Primary worktree only: explicitly take over a port owned by another OpenVideo instance.
    [switch]$Replace
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
# Node's bundled CA set can be incomplete on Windows installations.  Use the
# Windows system certificate store so HTTPS update manifests and packages work
# consistently on ordinary user machines.
$env:NODE_USE_SYSTEM_CA = '1'
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
. (Join-Path $PSScriptRoot 'OpenVideo-LauncherPort.ps1')

# PROD-HOTFIX-007: this supervisor runs in a hidden window, so every Write-Host below is invisible to
# the person who double-clicked the launcher. The visible bootstrap window used to print nothing at
# all while waiting, which made a slow launch indistinguishable from a hung one. These phase markers
# are appended to a progress log that Bootstrap-OpenVideo.ps1 tails, so the wait is legible without
# un-hiding the supervisor. The gateway appends its own OPENVIDEO_GATEWAY_PHASE lines to the same file.
$script:LaunchProgressLog = $env:OPENVIDEO_LAUNCH_PROGRESS_LOG
$script:LaunchStopwatch = [Diagnostics.Stopwatch]::StartNew()
$script:LaunchPhaseElapsed = [TimeSpan]::Zero

function Write-OpenVideoLaunchPhase {
    param([Parameter(Mandatory = $true)][string]$Phase)
    $total = $script:LaunchStopwatch.Elapsed
    $phaseSeconds = ($total - $script:LaunchPhaseElapsed).TotalSeconds
    $script:LaunchPhaseElapsed = $total
    $line = (
        'OPENVIDEO_PHASE: {0} took {1:F1}s (total {2:F1}s)' -f
        $Phase, $phaseSeconds, $total.TotalSeconds
    )
    Write-Host $line -ForegroundColor DarkGray
    if ([string]::IsNullOrWhiteSpace($script:LaunchProgressLog)) { return }
    try {
        Add-Content -LiteralPath $script:LaunchProgressLog -Value $line -Encoding UTF8
    } catch {
        # Progress reporting is best effort and must never fail a launch.
    }
}

function Write-OpenVideoLaunchNote {
    param([Parameter(Mandatory = $true)][string]$Message)
    if ([string]::IsNullOrWhiteSpace($script:LaunchProgressLog)) { return }
    try {
        Add-Content -LiteralPath $script:LaunchProgressLog -Value $Message -Encoding UTF8
    } catch {
    }
}

function Update-ProcessPath {
    $pathParts = [System.Collections.Generic.List[string]]::new()
    foreach ($pathValue in @(
        $env:Path,
        [Environment]::GetEnvironmentVariable('Path', 'User'),
        [Environment]::GetEnvironmentVariable('Path', 'Machine')
    )) {
        if ([string]::IsNullOrWhiteSpace($pathValue)) { continue }
        foreach ($part in $pathValue -split ';') {
            if ([string]::IsNullOrWhiteSpace($part)) { continue }
            $trimmed = $part.Trim()
            if ($pathParts -notcontains $trimmed) {
                $pathParts.Add($trimmed)
            }
        }
    }
    $env:Path = $pathParts -join ';'
}

function Set-ExecutableDirectoryOnPath {
    param([string]$Executable)
    if ([string]::IsNullOrWhiteSpace($Executable)) { return }
    $directory = Split-Path -Parent ([IO.Path]::GetFullPath($Executable))
    if ([string]::IsNullOrWhiteSpace($directory)) { return }
    $pathParts = @($directory) + @(
        ($env:Path -split ';') |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and $_.Trim() -ne $directory }
    )
    $env:Path = ($pathParts | Select-Object -Unique) -join ';'
}

function Resolve-NodeExecutable {
    $commandInfo = Get-Command node -ErrorAction SilentlyContinue
    if ($null -ne $commandInfo -and -not [string]::IsNullOrWhiteSpace($commandInfo.Source)) {
        return [IO.Path]::GetFullPath($commandInfo.Source)
    }

    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    $candidateRoots = [System.Collections.Generic.List[string]]::new()
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        $candidateRoots.Add((Join-Path $env:LOCALAPPDATA 'Programs\nodejs'))
    }
    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $candidateRoots.Add((Join-Path $env:ProgramFiles 'nodejs'))
    }
    if (-not [string]::IsNullOrWhiteSpace($programFilesX86)) {
        $candidateRoots.Add((Join-Path $programFilesX86 'nodejs'))
    }
    foreach ($candidateRoot in $candidateRoots) {
        if ([string]::IsNullOrWhiteSpace($candidateRoot)) { continue }
        $candidate = Join-Path $candidateRoot 'node.exe'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [IO.Path]::GetFullPath($candidate)
        }
    }

    return $null
}

function Add-CommandDirectoryToPath {
    param([string]$Name)
    $commandInfo = Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $commandInfo -or [string]::IsNullOrWhiteSpace($commandInfo.Source)) { return }
    Set-ExecutableDirectoryOnPath -Executable $commandInfo.Source
}

function Test-SupportedNodeVersion {
    $nodeExecutable = Resolve-NodeExecutable
    if ([string]::IsNullOrWhiteSpace($nodeExecutable)) { return $false }
    Set-ExecutableDirectoryOnPath -Executable $nodeExecutable
    try {
        $versionText = (& $nodeExecutable --version 2>$null).Trim().TrimStart('v')
        $version = [version]$versionText
        return $version -ge [version]'22.22.0'
    } catch {
        return $false
    }
}

Update-ProcessPath

function Assert-NodeLifecycleAvailable {
    param([string]$Root)
    Add-CommandDirectoryToPath -Name 'node'
    Add-CommandDirectoryToPath -Name 'corepack'
    & corepack pnpm --dir $Root exec node --version *> $null
    if ($LASTEXITCODE -ne 0) {
        throw 'NODE_LIFECYCLE_PATH_UNAVAILABLE: Node.js is installed but unavailable to pnpm package scripts. Close this terminal and restart OpenVideo.'
    }
}

function Write-JsonUtf8 {
    param([string]$Path, [object]$Value)
    New-Item -ItemType Directory -Path (Split-Path $Path -Parent) -Force | Out-Null
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::WriteAllText($Path, (($Value | ConvertTo-Json -Depth 8) + "`n"), $utf8)
}

function Get-OpenVideoDependencyRevision {
    param([Parameter(Mandatory = $true)][string]$Root)
    $normalizedRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $dependencyFiles = @(
        (Join-Path $normalizedRoot 'package.json'),
        (Join-Path $normalizedRoot 'pnpm-lock.yaml'),
        (Join-Path $normalizedRoot 'pnpm-workspace.yaml'),
        (Join-Path $normalizedRoot 'apps\gateway\package.json'),
        (Join-Path $normalizedRoot 'apps\web\package.json')
    )
    $revisionText = ($dependencyFiles | ForEach-Object {
        $relativePath = $_.Substring($normalizedRoot.Length).TrimStart('\').Replace('\', '/')
        "$relativePath|$(Get-OpenVideoFileSha256 -Path $_)"
    }) -join "`n"
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString(
            $hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($revisionText))
        )).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
    }
}

function Test-OpenVideoDependencyReceipt {
    param(
        [string]$Path,
        [string]$DependencyRevision,
        [string]$Root
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $Root 'node_modules\.pnpm') -PathType Container)) {
        return $false
    }
    try {
        $receipt = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        return (
            $receipt.schema_version -eq 1 -and
            [string]$receipt.dependency_revision -eq $DependencyRevision -and
            [string]$receipt.repository_root -eq [IO.Path]::GetFullPath($Root).TrimEnd('\')
        )
    } catch {
        return $false
    }
}

function Write-OpenVideoDependencyReceipt {
    param(
        [string]$Path,
        [string]$DependencyRevision,
        [string]$Root
    )
    $temporaryPath = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        Write-JsonUtf8 -Path $temporaryPath -Value ([ordered]@{
            schema_version = 1
            dependency_revision = $DependencyRevision
            repository_root = [IO.Path]::GetFullPath($Root).TrimEnd('\')
            verified_at = [DateTimeOffset]::UtcNow.ToString('O')
        })
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    } finally {
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
    }
}

function Get-OpenVideoRevisionFromPaths {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][object[]]$Paths,
        [string]$Salt = ''
    )
    $normalizedRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $revisionLines = [System.Collections.Generic.List[string]]::new()
    if (-not [string]::IsNullOrEmpty($Salt)) {
        $revisionLines.Add("salt|$Salt")
    }
    foreach ($path in @($Paths | Sort-Object -Unique)) {
        $fullPath = [IO.Path]::GetFullPath([string]$path)
        $relativePath = $fullPath.Substring($normalizedRoot.Length).TrimStart('\').Replace('\', '/')
        $hash = Get-OpenVideoFileSha256 -Path $fullPath
        $revisionLines.Add("$relativePath|$hash")
    }
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString(
            $hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($revisionLines -join "`n"))
        )).Replace('-', '').ToLowerInvariant()
    } finally {
        $hasher.Dispose()
    }
}

function Get-OpenVideoGatewayBuildRevision {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$DependencyRevision
    )
    $paths = @(
        Get-ChildItem -LiteralPath (Join-Path $Root 'apps\gateway\src') -File -Recurse
        Get-ChildItem -LiteralPath (Join-Path $Root 'apps\gateway\scripts') -File -Recurse
        Get-Item -LiteralPath (Join-Path $Root 'scripts\jy003-real-acceptance.mjs')
    ) | ForEach-Object { $_.FullName }
    return Get-OpenVideoRevisionFromPaths `
        -Root $Root `
        -Paths $paths `
        -Salt "gateway-v1|$DependencyRevision"
}

function Get-OpenVideoWebBuildRevision {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$DependencyRevision
    )
    $paths = @(
        Get-ChildItem -LiteralPath (Join-Path $Root 'apps\web\src') -File -Recurse
        Get-ChildItem -LiteralPath (Join-Path $Root 'apps\web') -File -Filter 'tsconfig*.json'
        Get-ChildItem -LiteralPath $Root -File -Filter 'tsconfig*.json'
        Get-Item -LiteralPath (Join-Path $Root 'apps\web\index.html')
        Get-Item -LiteralPath (Join-Path $Root 'apps\web\vite.config.ts')
    ) | ForEach-Object { $_.FullName }
    return Get-OpenVideoRevisionFromPaths `
        -Root $Root `
        -Paths $paths `
        -Salt "web-v1|$DependencyRevision"
}

function Test-OpenVideoComponentBuildReceipt {
    param(
        [string]$Path,
        [string]$ComponentRevision,
        [string]$Root,
        [string[]]$RequiredPaths = @()
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    foreach ($requiredPath in $RequiredPaths) {
        if (-not (Test-Path -LiteralPath $requiredPath)) { return $false }
    }
    try {
        $receipt = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        return (
            $receipt.schema_version -eq 1 -and
            [string]$receipt.component_revision -eq $ComponentRevision -and
            [string]$receipt.repository_root -eq [IO.Path]::GetFullPath($Root).TrimEnd('\')
        )
    } catch {
        return $false
    }
}

function Write-OpenVideoComponentBuildReceipt {
    param(
        [string]$Path,
        [string]$ComponentRevision,
        [string]$Root
    )
    $temporaryPath = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        Write-JsonUtf8 -Path $temporaryPath -Value ([ordered]@{
            schema_version = 1
            component_revision = $ComponentRevision
            repository_root = [IO.Path]::GetFullPath($Root).TrimEnd('\')
            built_at = [DateTimeOffset]::UtcNow.ToString('O')
        })
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    } finally {
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
    }
}

function Test-OpenVideoBuildReceipt {
    param(
        [string]$Path,
        [string]$ReleaseRevision,
        [string]$Root
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $requiredPaths = @(
        (Join-Path $Root 'node_modules\.pnpm'),
        (Join-Path $Root 'apps\web\dist\index.html')
    )
    foreach ($requiredPath in $requiredPaths) {
        if (-not (Test-Path -LiteralPath $requiredPath)) { return $false }
    }
    try {
        $receipt = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
        return (
            $receipt.schema_version -eq 1 -and
            [string]$receipt.release_revision -eq $ReleaseRevision -and
            [string]$receipt.repository_root -eq [IO.Path]::GetFullPath($Root).TrimEnd('\')
        )
    } catch {
        return $false
    }
}

function Test-OpenVideoDeferredBuildCompletion {
    param(
        [AllowNull()][object]$ExitCode,
        [string]$DependencyReceiptPath,
        [string]$DependencyRevision,
        [string]$GatewayBuildReceiptPath,
        [string]$GatewayBuildRevision,
        [string]$WebBuildReceiptPath,
        [string]$WebBuildRevision,
        [string]$BuildReceiptPath,
        [string]$ReleaseRevision,
        [string]$Root
    )
    if ($null -ne $ExitCode) {
        try {
            if ([int]$ExitCode -ne 0) { return $false }
        } catch {
            return $false
        }
    }
    return (
        (Test-OpenVideoDependencyReceipt `
            -Path $DependencyReceiptPath `
            -DependencyRevision $DependencyRevision `
            -Root $Root) -and
        (Test-OpenVideoComponentBuildReceipt `
            -Path $GatewayBuildReceiptPath `
            -ComponentRevision $GatewayBuildRevision `
            -Root $Root) -and
        (Test-OpenVideoComponentBuildReceipt `
            -Path $WebBuildReceiptPath `
            -ComponentRevision $WebBuildRevision `
            -Root $Root `
            -RequiredPaths @((Join-Path $Root 'apps\web\dist\index.html'))) -and
        (Test-OpenVideoBuildReceipt `
            -Path $BuildReceiptPath `
            -ReleaseRevision $ReleaseRevision `
            -Root $Root)
    )
}

function Write-OpenVideoBuildReceipt {
    param(
        [string]$Path,
        [string]$ReleaseRevision,
        [string]$Root
    )
    $temporaryPath = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        Write-JsonUtf8 -Path $temporaryPath -Value ([ordered]@{
            schema_version = 1
            release_revision = $ReleaseRevision
            repository_root = [IO.Path]::GetFullPath($Root).TrimEnd('\')
            built_at = [DateTimeOffset]::UtcNow.ToString('O')
        })
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    } finally {
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
    }
}

function Read-LauncherInstanceSecret {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    $item = Get-Item -LiteralPath $Path -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'OPENVIDEO_LAUNCHER_SECRET_INVALID'
    }
    $secret = (Get-Content -LiteralPath $Path -Raw).Trim()
    try {
        $bytes = [Convert]::FromBase64String($secret)
    } catch {
        throw 'OPENVIDEO_LAUNCHER_SECRET_INVALID'
    }
    try {
        if ($bytes.Length -ne 32) { throw 'OPENVIDEO_LAUNCHER_SECRET_INVALID' }
    } finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
    return $secret
}

function New-LauncherNonce {
    $bytes = [byte[]]::new(32)
    $random = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $random.GetBytes($bytes)
        return ([BitConverter]::ToString($bytes)).Replace('-', '').ToLowerInvariant()
    } finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
        $random.Dispose()
    }
}

function Get-LauncherProof {
    param([string]$Secret, [string]$Nonce)
    $key = [Convert]::FromBase64String($Secret)
    $hmac = [Security.Cryptography.HMACSHA256]::new($key)
    try {
        return ([BitConverter]::ToString(
            $hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes($Nonce))
        )).Replace('-', '').ToLowerInvariant()
    } finally {
        [Array]::Clear($key, 0, $key.Length)
        $hmac.Dispose()
    }
}

function Get-RunningOpenVideo {
    param([string]$LivenessUrl, [string]$Nonce)
    try {
        $response = Invoke-WebRequest `
            -Uri $LivenessUrl `
            -Headers @{ 'X-OpenVideo-Launcher-Nonce' = $Nonce } `
            -UseBasicParsing `
            -TimeoutSec 2
        $liveness = $response.Content | ConvertFrom-Json
        if (
            $response.StatusCode -eq 200 -and
            $liveness.live -eq $true -and
            $liveness.mode -eq 'production'
        ) {
            $proofHeader = $response.Headers['X-OpenVideo-Launcher-Proof']
            if ($null -eq $proofHeader) {
                $proofHeader = $response.Headers['x-openvideo-launcher-proof']
            }
            if ($proofHeader -is [System.Array]) {
                $proofHeader = $proofHeader | Select-Object -First 1
            }
            return [pscustomobject]@{
                Liveness = $liveness
                Proof = [string]$proofHeader
            }
        }
    } catch {
        return $null
    }
    return $null
}

function Get-OpenVideoEarlyLiveness {
    param([string]$LivenessUrl)
    try {
        $response = Invoke-RestMethod -Uri $LivenessUrl -TimeoutSec 1
        if (
            $response.live -eq $true -and
            $response.mode -eq 'production'
        ) {
            return $response
        }
    } catch {
        # The startup shell may not be listening yet; the authenticated probe below
        # remains the authoritative ownership/readiness check.
    }
    return $null
}

function Stop-OpenVideoLoopbackListener {
    param(
        [Parameter(Mandatory = $true)]
        [int]$Port,
        [Parameter(Mandatory = $true)]
        [int]$ExpectedPid,
        [Parameter(Mandatory = $true)]
        [ValidateSet('same_root', 'other_root', 'openvideo_unknown_root')]
        [string]$ExpectedState,
        [Parameter(Mandatory = $true)]
        [string]$ExpectedClassificationRoot,
        [string]$ExpectedRepositoryRoot,
        [string]$Reason = 'OPENVIDEO_REPLACING_STALE_RELEASE'
    )
    $ownership = Get-OpenVideoPortOwnership -Port $Port -ExpectedRoot $ExpectedClassificationRoot
    $pidOnPort = $ownership.Pid
    if ($null -eq $pidOnPort) {
        Write-Host "$Reason`: No listener remained on 127.0.0.1:$Port." -ForegroundColor Yellow
        return
    }
    $ownershipMatches = $true
    if (-not [string]::IsNullOrWhiteSpace($ExpectedRepositoryRoot)) {
        $ownershipMatches = (
            -not [string]::IsNullOrWhiteSpace([string]$ownership.RepositoryRoot) -and
            ([IO.Path]::GetFullPath([string]$ownership.RepositoryRoot).TrimEnd('\')).Equals(
                [IO.Path]::GetFullPath($ExpectedRepositoryRoot).TrimEnd('\'),
                [StringComparison]::OrdinalIgnoreCase
            )
        )
    }
    if ($pidOnPort -ne $ExpectedPid -or $ownership.State -ne $ExpectedState -or -not $ownershipMatches) {
        throw "OPENVIDEO_LISTENER_CHANGED: Refusing to stop a listener that no longer matches PID $ExpectedPid and ownership $ExpectedState."
    }
    # A source revision is not permission to interrupt in-flight work. Ordinary
    # launcher clicks may reuse a verified instance, never terminate one.
    if (-not $Replace) {
        throw 'OPENVIDEO_RESTART_REQUIRED: A running instance is preserved. Restart explicitly after completing active work.'
    }
    Write-Host "$Reason`: Stopping previous OpenVideo listener PID $pidOnPort..." -ForegroundColor Yellow
    $supervisorStopped = Stop-OpenVideoSupervisorOwner `
        -Ownership $ownership `
        -ExpectedListenerPid $pidOnPort
    if ($supervisorStopped) {
        Write-Host "$Reason`: Stopped the previous OpenVideo supervisor owner." -ForegroundColor Yellow
        # The supervisor has already been authenticated as the listener's parent.
        # Do not spend two seconds waiting for a child that the replacement must
        # terminate anyway; force-stop it now, then verify the port is released.
        Stop-Process -Id $pidOnPort -Force -ErrorAction SilentlyContinue
    }
    if (-not $supervisorStopped) {
        Stop-Process -Id $pidOnPort -Force -ErrorAction SilentlyContinue
    }
    for ($wait = 0; $wait -lt 40; $wait += 1) {
        if (-not (Test-LoopbackPortInUse -Port $Port)) {
            Write-Host "OPENVIDEO_PREVIOUS_INSTANCE_STOPPED: 127.0.0.1:$Port" -ForegroundColor Green
            return
        }
        Start-Sleep -Milliseconds 250
    }
    throw "OPENVIDEO_PREVIOUS_INSTANCE_STOP_TIMEOUT: Unable to free 127.0.0.1:$Port after stopping PID $pidOnPort."
}

function New-FirstRunConfig {
    param([string]$Path, [string]$Root)
    $privateRoot = Join-Path $env:LOCALAPPDATA 'OpenVideo\data'
    $config = [ordered]@{
        schema_version = 1
        runtime_data_root = $privateRoot
        short_video_factory_root = (Join-Path $Root 'upstream\short-video-factory')
        pyjianyingdraft_root = (Join-Path $Root 'upstream\pyJianYingDraft')
        gateway_port = 8787
    }
    $configuredPort = 0
    if (
        -not [string]::IsNullOrWhiteSpace($env:OPENVIDEO_GATEWAY_PORT) -and
        [int]::TryParse([string]$env:OPENVIDEO_GATEWAY_PORT, [ref]$configuredPort) -and
        $configuredPort -ge 1 -and
        $configuredPort -le 65535
    ) {
        $config.gateway_port = $configuredPort
    }
    Write-JsonUtf8 -Path $Path -Value $config
}

function Get-PlainText {
    param([Security.SecureString]$SecureValue)
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    }
}

function Invoke-PythonProbe {
    param(
        [string]$Command,
        [string[]]$Arguments = @(),
        [string]$Code
    )
    try {
        $output = & $Command @Arguments -c $Code 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        $text = (@($output) -join [Environment]::NewLine).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }
        return $text
    } catch {
        return $null
    }
}

function Test-PythonVersionTextSupported {
    param([string]$VersionText)
    try {
        $version = [version]$VersionText
        return $version.Major -eq 3 -and $version.Minor -eq 12
    } catch {
        return $false
    }
}

function Resolve-PythonExecutableFromProbe {
    param(
        [string]$Command,
        [string[]]$Arguments = @()
    )
    $versionText = Invoke-PythonProbe -Command $Command -Arguments $Arguments -Code "import sys; print('.'.join(map(str, sys.version_info[:3])))"
    if (-not (Test-PythonVersionTextSupported -VersionText $versionText)) { return $null }

    $executable = Invoke-PythonProbe -Command $Command -Arguments $Arguments -Code "import sys; print(sys.executable)"
    if ([string]::IsNullOrWhiteSpace($executable)) {
        if ($Arguments.Count -eq 0) {
            $commandInfo = Get-Command $Command -ErrorAction SilentlyContinue
            if ($null -ne $commandInfo) {
                $executable = $commandInfo.Source
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($executable)) { return $null }
    return [IO.Path]::GetFullPath($executable)
}

function Resolve-SupportedPythonExecutable {
    if ($null -ne (Get-Command python -ErrorAction SilentlyContinue)) {
        $python = Resolve-PythonExecutableFromProbe -Command 'python'
        if (-not [string]::IsNullOrWhiteSpace($python)) { return $python }
    }

    if ($null -ne (Get-Command py -ErrorAction SilentlyContinue)) {
        $python = Resolve-PythonExecutableFromProbe -Command 'py' -Arguments @('-3.12')
        if (-not [string]::IsNullOrWhiteSpace($python)) { return $python }
    }

    return $null
}

function Set-SupportedPythonEnvironment {
    param([string]$PythonExecutable)
    if ([string]::IsNullOrWhiteSpace($PythonExecutable)) { return }
    $pythonDirectory = Split-Path -Parent $PythonExecutable
    if (-not [string]::IsNullOrWhiteSpace($pythonDirectory)) {
        $env:Path = (@($pythonDirectory, $env:Path) |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) -join ';'
    }
    $env:OPENVIDEO_JY002_PYTHON_EXECUTABLE = $PythonExecutable
}

function Test-NoReparseAncestors {
    param([string]$Path)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $current = [IO.Path]::GetPathRoot($fullPath)
    foreach ($part in $fullPath.Substring($current.Length).Split('\')) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $current = Join-Path $current $part
        if (-not (Test-Path -LiteralPath $current)) { break }
        $item = Get-Item -LiteralPath $current -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            return $false
        }
    }
    return $true
}

function Test-Upstream {
    param(
        [string]$DisplayName,
        [string]$Root,
        [string]$ManifestPath,
        [System.Collections.Generic.List[string]]$Errors
    )
    if ([string]::IsNullOrWhiteSpace($Root) -or -not (Test-Path -LiteralPath $Root -PathType Container)) {
        $Errors.Add("$DisplayName pinned upstream is missing. See README-WINDOWS.md.")
        return
    }
    try {
        $manifest = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json
        $commit = (& git -C $Root rev-parse HEAD 2>$null).Trim()
        $remote = (& git -C $Root remote get-url origin 2>$null).Trim().TrimEnd('/')
        $status = (& git -C $Root status --porcelain=v1 2>$null) -join ''
        if ($LASTEXITCODE -ne 0 -or $commit -ne $manifest.commit) {
            $Errors.Add("$DisplayName pinned commit does not match.")
        }
        if ($remote -ne ([string]$manifest.repository).TrimEnd('/')) {
            $Errors.Add("$DisplayName repository URL does not match.")
        }
        if (-not [string]::IsNullOrWhiteSpace($status)) {
            $Errors.Add("$DisplayName working tree is not clean.")
        }
    } catch {
        $Errors.Add("$DisplayName integrity check failed.")
    }
}

function Test-MaterialDependencyReceipt {
    param([string]$ReceiptPath, [string]$ManifestPath)
    if (-not (Test-Path -LiteralPath $ReceiptPath -PathType Leaf)) { return $false }
    try {
        $receipt = Get-Content -LiteralPath $ReceiptPath -Raw | ConvertFrom-Json
        $manifestHash = Get-OpenVideoFileSha256 -Path $ManifestPath
        return (
            $receipt.schema_version -eq 1 -and
            $receipt.manifest_sha256 -eq $manifestHash -and
            @($receipt.dependencies).Count -gt 0
        )
    } catch {
        return $false
    }
}

function Test-PrivateRuntimeBoundary {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
    try {
        $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        $allowedSids = @($currentSid, 'S-1-5-18', 'S-1-5-32-544')
        $acl = Get-Acl -LiteralPath $Path
        if (
            -not $acl.AreAccessRulesProtected -or
            $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $currentSid
        ) {
            return $false
        }
        $rules = @($acl.GetAccessRules(
            $true,
            $true,
            [Security.Principal.SecurityIdentifier]
        ))
        if ($rules.Count -ne $allowedSids.Count) { return $false }
        foreach ($rule in $rules) {
            if (
                $rule.IsInherited -or
                $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
                ($rule.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -ne
                    [Security.AccessControl.FileSystemRights]::FullControl -or
                $allowedSids -notcontains $rule.IdentityReference.Value
            ) {
                return $false
            }
        }
        return $true
    } catch {
        return $false
    }
}

function New-SupervisedProcessJob {
    if (-not ('OpenVideo.ProcessJob' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace OpenVideo {
  public sealed class ProcessJob : IDisposable {
    private IntPtr handle;
    private const uint KillOnJobClose = 0x00002000;
    private const uint CreateSuspended = 0x00000004;
    private const uint CreateNoWindow = 0x08000000;
    private const uint GenericWrite = 0x40000000;
    private const uint FileShareRead = 0x00000001;
    private const uint FileShareWrite = 0x00000002;
    private const uint OpenAlways = 4;
    private const uint StartfUseStdHandles = 0x00000100;
    private const int StdInputHandle = -10;

    [StructLayout(LayoutKind.Sequential)]
    private struct BasicLimitInformation {
      public long PerProcessUserTimeLimit;
      public long PerJobUserTimeLimit;
      public uint LimitFlags;
      public UIntPtr MinimumWorkingSetSize;
      public UIntPtr MaximumWorkingSetSize;
      public uint ActiveProcessLimit;
      public UIntPtr Affinity;
      public uint PriorityClass;
      public uint SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IoCounters {
      public ulong ReadOperationCount;
      public ulong WriteOperationCount;
      public ulong OtherOperationCount;
      public ulong ReadTransferCount;
      public ulong WriteTransferCount;
      public ulong OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ExtendedLimitInformation {
      public BasicLimitInformation BasicLimitInformation;
      public IoCounters IoInfo;
      public UIntPtr ProcessMemoryLimit;
      public UIntPtr JobMemoryLimit;
      public UIntPtr PeakProcessMemoryUsed;
      public UIntPtr PeakJobMemoryUsed;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct StartupInfo {
      public int cb;
      public string reserved;
      public string desktop;
      public string title;
      public int x;
      public int y;
      public int xSize;
      public int ySize;
      public int xCountChars;
      public int yCountChars;
      public int fillAttribute;
      public uint flags;
      public short showWindow;
      public short reserved2Length;
      public IntPtr reserved2;
      public IntPtr stdInput;
      public IntPtr stdOutput;
      public IntPtr stdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessInformation {
      public IntPtr process;
      public IntPtr thread;
      public uint processId;
      public uint threadId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SecurityAttributes {
      public int length;
      public IntPtr securityDescriptor;
      [MarshalAs(UnmanagedType.Bool)]
      public bool inheritHandle;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr CreateJobObject(IntPtr attributes, string name);
    [DllImport("kernel32.dll")]
    private static extern bool SetInformationJobObject(
      IntPtr job, int informationClass, IntPtr information, uint length);
    [DllImport("kernel32.dll")]
    private static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CreateProcess(
      string applicationName, StringBuilder commandLine,
      IntPtr processAttributes, IntPtr threadAttributes,
      bool inheritHandles, uint creationFlags, IntPtr environment,
      string currentDirectory, ref StartupInfo startupInfo,
      out ProcessInformation processInformation);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateFile(
      string fileName, uint desiredAccess, uint shareMode,
      ref SecurityAttributes securityAttributes, uint creationDisposition,
      uint flagsAndAttributes, IntPtr templateFile);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetFilePointerEx(
      IntPtr file, long distance, out long newFilePointer, uint moveMethod);
    [DllImport("kernel32.dll")]
    private static extern IntPtr GetStdHandle(int standardHandle);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint ResumeThread(IntPtr thread);
    [DllImport("kernel32.dll")]
    private static extern bool TerminateProcess(IntPtr process, uint exitCode);
    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(IntPtr handle);

    public ProcessJob() {
      handle = CreateJobObject(IntPtr.Zero, null);
      if (handle == IntPtr.Zero) throw new Win32Exception();
      var info = new ExtendedLimitInformation();
      // Fix REL-HOTFIX-LAUNCHER-001: do NOT set KillOnJobClose (0x00002000). The previous
      // behavior caused .cmd-launched launchers to be torn down when the parent cmd
      // exited, leaving the gateway running but the launcher reporting GATEWAY_EXITED.
      info.BasicLimitInformation.LimitFlags = 0;
      int length = Marshal.SizeOf(info);
      IntPtr pointer = Marshal.AllocHGlobal(length);
      try {
        Marshal.StructureToPtr(info, pointer, false);
        if (!SetInformationJobObject(handle, 9, pointer, (uint)length)) {
          throw new Win32Exception();
        }
      } finally {
        Marshal.FreeHGlobal(pointer);
      }
    }

    public Process StartSuspended(
      string applicationName,
      string argument,
      string workingDirectory,
      string stdoutPath,
      string stderrPath
    ) {
      var security = new SecurityAttributes {
        length = Marshal.SizeOf<SecurityAttributes>(),
        inheritHandle = true
      };
      IntPtr stdout = CreateFile(
        stdoutPath, GenericWrite, FileShareRead | FileShareWrite,
        ref security, OpenAlways, 0, IntPtr.Zero);
      if (stdout == new IntPtr(-1)) throw new Win32Exception();
      IntPtr stderr = CreateFile(
        stderrPath, GenericWrite, FileShareRead | FileShareWrite,
        ref security, OpenAlways, 0, IntPtr.Zero);
      if (stderr == new IntPtr(-1)) {
        CloseHandle(stdout);
        throw new Win32Exception();
      }
      ProcessInformation information = new ProcessInformation();
      try {
        long ignored;
        if (!SetFilePointerEx(stdout, 0, out ignored, 2) ||
            !SetFilePointerEx(stderr, 0, out ignored, 2)) {
          throw new Win32Exception();
        }
        var startup = new StartupInfo {
          cb = Marshal.SizeOf<StartupInfo>(),
          flags = StartfUseStdHandles,
          stdInput = GetStdHandle(StdInputHandle),
          stdOutput = stdout,
          stdError = stderr
        };
        var commandLine = new StringBuilder(
          "\"" + applicationName + "\" \"" + argument.Replace("\"", "\\\"") + "\"");
        if (!CreateProcess(
          applicationName, commandLine, IntPtr.Zero, IntPtr.Zero, true,
          CreateSuspended | CreateNoWindow, IntPtr.Zero, workingDirectory,
          ref startup, out information)) {
          throw new Win32Exception();
        }
        try {
          if (!AssignProcessToJobObject(handle, information.process)) {
            throw new Win32Exception();
          }
          if (ResumeThread(information.thread) == UInt32.MaxValue) {
            throw new Win32Exception();
          }
          return Process.GetProcessById((int)information.processId);
        } catch {
          TerminateProcess(information.process, 1);
          throw;
        } finally {
          if (information.thread != IntPtr.Zero) CloseHandle(information.thread);
          if (information.process != IntPtr.Zero) CloseHandle(information.process);
        }
      } finally {
        CloseHandle(stdout);
        CloseHandle(stderr);
      }
    }

    public void Dispose() {
      if (handle != IntPtr.Zero) {
        CloseHandle(handle);
        handle = IntPtr.Zero;
      }
    }
  }
}
'@
    }
    return [OpenVideo.ProcessJob]::new()
}

$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
$resolvedConfigPath = [IO.Path]::GetFullPath($ConfigPath)
$localAppDataRoot = [IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd('\')
$privateConfigRoot = [IO.Path]::GetDirectoryName($resolvedConfigPath).TrimEnd('\')
$repositoryBoundary = $resolvedRoot.TrimEnd('\')
if (
    -not $resolvedConfigPath.StartsWith($localAppDataRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or
    $resolvedConfigPath.Equals($repositoryBoundary, [StringComparison]::OrdinalIgnoreCase) -or
    $resolvedConfigPath.StartsWith($repositoryBoundary + '\', [StringComparison]::OrdinalIgnoreCase) -or
    -not (Test-NoReparseAncestors -Path $resolvedConfigPath) -or
    (
        (Test-Path -LiteralPath $resolvedConfigPath) -and
        ((Get-Item -LiteralPath $resolvedConfigPath -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
    )
) {
    throw 'PRIVATE_CONFIG_PATH_UNSAFE: Config must stay in the current user local app-data boundary.'
}
if (-not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'package.json') -PathType Leaf)) {
    throw 'INVALID_OPENVIDEO_RELEASE_ROOT'
}
if (-not (Test-Path -LiteralPath $resolvedConfigPath -PathType Leaf)) {
    New-FirstRunConfig -Path $resolvedConfigPath -Root $resolvedRoot
    Write-Host 'OPENVIDEO_INITIAL_CONFIG_READY: LLM settings can be completed in the local workbench.' -ForegroundColor Green
}

try {
    $config = Get-Content -LiteralPath $resolvedConfigPath -Raw | ConvertFrom-Json
    if ($config.schema_version -ne 1) { throw 'invalid schema' }
} catch {
    $configBackupPath = "$resolvedConfigPath.bak"
    try {
        $backupText = Get-Content -LiteralPath $configBackupPath -Raw
        $config = $backupText | ConvertFrom-Json
        if ($config.schema_version -ne 1) { throw 'invalid backup schema' }
        $recoveryPath = "$resolvedConfigPath.recovery"
        [IO.File]::WriteAllText($recoveryPath, $backupText, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $recoveryPath -Destination $resolvedConfigPath -Force
    } catch {
        throw 'PRIVATE_CONFIG_CORRUPT: Primary and backup configuration are invalid.'
    }
}
$errors = [System.Collections.Generic.List[string]]::new()
$allowedConfigKeys = @(
    'schema_version', 'runtime_data_root', 'llm_revision', 'llm_api_key_dpapi', 'llm_provider', 'llm_base_url',
    'llm_text_model', 'llm_vision_model', 'llm_json_model',
    'short_video_factory_root', 'pyjianyingdraft_root', 'gateway_port',
    'voice', 'voice_rate', 'bgm_path'
)
foreach ($property in $config.PSObject.Properties.Name) {
    if ($allowedConfigKeys -notcontains $property) {
        $errors.Add("CONFIG_FIELD_NOT_ALLOWED: $property. Secrets must not be stored in config.json.")
    }
}
if ($config.schema_version -ne 1) { $errors.Add('CONFIG_SCHEMA_INVALID') }

$runtimeRoot = $resolvedRoot
$runtimeNeedsClaim = $false
if (-not (Test-SupportedNodeVersion)) {
    $errors.Add('NODE_NOT_FOUND: Install Node.js 22.22.0 or newer.')
}
try {
    Add-CommandDirectoryToPath -Name 'corepack'
    & corepack --version *> $null
    if ($LASTEXITCODE -ne 0) { $errors.Add('COREPACK_UNAVAILABLE') }
} catch {
    $errors.Add('COREPACK_UNAVAILABLE')
}
try {
    $supportedPythonExecutable = Resolve-SupportedPythonExecutable
    if ([string]::IsNullOrWhiteSpace($supportedPythonExecutable)) {
        $errors.Add('PYTHON_UNAVAILABLE: Python 3.12 is required; the launcher accepts either python or py -3.12.')
    } else {
        Set-SupportedPythonEnvironment -PythonExecutable $supportedPythonExecutable
    }
} catch {
    $errors.Add('PYTHON_UNAVAILABLE: Python 3.12 is required; the launcher accepts either python or py -3.12.')
}

try {
    $runtimeRootValue = [string]$config.runtime_data_root
    if (-not [IO.Path]::IsPathRooted($runtimeRootValue)) {
        $errors.Add('RUNTIME_DATA_ROOT_UNSAFE: Use an absolute path outside the repository.')
    } else {
        $runtimeRoot = [IO.Path]::GetFullPath($runtimeRootValue).TrimEnd('\')
        $repositoryBoundary = $resolvedRoot.TrimEnd('\')
        if (
            $runtimeRoot.Equals($repositoryBoundary, [StringComparison]::OrdinalIgnoreCase) -or
            $runtimeRoot.StartsWith($repositoryBoundary + '\', [StringComparison]::OrdinalIgnoreCase) -or
            $runtimeRoot.Equals([IO.Path]::GetPathRoot($runtimeRoot).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase) -or
            $runtimeRoot.Equals([IO.Path]::GetFullPath($env:USERPROFILE).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase) -or
            -not (Test-NoReparseAncestors -Path $runtimeRoot)
        ) {
            $errors.Add('RUNTIME_DATA_ROOT_UNSAFE: Use a non-reparse absolute path outside the repository.')
        }
    }
} catch {
    $errors.Add('RUNTIME_DATA_ROOT_UNSAFE: Use an absolute path outside the repository.')
}

$runtimeOwnerPath = Join-Path $runtimeRoot '.openvideo-runtime-owner.json'
if (Test-Path -LiteralPath $runtimeRoot -PathType Container) {
    if (Test-Path -LiteralPath $runtimeOwnerPath -PathType Leaf) {
        try {
            $owner = Get-Content -LiteralPath $runtimeOwnerPath -Raw | ConvertFrom-Json
            if (
                @($owner.PSObject.Properties.Name | Sort-Object) -join ',' -ne 'owner,schema_version' -or
                $owner.schema_version -ne 1 -or
                $owner.owner -ne 'openvideo-local-runtime'
            ) {
                $errors.Add('RUNTIME_ROOT_UNOWNED: Ownership marker is invalid.')
            }
        } catch {
            $errors.Add('RUNTIME_ROOT_UNOWNED: Ownership marker cannot be verified.')
        }
    } else {
        $entries = @(Get-ChildItem -LiteralPath $runtimeRoot -Force)
        $legacyOwned = @(
            @(
                'projects.json',
                'authorizations.json',
                'tasks.json',
                'material-analysis'
            ) | ForEach-Object { Test-Path -LiteralPath (Join-Path $runtimeRoot $_) } |
                Where-Object { $_ -eq $false }
        )
        if ($entries.Count -eq 0 -or $legacyOwned.Count -eq 0) {
            $runtimeNeedsClaim = $true
        } else {
            $errors.Add('RUNTIME_ROOT_UNOWNED: Refusing to modify an unrelated non-empty directory.')
        }
    }
} else {
    $runtimeNeedsClaim = $true
}

if ($null -eq $config.gateway_port -or [int]$config.gateway_port -lt 1 -or [int]$config.gateway_port -gt 65535) {
    $errors.Add('GATEWAY_PORT_INVALID')
}

if (-not $CheckOnly) {
    $defaultShortVideoFactoryRoot = [IO.Path]::GetFullPath((Join-Path $resolvedRoot 'upstream\short-video-factory'))
    $defaultPyJianYingDraftRoot = [IO.Path]::GetFullPath((Join-Path $resolvedRoot 'upstream\pyJianYingDraft'))
    $configuredShortVideoFactoryRoot = [IO.Path]::GetFullPath([string]$config.short_video_factory_root)
    $configuredPyJianYingDraftRoot = [IO.Path]::GetFullPath([string]$config.pyjianyingdraft_root)
    $missingDefaultUpstream = (
        (-not (Test-Path -LiteralPath $configuredShortVideoFactoryRoot -PathType Container)) -or
        (-not (Test-Path -LiteralPath $configuredPyJianYingDraftRoot -PathType Container))
    )
    $usesGovernedDefaultRoots = (
        $configuredShortVideoFactoryRoot -eq $defaultShortVideoFactoryRoot -and
        $configuredPyJianYingDraftRoot -eq $defaultPyJianYingDraftRoot
    )
    if ($missingDefaultUpstream -and $usesGovernedDefaultRoots) {
        Write-Host 'Pinned production providers are missing; installing governed checkouts.' -ForegroundColor Cyan
        Write-Host 'Third-party licenses: short-video-factory AGPL-3.0; pyJianYingDraft Apache-2.0.' -ForegroundColor Yellow
        & (Join-Path $resolvedRoot 'scripts\Install-OpenVideoUpstreams.ps1') -RepositoryRoot $resolvedRoot
        if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_UPSTREAM_INSTALL_FAILED' }
    } elseif ($missingDefaultUpstream) {
        $errors.Add('CUSTOM_UPSTREAM_ROOT_MISSING: Automatic installation only manages the repository upstream directories.')
    }
}

Test-Upstream -DisplayName 'short-video-factory' `
    -Root ([string]$config.short_video_factory_root) `
    -ManifestPath (Join-Path $resolvedRoot 'config\short-video-factory-upstream.json') `
    -Errors $errors
Test-Upstream -DisplayName 'pyJianYingDraft' `
    -Root ([string]$config.pyjianyingdraft_root) `
    -ManifestPath (Join-Path $resolvedRoot 'config\pyjianyingdraft-upstream.json') `
    -Errors $errors

$dependencyReceipt = Join-Path $runtimeRoot 'material-analysis\dependency-installation.json'
$dependencyManifest = Join-Path $resolvedRoot 'config\material-analysis-dependencies.json'
$materialDependenciesCurrent = Test-MaterialDependencyReceipt `
    -ReceiptPath $dependencyReceipt `
    -ManifestPath $dependencyManifest
if ($CheckOnly -and -not $materialDependenciesCurrent) {
    $errors.Add('MATERIAL_ANALYSIS_DEPENDENCIES_MISSING: A normal launch installs pinned dependencies.')
}
if ($CheckOnly -and -not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'apps\web\dist\index.html') -PathType Leaf)) {
    $errors.Add('WEB_BUILD_MISSING: A normal launch rebuilds the Web application.')
}

if ($errors.Count -gt 0) {
    foreach ($message in $errors) { Write-Host "  - $message" -ForegroundColor Red }
    throw "OPENVIDEO_PRECHECK_FAILED: $($errors.Count) issue(s)."
}
Write-Host 'OPENVIDEO_PRECHECK_PASSED' -ForegroundColor Green
Write-OpenVideoLaunchPhase -Phase 'precheck'
if ($CheckOnly) { exit 0 }

$isPrimaryWorktree = Test-OpenVideoPrimaryWorktree -Root $resolvedRoot
$effectivePort = Resolve-OpenVideoGatewayPort `
    -Root $resolvedRoot `
    -PrimaryPort ([int]$config.gateway_port)
$rootSlug = Split-Path -Leaf $resolvedRoot
Write-Host (
    "OPENVIDEO_PORT_RESOLVED: port=$effectivePort primaryWorktree=$isPrimaryWorktree root=$rootSlug"
) -ForegroundColor Cyan

$url = "http://127.0.0.1:$effectivePort/"
$livenessUrl = "http://127.0.0.1:$effectivePort/api/live"
$localApiTokenPath = Join-Path $runtimeRoot 'local-api-token.json'
$launcherSecretPath = Join-Path $runtimeRoot 'launcher-instance.key'
$browserOpened = $false
$browserOpened = $env:OPENVIDEO_INTRO_OPENED -eq '1'

function Get-OpenVideoIntroBrowserUrl {
    param([Parameter(Mandatory = $true)][string]$BaseUrl)
    # The root StartupGate owns the only intro. The HTTP response establishes
    # the local session cookie; no file path, token, or handoff query is needed.
    return $BaseUrl.TrimEnd('/') + '/'
}
$releaseRevision = Get-OpenVideoReleaseRevision -Root $resolvedRoot
Write-OpenVideoCachedReleaseRevision `
    -Root $resolvedRoot `
    -Port $effectivePort `
    -ReleaseRevision $releaseRevision
$launcherMutex = [Threading.Mutex]::new(
    $false,
    "Local\OpenVideo.Launcher.$effectivePort"
)
$launcherMutexAcquired = $false
try {
    $launcherMutexAcquired = $launcherMutex.WaitOne([TimeSpan]::Zero)
} catch [Threading.AbandonedMutexException] {
    $launcherMutexAcquired = $true
}
if (-not $launcherMutexAcquired) {
    for ($attempt = 0; $attempt -lt 240; $attempt += 1) {
        $followerSecret = Read-LauncherInstanceSecret -Path $launcherSecretPath
        if ($null -ne $followerSecret) {
            $followerNonce = New-LauncherNonce
            $followerExpectedProof = Get-LauncherProof `
                -Secret $followerSecret `
                -Nonce $followerNonce
            $followerGateway = Get-RunningOpenVideo `
                -LivenessUrl $livenessUrl `
                -Nonce $followerNonce
            if (
                $null -ne $followerGateway -and
                $followerGateway.Proof -eq $followerExpectedProof
            ) {
                $followerRelease = if (
                    $followerGateway.Liveness.PSObject.Properties.Name -contains 'releaseRevision'
                ) {
                    [string]$followerGateway.Liveness.releaseRevision
                } else {
                    ''
                }
                $ownership = Get-OpenVideoPortOwnership `
                    -Port $effectivePort `
                    -ExpectedRoot $resolvedRoot
                if (
                    -not $Replace -and
                    (
                        $ownership.State -eq 'same_root' -or
                        $ownership.State -eq 'openvideo_unknown_root' -or
                        $ownership.State -eq 'free'
                    )
                ) {
                    Write-Host (
                        "OPENVIDEO_ALREADY_RUNNING: $url (revision=$releaseRevision root=$rootSlug)"
                    ) -ForegroundColor Green
                    if (-not $NoBrowser -and -not $browserOpened) {
                        Start-Process (Get-OpenVideoIntroBrowserUrl -BaseUrl $url)
                        $browserOpened = $true
                    }
                    $launcherMutex.Dispose()
                    exit 0
                }
                if (
                    $ownership.State -eq 'same_root' -or
                    $ownership.State -eq 'openvideo_unknown_root' -or
                    $ownership.State -eq 'free'
                ) {
                    if ($attempt -eq 0) {
                        Write-Host (
                            "OPENVIDEO_ALREADY_RUNNING_STALE_RELEASE: $url " +
                            "(runningRevision=$followerRelease currentRevision=$releaseRevision root=$rootSlug). " +
                            'Waiting for the active launcher to publish the replacement.'
                        ) -ForegroundColor Yellow
                    }
                    if ($Replace -and $ownership.State -eq 'same_root') {
                        Stop-OpenVideoLoopbackListener `
                            -Port $effectivePort `
                            -ExpectedPid $ownership.Pid `
                            -ExpectedState $ownership.State `
                            -ExpectedClassificationRoot $resolvedRoot `
                            -ExpectedRepositoryRoot $ownership.RepositoryRoot `
                            -Reason 'OPENVIDEO_REPLACING_WITH_EXPLICIT_FLAG'
                    }
                }
                if ($ownership.State -eq 'other_root') {
                    if ($Replace -and $isPrimaryWorktree) {
                        Stop-OpenVideoLoopbackListener `
                            -Port $effectivePort `
                            -ExpectedPid $ownership.Pid `
                            -ExpectedState $ownership.State `
                            -ExpectedClassificationRoot $resolvedRoot `
                            -ExpectedRepositoryRoot $ownership.RepositoryRoot `
                            -Reason 'OPENVIDEO_REPLACING_WITH_EXPLICIT_FLAG'
                        continue
                    }
                    $otherSlug = Split-Path -Leaf ([string]$ownership.RepositoryRoot)
                    throw (
                        "OPENVIDEO_PORT_OWNED_BY_OTHER_WORKTREE: 127.0.0.1:$effectivePort is owned by '$otherSlug' " +
                        "(revision=$($ownership.ReleaseRevision)). This launcher will not steal the port."
                    )
                }
                if ($ownership.State -eq 'openvideo_unknown_root' -and $Replace -and $isPrimaryWorktree) {
                    Stop-OpenVideoLoopbackListener `
                        -Port $effectivePort `
                        -ExpectedPid $ownership.Pid `
                        -ExpectedState $ownership.State `
                        -ExpectedClassificationRoot $resolvedRoot `
                        -ExpectedRepositoryRoot $ownership.RepositoryRoot `
                        -Reason 'OPENVIDEO_REPLACING_WITH_EXPLICIT_FLAG'
                    continue
                }
                # Same port, different revision: wait for the owning launcher on this port.
                # Never auto-kill across releaseRevision mismatches.
            }
        }
        try {
            $launcherMutexAcquired = $launcherMutex.WaitOne([TimeSpan]::Zero)
        } catch [Threading.AbandonedMutexException] {
            $launcherMutexAcquired = $true
        }
        if ($launcherMutexAcquired) {
            break
        }
        Start-Sleep -Milliseconds 500
    }
    if (-not $launcherMutexAcquired) {
        $launcherMutex.Dispose()
        throw 'OPENVIDEO_LAUNCHER_BUSY: The active OpenVideo launcher did not publish a verified local instance in time.'
    }
}

New-Item -ItemType Directory -Path $runtimeRoot -Force | Out-Null
if ($runtimeNeedsClaim) {
    Write-JsonUtf8 -Path $runtimeOwnerPath -Value ([ordered]@{
        schema_version = 1
        owner = 'openvideo-local-runtime'
    })
}
$localRuntimeModule = [Uri]::new(
    (Join-Path $resolvedRoot 'apps\gateway\src\local-runtime.mjs'),
    [UriKind]::Absolute
).AbsoluteUri
if (-not (Test-PrivateRuntimeBoundary -Path $runtimeRoot)) {
    $secureRuntimeScript = "import { securePrivateRuntimeBoundary } from '$localRuntimeModule'; await securePrivateRuntimeBoundary(process.argv[1]);"
    & node --input-type=module -e $secureRuntimeScript $runtimeRoot
    if ($LASTEXITCODE -ne 0) { throw 'RUNTIME_DATA_ROOT_ACL_FAILED' }
    # securePrivateRuntimeBoundary performs an observed ACL readback in the same
    # PowerShell host that applied the descriptor. A second read from this legacy
    # host can retain a stale descriptor after a pwsh mutation, causing a valid
    # newly-created isolated runtime to be rejected. The repair command itself is
    # therefore the fail-closed verification boundary.
}
$launcherInstanceSecret = Read-LauncherInstanceSecret -Path $launcherSecretPath
if ($null -eq $launcherInstanceSecret) {
    $launcherSecretBytes = [byte[]]::new(32)
    $launcherRandom = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $launcherRandom.GetBytes($launcherSecretBytes)
        $launcherInstanceSecret = [Convert]::ToBase64String($launcherSecretBytes)
        [IO.File]::WriteAllText(
            $launcherSecretPath,
            $launcherInstanceSecret,
            [Text.UTF8Encoding]::new($false)
        )
    } finally {
        [Array]::Clear($launcherSecretBytes, 0, $launcherSecretBytes.Length)
        $launcherRandom.Dispose()
    }
}
if ($materialDependenciesCurrent) {
    Write-Host 'Pinned material-analysis dependencies are current; runtime verification remains fail closed.'
} else {
    Write-Host 'Installing and verifying pinned material-analysis dependencies...'
    & (Join-Path $resolvedRoot 'scripts\Initialize-MaterialAnalysisDependencies.ps1') `
        -RuntimeDataRoot $runtimeRoot
    if ($LASTEXITCODE -ne 0) { throw 'MATERIAL_ANALYSIS_DEPENDENCY_INSTALL_FAILED' }
}
Write-OpenVideoLaunchPhase -Phase 'material-analysis-deps'
$buildReceiptPath = Join-Path $runtimeRoot "launcher-build-receipt.$effectivePort.json"
$dependencyReceiptPath = Join-Path $runtimeRoot "launcher-dependency-receipt.$effectivePort.json"
$gatewayBuildReceiptPath = Join-Path $runtimeRoot "launcher-gateway-build-receipt.$effectivePort.json"
$webBuildReceiptPath = Join-Path $runtimeRoot "launcher-web-build-receipt.$effectivePort.json"
$dependencyRevision = Get-OpenVideoDependencyRevision -Root $resolvedRoot
$gatewayBuildRevision = Get-OpenVideoGatewayBuildRevision `
    -Root $resolvedRoot `
    -DependencyRevision $dependencyRevision
$webBuildRevision = Get-OpenVideoWebBuildRevision `
    -Root $resolvedRoot `
    -DependencyRevision $dependencyRevision
$dependencyCacheCurrent = Test-OpenVideoDependencyReceipt `
    -Path $dependencyReceiptPath `
    -DependencyRevision $dependencyRevision `
    -Root $resolvedRoot
$buildCacheCurrent = Test-OpenVideoBuildReceipt `
    -Path $buildReceiptPath `
    -ReleaseRevision $releaseRevision `
    -Root $resolvedRoot
$gatewayBuildCacheCurrent = (
    $dependencyCacheCurrent -and
    (Test-OpenVideoComponentBuildReceipt `
        -Path $gatewayBuildReceiptPath `
        -ComponentRevision $gatewayBuildRevision `
        -Root $resolvedRoot)
)
$webBuildCacheCurrent = (
    $dependencyCacheCurrent -and
    (Test-OpenVideoComponentBuildReceipt `
        -Path $webBuildReceiptPath `
        -ComponentRevision $webBuildRevision `
        -Root $resolvedRoot `
        -RequiredPaths @((Join-Path $resolvedRoot 'apps\web\dist\index.html')))
)
$deferredBuild = $false
$deferredBuildProcess = $null
Write-OpenVideoLaunchPhase -Phase 'revision-hashing'
Write-OpenVideoLaunchNote -Message (
    'OPENVIDEO_CACHE_STATE: dependency={0} release={1} gateway={2} web={3}' -f
    $dependencyCacheCurrent, $buildCacheCurrent, $gatewayBuildCacheCurrent, $webBuildCacheCurrent
)
if ($buildCacheCurrent) {
    Write-Host 'OPENVIDEO_BUILD_CACHE_HIT: Verified build is current; skipping dependency install and rebuild.' -ForegroundColor Green
    if (-not $dependencyCacheCurrent) {
        # A current full build receipt proves that node_modules was installed for the same
        # dependency inputs, so older installations can adopt the narrower receipt safely.
        Write-OpenVideoDependencyReceipt `
            -Path $dependencyReceiptPath `
            -DependencyRevision $dependencyRevision `
            -Root $resolvedRoot
    }
    if (-not $gatewayBuildCacheCurrent) {
        Write-OpenVideoComponentBuildReceipt `
            -Path $gatewayBuildReceiptPath `
            -ComponentRevision $gatewayBuildRevision `
            -Root $resolvedRoot
    }
    if (-not $webBuildCacheCurrent) {
        Write-OpenVideoComponentBuildReceipt `
            -Path $webBuildReceiptPath `
            -ComponentRevision $webBuildRevision `
            -Root $resolvedRoot
    }
} else {
    if ($dependencyCacheCurrent) {
        Write-Host 'OPENVIDEO_DEPENDENCY_CACHE_HIT: Pinned Node.js dependencies are current; skipping install.' -ForegroundColor Green
    } else {
        Write-Host 'Verifying pinned Node.js dependencies...'
        & corepack pnpm --dir $resolvedRoot install --frozen-lockfile
        if ($LASTEXITCODE -ne 0) { throw 'NODE_DEPENDENCY_INSTALL_FAILED' }
        Write-OpenVideoDependencyReceipt `
            -Path $dependencyReceiptPath `
            -DependencyRevision $dependencyRevision `
            -Root $resolvedRoot
        $gatewayBuildCacheCurrent = $false
        $webBuildCacheCurrent = $false
    }
    Assert-NodeLifecycleAvailable -Root $resolvedRoot
    # A previous Web build is enough to show the workbench while the current
    # release is validated in the background. This keeps the first useful
    # screen independent from the slow typecheck/build phase. On a truly empty
    # checkout we still build synchronously so the browser never opens blank.
    $canDeferBuild = (
        $dependencyCacheCurrent -and
        (Test-Path -LiteralPath (Join-Path $resolvedRoot 'apps\web\dist\index.html') -PathType Leaf)
    )
    if ($canDeferBuild) {
        $deferredBuild = $true
        Write-Host 'OPENVIDEO_BUILD_DEFERRED: existing workbench is available; validation continues after the window opens.' -ForegroundColor Cyan
        Write-OpenVideoLaunchNote -Message 'OPENVIDEO_BUILD_DEFERRED: existing frontend is served while current artifacts build in background.'
    } elseif ($gatewayBuildCacheCurrent) {
        Write-Host 'OPENVIDEO_GATEWAY_BUILD_CACHE_HIT: Gateway validation inputs are current; skipping checks.' -ForegroundColor Green
    } else {
        Write-Host 'Validating the OpenVideo Gateway...'
        & corepack pnpm --dir $resolvedRoot --filter '@openvideo/gateway' build
        if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_GATEWAY_BUILD_FAILED' }
        & corepack pnpm --dir $resolvedRoot --filter '@openvideo/gateway' build:workbench-preview
        if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_PREVIEW_BUILD_FAILED' }
        & corepack pnpm --dir $resolvedRoot --filter '@openvideo/gateway' build:tpl002
        if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_TEMPLATE_BUILD_FAILED' }
        & corepack pnpm --dir $resolvedRoot --filter '@openvideo/gateway' build:jy002
        if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_JIANYING_BUILD_FAILED' }
        Write-OpenVideoComponentBuildReceipt `
            -Path $gatewayBuildReceiptPath `
            -ComponentRevision $gatewayBuildRevision `
            -Root $resolvedRoot
    }
    if (-not $deferredBuild -and $webBuildCacheCurrent) {
        Write-Host 'OPENVIDEO_WEB_BUILD_CACHE_HIT: Web build inputs and output are current; skipping build.' -ForegroundColor Green
    } elseif (-not $deferredBuild) {
        Write-Host 'Building the OpenVideo Web application...'
        $env:VITE_OPENVIDEO_HEALTH_PATH = '/api/live'
        $env:VITE_MATERIAL_ANALYSIS_HEALTH_PATH = '/api/workbench/material-analysis/status'
        $env:VITE_OPENVIDEO_WORKBENCH_PATH = '/api/workbench'
        & corepack pnpm --dir $resolvedRoot --filter '@openvideo/web' build
        if ($LASTEXITCODE -ne 0) { throw 'OPENVIDEO_WEB_BUILD_FAILED' }
        Write-OpenVideoComponentBuildReceipt `
            -Path $webBuildReceiptPath `
            -ComponentRevision $webBuildRevision `
            -Root $resolvedRoot
    }
    if (-not $deferredBuild) {
        Write-OpenVideoBuildReceipt `
            -Path $buildReceiptPath `
            -ReleaseRevision $releaseRevision `
            -Root $resolvedRoot
    }
}

Write-OpenVideoLaunchPhase -Phase 'install-and-build'

function Set-LlmEnvironmentFromPrivateSettings {
    param([string]$PrivateConfigPath)
    $env:OPENVIDEO_LLM_PROVIDER = $null
    $env:OPENVIDEO_LLM_REVISION = $null
    $env:OPENVIDEO_LLM_BASE_URL = $null
    $env:OPENVIDEO_LLM_API_KEY = $null
    $env:OPENVIDEO_LLM_TEXT_MODEL = $null
    $env:OPENVIDEO_LLM_VISION_MODEL = $null
    $env:OPENVIDEO_LLM_JSON_MODEL = $null

    try {
        $privateConfig = Get-Content -LiteralPath $PrivateConfigPath -Raw | ConvertFrom-Json
        $requiredNames = @(
            'llm_provider',
            'llm_revision',
            'llm_api_key_dpapi',
            'llm_base_url',
            'llm_text_model',
            'llm_vision_model',
            'llm_json_model'
        )
        foreach ($name in $requiredNames) {
            if (
                $privateConfig.PSObject.Properties.Name -notcontains $name -or
                [string]::IsNullOrWhiteSpace([string]$privateConfig.$name)
            ) {
                return $false
            }
        }
        if ([string]$privateConfig.llm_provider -ne 'openai-compatible') { return $false }
        foreach ($name in @('llm_base_url', 'llm_text_model', 'llm_vision_model', 'llm_json_model')) {
            if ([string]$privateConfig.$name -like '*REPLACE_WITH_*') { return $false }
        }
        $baseUrl = [Uri]([string]$privateConfig.llm_base_url)
        if (
            $baseUrl.Scheme -ne 'https' -or
            -not [string]::IsNullOrEmpty($baseUrl.UserInfo) -or
            -not [string]::IsNullOrEmpty($baseUrl.Query) -or
            -not [string]::IsNullOrEmpty($baseUrl.Fragment)
        ) {
            return $false
        }
        Add-Type -AssemblyName System.Security
        $cipher = [Convert]::FromBase64String([string]$privateConfig.llm_api_key_dpapi)
        $entropy = [Text.Encoding]::UTF8.GetBytes([string]$privateConfig.llm_revision)
        $plainBytes = [Security.Cryptography.ProtectedData]::Unprotect(
            $cipher,
            $entropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        $apiKey = [Text.Encoding]::UTF8.GetString($plainBytes)
        if ([string]::IsNullOrWhiteSpace($apiKey)) { return $false }
        $env:OPENVIDEO_LLM_REVISION = [string]$privateConfig.llm_revision
        $env:OPENVIDEO_LLM_PROVIDER = [string]$privateConfig.llm_provider
        $env:OPENVIDEO_LLM_BASE_URL = [string]$privateConfig.llm_base_url
        $env:OPENVIDEO_LLM_API_KEY = $apiKey
        $env:OPENVIDEO_LLM_TEXT_MODEL = [string]$privateConfig.llm_text_model
        $env:OPENVIDEO_LLM_VISION_MODEL = [string]$privateConfig.llm_vision_model
        $env:OPENVIDEO_LLM_JSON_MODEL = [string]$privateConfig.llm_json_model
        [Array]::Clear($plainBytes, 0, $plainBytes.Length)
        [Array]::Clear($cipher, 0, $cipher.Length)
        [Array]::Clear($entropy, 0, $entropy.Length)
        $apiKey = $null
        return $true
    } catch {
        Write-Host 'LLM_SETTINGS_UNAVAILABLE: Configure the model in the local workbench.' -ForegroundColor Yellow
        return $false
    }
}

$env:OPENVIDEO_WORKBENCH_MODE = 'production'
$env:OPENVIDEO_RUNTIME_DATA_ROOT = $runtimeRoot
$env:OPENVIDEO_GATEWAY_PORT = [string]$effectivePort
$env:OPENVIDEO_RELEASE_REVISION = $releaseRevision
$env:OPENVIDEO_LAUNCHER_INSTANCE_SECRET = $launcherInstanceSecret
$env:OPENVIDEO_CONFIG_PATH = $resolvedConfigPath
$env:OPENVIDEO_PRIVATE_CONFIG_ROOT = $privateConfigRoot
$env:OPENVIDEO_SHORT_VIDEO_FACTORY_ROOT = [string]$config.short_video_factory_root
$env:OPENVIDEO_PYJIANYINGDRAFT_ROOT = [string]$config.pyjianyingdraft_root
if ($config.PSObject.Properties.Name -contains 'voice') {
    $env:OPENVIDEO_SHORT_VIDEO_FACTORY_VOICE = [string]$config.voice
}
if ($config.PSObject.Properties.Name -contains 'voice_rate') {
    $env:OPENVIDEO_SHORT_VIDEO_FACTORY_VOICE_RATE = [string]$config.voice_rate
}
if ($config.PSObject.Properties.Name -contains 'bgm_path') {
    $env:OPENVIDEO_SHORT_VIDEO_FACTORY_BGM_PATH = [string]$config.bgm_path
}

$logRoot = Join-Path $runtimeRoot 'launcher-logs'
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$stdoutPath = Join-Path $logRoot 'gateway.stdout.log'
$stderrPath = Join-Path $logRoot 'gateway.stderr.log'
$gatewayEntry = Join-Path $resolvedRoot 'apps\gateway\src\server.mjs'
$nodeExecutable = (Get-Command node.exe -ErrorAction Stop).Source

$launcherNonce = New-LauncherNonce
$expectedLauncherProof = Get-LauncherProof `
    -Secret $launcherInstanceSecret `
    -Nonce $launcherNonce
$runningGateway = Get-RunningOpenVideo `
    -LivenessUrl $livenessUrl `
    -Nonce $launcherNonce
if ($null -ne $runningGateway) {
    $runningReleaseRevision = if (
        $runningGateway.Liveness.PSObject.Properties.Name -contains 'releaseRevision'
    ) {
        [string]$runningGateway.Liveness.releaseRevision
    } else {
        ''
    }
    $proofMatches = (
        -not [string]::IsNullOrWhiteSpace($runningGateway.Proof) -and
        $runningGateway.Proof -eq $expectedLauncherProof
    )
    $portOwnershipPreview = Get-OpenVideoPortOwnership `
        -Port $effectivePort `
        -ExpectedRoot $resolvedRoot
    if (
        $proofMatches -and
        -not $Replace -and
        (
            $portOwnershipPreview.State -eq 'same_root' -or
            $portOwnershipPreview.State -eq 'openvideo_unknown_root' -or
            $portOwnershipPreview.State -eq 'free'
        )
    ) {
        Write-Host (
            "OPENVIDEO_ALREADY_RUNNING: $url (revision=$releaseRevision root=$rootSlug)"
        ) -ForegroundColor Green
        if (-not $NoBrowser -and -not $browserOpened) {
            Start-Process (Get-OpenVideoIntroBrowserUrl -BaseUrl $url)
            $browserOpened = $true
        }
        $launcherMutex.ReleaseMutex()
        $launcherMutexAcquired = $false
        $launcherMutex.Dispose()
        $env:OPENVIDEO_LAUNCHER_INSTANCE_SECRET = $null
        $launcherInstanceSecret = $null
        exit 0
    }
}

$portOwnership = Assert-OpenVideoPortOccupiable `
    -Port $effectivePort `
    -RepositoryRoot $resolvedRoot `
    -Replace:$Replace `
    -IsPrimaryWorktree:$isPrimaryWorktree
if ($null -ne $runningGateway) {
    $runningReleaseRevision = if (
        $runningGateway.Liveness.PSObject.Properties.Name -contains 'releaseRevision'
    ) {
        [string]$runningGateway.Liveness.releaseRevision
    } else {
        ''
    }
    # Only replace when ownership is same_root, or primary -Replace for foreign/orphan.
    if ($portOwnership.State -eq 'same_root') {
        Stop-OpenVideoLoopbackListener `
            -Port $effectivePort `
            -ExpectedPid $portOwnership.Pid `
            -ExpectedState $portOwnership.State `
            -ExpectedClassificationRoot $resolvedRoot `
            -ExpectedRepositoryRoot $portOwnership.RepositoryRoot `
            -Reason 'OPENVIDEO_REPLACING_SAME_WORKTREE'
    } elseif ($Replace -and $isPrimaryWorktree) {
        Stop-OpenVideoLoopbackListener `
            -Port $effectivePort `
            -ExpectedPid $portOwnership.Pid `
            -ExpectedState $portOwnership.State `
            -ExpectedClassificationRoot $resolvedRoot `
            -ExpectedRepositoryRoot $portOwnership.RepositoryRoot `
            -Reason 'OPENVIDEO_REPLACING_WITH_EXPLICIT_FLAG'
    } else {
        throw (
            "OPENVIDEO_PORT_CONFLICT: 127.0.0.1:$effectivePort has an OpenVideo listener " +
            "(state=$($portOwnership.State) revision=$runningReleaseRevision) that this launcher will not steal. " +
            "From the primary worktree, pass -Replace only when intentional."
        )
    }
}
if (Test-LoopbackPortInUse -Port $effectivePort) {
    $leftover = Get-OpenVideoPortOwnership -Port $effectivePort -ExpectedRoot $resolvedRoot
    if ($leftover.State -eq 'same_root') {
        Stop-OpenVideoLoopbackListener -Port $effectivePort -ExpectedPid $leftover.Pid -ExpectedState $leftover.State -ExpectedClassificationRoot $resolvedRoot -ExpectedRepositoryRoot $leftover.RepositoryRoot -Reason 'OPENVIDEO_REPLACING_SAME_WORKTREE'
    } elseif ($Replace -and $isPrimaryWorktree -and (
        $leftover.State -eq 'other_root' -or $leftover.State -eq 'openvideo_unknown_root'
    )) {
        Stop-OpenVideoLoopbackListener -Port $effectivePort -ExpectedPid $leftover.Pid -ExpectedState $leftover.State -ExpectedClassificationRoot $resolvedRoot -ExpectedRepositoryRoot $leftover.RepositoryRoot -Reason 'OPENVIDEO_REPLACING_WITH_EXPLICIT_FLAG'
    }
    if (Test-LoopbackPortInUse -Port $effectivePort) {
        throw "OPENVIDEO_PORT_IN_USE: Port $effectivePort remains occupied after ownership checks."
    }
}

$process = $null
$processJob = $null
$gatewayRestartAttempts = 0
function Start-OpenVideoDeferredBuild {
    if (-not $script:deferredBuild -or $null -ne $script:deferredBuildProcess) { return }
    $backgroundBuildLog = Join-Path $logRoot 'background-build.log'
    $backgroundBuildErrorLog = Join-Path $logRoot 'background-build.err.log'
    $buildScript = Join-Path $resolvedRoot 'scripts\Build-OpenVideoArtifacts.ps1'
    if (-not (Test-Path -LiteralPath $buildScript -PathType Leaf)) {
        Write-OpenVideoLaunchNote -Message 'OPENVIDEO_BACKGROUND_BUILD_UNAVAILABLE: helper script is missing; keeping existing artifacts.'
        $script:deferredBuild = $false
        return
    }
    $script:deferredBuildProcess = Start-Process -FilePath (Get-Command powershell.exe -ErrorAction Stop).Source `
        -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $buildScript + '"'),
            '-RepositoryRoot', ('"' + $resolvedRoot + '"'), '-RuntimeRoot', ('"' + $runtimeRoot + '"'),
            '-DependencyRevision', $dependencyRevision,
            '-GatewayBuildRevision', $gatewayBuildRevision,
            '-WebBuildRevision', $webBuildRevision,
            '-ReleaseRevision', $releaseRevision,
            '-DependencyReceiptPath', ('"' + $dependencyReceiptPath + '"'),
            '-GatewayBuildReceiptPath', ('"' + $gatewayBuildReceiptPath + '"'),
            '-WebBuildReceiptPath', ('"' + $webBuildReceiptPath + '"'),
            '-BuildReceiptPath', ('"' + $buildReceiptPath + '"')
        ) `
        -WorkingDirectory $resolvedRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $backgroundBuildLog `
        -RedirectStandardError $backgroundBuildErrorLog `
        -PassThru
    Write-OpenVideoLaunchNote -Message "OPENVIDEO_BACKGROUND_BUILD_STARTED: pid=$($script:deferredBuildProcess.Id)"
}
try {
    while ($true) {
        $null = Set-LlmEnvironmentFromPrivateSettings -PrivateConfigPath $resolvedConfigPath
        try {
            $processJob = New-SupervisedProcessJob
            $process = $processJob.StartSuspended(
                $nodeExecutable,
                $gatewayEntry,
                $resolvedRoot,
                $stdoutPath,
                $stderrPath
            )
            $live = $false
            $runtimeReady = $false
            $instanceRecordWritten = $false
            Write-OpenVideoLaunchNote -Message 'OPENVIDEO_GATEWAY_BOOTING: waiting for the gateway to answer.'
            # Open the browser when the startup shell is live, then keep this supervisor and the
            # visible bootstrap window active until the complete workbench request handler is ready.
            $livenessDeadline = [DateTime]::UtcNow.AddSeconds(180)
            for ($attempt = 0; $attempt -lt 240; $attempt += 1) {
                $now = [DateTime]::UtcNow
                if ($now -ge $livenessDeadline) { break }
                if ($process.HasExited) { throw 'OPENVIDEO_GATEWAY_START_FAILED: See private launcher-logs.' }
                # Open the browser as soon as this release's startup shell is listening.
                # Full HMAC ownership and runtime readiness are still required before the
                # launcher reports success or exposes the complete API.
                if (-not $browserOpened) {
                    $earlyLive = Get-OpenVideoEarlyLiveness -LivenessUrl $livenessUrl
                    if ($null -ne $earlyLive -and
                        [string]$earlyLive.releaseRevision -eq $releaseRevision) {
                        if (-not $NoBrowser) {
                            Start-Process (Get-OpenVideoIntroBrowserUrl -BaseUrl $url)
                        }
                        $browserOpened = $true
                        Write-OpenVideoLaunchNote -Message 'OPENVIDEO_FRONTEND_OPENED: startup shell is live; background capabilities continue.'
                        Start-OpenVideoDeferredBuild
                    }
                }
                $probe = Get-RunningOpenVideo `
                    -LivenessUrl $livenessUrl `
                    -Nonce $launcherNonce
                $probeReleaseRevision = if (
                    $null -ne $probe -and
                    $probe.Liveness.PSObject.Properties.Name -contains 'releaseRevision'
                ) {
                    [string]$probe.Liveness.releaseRevision
                } else {
                    ''
                }
                if (
                    $null -ne $probe -and
                    $probe.Proof -eq $expectedLauncherProof -and
                    $probeReleaseRevision -eq $releaseRevision
                ) {
                    if (-not $live) {
                        $live = $true
                    }
                    if (-not $instanceRecordWritten) {
                        Write-OpenVideoInstanceRecord `
                            -Port $effectivePort `
                            -RepositoryRoot $resolvedRoot `
                            -ReleaseRevision $releaseRevision `
                            -ProcessId ([int]$process.Id) `
                            -SupervisorProcessId $PID `
                            -Url $url
                        $instanceRecordWritten = $true
                    }
                    # Open the workbench as soon as the local HTTP server is alive. Capability
                    # readiness may require slow or unavailable external providers; it must not
                    # delay the first useful screen.
                    if (-not $NoBrowser -and -not $browserOpened) {
                        Start-Process (Get-OpenVideoIntroBrowserUrl -BaseUrl $url)
                        $browserOpened = $true
                    }
                    Start-OpenVideoDeferredBuild
                    $runtimeReady = (
                        $probe.Liveness.PSObject.Properties.Name -notcontains 'ready' -or
                        $probe.Liveness.ready -eq $true
                    )
                    if ($runtimeReady) { break }
                }
                Start-Sleep -Milliseconds 500
            }
            Write-OpenVideoLaunchPhase -Phase 'gateway-health'
            if (-not $live) { throw 'OPENVIDEO_GATEWAY_HEALTH_TIMEOUT' }
            if (-not $runtimeReady) { throw 'OPENVIDEO_GATEWAY_STARTUP_TIMEOUT' }
            Write-Host (
                "OPENVIDEO_STARTED: $url (revision=$releaseRevision root=$rootSlug)"
            ) -ForegroundColor Green
            if ($null -ne $deferredBuildProcess) {
                $deferredBuildProcess.WaitForExit()
                $deferredBuildProcess.Refresh()
                $deferredBuildExitCode = $null
                try {
                    $deferredBuildExitCode = $deferredBuildProcess.ExitCode
                } catch {
                    Write-OpenVideoLaunchNote -Message 'OPENVIDEO_BACKGROUND_BUILD_EXIT_UNAVAILABLE: validating exact cache receipts.'
                }
                $deferredBuildComplete = Test-OpenVideoDeferredBuildCompletion `
                    -ExitCode $deferredBuildExitCode `
                    -DependencyReceiptPath $dependencyReceiptPath `
                    -DependencyRevision $dependencyRevision `
                    -GatewayBuildReceiptPath $gatewayBuildReceiptPath `
                    -GatewayBuildRevision $gatewayBuildRevision `
                    -WebBuildReceiptPath $webBuildReceiptPath `
                    -WebBuildRevision $webBuildRevision `
                    -BuildReceiptPath $buildReceiptPath `
                    -ReleaseRevision $releaseRevision `
                    -Root $resolvedRoot
                if ($deferredBuildComplete) {
                    Write-OpenVideoLaunchNote -Message 'OPENVIDEO_BACKGROUND_BUILD_COMPLETE: current artifacts and cache receipts are ready.'
                } else {
                    $deferredBuildExitLabel = if ($null -eq $deferredBuildExitCode) { 'unavailable' } else { [string]$deferredBuildExitCode }
                    Write-OpenVideoLaunchNote -Message "OPENVIDEO_BACKGROUND_BUILD_FAILED: exit=$deferredBuildExitLabel or exact receipt validation failed; existing artifacts remain active."
                    Write-Host 'OPENVIDEO_BACKGROUND_BUILD_FAILED: existing workbench remains active; see private launcher-logs.' -ForegroundColor Yellow
                }
                $deferredBuildProcess.Dispose()
                $deferredBuildProcess = $null
            }
            # Duo is optional and fail-closed. Install it only after Gateway/Native
            # is live so a first-run JDK/class build cannot delay the primary path.
            $duoInstaller = Join-Path $resolvedRoot 'scripts\Install-JY200DuoWriterRuntime.mjs'
            if (Test-Path -LiteralPath $duoInstaller -PathType Leaf) {
                try {
                    $installerAlreadyRunning = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" |
                        Where-Object {
                            $_.CommandLine -like "*$duoInstaller*" -and $_.CommandLine -like "*$resolvedRoot*"
                        }).Count -gt 0
                    if ($installerAlreadyRunning) {
                        Write-OpenVideoLaunchNote -Message 'OPENVIDEO_OPTIONAL_PROVIDER_INSTALL_ALREADY_RUNNING: duo-video'
                    } else {
                        # Start-Process serializes ArgumentList into one command line. Keep this
                        # absolute script path as one Node argument when the worktree has spaces.
                        $duoInstallerArgument = '"' + $duoInstaller + '"'
                        Start-Process -FilePath $nodeExecutable `
                            -ArgumentList $duoInstallerArgument `
                            -WorkingDirectory $resolvedRoot `
                            -WindowStyle Hidden `
                            -RedirectStandardOutput (Join-Path $logRoot 'duo-installer.stdout.log') `
                            -RedirectStandardError (Join-Path $logRoot 'duo-installer.stderr.log') | Out-Null
                        Write-OpenVideoLaunchNote -Message 'OPENVIDEO_OPTIONAL_PROVIDER_INSTALL_STARTED: duo-video'
                    }
                } catch {
                    Write-Host 'OPENVIDEO_OPTIONAL_PROVIDER_UNAVAILABLE: duo-video' -ForegroundColor Yellow
                }
            }
            if (-not $NoBrowser -and -not $browserOpened) {
                Start-Process (Get-OpenVideoIntroBrowserUrl -BaseUrl $url)
                $browserOpened = $true
            }
            $process.WaitForExit()
            Remove-OpenVideoInstanceRecord -Port $effectivePort
            $restartMarkerPath = Join-Path $logRoot 'controlled-restart.marker'
            $restartRequested = Test-Path -LiteralPath $restartMarkerPath
            if ($restartRequested) {
                Remove-Item -LiteralPath $restartMarkerPath -Force -ErrorAction SilentlyContinue
            }
            $exitCode = $null
            try {
                $process.Refresh()
                if ($process.HasExited) {
                    $exitCode = $process.ExitCode
                }
            } catch {
                $exitCode = $null
            }
            if (
                $restartRequested -or
                $exitCode -eq 75 -or
                (($null -ne $exitCode) -and (($exitCode -band 0xff) -eq 75))
            ) {
                $gatewayRestartAttempts = 0
                Write-Host 'OPENVIDEO_RESTARTING: Applying settings from the local workbench.' -ForegroundColor Green
                continue
            }
            $nullExitCode = ($null -eq $exitCode)
            if ($nullExitCode -or $exitCode -ne 0) {
                $stillAlive = $false
                try {
                    $aliveProbe = Get-RunningOpenVideo `
                        -LivenessUrl $livenessUrl `
                        -Nonce $launcherNonce
                    if (
                        $null -ne $aliveProbe -and
                        $aliveProbe.Proof -eq $expectedLauncherProof
                    ) {
                        $stillAlive = $true
                    }
                } catch {
                    $stillAlive = $false
                }
                if ($stillAlive) {
                    Write-Host ('OPENVIDEO_GATEWAY_BACKGROUND_RUN: launcher detached but gateway still serves at ' + $url + '. You can keep using the workbench.') -ForegroundColor Green
                    Remove-OpenVideoInstanceRecord -Port $effectivePort
                    break
                }
                $gatewayRestartAttempts += 1
                $restartDelaySeconds = [Math]::Min(30, [Math]::Pow(2, [Math]::Min(5, $gatewayRestartAttempts - 1)))
                $exitLabel = if ($nullExitCode) { 'unknown' } else { [string]$exitCode }
                Write-OpenVideoLaunchNote -Message (
                    "OPENVIDEO_GATEWAY_CRASH: exit=$exitLabel attempt=$gatewayRestartAttempts delay=${restartDelaySeconds}s"
                )
                if ($gatewayRestartAttempts -gt 10) {
                    Write-Host ('OPENVIDEO_GATEWAY_EXIT_CODE: ' + $exitLabel) -ForegroundColor Red
                    throw 'OPENVIDEO_GATEWAY_EXITED_AFTER_RESTARTS'
                }
                Write-Host (
                    "OPENVIDEO_GATEWAY_RESTARTING_AFTER_CRASH: exit=$exitLabel attempt=$gatewayRestartAttempts delay=${restartDelaySeconds}s"
                ) -ForegroundColor Yellow
                Start-Sleep -Seconds $restartDelaySeconds
                continue
            }
            break
        } finally {
            if ($null -ne $processJob) {
                $processJob.Dispose()
                $processJob = $null
            }
            if ($null -ne $process -and -not $process.HasExited) {
                Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
            }
            if ($null -ne $process -and -not $process.HasExited) {
                $process.WaitForExit(5000) | Out-Null
            }
            Remove-OpenVideoInstanceRecord -Port $effectivePort
            $process = $null
        }
    }
} finally {
    if ($null -ne $processJob) {
        $processJob.Dispose()
    }
    if ($null -ne $process -and -not $process.HasExited) {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
    }
    if ($null -ne $process -and -not $process.HasExited) {
        $process.WaitForExit(5000) | Out-Null
    }
    Remove-OpenVideoInstanceRecord -Port $effectivePort
    $env:OPENVIDEO_LLM_API_KEY = $null
    $env:OPENVIDEO_LLM_REVISION = $null
    $env:OPENVIDEO_LAUNCHER_INSTANCE_SECRET = $null
    $launcherInstanceSecret = $null
    if ($launcherMutexAcquired) {
        $launcherMutex.ReleaseMutex()
        $launcherMutex.Dispose()
    }
}
