import { randomBytes } from 'node:crypto'
import { readFile, readdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

const APP_KEY = 'IZjhUeAYwP'
const APP_ID = '3704'
const speakerPattern = /^[A-Za-z][A-Za-z0-9_]{2,79}$/u

export class JianyingLocalTtsError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 502) {
    super(code)
    this.name = 'JianyingLocalTtsError'
    this.code = code
    this.status = status
  }
}

/**
 * @typedef {{
 *   addEventListener: (type: string, listener: (event: any) => void, options?: any) => void,
 *   send: (data: string) => void,
 *   close: () => void,
 * }} JianyingTtsSocket
 * @typedef {(url: string, options?: Record<string, any>) => JianyingTtsSocket} JianyingTtsSocketFactory
 */

/**
 * Resolve Jianying Pro local device identity from User Data (read-only).
 * Prefer Config/envcfg (device_id + app_install_id); fall back to TTNet / Log.
 * Never hardcode third-party device/iid values.
 * @param {{localAppData?: string}} [options]
 */
export const resolveJianyingLocalIdentity = async ({ localAppData = process.env.LOCALAPPDATA } = {}) => {
  if (typeof localAppData !== 'string' || !localAppData) {
    throw new JianyingLocalTtsError('JIANYING_LOCAL_IDENTITY_UNAVAILABLE', 503)
  }
  const userData = join(localAppData, 'JianyingPro', 'User Data')
  let deviceId = null
  let installId = null

  try {
    const envcfg = await readFile(join(userData, 'Config', 'envcfg'), 'utf8')
    const deviceMatch = envcfg.match(/^\s*device_id\s*=\s*(\d+)\s*$/mu)
    const installMatch = envcfg.match(/^\s*app_install_id\s*=\s*(\d+)\s*$/mu)
    if (deviceMatch) deviceId = deviceMatch[1]
    if (installMatch) installId = installMatch[1]
  } catch {
    /* optional */
  }

  if (!deviceId) {
    try {
      const ttnet = await readFile(join(userData, 'TTNet', 'tt_net_config.config'), 'utf8')
      const match = ttnet.match(/device_id&#\*(\d+)/u)
      if (match) deviceId = match[1]
    } catch {
      /* optional */
    }
  }

  if (!installId) {
    try {
      const logDir = join(userData, 'Log')
      const entries = await readdir(logDir)
      const logs = entries
        .filter((name) => name.endsWith('.log'))
        .map((name) => join(logDir, name))
      for (const path of logs.slice(0, 8)) {
        try {
          const chunk = await readFile(path, 'utf8')
          const match = chunk.match(/\biid=(\d+)/u)
          if (match) {
            installId = match[1]
            break
          }
        } catch {
          /* try next */
        }
      }
    } catch {
      /* optional */
    }
  }

  if (!deviceId || !installId) {
    throw new JianyingLocalTtsError('JIANYING_LOCAL_IDENTITY_UNAVAILABLE', 503)
  }
  return { deviceId, installId }
}

/**
 * @param {{
 *   text: string,
 *   speakerId: string,
 *   outputPath: string,
 *   identity?: {deviceId: string, installId: string},
 *   signal?: AbortSignal,
 *   openWebSocket?: JianyingTtsSocketFactory,
 * }} input
 */
export const synthesizeJianyingLocalSpeech = async ({
  text,
  speakerId,
  outputPath,
  identity,
  signal,
  openWebSocket = (url, options) => new (/** @type {any} */ (WebSocket))(url, options),
}) => {
  if (typeof text !== 'string' || text.trim().length === 0 || text.length > 20_000) {
    throw new JianyingLocalTtsError('JIANYING_LOCAL_TTS_INPUT_INVALID', 400)
  }
  if (!speakerPattern.test(speakerId) || typeof outputPath !== 'string' || !outputPath) {
    throw new JianyingLocalTtsError('JIANYING_LOCAL_TTS_INPUT_INVALID', 400)
  }
  signal?.throwIfAborted()
  const { deviceId, installId } = identity ?? await resolveJianyingLocalIdentity()
  if (typeof openWebSocket !== 'function') {
    throw new JianyingLocalTtsError('JIANYING_LOCAL_TTS_UNSUPPORTED', 501)
  }

  const wsUrl = `wss://sami.bytedance.com/internal/api/v2/ws?device_id=${deviceId}&iid=${installId}`
  const audioData = await /** @type {Promise<Buffer>} */ (new Promise((resolve, reject) => {
    /** @type {JianyingTtsSocket | null} */
    let socket = null
    /** @type {Buffer[]} */
    const chunks = []
    let settled = false
    let taskFinished = false
    let pendingBinary = 0
    /** @type {ReturnType<typeof setTimeout> | null} */
    let settleTimer = null
    /** @type {ReturnType<typeof setTimeout> | null} */
    let timeout = null

    const cleanup = () => {
      if (timeout) clearTimeout(timeout)
      if (settleTimer) clearTimeout(settleTimer)
      signal?.removeEventListener('abort', onAbort)
    }
    /** @param {string} code @param {number} [status] */
    const fail = (code, status = 502) => {
      if (settled) return
      settled = true
      cleanup()
      try { socket?.close() } catch { /* ignore */ }
      reject(new JianyingLocalTtsError(code, status))
    }
    /** @param {Buffer} buffer */
    const succeed = (buffer) => {
      if (settled) return
      settled = true
      cleanup()
      try { socket?.close() } catch { /* ignore */ }
      resolve(buffer)
    }
    const tryComplete = () => {
      if (!taskFinished || pendingBinary > 0 || settled) return
      if (settleTimer) clearTimeout(settleTimer)
      // Node may deliver binary Blob after TaskFinished; wait briefly for trailing frames.
      settleTimer = setTimeout(() => {
        if (settled) return
        if (pendingBinary > 0) {
          tryComplete()
          return
        }
        if (chunks.length === 0) fail('JIANYING_LOCAL_TTS_AUDIO_MISSING')
        else succeed(Buffer.concat(chunks))
      }, 350)
    }
    /** @param {Buffer} buffer */
    const pushChunk = (buffer) => {
      if (!buffer.length) return
      chunks.push(buffer)
      if (taskFinished) tryComplete()
    }

    const onAbort = () => fail('JIANYING_LOCAL_TTS_CANCELLED', 499)
    signal?.addEventListener('abort', onAbort, { once: true })

    try {
      // Factory (not `new`) so tests can inject non-constructible stubs.
      socket = openWebSocket(wsUrl, {
        headers: {
          'User-Agent': `JianyingPro/5.9.0.11632 (Windows 10.0.19045; app_id:${APP_ID}; device_id:${deviceId})`,
        },
      })
    } catch {
      signal?.removeEventListener('abort', onAbort)
      fail('JIANYING_LOCAL_TTS_CONNECT_FAILED')
      return
    }
    const activeSocket = socket

    timeout = setTimeout(() => fail('JIANYING_LOCAL_TTS_TIMED_OUT', 504), 45_000)

    activeSocket.addEventListener('open', () => {
      const taskId = `ov_${cryptoRandom()}`
      activeSocket.send(JSON.stringify({
        app_id: APP_ID,
        appkey: APP_KEY,
        event: 'StartTask',
        namespace: 'TTS',
        task_id: taskId,
        message_id: `${taskId}_0`,
        payload: JSON.stringify({
          text: text.trim(),
          speaker: speakerId,
          audio_config: {
            format: 'ogg_opus',
            sample_rate: 24_000,
            bit_rate: 64_000,
          },
        }),
      }))
      activeSocket.send(JSON.stringify({
        appkey: APP_KEY,
        event: 'FinishTask',
        namespace: 'TTS',
      }))
    })

    activeSocket.addEventListener('message', (event) => {
      const data = event.data
      if (typeof data === 'string') {
        let parsed
        try {
          parsed = JSON.parse(data)
        } catch {
          fail('JIANYING_LOCAL_TTS_RESPONSE_INVALID')
          return
        }
        const eventName = parsed?.event
        if (eventName === 'TaskFailed') {
          fail('JIANYING_LOCAL_TTS_PROVIDER_FAILED')
          return
        }
        if (eventName === 'TaskFinished') {
          taskFinished = true
          tryComplete()
        }
        return
      }
      if (data instanceof ArrayBuffer) {
        pushChunk(Buffer.from(data))
        return
      }
      if (ArrayBuffer.isView(data)) {
        pushChunk(Buffer.from(data.buffer, data.byteOffset, data.byteLength))
        return
      }
      if (typeof Blob !== 'undefined' && data instanceof Blob) {
        pendingBinary += 1
        if (settleTimer) {
          clearTimeout(settleTimer)
          settleTimer = null
        }
        void data.arrayBuffer().then((/** @type {ArrayBuffer} */ buffer) => {
          pendingBinary -= 1
          pushChunk(Buffer.from(buffer))
          tryComplete()
        }, () => fail('JIANYING_LOCAL_TTS_RESPONSE_INVALID'))
        return
      }
      if (Buffer.isBuffer(data)) pushChunk(data)
    })

    activeSocket.addEventListener('error', () => {
      fail('JIANYING_LOCAL_TTS_CONNECT_FAILED')
    })
    activeSocket.addEventListener('close', () => {
      if (!settled && !taskFinished) {
        fail('JIANYING_LOCAL_TTS_CONNECT_FAILED')
      } else if (!settled && taskFinished) {
        tryComplete()
      }
    })
  }))

  await writeFile(outputPath, audioData, { flag: 'wx', mode: 0o600 })
  return { bytes: audioData.length, format: 'ogg_opus' }
}

const cryptoRandom = () => randomBytes(4).toString('hex')

/**
 * @param {{
 *   resolveIdentity?: typeof resolveJianyingLocalIdentity,
 *   synthesize?: typeof synthesizeJianyingLocalSpeech,
 * }} [options]
 */
export const createJianyingLocalTts = ({
  resolveIdentity = resolveJianyingLocalIdentity,
  synthesize = synthesizeJianyingLocalSpeech,
} = {}) => ({
  probe: async () => {
    const identity = await resolveIdentity()
    return {
      schema_version: 1,
      provider: 'jianying-local-tts',
      available: true,
      // Never echo raw device/iid to callers — only availability.
      identityPresent: Boolean(identity.deviceId && identity.installId),
    }
  },
  /**
   * @param {{text: string, speakerId: string, outputPath: string, signal?: AbortSignal}} input
   */
  synthesize: async (input) => {
    const identity = await resolveIdentity()
    return synthesize({ ...input, identity })
  },
})
