const sensitiveCreativeTextPattern =
  /(?:^\/[^\s]+|(?:\u8def\u5f84|\u76ee\u5f55|path|source|file)\s*\/[^\s]+|[A-Za-z]:[\\/]|\\\\|[A-Za-z][A-Za-z0-9+.-]{1,31}:\/\/|(?:data|mailto|javascript|blob|file|s3|gs|ssh|ftp|ftps|urn):[^\s]|\.{1,2}[\\/][^\s]+|\/(?:etc|home|users|var|tmp|root|private|mnt|media|volumes|workspace|app|data|opt|usr|proc|sys|dev|run|srv)(?:\/[^\s]*)?|\/(?:[^/\s]+\/)*[^/\s]+\.[A-Za-z0-9]{1,12}(?:[?#][^\s]*)?|\b(?:provider|model|api[_ -]?key|base[_ -]?url|credential|password|passwd|secret|client[_ -]?secret|access[_ -]?token|refresh[_ -]?token|private[_ -]?key)\s*[:=]|\b(?:authorization|bearer)(?:\s*[:=]\s*|\s+)[A-Za-z0-9._~+/-]{6,}|-----begin (?:rsa )?private key-----|\b(?:sk|rk|pk)-(?:live|test)?-?[a-z0-9_-]{6,}\b|\b(?:ghp|github_pat|xox[baprs])[_-][a-z0-9_-]{6,}\b)/iu

/** @param {string} value */
const containsSensitiveCreativeText = (value) => {
  let current = value
  for (let depth = 0; depth < 6; depth += 1) {
    if (sensitiveCreativeTextPattern.test(current)) return true
    if (!/%[0-9a-f]{2}/iu.test(current)) return false
    try {
      const decoded = decodeURIComponent(current.replace(/\+/gu, '%20'))
      if (decoded === current) return false
      current = decoded
    } catch {
      return true
    }
  }
  return sensitiveCreativeTextPattern.test(current)
}

/** @param {unknown} value @param {number} maximumLength @param {{trimmed?: boolean}} [options] */
export const isSafeCreativeText = (value, maximumLength, { trimmed = false } = {}) =>
  typeof value === 'string' && value.length > 0 && value.length <= maximumLength &&
  (!trimmed || value === value.trim()) && !/[\u0000-\u001f]/u.test(value) &&
  !containsSensitiveCreativeText(value)
