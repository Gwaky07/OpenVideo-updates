import { execFile, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)

/** @param {unknown} value */
const safeResourceId = (value) =>
  typeof value === 'string' && /^[a-z0-9][a-z0-9._-]{0,127}$/iu.test(value)

export class WorkbenchPreviewError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'WorkbenchPreviewError'
    this.code = code
  }
}

/** @param {{runner?: typeof spawnSync}} [options] */
export const createSyntheticPreviewProvider = ({ runner = spawnSync } = {}) => {
  /** @type {Buffer | null} */
  let cachedBytes = null

  /** @param {{resourceId: string}} input */
  return async ({ resourceId }) => {
    if (!safeResourceId(resourceId)) return null
    /** @param {Buffer} bytes */
    const toResource = (bytes) => ({
      size: bytes.length,
      contentType: 'video/mp4',
      etag: `"${resourceId}"`,
      /** @param {{start: number, end: number}} range */
      createStream: ({ start, end }) => new ReadableStream({
        start(controller) {
          controller.enqueue(bytes.subarray(start, end + 1))
          controller.close()
        },
      }),
    })
    if (cachedBytes) {
      return toResource(cachedBytes)
    }

    const workRoot = mkdtempSync(path.join(tmpdir(), 'openvideo-ui004-preview-'))
    const outputPath = path.join(workRoot, 'synthetic-preview.mp4')
    try {
      const result = /** @type {import('node:child_process').SpawnSyncReturns<string>} */ (runner(
        'ffmpeg',
        [
          '-n',
          '-hide_banner',
          '-loglevel',
          'error',
          '-f',
          'lavfi',
          '-i',
          'color=c=#10211b:s=360x640:r=24:d=6',
          '-f',
          'lavfi',
          '-i',
          'sine=frequency=440:sample_rate=48000:duration=6',
          '-shortest',
          '-vf',
          "drawbox=x=34:y=70:w=292:h=500:color=#1a3c30:t=fill,drawbox=x=48:y=86:w=264:h=468:color=#eaf4ee:t=fill,drawbox=x=48:y=86:w=264:h=168:color=#8de6bf:t=fill,drawbox=x=78+18*t:y=300:w=92:h=150:color=#45bd8d:t=fill,drawbox=x=190-10*t:y=330:w=76:h=96:color=#12372b:t=fill,drawbox=x=78:y=480:w=184:h=7:color=#b8d9ca:t=fill,drawbox=x=78:y=498:w=132:h=7:color=#d5e6de:t=fill",
          '-c:v',
          'libx264',
          '-preset',
          'ultrafast',
          '-pix_fmt',
          'yuv420p',
          '-c:a',
          'aac',
          '-movflags',
          '+faststart',
          outputPath,
        ],
        { encoding: 'utf8', windowsHide: true },
      ))
      if (result.status !== 0) throw new WorkbenchPreviewError('PREVIEW_RESOURCE_UNAVAILABLE')
      cachedBytes = readFileSync(outputPath)
      return toResource(cachedBytes)
    } catch (error) {
      if (error instanceof WorkbenchPreviewError) throw error
      throw new WorkbenchPreviewError('PREVIEW_RESOURCE_UNAVAILABLE')
    } finally {
      rmSync(workRoot, { recursive: true, force: true })
    }
  }
}

/** @param {string | null} header @param {number} size */
const parseByteRange = (header, size) => {
  if (!header) return null
  const match = /^bytes=(\d*)-(\d*)$/u.exec(header.trim())
  if (!match || (!match[1] && !match[2])) return false

  let start
  let end
  if (!match[1]) {
    const suffixLength = Number(match[2])
    if (!Number.isSafeInteger(suffixLength) || suffixLength <= 0) return false
    start = Math.max(0, size - suffixLength)
    end = size - 1
  } else {
    start = Number(match[1])
    end = match[2] ? Number(match[2]) : size - 1
  }
  if (
    !Number.isSafeInteger(start) ||
    !Number.isSafeInteger(end) ||
    start < 0 ||
    start >= size ||
    end < start
  ) {
    return false
  }
  return { start, end: Math.min(end, size - 1) }
}

const maxCandidateClipSeconds = 8
const candidateClipCacheTtlMs = 5 * 60_000
const candidateClipCacheMaxEntries = 96
/** @type {ReadonlyArray<readonly [string, readonly string[]]>} */
/** @type {ReadonlyArray<readonly [string, readonly string[]]>} */
const candidateClipVideoEncoders = Object.freeze([
  ['libopenh264', ['-b:v', '900k', '-maxrate', '1200k', '-bufsize', '2400k']],
  ['h264_mf', ['-b:v', '1200k']],
])

/**
 * @param {{
 *   ttlMs?: number,
 *   maxEntries?: number,
 *   now?: () => number,
 * }} [options]
 */
export const createCandidateClipResourceCache = ({
  ttlMs = candidateClipCacheTtlMs,
  maxEntries = candidateClipCacheMaxEntries,
  now = () => Date.now(),
} = {}) => {
  /** @type {Map<string, {expiresAt: number, resource: any}>} */
  const entries = new Map()
  /** @param {string} key */
  const purge = (key) => {
    const entry = entries.get(key)
    if (!entry) return
    if (entry.expiresAt > now()) return
    entries.delete(key)
  }
  const purgeExpired = () => {
    for (const key of [...entries.keys()]) purge(key)
  }
  return {
    /** @param {string} key */
    get(key) {
      purge(key)
      const entry = entries.get(key)
      if (!entry) return null
      entries.delete(key)
      entries.set(key, entry)
      return entry.resource
    },
    /** @param {string} key @param {any} resource */
    set(key, resource) {
      purgeExpired()
      if (entries.has(key)) entries.delete(key)
      entries.set(key, { expiresAt: now() + ttlMs, resource })
      while (entries.size > maxEntries) {
        const oldest = entries.keys().next().value
        if (oldest === undefined) break
        entries.delete(oldest)
      }
    },
    size() {
      purgeExpired()
      return entries.size
    },
  }
}

/**
 * Shares in-flight candidate encodes and bounds FFmpeg concurrency.  Resources
 * remain in the ephemeral memory cache; this queue never writes permanent clips.
 * @param {{cache: ReturnType<typeof createCandidateClipResourceCache>, maxConcurrent?: number}} input
 */
export const createCandidateClipResourceLoader = ({ cache, maxConcurrent = 2 }) => {
  if (!Number.isSafeInteger(maxConcurrent) || maxConcurrent < 1) {
    throw new TypeError('maxConcurrent must be a positive integer')
  }
  /** @type {Map<string, Promise<any>>} */
  const inFlight = new Map()
  /** @type {Array<() => void>} */
  const pending = []
  let running = 0
  const schedule = () => {
    while (running < maxConcurrent && pending.length) {
      running += 1
      pending.shift()?.()
    }
  }
  return {
    /** @param {string} key @param {() => Promise<any>} create */
    async getOrCreate(key, create) {
      const cached = cache.get(key)
      if (cached) return cached
      const existing = inFlight.get(key)
      if (existing) return existing
      const work = new Promise((resolve, reject) => {
        pending.push(() => {
          Promise.resolve()
            .then(create)
            .then((resource) => {
              if (resource) cache.set(key, resource)
              resolve(resource)
            }, reject)
            .finally(() => {
              running -= 1
              inFlight.delete(key)
              schedule()
            })
        })
        schedule()
      })
      inFlight.set(key, work)
      return work
    },
  }
}

/**
 * Build an ephemeral browser-compatible MP4 clip for one storyboard candidate.
 * Temp files are removed before the resource is returned; no permanent Scene-*.mp4.
 * Scenes longer than 8s are truncated for card preview (not rejected).
 * @param {{
 *   sourcePath: string,
 *   start: number,
 *   end: number,
 *   candidateId: string,
 *   ffmpegPath?: string | null,
 *   runner?: (command: string, args: string[], options: Record<string, unknown>) => unknown,
 * }} input
 */
export const createEphemeralCandidateClipResource = async ({
  sourcePath,
  start,
  end,
  candidateId,
  ffmpegPath = 'ffmpeg',
  runner = (command, args, options) => execFileAsync(command, args, options),
}) => {
  if (
    typeof sourcePath !== 'string' ||
    !path.isAbsolute(sourcePath) ||
    typeof candidateId !== 'string' ||
    !safeResourceId(candidateId) ||
    !Number.isFinite(start) ||
    !Number.isFinite(end) ||
    start < 0 ||
    end <= start
  ) {
    throw new WorkbenchPreviewError('CANDIDATE_CLIP_UNAVAILABLE')
  }
  const duration = Number(Math.min(end - start, maxCandidateClipSeconds).toFixed(3))
  const workRoot = mkdtempSync(path.join(tmpdir(), 'openvideo-candidate-clip-'))
  const outputPath = path.join(workRoot, 'clip.mp4')
  try {
    const baseArgs = [
      '-hide_banner',
      '-loglevel',
      'error',
      '-ss',
      String(start),
      '-i',
      sourcePath,
      '-t',
      String(duration),
      '-map',
      '0:v:0',
      '-map',
      '0:a?',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-avoid_negative_ts',
      'make_zero',
      '-reset_timestamps',
      '1',
      '-movflags',
      '+faststart',
      '-y',
    ]
    let encoded = false
    for (const [encoder, encoderArgs] of candidateClipVideoEncoders) {
      try {
        const result = await runner(ffmpegPath || 'ffmpeg', [
          ...baseArgs,
          '-c:v',
          encoder,
          ...encoderArgs,
          outputPath,
        ], {
          encoding: 'utf8',
          windowsHide: true,
          timeout: 120_000,
        })
        const processResult = /** @type {{status?: number} | null | undefined} */ (result)
        if (processResult?.status === undefined || processResult.status === 0) {
          encoded = true
          break
        }
      } catch {
        // Try the Windows MediaFoundation encoder after an unavailable codec.
      }
    }
    if (!encoded) throw new WorkbenchPreviewError('CANDIDATE_CLIP_UNAVAILABLE')
    const bytes = readFileSync(outputPath)
    if (!bytes.length) throw new WorkbenchPreviewError('CANDIDATE_CLIP_UNAVAILABLE')
    const digest = createHash('sha256').update(bytes).digest('hex').slice(0, 16)
    return {
      size: bytes.length,
      contentType: 'video/mp4',
      etag: `"${candidateId}-${digest}"`,
      /** @param {{start: number, end: number}} range */
      createStream: ({ start: rangeStart, end: rangeEnd }) => new ReadableStream({
        start(controller) {
          controller.enqueue(bytes.subarray(rangeStart, rangeEnd + 1))
          controller.close()
        },
      }),
    }
  } catch (error) {
    if (error instanceof WorkbenchPreviewError) throw error
    throw new WorkbenchPreviewError('CANDIDATE_CLIP_UNAVAILABLE')
  } finally {
    rmSync(workRoot, { recursive: true, force: true })
  }
}

/**
 * Synthetic candidate clip for local acceptance without real media.
 * @param {{candidateId: string, runner?: typeof spawnSync}} input
 */
export const createSyntheticCandidateClipResource = async ({
  candidateId,
  runner = spawnSync,
}) => {
  if (!safeResourceId(candidateId)) return null
  const provider = createSyntheticPreviewProvider({ runner })
  return provider({ resourceId: `candidate-${candidateId}` })
}

const syntheticCandidatePosterJpeg = Buffer.from(
  '/9j/4AAQSkZJRgABAQAAAQABAAD/2wAAAAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgI/wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAX/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAf/2gAIAQEAAQUCf//Z',
  'base64',
)

/**
 * Tiny JPEG stand-in so storyboard cards can paint a still before the clip encodes.
 * @param {{candidateId: string}} input
 */
export const createSyntheticCandidatePosterResource = async ({ candidateId }) => {
  if (!safeResourceId(candidateId)) return null
  return {
    bytes: syntheticCandidatePosterJpeg,
    contentType: 'image/jpeg',
    etag: `"poster-${candidateId}"`,
  }
}

/**
 * @param {{
 *   resource: {
 *     bytes?: Uint8Array,
 *     size?: number,
 *     contentType: string,
 *     etag: string,
 *     close?: () => void | Promise<void>,
 *     createStream?: (range: {start: number, end: number}) => ReadableStream
 *   },
 *   rangeHeader: string | null,
 *   method?: string,
 *   contentDisposition?: string
 *   cacheControl?: string,
 *   ifNoneMatch?: string | null
 * }} input
 */
export const createPreviewMediaResponse = ({
  resource,
  rangeHeader,
  method = 'GET',
  contentDisposition,
  cacheControl = 'private, no-store',
  ifNoneMatch = null,
}) => {
  const legacyBytes = resource.bytes ? Buffer.from(resource.bytes) : null
  const size = resource.size ?? legacyBytes?.length
  if (typeof size !== 'number' || !Number.isSafeInteger(size) || size < 0) {
    throw new WorkbenchPreviewError('PREVIEW_RESOURCE_UNAVAILABLE')
  }
  const streamFactory = resource.createStream
  const closeUnused = () => {
    if (typeof resource.close === 'function') void resource.close()
  }
  if (!streamFactory && !legacyBytes) {
    throw new WorkbenchPreviewError('PREVIEW_RESOURCE_UNAVAILABLE')
  }
  /** @param {{start: number, end: number}} selectedRange */
  const openBody = (selectedRange) => {
    if (streamFactory) return streamFactory(selectedRange)
    if (legacyBytes) return legacyBytes.subarray(selectedRange.start, selectedRange.end + 1)
    throw new WorkbenchPreviewError('PREVIEW_RESOURCE_UNAVAILABLE')
  }
  const range = parseByteRange(rangeHeader, size)
  const headers = {
    'accept-ranges': 'bytes',
    'cache-control': cacheControl,
    ...(contentDisposition ? { 'content-disposition': contentDisposition } : {}),
    'content-type': resource.contentType,
    'cross-origin-resource-policy': 'same-origin',
    etag: resource.etag,
    'x-content-type-options': 'nosniff',
  }

  /** @param {string} value */
  const normalizedEtag = (value) => value.trim().replace(/^W\//u, '')
  const etagMatches = typeof ifNoneMatch === 'string' && ifNoneMatch
    .split(',')
    .some((candidate) => candidate.trim() === '*' || normalizedEtag(candidate) === normalizedEtag(resource.etag))
  if (etagMatches) {
    closeUnused()
    return new Response(null, { status: 304, headers })
  }

  if (range === false) {
    closeUnused()
    return new Response(null, {
      status: 416,
      headers: { ...headers, 'content-range': `bytes */${size}` },
    })
  }
  if (range) {
    if (method === 'HEAD') closeUnused()
    const body = method === 'HEAD' ? null : openBody(range)
    return new Response(body, {
      status: 206,
      headers: {
        ...headers,
        'content-length': String(range.end - range.start + 1),
        'content-range': `bytes ${range.start}-${range.end}/${size}`,
      },
    })
  }
  if (method === 'HEAD') closeUnused()
  const body = method === 'HEAD' ? null : openBody({ start: 0, end: size - 1 })
  return new Response(body, {
    status: 200,
    headers: { ...headers, 'content-length': String(size) },
  })
}
