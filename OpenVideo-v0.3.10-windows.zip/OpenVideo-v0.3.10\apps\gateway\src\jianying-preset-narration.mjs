import { spawn } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { mkdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import { isAbsolute, join, resolve } from 'node:path'

import { isJianyingPresetVoiceId } from './jianying-tts-presets.mjs'
import { JianyingLocalTtsError } from './jianying-local-tts.mjs'

/** @param {string} value */
const digest = (value) => createHash('sha256').update(value).digest('hex')

/**
 * @param {string | {command: string, prefixArgs?: string[]}} ffmpegPath
 * @param {string[]} args
 */
const spawnFfmpeg = (ffmpegPath, args) => {
  const command = typeof ffmpegPath === 'string' ? ffmpegPath : ffmpegPath.command
  const prefixArgs = typeof ffmpegPath === 'string' ? [] : (ffmpegPath.prefixArgs ?? [])
  return spawn(command, [...prefixArgs, ...args], { stdio: 'ignore', windowsHide: true })
}
/**
 * @param {{
 *   ffmpegPath?: string | {command: string, prefixArgs?: string[]},
 *   inputPath: string,
 *   outputPath: string,
 *   signal?: AbortSignal,
 * }} input
 */
const convertToWav = ({ ffmpegPath = 'ffmpeg', inputPath, outputPath, signal }) =>
  new Promise((resolvePromise, reject) => {
    const child = spawnFfmpeg(
      ffmpegPath,
      ['-y', '-i', inputPath, '-acodec', 'pcm_s16le', '-ar', '24000', '-ac', '1', outputPath],
    )
    let settled = false
    /** @param {Error | null} error */
    const finish = (error) => {
      if (settled) return
      settled = true
      signal?.removeEventListener('abort', onAbort)
      error ? reject(error) : resolvePromise(undefined)
    }
    const onAbort = () => {
      child.kill('SIGKILL')
      finish(new JianyingLocalTtsError('JIANYING_LOCAL_TTS_CANCELLED', 499))
    }
    signal?.addEventListener('abort', onAbort, { once: true })
    child.once('error', () => finish(new JianyingLocalTtsError('JIANYING_LOCAL_TTS_CONVERT_FAILED')))
    child.once('close', (code) => finish(
      code === 0 ? null : new JianyingLocalTtsError('JIANYING_LOCAL_TTS_CONVERT_FAILED'),
    ))
    if (signal?.aborted) onAbort()
  })

/**
 * @param {{
 *   ffmpegPath?: string | {command: string, prefixArgs?: string[]},
 *   listPath: string,
 *   outputPath: string,
 *   signal?: AbortSignal,
 * }} input
 */
const concatWav = ({ ffmpegPath = 'ffmpeg', listPath, outputPath, signal }) =>
  new Promise((resolvePromise, reject) => {
    const child = spawnFfmpeg(
      ffmpegPath,
      ['-y', '-f', 'concat', '-safe', '0', '-i', listPath, '-c', 'copy', outputPath],
    )
    let settled = false
    /** @param {Error | null} error */
    const finish = (error) => {
      if (settled) return
      settled = true
      signal?.removeEventListener('abort', onAbort)
      error ? reject(error) : resolvePromise(undefined)
    }
    const onAbort = () => {
      child.kill('SIGKILL')
      finish(new JianyingLocalTtsError('JIANYING_LOCAL_TTS_CANCELLED', 499))
    }
    signal?.addEventListener('abort', onAbort, { once: true })
    child.once('error', () => finish(new JianyingLocalTtsError('JIANYING_LOCAL_TTS_CONVERT_FAILED')))
    child.once('close', (code) => finish(
      code === 0 ? null : new JianyingLocalTtsError('JIANYING_LOCAL_TTS_CONVERT_FAILED'),
    ))
    if (signal?.aborted) onAbort()
  })

/** @param {string} path */
const existingNonEmptyFile = async (path) => {
  try {
    const metadata = await stat(path)
    return metadata.isFile() && metadata.size > 0
  } catch {
    return false
  }
}
/**
 * Shared Jianying-preset narration store for Preview + Jianying.
 * Stable keys include voiceId + speakerId so switching presets never reuses stale audio.
 *
 * @param {{
 *   presetsService: {get: (id: string) => Promise<{id: string, speakerId: string, label: string, updatedAt?: string}>},
 *   localTts: {synthesize: Function},
 *   dataRoot: string,
 *   ffmpegPath?: string | {command: string, prefixArgs?: string[]},
 * }} deps
 */
export const createJianyingPresetNarration = ({
  presetsService,
  localTts,
  dataRoot,
  ffmpegPath = 'ffmpeg',
}) => {
  if (typeof dataRoot !== 'string' || !dataRoot || !isAbsolute(dataRoot)) {
    throw new Error('jianying_preset_narration_data_root_invalid')
  }

  /**
   * @param {{
   *   projectId: string,
   *   voiceId: string,
   *   segments: Array<{sentenceId?: string, sentence_id?: string, text: string}>,
   *   signal?: AbortSignal,
   * }} input
   */
  const resolveSegmentAssets = async (input) => {
    if (!isJianyingPresetVoiceId(input.voiceId)) {
      throw new JianyingLocalTtsError('JIANYING_TTS_PRESET_NOT_FOUND', 404)
    }
    if (typeof input.projectId !== 'string' || !input.projectId) {
      throw new JianyingLocalTtsError('JIANYING_LOCAL_TTS_INPUT_INVALID', 400)
    }
    const preset = await presetsService.get(input.voiceId)
    const normalized = input.segments.map((segment) => {
      const sentenceId = segment.sentenceId || segment.sentence_id
      if (typeof sentenceId !== 'string' || typeof segment.text !== 'string') {
        throw new JianyingLocalTtsError('JIANYING_LOCAL_TTS_INPUT_INVALID', 400)
      }
      return { sentenceId, text: segment.text }
    })
    const fingerprint = digest([
      input.voiceId,
      preset.speakerId,
      preset.updatedAt ?? '',
      ...normalized.map((segment) => `${segment.sentenceId}\u0000${segment.text}`),
    ].join('\u0001'))
    const assetId = `jytts_${fingerprint.slice(0, 24)}`
    const assetRoot = resolve(
      dataRoot,
      'jianying-preset-tts',
      input.projectId,
      input.voiceId,
      fingerprint.slice(0, 32),
    )
    await mkdir(assetRoot, { recursive: true, mode: 0o700 })

    const output = []
    for (const [index, segment] of normalized.entries()) {
      input.signal?.throwIfAborted()
      const audioId = `audio-${digest([
        input.voiceId,
        preset.speakerId,
        segment.sentenceId,
        segment.text,
      ].join('\u0000')).slice(0, 24)}`
      const outputPath = resolve(assetRoot, `${String(index + 1).padStart(3, '0')}-${audioId}.wav`)
      const originalPath = resolve(assetRoot, `${String(index + 1).padStart(3, '0')}-${audioId}.ogg`)
      let segmentPath = (await existingNonEmptyFile(outputPath))
        ? outputPath
        : (await existingNonEmptyFile(originalPath))
            ? originalPath
            : null
      if (!segmentPath) {
        const oggPath = `${originalPath}.${randomUUID()}.tmp`
        const wavTmp = `${outputPath}.${randomUUID()}.tmp`
        try {
          await localTts.synthesize({
            text: segment.text,
            speakerId: preset.speakerId,
            outputPath: oggPath,
            signal: input.signal,
          })
          try {
            await convertToWav({
              ffmpegPath,
              inputPath: oggPath,
              outputPath: wavTmp,
              signal: input.signal,
            })
            await rename(wavTmp, outputPath)
            segmentPath = outputPath
          } catch (error) {
            const errorCode = error && typeof error === 'object' && 'code' in error
              ? /** @type {{ code?: unknown }} */ (error).code
              : undefined
            if (
              errorCode === 'JIANYING_LOCAL_TTS_CONVERT_FAILED' &&
              await existingNonEmptyFile(oggPath)
            ) {
              await rename(oggPath, originalPath)
              segmentPath = originalPath
            } else {
              throw error
            }
          }
        } finally {
          await rm(oggPath, { force: true }).catch(() => {})
          await rm(wavTmp, { force: true }).catch(() => {})
        }
      }
      output.push({
        sentenceId: segment.sentenceId,
        audioId,
        path: segmentPath,
      })
    }

    return {
      assetId,
      assetRoot,
      fingerprint,
      segments: output,
    }
  }

  /**
   * @param {{
   *   projectId: string,
   *   voiceId: string,
   *   segments: Array<{sentenceId?: string, sentence_id?: string, text: string}>,
   *   signal?: AbortSignal,
   * }} input
   */
  const resolveBundle = async (input) => {
    const { assetId, assetRoot, segments: output } = await resolveSegmentAssets(input)
    const narrationPath = resolve(assetRoot, 'narration.wav')
    if (!(await existingNonEmptyFile(narrationPath))) {
      const listPath = join(assetRoot, 'concat.txt')
      const narrationTmp = `${narrationPath}.${randomUUID()}.tmp`
      try {
        await writeFile(
          listPath,
          output.map((segment) => `file '${String(segment.path).replace(/'/gu, "'\\''")}'`).join('\n'),
          'utf8',
        )
        await concatWav({
          ffmpegPath,
          listPath,
          outputPath: narrationTmp,
          signal: input.signal,
        })
        await rename(narrationTmp, narrationPath)
      } finally {
        await rm(narrationTmp, { force: true }).catch(() => {})
      }
    }

    return {
      assetId,
      narrationPath,
      segments: output,
      // Shared store — do not delete after Preview/Jianying jobs.
      cleanupRoot: null,
    }
  }

  return {
    isVoiceId: isJianyingPresetVoiceId,
    resolveBundle,
    /**
     * Compatibility wrapper used by Jianying voiceover provider.
     * @param {{
     *   projectId: string,
     *   jobId?: string,
     *   voiceId: string,
     *   segments: Array<{sentenceId?: string, sentence_id?: string, text: string}>,
     *   jobRoot?: string,
     *   signal?: AbortSignal,
     * }} input
     */
    async resolveSegments(input) {
      const bundle = await resolveSegmentAssets(input)
      return bundle.segments
    },
  }
}
