[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [switch]$Full
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) {
    $RepositoryRoot = Split-Path -Parent $PSScriptRoot
}
$root = [IO.Path]::GetFullPath($RepositoryRoot)
$pnpmCommand = Get-Command pnpm.cmd -ErrorAction SilentlyContinue
$pnpm = if ($pnpmCommand) { $pnpmCommand.Source } else { (Get-Command corepack.cmd -ErrorAction Stop).Source }

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [scriptblock]$Action
    )
    Write-Host "==> $Name" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Action
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

Push-Location $root
try {
    Invoke-Checked 'Creative planning contracts and A/B policy' {
        & node --test `
            'apps/gateway/test/creative-knowledge.test.mjs' `
            'apps/gateway/test/creative-shadow.test.mjs' `
            'apps/gateway/test/creative-ab-evaluation.test.mjs' `
            'apps/gateway/test/creative-ab-receipts.test.mjs' `
            'apps/gateway/test/director.test.mjs' `
            'apps/gateway/test/server.test.mjs'
    }
    Invoke-Checked 'Creative automatic continuation and legacy packaging regression' {
        & node --test --test-concurrency=4 `
            'apps/gateway/test/workbench-job-coordinator.test.mjs'
    }
    Invoke-Checked 'Gateway typecheck' {
        if ($pnpmCommand) {
            & $pnpm --filter '@openvideo/gateway' typecheck
        } else {
            & $pnpm pnpm --filter '@openvideo/gateway' typecheck
        }
    }
    Invoke-Checked 'Repository lint' {
        if ($pnpmCommand) { & $pnpm lint } else { & $pnpm pnpm lint }
    }
    if ($Full) {
        Invoke-Checked 'Repository build' {
            if ($pnpmCommand) { & $pnpm build } else { & $pnpm pnpm build }
        }
        Invoke-Checked 'Repository tests' {
            if ($pnpmCommand) { & $pnpm test } else { & $pnpm pnpm test }
        }
    }
}
finally {
    Pop-Location
}

Write-Host 'OpenVideo Creative Planning regression checks passed.' -ForegroundColor Green
