import { randomUUID } from 'node:crypto'
import { existsSync, realpathSync } from 'node:fs'
import { chmod, copyFile, link, mkdir, open, readFile, rename, rm, stat } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  createReferenceTemplateReviewDecision,
  createRevisedReferenceTemplateDraft,
  preflightReferenceTemplateDraft,
  ReferenceTemplateContractError,
} from './reference-template-contracts.mjs'
import {
  assertReferenceTemplateWorkflowRecord,
  isReferenceTemplateWorkflowRecord,
  toReferenceTemplatePublicDetail,
  toReferenceTemplatePublicSummary,
} from './reference-template-workflow-contracts.mjs'
import { securePrivateRuntimeRoot } from './local-runtime.mjs'

const schemaVersion = 2
const legacySchemaVersion = 1
const repositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const activeOwnerTokens = new Set()
const transientWindowsCodes = new Set(['EPERM', 'EBUSY', 'EACCES'])

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} error */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error
  ? /** @type {{code?: unknown}} */ (error).code
  : undefined
/** @param {number} milliseconds */
const delay = (milliseconds) => new Promise((resolveDelay) => setTimeout(resolveDelay, milliseconds))
/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {unknown} value */
const digest = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value)
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  /** @param {string} value */
  const canonical = (value) => existsSync(value) ? realpathSync.native(value) : resolve(value)
  const fragment = relative(canonical(parent), canonical(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}

export class ReferenceTemplateRepositoryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'ReferenceTemplateRepositoryError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {unknown} */
const normalizeDocument = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return value
  const document = /** @type {Record<string, any>} */ (value)
  if (document.schema_version === schemaVersion) return document
  if (document.schema_version !== legacySchemaVersion || !Array.isArray(document.records)) {
    return document
  }
  const migrated = clone(document)
  migrated.schema_version = schemaVersion
  for (let index = 0; index < migrated.records.length; index += 1) {
    const record = migrated.records[index]
    const current = { ...record, contractVersion: 2 }
    if (isReferenceTemplateWorkflowRecord(current)) {
      migrated.records[index] = current
      continue
    }
    const historical = { ...record, contractVersion: 1 }
    if (!isReferenceTemplateWorkflowRecord(historical)) return document
    migrated.records[index] = historical
  }
  return migrated
}

/** @param {unknown} value */
const validDocument = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const document = /** @type {Record<string, any>} */ (value)
  return document.schema_version === schemaVersion &&
    Array.isArray(document.records) &&
    document.records.every(isReferenceTemplateWorkflowRecord) &&
    new Set(document.records.map((/** @type {Record<string, any>} */ record) =>
      record.referenceTemplateId)).size === document.records.length
}

/** @param {string} source @param {string} destination @param {number} [maximumAttempts] @param {typeof rename} [renameFile] */
const renameWithTransientRetries = async (
  source,
  destination,
  maximumAttempts = 20,
  renameFile = rename,
) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    try {
      await renameFile(source, destination)
      return
    } catch (error) {
      if (
        !transientWindowsCodes.has(String(errorCode(error))) ||
        attempt + 1 >= maximumAttempts
      ) throw error
      await delay(10)
    }
  }
}

/** @param {string} path @param {boolean} [force] @param {number} [maximumAttempts] @param {typeof rm} [removeFile] */
const removeWithTransientRetries = async (
  path,
  force = false,
  maximumAttempts = 20,
  removeFile = rm,
) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    try {
      await removeFile(path, { force })
      return true
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return true
      if (
        !transientWindowsCodes.has(String(errorCode(error))) ||
        attempt + 1 >= maximumAttempts
      ) throw error
      await delay(10)
    }
  }
  return false
}

/** @param {string} path @param {unknown} document @param {boolean} [preservePrimary] @param {{renameFile?: typeof rename, removeFile?: typeof rm}} [operations] */
const writeAtomic = async (path, document, preservePrimary = true, operations = {}) => {
  const temporary = `${path}.${randomUUID()}.tmp`
  /** @type {import('node:fs/promises').FileHandle | null} */
  let handle = null
  try {
    handle = await open(temporary, 'wx', 0o600)
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
    await handle.close()
    handle = null
    if (preservePrimary) {
      try {
        await copyFile(path, `${path}.bak`)
        await chmod(`${path}.bak`, 0o600).catch(() => {})
      } catch (error) {
        if (errorCode(error) !== 'ENOENT') throw error
      }
    }
    await renameWithTransientRetries(temporary, path, 20, operations.renameFile)
    await chmod(path, 0o600).catch(() => {})
  } catch (error) {
    await handle?.close().catch(() => {})
    await removeWithTransientRetries(temporary, true, 20, operations.removeFile).catch(() => false)
    throw error
  }
}

/** @param {string} path @param {boolean} allowCreate @param {{renameFile?: typeof rename, removeFile?: typeof rm}} [operations] */
const readDocument = async (path, allowCreate, operations = {}) => {
  let primaryError
  try {
    const primary = /** @type {Record<string, any>} */ (
      normalizeDocument(JSON.parse(await readFile(path, 'utf8')))
    )
    if (!validDocument(primary)) throw new Error('invalid_primary')
    return primary
  } catch (error) {
    primaryError = error
  }
  let backupError
  try {
    const backup = /** @type {Record<string, any>} */ (
      normalizeDocument(JSON.parse(await readFile(`${path}.bak`, 'utf8')))
    )
    if (!validDocument(backup)) throw new Error('invalid_backup')
    await writeAtomic(path, backup, false, operations)
    return backup
  } catch (error) {
    backupError = error
  }
  if (
    allowCreate &&
    errorCode(primaryError) === 'ENOENT' &&
    errorCode(backupError) === 'ENOENT'
  ) return { schema_version: schemaVersion, records: [] }
  throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_STORAGE_CORRUPT')
}

/** @param {string} lockPath @param {string} expectedOwner @param {typeof rm} [removeFile] */
const removeOwnedLock = async (lockPath, expectedOwner, removeFile = rm) => {
  const currentOwner = await readFile(lockPath, 'utf8').catch((error) => {
    if (errorCode(error) === 'ENOENT') return null
    throw error
  })
  if (currentOwner === null || currentOwner !== expectedOwner) return true
  return removeWithTransientRetries(lockPath, false, 20, removeFile)
}

/** @param {string} lockPath @param {{openLockFile?: typeof open, linkLockFile?: typeof link, removeFile?: typeof rm}} [operations] */
const acquireLock = async (lockPath, operations = {}) => {
  const token = randomUUID()
  const owner = `${JSON.stringify({ token, pid: process.pid })}\n`
  for (let attempt = 0; attempt < 500; attempt += 1) {
    const temporaryLockPath = `${lockPath}.${token}.${attempt}.claim`
    let claimed = false
    /** @type {import('node:fs/promises').FileHandle | null} */
    let handle = null
    try {
      handle = await (operations.openLockFile ?? open)(temporaryLockPath, 'wx', 0o600)
      await handle.writeFile(owner, 'utf8')
      await handle.sync()
      await handle.close()
      handle = null
      await (operations.linkLockFile ?? link)(temporaryLockPath, lockPath)
      claimed = true
      activeOwnerTokens.add(token)
      await removeWithTransientRetries(
        temporaryLockPath,
        true,
        20,
        operations.removeFile,
      )
      return { owner, token }
    } catch (error) {
      await handle?.close().catch(() => {})
      await removeWithTransientRetries(
        temporaryLockPath,
        true,
        20,
        operations.removeFile,
      ).catch(() => false)
      if (claimed) {
        await removeOwnedLock(lockPath, owner, operations.removeFile).catch(() => false)
      }
      activeOwnerTokens.delete(token)
      if (errorCode(error) !== 'EEXIST') throw error
      const observedOwner = await readFile(lockPath, 'utf8').catch(() => null)
      const metadata = await stat(lockPath).catch(() => null)
      let processAlive = true
      let parsedPid = null
      let parsedToken = null
      let malformed = false
      try {
        const parsed = JSON.parse(observedOwner ?? '')
        if (
          !Number.isSafeInteger(parsed?.pid) ||
          parsed.pid < 1 ||
          typeof parsed.token !== 'string' ||
          parsed.token.length === 0
        ) throw new Error('invalid_lock')
        parsedPid = parsed.pid
        parsedToken = parsed.token
        process.kill(parsed.pid, 0)
      } catch (processError) {
        malformed = parsedPid === null || parsedToken === null
        processAlive = errorCode(processError) !== 'ESRCH'
      }
      const orphanedCurrentProcess =
        parsedPid === process.pid &&
        parsedToken !== null &&
        !activeOwnerTokens.has(parsedToken)
      if (
        observedOwner &&
        metadata &&
        (
          orphanedCurrentProcess ||
          (
            (!processAlive || malformed) &&
            Date.now() - metadata.mtimeMs > 5 * 60_000
          )
        ) &&
        await readFile(lockPath, 'utf8').catch(() => null) === observedOwner
      ) {
        if (await removeOwnedLock(lockPath, observedOwner, operations.removeFile)) continue
      }
      await delay(10)
    }
  }
  throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_STORAGE_LOCKED', 503)
}

/** @param {string} lockPath @param {{owner: string, token: string}} lock @param {typeof rm} [removeFile] */
const releaseLock = async (lockPath, lock, removeFile = rm) => {
  try {
    await removeOwnedLock(lockPath, lock.owner, removeFile)
  } finally {
    activeOwnerTokens.delete(lock.token)
  }
}

/** @param {unknown} error */
const mapReviewError = (error) => {
  if (!(error instanceof ReferenceTemplateContractError)) return error
  if (error.code === 'invalid_template_review_command') {
    return new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_REVIEW_INVALID', 400)
  }
  if (
    error.code === 'template_revision_limit_reached' ||
    error.code === 'revision_decision_mismatch'
  ) {
    return new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_REVISION_CONFLICT', 409)
  }
  return error
}

/**
 * @param {{
 *  dataRoot: string,
 *  securePrivateRoot?: (root: string) => Promise<void>,
 *  now?: () => Date,
 *  createId?: () => string,
 *  storageOperations?: {
 *    openLockFile?: typeof open,
 *    linkLockFile?: typeof link,
 *    renameFile?: typeof rename,
 *    removeFile?: typeof rm,
 *  },
 * }} options
 */
export const createReferenceTemplateRepository = async ({
  dataRoot,
  securePrivateRoot = securePrivateRuntimeRoot,
  now = () => new Date(),
  createId = () => `reference-workflow-${randomUUID()}`,
  storageOperations = {},
}) => {
  if (!isAbsolute(dataRoot) || inside(repositoryRoot, dataRoot)) {
    throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_DATA_ROOT_UNSAFE')
  }
  await mkdir(dataRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(dataRoot)
  const path = resolve(dataRoot, 'reference-templates.json')
  const lockPath = `${path}.lock`
  /** @type {Promise<unknown>} */
  let queue = Promise.resolve()

  /** @template T @param {(document: {schema_version: number, records: Record<string, any>[]}) => Promise<{document: {schema_version: number, records: Record<string, any>[]}, result: T}>} operation */
  const mutate = (operation) => {
    const run = async () => {
      const lock = await acquireLock(lockPath, storageOperations)
      try {
        const document = /** @type {{schema_version: number, records: Record<string, any>[]}} */ (
          await readDocument(path, true, storageOperations)
        )
        const output = await operation(clone(document))
        if (!validDocument(output.document)) {
          throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_RECORD_INVALID')
        }
        await writeAtomic(path, output.document, true, storageOperations)
        return clone(output.result)
      } finally {
        await releaseLock(lockPath, lock, storageOperations.removeFile)
      }
    }
    const result = queue.then(run, run)
    queue = result.then(() => undefined, () => undefined)
    return result
  }

  const read = async () => {
    const lock = await acquireLock(lockPath, storageOperations)
    try {
      const document = await readDocument(path, true, storageOperations)
      const persisted = await readFile(path, 'utf8').catch(() => null)
      if (
        persisted === null ||
        JSON.stringify(JSON.parse(persisted)) !== JSON.stringify(document)
      ) {
        await writeAtomic(path, document, true, storageOperations)
      }
      return clone(document)
    } finally {
      await releaseLock(lockPath, lock, storageOperations.removeFile)
    }
  }

  await read()

  /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string}} input */
  const validateOwnerIdentity = (input) => {
    if (
      !identifier(input?.projectId) ||
      !identifier(input?.jobId) ||
      !identifier(input?.attemptId) ||
      !Number.isSafeInteger(input?.generation) ||
      input.generation < 1 ||
      !digest(input?.inputFingerprint)
    ) throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_OWNER_INVALID', 400)
  }
  /** @param {{projectId: string, referenceTemplateId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string}} input */
  const validateOwner = (input) => {
    validateOwnerIdentity(input)
    if (!identifier(input?.referenceTemplateId)) {
      throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_OWNER_INVALID', 400)
    }
  }

  return {
    async probeAvailability() {
      await read()
      return { available: true, state: 'ready', code: null }
    },
    /** @param {{projectId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string, generated: Record<string, any>}} input */
    async stageGenerated(input) {
      validateOwnerIdentity(input)
      return mutate(async (document) => {
        const createdAt = now().toISOString()
        const candidate = assertReferenceTemplateWorkflowRecord({
          referenceTemplateId: createId(),
          contractVersion: 2,
          projectId: input.projectId,
          ownerJobId: input.jobId,
          ownerAttemptId: input.attemptId,
          ownerGeneration: input.generation,
          ownerInputFingerprint: input.inputFingerprint,
          publication: 'staged',
          revision: 1,
          status: 'generated',
          templateSelectionRequest: clone(input.generated.templateSelectionRequest),
          adapterRequest: clone(input.generated.adapterRequest),
          analysis: clone(input.generated.analysis),
          draft: clone(input.generated.draft),
          preflight: clone(input.generated.preflight),
          decision: null,
          createdAt,
          updatedAt: createdAt,
        })
        const existing = document.records.find((record) =>
          record.projectId === input.projectId &&
          record.ownerInputFingerprint === input.inputFingerprint &&
          record.draft.draft_id === candidate.draft.draft_id)
        if (existing) {
          if (existing.publication !== 'committed') {
            if (
              existing.ownerJobId !== input.jobId ||
              existing.ownerAttemptId !== input.attemptId ||
              existing.ownerGeneration !== input.generation
            ) {
              throw new ReferenceTemplateRepositoryError(
                'REFERENCE_TEMPLATE_PENDING_CONFLICT',
                409,
              )
            }
          }
          return {
            document,
            result: {
              referenceTemplateId: existing.referenceTemplateId,
              publication: existing.publication,
              owned: existing.publication !== 'committed',
            },
          }
        }
        document.records.push(candidate)
        return {
          document,
          result: {
            referenceTemplateId: candidate.referenceTemplateId,
            publication: 'staged',
            owned: true,
          },
        }
      })
    },
    /** @param {{projectId: string, referenceTemplateId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string}} input */
    async getStage(input) {
      validateOwner(input)
      const document = await read()
      const record = document.records.find((/** @type {Record<string, any>} */ entry) =>
        entry.projectId === input.projectId &&
        entry.referenceTemplateId === input.referenceTemplateId &&
        entry.ownerJobId === input.jobId &&
        entry.ownerAttemptId === input.attemptId &&
        entry.ownerGeneration === input.generation &&
        entry.ownerInputFingerprint === input.inputFingerprint)
      return record
        ? {
            referenceTemplateId: record.referenceTemplateId,
            publication: record.publication,
            owned: true,
          }
        : null
    },
    /** @param {{projectId: string, referenceTemplateId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string}} input */
    async commit(input) {
      validateOwner(input)
      return mutate(async (document) => {
        const record = document.records.find((entry) =>
          entry.projectId === input.projectId &&
          entry.referenceTemplateId === input.referenceTemplateId)
        if (!record) throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_NOT_FOUND', 404)
        if (
          record.ownerJobId !== input.jobId ||
          record.ownerAttemptId !== input.attemptId ||
          record.ownerGeneration !== input.generation ||
          record.ownerInputFingerprint !== input.inputFingerprint
        ) throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_OWNER_CONFLICT', 409)
        if (record.publication === 'staged') {
          record.publication = 'prepared'
          record.updatedAt = now().toISOString()
        }
        return {
          document,
          result: {
            referenceTemplateId: record.referenceTemplateId,
            publication: record.publication,
            owned: true,
          },
        }
      })
    },
    /** @param {{projectId: string, referenceTemplateId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string}} input */
    async publish(input) {
      validateOwner(input)
      return mutate(async (document) => {
        const record = document.records.find((entry) =>
          entry.projectId === input.projectId &&
          entry.referenceTemplateId === input.referenceTemplateId)
        if (!record) throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_NOT_FOUND', 404)
        if (
          record.ownerJobId !== input.jobId ||
          record.ownerAttemptId !== input.attemptId ||
          record.ownerGeneration !== input.generation ||
          record.ownerInputFingerprint !== input.inputFingerprint
        ) throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_OWNER_CONFLICT', 409)
        if (record.publication === 'staged') {
          throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_NOT_PREPARED', 409)
        }
        if (record.publication === 'prepared') {
          record.publication = 'committed'
          record.updatedAt = now().toISOString()
        }
        return { document, result: toReferenceTemplatePublicDetail(record) }
      })
    },
    /** @param {{projectId: string, referenceTemplateId: string, jobId: string, attemptId: string, generation: number, inputFingerprint: string, includeCommitted?: boolean}} input */
    async rollback(input) {
      validateOwner(input)
      return mutate(async (document) => {
        const index = document.records.findIndex((entry) =>
          entry.projectId === input.projectId &&
          entry.referenceTemplateId === input.referenceTemplateId)
        if (index === -1) return { document, result: false }
        const record = document.records[index]
        if (
          record.ownerJobId !== input.jobId ||
          record.ownerAttemptId !== input.attemptId ||
          record.ownerGeneration !== input.generation ||
          record.ownerInputFingerprint !== input.inputFingerprint ||
          (record.publication === 'committed' && input.includeCommitted !== true)
        ) return { document, result: false }
        document.records.splice(index, 1)
        return { document, result: true }
      })
    },
    /** @param {{projectId: string, jobId: string, attemptId?: string, generation?: number}} input */
    async rollbackByOwner(input) {
      if (
        !identifier(input?.projectId) ||
        !identifier(input?.jobId) ||
        (input.attemptId !== undefined && !identifier(input.attemptId)) ||
        (input.generation !== undefined &&
          (!Number.isSafeInteger(input.generation) || input.generation < 1))
      ) throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_OWNER_INVALID', 400)
      return mutate(async (document) => {
        const retained = document.records.filter((record) =>
          record.publication === 'committed' ||
          record.projectId !== input.projectId ||
          record.ownerJobId !== input.jobId ||
          (input.attemptId !== undefined && record.ownerAttemptId !== input.attemptId) ||
          (input.generation !== undefined && record.ownerGeneration !== input.generation))
        const removed = document.records.length - retained.length
        document.records = retained
        return { document, result: removed }
      })
    },
    /** @param {string} projectId @param {string} referenceTemplateId */
    async get(projectId, referenceTemplateId) {
      const document = await read()
      const record = document.records.find((/** @type {Record<string, any>} */ entry) =>
        entry.projectId === projectId &&
        entry.referenceTemplateId === referenceTemplateId &&
        entry.publication === 'committed')
      return record ? toReferenceTemplatePublicDetail(record) : null
    },
    /** @param {string} projectId */
    async list(projectId) {
      const document = await read()
      return document.records
        .filter((/** @type {Record<string, any>} */ entry) =>
          entry.projectId === projectId && entry.publication === 'committed')
        .map(toReferenceTemplatePublicSummary)
    },
    /** @param {string} projectId */
    async removeByProject(projectId) {
      if (!identifier(projectId)) {
        throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_PROJECT_INVALID', 400)
      }
      return mutate(async (document) => {
        const retained = document.records.filter((entry) => entry.projectId !== projectId)
        const removed = document.records.length - retained.length
        document.records = retained
        return { document, result: removed }
      })
    },
    async listPending() {
      const document = await read()
      return document.records
        .filter((/** @type {Record<string, any>} */ entry) =>
          entry.publication !== 'committed')
        .map((/** @type {Record<string, any>} */ entry) => ({
          projectId: entry.projectId,
          referenceTemplateId: entry.referenceTemplateId,
          jobId: entry.ownerJobId,
          attemptId: entry.ownerAttemptId,
          generation: entry.ownerGeneration,
          inputFingerprint: entry.ownerInputFingerprint,
          publication: entry.publication,
        }))
    },
    /** @param {{projectId: string, referenceTemplateId: string, expectedRevision: number, command: unknown}} input */
    async review(input) {
      return mutate(async (document) => {
        const record = document.records.find((entry) =>
          entry.projectId === input.projectId &&
          entry.referenceTemplateId === input.referenceTemplateId)
        if (!record || record.publication !== 'committed') {
          throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_NOT_FOUND', 404)
        }
        if (record.contractVersion === 1) {
          throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_LEGACY_READ_ONLY', 409)
        }
        if (record.revision !== input.expectedRevision || record.status !== 'generated') {
          throw new ReferenceTemplateRepositoryError('REFERENCE_TEMPLATE_REVISION_CONFLICT', 409)
        }
        try {
          const decision = createReferenceTemplateReviewDecision(
            record.templateSelectionRequest,
            record.adapterRequest,
            record.analysis,
            record.draft,
            record.preflight,
            input.command,
          )
          record.revision += 1
          record.updatedAt = now().toISOString()
          if (decision.decision === 'revision_required') {
            record.draft = createRevisedReferenceTemplateDraft(record.draft, decision)
            record.preflight = preflightReferenceTemplateDraft(
              record.templateSelectionRequest,
              record.adapterRequest,
              record.analysis,
              record.draft,
            )
            record.status = 'generated'
            record.decision = null
          } else {
            record.status = decision.decision === 'approved' ? 'approved' : 'rejected'
            record.decision = decision
          }
        } catch (error) {
          throw mapReviewError(error)
        }
        assertReferenceTemplateWorkflowRecord(record)
        return { document, result: toReferenceTemplatePublicDetail(record) }
      })
    },
    /** @param {string} projectId */
    async getApproved(projectId) {
      const document = await read()
      const record = [...document.records].reverse().find((entry) =>
        entry.projectId === projectId &&
        entry.contractVersion === 2 &&
        entry.publication === 'committed' &&
        entry.status === 'approved')
      return record ? toReferenceTemplatePublicDetail(record) : null
    },
    /** Trusted server-only export boundary. Never return this record from HTTP.
     * @param {string} projectId
     */
    async getApprovedForExport(projectId) {
      const document = await read()
      const record = [...document.records].reverse().find((entry) =>
        entry.projectId === projectId &&
        entry.contractVersion === 2 &&
        entry.publication === 'committed' &&
        entry.status === 'approved')
      return record ? clone(record) : null
    },
    /** Trusted server-only one-time migration boundary. Never return these records from HTTP. */
    async listApprovedForLibraryMigration() {
      const document = await read()
      return document.records
        .filter((/** @type {Record<string, any>} */ entry) =>
          entry.contractVersion === 2 &&
          entry.publication === 'committed' &&
          entry.status === 'approved')
        .map(clone)
    },
  }
}
