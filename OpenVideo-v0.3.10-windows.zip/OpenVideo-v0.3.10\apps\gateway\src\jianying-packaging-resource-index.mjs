import { createHash } from 'node:crypto'

const opaqueTokenPattern = /^ovj[a-z0-9_]{7,159}$/iu
const safeTextPattern = /^[^\u0000-\u001f]+$/u
const privateFieldPattern = /(?:^|_)(?:id|path|url|uri|token|resource|effect|material|cache|identity|device|draft|fingerprint|sha256|hash|digest)(?:$|_)/iu
const privateValuePattern = /(?:[A-Za-z]:[\\/]|\\\\|[a-z][a-z0-9+.-]*:\/\/|file:|(?:resource|effect|material|sticker|template)[_-]?id\s*[:=])/iu
const privatePathPattern = /(?:^|[\s=(,;:"'])(?:[\\/]|~[\\/]|\.\.?[\\/])|[\\/]\.\.?[\\/]/u
const privateFingerprintValuePattern = /\b[a-f0-9]{64}\b/iu
const identifierShapedValuePattern = /(?:^|[^a-z0-9])(?:\d{8,}|[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}|[a-f0-9]{32,64})(?=$|[^a-z0-9])/iu

export const PACKAGING_RESOURCE_FAMILIES = Object.freeze([
  'flower',
  'bubble',
  'sticker',
  'filter',
  'video_effect',
  'video_animation',
  'mask',
  'blend',
  'transition',
  'audio_effect',
  'text_animation',
  'bgm',
  'sfx',
])

const familySet = new Set(PACKAGING_RESOURCE_FAMILIES)
const familyTokenPrefixes = Object.freeze(Object.fromEntries(PACKAGING_RESOURCE_FAMILIES.map((family) => [family, `ovj${family}_v1_`])))

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {string} key */
const isPrivateFieldName = (key) => privateFieldPattern.test(
  key.replace(/([a-z0-9])([A-Z])/gu, '$1_$2').replaceAll('-', '_').toLocaleLowerCase(),
)

/** @param {string} value */
const containsPrivateValue = (value) =>
  privateValuePattern.test(value) || privatePathPattern.test(value) ||
  privateFingerprintValuePattern.test(value) || identifierShapedValuePattern.test(value.trim())

/** Keep owner-private catalog bindings finite without inspecting or exposing them. */
/** @param {unknown} value @param {number} [depth] */
export const assertBoundedPrivatePackagingValue = (value, depth = 0) => {
  if (depth > 8) throw new Error('JY132_PRIVATE_BINDING_TOO_DEEP')
  if (value === null || typeof value === 'boolean') return value
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('JY132_PRIVATE_BINDING_NUMBER_INVALID')
    return value
  }
  if (typeof value === 'string') {
    if (value.length === 0 || value.length > 512 || /[\u0000-\u001f]/u.test(value)) {
      throw new Error('JY132_PRIVATE_BINDING_TEXT_INVALID')
    }
    return value
  }
  if (Array.isArray(value)) {
    if (value.length > 64) throw new Error('JY132_PRIVATE_BINDING_TOO_LARGE')
    value.forEach((item) => assertBoundedPrivatePackagingValue(item, depth + 1))
    return value
  }
  if (isRecord(value)) {
    const entries = Object.entries(value)
    if (entries.length > 64) throw new Error('JY132_PRIVATE_BINDING_TOO_LARGE')
    for (const [key, child] of entries) {
      if (key === '__proto__' || key === 'constructor' || key === 'prototype' || key.length > 128) {
        throw new Error('JY132_PRIVATE_BINDING_KEY_INVALID')
      }
      assertBoundedPrivatePackagingValue(child, depth + 1)
    }
    return value
  }
  throw new Error('JY132_PRIVATE_BINDING_TYPE_INVALID')
}

/** @template T @param {T} value @returns {T} */
const deepFreeze = (value) => {
  if (Array.isArray(value)) {
    for (const item of value) deepFreeze(item)
  } else if (isRecord(value)) {
    for (const item of Object.values(value)) deepFreeze(item)
  }
  return Object.freeze(value)
}

/** @param {unknown} value @param {string} field @param {number} [max] */
const assertSafeText = (value, field, max = 160) => {
  if (typeof value !== 'string' || value.length === 0 || value.length > max || !safeTextPattern.test(value)) {
    throw new Error(`JY132_${field.toUpperCase()}_INVALID`)
  }
  if (containsPrivateValue(value)) throw new Error(`JY132_${field.toUpperCase()}_PRIVATE`)
  return value
}

/** Public recommendation prose must obey the same path/URL privacy boundary. */
/** @param {unknown} value @param {string} [field] @param {number} [max] */
export const assertSafePackagingText = (value, field = 'text', max = 240) =>
  assertSafeText(value, field, max)

/** @param {unknown} value */
export const isOpaquePackagingToken = (value) =>
  typeof value === 'string' && opaqueTokenPattern.test(value)

/** @param {unknown} family @param {unknown} token */
const tokenMatchesFamily = (family, token) =>
  typeof family === 'string' && typeof token === 'string' &&
  typeof familyTokenPrefixes[family] === 'string' && token.startsWith(familyTokenPrefixes[family])

/** Keep writer-bound tokens tied to the packaging family they claim to use. */
/** @param {unknown} family @param {unknown} token */
export const isPackagingResourceTokenForFamily = (family, token) =>
  isOpaquePackagingToken(token) && tokenMatchesFamily(family, token)

/** @param {unknown} value */
const assertOpaquePackagingToken = (value) => {
  if (!isOpaquePackagingToken(value)) throw new Error('JY132_PACKAGING_TOKEN_INVALID')
  return value
}

/** @param {unknown} value @returns {string[]} */
const normalizeTags = (value) => {
  if (!Array.isArray(value)) return []
  return [...new Set(value
    .filter((item) => typeof item === 'string' && item.trim())
    .map((item) => item.trim().slice(0, 48))
    .filter((item) => !containsPrivateValue(item)))]
    .slice(0, 16)
}

const fingerprintPattern = /^[a-f0-9]{64}$/u
const desktopVersionPattern = /^[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u
const draftAuthorizationPattern = /^ovauth_[A-Za-z0-9_-]{8,160}$/u

/** @param {unknown} input @returns {Readonly<{draft_authorization_id: string, source_fingerprint: string}>} */
const normalizePrivateSourceBinding = (input) => {
  if (!isRecord(input) ||
      typeof input.draft_authorization_id !== 'string' ||
      !draftAuthorizationPattern.test(input.draft_authorization_id) ||
      typeof input.source_fingerprint !== 'string' ||
      !fingerprintPattern.test(input.source_fingerprint)) {
    throw new Error('JY132_PRIVATE_SOURCE_BINDING_INVALID')
  }
  return Object.freeze({
    draft_authorization_id: input.draft_authorization_id,
    source_fingerprint: input.source_fingerprint,
  })
}
export const PACKAGING_RESOURCE_WRITER_FAMILIES = Object.freeze([
  'flower',
  'bubble',
  'sticker',
  'video_effect',
  'video_animation',
  'mask',
  'blend',
])

const writerFamilySet = new Set(PACKAGING_RESOURCE_WRITER_FAMILIES)

/** Evidence admission without asserting the family-specific writer shape. */
/** @param {unknown} entry @returns {entry is Record<string, any>} */
export const isAdmittedPackagingEntry = (entry) =>
  isRecord(entry) && entry.state === 'writer_eligible' && entry.writer_eligible === true &&
  isPackagingResourceTokenForFamily(entry.family, entry.packaging_token)

/** Only an explicitly admitted, structurally writable entry may be recommended. */
/** @param {unknown} entry */
export const isPackagingWriterReadyEntry = (entry) => {
  if (!isAdmittedPackagingEntry(entry)) return false
  try {
    assertPackagingWriterBinding(entry.family, entry.private_binding)
    return true
  } catch {
    return false
  }
}

/** @param {{profileId: string, appVersion: string, entries: any[], desktopBinding?: Record<string, any>, privateRootSetFingerprint?: string}} input */
const catalogFingerprintBody = ({ profileId, appVersion, entries, desktopBinding = undefined, privateRootSetFingerprint = undefined }) => ({
  schema_version: 1,
  profile_id: profileId,
  app_version: appVersion,
  ...(desktopBinding ? { desktop_binding: desktopBinding } : {}),
  ...(privateRootSetFingerprint ? { private_root_set_fingerprint: privateRootSetFingerprint } : {}),
  entries,
})

/** @param {{profileId: string, appVersion: string, entries: any[], desktopBinding?: Record<string, any>, privateRootSetFingerprint?: string}} input */
export const computePackagingCatalogFingerprint = ({ profileId, appVersion, entries, desktopBinding = undefined, privateRootSetFingerprint = undefined }) =>
  createHash('sha256').update(JSON.stringify(catalogFingerprintBody({ profileId, appVersion, entries, desktopBinding, privateRootSetFingerprint }))).digest('hex')

/** @param {unknown} value */
const isAbsoluteDesktopPath = (value) => typeof value === 'string' && value.length > 0 && (
  /^[A-Za-z]:[\\/]/u.test(value) || value.startsWith('/') || value.startsWith('\\\\')
)

/** @param {{profileId: string, appVersion: string, executablePath: string, installRoot: string, dllFingerprint: string}} input */
export const computeJianyingDesktopBindingFingerprint = (input) => {
  if (!isRecord(input) || typeof input.profileId !== 'string' || typeof input.appVersion !== 'string' ||
      typeof input.executablePath !== 'string' || typeof input.installRoot !== 'string' ||
      typeof input.dllFingerprint !== 'string') {
    throw new Error('JY000_DESKTOP_BINDING_INVALID')
  }
  return createHash('sha256').update(JSON.stringify({
    profile_id: input.profileId,
    app_version: input.appVersion,
    executable_path: input.executablePath,
    install_root: input.installRoot,
    dll_fingerprint: input.dllFingerprint.toLowerCase(),
  })).digest('hex')
}

/** @param {unknown} input @returns {Record<string, string>} */
export const normalizeJianyingDesktopBinding = (input) => {
  if (!isRecord(input) ||
      typeof input.profile_id !== 'string' ||
      typeof input.app_version !== 'string' ||
      !desktopVersionPattern.test(input.app_version) ||
      !isAbsoluteDesktopPath(input.executable_path) ||
      !isAbsoluteDesktopPath(input.install_root) ||
      typeof input.dll_fingerprint !== 'string' ||
      !fingerprintPattern.test(input.dll_fingerprint)) {
    throw new Error('JY000_DESKTOP_BINDING_INVALID')
  }
  const binding = {
    profile_id: input.profile_id,
    app_version: input.app_version,
    executable_path: input.executable_path,
    install_root: input.install_root,
    dll_fingerprint: input.dll_fingerprint.toLowerCase(),
  }
  const expectedFingerprint = computeJianyingDesktopBindingFingerprint({
    profileId: binding.profile_id,
    appVersion: binding.app_version,
    executablePath: binding.executable_path,
    installRoot: binding.install_root,
    dllFingerprint: binding.dll_fingerprint,
  })
  if (input.binding_fingerprint !== undefined &&
      (typeof input.binding_fingerprint !== 'string' || input.binding_fingerprint !== expectedFingerprint)) {
    throw new Error('JY000_DESKTOP_BINDING_FINGERPRINT_INVALID')
  }
  return Object.freeze({ ...binding, binding_fingerprint: expectedFingerprint })
}

/** @param {{profileId?: string, version?: string, executablePath?: string, installRoot?: string, dllFingerprint?: string}} desktop */
export const createJianyingDesktopBinding = (desktop) => normalizeJianyingDesktopBinding({
  profile_id: desktop?.profileId,
  app_version: desktop?.version,
  executable_path: desktop?.executablePath,
  install_root: desktop?.installRoot,
  dll_fingerprint: desktop?.dllFingerprint,
})

/** @param {unknown} index @param {{profileId: string, version: string, executablePath?: string, installRoot?: string, dllFingerprint?: string}} desktop */
export const isPackagingCatalogBoundToDesktop = (index, desktop) => {
  if (!isRecord(index) || index.profileId !== desktop?.profileId || index.appVersion !== desktop?.version) return false
  const hasExactDesktopIdentity = typeof desktop?.executablePath === 'string' &&
    typeof desktop?.installRoot === 'string' && typeof desktop?.dllFingerprint === 'string'
  if (index.desktopBinding === undefined) return !hasExactDesktopIdentity
  try {
    const expected = createJianyingDesktopBinding(desktop)
    return isRecord(index.desktopBinding) &&
      index.desktopBinding.binding_fingerprint === expected.binding_fingerprint &&
      JSON.stringify(index.desktopBinding) === JSON.stringify(expected)
  } catch {
    return false
  }
}

/** Keep catalog revision identity opaque when it crosses the public timeline contract. */
/** @param {string} catalogFingerprint */
export const computePackagingCatalogRevisionToken = (catalogFingerprint) => {
  if (typeof catalogFingerprint !== 'string' || !fingerprintPattern.test(catalogFingerprint)) {
    throw new Error('JY132_CATALOG_FINGERPRINT_INVALID')
  }
  return `ovjcatalog_v1_${catalogFingerprint.slice(0, 24)}`
}

/** Bind private evidence to the exact family/binding pair admitted by the catalog. */
/** @param {{family: string, privateBinding: Record<string, any>}} input */
export const computePackagingEntryBindingFingerprint = ({ family, privateBinding }) =>
  createHash('sha256').update(JSON.stringify({ family, private_binding: privateBinding })).digest('hex')

/** Mint a public-safe token that cannot resolve to a different private binding after restart. */
/** @param {{family: string, profileId: string, appVersion: string, privateBinding: Record<string, any>}} input */
export const computePackagingResourceToken = ({ family, profileId, appVersion, privateBinding }) => {
  if (!familySet.has(family) || typeof profileId !== 'string' || typeof appVersion !== 'string' || !isRecord(privateBinding)) {
    throw new Error('JY132_RESOURCE_TOKEN_INPUT_INVALID')
  }
  const digest = createHash('sha256').update(JSON.stringify({
    family,
    profile_id: profileId,
    app_version: appVersion,
    private_binding: privateBinding,
  })).digest('hex')
  return `${familyTokenPrefixes[family]}${digest.slice(0, 24)}`
}

/** @param {unknown} entry @param {{profileId: string, appVersion: string}} expected @returns {Record<string, any>} */
const assertPrivateCatalogEntry = (entry, { profileId, appVersion }) => {
  if (!isRecord(entry)) throw new Error('JY132_CATALOG_ENTRY_INVALID')
  assertOpaquePackagingToken(entry.packaging_token)
  if (!familySet.has(entry.family)) throw new Error('JY132_CATALOG_FAMILY_INVALID')
  if (!tokenMatchesFamily(entry.family, entry.packaging_token)) throw new Error('JY132_CATALOG_TOKEN_FAMILY_MISMATCH')
  assertSafeText(entry.label, 'catalog_label')
  if (entry.writer_eligible !== false) throw new Error('JY132_DISCOVERY_CANNOT_ADMIT_WRITER')
  if (!['discoverable', 'blocked'].includes(entry.state)) {
    throw new Error('JY132_CATALOG_STATE_INVALID')
  }
  if (Object.hasOwn(entry, 'evidence')) throw new Error('JY132_DISCOVERY_EVIDENCE_PROHIBITED')
  if (!isRecord(entry.private_binding)) throw new Error('JY132_PRIVATE_BINDING_MISSING')
  assertBoundedPrivatePackagingValue(entry.private_binding)
  if (entry.packaging_token !== computePackagingResourceToken({
    family: entry.family,
    profileId,
    appVersion,
    privateBinding: entry.private_binding,
  })) throw new Error('JY132_CATALOG_TOKEN_BINDING_MISMATCH')
  return entry
}

/** Validate only the families and binding shapes implemented by the generic JY-132 resolver. */
/** @param {unknown} family @param {unknown} binding */
export const assertPackagingWriterBinding = (family, binding) => {
  if (typeof family !== 'string' || !writerFamilySet.has(family) || !isRecord(binding)) throw new Error('JY132_WRITER_FAMILY_UNSUPPORTED')
  const hasResource = typeof binding.resourceId === 'string' && /^[A-Za-z0-9_-]{4,80}$/u.test(binding.resourceId)
  const valid = family === 'flower' || family === 'bubble'
    ? hasResource && typeof binding.effectId === 'string' && /^[A-Za-z0-9_-]{4,80}$/u.test(binding.effectId)
    : family === 'video_effect'
      ? hasResource && (!Object.hasOwn(binding, 'effectId') || (typeof binding.effectId === 'string' && /^[A-Za-z0-9_-]{4,80}$/u.test(binding.effectId)))
    : family === 'video_animation'
      ? hasResource && Number.isSafeInteger(binding.durationUs) && binding.durationUs > 0 && binding.durationUs <= 10_000_000
      : family === 'mask'
        ? hasResource && isRecord(binding.commonMaskTemplate)
        : hasResource
  if (!valid) throw new Error('JY132_WRITER_BINDING_SHAPE_INVALID')
  return binding
}

/**
 * Parse an owner-private resource index. Raw provider fields intentionally stay
 * on `private_binding`; callers must use projectPackagingResourceCandidates for
 * anything that can cross the server/Agent boundary.
 */
/** @param {unknown} input @param {{profileId?: string, appVersion?: string, desktopBinding?: Record<string, any>}} [options] */
export const parsePrivatePackagingResourceIndex = (input, { profileId, appVersion } = {}) => {
  if (!isRecord(input) || input.schema_version !== 1 || !Array.isArray(input.entries)) {
    throw new Error('JY132_PRIVATE_CATALOG_INVALID')
  }
  if (typeof input.profile_id !== 'string' || input.profile_id !== profileId ||
      typeof input.app_version !== 'string' || input.app_version !== appVersion) {
    throw new Error('JY132_PROFILE_MISMATCH')
  }
  if (input.entries.length > 20000) throw new Error('JY132_CATALOG_TOO_LARGE')
  const desktopBinding = input.desktop_binding === undefined
    ? undefined
    : normalizeJianyingDesktopBinding(input.desktop_binding)
  const privateSourceBinding = input.private_source_binding === undefined
    ? undefined
    : normalizePrivateSourceBinding(input.private_source_binding)
  const privateRootSetFingerprint = input.private_root_set_fingerprint === undefined
    ? undefined
    : input.private_root_set_fingerprint
  if (privateRootSetFingerprint !== undefined &&
      (typeof privateRootSetFingerprint !== 'string' || !fingerprintPattern.test(privateRootSetFingerprint))) {
    throw new Error('JY200_PRIVATE_ROOT_BINDING_INVALID')
  }
  if (desktopBinding && (desktopBinding.profile_id !== input.profile_id || desktopBinding.app_version !== input.app_version)) {
    throw new Error('JY000_DESKTOP_BINDING_MISMATCH')
  }
  const entries = input.entries
    .map((entry) => assertPrivateCatalogEntry(entry, { profileId, appVersion }))
    .map((entry) => structuredClone(entry))
  if (typeof input.catalog_fingerprint !== 'string' || !fingerprintPattern.test(input.catalog_fingerprint) ||
      input.catalog_fingerprint !== computePackagingCatalogFingerprint({ profileId, appVersion, entries, desktopBinding, privateRootSetFingerprint })) {
    throw new Error('JY132_CATALOG_FINGERPRINT_INVALID')
  }
  const tokens = new Set()
  for (const entry of entries) {
    if (tokens.has(entry.packaging_token)) throw new Error('JY132_DUPLICATE_PACKAGING_TOKEN')
    tokens.add(entry.packaging_token)
  }
  return Object.freeze({
    schemaVersion: 1,
    profileId,
    appVersion,
    desktopBinding,
    ...(privateSourceBinding ? { privateSourceBinding } : {}),
    ...(privateRootSetFingerprint ? { privateRootSetFingerprint } : {}),
    catalogFingerprint: input.catalog_fingerprint,
    catalogRevisionToken: computePackagingCatalogRevisionToken(input.catalog_fingerprint),
    entries: deepFreeze(entries),
  })
}

/** Convert the immutable runtime view back to the exact private on-disk schema. */
/** @param {unknown} index */
export const serializePrivatePackagingResourceIndex = (index) => {
  if (!isRecord(index) || index.schemaVersion !== 1 || typeof index.profileId !== 'string' ||
      typeof index.appVersion !== 'string' || typeof index.catalogFingerprint !== 'string' ||
      !Array.isArray(index.entries)) {
    throw new Error('JY132_INDEX_INVALID')
  }
  if (index.entries.some((entry) => entry.state === 'writer_eligible' || entry.writer_eligible === true)) {
    throw new Error('JY132_ADMITTED_INDEX_NOT_SERIALIZABLE')
  }
  const privateSourceBinding = index.privateSourceBinding === undefined
    ? undefined
    : normalizePrivateSourceBinding(index.privateSourceBinding)
  const privateRootSetFingerprint = index.privateRootSetFingerprint === undefined
    ? undefined
    : index.privateRootSetFingerprint
  if (privateRootSetFingerprint !== undefined &&
      (typeof privateRootSetFingerprint !== 'string' || !fingerprintPattern.test(privateRootSetFingerprint))) {
    throw new Error('JY200_PRIVATE_ROOT_BINDING_INVALID')
  }
  return {
    schema_version: 1,
    profile_id: index.profileId,
    app_version: index.appVersion,
    ...(index.desktopBinding ? { desktop_binding: structuredClone(index.desktopBinding) } : {}),
    ...(privateSourceBinding ? { private_source_binding: structuredClone(privateSourceBinding) } : {}),
    ...(privateRootSetFingerprint ? { private_root_set_fingerprint: privateRootSetFingerprint } : {}),
    catalog_fingerprint: index.catalogFingerprint,
    entries: structuredClone(index.entries),
  }
}

/** @param {Record<string, any>} entry */
const publicCandidate = (entry) => Object.freeze({
  packagingToken: entry.packaging_token,
  family: entry.family,
  label: entry.label,
  tags: normalizeTags(entry.tags),
  state: entry.state,
  parameterSchema: projectPublicParameterSchema(entry.family, entry.parameter_schema),
})

/** @param {unknown} value @returns {Record<string, any>} */
const assertPublicCandidate = (value) => {
  /** @param {unknown} node @param {string} [path] */
  const walk = (node, path = '') => {
    if (Array.isArray(node)) return node.forEach((item, index) => walk(item, `${path}[${index}]`))
    if (!isRecord(node)) {
      if (typeof node === 'string' && containsPrivateValue(node)) throw new Error('JY132_PUBLIC_PRIVATE_VALUE')
      return
    }
    for (const [key, child] of Object.entries(node)) {
      if (isPrivateFieldName(key) && key !== 'packagingToken' && key !== 'parameterSchema') {
        throw new Error('JY132_PUBLIC_PRIVATE_FIELD')
      }
      walk(child, `${path}.${key}`)
    }
  }
  walk(value)
  return /** @type {Record<string, any>} */ (value)
}

/** Parameters may cross the Agent boundary only when they contain safe values. */
/** @param {unknown} value @param {number} [depth] @returns {any} */
export const assertSafePackagingParameters = (value, depth = 0) => {
  if (depth > 5) throw new Error('JY132_PARAMETERS_TOO_DEEP')
  if (value === null || typeof value === 'boolean') return value
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('JY132_PARAMETER_NUMBER_INVALID')
    return value
  }
  if (typeof value === 'string') {
    if (containsPrivateValue(value) || value.length > 160 || /[\u0000-\u001f]/u.test(value)) {
      throw new Error('JY132_PARAMETER_PRIVATE_VALUE')
    }
    return value
  }
  if (Array.isArray(value)) {
    if (value.length > 32) throw new Error('JY132_PARAMETERS_TOO_LARGE')
    return value.map((item) => assertSafePackagingParameters(item, depth + 1))
  }
  if (isRecord(value)) {
    const entries = Object.entries(value)
    if (entries.length > 32) throw new Error('JY132_PARAMETERS_TOO_LARGE')
    return Object.fromEntries(entries.map(([key, item]) => {
      if (isPrivateFieldName(key)) throw new Error('JY132_PARAMETER_PRIVATE_FIELD')
      return [key, assertSafePackagingParameters(item, depth + 1)]
    }))
  }
  throw new Error('JY132_PARAMETER_TYPE_INVALID')
}

const familyParameterPolicy = Object.freeze({
  flower: Object.freeze({}),
  bubble: Object.freeze({}),
  sticker: Object.freeze({}),
  filter: Object.freeze({ intensity: Object.freeze({ type: 'number', minimum: 0, maximum: 1 }) }),
  video_effect: Object.freeze({}),
  video_animation: Object.freeze({}),
  mask: Object.freeze({ size: Object.freeze({ type: 'number', minimum: 0, maximum: 1 }) }),
  blend: Object.freeze({}),
  transition: Object.freeze({ durationUs: Object.freeze({ type: 'integer', minimum: 1, maximum: 5_000_000 }) }),
  audio_effect: Object.freeze({}),
  text_animation: Object.freeze({}),
  bgm: Object.freeze({ volume: Object.freeze({ type: 'number', minimum: 0, maximum: 1 }) }),
  sfx: Object.freeze({ volume: Object.freeze({ type: 'number', minimum: 0, maximum: 1 }) }),
})

/** Project only fixed family keys and bounded rule fields into public/LLM DTOs. */
/** @param {string} family @param {unknown} schema */
const projectPublicParameterSchema = (family, schema) => {
  const policy = /** @type {Record<string, Record<string, any>>} */ (familyParameterPolicy)[family]
  if (!isRecord(schema) || !isRecord(policy)) return {}
  return Object.fromEntries(Object.entries(policy).flatMap(([key, fixedRule]) => {
    const rawRule = schema[key]
    if (!isRecord(rawRule) || (rawRule.type !== undefined && rawRule.type !== fixedRule.type)) return []
    return [[key, fixedRule]]
  }))
}

/** @param {unknown} value @param {Record<string, any>} rule @param {string} key */
const assertParameterRule = (value, rule, key) => {
  const type = rule.type
  if (type === 'number' || type === 'integer') {
    if (typeof value !== 'number' || !Number.isFinite(value) || (type === 'integer' && !Number.isSafeInteger(value))) {
      throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_TYPE`)
    }
    if (typeof rule.minimum === 'number' && value < rule.minimum) throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_RANGE`)
    if (typeof rule.maximum === 'number' && value > rule.maximum) throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_RANGE`)
    return value
  }
  if (type === 'boolean') {
    if (typeof value !== 'boolean') throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_TYPE`)
    return value
  }
  if (type === 'string') {
    if (typeof value !== 'string') throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_TYPE`)
    if (Array.isArray(rule.enum) && !rule.enum.includes(value)) throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_ENUM`)
    if (typeof rule.maxLength === 'number' && value.length > rule.maxLength) throw new Error(`JY132_PARAMETER_${key.toUpperCase()}_LENGTH`)
    return assertSafePackagingParameters(value)
  }
  throw new Error('JY132_PARAMETER_SCHEMA_UNSUPPORTED')
}

/** Validate exact parameter keys against both the resource schema and the fixed family policy. */
/** @param {string} family @param {unknown} schema @param {unknown} parameters */
export const assertPackagingParametersForCandidate = (family, schema, parameters) => {
  if (!familySet.has(family) || !isRecord(schema) || !isRecord(parameters)) {
    throw new Error('JY132_PARAMETER_SCHEMA_INVALID')
  }
  const safe = assertSafePackagingParameters(parameters)
  const policy = /** @type {Record<string, Record<string, any>>} */ (familyParameterPolicy)[family]
  for (const [key, value] of Object.entries(safe)) {
    if (!Object.hasOwn(policy, key) || !Object.hasOwn(schema, key)) {
      throw new Error('JY132_PARAMETER_UNKNOWN')
    }
    const catalogRule = schema[key]
    if (!isRecord(catalogRule)) throw new Error('JY132_PARAMETER_SCHEMA_INVALID')
    const fixedRule = policy[key]
    assertParameterRule(value, fixedRule, key)
    assertParameterRule(value, { ...catalogRule, type: catalogRule.type ?? fixedRule.type }, key)
  }
  return safe
}

/** @param {unknown} index @param {{writerEligibleOnly?: boolean, family?: string | null}} [options] @returns {Array<Record<string, any>>} */
export const projectPackagingResourceCandidates = (index, { writerEligibleOnly = false, family = null } = {}) => {
  if (!isRecord(index) || !Array.isArray(index.entries)) throw new Error('JY132_INDEX_INVALID')
  return /** @type {Array<Record<string, any>>} */ (index.entries)
    .filter((entry) => !writerEligibleOnly || isPackagingWriterReadyEntry(entry))
    .filter((entry) => family === null || entry.family === family)
    .map(publicCandidate)
    .map(assertPublicCandidate)
}

/**
 * Produce a public-safe batch readiness view from either the discovery index
 * or the ephemeral, evidence-admitted runtime index. Counts are the only
 * private-catalog detail exposed; bindings and raw resource identifiers never
 * cross this boundary.
 * @param {unknown} index
 */
export const summarizePackagingResourceReadiness = (index) => {
  if (!isRecord(index) || index.schemaVersion !== 1 || !Array.isArray(index.entries) ||
      typeof index.profileId !== 'string' || typeof index.appVersion !== 'string' ||
      typeof index.catalogRevisionToken !== 'string') {
    throw new Error('JY148_INDEX_INVALID')
  }
  const counts = new Map(PACKAGING_RESOURCE_FAMILIES.map((family) => [family, {
    family,
    total: 0,
    discoverable: 0,
    blocked: 0,
    writerEligible: 0,
  }]))
  for (const entry of index.entries) {
    const family = counts.get(entry?.family)
    if (!family) throw new Error('JY148_FAMILY_INVALID')
    family.total += 1
    if (isPackagingWriterReadyEntry(entry)) {
      family.writerEligible += 1
    } else if (entry.state === 'discoverable' && entry.writer_eligible === false) {
      family.discoverable += 1
    } else {
      // Unknown or malformed states are reported as blocked rather than
      // treated as writable, preserving the admission fail-closed boundary.
      family.blocked += 1
    }
  }
  const families = [...counts.values()]
    .filter((family) => family.total > 0)
    .map((family) => Object.freeze({ ...family }))
  const totals = families.reduce((result, family) => ({
    totalEntries: result.totalEntries + family.total,
    discoverable: result.discoverable + family.discoverable,
    blocked: result.blocked + family.blocked,
    writerEligible: result.writerEligible + family.writerEligible,
  }), { totalEntries: 0, discoverable: 0, blocked: 0, writerEligible: 0 })
  const writerEligibleFamilies = Object.freeze(families
    .filter((family) => family.writerEligible > 0)
    .map((family) => family.family))
  return Object.freeze({
    schemaVersion: 1,
    profileId: index.profileId,
    appVersion: index.appVersion,
    catalogRevisionToken: index.catalogRevisionToken,
    ...totals,
    writerEligibleFamilies,
    families: Object.freeze(families),
  })
}

/** Resolve a writer-only token while keeping the private binding server-side. */
/** @param {unknown} index @param {unknown} packagingToken */
export const resolvePrivatePackagingResourceToken = (index, packagingToken) => {
  if (!isRecord(index) || !Array.isArray(index.entries) || !isOpaquePackagingToken(packagingToken)) return null
  const entry = index.entries.find((candidate) =>
    candidate.packaging_token === packagingToken && isAdmittedPackagingEntry(candidate))
  if (!entry) return null
  const kind = entry.family === 'video_effect' ? 'effect' : entry.family === 'video_animation' ? 'animation' : entry.family
  return {
    ...structuredClone(entry.private_binding),
    kind,
    packagingToken,
    family: entry.family,
  }
}

/** @param {unknown} value */
const normalizeQuery = (value) => String(value ?? '').trim().toLocaleLowerCase().slice(0, 200)

/** @param {Record<string, any>} candidate @param {unknown} query */
const scoreCandidate = (candidate, query) => {
  const terms = normalizeQuery(query).split(/\s+/u).filter(Boolean)
  if (!terms.length) return 1
  const haystack = [candidate.label, ...candidate.tags].join(' ').toLocaleLowerCase()
  return terms.reduce((score, term) => score + (haystack.includes(term) ? (candidate.label.toLocaleLowerCase() === term ? 5 : 1) : 0), 0)
}

/** @param {unknown} index @param {unknown} query @param {{limit?: number, writerEligibleOnly?: boolean, family?: string | null}} [options] @returns {Array<Record<string, any>>} */
export const searchPackagingResourceCandidates = (index, query, options = {}) => {
  const requestedLimit = options.limit
  const limit = Number.isInteger(requestedLimit) ? Math.max(1, Math.min(100, Number(requestedLimit))) : 20
  return projectPackagingResourceCandidates(index, options)
    .map((candidate) => ({ candidate, score: scoreCandidate(candidate, query) }))
    .filter((item) => item.score > 0)
    .sort((left, right) => right.score - left.score || left.candidate.packagingToken.localeCompare(right.candidate.packagingToken))
    .slice(0, limit)
    .map((item) => ({ ...item.candidate, score: item.score }))
}

/** @param {Record<string, any>} request */
const assertRange = (request) => {
  if (!Number.isSafeInteger(request.startUs) || request.startUs < 0 ||
      !Number.isSafeInteger(request.durationUs) || request.durationUs <= 0) {
    throw new Error('JY132_TARGET_RANGE_INVALID')
  }
}

/** Select one or more safe, writer-eligible candidates for one packaging batch. */
/** @param {any} index @param {unknown} requests @param {{maxPerFamily?: number, maxTotal?: number}} [options] @returns {Array<Record<string, any>>} */
export const selectPackagingBatch = (index, requests, { maxPerFamily = 4, maxTotal = 24 } = {}) => {
  if (!Array.isArray(requests) || requests.length === 0 || requests.length > maxTotal) {
    throw new Error('JY132_BATCH_REQUEST_INVALID')
  }
  const eligible = new Map(/** @type {Array<Record<string, any>>} */ (index.entries)
    .filter((/** @type {Record<string, any>} */ entry) => isPackagingWriterReadyEntry(entry))
    .map((/** @type {Record<string, any>} */ entry) => [entry.packaging_token, entry]))
  const familyCounts = new Map()
  const selected = []
  const usedTokens = new Set()
  for (const request of requests) {
    if (!isRecord(request) || !familySet.has(request.family)) throw new Error('JY132_REQUEST_FAMILY_INVALID')
    assertRange(request)
    const query = normalizeQuery(request.query)
    const candidates = [...eligible.values()]
      .filter((entry) => entry.family === request.family)
      .map(publicCandidate)
      .map((candidate) => ({ candidate, score: scoreCandidate(candidate, query) }))
      .filter((item) => item.score > 0)
      .sort((left, right) => right.score - left.score || left.candidate.packagingToken.localeCompare(right.candidate.packagingToken))
    const chosen = candidates.find((item) => !usedTokens.has(item.candidate.packagingToken))
    if (!chosen) throw new Error('JY132_NO_ELIGIBLE_RESOURCE')
    const count = familyCounts.get(request.family) ?? 0
    if (count >= maxPerFamily) throw new Error('JY132_FAMILY_QUOTA_EXCEEDED')
    familyCounts.set(request.family, count + 1)
    usedTokens.add(chosen.candidate.packagingToken)
    selected.push({
      ...chosen.candidate,
      targetSegmentId: typeof request.targetSegmentId === 'string' ? request.targetSegmentId : null,
      targetRange: { startUs: request.startUs, durationUs: request.durationUs },
      parameters: isRecord(request.parameters)
        ? assertPackagingParametersForCandidate(
            request.family,
            eligible.get(chosen.candidate.packagingToken)?.parameter_schema ?? {},
            request.parameters,
          )
        : {},
    })
  }
  return selected
}

/** @param {unknown} value */
export const isPublicPackagingCandidate = (value) => {
  try {
    assertPublicCandidate(value)
    return true
  } catch {
    return false
  }
}
