import { createHash } from 'node:crypto'

import {
  signArtistEffectStickerReceipt,
  verifyArtistEffectStickerReceiptSignature,
} from './jianying-artist-effect-probe.mjs'

const FINGERPRINT = /^[a-f0-9]{64}$/u
const COMMIT = /^[a-f0-9]{40}$/u
const DRAFT_ID = /^OpenVideo-JY200-duo-direct-[0-9]{8}-(?:[0-9]{4}|[0-9]{6})$/u
const ATTESTATION = 'opened-edited-saved-closed-reopened'
const LOCAL_CAPABILITIES = Object.freeze([
  'effect.video.named',
  'sticker.named',
  'text.flower.private',
])
const PUBLISHER_OWNED_DRAFT_INFO_KEYS = new Set(['name', 'create_time', 'update_time'])

const EXECUTION_BINDING_KEYS = Object.freeze([
  'schema_version', 'kind', 'family', 'packaging_token', 'binding_fingerprint',
  'source_material_fingerprint', 'payload_fingerprint', 'source_fingerprint',
  'catalog_fingerprint', 'desktop_binding_fingerprint', 'resource_mode',
  'admission', 'writer_eligible', 'probe_candidate',
])

const EXECUTION_RECEIPT_KEYS = Object.freeze([
  'schema_version', 'kind', 'status', 'admission', 'writer_eligible', 'catalog_bound',
  'provider', 'provider_commit', 'build_digest', 'profile_id', 'app_version',
  'desktop_binding_fingerprint', 'current_catalog_fingerprint', 'draft_id',
  'draft_id_fingerprint', 'initial_draft_fingerprint', 'binding_set_fingerprint',
  'binding_evidence_fingerprint', 'capability_snapshot', 'binding_evidence',
  'audio_evidence_fingerprint', 'audio_evidence',
  'created_at', 'integrity_revision', 'integrity_signature',
])

const AUDIO_EVIDENCE_KEYS = Object.freeze([
  'role', 'audio_token', 'source_fingerprint', 'source_start_us',
  'source_duration_us', 'target_start_us', 'target_duration_us', 'volume',
])

/** @param {unknown} value */
const normalizeAudioEvidence = (value) => {
  if (!Array.isArray(value)) return null
  const normalized = value.map((entry) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry) ||
        Object.keys(entry).sort().join('\0') !== AUDIO_EVIDENCE_KEYS.slice().sort().join('\0')) return null
    const record = /** @type {Record<string, any>} */ (entry)
    if (!['voiceover', 'bgm', 'sfx'].includes(record.role) ||
        typeof record.audio_token !== 'string' || record.audio_token.length === 0 ||
        !FINGERPRINT.test(record.source_fingerprint ?? '') ||
        ![record.source_start_us, record.source_duration_us, record.target_start_us,
          record.target_duration_us, record.volume].every((item) => Number.isSafeInteger(item) && item >= 0)) return null
    return Object.freeze({ ...record })
  })
  return normalized.some((entry) => !entry) ? null : Object.freeze(normalized)
}

/** @param {Buffer|string} value */
export const fingerprintJY200DuoValue = (value) => createHash('sha256').update(value).digest('hex')

/** @param {unknown} value @returns {string} */
export const canonicalJY200DuoJson = (value) => Array.isArray(value)
  ? `[${value.map(canonicalJY200DuoJson).join(',')}]`
  : !value || typeof value !== 'object'
    ? JSON.stringify(value)
    : `{${Object.keys(/** @type {Record<string, unknown>} */ (value)).sort()
        .map((key) => `${JSON.stringify(key)}:${canonicalJY200DuoJson(/** @type {Record<string, unknown>} */ (value)[key])}`)
        .join(',')}}`

/**
 * Bind the Writer bundle and Launcher-owned private Java into one runtime
 * identity. Execution and lifecycle verification must use this exact helper so
 * a receipt cannot be replayed against the same Writer JARs on another Java
 * tree.
 * @param {{writerBuildDigest: string, javaInventoryFingerprint: string}} input
 */
export const fingerprintJY200DuoProductRuntime = ({
  writerBuildDigest,
  javaInventoryFingerprint,
}) => {
  if (!FINGERPRINT.test(writerBuildDigest ?? '') || !FINGERPRINT.test(javaInventoryFingerprint ?? '')) {
    throw new Error('JY200_DUO_PRODUCT_RUNTIME_IDENTITY_INVALID')
  }
  return fingerprintJY200DuoValue(canonicalJY200DuoJson({
    writerBuildDigest,
    javaInventoryFingerprint,
  }))
}

/**
 * Bind Writer output across the publisher's homepage metadata normalization.
 * Only the three top-level fields owned by publishJY200DuoStagingDraft are
 * excluded; tracks, materials, resource identities and all other metadata
 * remain part of the signed execution identity.
 * @param {unknown} value
 */
export const fingerprintJY200DuoExecutionDraft = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('JY200_DUO_EXECUTION_DRAFT_INVALID')
  }
  const stable = Object.fromEntries(Object.entries(/** @type {Record<string, unknown>} */ (value))
    .filter(([key]) => !PUBLISHER_OWNED_DRAFT_INFO_KEYS.has(key)))
  return fingerprintJY200DuoValue(canonicalJY200DuoJson(stable))
}

/** @param {ReadonlyArray<Record<string, any>>} bindings @returns {ReadonlyArray<Record<string, any>>|null} */
const normalizeExecutionBindings = (bindings) => {
  if (!Array.isArray(bindings) || bindings.length !== 3 ||
      bindings.some((binding) => !exactKeys(binding, EXECUTION_BINDING_KEYS) ||
        binding.schema_version !== 1 || binding.kind !== 'jy200_duo_local_resource_probe_candidate' ||
        !['sticker', 'flower', 'video_effect'].includes(binding.family) ||
        typeof binding.packaging_token !== 'string' ||
        !['binding_fingerprint', 'source_material_fingerprint', 'payload_fingerprint', 'source_fingerprint',
          'catalog_fingerprint', 'desktop_binding_fingerprint']
          .every((key) => FINGERPRINT.test(binding[key] ?? '')) ||
        binding.resource_mode !== 'jianying_managed' || binding.admission !== 'deferred' ||
        binding.writer_eligible !== false || binding.probe_candidate !== true)) return null
  const normalized = /** @type {Array<Record<string, any>>} */ (
    bindings.map((binding) => ({ ...binding })).sort((left, right) => left.family.localeCompare(right.family))
  )
  if (normalized.map((binding) => binding.family).join('\0') !== 'flower\0sticker\0video_effect' ||
      new Set(normalized.map((binding) => binding.packaging_token)).size !== 3) return null
  return Object.freeze(normalized.map(Object.freeze))
}

/** @param {ReadonlyArray<Record<string, any>>} bindings */
export const fingerprintJY200DuoBindingSet = (bindings) => {
  const normalized = normalizeExecutionBindings(bindings)
  if (!normalized) throw new Error('JY200_DUO_EXECUTION_BINDING_INVALID')
  return fingerprintJY200DuoValue(normalized
    .map((binding) => `${binding.family}\0${binding.packaging_token}\0${binding.binding_fingerprint}`)
    .join('\0'))
}

/** @param {unknown} value @param {string} integrityKey */
export const parseJY200DuoProbeExecutionReceipt = (value, integrityKey) => {
  const receipt = /** @type {any} */ (value)
  const bindings = normalizeExecutionBindings(receipt?.binding_evidence)
  const audioEvidence = normalizeAudioEvidence(receipt?.audio_evidence)
  if (!exactKeys(receipt, EXECUTION_RECEIPT_KEYS) || !bindings ||
      !audioEvidence || !FINGERPRINT.test(receipt.audio_evidence_fingerprint ?? '') ||
      receipt.schema_version !== 2 || receipt.kind !== 'jy200_duo_local_probe_execution' ||
      receipt.status !== 'probe_candidate_written' || receipt.admission !== 'deferred' ||
      receipt.writer_eligible !== false || receipt.catalog_bound !== true || receipt.provider !== 'duo-video' ||
      !COMMIT.test(receipt.provider_commit ?? '') || !DRAFT_ID.test(receipt.draft_id ?? '') ||
      !['build_digest', 'desktop_binding_fingerprint', 'current_catalog_fingerprint', 'draft_id_fingerprint',
        'initial_draft_fingerprint', 'binding_set_fingerprint', 'binding_evidence_fingerprint']
        .every((key) => FINGERPRINT.test(receipt[key] ?? '')) ||
      receipt.draft_id_fingerprint !== fingerprintJY200DuoValue(receipt.draft_id) ||
      receipt.binding_set_fingerprint !== fingerprintJY200DuoBindingSet(bindings) ||
      receipt.binding_evidence_fingerprint !== fingerprintJY200DuoValue(canonicalJY200DuoJson(bindings)) ||
      receipt.audio_evidence_fingerprint !== fingerprintJY200DuoValue(canonicalJY200DuoJson(audioEvidence)) ||
      canonicalJY200DuoJson(receipt.capability_snapshot) !== canonicalJY200DuoJson(LOCAL_CAPABILITIES) ||
      bindings.some((binding) => binding.catalog_fingerprint !== receipt.current_catalog_fingerprint ||
        binding.desktop_binding_fingerprint !== receipt.desktop_binding_fingerprint) ||
      Number.isNaN(Date.parse(receipt.created_at)) || receipt.integrity_revision !== 2 ||
      !verifyArtistEffectStickerReceiptSignature(receipt, integrityKey)) return null
  return Object.freeze({ ...receipt, binding_evidence: bindings, audio_evidence: audioEvidence, capability_snapshot: LOCAL_CAPABILITIES })
}

/** @param {Record<string, any>} input @param {string} integrityKey */
export const createJY200DuoProbeExecutionReceipt = (input, integrityKey) => {
  const bindings = normalizeExecutionBindings(input?.bindingEvidence)
  const audioEvidence = normalizeAudioEvidence(input?.audioEvidence ?? [])
  if (!bindings || !audioEvidence) throw new Error('JY200_DUO_EXECUTION_BINDING_INVALID')
  if (!DRAFT_ID.test(input?.draftId ?? '')) throw new Error('JY200_DUO_EXECUTION_DRAFT_ID_INVALID')
  const unsigned = {
    schema_version: 2,
    kind: 'jy200_duo_local_probe_execution',
    status: 'probe_candidate_written',
    admission: 'deferred',
    writer_eligible: false,
    catalog_bound: true,
    provider: 'duo-video',
    provider_commit: input.providerCommit,
    build_digest: input.buildDigest,
    profile_id: input.profileId,
    app_version: input.appVersion,
    desktop_binding_fingerprint: input.desktopBindingFingerprint,
    current_catalog_fingerprint: input.currentCatalogFingerprint,
    draft_id: input.draftId,
    draft_id_fingerprint: fingerprintJY200DuoValue(input.draftId),
    initial_draft_fingerprint: input.initialDraftFingerprint,
    binding_set_fingerprint: fingerprintJY200DuoBindingSet(bindings),
    binding_evidence_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(bindings)),
    audio_evidence_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(audioEvidence)),
    audio_evidence: audioEvidence,
    capability_snapshot: [...LOCAL_CAPABILITIES],
    binding_evidence: bindings.map((binding) => ({ ...binding })),
    created_at: input.createdAt ?? new Date().toISOString(),
    integrity_revision: 2,
  }
  const receipt = { ...unsigned, integrity_signature: signArtistEffectStickerReceipt(unsigned, integrityKey) }
  const parsed = parseJY200DuoProbeExecutionReceipt(receipt, integrityKey)
  if (!parsed) throw new Error('JY200_DUO_EXECUTION_RECEIPT_INVALID')
  return parsed
}

/** @param {unknown} value @param {readonly string[]} keys */
const exactKeys = (value, keys) => value && typeof value === 'object' &&
  Object.keys(/** @type {Record<string, unknown>} */ (value)).sort().join('\0') === [...keys].sort().join('\0')

/** @param {unknown} value */
const draftShape = (value) => {
  const draft = /** @type {any} */ (value)
  const materials = draft?.materials
  /** @type {Array<Record<string, any>>} */
  const tracks = Array.isArray(draft?.tracks) ? draft.tracks : []
  const texts = Array.isArray(materials?.texts) ? materials.texts : []
  const videos = Array.isArray(materials?.videos) ? materials.videos : []
  const audios = Array.isArray(materials?.audios) ? materials.audios : []
  const stickers = Array.isArray(materials?.stickers) ? materials.stickers : []
  const videoEffects = Array.isArray(materials?.video_effects) ? materials.video_effects : []
  const legacyEffects = Array.isArray(materials?.effects) ? materials.effects : []
  const videoTracks = tracks.filter((track) => track?.type === 'video')
  const audioTracks = tracks.filter((track) => track?.type === 'audio')
  const textTracks = tracks.filter((track) => track?.type === 'text')
  const stickerTracks = tracks.filter((track) => track?.type === 'sticker')
  const effectTracks = tracks.filter((track) => track?.type === 'effect')
  const activeTracks = tracks.filter((track) => Array.isArray(track?.segments) && track.segments.length > 0)
  const allSegments = activeTracks.flatMap((track) => track.segments)
  const textSegments = textTracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
  const audioSegments = audioTracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
  const stickerSegments = stickerTracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
  const effectSegments = effectTracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
  return {
    draft, texts, videos, audios, stickers, videoEffects, legacyEffects, tracks, videoTracks, audioTracks, textTracks,
    stickerTracks, effectTracks, activeTracks, allSegments, textSegments, audioSegments, stickerSegments, effectSegments,
  }
}

const FULL_AV_MATERIALS = /** @type {ReadonlyArray<readonly [string, 'audios'|'videoEffects'|'stickers'|'texts'|'videos']>} */ (Object.freeze([
  ['audio', 'audios'],
  ['effect', 'videoEffects'],
  ['sticker', 'stickers'],
  ['text', 'texts'],
  ['video', 'videos'],
]))

/** @param {ReturnType<typeof draftShape>} shape */
const fullAvAttachmentIdentity = (shape) => {
  const materialIdentity = []
  const segmentIdentity = []
  for (const [trackType, materialKey] of FULL_AV_MATERIALS) {
    const materials = /** @type {Array<Record<string, any>>} */ (shape[materialKey])
    const materialIds = /** @type {string[]} */ (materials.map((material) => material?.id))
    const segments = shape.tracks
      .filter((track) => track?.type === trackType)
      .flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
    if (materialIds.some((id) => typeof id !== 'string' || id.length === 0) ||
        new Set(materialIds).size !== materialIds.length || segments.length !== materialIds.length ||
        segments.some((segment) => typeof segment?.id !== 'string' || segment.id.length === 0 ||
          typeof segment?.material_id !== 'string' || !materialIds.includes(segment.material_id)) ||
        new Set(segments.map((segment) => segment.id)).size !== segments.length ||
        new Set(segments.map((segment) => segment.material_id)).size !== materialIds.length) return null
    materialIdentity.push(...materialIds.map((id) => `${trackType}\0${id}`))
    segmentIdentity.push(...segments.map((segment) => `${trackType}\0${segment.id}\0${segment.material_id}`))
  }
  return Object.freeze({
    materials: Object.freeze(materialIdentity.sort()),
    segments: Object.freeze(segmentIdentity.sort()),
  })
}

/** @param {ReturnType<typeof draftShape>} shape @returns {number[]} */
const audioTrackDistribution = (shape) => shape.audioTracks
  .map((/** @type {Record<string, any>} */ track) => Array.isArray(track?.segments) ? track.segments.length : 0)
  .sort((/** @type {number} */ left, /** @type {number} */ right) => right - left)

/** @param {number} left @param {number} right */
const closeNumber = (left, right) => Number.isFinite(left) && Number.isFinite(right) && Math.abs(left - right) <= 1e-6

/**
 * Independently compare Duo's original plaintext output with Jianying's saved
 * encrypted-v2 readback. Raw resource IDs and paths never leave this helper.
 * @param {{initialDraft: unknown, postSaveDraft: unknown, expectedRotation?: number, expectedTextTransform?: {x: number, y: number}, expectedAudioVolume?: number}} input
 */
export const inspectJY200DuoDirectLifecycle = ({ initialDraft, postSaveDraft, expectedRotation, expectedTextTransform, expectedAudioVolume }) => {
  if (Number.isFinite(expectedAudioVolume) && Number(expectedAudioVolume) > 0) {
    const expectedVolume = Number(expectedAudioVolume)
    const initial = draftShape(initialDraft)
    const saved = draftShape(postSaveDraft)
    const shapes = [initial, saved]
    if (shapes.some((candidate) => candidate.videos.length !== 3 || candidate.audios.length !== 5 ||
        candidate.texts.length !== 4 || candidate.stickers.length !== 1 || candidate.videoEffects.length !== 1 ||
        candidate.allSegments.length !== 14 || candidate.videoTracks.length !== 1 ||
        candidate.videoTracks[0]?.segments?.length !== 3 || candidate.audioSegments.length !== 5 ||
        candidate.textSegments.length !== 4 || candidate.stickerSegments.length !== 1 ||
        candidate.effectSegments.length !== 1)) return null
    if (initial.tracks.length !== 6 || initial.activeTracks.length !== 6 || initial.audioTracks.length !== 2 ||
        canonicalJY200DuoJson(audioTrackDistribution(initial)) !== canonicalJY200DuoJson([4, 1]) ||
        initial.textTracks.length !== 1 || initial.textTracks[0]?.segments?.length !== 4 ||
        saved.tracks.length !== 8 || saved.activeTracks.length !== 8 || saved.audioTracks.length !== 3 ||
        canonicalJY200DuoJson(audioTrackDistribution(saved)) !== canonicalJY200DuoJson([3, 1, 1]) ||
        saved.textTracks.length !== 2 ||
        canonicalJY200DuoJson(saved.textTracks.map((track) => track.segments.length).sort((left, right) => right - left)) !==
          canonicalJY200DuoJson([3, 1]) || initial.legacyEffects.length < 1 || saved.legacyEffects.length !== 0) return null

    const initialAttachments = fullAvAttachmentIdentity(initial)
    const savedAttachments = fullAvAttachmentIdentity(saved)
    if (!initialAttachments || !savedAttachments ||
        canonicalJY200DuoJson(initialAttachments) !== canonicalJY200DuoJson(savedAttachments)) return null
    const initialAudioById = new Map(initial.audioSegments.map((segment) => [segment.id, segment]))
    const persistedSegments = saved.audioSegments.filter((segment) => closeNumber(Number(segment?.volume), expectedVolume))
    if (persistedSegments.length !== 1) return null
    const persistedSegment = persistedSegments[0]
    const initialSegment = initialAudioById.get(persistedSegment.id)
    const initialVolume = Number(initialSegment?.volume)
    if (!Number.isFinite(initialVolume) || closeNumber(initialVolume, expectedVolume) ||
        initial.draft?.id !== saved.draft?.id) return null

    const initialTextById = new Map(initial.texts.map((/** @type {Record<string, any>} */ material) => [material?.id, material?.content]))
    if (initialTextById.size !== 4 || saved.texts.some((/** @type {Record<string, any>} */ material) => typeof material?.content !== 'string' ||
        material.content.length < 4 || initialTextById.get(material.id) !== material.content)) return null
    const initialFlower = initial.legacyEffects[0]
    const resources = [initial.stickers[0]?.resource_id, initialFlower?.resource_id, initial.videoEffects[0]?.resource_id]
    if (resources.some((resource) => typeof resource !== 'string' || resource.length < 4) ||
        saved.stickers[0]?.resource_id !== resources[0] || saved.videoEffects[0]?.resource_id !== resources[2] ||
        typeof initialFlower?.effect_id !== 'string' || initialFlower.effect_id.length < 4) return null

    const attachmentSetFingerprint = fingerprintJY200DuoValue(canonicalJY200DuoJson(initialAttachments))
    return Object.freeze({
      stickers: 1,
      flowers: 1,
      video_effects: 1,
      videos: 3,
      audios: 5,
      texts: 4,
      tracks: 8,
      segments: 14,
      audio_tracks: 3,
      audio_segments: 5,
      audio_track_segments: Object.freeze([3, 1, 1]),
      edit_kind: 'audio_volume',
      initial_edit_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson({ id: persistedSegment.id, volume: initialVolume })),
      persisted_edit_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson({ id: persistedSegment.id, volume: expectedVolume })),
      attachment_set_fingerprint: attachmentSetFingerprint,
      flower_style_fingerprint: fingerprintJY200DuoValue(initial.texts
        .map((/** @type {Record<string, any>} */ material) => `${material.id}\0${material.content}`).sort().join('\0')),
      resource_set_fingerprint: fingerprintJY200DuoValue(resources.join('\0')),
    })
  }
  if (expectedTextTransform && Number.isFinite(expectedTextTransform.x) && Number.isFinite(expectedTextTransform.y)) {
    const initial = draftShape(initialDraft)
    const saved = draftShape(postSaveDraft)
    const shapes = [initial, saved]
    if (shapes.some((candidate) => candidate.videos.length !== 1 || candidate.texts.length !== 2 ||
        candidate.stickers.length !== 1 || candidate.videoEffects.length !== 1 || candidate.tracks.length !== 4 ||
        candidate.activeTracks.length !== 4 || candidate.videoTracks.length !== 1 || candidate.textTracks.length !== 1 ||
        candidate.stickerTracks.length !== 1 || candidate.effectTracks.length !== 1 || candidate.allSegments.length !== 5 ||
        candidate.videoTracks[0].segments.length !== 1 || candidate.textSegments.length !== 2 ||
        candidate.stickerSegments.length !== 1 || candidate.effectSegments.length !== 1)) return null
    if (initial.legacyEffects.length < 1 || saved.legacyEffects.length !== 0) return null

    const initialTextSegment = initial.textSegments[0]
    const savedTextSegment = saved.textSegments[0]
    const initialTransform = initialTextSegment?.clip?.transform
    const savedTransform = savedTextSegment?.clip?.transform
    const expectedTransform = { x: expectedTextTransform.x, y: expectedTextTransform.y }
    const initialTransformFingerprint = fingerprintJY200DuoValue(canonicalJY200DuoJson(initialTransform))
    const persistedTransformFingerprint = fingerprintJY200DuoValue(canonicalJY200DuoJson(expectedTransform))
    const stableText = initial.texts.every((/** @type {Record<string, any>} */ material, /** @type {number} */ index) => material?.id === saved.texts[index]?.id &&
      typeof material?.content === 'string' && material.content.length >= 4 && material.content === saved.texts[index]?.content)
    const stableAttachments = [
      [initial.videoTracks[0]?.segments?.[0], initial.videos[0], saved.videoTracks[0]?.segments?.[0], saved.videos[0]],
      [initial.stickerSegments[0], initial.stickers[0], saved.stickerSegments[0], saved.stickers[0]],
      [initial.effectSegments[0], initial.videoEffects[0], saved.effectSegments[0], saved.videoEffects[0]],
    ].every(([initialSegment, initialMaterial, savedSegment, savedMaterial]) =>
      initialMaterial?.id === savedMaterial?.id && initialSegment?.material_id === initialMaterial?.id &&
      savedSegment?.material_id === savedMaterial?.id)
    const stableTextAttachments = initial.textSegments.every((segment, index) =>
      segment?.material_id === initial.texts[index]?.id && saved.textSegments[index]?.material_id === saved.texts[index]?.id)
    const initialFlower = initial.legacyEffects[0]
    const resources = [initial.stickers[0]?.resource_id, initialFlower?.resource_id, initial.videoEffects[0]?.resource_id]
    if (initial.draft?.id !== saved.draft?.id || !stableText || !stableAttachments || !stableTextAttachments ||
        !initialTransform || !savedTransform || canonicalJY200DuoJson(initialTransform) === canonicalJY200DuoJson(expectedTransform) ||
        canonicalJY200DuoJson(savedTransform) !== canonicalJY200DuoJson(expectedTransform) ||
        resources.some((resource) => typeof resource !== 'string' || resource.length < 4) ||
        saved.stickers[0]?.resource_id !== resources[0] || saved.videoEffects[0]?.resource_id !== resources[2] ||
        typeof initialFlower?.effect_id !== 'string' || initialFlower.effect_id.length < 4) return null
    return Object.freeze({
      stickers: 1,
      flowers: 1,
      video_effects: 1,
      videos: 1,
      texts: 2,
      tracks: 4,
      segments: 5,
      edit_kind: 'text_transform',
      initial_edit_fingerprint: initialTransformFingerprint,
      persisted_edit_fingerprint: persistedTransformFingerprint,
      flower_style_fingerprint: fingerprintJY200DuoValue(initial.texts.map((/** @type {Record<string, any>} */ material) => material.content).join('\0')),
      resource_set_fingerprint: fingerprintJY200DuoValue(resources.join('\0')),
    })
  }
  if (!Number.isFinite(expectedRotation)) return null
  const initial = draftShape(initialDraft)
  const saved = draftShape(postSaveDraft)
  const shapes = [initial, saved]
  if (shapes.some((candidate) => candidate.texts.length !== 1 || candidate.stickers.length !== 1 ||
      candidate.videoEffects.length !== 1 || candidate.activeTracks.length !== 3 || candidate.textTracks.length !== 1 ||
      candidate.stickerTracks.length !== 1 || candidate.effectTracks.length !== 1 || candidate.allSegments.length !== 3 ||
      candidate.textSegments.length !== 1 || candidate.stickerSegments.length !== 1 ||
      candidate.effectSegments.length !== 1)) return null
  if (initial.tracks.length !== 3 || initial.videoTracks.length !== 0 || saved.tracks.length !== 4 ||
      saved.videoTracks.length !== 1 || (saved.videoTracks[0]?.segments ?? []).length !== 0 ||
      initial.legacyEffects.length !== 1 || saved.legacyEffects.length !== 0) return null
  const initialStickerSegment = initial.stickerSegments[0]
  const savedStickerSegment = saved.stickerSegments[0]
  const initialFlowerResource = initial.legacyEffects[0]?.resource_id
  const initialFlowerEffect = initial.legacyEffects[0]?.effect_id
  const initialTextContent = initial.texts[0]?.content
  const savedTextContent = saved.texts[0]?.content
  const resources = [initial.stickers[0]?.resource_id, initialFlowerResource, initial.videoEffects[0]?.resource_id]
  const initialRotation = Number(initialStickerSegment?.clip?.rotation)
  const savedRotation = Number(savedStickerSegment?.clip?.rotation)
  if (!Number.isFinite(initialRotation) || initialRotation === expectedRotation ||
      savedRotation !== expectedRotation ||
      initial.draft?.id !== saved.draft?.id ||
      initial.texts[0]?.id !== saved.texts[0]?.id || initial.stickers[0]?.id !== saved.stickers[0]?.id ||
      initial.videoEffects[0]?.id !== saved.videoEffects[0]?.id ||
      initialStickerSegment?.material_id !== initial.stickers[0]?.id ||
      savedStickerSegment?.material_id !== saved.stickers[0]?.id ||
      initial.textSegments[0]?.material_id !== initial.texts[0]?.id ||
      saved.textSegments[0]?.material_id !== saved.texts[0]?.id ||
      initial.effectSegments[0]?.material_id !== initial.videoEffects[0]?.id ||
      saved.effectSegments[0]?.material_id !== saved.videoEffects[0]?.id ||
      resources.some((resource) => typeof resource !== 'string' || resource.length < 4) ||
      saved.stickers[0]?.resource_id !== resources[0] || saved.videoEffects[0]?.resource_id !== resources[2] ||
      typeof initialFlowerEffect !== 'string' || initialFlowerEffect.length < 4 ||
      typeof initialTextContent !== 'string' || initialTextContent.length < 4 || savedTextContent !== initialTextContent) return null
  return Object.freeze({
    stickers: 1,
    flowers: 1,
    video_effects: 1,
    tracks: 3,
    segments: 3,
    saved_empty_video_tracks: 1,
    initial_rotation: initialRotation,
    persisted_rotation: expectedRotation,
    flower_style_fingerprint: fingerprintJY200DuoValue(initialTextContent),
    resource_set_fingerprint: fingerprintJY200DuoValue(resources.join('\0')),
  })
}

/**
 * Bind the three independently read-back Duo resources to the exact entries
 * admitted by the current private evidence registry. This helper returns only
 * opaque fingerprints and semantic capability IDs.
 * @param {{initialDraft: unknown, admittedIndex: any, evidence: any}} input
 */
export const bindJY200DuoLifecycleToCurrentCatalog = ({ initialDraft, admittedIndex, evidence }) => {
  const shape = draftShape(initialDraft)
  if (!admittedIndex || !Array.isArray(admittedIndex.entries) ||
      admittedIndex.evidenceId !== evidence?.evidence_id ||
      admittedIndex.catalogFingerprint !== evidence?.catalog_fingerprint ||
      !Array.isArray(evidence?.admitted_bindings)) return null
  const requested = [
    { family: 'sticker', resourceId: shape.stickers[0]?.resource_id, effectId: undefined },
    { family: 'flower', resourceId: shape.legacyEffects[0]?.resource_id, effectId: shape.legacyEffects[0]?.effect_id },
    { family: 'video_effect', resourceId: shape.videoEffects[0]?.resource_id, effectId: shape.videoEffects[0]?.effect_id },
  ]
  const evidenceByToken = new Map(evidence.admitted_bindings.map((/** @type {Record<string, any>} */ binding) => [binding?.packaging_token, binding]))
  const matched = requested.map((resource) => admittedIndex.entries.find((/** @type {Record<string, any>} */ entry) => {
    if (entry?.family !== resource.family || entry?.state !== 'writer_eligible' || entry?.writer_eligible !== true ||
        entry?.private_binding?.resourceId !== resource.resourceId) return false
    return resource.effectId === undefined || entry.private_binding.effectId === resource.effectId
  }))
  if (matched.some((entry) => !entry) || new Set(matched.map((entry) => entry.packaging_token)).size !== 3) return null
  const bindings = matched.map((entry) => evidenceByToken.get(entry.packaging_token))
  if (bindings.some((binding, index) => !binding || binding.family !== matched[index].family)) return null
  const bindingIdentity = bindings
    .map((binding) => `${binding.family}\0${binding.packaging_token}\0${binding.binding_fingerprint}`)
    .sort()
  const bindingEvidence = bindings
    .map((binding) => Object.freeze({
      family: binding.family,
      packaging_token: binding.packaging_token,
      binding_fingerprint: binding.binding_fingerprint,
    }))
    .sort((left, right) => left.family.localeCompare(right.family))
  return Object.freeze({
    families: Object.freeze(['flower', 'sticker', 'video_effect']),
    capabilities: LOCAL_CAPABILITIES,
    binding_set_fingerprint: fingerprintJY200DuoValue(bindingIdentity.join('\0')),
    current_evidence_fingerprint: fingerprintJY200DuoValue(canonicalJY200DuoJson(evidence)),
    binding_evidence: Object.freeze(bindingEvidence),
  })
}

const receiptKeys = Object.freeze([
  'schema_version', 'kind', 'status', 'admission', 'writer_eligible', 'provider', 'provider_commit',
  'build_digest', 'profile_id', 'app_version', 'desktop_binding_fingerprint', 'current_catalog_fingerprint',
  'catalog_bound', 'draft_id_fingerprint', 'initial_draft_fingerprint', 'post_save_draft_fingerprint',
  'encrypted_draft_fingerprint', 'resource_set_fingerprint', 'external_resource_dependent', 'resource_origin',
  'readback', 'manual_attestation', 'opened', 'edited', 'saved', 'closed', 'reopened', 'same_draft',
  'verified_at', 'integrity_revision', 'integrity_signature',
])
const readbackKeys = Object.freeze([
  'stickers', 'flowers', 'video_effects', 'tracks', 'segments', 'saved_empty_video_tracks',
  'initial_rotation', 'persisted_rotation', 'flower_style_fingerprint',
])
const legacyLocalReadbackKeys = Object.freeze([
  'stickers', 'flowers', 'video_effects', 'videos', 'texts', 'tracks', 'segments', 'edit_kind',
  'initial_edit_fingerprint', 'persisted_edit_fingerprint', 'flower_style_fingerprint',
])
const fullAvLocalReadbackKeys = Object.freeze([
  'stickers', 'flowers', 'video_effects', 'videos', 'audios', 'texts', 'tracks', 'segments',
  'audio_tracks', 'audio_segments', 'audio_track_segments', 'edit_kind', 'initial_edit_fingerprint',
  'persisted_edit_fingerprint', 'attachment_set_fingerprint', 'flower_style_fingerprint',
])
const directProbeReadbackInputKeys = Object.freeze([...readbackKeys, 'resource_set_fingerprint'])
const legacyLocalReadbackInputKeys = Object.freeze([...legacyLocalReadbackKeys, 'resource_set_fingerprint'])
const fullAvLocalReadbackInputKeys = Object.freeze([...fullAvLocalReadbackKeys, 'resource_set_fingerprint'])

/** @param {unknown} value */
const validDirectProbeReadback = (value) => {
  const readback = /** @type {any} */ (value)
  return exactKeys(readback, readbackKeys) &&
    readback.stickers === 1 &&
    readback.flowers === 1 &&
    readback.video_effects === 1 &&
    readback.tracks === 3 &&
    readback.segments === 3 &&
    readback.saved_empty_video_tracks === 1 &&
    FINGERPRINT.test(readback.flower_style_fingerprint ?? '') &&
    Number.isFinite(readback.initial_rotation) &&
    Number.isFinite(readback.persisted_rotation) &&
    readback.initial_rotation !== readback.persisted_rotation
}

/** @param {unknown} value */
const validDirectProbeReadbackInput = (value) => {
  const readback = /** @type {any} */ (value)
  return exactKeys(readback, directProbeReadbackInputKeys) &&
    FINGERPRINT.test(readback.resource_set_fingerprint ?? '') &&
    validDirectProbeReadback(Object.fromEntries(
      Object.entries(readback).filter(([key]) => key !== 'resource_set_fingerprint'),
    ))
}

/** @param {unknown} value */
const validLegacyLocalCatalogReadback = (value) => {
  const readback = /** @type {any} */ (value)
  return exactKeys(readback, legacyLocalReadbackKeys) &&
    readback.stickers === 1 &&
    readback.flowers === 1 &&
    readback.video_effects === 1 &&
    readback.videos === 1 &&
    readback.texts === 2 &&
    readback.tracks === 4 &&
    readback.segments === 5 &&
    readback.edit_kind === 'text_transform' &&
    FINGERPRINT.test(readback.flower_style_fingerprint ?? '') &&
    FINGERPRINT.test(readback.initial_edit_fingerprint ?? '') &&
    FINGERPRINT.test(readback.persisted_edit_fingerprint ?? '') &&
    readback.initial_edit_fingerprint !== readback.persisted_edit_fingerprint
}

/** @param {unknown} value */
const validLegacyLocalCatalogReadbackInput = (value) => {
  const readback = /** @type {any} */ (value)
  return exactKeys(readback, legacyLocalReadbackInputKeys) &&
    FINGERPRINT.test(readback.resource_set_fingerprint ?? '') &&
    validLegacyLocalCatalogReadback(Object.fromEntries(
      Object.entries(readback).filter(([key]) => key !== 'resource_set_fingerprint'),
    ))
}

/** @param {unknown} value */
const validFullAvLocalCatalogReadback = (value) => {
  const readback = /** @type {any} */ (value)
  return exactKeys(readback, fullAvLocalReadbackKeys) &&
    readback.stickers === 1 &&
    readback.flowers === 1 &&
    readback.video_effects === 1 &&
    readback.videos === 3 &&
    readback.audios === 5 &&
    readback.texts === 4 &&
    readback.tracks === 8 &&
    readback.segments === 14 &&
    readback.audio_tracks === 3 &&
    readback.audio_segments === 5 &&
    canonicalJY200DuoJson(readback.audio_track_segments) === canonicalJY200DuoJson([3, 1, 1]) &&
    readback.edit_kind === 'audio_volume' &&
    ['initial_edit_fingerprint', 'persisted_edit_fingerprint', 'attachment_set_fingerprint',
      'flower_style_fingerprint'].every((key) => FINGERPRINT.test(readback[key] ?? '')) &&
    readback.initial_edit_fingerprint !== readback.persisted_edit_fingerprint
}

/** @param {unknown} value */
const validFullAvLocalCatalogReadbackInput = (value) => {
  const readback = /** @type {any} */ (value)
  return exactKeys(readback, fullAvLocalReadbackInputKeys) &&
    FINGERPRINT.test(readback.resource_set_fingerprint ?? '') &&
    validFullAvLocalCatalogReadback(Object.fromEntries(
      Object.entries(readback).filter(([key]) => key !== 'resource_set_fingerprint'),
    ))
}

/** @param {unknown} value */
const validLocalCatalogReadback = (value) =>
  validDirectProbeReadback(value) || validLegacyLocalCatalogReadback(value) || validFullAvLocalCatalogReadback(value)

/** @param {unknown} value */
const validLocalCatalogReadbackInput = (value) =>
  validDirectProbeReadbackInput(value) || validLegacyLocalCatalogReadbackInput(value) || validFullAvLocalCatalogReadbackInput(value)

/** @param {Record<string, any>} readback */
const cloneLocalCatalogReadback = (readback) => {
  if (validDirectProbeReadbackInput(readback)) return {
      stickers: readback.stickers,
      flowers: readback.flowers,
      video_effects: readback.video_effects,
      tracks: readback.tracks,
      segments: readback.segments,
      saved_empty_video_tracks: readback.saved_empty_video_tracks,
      initial_rotation: readback.initial_rotation,
      persisted_rotation: readback.persisted_rotation,
      flower_style_fingerprint: readback.flower_style_fingerprint,
    }
  if (validLegacyLocalCatalogReadbackInput(readback)) return {
      stickers: readback.stickers,
      flowers: readback.flowers,
      video_effects: readback.video_effects,
      videos: readback.videos,
      texts: readback.texts,
      tracks: readback.tracks,
      segments: readback.segments,
      edit_kind: readback.edit_kind,
      initial_edit_fingerprint: readback.initial_edit_fingerprint,
      persisted_edit_fingerprint: readback.persisted_edit_fingerprint,
      flower_style_fingerprint: readback.flower_style_fingerprint,
    }
  return {
    stickers: readback.stickers,
    flowers: readback.flowers,
    video_effects: readback.video_effects,
    videos: readback.videos,
    audios: readback.audios,
    texts: readback.texts,
    tracks: readback.tracks,
    segments: readback.segments,
    audio_tracks: readback.audio_tracks,
    audio_segments: readback.audio_segments,
    audio_track_segments: [...readback.audio_track_segments],
    edit_kind: readback.edit_kind,
    initial_edit_fingerprint: readback.initial_edit_fingerprint,
    persisted_edit_fingerprint: readback.persisted_edit_fingerprint,
    attachment_set_fingerprint: readback.attachment_set_fingerprint,
    flower_style_fingerprint: readback.flower_style_fingerprint,
  }
}

/** @param {unknown} value @param {string} integrityKey */
export const parseJY200DuoDirectLifecycleReceipt = (value, integrityKey) => {
  const receipt = /** @type {any} */ (value)
  if (!exactKeys(receipt, receiptKeys) || !exactKeys(receipt?.readback, readbackKeys) ||
      receipt.schema_version !== 2 || receipt.kind !== 'jy200_duo_direct_probe_lifecycle' ||
      receipt.status !== 'technical_go' || receipt.admission !== 'deferred' || receipt.writer_eligible !== false ||
      receipt.provider !== 'duo-video' || !COMMIT.test(receipt.provider_commit ?? '') ||
      !['build_digest', 'desktop_binding_fingerprint', 'current_catalog_fingerprint', 'draft_id_fingerprint',
        'initial_draft_fingerprint', 'post_save_draft_fingerprint', 'encrypted_draft_fingerprint',
        'resource_set_fingerprint'].every((key) => FINGERPRINT.test(receipt[key] ?? '')) ||
      receipt.catalog_bound !== false || receipt.external_resource_dependent !== true ||
      receipt.resource_origin !== 'api.duoec.com' || receipt.manual_attestation !== ATTESTATION ||
      !['opened', 'edited', 'saved', 'closed', 'reopened', 'same_draft'].every((key) => receipt[key] === true) ||
      receipt.integrity_revision !== 1 || Number.isNaN(Date.parse(receipt.verified_at)) ||
      receipt.readback.stickers !== 1 || receipt.readback.flowers !== 1 || receipt.readback.video_effects !== 1 ||
      receipt.readback.tracks !== 3 || receipt.readback.segments !== 3 ||
      receipt.readback.saved_empty_video_tracks !== 1 ||
      !FINGERPRINT.test(receipt.readback.flower_style_fingerprint ?? '') ||
      !Number.isFinite(receipt.readback.initial_rotation) || !Number.isFinite(receipt.readback.persisted_rotation) ||
      receipt.readback.initial_rotation === receipt.readback.persisted_rotation ||
      !verifyArtistEffectStickerReceiptSignature(receipt, integrityKey)) return null
  return Object.freeze(receipt)
}

/**
 * Mint a private, non-admission lifecycle receipt after the observed desktop
 * cycle and independent encrypted readback have both completed.
 * @param {Record<string, any>} input
 * @param {string} integrityKey
 */
export const createJY200DuoDirectLifecycleReceipt = (input, integrityKey) => {
  if (!DRAFT_ID.test(input?.draftId ?? '') || !input?.readback ||
      input.readback.resource_set_fingerprint !== input.resourceSetFingerprint) {
    throw new Error('JY200_DUO_LIFECYCLE_INPUT_INVALID')
  }
  const unsigned = {
    schema_version: 2,
    kind: 'jy200_duo_direct_probe_lifecycle',
    status: 'technical_go',
    admission: 'deferred',
    writer_eligible: false,
    provider: 'duo-video',
    provider_commit: input.providerCommit,
    build_digest: input.buildDigest,
    profile_id: input.profileId,
    app_version: input.appVersion,
    desktop_binding_fingerprint: input.desktopBindingFingerprint,
    current_catalog_fingerprint: input.currentCatalogFingerprint,
    catalog_bound: false,
    draft_id_fingerprint: fingerprintJY200DuoValue(input.draftId),
    initial_draft_fingerprint: input.initialDraftFingerprint,
    post_save_draft_fingerprint: input.postSaveDraftFingerprint,
    encrypted_draft_fingerprint: input.encryptedDraftFingerprint,
    resource_set_fingerprint: input.resourceSetFingerprint,
    external_resource_dependent: true,
    resource_origin: 'api.duoec.com',
    readback: {
      stickers: input.readback.stickers,
      flowers: input.readback.flowers,
      video_effects: input.readback.video_effects,
      tracks: input.readback.tracks,
      segments: input.readback.segments,
      saved_empty_video_tracks: input.readback.saved_empty_video_tracks,
      initial_rotation: input.readback.initial_rotation,
      persisted_rotation: input.readback.persisted_rotation,
      flower_style_fingerprint: input.readback.flower_style_fingerprint,
    },
    manual_attestation: ATTESTATION,
    opened: true,
    edited: true,
    saved: true,
    closed: true,
    reopened: true,
    same_draft: true,
    verified_at: input.verifiedAt ?? new Date().toISOString(),
    integrity_revision: 1,
  }
  const receipt = { ...unsigned, integrity_signature: signArtistEffectStickerReceipt(unsigned, integrityKey) }
  if (!parseJY200DuoDirectLifecycleReceipt(receipt, integrityKey)) throw new Error('JY200_DUO_LIFECYCLE_RECEIPT_INVALID')
  return Object.freeze(receipt)
}

const localReceiptKeys = Object.freeze([
  ...receiptKeys,
  'binding_set_fingerprint', 'current_evidence_fingerprint', 'capability_snapshot',
  'execution_receipt_fingerprint', 'execution_binding_evidence_fingerprint',
])

/** @param {unknown} value @param {string} integrityKey */
export const parseJY200DuoLocalCatalogLifecycleReceipt = (value, integrityKey) => {
  const receipt = /** @type {any} */ (value)
  const schemaReadbackMatches = receipt?.schema_version === 5
    ? validFullAvLocalCatalogReadback(receipt?.readback)
    : [3, 4].includes(receipt?.schema_version) &&
      (validDirectProbeReadback(receipt?.readback) || validLegacyLocalCatalogReadback(receipt?.readback))
  if (!exactKeys(receipt, localReceiptKeys) || !schemaReadbackMatches ||
      receipt.kind !== 'jy200_duo_local_catalog_lifecycle' ||
      receipt.status !== 'technical_go' || receipt.admission !== 'deferred' || receipt.writer_eligible !== false ||
      receipt.provider !== 'duo-video' || !COMMIT.test(receipt.provider_commit ?? '') ||
      !['build_digest', 'desktop_binding_fingerprint', 'current_catalog_fingerprint', 'draft_id_fingerprint',
        'initial_draft_fingerprint', 'post_save_draft_fingerprint', 'encrypted_draft_fingerprint',
        'resource_set_fingerprint', 'binding_set_fingerprint', 'current_evidence_fingerprint',
        'execution_receipt_fingerprint', 'execution_binding_evidence_fingerprint']
        .every((key) => FINGERPRINT.test(receipt[key] ?? '')) ||
      receipt.catalog_bound !== true || receipt.external_resource_dependent !== false ||
      receipt.resource_origin !== 'openvideo_private_catalog' || receipt.manual_attestation !== ATTESTATION ||
      JSON.stringify(receipt.capability_snapshot) !== JSON.stringify(LOCAL_CAPABILITIES) ||
      !['opened', 'edited', 'saved', 'closed', 'reopened', 'same_draft'].every((key) => receipt[key] === true) ||
      receipt.integrity_revision !== 1 || Number.isNaN(Date.parse(receipt.verified_at)) ||
      !verifyArtistEffectStickerReceiptSignature(receipt, integrityKey)) return null
  return Object.freeze(receipt)
}

/**
 * Mint a technical-only receipt for the local private-catalog path. Product
 * admission remains a separate trusted-registry decision.
 * @param {Record<string, any>} input
 * @param {string} integrityKey
 */
export const createJY200DuoLocalCatalogLifecycleReceipt = (input, integrityKey) => {
  if (!DRAFT_ID.test(input?.draftId ?? '') || !input?.readback || !input?.catalogBinding ||
      input.readback.resource_set_fingerprint !== input.resourceSetFingerprint ||
      JSON.stringify(input.catalogBinding.capabilities) !== JSON.stringify(LOCAL_CAPABILITIES) ||
      !validLocalCatalogReadbackInput(input.readback) ||
      !FINGERPRINT.test(input.executionReceiptFingerprint ?? '') ||
      !FINGERPRINT.test(input.executionBindingEvidenceFingerprint ?? '')) {
    throw new Error('JY200_DUO_LOCAL_LIFECYCLE_INPUT_INVALID')
  }
  const unsigned = {
    schema_version: validFullAvLocalCatalogReadbackInput(input.readback) ? 5 : 4,
    kind: 'jy200_duo_local_catalog_lifecycle',
    status: 'technical_go',
    admission: 'deferred',
    writer_eligible: false,
    provider: 'duo-video',
    provider_commit: input.providerCommit,
    build_digest: input.buildDigest,
    profile_id: input.profileId,
    app_version: input.appVersion,
    desktop_binding_fingerprint: input.desktopBindingFingerprint,
    current_catalog_fingerprint: input.currentCatalogFingerprint,
    catalog_bound: true,
    draft_id_fingerprint: fingerprintJY200DuoValue(input.draftId),
    initial_draft_fingerprint: input.initialDraftFingerprint,
    post_save_draft_fingerprint: input.postSaveDraftFingerprint,
    encrypted_draft_fingerprint: input.encryptedDraftFingerprint,
    resource_set_fingerprint: input.resourceSetFingerprint,
    external_resource_dependent: false,
    resource_origin: 'openvideo_private_catalog',
    readback: cloneLocalCatalogReadback(input.readback),
    manual_attestation: ATTESTATION,
    opened: true,
    edited: true,
    saved: true,
    closed: true,
    reopened: true,
    same_draft: true,
    verified_at: input.verifiedAt ?? new Date().toISOString(),
    integrity_revision: 1,
    binding_set_fingerprint: input.catalogBinding.binding_set_fingerprint,
    current_evidence_fingerprint: input.catalogBinding.current_evidence_fingerprint,
    capability_snapshot: [...LOCAL_CAPABILITIES],
    execution_receipt_fingerprint: input.executionReceiptFingerprint,
    execution_binding_evidence_fingerprint: input.executionBindingEvidenceFingerprint,
  }
  const receipt = { ...unsigned, integrity_signature: signArtistEffectStickerReceipt(unsigned, integrityKey) }
  if (!parseJY200DuoLocalCatalogLifecycleReceipt(receipt, integrityKey)) {
    throw new Error('JY200_DUO_LOCAL_LIFECYCLE_RECEIPT_INVALID')
  }
  return Object.freeze(receipt)
}
