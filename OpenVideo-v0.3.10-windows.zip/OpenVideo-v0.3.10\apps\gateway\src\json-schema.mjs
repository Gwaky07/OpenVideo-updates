const schemaTypes = ['object', 'array', 'string', 'number', 'integer', 'boolean', 'null']
const supportedKeywords = [
  'type',
  'properties',
  'required',
  'additionalProperties',
  'items',
  'enum',
  'const',
]

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} left @param {unknown} right @returns {boolean} */
const isJsonEqual = (left, right) => {
  if (Object.is(left, right)) return true
  if (Array.isArray(left) || Array.isArray(right)) {
    return (
      Array.isArray(left) &&
      Array.isArray(right) &&
      left.length === right.length &&
      left.every((entry, index) => isJsonEqual(entry, right[index]))
    )
  }
  if (!isRecord(left) || !isRecord(right)) return false
  const leftRecord = /** @type {Record<string, unknown>} */ (left)
  const rightRecord = /** @type {Record<string, unknown>} */ (right)
  const leftKeys = Object.keys(leftRecord).sort()
  const rightKeys = Object.keys(rightRecord).sort()
  return (
    leftKeys.length === rightKeys.length &&
    leftKeys.every((key, index) => key === rightKeys[index] && isJsonEqual(leftRecord[key], rightRecord[key]))
  )
}

/** @param {unknown} schema @param {number} [depth] */
export const isSupportedJsonSchema = (schema, depth = 0) => {
  if (!isRecord(schema) || depth > 20) return false
  const record = /** @type {Record<string, unknown>} */ (schema)
  if (!Object.keys(record).every((key) => supportedKeywords.includes(key))) return false
  if (
    record.type !== undefined &&
    !(
      (typeof record.type === 'string' && schemaTypes.includes(record.type)) ||
      (Array.isArray(record.type) &&
        record.type.length > 0 &&
        new Set(record.type).size === record.type.length &&
        record.type.every((type) => typeof type === 'string' && schemaTypes.includes(type)))
    )
  ) {
    return false
  }
  if (record.properties !== undefined) {
    if (!isRecord(record.properties)) return false
    const properties = /** @type {Record<string, unknown>} */ (record.properties)
    if (!Object.values(properties).every((value) => isSupportedJsonSchema(value, depth + 1))) return false
  }
  if (
    record.required !== undefined &&
    (!Array.isArray(record.required) ||
      new Set(record.required).size !== record.required.length ||
      !record.required.every((name) => typeof name === 'string'))
  ) {
    return false
  }
  if (
    record.additionalProperties !== undefined &&
    typeof record.additionalProperties !== 'boolean' &&
    !isSupportedJsonSchema(record.additionalProperties, depth + 1)
  ) {
    return false
  }
  if (record.items !== undefined && !isSupportedJsonSchema(record.items, depth + 1)) return false
  if (record.enum !== undefined && (!Array.isArray(record.enum) || record.enum.length === 0)) return false
  return true
}

/** @param {string} type @param {unknown} value */
const matchesType = (type, value) => {
  if (type === 'null') return value === null
  if (type === 'array') return Array.isArray(value)
  if (type === 'object') return isRecord(value)
  if (type === 'integer') return Number.isSafeInteger(value)
  if (type === 'number') return typeof value === 'number' && Number.isFinite(value)
  return typeof value === type
}

/** @param {unknown} schema @param {unknown} value */
export const validateJsonSchema = (schema, value) => {
  if (!isSupportedJsonSchema(schema)) return false
  const record = /** @type {Record<string, unknown>} */ (schema)
  const types = Array.isArray(record.type) ? record.type : record.type ? [record.type] : []
  if (types.length > 0 && !types.some((type) => matchesType(/** @type {string} */ (type), value))) return false
  if (Array.isArray(record.enum) && !record.enum.some((entry) => isJsonEqual(entry, value))) return false
  if ('const' in record && !isJsonEqual(record.const, value)) return false

  if (Array.isArray(value) && record.items !== undefined) {
    if (!value.every((entry) => validateJsonSchema(record.items, entry))) return false
  }
  if (isRecord(value)) {
    const object = /** @type {Record<string, unknown>} */ (value)
    const properties = isRecord(record.properties)
      ? /** @type {Record<string, unknown>} */ (record.properties)
      : {}
    const required = Array.isArray(record.required) ? record.required : []
    if (!required.every((name) => typeof name === 'string' && Object.hasOwn(object, name))) return false
    for (const [name, entry] of Object.entries(object)) {
      if (name in properties) {
        if (!validateJsonSchema(properties[name], entry)) return false
      } else if (record.additionalProperties === false) {
        return false
      } else if (isRecord(record.additionalProperties)) {
        if (!validateJsonSchema(record.additionalProperties, entry)) return false
      }
    }
  }
  return true
}
