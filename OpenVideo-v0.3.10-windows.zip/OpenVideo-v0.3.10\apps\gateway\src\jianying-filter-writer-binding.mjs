/**
 * Private bridge from opaque RichTimeline filter tokens to the writer-only
 * pyJianYingDraft FilterType resource binding. This module must never be used
 * to construct browser responses or public job DTOs.
 */

const capabilityIds = new Set(['filter.video.named', 'filter.video.track_named'])

export class JianyingFilterWriterBindingError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingFilterWriterBindingError'
    this.code = code
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys */
const hasExactKeys = (value, keys) =>
  isRecord(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key))

/**
 * Resolve prevalidated, opaque filter requests for the writer boundary only.
 * @param {unknown} requests
 * @param {{filterResolver?: {resolveFilterToken: (token: string, capabilityId: string) => Promise<{filterToken: string, capabilityId: string, resourceId: string}>}}} options
 */
export const resolveJianyingFilterWriterBindings = async (requests, options = {}) => {
  if (!Array.isArray(requests) || requests.length > 32 || !options.filterResolver) {
    throw new JianyingFilterWriterBindingError('JY016_FILTER_BINDING_INVALID')
  }
  /** @type {Array<{resource_id: string, capability_id: string, target_start_us: number, target_duration_us: number, intensity: number}>} */
  const bindings = []
  for (const request of requests) {
    if (
      !hasExactKeys(request, ['filterToken', 'capabilityId', 'targetStartUs', 'targetDurationUs', 'intensity']) ||
      typeof request.filterToken !== 'string' ||
      typeof request.capabilityId !== 'string' || !capabilityIds.has(request.capabilityId) ||
      !Number.isSafeInteger(request.targetStartUs) || request.targetStartUs < 0 ||
      !Number.isSafeInteger(request.targetDurationUs) || request.targetDurationUs <= 0 ||
      typeof request.intensity !== 'number' || !Number.isFinite(request.intensity) ||
      request.intensity < 0 || request.intensity > 100
    ) throw new JianyingFilterWriterBindingError('JY016_FILTER_BINDING_INVALID')
    let resolved
    try {
      resolved = await options.filterResolver.resolveFilterToken(request.filterToken, request.capabilityId)
    } catch {
      throw new JianyingFilterWriterBindingError('JY016_FILTER_BINDING_UNRESOLVED')
    }
    if (
      !isRecord(resolved) ||
      resolved.filterToken !== request.filterToken ||
      resolved.capabilityId !== request.capabilityId ||
      typeof resolved.resourceId !== 'string' || !/^[A-Za-z0-9_-]{4,80}$/u.test(resolved.resourceId)
    ) throw new JianyingFilterWriterBindingError('JY016_FILTER_BINDING_UNRESOLVED')
    bindings.push(Object.freeze({
      resource_id: resolved.resourceId,
      capability_id: request.capabilityId,
      target_start_us: request.targetStartUs,
      target_duration_us: request.targetDurationUs,
      intensity: request.intensity,
    }))
  }
  return Object.freeze(bindings)
}
