[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimeDataRoot,

    [Parameter(Mandatory = $true)]
    [string]$GeneratedEvidencePath,

    [Parameter(Mandatory = $true)]
    [string]$DesktopVersion,

    [Parameter(Mandatory = $true)]
    [long]$ObservedVoiceoverFadeInUs,
    [Parameter(Mandatory = $true)]
    [long]$ObservedVoiceoverFadeOutUs,
    [Parameter(Mandatory = $true)]
    [long]$ObservedSfxFadeInUs,
    [Parameter(Mandatory = $true)]
    [long]$ObservedSfxFadeOutUs,
    [Parameter(Mandatory = $true)]
    [long]$ObservedBgmFadeInUs,
    [Parameter(Mandatory = $true)]
    [long]$ObservedBgmFadeOutUs,

    [Parameter(Mandatory = $true)]
    [long]$EditedVoiceoverFadeInUs,
    [Parameter(Mandatory = $true)]
    [long]$EditedVoiceoverFadeOutUs,
    [Parameter(Mandatory = $true)]
    [long]$EditedSfxFadeInUs,
    [Parameter(Mandatory = $true)]
    [long]$EditedSfxFadeOutUs,
    [Parameter(Mandatory = $true)]
    [long]$EditedBgmFadeInUs,
    [Parameter(Mandatory = $true)]
    [long]$EditedBgmFadeOutUs,

    [Parameter(Mandatory = $true)]
    [switch]$UserAuthorized,
    [Parameter(Mandatory = $true)]
    [switch]$OpenedInSupportedJianying,
    [Parameter(Mandatory = $true)]
    [switch]$SavedAfterAudioFadeEdit
)

$ErrorActionPreference = 'Stop'

function Assert-PrivatePath {
    param([string]$CandidatePath, [string]$BoundaryPath)
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if ($candidate -eq $boundary -or -not $candidate.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'JY014_EVIDENCE_OUTSIDE_PRIVATE_RUNTIME_ROOT'
    }
}

function Assert-NoReparseBoundary {
    param([string]$CandidatePath, [string]$BoundaryPath)
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if (-not (Test-Path -LiteralPath $candidate) -or -not (Test-Path -LiteralPath $boundary)) {
        throw 'JY014_EVIDENCE_PATH_MISSING'
    }
    $currentPath = $candidate
    while ($true) {
        $current = Get-Item -LiteralPath $currentPath -Force
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'JY014_EVIDENCE_REPARSE_POINT_REJECTED'
        }
        if ([IO.Path]::GetFullPath($currentPath).TrimEnd('\') -eq $boundary) { break }
        $currentPath = [IO.Path]::GetDirectoryName($currentPath.TrimEnd('\'))
        if ([string]::IsNullOrWhiteSpace($currentPath)) { throw 'JY014_EVIDENCE_OUTSIDE_PRIVATE_RUNTIME_ROOT' }
    }
}

function Assert-NonNegativeFades {
    param([long[]]$Values)
    if (($Values | Where-Object { $_ -lt 0 }).Count -gt 0) {
        throw 'JY014_AUDIO_FADE_VALUE_INVALID'
    }
}

function Get-SupportedProfile {
    param([string]$VersionText)
    $manifestPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'config/jianying-compatibility.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $version = [Version]$VersionText
    $matches = @($manifest.profiles | Where-Object {
        $profile = $_
        $version -ge [Version]$profile.minimum_version -and
        $version -lt [Version]$profile.maximum_version_exclusive -and
        $profile.capabilities.draft_generation -eq $true -and
        $profile.capabilities.manual_open -eq $true
    })
    if ($matches.Count -ne 1) { throw 'JY014_SUPPORTED_VERSION_REQUIRED' }
    return $matches[0]
}

if (-not $UserAuthorized.IsPresent -or -not $OpenedInSupportedJianying.IsPresent -or -not $SavedAfterAudioFadeEdit.IsPresent) {
    throw 'JY014_MANUAL_CONFIRMATION_REQUIRED'
}
if ([string]::IsNullOrWhiteSpace($DesktopVersion) -or $DesktopVersion.Length -gt 120) {
    throw 'JY014_SUPPORTED_VERSION_REQUIRED'
}
$supportedProfile = Get-SupportedProfile -VersionText $DesktopVersion

$runtimeRoot = [IO.Path]::GetFullPath($RuntimeDataRoot)
$generatedPath = [IO.Path]::GetFullPath($GeneratedEvidencePath)
Assert-PrivatePath -CandidatePath $generatedPath -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $runtimeRoot -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $generatedPath -BoundaryPath $runtimeRoot

$generated = Get-Content -LiteralPath $generatedPath -Raw -Encoding UTF8 | ConvertFrom-Json
if (
    $generated.schema_version -ne 1 -or
    $generated.kind -ne 'jy008_capability_acceptance_evidence' -or
    $generated.desktop_opened -ne $false -or
    $generated.edit_confirmed -ne $false -or
    $DesktopVersion -ne $generated.desktop_version -or
    $generated.output_fingerprint -notmatch '^[a-f0-9]{64}$'
) {
    throw 'JY014_GENERATED_EVIDENCE_INVALID'
}

$observed = @(
    $ObservedVoiceoverFadeInUs, $ObservedVoiceoverFadeOutUs,
    $ObservedSfxFadeInUs, $ObservedSfxFadeOutUs,
    $ObservedBgmFadeInUs, $ObservedBgmFadeOutUs
)
$edited = @(
    $EditedVoiceoverFadeInUs, $EditedVoiceoverFadeOutUs,
    $EditedSfxFadeInUs, $EditedSfxFadeOutUs,
    $EditedBgmFadeInUs, $EditedBgmFadeOutUs
)
Assert-NonNegativeFades -Values $observed
Assert-NonNegativeFades -Values $edited

$expected = @(
    [long]$generated.structures.voiceover_fade[0], [long]$generated.structures.voiceover_fade[1],
    [long]$generated.structures.sfx_fade[0], [long]$generated.structures.sfx_fade[1],
    [long]$generated.structures.bgm_fade[0], [long]$generated.structures.bgm_fade[1]
)
if (@(Compare-Object $expected $observed -SyncWindow 0).Count -ne 0) {
    throw 'JY014_OBSERVED_VALUES_DO_NOT_MATCH_PERSISTED_DRAFT'
}
if (@(Compare-Object $observed $edited -SyncWindow 0).Count -eq 0) {
    throw 'JY014_AUDIO_FADE_EDIT_NOT_OBSERVED'
}

$evidenceParent = Join-Path $runtimeRoot 'evidence'
New-Item -ItemType Directory -Force -Path $evidenceParent | Out-Null
Assert-NoReparseBoundary -CandidatePath $evidenceParent -BoundaryPath $runtimeRoot
$evidenceRoot = Join-Path $evidenceParent 'jy014-audio-fade'
New-Item -ItemType Directory -Force -Path $evidenceRoot | Out-Null
Assert-NoReparseBoundary -CandidatePath $evidenceRoot -BoundaryPath $runtimeRoot
$manualEvidencePath = Join-Path $evidenceRoot ("{0}.json" -f [Guid]::NewGuid().ToString('N'))
$manual = [ordered]@{
    schema_version = 1
    kind = 'jy014_audio_fade_manual_evidence'
    recorded_at = (Get-Date).ToUniversalTime().ToString('o')
    desktop_version = $DesktopVersion
    compatibility_profile = [string]$supportedProfile.id
    user_authorized = $true
    draft_fingerprint = [string]$generated.output_fingerprint
    opened_in_supported_jianying = $true
    observed_fades_us = [ordered]@{
        voiceover = @($ObservedVoiceoverFadeInUs, $ObservedVoiceoverFadeOutUs)
        sfx = @($ObservedSfxFadeInUs, $ObservedSfxFadeOutUs)
        bgm = @($ObservedBgmFadeInUs, $ObservedBgmFadeOutUs)
    }
    edited_fades_us = [ordered]@{
        voiceover = @($EditedVoiceoverFadeInUs, $EditedVoiceoverFadeOutUs)
        sfx = @($EditedSfxFadeInUs, $EditedSfxFadeOutUs)
        bgm = @($EditedBgmFadeInUs, $EditedBgmFadeOutUs)
    }
    saved_after_audio_fade_edit = $true
}
[IO.File]::WriteAllText($manualEvidencePath, (($manual | ConvertTo-Json -Depth 6) + "`n"), [Text.UTF8Encoding]::new($false))
Write-Output 'JY-014 private audio-fade manual evidence recorded. Validate it with Test-JY014AudioFadeManualEvidence.ps1.'
