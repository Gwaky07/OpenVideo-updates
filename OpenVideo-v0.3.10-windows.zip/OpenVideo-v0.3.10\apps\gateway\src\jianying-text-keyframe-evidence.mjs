/** @type {Readonly<Record<string, string>>} */
const admittedProfiles = Object.freeze({
  'jianying-11-1-provisional': '11.1.0.14287',
  'jianying-11-2-provisional': '11.2.0.14339',
})

/** @param {unknown} value @param {{profileId: string, version: string}} desktop */
export const parseJianyingTextKeyframeEvidence = (value, desktop) => {
  /** @type {any} */ const candidate = value
  const keys = ['schema_version', 'manual_evidence_verified', 'manual_attestation', 'profile_id', 'app_version', 'scheme', 'opened', 'edited', 'saved', 'reopened', 'matching_keyframe_count', 'temporary_media_cleaned', 'draft_id', 'target_text', 'target_start_us', 'target_duration_us', 'keyframe_ids', 'pre_open_fingerprint', 'post_save_fingerprint']
  /** @type {Array<{id?: unknown, offset_us?: unknown, value?: unknown}>} */
  const keyframeIds = Array.isArray(candidate?.keyframe_ids) ? candidate.keyframe_ids : []
  if (!candidate || Object.keys(candidate).sort().join('\0') !== keys.sort().join('\0') || candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true || candidate.manual_attestation !== 'opened-edited-saved-reopened' || admittedProfiles[desktop.profileId] !== desktop.version || candidate.profile_id !== desktop.profileId || candidate.app_version !== desktop.version || candidate.scheme !== 'encrypt_v2' || candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true || candidate.matching_keyframe_count !== 2 || candidate.temporary_media_cleaned !== true || typeof candidate.draft_id !== 'string' || typeof candidate.target_text !== 'string' || !Number.isSafeInteger(candidate.target_start_us) || !Number.isSafeInteger(candidate.target_duration_us) || keyframeIds.length !== 2 || keyframeIds.some((point, index) => typeof point?.id !== 'string' || point.offset_us !== (index === 0 ? 500_000 : 1_000_000) || point.value !== (index === 0 ? 1 : 1.4)) || !/^[a-f0-9]{64}$/u.test(candidate.pre_open_fingerprint) || !/^[a-f0-9]{64}$/u.test(candidate.post_save_fingerprint) || candidate.pre_open_fingerprint === candidate.post_save_fingerprint) return null
  return Object.freeze({ ...candidate })
}
