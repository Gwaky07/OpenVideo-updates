const fingerprintPattern = /^[a-f0-9]{64}$/u
const draftPattern = /^OpenVideo-JY074-video-fade-[0-9]+$/u
const expectedKeys = Object.freeze([
  'schema_version', 'manual_evidence_verified', 'manual_attestation',
  'profile_id', 'app_version', 'draft_id', 'scheme', 'opened', 'edited',
  'saved', 'reopened', 'persisted_fade_in_us', 'persisted_fade_out_us',
  'pre_open_fingerprint', 'post_save_fingerprint',
])

const expectedFade = Object.freeze({
  fade_in_duration: 500_000,
  fade_out_duration: 800_000,
  type: 'audio_fade',
})

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Validate the native Jianying 11.1 three-way video-fade binding.
 * @param {unknown} value
 * @returns {{fadeInUs: number, fadeOutUs: number}}
 */
export const validateJianyingVideoFadeContent = (value) => {
  if (!isRecord(value)) throw new Error('JY074_VIDEO_FADE_PERSISTENCE_INVALID')
  const tracks = Array.isArray(value.tracks)
    ? value.tracks.filter((track) => track?.name === 'video-primary')
    : []
  const segments = Array.isArray(tracks[0]?.segments) ? tracks[0].segments : []
  const fades = Array.isArray(value.materials?.audio_fades) ? value.materials.audio_fades : []
  if (tracks.length !== 1 || segments.length !== 1 || fades.length !== 1) {
    throw new Error('JY074_VIDEO_FADE_PERSISTENCE_INVALID')
  }

  const segment = segments[0]
  const fade = fades[0]
  const refs = Array.isArray(segment?.extra_material_refs) ? segment.extra_material_refs : []
  if (!isRecord(fade) || typeof fade.id !== 'string' || refs.filter((/** @type {unknown} */ id) => id === fade.id).length !== 1 ||
    fade.type !== expectedFade.type || fade.fade_in_duration !== expectedFade.fade_in_duration ||
    fade.fade_out_duration !== expectedFade.fade_out_duration || typeof segment?.material_id !== 'string') {
    throw new Error('JY074_VIDEO_FADE_PERSISTENCE_INVALID')
  }

  const videos = Array.isArray(value.materials?.videos) ? value.materials.videos : []
  const matchingVideos = videos.filter((/** @type {Record<string, any>} */ video) => video?.id === segment.material_id)
  if (matchingVideos.length !== 1 || !isRecord(matchingVideos[0].audio_fade)) {
    throw new Error('JY074_VIDEO_FADE_PERSISTENCE_INVALID')
  }
  const mirror = matchingVideos[0].audio_fade
  const expectedKeys = ['fade_in_duration', 'fade_out_duration', 'id', 'type']
  if (Object.keys(fade).sort().join('\0') !== expectedKeys.join('\0') ||
    Object.keys(mirror).sort().join('\0') !== expectedKeys.join('\0') ||
    expectedKeys.some((key) => mirror[key] !== fade[key])) {
    throw new Error('JY074_VIDEO_FADE_PERSISTENCE_INVALID')
  }
  return { fadeInUs: fade.fade_in_duration, fadeOutUs: fade.fade_out_duration }
}

/** @param {unknown} value @param {{profileId: string, version: string}} desktop */
export const parseJianyingVideoFadeEvidence = (value, desktop) => {
  if (!value || typeof value !== 'object') return null
  const candidate = /** @type {Record<string, any>} */ (value)
  if (Object.keys(candidate).sort().join('\0') !== [...expectedKeys].sort().join('\0') ||
    candidate.schema_version !== 1 || candidate.manual_evidence_verified !== true ||
    candidate.manual_attestation !== 'opened-edited-saved-reopened' ||
    candidate.profile_id !== desktop.profileId || candidate.app_version !== desktop.version ||
    !draftPattern.test(candidate.draft_id) || candidate.scheme !== 'encrypt_v2' ||
    candidate.opened !== true || candidate.edited !== true || candidate.saved !== true || candidate.reopened !== true ||
    candidate.persisted_fade_in_us !== 500_000 || candidate.persisted_fade_out_us !== 800_000 ||
    !fingerprintPattern.test(candidate.pre_open_fingerprint) || !fingerprintPattern.test(candidate.post_save_fingerprint) ||
    candidate.pre_open_fingerprint === candidate.post_save_fingerprint) return null
  return Object.freeze({ ...candidate })
}
