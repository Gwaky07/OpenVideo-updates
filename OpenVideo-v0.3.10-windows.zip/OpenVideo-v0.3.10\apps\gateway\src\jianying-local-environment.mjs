import { execFile } from 'node:child_process'
import { lstat, readFile } from 'node:fs/promises'
import { basename, dirname, isAbsolute, relative, resolve } from 'node:path'
import process from 'node:process'
import { promisify } from 'node:util'

const execFileAsync = promisify(execFile)
const pinnedRepository = 'https://github.com/GuanYixuan/pyJianYingDraft.git'
const pinnedCommit = 'c3318066d964744e2bfc66f75c71745fe8cea52a'
const pinnedLicense = 'Apache-2.0'
const trustedPublisher = 'CN=深圳市脸萌科技有限公司'
const trustedExecutable = 'JianyingPro.exe'
const capabilityKeys = [
  'draft_generation',
  'manual_open',
  'desktop_ui_automation',
  'template_read',
  'background_render',
]
const governedProfiles = [
  {
    id: 'jianying-5-9',
    minimum_version: '5.9.0.0',
    maximum_version_exclusive: '6.0.0.0',
    provisional: false,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: true,
      template_read: true,
      background_render: false,
    },
  },
  {
    id: 'jianying-6',
    minimum_version: '6.0.0.0',
    maximum_version_exclusive: '7.0.0.0',
    provisional: false,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: true,
      template_read: false,
      background_render: false,
    },
  },
  {
    id: 'jianying-10-9-provisional',
    minimum_version: '10.9.0.0',
    maximum_version_exclusive: '10.10.0.0',
    provisional: true,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: false,
      template_read: false,
      background_render: false,
    },
  },
  {
    id: 'jianying-11-1-provisional',
    minimum_version: '11.1.0.0',
    maximum_version_exclusive: '11.2.0.0',
    provisional: true,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: false,
      template_read: false,
      background_render: false,
    },
  },
  {
    id: 'jianying-11-2-provisional',
    minimum_version: '11.2.0.0',
    maximum_version_exclusive: '11.3.0.0',
    provisional: true,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: false,
      template_read: false,
      background_render: false,
    },
  },
  {
    id: 'jianying-11-3-codec-candidate',
    minimum_version: '11.3.0.0',
    maximum_version_exclusive: '11.4.0.0',
    provisional: true,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: false,
      template_read: false,
      background_render: false,
    },
  },
]

/** @param {unknown} value */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} value */
const normalizedRepository = (value) => value.trim().replace(/\.git$/iu, '').replace(/\/$/u, '').toLowerCase()
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const fragment = relative(resolve(parent), resolve(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) => {
  if (!record(value)) return false
  const metadata = /** @type {Record<string, any>} */ (value)
  return Object.keys(metadata).length === keys.length &&
    keys.every((key) => Object.hasOwn(metadata, key))
}
/** @param {unknown} value */
const parseVersion = (value) => {
  if (typeof value !== 'string' || !/^[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?$/u.test(value)) return null
  const parts = value.split('.').map(Number)
  if (parts.some((part) => !Number.isSafeInteger(part) || part < 0)) return null
  while (parts.length < 4) parts.push(0)
  return parts
}
/** @param {number[]} left @param {number[]} right */
const compareVersion = (left, right) => {
  for (let index = 0; index < 4; index += 1) {
    if (left[index] !== right[index]) return left[index] - right[index]
  }
  return 0
}
/** @param {unknown} manifest */
const validateCompatibilityManifest = (manifest) => {
  const metadata = /** @type {Record<string, any>} */ (manifest)
  if (
    !exactKeys(manifest, ['schema_version', 'kind', 'publisher', 'executable', 'profiles']) ||
    metadata.schema_version !== 1 ||
    metadata.kind !== 'jianying_compatibility_matrix' ||
    metadata.publisher !== trustedPublisher ||
    metadata.executable !== trustedExecutable ||
    !Array.isArray(metadata.profiles) ||
    metadata.profiles.length !== governedProfiles.length
  ) return false
  return governedProfiles.every((expected, index) => {
    const profile = metadata.profiles[index]
    const capabilities = /** @type {Record<string, any>} */ (profile?.capabilities)
    const expectedCapabilities = /** @type {Record<string, any>} */ (expected.capabilities)
    return (
      exactKeys(profile, ['id', 'minimum_version', 'maximum_version_exclusive', 'provisional', 'capabilities']) &&
      profile.id === expected.id &&
      profile.minimum_version === expected.minimum_version &&
      profile.maximum_version_exclusive === expected.maximum_version_exclusive &&
      profile.provisional === expected.provisional &&
      exactKeys(capabilities, capabilityKeys) &&
      capabilityKeys.every((key) => capabilities[key] === expectedCapabilities[key])
    )
  })
}

/** @param {string} version @param {unknown} manifest */
export const resolveJianyingCompatibility = (version, manifest) => {
  if (!validateCompatibilityManifest(manifest)) {
    throw new JianyingLocalEnvironmentError('JY003_COMPATIBILITY_MANIFEST_INVALID')
  }
  const metadata = /** @type {Record<string, any>} */ (manifest)
  const parsed = parseVersion(version)
  if (!parsed) throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  const profile = parsed
    ? metadata.profiles.find((/** @type {Record<string, any>} */ candidate) => {
        const minimum = parseVersion(candidate.minimum_version)
        const maximum = parseVersion(candidate.maximum_version_exclusive)
        return minimum && maximum &&
          compareVersion(parsed, minimum) >= 0 &&
          compareVersion(parsed, maximum) < 0
      })
    : null
  // Known ranges provide capability hints only. A valid signed executable in
  // a newer/older release gets a conservative detected profile; the actual
  // catalog, decoder and writer probes decide what can be used.
  const resolvedProfile = profile ?? {
    id: `jianying-${parsed[0]}-${parsed[1]}-detected`,
    provisional: true,
    capabilities: {
      draft_generation: true,
      manual_open: true,
      desktop_ui_automation: false,
      template_read: false,
      background_render: false,
    },
  }
  if (resolvedProfile.capabilities.draft_generation !== true) {
    throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  }
  return {
    profileId: resolvedProfile.id,
    provisional: resolvedProfile.provisional,
    capabilities: structuredClone(resolvedProfile.capabilities),
  }
}

export class JianyingLocalEnvironmentError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'JianyingLocalEnvironmentError'
    this.code = code
    this.status = status
  }
}

/** @param {string} upstreamRoot */
const inspectGitUpstream = async (upstreamRoot) => {
  const options = { cwd: upstreamRoot, encoding: /** @type {BufferEncoding} */ ('utf8'), windowsHide: true, timeout: 10_000 }
  const [{ stdout: repository }, { stdout: commit }, { stdout: status }] = await Promise.all([
    execFileAsync('git', ['remote', 'get-url', 'origin'], options),
    execFileAsync('git', ['rev-parse', 'HEAD'], options),
    execFileAsync('git', ['status', '--porcelain', '--untracked-files=all'], options),
  ])
  return {
    repository: repository.trim(),
    commit: commit.trim(),
    clean: status.trim().length === 0,
  }
}

/**
 * @param {{
 *   upstreamRoot: string,
 *   manifest: unknown,
 *   inspectGit?: (root: string) => Promise<{repository: string, commit: string, clean: boolean}>,
 *   readLicense?: (path: string) => Promise<string>,
 * }} input
 */
export const inspectPyJianyingUpstream = async ({
  upstreamRoot,
  manifest,
  inspectGit = inspectGitUpstream,
  readLicense: loadLicense = (path) => readFile(path, 'utf8'),
}) => {
  if (!isAbsolute(upstreamRoot) || !record(manifest)) {
    throw new JianyingLocalEnvironmentError('JY003_UPSTREAM_INTEGRITY_INVALID')
  }
  const metadata = /** @type {Record<string, any>} */ (manifest)
  if (
    metadata.repository !== pinnedRepository ||
    metadata.commit !== pinnedCommit ||
    metadata.license !== pinnedLicense ||
    metadata.module !== 'pyJianYingDraft'
  ) throw new JianyingLocalEnvironmentError('JY003_UPSTREAM_INTEGRITY_INVALID')
  let inspected
  try {
    inspected = await inspectGit(upstreamRoot)
  } catch {
    throw new JianyingLocalEnvironmentError('JY003_UPSTREAM_INTEGRITY_INVALID')
  }
  if (
    normalizedRepository(inspected.repository) !== normalizedRepository(pinnedRepository) ||
    inspected.commit !== pinnedCommit ||
    inspected.clean !== true
  ) throw new JianyingLocalEnvironmentError('JY003_UPSTREAM_INTEGRITY_INVALID')
  let license
  try {
    license = await loadLicense(resolve(upstreamRoot, 'LICENSE'))
  } catch {
    throw new JianyingLocalEnvironmentError('JY003_UPSTREAM_LICENSE_INVALID')
  }
  if (!/Apache License\s+Version 2\.0/iu.test(license)) {
    throw new JianyingLocalEnvironmentError('JY003_UPSTREAM_LICENSE_INVALID')
  }
  return {
    available: true,
    repository: pinnedRepository,
    commit: pinnedCommit,
    license: pinnedLicense,
  }
}

const inspectWindowsDesktop = async () => {
  const script = [
    "$ErrorActionPreference='Stop'",
    "function Test-SafePath([string]$Path,[string]$Boundary){$current=Get-Item -LiteralPath $Path -Force; $limit=[IO.Path]::GetFullPath($Boundary).TrimEnd('\\'); while($null -ne $current){if(($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){return $false}; if($current.FullName.TrimEnd('\\') -eq $limit){return $true}; $parent=Split-Path -Parent $current.FullName; if([string]::IsNullOrWhiteSpace($parent) -or -not $current.FullName.StartsWith($limit,[StringComparison]::OrdinalIgnoreCase)){return $false}; $current=Get-Item -LiteralPath $parent -Force}; return $false}",
    "$roots=@('HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*')",
    "$app=Get-ItemProperty $roots -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -in @('剪映专业版','Jianying Pro') } | Sort-Object {[version]$_.DisplayVersion} -Descending | Select-Object -First 1",
    "if($null -eq $app){ throw 'not-found' }",
    "$icon=[string]$app.DisplayIcon",
    "$iconPath=($icon -replace '^\"|\"$','' -replace ',\\d+$','')",
    "$install=if(-not [string]::IsNullOrWhiteSpace([string]$app.InstallLocation)){[string]$app.InstallLocation}elseif([IO.Path]::IsPathRooted($iconPath)){Split-Path -Parent $iconPath}else{throw 'install-root-not-found'}",
    "if(-not (Test-Path -LiteralPath $install -PathType Container)){throw 'install-root-not-found'}",
    "$candidates=@(Get-ChildItem -LiteralPath $install -Filter 'JianyingPro.exe' -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {$sig=Get-AuthenticodeSignature -LiteralPath $_.FullName;$versionDir=Split-Path -Parent $_.FullName;$dll=Join-Path $versionDir 'videoeditor.dll';$dllHash=if((Test-Path -LiteralPath $dll -PathType Leaf) -and (Test-SafePath $dll $install)){(Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash.ToLowerInvariant()}else{''};@{executablePath=$_.FullName;fileVersion=$_.VersionInfo.FileVersion;signatureStatus=[string]$sig.Status;publisher=if($sig.SignerCertificate){$sig.SignerCertificate.Subject}else{''};pathSafe=(Test-SafePath $_.FullName $install);dllFingerprint=$dllHash}})",
    "if($candidates.Count -eq 0){throw 'exe-not-found'}",
    "$local=[Environment]::GetFolderPath('LocalApplicationData')",
    "$draft=Join-Path $local 'JianyingPro\\User Data\\Projects\\com.lveditor.draft'",
    "if(-not (Test-Path -LiteralPath $draft -PathType Container)){ throw 'draft-root-not-found' }",
    // Some Jianying installers leave a stale registry DisplayVersion (8.9)
    // while the installed executable has been upgraded in-place (11.1). Use
    // the signed executable version as the source of truth for compatibility.
    "$version=($candidates | Where-Object {$_.signatureStatus -eq 'Valid' -and $_.pathSafe -eq $true -and $_.fileVersion -match '^[0-9]+(\\.[0-9]+){1,3}$'} | Sort-Object {[version]$_.fileVersion} -Descending | Select-Object -First 1).fileVersion",
    "if([string]::IsNullOrWhiteSpace([string]$version)){throw 'version-not-found'}",
    "$json=@{version=[string]$version;displayIconExecutable=Split-Path -Leaf $iconPath;installRoot=[IO.Path]::GetFullPath($install);draftRoot=[IO.Path]::GetFullPath($draft);draftRootSafe=(Test-SafePath $draft $local);executableCandidates=$candidates} | ConvertTo-Json -Compress -Depth 4",
    "[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($json))",
  ].join(';')
  let stdout = ''
  let failure = null
  // Jianying is a Windows desktop product, and the signed-file inspection is
  // implemented against the inbox Windows PowerShell APIs. A separately
  // installed pwsh can stall on Authenticode inspection before timing out, so
  // keep it as the compatibility fallback instead of delaying every probe.
  for (const executable of ['powershell.exe', 'pwsh.exe']) {
    try {
      ({ stdout } = await execFileAsync(
        executable,
        ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
        { encoding: 'utf8', windowsHide: true, timeout: 15_000 },
      ))
      break
    } catch (error) {
      failure = error
    }
  }
  if (!stdout) throw failure ?? new Error('powershell-unavailable')
  return JSON.parse(Buffer.from(stdout.trim(), 'base64').toString('utf8'))
}

/** @param {string} path */
const inspectLocalPath = async (path) => {
  const metadata = await lstat(path)
  return {
    executable: metadata.isFile(),
    directory: metadata.isDirectory(),
    reparsePoint: metadata.isSymbolicLink(),
  }
}

/**
 * @param {{
 *   platform?: string,
 *   inspectDesktop?: () => Promise<unknown>,
 *   inspectPath?: (path: string) => Promise<{executable: boolean, directory: boolean, reparsePoint: boolean}>,
 *   compatibilityManifest?: unknown,
 * }} [options]
 */
export const detectJianyingDesktop = async ({
  platform = process.platform,
  inspectDesktop = inspectWindowsDesktop,
  inspectPath = inspectLocalPath,
  compatibilityManifest,
} = {}) => {
  if (platform !== 'win32') {
    throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  }
  let inspected
  try {
    inspected = await inspectDesktop()
  } catch {
    throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  }
  if (!record(inspected)) throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  const value = /** @type {Record<string, any>} */ (inspected)
  if (!validateCompatibilityManifest(compatibilityManifest)) {
    throw new JianyingLocalEnvironmentError('JY003_COMPATIBILITY_MANIFEST_INVALID')
  }
  if (
    typeof value.installRoot !== 'string' ||
    typeof value.draftRoot !== 'string' ||
    !isAbsolute(value.installRoot) ||
    !isAbsolute(value.draftRoot) ||
    value.draftRootSafe !== true
  ) throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  const candidates = Array.isArray(value.executableCandidates)
    ? value.executableCandidates.filter((candidate) =>
        record(candidate) &&
        typeof candidate.executablePath === 'string' &&
        isAbsolute(candidate.executablePath) &&
        inside(value.installRoot, candidate.executablePath) &&
        basename(candidate.executablePath).toLowerCase() === trustedExecutable.toLowerCase() &&
        typeof candidate.fileVersion === 'string' &&
        typeof candidate.dllFingerprint === 'string' &&
        /^[a-f0-9]{64}$/u.test(candidate.dllFingerprint) &&
        candidate.signatureStatus === 'Valid' &&
        candidate.pathSafe === true &&
        typeof candidate.publisher === 'string' &&
        (candidate.publisher === trustedPublisher || candidate.publisher.startsWith(`${trustedPublisher},`)))
    : []
  const compatibleCandidates = candidates
    .map((candidate) => {
      try {
        const parsedVersion = parseVersion(candidate.fileVersion)
        if (!parsedVersion) return null
        return {
          candidate,
          parsedVersion,
          compatibility: resolveJianyingCompatibility(candidate.fileVersion, compatibilityManifest),
        }
      } catch (error) {
        if (error instanceof JianyingLocalEnvironmentError && error.code === 'JY002_DESKTOP_VERSION_UNSUPPORTED') {
          return null
        }
        throw error
      }
    })
    .filter((value) => value !== null)
    .sort((left, right) => compareVersion(right.parsedVersion, left.parsedVersion))
  const selected = compatibleCandidates[0]
  const executable = selected?.candidate
  if (
    !executable
  ) throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  try {
    const [executablePath, draftRoot] = await Promise.all([
      inspectPath(executable.executablePath),
      inspectPath(value.draftRoot),
    ])
    if (
      !executablePath.executable ||
      executablePath.reparsePoint ||
      !draftRoot.directory ||
      draftRoot.reparsePoint
    ) throw new Error('unsafe-path')
  } catch {
    throw new JianyingLocalEnvironmentError('JY002_DESKTOP_VERSION_UNSUPPORTED')
  }
  return {
    available: true,
    version: executable.fileVersion,
    profileId: selected.compatibility.profileId,
    provisional: selected.compatibility.provisional,
    capabilities: selected.compatibility.capabilities,
    publisher: executable.publisher,
    dllFingerprint: executable.dllFingerprint.toLowerCase(),
    executablePath: resolve(executable.executablePath),
    installRoot: resolve(value.installRoot),
    draftRoot: resolve(value.draftRoot),
  }
}
