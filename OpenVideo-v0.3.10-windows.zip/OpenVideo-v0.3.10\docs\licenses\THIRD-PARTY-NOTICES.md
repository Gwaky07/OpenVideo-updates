# 第三方 NOTICE（内部交付）

本文件汇总 OpenVideo 自然语言 AI Editor MVP 内部交付所触及的主要第三方边界。当前仓库标记为 `private`，不授予公开再分发权；若未来公开开源，必须重新完成法律复核并更新本文件。

## 正式发行依赖（本机 `upstream/`，不进 Git）

| 依赖 | 许可证 | 固定入口 | 说明 |
| --- | --- | --- | --- |
| `short-video-factory` | AGPL-3.0 | `config/short-video-factory-upstream.json` | 预览主链；不得复制源码进 OpenVideo；对外分发前须单独满足 AGPL |
| `pyJianYingDraft` | Apache-2.0 | `config/pyjianyingdraft-upstream.json` | 剪映草稿 writer 依赖 |
| `video-shotcraft` | Apache-2.0 | `config/creative-knowledge/shotcraft-v1.manifest.json` | 仅离线读取固定 commit 的 Markdown 镜头元数据；规范化为 Creative Knowledge 快照，不复制或执行其源码、TSX、音频、截图、模板媒体或运行时服务 |

启动器会对上述正式依赖执行完整性 / clean tree 检查；失败时 capability fail closed。

## JY-200 Duo Writer-only 运行时（本地 Writer 已准入）

`duo-video@3b689ea876fcab4fc05b53b87762e991c3a9c345` 的根仓代码为
MIT。OpenVideo 的隔离构建只复制 `duo-server-base`、`duo-video-base` 和
`duo-video-jy`；`duo-video-api`、`auto-jy-win/mac`、GUI 自动导出、任务轮询、
OSS/COS、账号与 device identity 均不进入构建、运行或发行边界。

上游 POM 把 `spring-boot-starter-test` 留在 compile scope，且生产源码直接使用
AssertJ collection helper。OpenVideo 不修改 pinned checkout，只在固定 source SHA
的私有 staging 中把 starter-test 改为 test scope、把 Lombok 显式改为 provided，
并以 JDK `ArrayList` / `HashSet` 等价替换三个文件中的 AssertJ helper。任一上游
文件或补丁后 SHA 漂移都 fail closed。

2026-08-29 使用 Microsoft OpenJDK `21.0.10+7-LTS` 和 Maven `3.9.9` 离线
重复构建，两次都得到 manifest 指纹
`a1b13b3de86ef3715e4e92fe3b530c6297a6f620f31e585fd646c45380123761`：
3 个 reactor JAR、39 个 runtime dependency（其中 37 个外部 artifact），且
JUnit、AssertJ、Mockito、Hamcrest、Spring test stack 和 Lombok 均不在 runtime。
私有 runtime manifest 保存每个外部 artifact 的 coordinate、size 和 JAR SHA-256；
`config/duo-video-upstream.json` 以数量和 canonical inventory fingerprint
`43274aab09aa9a3f8abfb8e41aa79af18c9707098c3244c19fd0ad0d3fe52be3`
绑定完整清单，并直接绑定三个 reactor JAR 的 size/SHA-256。

| Runtime group / component | Version family | License notice |
| --- | --- | --- |
| `duo-server-base`, `duo-video-base`, `duo-video-jy` | pinned commit / `1.0.0-SNAPSHOT` build | MIT；保留 pinned 根仓 `LICENSE` |
| Spring Framework / Spring Boot | `6.2.14` / `3.5.8` | Apache-2.0 |
| Jackson / ClassMate | `2.19.4` / `1.7.1` | Apache-2.0 |
| Guava 及 error-prone、J2ObjC、JSR-305 辅助注解 | `32.1.3-jre` dependency set | Apache-2.0 |
| Checker Qual | `3.37.0` | MIT |
| SLF4J | `2.0.17` | MIT |
| Logback | `1.5.21` | EPL-1.0 OR LGPL-2.1-only |
| Log4j API bridge | `2.24.3` | Apache-2.0 |
| Hibernate Validator / Jakarta Validation / JBoss Logging / Tomcat EL | `8.0.3.Final` dependency set | Apache-2.0 |
| Jakarta Annotations | `2.1.1` | EPL-2.0 OR GPL-2.0 WITH Classpath Exception |
| Micrometer | `1.15.6` | Apache-2.0 |
| SnakeYAML | `2.4` | Apache-2.0 |
| Microsoft Build of OpenJDK | `21.0.10+7-LTS` | GPL-2.0-only WITH Classpath-exception-2.0；发行时保留 JDK `legal/` |

该清单支持本地 Writer 的固定 classpath/NOTICE 与准入证据，但不授权
`api.duoec.com` 的运行时获取、私有缓存或资源再分发。Duo 本地 Writer 当前
`admission=admitted / writer_eligible=true / catalog_bound=true`；远端资源服务仍
单独 denied/fail-closed，VectCut 仍 scoped deferred。

## 明确排除的开发参考

| 依赖 | 角色 | 说明 |
| --- | --- | --- |
| Edit Mind | 开发期行为参考 | `release_role: development-reference-only`；启动器不下载、不启动、不作发行依赖 |
| Auto-Cut / Auto-Cut-CopyA | 行为参考 | 见 `docs/licenses/AUTO-CUT-REFERENCE.md`；禁止复制代码/提示词/内部结构 |

## Node 生产依赖

- 复核命令：`pnpm licenses list --prod --json`
- 安全复核：`pnpm audit --prod --audit-level high --registry https://registry.npmjs.org`
- 详细上游与素材分析二进制边界：`docs/UPSTREAM-DEPENDENCIES.md`

## 本 release 许可证复核摘要

- 命令：`pnpm licenses list --prod`、`pnpm audit --prod --audit-level high --registry https://registry.npmjs.org`
- 审计结果：No known vulnerabilities found（2026-07-27）
- 生产依赖以 MIT / Apache-2.0 / BSD-3-Clause 为主；`@img/sharp-win32-x64` 含 LGPL-3.0-or-later（sharp 原生绑定，发行时随二进制提供）
- Edit Mind / Auto-Cut：非发行依赖，保持排除
