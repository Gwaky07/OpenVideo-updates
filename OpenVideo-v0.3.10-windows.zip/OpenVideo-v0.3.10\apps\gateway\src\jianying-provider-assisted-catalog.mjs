import { computePackagingCatalogFingerprint, parsePrivatePackagingResourceIndex } from './jianying-packaging-resource-index.mjs'

const providerIds = new Set(['user_draft', 'duo_video_probe', 'capcut_mate_snapshot'])
const sourceStates = new Set(['discovery_only', 'evidence_admitted'])
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} code @returns {never} */
const fail = (code, status = 503) => { const error = /** @type {Error & {code?: string, status?: number}} */ (new Error(code)); error.code = code; error.status = status; throw error }
const fingerprint = /^[a-f0-9]{64}$/u

/**
 * Normalize private provider output into a profile-bound catalog candidate.
 * This is an intake boundary only: Duo is a development probe and neither
 * provider can promote a writer capability without the existing evidence
 * registry and admission gates.
 * @param {{providerId: string, profileId: string, appVersion: string, desktopBinding?: Record<string, any>, catalogFingerprint: string, ingest: (payload: unknown) => Promise<Record<string, any>>, assertCurrentDesktop: (input: Record<string, any>) => Promise<boolean>}} dependencies
 */
export const createProviderAssistedCatalogIntake = ({ providerId, profileId, appVersion, desktopBinding = undefined, catalogFingerprint, ingest, assertCurrentDesktop }) => {
  if (!providerIds.has(providerId) || typeof profileId !== 'string' || !/^jianying-[a-z0-9-]{1,80}$/u.test(profileId) ||
      typeof appVersion !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(appVersion) || !fingerprint.test(catalogFingerprint ?? '') || typeof ingest !== 'function' || typeof assertCurrentDesktop !== 'function') {
    fail('NATIVE014_PROVIDER_INTAKE_INVALID')
  }
  return Object.freeze({
    providerId,
    /** @param {unknown} payload */
    ingest: async (payload) => {
      try { if (await assertCurrentDesktop({ profileId, appVersion, desktopBinding }) !== true) fail('NATIVE014_DESKTOP_BINDING_UNAVAILABLE') } catch (error) {
        if (isRecord(error) && error.code === 'NATIVE014_DESKTOP_BINDING_UNAVAILABLE') throw error
        fail('NATIVE014_DESKTOP_BINDING_UNAVAILABLE')
      }
      let result
      try { result = await ingest(payload) } catch (error) {
        const candidate = /** @type {{code?: unknown, status?: unknown}} */ (error)
        const code = typeof candidate?.code === 'string' && /^NATIVE017_[A-Z_]+$/u.test(candidate.code) ? candidate.code : null
        if (code) fail(code, typeof candidate.status === 'number' ? candidate.status : 503)
        fail('NATIVE014_PROVIDER_INGEST_FAILED')
      }
      if (!isRecord(result) || result.profile_id !== profileId || result.app_version !== appVersion ||
          result.catalog_fingerprint !== catalogFingerprint || !sourceStates.has(result.state) ||
          !Array.isArray(result.entries) || result.entries.length > 20_000) fail('NATIVE014_PROVIDER_RESULT_INVALID')
      if (result.state === 'evidence_admitted') fail('NATIVE014_EVIDENCE_VERIFICATION_REQUIRED')
      const privateSourceBinding = result.private_source_binding === undefined
        ? undefined
        : result.private_source_binding
      if (privateSourceBinding !== undefined && providerId !== 'user_draft') fail('NATIVE014_PROVIDER_RESULT_INVALID')
      let index
      try {
        index = parsePrivatePackagingResourceIndex({
          schema_version: 1,
          profile_id: profileId,
          app_version: appVersion,
          ...(desktopBinding ? { desktop_binding: desktopBinding } : {}),
          ...(privateSourceBinding ? { private_source_binding: privateSourceBinding } : {}),
          entries: result.entries,
          catalog_fingerprint: catalogFingerprint,
        }, { profileId, appVersion })
      } catch {
        fail('NATIVE014_PROVIDER_RESULT_INVALID')
      }
      if (computePackagingCatalogFingerprint({ profileId, appVersion, entries: index.entries, desktopBinding: index.desktopBinding }) !== catalogFingerprint) {
        fail('NATIVE014_CATALOG_FINGERPRINT_MISMATCH')
      }
      return Object.freeze({
        provider_id: providerId,
        profile_id: profileId,
        app_version: appVersion,
        catalog_fingerprint: catalogFingerprint,
        state: result.state,
        evidence_id: null,
        index,
      })
    },
  })
}

/**
 * CapCut Mate uses a bounded-shard intake because the pinned discovery source
 * is intentionally larger than the legacy provider-assisted 20k monolith.
 * The returned handle remains private and can only be searched lazily.
 * @param {{profileId: string, appVersion: string, manifest: Record<string, any>, readShards: () => AsyncIterable<Record<string, any>>, assertCurrentDesktop: (input: Record<string, any>) => Promise<boolean>}} input
 */
export const createCapCutMateShardedCatalogIntake = ({ profileId, appVersion, manifest, readShards, assertCurrentDesktop }) => {
  if (typeof profileId !== 'string' || !/^jianying-[a-z0-9-]{1,80}$/u.test(profileId) ||
      typeof appVersion !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(appVersion) ||
      !isRecord(manifest) || typeof manifest.manifestFingerprint !== 'string' || !fingerprint.test(manifest.manifestFingerprint) ||
      !Array.isArray(manifest.shards) || manifest.shards.length === 0 || typeof readShards !== 'function' ||
      typeof assertCurrentDesktop !== 'function') fail('NATIVE014_PROVIDER_INTAKE_INVALID')
  const expectedEntries = manifest.shards.reduce((sum, shard) => sum + Number(shard?.entries ?? 0), 0)
  if (!Number.isSafeInteger(expectedEntries) || expectedEntries < 1 ||
      manifest.shards.some((shard) => !Number.isSafeInteger(shard?.entries) || shard.entries < 1 || shard.entries > 10_000)) {
    fail('NATIVE014_PROVIDER_RESULT_INVALID')
  }
  return Object.freeze({
    providerId: 'capcut_mate_snapshot',
    async ingest() {
      if (await assertCurrentDesktop({ profileId, appVersion }) !== true) fail('NATIVE014_DESKTOP_BINDING_UNAVAILABLE')
      let observedEntries = 0
      const families = new Set()
      for await (const shard of readShards()) {
        if (!isRecord(shard) || !Array.isArray(shard.entries) || shard.entries.length > 10_000) fail('NATIVE014_PROVIDER_RESULT_INVALID')
        for (const entry of shard.entries) {
          if (!isRecord(entry) || entry.state !== 'discoverable' || entry.writer_eligible === true || entry.evidence !== undefined ||
              typeof entry.family !== 'string' || !isRecord(entry.private_binding)) fail('NATIVE014_PROVIDER_RESULT_INVALID')
          observedEntries += 1
          families.add(entry.family)
        }
      }
      if (observedEntries !== expectedEntries) fail('NATIVE014_PROVIDER_RESULT_INVALID')
      return Object.freeze({
        provider_id: 'capcut_mate_snapshot',
        profile_id: profileId,
        app_version: appVersion,
        catalog_fingerprint: manifest.manifestFingerprint,
        state: 'discovery_only',
        entries: observedEntries,
        families: Object.freeze([...families].sort()),
        shards: manifest.shards.length,
      })
    },
  })
}
