import {
  EditorCapabilityRegistryError,
  createEditorCapabilityRegistry,
} from './editor-capability-registry.mjs'
import { spanZeroStartBgmToTimeline } from './rich-timeline-bgm-span.mjs'
import { assertRichTimeline } from './rich-timeline-contracts.mjs'

export class RichTimelineJianyingProjectionError extends Error {
  /** @param {string} code @param {number} [status] @param {string | null} [capabilityId] */
  constructor(code, status = 409, capabilityId = null) {
    super(code)
    this.name = 'RichTimelineJianyingProjectionError'
    this.code = code
    this.status = status
    this.capabilityId = capabilityId
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {Record<string, any>} range */
const toLegacyRange = (range) => ({
  start: range.startUs,
  duration: range.durationUs,
})

/**
 * Build a synthetic EditPlan that canonical-matches the projected preparation.
 * @param {Record<string, any>} preparation
 * @param {{createdAt?: string}} [meta]
 */
export const editPlanFromJianyingPreparation = (preparation, meta = {}) => {
  const tracks = preparation.timeline.tracks
  /** @type {Record<string, any>[]} */
  const videoSegments = tracks[0].segments
  /** @type {Record<string, any>[]} */
  const voiceoverSegments = tracks[1].segments
  return {
    schema_version: 1,
    plan_id: preparation.source_plan_id,
    project_id: preparation.project_id,
    created_at: typeof meta.createdAt === 'string' ? meta.createdAt : '2026-07-27T00:00:00.000Z',
    items: videoSegments.map((segment, index) => {
      const voiceover = voiceoverSegments[index]
      const start = segment.source_range.start / 1_000_000
      const end = (segment.source_range.start + segment.source_range.duration) / 1_000_000
      return {
        sentence_id: segment.sentence_id,
        order: segment.order,
        voiceover_text: voiceover.text,
        status: 'selected',
        selected_candidate_id: segment.material_ref.candidate_id,
        candidates: [
          {
            candidate_id: segment.material_ref.candidate_id,
            asset_id: segment.material_ref.asset_id,
            scene_id: segment.material_ref.scene_id,
            source: 'search',
            start,
            end,
            summary: `rich timeline segment ${index + 1}`,
            tags: [],
            search_score: 1,
            director_score: 1,
            reason: 'finalized RichTimeline segment',
          },
        ],
      }
    }),
  }
}

/**
 * @param {unknown} timeline
 * @param {{capabilityRegistry?: ReturnType<typeof createEditorCapabilityRegistry>, jianyingProfileId?: string | null, allowAppendTrackFallback?: boolean}} [options]
 */
export const projectRichTimelineToJianyingExport = (timeline, options = {}) => {
  if (!isRecord(timeline) || timeline.status !== 'finalized') {
    throw new RichTimelineJianyingProjectionError('JY004_TIMELINE_NOT_FINALIZED')
  }
  for (const track of Array.isArray(timeline.tracks) ? timeline.tracks : []) {
    for (const segment of Array.isArray(track?.segments) ? track.segments : []) {
      const videoFadeCount = Array.isArray(segment?.effects)
        ? segment.effects.filter((/** @type {Record<string, any>} */ effect) => effect?.capabilityId === 'audio.video.fade').length
        : 0
      if (videoFadeCount > 1) {
        throw new RichTimelineJianyingProjectionError('JY074_VIDEO_FADE_DUPLICATE', 409, 'audio.video.fade')
      }
      const chromaCount = Array.isArray(segment?.effects)
        ? segment.effects.filter((/** @type {Record<string, any>} */ effect) => effect?.capabilityId === 'chroma.video').length
        : 0
      if (chromaCount > 1) {
        throw new RichTimelineJianyingProjectionError('JY082_CHROMA_DUPLICATE', 409, 'chroma.video')
      }
    }
  }
  assertRichTimeline(timeline)
  timeline = spanZeroStartBgmToTimeline(timeline)

  const registry = options.capabilityRegistry ?? createEditorCapabilityRegistry({
    jianyingProfileId: options.jianyingProfileId,
  })
  for (const requirement of timeline.capabilityRequirements ?? []) {
    // The canonical timeline records the number of non-video lanes, but this
    // is an implementation detail for the writer.  Jianying 11.2 has no
    // verified bulk-insert API; the writer uses its established append-track
    // path instead.  The caller owns the decision to enable this fallback
    // after checking the exact writer/profile boundary; the projection must
    // not encode a historical profile allowlist here.
    if (
      options.allowAppendTrackFallback === true &&
      (requirement.capabilityId === 'track.insert' || requirement.capabilityId === 'track.insert_many')
    ) continue
    try {
      registry.assertWriterCapability(requirement.capabilityId, 'jianying')
    } catch (error) {
      if (error instanceof EditorCapabilityRegistryError) {
        throw new RichTimelineJianyingProjectionError(
          'JY004_CAPABILITY_UNSUPPORTED',
          error.status,
          error.capabilityId,
        )
      }
      throw error
    }
  }

  const videoTrack = timeline.tracks.find(
    (/** @type {Record<string, any>} */ track) =>
      track.kind === 'video' && track.role === 'primary' && track.enabled !== false,
  )
  if (!videoTrack || !Array.isArray(videoTrack.segments) || videoTrack.segments.length === 0) {
    throw new RichTimelineJianyingProjectionError('JY004_PRIMARY_VIDEO_MISSING')
  }

  const voiceoverTrack = timeline.tracks.find(
    (/** @type {Record<string, any>} */ track) =>
      track.kind === 'audio' && track.role === 'voiceover' && track.enabled !== false,
  )
  const voiceoverSegments = Array.isArray(voiceoverTrack?.segments)
    ? [...voiceoverTrack.segments].sort(
        (left, right) => left.targetRange.startUs - right.targetRange.startUs,
      )
    : []

  if (
    voiceoverSegments.length > 0 &&
    voiceoverSegments.length !== videoTrack.segments.length
  ) {
    throw new RichTimelineJianyingProjectionError('JY002_VOICEOVER_AUDIO_MISSING')
  }

  const captionTrack = timeline.tracks.find(
    (/** @type {Record<string, any>} */ track) =>
      track.kind === 'caption' && track.enabled !== false,
  )
  const captionTexts = Array.isArray(captionTrack?.segments)
    ? [...captionTrack.segments]
        .sort((left, right) => left.targetRange.startUs - right.targetRange.startUs)
        .map((segment) =>
          typeof segment.text === 'string' && segment.text.trim()
            ? segment.text.trim().slice(0, 500)
            : null,
        )
    : []
  const effectiveVoiceoverSegments = voiceoverSegments.length > 0
    ? voiceoverSegments
    : videoTrack.segments.map(
        (/** @type {Record<string, any>} */ segment, /** @type {number} */ index) => ({
        targetRange: segment.targetRange,
        text: captionTexts[index] ?? `镜头 ${index + 1}`,
        source: null,
      }))

  /** @type {Record<string, any>[]} */
  const projectedVideo = []
  /** @type {Record<string, any>[]} */
  const projectedVoiceover = []
  /** @type {Record<string, any>[]} */
  const packagingVideo = []
  const packagingVoiceoverSegments = []
  /** @type {string[]} */
  const voiceoverAudioTokens = []
  /** @type {Record<string, any>[]} */
  const packagingChromaSegments = []

  for (let index = 0; index < videoTrack.segments.length; index += 1) {
    const segment = videoTrack.segments[index]
    const voiceover = effectiveVoiceoverSegments[index]
    if (
      voiceover.targetRange.startUs !== segment.targetRange.startUs ||
      voiceover.targetRange.durationUs !== segment.targetRange.durationUs
    ) {
      throw new RichTimelineJianyingProjectionError('JY004_VOICEOVER_RANGE_MISMATCH')
    }
    const audioToken =
      voiceover.source?.kind === 'generated'
        ? voiceover.source.generatedAudioId
        : voiceover.source?.kind === 'asset'
          ? voiceover.source.reference?.assetId
          : null
    if (
      voiceoverSegments.length > 0 &&
      (typeof audioToken !== 'string' || audioToken.length === 0)
    ) {
      throw new RichTimelineJianyingProjectionError('JY002_VOICEOVER_AUDIO_MISSING')
    }

    const transitionOut = segment.transitionOut
    const speed = segment.speed
    const speedValue = speed.numerator / speed.denominator
    if (!Number.isFinite(speedValue) || speedValue < 0.25 || speedValue > 4) {
      throw new RichTimelineJianyingProjectionError('JY066_SPEED_OUT_OF_RANGE', 409, 'speed.constant')
    }
    if (
      transitionOut &&
      transitionOut.capabilityId !== 'transition.cut' &&
      transitionOut.capabilityId !== 'transition.none'
    ) {
      registry.assertWriterCapability(transitionOut.capabilityId, 'jianying')
    }
    for (const keyframe of segment.keyframes ?? []) {
      registry.assertWriterCapability(keyframe.capabilityId, 'jianying')
    }

    const sentenceId = `editor-${index + 1}`
    projectedVideo.push({
      segment_id: `video-${sentenceId}`,
      sentence_id: sentenceId,
      order: index + 1,
      material_ref: {
        asset_id: segment.asset.assetId,
        scene_id: `${segment.asset.sceneId}-slot${index + 1}`,
        candidate_id: segment.audit?.candidateId ?? `candidate-${index + 1}`,
      },
      source_range: toLegacyRange(segment.sourceRange),
      target_range: toLegacyRange(segment.targetRange),
    })
    const projectedVoiceoverSegmentId = `voiceover-${sentenceId}`
    projectedVoiceover.push({
      segment_id: projectedVoiceoverSegmentId,
      sentence_id: sentenceId,
      order: index + 1,
      text: captionTexts[index] ?? `镜头 ${index + 1}`,
      target_range: toLegacyRange(voiceover.targetRange),
    })
    if (typeof audioToken === 'string' && audioToken.length > 0) {
      for (const keyframe of voiceover.keyframes ?? []) {
        registry.assertWriterCapability(keyframe.capabilityId, 'jianying')
      }
      voiceoverAudioTokens.push(audioToken)
      packagingVoiceoverSegments.push({
        segment_id: projectedVoiceoverSegmentId,
        fade_in_us: voiceover.fadeInUs ?? 0,
        fade_out_us: voiceover.fadeOutUs ?? 0,
        keyframes: (voiceover.keyframes ?? []).map((/** @type {Record<string, any>} */ keyframe) => ({
          capability_id: keyframe.capabilityId,
          offset_us: keyframe.offsetUs,
          value: keyframe.value,
          interpolation: keyframe.interpolation,
        })),
      })
    }
    const background = (segment.effects ?? []).find((/** @type {Record<string, any>} */ effect) => effect.capabilityId === 'background.video')
    const chroma = (segment.effects ?? []).find((/** @type {Record<string, any>} */ effect) => effect.capabilityId === 'chroma.video')
    const videoFades = (segment.effects ?? []).filter((/** @type {Record<string, any>} */ effect) => effect.capabilityId === 'audio.video.fade')
    if (videoFades.length > 1) {
      throw new RichTimelineJianyingProjectionError('JY074_VIDEO_FADE_DUPLICATE', 409, 'audio.video.fade')
    }
    const videoFade = videoFades[0]
    let videoFadeParameters = null
    if (videoFade) {
      const parameters = /** @type {Record<string, any>} */ (videoFade.parameters ?? {})
      registry.assertAllowedParameters('audio.video.fade', parameters, { writerTarget: 'jianying' })
      if (parameters.fadeInUs > segment.targetRange.durationUs || parameters.fadeOutUs > segment.targetRange.durationUs) {
        throw new RichTimelineJianyingProjectionError('JY074_VIDEO_FADE_OUT_OF_RANGE', 409, 'audio.video.fade')
      }
      videoFadeParameters = { fade_in_us: parameters.fadeInUs, fade_out_us: parameters.fadeOutUs }
    }
    let backgroundFillToken = null
    if (background) {
      registry.assertWriterCapability('background.video', 'jianying')
      backgroundFillToken = typeof background.parameters?.fillToken === 'string'
        ? background.parameters.fillToken
        : null
      if (!backgroundFillToken) {
        throw new RichTimelineJianyingProjectionError('JY004_PACKAGING_TOKEN_MISSING', 409, 'background.video')
      }
    }
    if (chroma) {
      const parameters = /** @type {Record<string, any>} */ (chroma.parameters ?? {})
      registry.assertAllowedParameters('chroma.video', parameters, { writerTarget: 'jianying' })
      packagingChromaSegments.push({
        color: parameters.color,
        intensity: parameters.intensity,
        shadow: parameters.shadow,
        edge_smooth: parameters.edgeSmooth,
        spill: parameters.spill,
        target_start_us: segment.targetRange.startUs,
        target_duration_us: segment.targetRange.durationUs,
      })
    }
    packagingVideo.push({
      segment_id: segment.segmentId,
      target_start_us: segment.targetRange.startUs,
      target_duration_us: segment.targetRange.durationUs,
      speed: structuredClone(speed),
      ...(backgroundFillToken ? { background_fill_token: backgroundFillToken } : {}),
      ...(videoFadeParameters ?? {}),
      transition_out:
        transitionOut &&
        transitionOut.capabilityId !== 'transition.cut' &&
        transitionOut.capabilityId !== 'transition.none'
          ? {
              capability_id: transitionOut.capabilityId,
              duration_us: transitionOut.durationUs,
              parameters: structuredClone(transitionOut.parameters ?? {}),
            }
          : null,
      keyframes: (segment.keyframes ?? []).map((/** @type {Record<string, any>} */ keyframe) => ({
        capability_id: keyframe.capabilityId,
        offset_us: keyframe.offsetUs,
        value: structuredClone(keyframe.value),
        interpolation: keyframe.interpolation,
      })),
    })
  }

  /** @type {Record<string, any>[]} */
  const captionSegments = []
  /** @type {Record<string, any>[]} */
  const titleSegments = []
  /** @type {Record<string, any>[]} */
  const richTextSegments = []
  /** @type {Record<string, any>[]} */
  const sfxSegments = []
  /** @type {Record<string, any>[]} */
  const packagingEffectSegments = []
  /** @type {Record<string, any>[]} */
  const packagingStickerSegments = []
  /** @type {Record<string, any>[]} */
  const packagingAnimationSegments = []
  /** @type {Record<string, any>[]} */
  const packagingMaskSegments = []
  const packagingBlendSegments = []
  /** @type {Record<string, any>[]} */
  const packagingAudioEffectSegments = []
  /** @type {Record<string, any>[]} */
  const packagingTextAnimationSegments = []
  /** @type {Array<Record<string, any>>} */
  const packagingFilterSegments = []
  /** @type {Record<string, any> | null} */
  let bgm = null
  /** @type {'default' | 'bottom_safe'} */
  let subtitleStyle = 'default'
  const knownSfxRangeCounts = new Map()
  for (const segment of timeline.tracks
    .filter((/** @type {Record<string, any>} */ track) => track.enabled !== false && track.kind === 'audio' && track.role === 'sfx')
    .flatMap((/** @type {Record<string, any>} */ track) => track.segments ?? [])) {
    const key = `${segment.targetRange.startUs}:${segment.targetRange.durationUs}`
    knownSfxRangeCounts.set(key, (knownSfxRangeCounts.get(key) ?? 0) + 1)
  }

  for (const track of timeline.tracks) {
    if (track.enabled === false) continue
    if (track.kind === 'caption') {
      for (const segment of track.segments ?? []) {
        registry.assertWriterCapability(segment.capabilityId, 'jianying')
        if (segment.capabilityId === 'caption.bottom_safe') subtitleStyle = 'bottom_safe'
        captionSegments.push({
          segment_id: segment.segmentId,
          text: segment.text,
          style_token: segment.styleToken,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
          capability_id: segment.capabilityId,
        })
      }
    }
    if (track.kind === 'title') {
      for (const segment of track.segments ?? []) {
        registry.assertWriterCapability(segment.capabilityId, 'jianying')
        const animationTokens = [segment.animationIn, segment.animationOut]
          .filter((token) => typeof token === 'string')
        if (animationTokens.length > 1) {
          throw new RichTimelineJianyingProjectionError('JY083_TEXT_ANIMATION_AMBIGUOUS', 409, 'animation.text.named')
        }
        if (animationTokens.length === 1) {
          registry.assertWriterCapability('animation.text.named', 'jianying')
          packagingTextAnimationSegments.push({
            target_segment_id: segment.segmentId,
            animation_token: animationTokens[0],
          })
        }
        for (const keyframe of segment.keyframes ?? []) {
          registry.assertWriterCapability(keyframe.capabilityId, 'jianying')
        }
        const entry = /** @type {Record<string, any>} */ ({
          segment_id: segment.segmentId,
          text: segment.text,
          style_token: segment.styleToken,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
          capability_id: segment.capabilityId,
          template_token: segment.templateToken,
          ...(typeof segment.templateSlotId === 'string' ? { template_slot_id: segment.templateSlotId } : {}),
          ...(segment.layout ? { layout: structuredClone(segment.layout) } : {}),
          keyframes: (segment.keyframes ?? []).map((/** @type {Record<string, any>} */ keyframe) => ({
            capability_id: keyframe.capabilityId,
            offset_us: keyframe.offsetUs,
            value: keyframe.value,
            interpolation: keyframe.interpolation,
          })),
        })
        if (segment.kind === 'rich_text') richTextSegments.push(entry)
        else titleSegments.push(entry)
      }
    }
    if (track.kind === 'audio' && track.role === 'sfx') {
      for (const segment of track.segments ?? []) {
        registry.assertWriterCapability(segment.capabilityId, 'jianying')
        const audioToken =
          segment.source?.kind === 'generated'
            ? segment.source.generatedAudioId
            : segment.source?.reference?.assetId
        if (typeof audioToken !== 'string') {
          throw new RichTimelineJianyingProjectionError('JY004_SFX_AUDIO_MISSING')
        }
        sfxSegments.push({
          segment_id: segment.segmentId,
          audio_token: audioToken,
          volume: segment.volume,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
          fade_in_us: segment.fadeInUs,
          fade_out_us: segment.fadeOutUs,
        })
      }
    }
    if (track.kind === 'audio' && track.role === 'bgm') {
      for (const segment of track.segments ?? []) {
        registry.assertWriterCapability(segment.capabilityId, 'jianying')
        const audioToken =
          segment.source?.kind === 'generated'
            ? segment.source.generatedAudioId
            : segment.source?.reference?.assetId ?? segment.source?.reference?.authorizationId
        if (typeof audioToken !== 'string') {
          throw new RichTimelineJianyingProjectionError('JY004_BGM_AUDIO_MISSING')
        }
        if (bgm) {
          throw new RichTimelineJianyingProjectionError('JY004_BGM_AMBIGUOUS')
        }
        if (
          segment.targetRange.startUs !== 0 ||
          segment.targetRange.durationUs !== timeline.durationUs
        ) {
          throw new RichTimelineJianyingProjectionError(
            'JY004_BGM_RANGE_UNSUPPORTED',
            409,
            segment.capabilityId,
          )
        }
        bgm = {
          segment_id: segment.segmentId,
          audio_token: audioToken,
          capability_id: segment.capabilityId,
          volume: segment.volume,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
          fade_in_us: segment.fadeInUs,
          fade_out_us: segment.fadeOutUs,
        }
      }
    }
    if (track.kind === 'effect') {
      for (const segment of track.segments ?? []) {
        registry.assertWriterCapability(segment.capabilityId, 'jianying')
        if (segment.capabilityId === 'audio.effect.named') {
          const effectToken = typeof segment.parameters?.effectToken === 'string'
            ? segment.parameters.effectToken
            : null
          if (!effectToken || knownSfxRangeCounts.get(`${segment.targetRange.startUs}:${segment.targetRange.durationUs}`) !== 1) {
            throw new RichTimelineJianyingProjectionError('JY067_AUDIO_EFFECT_BINDING_INVALID', 409, segment.capabilityId)
          }
          packagingAudioEffectSegments.push({
            effect_token: effectToken,
            target_start_us: segment.targetRange.startUs,
            target_duration_us: segment.targetRange.durationUs,
          })
          continue
        }
        if (segment.capabilityId === 'filter.video.named' || segment.capabilityId === 'filter.video.track_named') {
          const filterToken = typeof segment.parameters?.packagingToken === 'string'
            ? segment.parameters.packagingToken
            : null
          if (!filterToken) {
            throw new RichTimelineJianyingProjectionError(
              'JY004_PACKAGING_TOKEN_MISSING',
              409,
              segment.capabilityId,
            )
          }
          const intensity = segment.parameters?.intensity
          if (typeof intensity !== 'number' || !Number.isFinite(intensity) || intensity < 0 || intensity > 1) {
            throw new RichTimelineJianyingProjectionError(
              'JY004_FILTER_INTENSITY_INVALID',
              409,
              segment.capabilityId,
            )
          }
          packagingFilterSegments.push({
            segment_id: segment.segmentId,
            filter_token: filterToken,
            capability_id: segment.capabilityId,
            target_start_us: segment.targetRange.startUs,
            target_duration_us: segment.targetRange.durationUs,
            intensity: intensity * 100,
          })
          continue
        }
        const packagingToken = segment.capabilityId === 'animation.video.named'
          ? (typeof segment.parameters?.animationToken === 'string' ? segment.parameters.animationToken : null)
          : segment.capabilityId === 'mask.video.named'
          ? (typeof segment.parameters?.maskToken === 'string' ? segment.parameters.maskToken : null)
          : segment.capabilityId === 'blend.video.named'
            ? (typeof segment.parameters?.blendToken === 'string' ? segment.parameters.blendToken : null)
            : (typeof segment.parameters?.packagingToken === 'string' ? segment.parameters.packagingToken : null)
        if (!packagingToken) {
          throw new RichTimelineJianyingProjectionError(
            'JY004_PACKAGING_TOKEN_MISSING',
            409,
            segment.capabilityId,
          )
        }
        /** @type {Record<string, any>} */
        const entry = {
          segment_id: segment.segmentId,
          packaging_token: packagingToken,
          capability_id: segment.capabilityId,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
          intensity: segment.intensity,
        }
        if (segment.capabilityId === 'sticker.named' && Array.isArray(segment.keyframes) && segment.keyframes.length > 0) {
          for (const keyframe of segment.keyframes) {
            registry.assertWriterCapability(keyframe.capabilityId, 'jianying')
          }
          entry.keyframes = segment.keyframes.map((/** @type {any} */ keyframe) => ({
            capability_id: keyframe.capabilityId,
            offset_us: keyframe.offsetUs,
            value: keyframe.value,
            interpolation: keyframe.interpolation,
          }))
        }
        if (segment.capabilityId === 'animation.video.named') packagingAnimationSegments.push({
          segment_id: segment.segmentId,
          animation_token: packagingToken,
          capability_id: segment.capabilityId,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
        })
        else if (segment.capabilityId === 'mask.video.named') packagingMaskSegments.push({
          segment_id: segment.segmentId,
          mask_token: packagingToken,
          capability_id: segment.capabilityId,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
          size: segment.parameters?.size ?? 0.5,
        })
        else if (segment.capabilityId === 'blend.video.named') packagingBlendSegments.push({
          segment_id: segment.segmentId,
          blend_token: packagingToken,
          capability_id: segment.capabilityId,
          target_start_us: segment.targetRange.startUs,
          target_duration_us: segment.targetRange.durationUs,
        })
        else if (segment.capabilityId === 'sticker.named') packagingStickerSegments.push(entry)
        else packagingEffectSegments.push(entry)
      }
    }
  }

  // Flower/bubble text is an additional title layer. Preserve every ordinary
  // caption range even when the two layers overlap; otherwise a full-range
  // flower silently removes the only subtitle for that shot.
  const filteredCaptionSegments = captionSegments
    .map((segment) => ({
      ...segment,
      text: segment.text.replace(/^[\s\p{P}]+|[\s\p{P}]+$/gu, '').trim(),
    }))
    .filter((segment) => segment.text.length > 0)

  const preparation = {
    schema_version: 1,
    kind: 'jianying_draft_preparation',
    preparation_id: `jianying-${timeline.timelineId}`,
    source_plan_id: timeline.timelineId,
    project_id: timeline.projectId,
    timeline: {
      timebase: 'microseconds',
      duration: timeline.durationUs,
      tracks: [
        { track_id: 'video-primary', type: 'video', segments: projectedVideo },
        { track_id: 'voiceover-guide', type: 'voiceover_guide', segments: projectedVoiceover },
      ],
    },
    blocked_items: [],
  }

  const packaging = {
    schema_version: 1,
    kind: 'jianying_timeline_packaging',
    timeline_content_fingerprint: timeline.contentFingerprint,
    timeline_revision_fingerprint: timeline.revisionFingerprint,
    subtitle_style: subtitleStyle,
    video: packagingVideo,
    voiceover_segments: packagingVoiceoverSegments,
    caption_segments: filteredCaptionSegments,
    title_segments: titleSegments,
    rich_text_segments: richTextSegments,
    sfx_segments: sfxSegments,
    audio_effect_segments: packagingAudioEffectSegments,
    effect_segments: packagingEffectSegments,
    sticker_segments: packagingStickerSegments,
    animation_segments: packagingAnimationSegments,
    mask_segments: packagingMaskSegments,
    blend_segments: packagingBlendSegments,
    filter_segments: packagingFilterSegments,
    chroma_segments: packagingChromaSegments,
    text_animation_segments: packagingTextAnimationSegments,
    bgm,
    voiceover_audio_tokens: voiceoverAudioTokens,
  }

  const serialized = JSON.stringify({ preparation, packaging })
  if (
    /[A-Za-z]:[\\/]/u.test(serialized) ||
    serialized.includes('file:') ||
    /\/(?:Users|home|opt)\//u.test(serialized)
  ) {
    throw new RichTimelineJianyingProjectionError('JY004_PRIVATE_PATH_LEAK')
  }

  return {
    preparation,
    packaging,
    editPlan: editPlanFromJianyingPreparation(preparation, {
      createdAt: timeline.createdAt,
    }),
    voiceoverAudioTokens,
  }
}
