import { createHash, randomUUID } from 'node:crypto'

import {
  materialAnalysisProviderErrorCodes,
  validAnalyzedAsset,
  validAnalyzedMaterials,
  validMaterialAnalysisProviderStatus,
  validSearchCandidate,
} from './material-analysis-contracts.mjs'
import {
  deriveMaterialContentTags,
  isPlaceholderMaterialTags,
  publicSceneCard,
} from './permissive-material-analyzer.mjs'
import {
  auditPackagingCapabilities,
  emptyPackaging,
  isVoiceId,
  listCuratedVoices,
  normalizeBrief,
  normalizePackaging,
  validBriefExtensions,
  validPackaging,
} from './brief-packaging.mjs'
import {
  createPreviewMediaResponse,
  createSyntheticCandidateClipResource,
  createSyntheticCandidatePosterResource,
  WorkbenchPreviewError,
} from './workbench-preview.mjs'
import {
  createBlendedProjectTemplateBinding,
  createProjectTemplateBinding,
  isProjectTemplateBinding,
  isReusableTemplateCreateCommand,
  toPublicReplicationRecipe,
} from './reusable-template-contracts.mjs'
import { ensureWindowsNativePickerHost } from './local-runtime.mjs'
import { isReplicationRecipe } from './replication-recipe.mjs'
import {
  createTemplateGuidance,
  adaptTemplateGuidanceToCount,
  applyTemplateGuidanceToSelections,
  TemplateBindingConsumptionError,
} from './template-binding-consumption.mjs'
import { materialContentFingerprint } from './workbench-job-coordinator.mjs'

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
const timestamp = () => new Date().toISOString()
/** @param {unknown} value */
const isTimestamp = (value) => typeof value === 'string' && Number.isFinite(Date.parse(value))
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {number} [max] */
const safeLabel = (value, max = 160) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= max &&
  !value.includes('\\') &&
  !value.includes('/') &&
  !value.includes('\u0000') &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value) &&
  !/\.(?:mp4|mov|mkv|avi|mp3|wav|aac|m4a)$/iu.test(value)
/** @param {unknown} value @param {number} [max] */
const safeText = (value, max = 8000) =>
  typeof value === 'string' && value.length <= max && !value.includes('\u0000')
/** @param {unknown} value */
const safeCreatorMaterialTag = (value) =>
  typeof value === 'string' && /^[\u3400-\u9fff0-9]{2,20}$/u.test(value)
/** @param {unknown} value */
const safeCreatorSceneSummary = (value) => {
  if (typeof value !== 'string') return ''
  const summary = value
    .replace(/(?:OCR|屏幕文字|Observed OCR)\s*[:：]?[^|]*/giu, '')
    .replace(/\b[A-Za-z][A-Za-z0-9_.-]*\b/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
  return /[\u3400-\u9fff]{2}/u.test(summary) && !/[\u2500-\u257f\uFFFD]/u.test(summary)
    ? summary.slice(0, 500)
    : ''
}
/** @param {unknown} value @param {number} [max] */
const safeBgmLabel = (value, max = 100) =>
  typeof value === 'string' &&
  value.trim().length > 0 &&
  value.length <= max &&
  !value.includes('\\') &&
  !value.includes('/') &&
  !value.includes('\u0000') &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value)
/** @param {unknown} value */
const safeReferenceVideoLabel = (value) =>
  typeof value === 'string' &&
  value.length <= 100 &&
  (/^已授权本机视频（\.(?:avi|m4v|mkv|mov|mp4|webm|wmv)）$/u.test(value) ||
    value === '已上传参考视频')

export const workbenchJobStates = Object.freeze(['preflight', 'resolving_materials', 'building_draft', 'verifying_output', 'ready_to_open', 'failed', 'cancelled'])
export const workbenchStages = Object.freeze(['materials', 'brief', 'storyboard', 'preview', 'delivery'])
export const recoveryDefinitions = Object.freeze({
  JY002_MATERIAL_AUTHORIZATION_EXPIRED: { title: '素材授权已失效', action: '重新授权素材文件夹', stage: 'materials' },
  TPL002_TEMPLATE_NOT_APPROVED: { title: '模板尚未批准使用', action: '确认或重新选择模板', stage: 'delivery' },
  JY002_TEMPLATE_CAPABILITY_UNSUPPORTED: { title: '模板能力暂不支持', action: '调整模板设置', stage: 'delivery' },
  JY002_VOICEOVER_AUDIO_MISSING: { title: '缺少配音音频', action: '补充配音后重新预检', stage: 'brief' },
  JY002_PATH_PERMISSION_DENIED: { title: '输出目录权限不足', action: '重新授权输出目录', stage: 'delivery' },
  JY002_DESKTOP_VERSION_UNSUPPORTED: { title: '桌面剪映环境暂不可验证', action: '查看处理说明', stage: 'delivery' },
  JY002_OUTPUT_CONFLICT: { title: '输出目录已有同名草稿', action: '选择新的输出目标', stage: 'delivery' },
  JY002_DRAFT_STRUCTURE_INVALID: { title: '草稿结构校验失败', action: '重新预检并导出', stage: 'delivery' },
})
const localAuthorizationErrors = Object.freeze({
  LOCAL_FOLDER_SELECTION_CANCELLED: { title: '文件夹选择已取消', action: '重新选择素材文件夹' },
  LOCAL_FOLDER_PERMISSION_DENIED: { title: '素材文件夹无法只读访问', action: '检查权限后重新选择' },
  LOCAL_FOLDER_PICKER_UNAVAILABLE: { title: 'Windows 文件夹选择器不可用', action: '检查本地 Gateway 后重试' },
  LOCAL_MEDIA_SELECTION_CANCELLED: { title: '素材选择已取消', action: '重新选择视频或文件夹' },
  LOCAL_MEDIA_PICKER_UNAVAILABLE: { title: 'Windows 素材选择器不可用', action: '检查本地 Gateway 后重试' },
  LOCAL_REFERENCE_VIDEO_SELECTION_CANCELLED: { title: '视频选择已取消', action: '重新选择视频' },
  LOCAL_AUDIO_SELECTION_CANCELLED: { title: 'BGM 文件选择已取消', action: '重新选择 BGM 音频' },
  LOCAL_AUDIO_PERMISSION_DENIED: { title: 'BGM 文件无法只读访问', action: '检查权限后重新选择' },
  LOCAL_AUDIO_PICKER_UNAVAILABLE: { title: 'Windows 音频选择器不可用', action: '检查本地 Gateway 后重试' },
})

export class WorkbenchOperationError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'WorkbenchOperationError'
    this.code = code
    this.status = status
  }
}

/** @param {(string | number)[]} path @param {boolean} allowAnalyzedMaterialsRoot */
const isAllowedAsrTranscriptPath = (path, allowAnalyzedMaterialsRoot) => {
  const projectPath = !allowAnalyzedMaterialsRoot && path.length === 6 &&
    path[0] === 'materials' && path[1] === 'assets' && typeof path[2] === 'number' &&
    path[3] === 'scenes' && typeof path[4] === 'number' && path[5] === 'asrTranscript'
  const analyzedMaterialsPath = allowAnalyzedMaterialsRoot && path.length === 5 &&
    path[0] === 'assets' && typeof path[1] === 'number' &&
    path[2] === 'scenes' && typeof path[3] === 'number' && path[4] === 'asrTranscript'
  const materialLibraryDetailPath = allowAnalyzedMaterialsRoot && path.length === 4 &&
    path[0] === 'asset' && path[1] === 'scenes' && typeof path[2] === 'number' && path[3] === 'asrTranscript'
  return projectPath || analyzedMaterialsPath || materialLibraryDetailPath
}

const materialLibraryMetadataKeys = Object.freeze([
  'libraryState',
  'sourceProjectId',
  'projectIds',
  'projectNames',
  'addedAt',
  'lastUsedAt',
])
const materialLibraryOpaqueIdPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/u

/** @param {unknown} value */
const validReviewedPublicAsset = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const asset = /** @type {Record<string, any>} */ (clone(value))
  if (!Array.isArray(asset.scenes)) return validAnalyzedAsset(asset)
  for (const scene of asset.scenes) {
    if (!scene || typeof scene !== 'object' || Array.isArray(scene)) return false
    if (scene.reviewStatus === undefined && scene.reviewUpdatedAt === undefined) continue
    if (!['confirmed', 'needsReview', 'unavailable'].includes(scene.reviewStatus)) return false
    if (scene.reviewUpdatedAt !== undefined &&
      (typeof scene.reviewUpdatedAt !== 'string' || !Number.isFinite(Date.parse(scene.reviewUpdatedAt)))) return false
    delete scene.reviewStatus
    delete scene.reviewUpdatedAt
  }
  return validAnalyzedAsset(asset)
}

/** @param {unknown} value */
const validMaterialLibraryAsset = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const asset = { .../** @type {Record<string, unknown>} */ (value) }
  const state = asset.libraryState
  if (!['ready', 'stale', 'unavailable'].includes(String(state))) return false
  if (!Array.isArray(asset.projectIds) || asset.projectIds.length === 0 ||
      !asset.projectIds.every((id) => typeof id === 'string' && materialLibraryOpaqueIdPattern.test(id))) return false
  if (!Array.isArray(asset.projectNames) || asset.projectNames.length !== asset.projectIds.length ||
      !asset.projectNames.every((name) => typeof name === 'string' && name.trim().length > 0 && name.length <= 160)) return false
  if (asset.sourceProjectId !== null && (typeof asset.sourceProjectId !== 'string' || !materialLibraryOpaqueIdPattern.test(asset.sourceProjectId))) return false
  if (typeof asset.addedAt !== 'string' || !Number.isFinite(Date.parse(asset.addedAt))) return false
  if (typeof asset.lastUsedAt !== 'string' || !Number.isFinite(Date.parse(asset.lastUsedAt))) return false
  for (const key of materialLibraryMetadataKeys) delete asset[key]
  // Stale/unavailable cards intentionally retain the last safe scene card while
  // exposing a non-ready state; normalize the presentation fields for schema validation.
  if (state !== 'ready') {
    asset.status = 'ready'
    asset.analyzedPercent = 100
  }
  return validAnalyzedAsset(asset)
}

/** @param {unknown} value @param {(string | number)[]} [path] @param {boolean} [allowAnalyzedMaterialsRoot] @returns {boolean} */
const hasForbiddenPublicField = (value, path = [], allowAnalyzedMaterialsRoot = false) => {
  if (typeof value === 'string') {
    let containsDrivePath = false
    for (let index = 0; index <= value.length - 3; index += 1) {
      const character = value.charCodeAt(index)
      const isAsciiLetter =
        (character >= 65 && character <= 90) ||
        (character >= 97 && character <= 122)
      if (
        isAsciiLetter &&
        value.charCodeAt(index + 1) === 58 &&
        [47, 92].includes(value.charCodeAt(index + 2))
      ) {
        containsDrivePath = true
        break
      }
    }
    return containsDrivePath ||
      value.includes(String.fromCharCode(92, 92)) ||
      /(?:file:\/\/|\/(?:home|users|private|var|tmp|mnt|volumes)\/|\.(?:mp4|mov|mkv|avi|mp3|wav|aac|m4a)(?:\b|$))/iu.test(value)
  }
  if (Array.isArray(value)) {
    return value.some((entry, index) => hasForbiddenPublicField(entry, [...path, index], allowAnalyzedMaterialsRoot))
  }
  if (!value || typeof value !== 'object') return false
  const isPublicMaterialAsset = !allowAnalyzedMaterialsRoot && path.length === 3 &&
    path[0] === 'materials' && path[1] === 'assets' && typeof path[2] === 'number'
  const isAnalyzedMaterialAsset = allowAnalyzedMaterialsRoot && path.length === 2 &&
    path[0] === 'assets' && typeof path[1] === 'number'
  const isMaterialLibraryAsset = allowAnalyzedMaterialsRoot && path.length === 2 &&
    path[0] === 'assets' && typeof path[1] === 'number' && 'libraryState' in value
  const isMaterialLibraryDetailAsset = allowAnalyzedMaterialsRoot && path.length === 1 &&
    path[0] === 'asset' && 'libraryState' in value
  if (isPublicMaterialAsset && 'scenes' in value && !validReviewedPublicAsset(value)) return true
  if ((isMaterialLibraryAsset || isMaterialLibraryDetailAsset) && 'scenes' in value && !validMaterialLibraryAsset(value)) return true
  if (isAnalyzedMaterialAsset && !isMaterialLibraryAsset && 'scenes' in value && !validAnalyzedAsset(value)) return true
  return Object.entries(value).some(([key, entry]) => {
    if (key === 'bgmLabel' || key === 'sfxLabel') {
      return entry !== null && !safeBgmLabel(entry)
    }
    if (key === 'label' && safeReferenceVideoLabel(entry)) return false
    // Only validated material scene-card locations may expose sanitized ASR evidence.
    if (key === 'asrTranscript') {
      const entryPath = [...path, key]
      return !isAllowedAsrTranscriptPath(entryPath, allowAnalyzedMaterialsRoot) ||
        typeof entry !== 'string' ||
        entry.trim().length === 0 ||
        entry.length > 500 ||
        hasForbiddenPublicField(entry, entryPath, allowAnalyzedMaterialsRoot)
    }
    // Opaque library audio refs are intentional public fields (tma_*); only values are scanned.
    if (key === 'audioToken' || key === 'bgmAudioToken' || key === 'sfxAudioToken') {
      if (entry === null || entry === undefined) return false
      return typeof entry !== 'string' || hasForbiddenPublicField(entry, [...path, key], allowAnalyzedMaterialsRoot)
    }
    // Packaging refs are opaque, non-path tokens used by the Jianying writer.
    // They are safe to expose in the public recipe; their private resource IDs
    // remain in template-media-store's packaging map.
    if (key === 'packagingToken' || (key === 'token' && path.includes('packaging'))) {
      return entry !== null && entry !== undefined &&
        (typeof entry !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(entry))
    }
    return /(?:path|url|transcript|media|thumbnail|provider|secret|token|credential|password|api[_-]?key|base[_-]?url)/iu.test(key) ||
      hasForbiddenPublicField(entry, [...path, key], allowAnalyzedMaterialsRoot)
  })
}

/** @template T @param {T} value @returns {T} */
const assertSafeCapabilityResult = (value) => {
  if (hasForbiddenPublicField(value, [], true)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
  return value
}

/** @param {keyof typeof recoveryDefinitions} code */
const safeError = (code) => ({ code, ...(recoveryDefinitions[code] ?? { title: '任务需要重试', action: '重试任务', stage: 'overview' }), recoverable: true })
const privateTaskFields = Object.freeze([
  'projectId',
  'position',
  'operation',
  'idempotencyKey',
  'attempt',
  'leaseOwner',
  'leaseExpiresAt',
  'checkpoint',
  'cancelRequestedAt',
  'timeoutAt',
])
/** @param {any} task */
const publicTask = (task) => {
  const safe = clone(task)
  for (const field of privateTaskFields) delete safe[field]
  return safe
}
/** @param {any} project */
const enrichMaterialSceneTags = (project) => {
  const assets = project?.materials?.assets
  if (!Array.isArray(assets)) return project
  for (const asset of assets) {
    if (!Array.isArray(asset?.scenes)) continue
    for (const scene of asset.scenes) {
      if (!isRecord(scene)) continue
      // Re-project persisted cards on every public read. Analysis records are
      // intentionally immutable, so a historical OCR/ASR result must never
      // bypass newer presentation quality gates just because it was produced
      // before the current Gateway process started.
      const card = publicSceneCard(scene)
      Object.assign(scene, card)
      const safeSummary = scene.summary === '已完成多帧采样，暂未提取到可验证的画面描述。'
        ? ''
        : safeCreatorSceneSummary(scene.summary)
      if (safeSummary) scene.summary = safeSummary
      else {
        scene.needsReview = true
        if (card.visualObservations[0]) scene.summary = card.visualObservations[0].split(/屏幕文字[:：]/u)[0].trim()
        else scene.summary = '该片段已完成画面分析。'
      }
      const usefulTags = Array.isArray(scene.tags)
        ? scene.tags.filter((/** @type {unknown} */ tag) =>
          safeCreatorMaterialTag(tag) && tag !== '已分析')
        : []
      if (usefulTags.length > 0 && !isPlaceholderMaterialTags(usefulTags)) {
        scene.tags = usefulTags.slice(0, 8)
        continue
      }
      scene.tags = deriveMaterialContentTags(typeof scene.summary === 'string' ? scene.summary : '')
    }
  }
  return project
}

/** @param {any} project */
const publicProject = (project) => {
  const safe = clone(project)
  delete safe.pendingOutputInvalidation
  delete safe.pendingProjectDeletion
  if (safe.materials && typeof safe.materials === 'object') {
    const materialCounts = ['total', 'analyzed', 'queued', 'failed']
      .map((key) => safe.materials[key])
      .filter((value) => Number.isSafeInteger(value) && value >= 0)
    const minimumTotal = Math.max(0, ...materialCounts)
    if (Number.isSafeInteger(safe.materials.total) && safe.materials.total < minimumTotal) {
      // Older persisted projects can retain a failed/queued count after their
      // source inventory was cleared. Keep the public counters self-consistent
      // so the browser can show the recoverable failure instead of rejecting
      // the entire project list.
      safe.materials.total = minimumTotal
    }
  }
  safe.templateBinding = isProjectTemplateBinding(safe.templateBinding)
    ? {
        ...clone(safe.templateBinding),
        ...(isReplicationRecipe(safe.templateBinding.replicationRecipe)
          ? { replicationRecipe: toPublicReplicationRecipe(safe.templateBinding.replicationRecipe) }
          : {}),
      }
    : null
  safe.brief = {
    ...normalizeBrief(safe.brief),
    packagingCapabilities: auditPackagingCapabilities(safe.brief),
  }
  safe.tasks = Array.isArray(project.tasks) ? project.tasks.map(publicTask) : []
  delete safe.editor
  return enrichMaterialSceneTags(safe)
}
/** @param {number} timeoutMs */
/** @param {unknown} value */
const optionalIdempotencyKey = (value) => safeLabel(value, 160) ? /** @type {string} */ (value) : null
/** @param {unknown} value @param {number} fallback */
const optionalTimeoutMs = (value, fallback) =>
  Number.isInteger(value) && /** @type {number} */ (value) >= 1 && /** @type {number} */ (value) <= 600_000
    ? /** @type {number} */ (value)
    : fallback
const storyboard = () => ({ id: 'storyboard-demo', title: '水杯新品短片', updatedAt: '2026-07-23T08:20:00.000Z', sentences: [
  { id: 'sentence-opening', order: 1, text: '打开包装，第一眼就能看到简洁完整的产品组合。', selectedCandidateId: 'candidate-opening', status: 'selected', candidates: [
    { id: 'candidate-opening', assetLabel: '包装开箱 · 片段 02', start: 12.2, end: 21.4, summary: '产品和配件逐步露出，画面信息完整。', matchScore: 0.96, reason: '动作、主体和开场节奏与文案最一致。' },
    { id: 'candidate-opening-alt', assetLabel: '包装开箱 · 片段 01', start: 0, end: 8.6, summary: '包装盒居中，手部准备打开上盖。', matchScore: 0.83, reason: '适合作为开场铺垫，但产品露出稍晚。' },
    { id: 'candidate-opening-detail', assetLabel: '杯身细节 · 片段 01', start: 0, end: 7.4, summary: '水杯从画面左侧进入，手部动作稳定。', matchScore: 0.74, reason: '产品出现明确，但缺少包装信息。' },
  ] },
  { id: 'sentence-detail', order: 2, text: '细看杯身，磨砂质感会随着柔光慢慢显现。', selectedCandidateId: 'candidate-detail', status: 'selected', candidates: [
    { id: 'candidate-detail', assetLabel: '杯身细节 · 片段 02', start: 7.4, end: 16.8, summary: '杯身旋转展示磨砂材质和高光变化。', matchScore: 0.97, reason: '材质、光线和运动方向均直接对应文案。' },
    { id: 'candidate-detail-alt', assetLabel: '杯身细节 · 片段 03', start: 16.8, end: 24, summary: '镜头靠近标识区域，背景保持干净。', matchScore: 0.86, reason: '近景清晰，但对整体磨砂质感覆盖较少。' },
    { id: 'candidate-detail-window', assetLabel: '晨间桌面 · 片段 01', start: 0, end: 18.5, summary: '晨光照在桌面和产品上，整体色调明亮。', matchScore: 0.68, reason: '光线氛围相近，但材质细节不够集中。' },
  ] },
  { id: 'sentence-lifestyle', order: 3, text: '放回日常桌面，它自然融入清晨的使用节奏。', selectedCandidateId: 'candidate-lifestyle', status: 'selected', candidates: [
    { id: 'candidate-lifestyle', assetLabel: '晨间桌面 · 片段 02', start: 18.5, end: 31, summary: '用户伸手拿起杯子，动作自然。', matchScore: 0.93, reason: '环境、动作和生活方式语义高度匹配。' },
    { id: 'candidate-lifestyle-alt', assetLabel: '环境空镜 · 片段 01', start: 3, end: 11, summary: '桌面和窗边光线提供干净的生活氛围。', matchScore: 0.81, reason: '氛围匹配，但缺少产品动作。' },
    { id: 'candidate-lifestyle-pack', assetLabel: '包装开箱 · 片段 03', start: 22, end: 29, summary: '产品回到桌面中央，构图稳定。', matchScore: 0.72, reason: '画面稳定，但生活感较弱。' },
  ] },
] })

const demoProject = () => ({
  id: 'project-demo', name: '水杯新品短片', notes: '春季新品发布，突出材质和清晨使用场景。', status: 'active', currentStage: 'delivery', createdAt: '2026-07-23T08:00:00.000Z', updatedAt: '2026-07-23T08:30:00.000Z',
  materials: { authorizationId: 'authorization-demo', authorized: true, readOnlyConfirmed: true, folderLabel: '素材库 · 产品实拍', total: 6, analyzed: 5, queued: 0, failed: 1, analysisStatus: 'ready', lastScanAt: '2026-07-23T08:12:00.000Z', assets: [
    { id: 'asset-cup-detail', label: '杯身细节', status: 'ready', analyzedPercent: 100, durationSeconds: 24, sceneCount: 3 }, { id: 'asset-morning-desk', label: '晨间桌面', status: 'analyzing', analyzedPercent: 68, durationSeconds: 42, sceneCount: 2 }, { id: 'asset-packaging-open', label: '包装开箱', status: 'ready', analyzedPercent: 100, durationSeconds: 31, sceneCount: 3 }, { id: 'asset-failed', label: '待重试素材', status: 'failed', analyzedPercent: 0, durationSeconds: 18, sceneCount: 0 },
  ] },
  brief: { theme: '把一只日常水杯拍出轻盈、可靠的清晨仪式感。', title: '每天都想带上的那只杯子', sellingPoints: ['磨砂材质不易留指纹', '轻量杯身适合通勤', '开盖和收纳动作顺手'], script: '打开包装，第一眼就能看到简洁完整的产品组合。\n细看杯身，磨砂质感会随着柔光慢慢显现。\n放回日常桌面，它自然融入清晨的使用节奏。', style: '自然、明亮、节奏克制，避免夸张转场和过度饱和。', durationSeconds: 35, orientation: 'portrait', voiceover: 'none', voiceId: null, voiceRate: 0, captions: 'auto', packaging: emptyPackaging(), savedAt: '2026-07-23T08:18:00.000Z' },
  templateBinding: null,
  storyboard: storyboard(), preview: { status: 'ready', resourceId: 'preview-demo-v1', durationSeconds: 34.2, updatedAt: '2026-07-23T08:25:00.000Z' },
  delivery: { finalVideo: null, template: { status: 'confirmed', name: '轻量产品展示 · 竖屏', version: 'tpl002-demo-v1', reason: '匹配 35 秒、竖屏和克制字幕节奏。' }, preflight: { status: 'ready', checkedAt: '2026-07-23T08:27:00.000Z', checks: [{ label: '分镜完整性', status: 'pass' }, { label: '模板能力', status: 'pass' }, { label: '素材绑定', status: 'pass' }, { label: '配音音频', status: 'pass' }] }, exportJob: { id: 'jy002-demo-job', state: 'ready_to_open', progressPercent: 100, recoverable: false, error: null, result: { draftLabel: '水杯新品短片 · 可编辑草稿', outputFingerprint: 'demo-output-20260723', handoffMode: 'manual_open_required', desktopOpened: false, manualOpenHint: '请在剪映专业版首页的本地草稿列表中打开该标签。' } }, recoveryOptions: /** @type {(keyof typeof recoveryDefinitions)[]} */ (Object.keys(recoveryDefinitions)).map(safeError) },
  tasks: [{ id: 'task-analysis-demo', type: 'analysis', label: '素材分析', state: 'running', progressPercent: 82, detail: '已分析 5 / 6 个素材', error: null }, { id: 'task-jy002-demo', type: 'jianying_export', label: '剪映草稿导出', state: 'ready_to_open', progressPercent: 100, detail: '草稿已完成结构校验', error: null }],
})

const emptyPreview = () => ({
  status: 'not_started',
  resourceId: null,
  durationSeconds: null,
  updatedAt: null,
})
const emptyEditor = () => ({
  timelineId: null,
  timelineRevision: null,
})
const emptyDelivery = () => ({
  finalVideo: null,
  template: { status: 'not_started', name: null, version: null, reason: null },
  preflight: { status: 'not_started', checkedAt: null, checks: [] },
  exportJob: null,
  recoveryOptions: [],
})
/** @param {any} project */
const invalidateStoryboardOutputs = (project) => {
  project.editor = emptyEditor()
  project.preview = emptyPreview()
  project.delivery = emptyDelivery()
}
/** @param {any} project */
const projectHasBoundEditorTimeline = (project) =>
  Boolean(
    (project.editor?.timelineId && Number.isInteger(project.editor?.timelineRevision)) ||
    (project.preview?.timelineId && Number.isInteger(project.preview?.timelineRevision)),
  )
/**
 * Homepage list cannot call getWithJobs. Delivery may live only in the job
 * store (status=succeeded) while persist.exportJob is still empty.
 * @param {any} project
 * @param {any[]} [jobs]
 */
export const attachDeliveryJobsForListProgress = (project, jobs = []) => {
  const mapped = (Array.isArray(jobs) ? jobs : [])
    .filter((/** @type {any} */ job) =>
      job && ['jianying_draft_export', 'jianying_export'].includes(job.type))
    .map((/** @type {any} */ job) => {
      const raw = job.state ?? job.status
      const terminal = raw === 'succeeded' || raw === 'ready_to_open' ? 'completed' : raw
      return {
        type: job.type,
        state: terminal,
        status: terminal,
        updatedAt: job.updatedAt,
        createdAt: job.createdAt,
      }
    })
  if (mapped.length === 0) return project
  return {
    ...project,
    tasks: [...(Array.isArray(project.tasks) ? project.tasks : []), ...mapped],
  }
}

/**
 * List progress uses persisted project fields plus optional current Jianying
 * jobs. Editor completion is the bound timeline pointer; leftover preview/draft
 * still cannot unlock later cells without that identity. A ready 成片 MP4
 * counts even when previewStatus is preview_degraded (voice+BGM only).
 * Library-only projects complete the materials cell from referencedAssetCount
 * without a local folder grant.
 * @param {any} project
 * @param {any} [materials]
 */
export const computeProjectListProgressPercent = (project, materials = project?.materials) => {
  const storyboardComplete = Boolean(project.storyboard?.sentences?.length) &&
    project.storyboard.sentences.every((/** @type {{selectedCandidateId?: string}} */ sentence) =>
      Boolean(sentence.selectedCandidateId))
  const editorComplete = storyboardComplete && projectHasBoundEditorTimeline(project)
  const authorizedMaterialsComplete = Boolean(materials?.authorized) &&
    materials.total > 0 &&
    materials.analyzed === materials.total &&
    materials.queued === 0 &&
    materials.failed === 0
  const libraryMaterialsComplete = !materials?.authorized &&
    Number.isSafeInteger(materials?.referencedAssetCount) &&
    Number(materials.referencedAssetCount) > 0
  const deliveryJob = project.delivery?.exportJob
  const deliveryTerminal = new Set(['ready_to_open', 'succeeded', 'completed'])
  const latestDeliveryTask = (Array.isArray(project.tasks) ? project.tasks : []).reduce((/** @type {any} */ current, /** @type {any} */ task) => {
    if (!['jianying_draft_export', 'jianying_export'].includes(task?.type)) return current
    const taskTs = Date.parse(task.updatedAt ?? task.createdAt ?? '')
    const currentTs = current ? Date.parse(current.updatedAt ?? current.createdAt ?? '') : Number.NaN
    if (!current) return task
    if (Number.isFinite(taskTs) && Number.isFinite(currentTs)) return taskTs >= currentTs ? task : current
    return task
  }, null)
  const deliveryTaskReady = Boolean(latestDeliveryTask) &&
    deliveryTerminal.has(latestDeliveryTask.state ?? latestDeliveryTask.status)
  return Math.round(([
    authorizedMaterialsComplete || libraryMaterialsComplete,
    Boolean(project.brief?.theme?.trim()) &&
      Boolean(project.brief?.script?.trim()) &&
      Boolean(project.brief?.savedAt),
    storyboardComplete,
    editorComplete,
    editorComplete &&
      project.preview?.status === 'ready' &&
      Boolean(project.preview?.resourceId),
    editorComplete &&
      ((deliveryJob?.state === 'ready_to_open' && Boolean(deliveryJob.result)) || deliveryTaskReady),
  ].filter(Boolean).length * 100) / 6)
}
/** @param {any} project */
const invalidateBriefOutputs = (project) => {
  project.storyboard = null
  invalidateStoryboardOutputs(project)
}
const outputTaskTypes = new Set([
  'storyboard_generation',
  'editor_agent',
  'preview_generation',
  'jianying_draft_export',
  'jianying_export',
  'recovery',
])
/** @param {any} project */
const clearOutputTasks = (project) => {
  project.tasks = project.tasks.filter(
    (/** @type {Record<string, any>} */ task) => !outputTaskTypes.has(task.type),
  )
}

/** @param {string} id @param {any} input @returns {any} */
const emptyProject = (id, input) => {
  const now = timestamp()
  return { id, name: input.name, notes: input.notes || '', status: 'active', currentStage: 'materials', createdAt: now, updatedAt: now, materials: { authorizationId: null, authorized: false, readOnlyConfirmed: false, folderLabel: null, total: 0, analyzed: 0, queued: 0, failed: 0, analysisStatus: 'not_started', lastScanAt: null, assets: [] }, brief: { theme: '', title: '', sellingPoints: [], script: '', style: '', durationSeconds: 30, orientation: 'portrait', voiceover: 'none', voiceId: null, voiceRate: 0, captions: 'auto', packaging: emptyPackaging(), savedAt: null }, templateBinding: null, pendingOutputInvalidation: null, pendingProjectDeletion: null, storyboard: null, editor: emptyEditor(), preview: emptyPreview(), delivery: emptyDelivery(), tasks: [] }
}

export const createSyntheticWorkbenchCapabilities = () => ({
  /** @param {{folderLabel: string}} input */
  async authorizeMaterials(input) {
    const materials = demoProject().materials
    return {
      ...materials,
      authorizationId: 'authorization-synthetic',
      authorized: true,
      readOnlyConfirmed: true,
      folderLabel: input.folderLabel,
      lastScanAt: timestamp(),
    }
  },
  async authorizeBgm() {
    return {
      authorizationId: 'authorization-bgm-synthetic',
      bgmLabel: '已授权本机音频（.mp3）',
    }
  },
  async authorizeReferenceVideo() {
    return {
      authorizationId: 'authorization-reference-video-synthetic',
      label: '已授权本机视频（.mp4）',
    }
  },
  async uploadReferenceVideo() {
    return {
      authorizationId: 'authorization-reference-upload-synthetic',
      label: '已上传参考视频',
    }
  },
  async generateStoryboard() {
    return storyboard()
  },
  /** @param {{projectId: string, project: any}} input */
  async generatePreview(input) {
    return {
      status: 'ready',
      resourceId: `preview-${input.projectId}-synthetic`,
      durationSeconds: Math.max(1, input.project.brief.durationSeconds - 0.8),
      updatedAt: timestamp(),
    }
  },
  /** @param {{projectId: string, durationSeconds: number}} input */
  async finalizeVideo(input) {
    return {
      status: 'ready',
      resourceId: `final-${input.projectId}-synthetic`,
      durationSeconds: input.durationSeconds,
      updatedAt: timestamp(),
    }
  },
  /** @param {{project: any}} input */
  async preflight(input) {
    if (input.project.brief.voiceover === 'required') {
      throw new WorkbenchOperationError('JY002_VOICEOVER_AUDIO_MISSING', 409)
    }
    return {
      template: { status: 'confirmed', name: '轻量产品展示 · 竖屏', version: 'tpl002-synthetic-v1', reason: '合成 fixture 与当前时长、画幅和字幕节奏兼容。' },
      preflight: { status: 'ready', checkedAt: timestamp(), checks: [{ label: '分镜完整性', status: 'pass' }, { label: '模板能力', status: 'pass' }, { label: '素材绑定', status: 'pass' }, { label: '配音音频', status: 'pass' }] },
    }
  },
  /** @param {{projectId: string, project: any, jobId: string}} input */
  async exportDraft(input) {
    return {
      id: input.jobId,
      state: 'ready_to_open',
      progressPercent: 100,
      recoverable: false,
      error: null,
      result: { draftLabel: `${input.project.name} · 可编辑草稿`, outputFingerprint: `synthetic-output-${input.projectId}`, handoffMode: 'manual_open_required', desktopOpened: false, manualOpenHint: '请在剪映专业版首页的本地草稿列表中打开该标签。' },
    }
  },
  /** @param {{code: string, projectId: string, project: any, taskId: string}} input */
  async recoverDelivery(input) {
    /** @type {Record<string, string>} */
    const details = {
      JY002_TEMPLATE_CAPABILITY_UNSUPPORTED: '已请求本地宿主重新选择兼容模板。',
      JY002_PATH_PERMISSION_DENIED: '已请求本地宿主重新授权输出目录。',
      JY002_DESKTOP_VERSION_UNSUPPORTED: '已请求本地宿主显示受支持版本与手动打开说明。',
      JY002_OUTPUT_CONFLICT: '已请求本地宿主选择新的输出目标。',
      JY002_DRAFT_STRUCTURE_INVALID: '已请求本地宿主重新预检、构建并校验草稿。',
    }
    const detail = details[input.code]
    if (!detail) throw new WorkbenchOperationError('WORKBENCH_ACTION_INVALID', 400)
    if (input.code !== 'JY002_DRAFT_STRUCTURE_INVALID') return { detail }
    return {
      detail,
      preflight: { ...input.project.delivery.preflight, status: 'ready', checkedAt: timestamp() },
      exportJob: {
        id: `${input.taskId}-export`,
        state: 'ready_to_open',
        progressPercent: 100,
        recoverable: false,
        error: null,
        result: { draftLabel: `${input.project.name} · 可编辑草稿`, outputFingerprint: `synthetic-recovery-${input.projectId}`, handoffMode: 'manual_open_required', desktopOpened: false, manualOpenHint: '请在剪映专业版首页的本地草稿列表中打开该标签。' },
      },
    }
  },
})

/**
 * Coordinates public workbench state. Trusted local capabilities are injected;
 * missing capabilities fail closed instead of fabricating successful outputs.
 * @param {{seedDemo?: boolean, synthetic?: boolean, capabilities?: Record<string, Function>, repositories?: {projectRepository: any, authorizationRepository?: any, taskRepository: any}, jobCoordinator?: Record<string, Function>, referenceTemplateRepository?: Record<string, Function>, reusableTemplateLibraryService?: Record<string, Function>, materialLibraryService?: Record<string, Function>, materialReviewOverlay?: {apply: (projectId: string, project: any) => any, save: (input: any) => Promise<any>}, projectTemplateAbPreviewStore?: Record<string, Function>, bgmLibrary?: {getBackingAuthorizationId?: Function}, resolveTemplateAudioPath?: Function, authorizeProjectBgmFromPath?: Function}} [options]
 */
export const createWorkbenchRuntime = ({
  seedDemo = false,
  synthetic = seedDemo,
  capabilities = {},
  repositories,
  jobCoordinator,
  referenceTemplateRepository,
  reusableTemplateLibraryService,
  materialLibraryService,
  materialReviewOverlay,
  projectTemplateAbPreviewStore,
  bgmLibrary,
  resolveTemplateAudioPath,
  authorizeProjectBgmFromPath,
} = {}) => {
  /** @type {any[]} */
  const persistedProjects = repositories?.projectRepository.list() ?? []
  /** @type {[string, any][]} */
  const restoredEntries = []
  if (repositories) {
    for (const project of persistedProjects) {
      const tasks = repositories.taskRepository
        .listByProject(project.id)
        .map((/** @type {any} */ task) => {
          const publicTask = clone(task)
          delete publicTask.projectId
          delete publicTask.position
          return publicTask
        })
      restoredEntries.push([project.id, {
        ...project,
        templateBinding: clone(project.templateBinding ?? null),
        pendingProjectDeletion: clone(project.pendingProjectDeletion ?? null),
        tasks,
      }])
    }
  }
  /** @type {Map<string, any>} */
  const projects = new Map(
    seedDemo
      ? [['project-demo', demoProject()]]
      : restoredEntries,
  )
  /** @type {Map<string, symbol>} */
  const projectMutationLocks = new Map()
  /** @type {Map<string, number>} */
  const activeProjectMutations = new Map()
  /** @param {any} project */
  const hydrateProject = (project) => {
    if (!project) return null
    const tasks = repositories
      ? repositories.taskRepository.listByProject(project.id).map((/** @type {any} */ task) => clone(task))
      : clone(project.tasks ?? [])
    const hydrated = {
      ...clone(project),
      createdAt: project.createdAt ?? project.updatedAt,
      templateBinding: clone(project.templateBinding ?? null),
      pendingProjectDeletion: clone(project.pendingProjectDeletion ?? null),
      tasks,
    }
    projects.set(project.id, hydrated)
    return hydrated
  }
  /** @param {string} id */
  const readProject = (id) => {
    if (!repositories) return projects.get(id) ?? null
    const persisted = repositories.projectRepository.get(id)
    if (!persisted) {
      projects.delete(id)
      return null
    }
    return hydrateProject(persisted)
  }
  /** @returns {any[]} */
  const readProjects = () => {
    if (!repositories) return [...projects.values()]
    const persisted = repositories.projectRepository.list()
    const liveIds = new Set(persisted.map((/** @type {any} */ project) => project.id))
    for (const id of projects.keys()) {
      if (!liveIds.has(id)) projects.delete(id)
    }
    return persisted.map(hydrateProject)
  }
  const requireJobCoordinator = () => {
    if (
      !jobCoordinator ||
      ['createJob', 'getJob', 'listJobs', 'cancelJob', 'retryJob']
        .some((method) => typeof jobCoordinator[method] !== 'function')
    ) {
      throw new WorkbenchOperationError('WORKBENCH_JOB_COORDINATOR_UNAVAILABLE')
    }
    return jobCoordinator
  }
  let projectNumber = 1
  let taskNumber = 1
  /** @type {Map<string, any>} */
  const syntheticJobs = new Map()
  /** @type {Map<string, string>} */
  const syntheticJobKeys = new Map()
  /** @type {Map<string, any>} */
  const syntheticEditorTimelines = new Map()

  /** @param {any} project @returns {any} */
  const createSyntheticEditorTimeline = (project) => {
    const existing = syntheticEditorTimelines.get(project.id)
    if (existing) return clone(existing)
    const selected = project.storyboard?.sentences?.filter((/** @type {any} */ sentence) => sentence.selectedCandidateId) ?? []
    if (selected.length === 0) return null
    const shots = selected.map((/** @type {any} */ sentence, /** @type {number} */ index) => {
      const candidate = sentence.candidates?.find((/** @type {any} */ item) => item.id === sentence.selectedCandidateId)
      const startUs = Math.max(0, Math.round(Number(candidate?.start ?? 0) * 1_000_000))
      const durationUs = Math.max(1_000_000, Math.round(Math.max(1, Number(candidate?.end ?? 1) - Number(candidate?.start ?? 0)) * 1_000_000))
      const targetStartUs = index === 0 ? 0 : selected.slice(0, index).reduce((/** @type {number} */ sum, /** @type {any} */ previous) => {
        const previousCandidate = previous.candidates?.find((/** @type {any} */ item) => item.id === previous.selectedCandidateId)
        return sum + Math.max(1_000_000, Math.round(Math.max(1, Number(previousCandidate?.end ?? 1) - Number(previousCandidate?.start ?? 0)) * 1_000_000))
      }, 0)
      const candidateId = String(candidate?.id ?? sentence.selectedCandidateId)
      return {
        order: index + 1,
        shotId: `shot-${project.id}-${index + 1}`,
        assetId: `asset-${candidateId}`,
        sceneId: `scene-${candidateId}`,
        candidateId,
        sourceRange: { startUs, durationUs },
        targetRange: { startUs: targetStartUs, durationUs },
        captions: [String(sentence.text ?? '').slice(0, 240)],
        audioRoles: [],
        transitionOut: { capabilityId: 'transition.none', durationUs: 0 },
      }
    })
    const content = JSON.stringify({ projectId: project.id, shots })
    const contentFingerprint = createHash('sha256').update(content).digest('hex')
    const revisionFingerprint = createHash('sha256').update(`${content}\u0000${timestamp()}`).digest('hex')
    const timeline = {
      timelineId: `timeline-${project.id}`,
      revision: 1,
      contentFingerprint,
      revisionFingerprint,
      status: 'finalized',
      durationUs: Math.max(1_000_000, shots.reduce((/** @type {number} */ sum, /** @type {any} */ shot) => sum + shot.targetRange.durationUs, 0)),
      createdAt: timestamp(),
      sourceKind: 'agent',
      shotCount: shots.length,
      shots,
    }
    syntheticEditorTimelines.set(project.id, timeline)
    return clone(timeline)
  }
  /** @param {any} project @param {any | null} [expected] */
  const persist = (project, expected = null) => {
    if (!repositories) return
    const persisted = clone(project)
    delete persisted.tasks
    if (expected && typeof repositories.projectRepository.saveIfCurrent === 'function') {
      const expectedPersisted = clone(expected)
      delete expectedPersisted.tasks
      const saved = repositories.projectRepository.saveIfCurrent(persisted, expectedPersisted)
      if (!saved) throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
    } else {
      repositories.projectRepository.save(persisted)
    }
    if (
      typeof repositories.taskRepository.listByProject === 'function' &&
      typeof repositories.taskRepository.remove === 'function'
    ) {
      const liveTaskIds = new Set(project.tasks.map((/** @type {any} */ task) => task.id))
      for (const task of repositories.taskRepository.listByProject(project.id)) {
        if (!liveTaskIds.has(task.id)) repositories.taskRepository.remove(task.id)
      }
    }
    for (const [position, task] of project.tasks.entries()) {
      repositories.taskRepository.save({ ...clone(task), projectId: project.id, position })
    }
  }
  if (repositories) {
    const referencedAuthorizationIds = new Set()
    const bgmBackingAuthorizationIds = new Set()
    if (typeof materialLibraryService?.listImportAuthorizationIds === 'function') {
      for (const authorizationId of materialLibraryService.listImportAuthorizationIds()) {
        if (typeof authorizationId === 'string' && authorizationId) referencedAuthorizationIds.add(authorizationId)
      }
    }
    for (const project of projects.values()) {
      if (project.materials.authorizationId) referencedAuthorizationIds.add(project.materials.authorizationId)
      const bgmAuthorizationId = normalizePackaging(project.brief?.packaging).bgmAuthorizationId
      if (bgmAuthorizationId) {
        referencedAuthorizationIds.add(bgmAuthorizationId)
        const backingAuthorizationId = bgmLibrary?.getBackingAuthorizationId?.({
          projectId: project.id,
          trackId: bgmAuthorizationId,
        })
        if (backingAuthorizationId) {
          referencedAuthorizationIds.add(backingAuthorizationId)
          bgmBackingAuthorizationIds.add(backingAuthorizationId)
        }
      }
      const sfxAuthorizationId = normalizePackaging(project.brief?.packaging).sfxAuthorizationId
      if (sfxAuthorizationId) {
        referencedAuthorizationIds.add(sfxAuthorizationId)
        const backingAuthorizationId = bgmLibrary?.getBackingAuthorizationId?.({
          projectId: project.id,
          trackId: sfxAuthorizationId,
        })
        if (backingAuthorizationId) {
          referencedAuthorizationIds.add(backingAuthorizationId)
          bgmBackingAuthorizationIds.add(backingAuthorizationId)
        }
      }
      let changed = false
      for (const task of project.tasks) {
        if (task.state !== 'running') continue
        changed = true
        task.state = 'failed'
        task.detail = 'Gateway 重启时发现任务已中断'
        task.error = {
          code: 'WORKBENCH_TASK_INTERRUPTED',
          title: '任务因 Gateway 重启而中断',
          action: '重新执行此步骤',
          stage: task.type === 'material_authorization' ? 'materials' : project.currentStage,
          recoverable: true,
        }
        if (task.type === 'analysis' && project.materials.analysisStatus === 'analyzing') {
          project.materials.analysisStatus = 'failed'
        }
      }
      if (changed) persist(project)
    }
    if (repositories.authorizationRepository) {
      for (const authorization of repositories.authorizationRepository.list()) {
        if (authorization.status !== 'authorized' ||
            ['bgm', 'voice_reference', 'reusable_template_draft', 'jianying_draft', 'jianying_draft_root'].includes(authorization.purpose)) continue
        if (bgmBackingAuthorizationIds.has(authorization.id)) {
          repositories.authorizationRepository.save({ ...authorization, purpose: 'bgm' })
        } else if (!referencedAuthorizationIds.has(authorization.id)) {
          repositories.authorizationRepository.save({ ...authorization, status: 'orphaned' })
        }
      }
      for (const authorization of repositories.authorizationRepository.list()) {
        if (authorization.status === 'orphaned' && referencedAuthorizationIds.has(authorization.id)) {
          repositories.authorizationRepository.save({ ...authorization, status: 'authorized' })
        }
      }
    }
  }
  /** @param {any} project */
  const reviewedPublicProject = (project) => {
    const result = publicProject(project)
    const status = providerStatus()
    const recordedVersion = result.materials?.analyzerVersion
    const currentVersion = status.analyzerVersion
    // A version mismatch is an expected lifecycle state, not a usable analysis.
    // Do not expose old scene cards as current and wait for a later preview
    // request to discover that the provider will fail closed.
    if (
      result.materials?.analysisStatus === 'ready' &&
      status.available === true &&
      safeLabel(currentVersion, 160) &&
      recordedVersion !== currentVersion
    ) {
      result.materials = {
        ...result.materials,
        analyzed: 0,
        queued: result.materials.total,
        failed: 0,
        analysisStatus: 'stale',
        analysisProgress: null,
        assets: [],
      }
    }
    const overlaid = materialReviewOverlay?.apply(project.id, result) ?? result
    return applyLibraryReferenceCounts(overlaid)
  }

  /** @param {any} project */
  const applyLibraryReferenceCounts = (project) => {
    if (!project?.id || !project.materials || typeof materialLibraryService?.referencedAssetIds !== 'function') {
      return project
    }
    const localIds = new Set(
      (Array.isArray(project.materials.assets) ? project.materials.assets : [])
        .map((/** @type {{id?: string}} */ asset) => asset?.id)
        .filter(Boolean),
    )
    let extra = 0
    for (const assetId of materialLibraryService.referencedAssetIds(project.id)) {
      if (!localIds.has(assetId)) extra += 1
    }
    const total = Number.isSafeInteger(project.materials.total) ? project.materials.total : 0
    const analyzed = Number.isSafeInteger(project.materials.analyzed) ? project.materials.analyzed : 0
    const persistedExtra = Number.isSafeInteger(project.materials.referencedAssetCount)
      ? project.materials.referencedAssetCount
      : 0
    const folderCount = Math.max(Math.max(0, total - persistedExtra), localIds.size)
    const nextTotal = folderCount + extra
    const nextAnalyzed = extra === 0
      ? analyzed
      : Math.max(analyzed, Math.min(nextTotal, analyzed + extra))
    if (
      nextTotal === total &&
      nextAnalyzed === analyzed &&
      project.materials.referencedAssetCount === extra
    ) {
      return project
    }
    return {
      ...project,
      materials: {
        ...project.materials,
        total: nextTotal,
        analyzed: nextAnalyzed,
        referencedAssetCount: extra,
      },
    }
  }
  /** @param {unknown} materials */
  const hasLibraryMaterialReferences = (materials) =>
    isRecord(materials) &&
    Number.isSafeInteger(materials.referencedAssetCount) &&
    Number(materials.referencedAssetCount) > 0
  /** @param {unknown} materials */
  const hasUsableWorkbenchMaterials = (materials) =>
    (
      isRecord(materials) &&
      materials.authorized === true &&
      materials.analysisStatus === 'ready' &&
      safeLabel(materials.authorizationId, 160)
    ) || hasLibraryMaterialReferences(materials)
  /**
   * Library-reference projects have no local folder authorization. Search must
   * use the source authorizations that already analyzed those assets.
   * @param {string} projectId
   * @param {Record<string, any> | null | undefined} materials
   */
  const collectWorkbenchSearchScopes = async (projectId, materials) => {
    /** @type {Array<{projectId: string, authorizationId: string}>} */
    const scopes = []
    if (safeLabel(materials?.authorizationId, 160)) {
      scopes.push({
        projectId,
        authorizationId: materials.authorizationId,
      })
    }
    if (typeof materialLibraryService?.listStoryboardSearchScopes === 'function') {
      try {
        const extra = await materialLibraryService.listStoryboardSearchScopes(projectId)
        if (Array.isArray(extra)) {
          for (const scope of extra.slice(0, 64)) {
            if (!safeLabel(scope?.projectId, 160) || !safeLabel(scope?.authorizationId, 160)) continue
            if (scopes.some((existing) =>
              existing.projectId === scope.projectId &&
              existing.authorizationId === scope.authorizationId)) continue
            scopes.push({
              projectId: scope.projectId,
              authorizationId: scope.authorizationId,
            })
          }
        }
      } catch {
        // Optional library scopes must not block the project's own search.
      }
    }
    return scopes
  }
  /** @param {string} projectId */
  const referencedAssetIdSet = (projectId) => new Set(
    typeof materialLibraryService?.referencedAssetIds === 'function'
      ? materialLibraryService.referencedAssetIds(projectId).filter(Boolean)
      : [],
  )
  /**
   * @param {Record<string, any>} scope
   * @param {Record<string, any>} candidate
   * @param {string | null | undefined} localAuthorizationId
   * @param {Set<string>} allowedAssetIds
   */
  const isProjectScopedCandidate = (scope, candidate, localAuthorizationId, allowedAssetIds) => {
    if (allowedAssetIds.size === 0) return true
    if (scope.authorizationId === localAuthorizationId) return true
    return allowedAssetIds.has(candidate.assetId)
  }
  /** @param {string} id */
  const get = (id) => { const project = readProject(id); return project ? reviewedPublicProject(project) : null }
  /** @param {string} id @param {symbol | null} [owner] */
  const assertProjectLockAvailable = (id, owner = null) => {
    const currentOwner = projectMutationLocks.get(id)
    if (currentOwner && currentOwner !== owner) {
      throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
    }
  }
  /** @param {string} id @param {symbol | null} [owner] */
  const assertProjectMutationAvailable = (id, owner = null) => {
    assertProjectLockAvailable(id, owner)
    if (!projectMutationLocks.has(id) && readProject(id)?.pendingProjectDeletion) {
      throw new WorkbenchOperationError('WORKBENCH_PROJECT_DELETE_PENDING', 409)
    }
  }
  /** @param {string} id */
  const assertProjectDeletionAvailable = (id) => {
    assertProjectLockAvailable(id)
    if ((activeProjectMutations.get(id) ?? 0) > 0) {
      throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
    }
  }
  /** @param {(projectId: string, ...args: any[]) => Promise<any>} operation */
  const withActiveProjectMutation = (operation) => {
    /** @param {string} projectId @param {...any} args */
    return async function activeProjectMutation(projectId, ...args) {
      assertProjectMutationAvailable(projectId)
      activeProjectMutations.set(projectId, (activeProjectMutations.get(projectId) ?? 0) + 1)
      try {
        return await operation(projectId, ...args)
      } finally {
        const remaining = (activeProjectMutations.get(projectId) ?? 1) - 1
        if (remaining > 0) activeProjectMutations.set(projectId, remaining)
        else activeProjectMutations.delete(projectId)
      }
    }
  }
  /** @param {string} id @param {(project: any) => void} callback @param {symbol | null} [owner] */
  const update = (id, callback, owner = null) => {
    assertProjectMutationAvailable(id, owner)
    const current = readProject(id)
    if (!current) return null
    const project = clone(current)
    callback(project)
    const now = timestamp()
    project.updatedAt = Date.parse(now) > Date.parse(current.updatedAt)
      ? now
      : new Date(Date.parse(current.updatedAt) + 1).toISOString()
    persist(project, current)
    projects.set(id, project)
    return publicProject(project)
  }
  /** @param {string} id @param {string} expectedUpdatedAt @param {(project: any) => void} callback @param {symbol | null} [owner] */
  const updateIfCurrent = (id, expectedUpdatedAt, callback, owner = null) => {
    assertProjectMutationAvailable(id, owner)
    const current = readProject(id)
    if (!current) return null
    if (current.updatedAt !== expectedUpdatedAt) {
      throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
    }
    return update(id, callback, owner)
  }
  /** @param {any} project */
  const deletePreviewBeforeInvalidation = async (project) => {
    const resourceIds = [
      project?.preview?.resourceId,
      project?.delivery?.finalVideo?.resourceId,
    ].filter(Boolean)
    if (resourceIds.length === 0 || synthetic) return
    if (typeof capabilities.deletePreviewResource !== 'function') {
      throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_UNAVAILABLE', 503)
    }
    for (const resourceId of resourceIds) {
      const deleted = await capabilities.deletePreviewResource({
        projectId: project.id,
        resourceId,
      })
      if (deleted !== true) {
        throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_FAILED', 500)
      }
    }
  }
  /** @param {any} project */
  const stageOutputCleanup = (project) => {
    const resourceIds = new Set([
      ...(project.pendingOutputInvalidation?.resourceIds ?? []),
      project.preview?.resourceId,
      project.delivery?.finalVideo?.resourceId,
    ].filter(Boolean))
    project.pendingOutputInvalidation = {
      resourceIds: [...resourceIds],
      jobsPending: true,
      createdAt: project.pendingOutputInvalidation?.createdAt ?? timestamp(),
    }
  }
  /** @param {any} project */
  const stageProjectOutputInvalidation = (project) => {
    stageOutputCleanup(project)
    invalidateBriefOutputs(project)
    clearOutputTasks(project)
  }
  /** @param {any} project */
  const stageStoryboardOutputInvalidation = (project) => {
    stageOutputCleanup(project)
    invalidateStoryboardOutputs(project)
  }

  /**
   * Drains a persisted invalidation plan. Every completed step is persisted so
   * the same request or a later brief save can safely resume after failure.
   * @param {string} projectId
   * @param {symbol} owner
   */
  const drainProjectOutputInvalidation = async (projectId, owner) => {
    let project = readProject(projectId)
    while (project?.pendingOutputInvalidation?.resourceIds?.length > 0) {
      const resourceId = project.pendingOutputInvalidation.resourceIds[0]
      if (!synthetic) {
        if (typeof capabilities.deletePreviewResource !== 'function') {
          throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_UNAVAILABLE', 503)
        }
        const deleted = await capabilities.deletePreviewResource({ projectId, resourceId })
        if (deleted !== true) {
          throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_FAILED', 500)
        }
      }
      update(projectId, (current) => {
        if (!current.pendingOutputInvalidation) return
        current.pendingOutputInvalidation.resourceIds =
          current.pendingOutputInvalidation.resourceIds.filter(
            (/** @type {string} */ candidate) => candidate !== resourceId,
          )
      }, owner)
      project = readProject(projectId)
    }
    if (project?.pendingOutputInvalidation?.jobsPending) {
      if (typeof jobCoordinator?.invalidateProjectOutputs === 'function') {
        await jobCoordinator.invalidateProjectOutputs(projectId, {
          createdBefore: project.pendingOutputInvalidation.createdAt,
        })
      }
      update(projectId, (current) => {
        if (current.pendingOutputInvalidation) {
          current.pendingOutputInvalidation.jobsPending = false
        }
      }, owner)
      project = readProject(projectId)
    }
    if (project?.pendingOutputInvalidation) {
      return update(projectId, (current) => {
        current.pendingOutputInvalidation = null
      }, owner)
    }
    return project ? publicProject(project) : null
  }

  /** @param {string} projectId */
  const resumeProjectOutputInvalidation = async (projectId) => {
    assertProjectMutationAvailable(projectId)
    const project = readProject(projectId)
    if (!project) return null
    if (!project.pendingOutputInvalidation) return publicProject(project)
    const owner = Symbol(projectId)
    projectMutationLocks.set(projectId, owner)
    try {
      return await drainProjectOutputInvalidation(projectId, owner)
    } finally {
      if (projectMutationLocks.get(projectId) === owner) {
        projectMutationLocks.delete(projectId)
      }
    }
  }
  /**
   * Serializes one destructive output invalidation with its project CAS. The
   * project state is committed first so stale or failed persistence can never
   * delete resources or cancel jobs belonging to the still-current project.
   * @param {string} projectId
   * @param {string} expectedUpdatedAt
   * @param {(project: any) => void} callback
   * @param {symbol | null} [existingOwner]
   */
  const updateTemplateBinding = async (
    projectId,
    expectedUpdatedAt,
    callback,
    existingOwner = null,
  ) => {
    assertProjectMutationAvailable(projectId, existingOwner)
    const project = readProject(projectId)
    if (!project) return null
    if (project.updatedAt !== expectedUpdatedAt) {
      throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
    }
    const owner = existingOwner ?? Symbol(projectId)
    if (!existingOwner) projectMutationLocks.set(projectId, owner)
    try {
      updateIfCurrent(projectId, expectedUpdatedAt, (current) => {
        callback(current)
        stageProjectOutputInvalidation(current)
      }, owner)
      return await drainProjectOutputInvalidation(projectId, owner)
    } finally {
      if (projectMutationLocks.get(projectId) === owner) {
        projectMutationLocks.delete(projectId)
      }
    }
  }
  /** @param {any} project @param {any} materials @param {any[]} [jobs] */
  const summarizeListedProject = (project, materials, jobs = []) => ({
    id: project.id,
    name: project.name,
    status: project.status,
    currentStage: project.currentStage,
    createdAt: project.createdAt ?? project.updatedAt,
    updatedAt: project.updatedAt,
    materials: {
      authorized: materials.authorized,
      total: materials.total,
      analyzed: materials.analyzed,
      failed: materials.failed,
      analysisStatus: materials.analysisStatus,
      ...(Number.isSafeInteger(materials.referencedAssetCount)
        ? { referencedAssetCount: materials.referencedAssetCount }
        : {}),
    },
    progressPercent: computeProjectListProgressPercent(
      attachDeliveryJobsForListProgress(project, jobs),
      materials,
    ),
    blockingCount: materials.failed,
  })
  const list = () => readProjects().map((project) => {
    const reviewed = reviewedPublicProject(project)
    return summarizeListedProject(project, reviewed.materials)
  })
  const listWithDeliveryJobs = async () => {
    const records = readProjects()
    let jobs = []
    if (typeof jobCoordinator?.listJobsForProjects === 'function') {
      try {
        jobs = await jobCoordinator.listJobsForProjects(records.map((project) => project.id))
      } catch {
        jobs = []
      }
    }
    /** @type {Map<string, any[]>} */
    const jobsByProject = new Map()
    for (const job of Array.isArray(jobs) ? jobs : []) {
      if (!job?.projectId || typeof job.projectId !== 'string') continue
      const bucket = jobsByProject.get(job.projectId) ?? []
      bucket.push(job)
      jobsByProject.set(job.projectId, bucket)
    }
    return records.map((project) => {
      const reviewed = reviewedPublicProject(project)
      return summarizeListedProject(project, reviewed.materials, jobsByProject.get(project.id) ?? [])
    })
  }
  const listMaterialLibrary = /** @param {Record<string, unknown>} input */ async (input) => {
    void ensureWindowsNativePickerHost()
    return materialLibraryService
      ? materialLibraryService.listAssets(input)
      : { schema_version: 1, assets: [], preferences: { favoriteAssetIds: [], favoriteSceneRefs: [], collections: [], lastViewedAt: {}, usageCounts: {} }, folders: [], counts: { all: 0, ready: 0, analyzing: 0, queued: 0, failed: 0 } }
  }
  const getMaterialLibraryAsset = /** @param {string} assetId */ async (assetId) => materialLibraryService
    ? materialLibraryService.getAsset(assetId)
    : null
  const saveMaterialLibraryPreferences = /** @param {Record<string, unknown>} preferences */ async (preferences) => materialLibraryService
    ? materialLibraryService.savePreferences(preferences)
    : { schema_version: 1, preferences }
  const addMaterialLibraryReference = /** @param {string} projectId @param {Record<string, unknown>} input */ async (projectId, input) => materialLibraryService
    ? materialLibraryService.addReference(projectId, input)
    : null
  const addMaterialLibraryReferences = /** @param {string} projectId @param {Record<string, unknown>} input */ async (projectId, input) => materialLibraryService
    ? materialLibraryService.addReferences(projectId, input)
    : null
  const getMaterialLibraryReferenceState = /** @param {string} projectId */ async (projectId) => materialLibraryService
    ? materialLibraryService.getProjectReferenceState(projectId)
    : { schema_version: 1, referenceCount: 0, availableCount: 0, references: [], timeline: null }
  const importMaterialLibrary = /** @param {Record<string, unknown>} input */ async (input) => materialLibraryService
    ? materialLibraryService.importMaterials(input)
    : null
  const listMaterialLibraryImportJobs = async () => materialLibraryService
    ? materialLibraryService.listImportJobs()
    : { schema_version: 1, jobs: [] }
  const cancelMaterialLibraryImportJob = /** @param {string} jobId */ async (jobId) => materialLibraryService
    ? materialLibraryService.cancelImportJob(jobId)
    : null
  const retryMaterialLibraryImportJob = /** @param {string} jobId */ async (jobId) => materialLibraryService
    ? materialLibraryService.retryImportJob(jobId)
    : null
  /** @param {string} jobId */
  const dismissMaterialLibraryImportJob = async (jobId) => materialLibraryService
    ? materialLibraryService.dismissImportJob(jobId)
    : null
  /** @param {string} projectId @param {string} assetId @param {string} sceneId @param {any} input */
  const reviewMaterialScene = async (projectId, assetId, sceneId, input) => {
    if (!materialReviewOverlay?.save) throw new WorkbenchOperationError('MATERIAL_REVIEW_UNAVAILABLE', 503)
    const owner = Symbol(projectId)
    assertProjectMutationAvailable(projectId)
    projectMutationLocks.set(projectId, owner)
    try {
      const project = readProject(projectId)
      const asset = project?.materials?.assets?.find((/** @type {any} */ entry) => entry?.id === assetId)
      const scene = asset?.scenes?.find((/** @type {any} */ entry) => entry?.id === sceneId)
      if (!project || !asset || !scene) throw new WorkbenchOperationError('MATERIAL_REVIEW_SCENE_NOT_FOUND', 404)
      if (input.status === 'unavailable') {
        update(projectId, (current) => {
          stageProjectOutputInvalidation(current)
        }, owner)
      }
      try {
        await materialReviewOverlay.save({
          projectId,
          assetId,
          sceneId,
          status: input.status,
          correction: input.correction,
        })
      } catch (error) {
        if (input.status === 'unavailable') {
          await drainProjectOutputInvalidation(projectId, owner).catch(() => {})
        }
        throw error
      }
      if (input.status === 'unavailable') {
        await drainProjectOutputInvalidation(projectId, owner)
      }
      return reviewedPublicProject(readProject(projectId) ?? project)
    } finally {
      if (projectMutationLocks.get(projectId) === owner) projectMutationLocks.delete(projectId)
    }
  }
  /** @param {any} input */
  const create = (input) => { if (!input || !safeLabel(input.name, 100) || (input.notes !== undefined && !safeText(input.notes, 500))) return null; const project = emptyProject(repositories ? randomUUID() : 'project-new-' + projectNumber++, { name: input.name.trim(), notes: typeof input.notes === 'string' ? input.notes : '' }); persist(project); projects.set(project.id, project); return publicProject(project) }
  /** @param {string} id @param {any} input */
  const authorize = async (id, input) => {
    assertProjectMutationAvailable(id)
    if (
      !input ||
      input.readOnlyConfirmed !== true ||
      !safeLabel(input.folderLabel, 100) ||
      !readProject(id)
    ) return null
    if (typeof capabilities.authorizeMaterials !== 'function') throw new WorkbenchOperationError('WORKBENCH_MATERIAL_AUTHORIZATION_UNAVAILABLE')
    const taskId = repositories ? randomUUID() : 'task-authorization-' + taskNumber++
    update(id, (project) => {
      project.tasks.unshift({ id: taskId, type: 'material_authorization', label: '素材文件夹授权', state: 'running', progressPercent: 0, detail: '正在确认所选素材文件夹的只读授权', error: null })
    })
    try {
      const materials = assertSafeCapabilityResult(await capabilities.authorizeMaterials({
        projectId: id,
        folderLabel: input.folderLabel.trim(),
        readOnlyConfirmed: true,
        ...(input.sourceType === 'file' || input.sourceType === 'folder' || input.sourceType === 'auto'
          ? { sourceType: input.sourceType }
          : {}),
        ...(safeLabel(input.sessionId, 160) && safeLabel(input.nodeId, 160)
          ? { sessionId: input.sessionId, nodeId: input.nodeId }
          : {}),
      }))
      if (!materials || !safeLabel(materials.authorizationId, 160) || materials.authorized !== true || materials.readOnlyConfirmed !== true || !safeLabel(materials.folderLabel, 100) || !Array.isArray(materials.assets)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      await deletePreviewBeforeInvalidation(readProject(id))
      return update(id, (project) => {
        project.materials = clone(materials)
        invalidateBriefOutputs(project)
        project.currentStage = 'materials'
        const task = project.tasks.find((/** @type {any} */ entry) => entry.id === taskId)
        task.state = 'completed'
        task.progressPercent = 100
        task.detail = materials.total > 0
          ? `已授权「${materials.folderLabel}」，发现 ${materials.total} 个视频，可继续只读分析`
          : `已授权「${materials.folderLabel}」，未发现可分析视频`
      })
    } catch (error) {
      const localError = error && typeof error === 'object'
        ? /** @type {{code?: unknown, status?: unknown}} */ (error)
        : {}
      const code = typeof localError.code === 'string' ? localError.code : 'WORKBENCH_MATERIAL_AUTHORIZATION_FAILED'
      update(id, (project) => {
        const task = project.tasks.find((/** @type {any} */ entry) => entry.id === taskId)
        task.state = 'failed'
        task.detail = code === 'LOCAL_FOLDER_SELECTION_CANCELLED'
          ? '已取消文件夹选择；这不是分析失败，可重新选择'
          : '素材授权未完成（取消或失败），未修改原素材'
        task.error = {
          code,
          ...(localAuthorizationErrors[/** @type {keyof typeof localAuthorizationErrors} */ (code)] ?? {
            title: '素材授权未完成',
            action: '重新选择素材文件夹',
          }),
          stage: 'materials',
          recoverable: true,
        }
      })
      if (error instanceof WorkbenchOperationError) throw error
      throw new WorkbenchOperationError(code, Number.isInteger(localError.status) ? /** @type {number} */ (localError.status) : 503)
    }
  }
  const providerStatus = () => {
    if (typeof capabilities.getStatus !== 'function') {
      return { available: false, state: 'blocked', code: materialAnalysisProviderErrorCodes.unavailable }
    }
    const status = assertSafeCapabilityResult(capabilities.getStatus())
    if (!validMaterialAnalysisProviderStatus(status)) {
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    return clone(status)
  }
  /** @param {string} id @param {{idempotencyKey?: string, assetId?: string}} [options] */
  const analyze = async (id, options = {}) => {
    assertProjectMutationAvailable(id)
    if (!synthetic) {
      return requireJobCoordinator().createJob({
        projectId: id,
        type: 'material_analysis',
        ...(safeLabel(options.assetId, 160) ? { assetId: options.assetId } : {}),
        idempotencyKey: options.idempotencyKey ??
          createHash('sha256').update(`${id}\u0000material_analysis\u0000${options.assetId ?? 'all'}`).digest('hex'),
      })
    }
    const project = readProject(id)
    if (!project?.materials.authorized || !safeLabel(project.materials.authorizationId, 160)) return null
    const authorizationId = project.materials.authorizationId
    if (typeof capabilities.analyzeMaterials !== 'function') {
      throw new WorkbenchOperationError(materialAnalysisProviderErrorCodes.analysisUnavailable)
    }
    const taskId = repositories ? randomUUID() : 'task-analysis-' + taskNumber++
    update(id, (current) => {
      current.tasks.unshift({
        id: taskId,
        type: 'analysis',
        label: '素材分析',
        state: 'running',
        progressPercent: 0,
        detail: '素材分析引擎正在只读扫描、分析和索引素材',
        error: null,
      })
      current.materials.analysisStatus = 'analyzing'
    })
    try {
      const materials = assertSafeCapabilityResult(await capabilities.analyzeMaterials({
        authorizationId,
        projectId: id,
        ...(safeLabel(options.assetId, 160) ? { assetId: options.assetId } : {}),
      }))
      if (!validAnalyzedMaterials(materials, authorizationId)) {
        throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      }
      if (readProject(id)?.materials.authorizationId !== authorizationId) {
        throw new WorkbenchOperationError('WORKBENCH_ANALYSIS_SUPERSEDED', 409)
      }
      return update(id, (current) => {
        const materialsChanged =
          materialContentFingerprint(current.materials) !== materialContentFingerprint(materials)
        current.materials = clone(materials)
        if (materialsChanged) invalidateBriefOutputs(current)
        current.currentStage = 'materials'
        const task = current.tasks.find((/** @type {any} */ entry) => entry.id === taskId)
        task.state = 'completed'
        task.progressPercent = 100
        task.detail = `已只读分析 ${materials.analyzed} 个素材`
      })
    } catch (error) {
      const localError = error && typeof error === 'object'
        ? /** @type {{code?: unknown, status?: unknown, detail?: unknown}} */ (error)
        : {}
      const code = typeof localError.code === 'string' ? localError.code : materialAnalysisProviderErrorCodes.analysisFailed
      const diagnosticDetail = typeof localError.detail === 'string' && localError.detail.length > 0
        ? localError.detail
        : null
      if (
        code === 'WORKBENCH_ANALYSIS_SUPERSEDED' ||
        readProject(id)?.materials.authorizationId !== authorizationId
      ) {
        update(id, (current) => {
          const task = current.tasks.find((/** @type {any} */ entry) => entry.id === taskId)
          if (task) {
            task.state = 'cancelled'
            task.detail = '素材授权已更新，已丢弃旧授权的分析结果'
            task.error = null
          }
        })
        if (code === 'WORKBENCH_ANALYSIS_SUPERSEDED' && error instanceof WorkbenchOperationError) {
          throw error
        }
        throw new WorkbenchOperationError('WORKBENCH_ANALYSIS_SUPERSEDED', 409)
      }
      update(id, (current) => {
        current.materials.analysisStatus = 'failed'
        const task = current.tasks.find((/** @type {any} */ entry) => entry.id === taskId)
        task.state = 'failed'
        task.detail = diagnosticDetail
          ? `素材分析未完成（${code}）：${diagnosticDetail}。原素材未修改`
          : '素材分析未完成，原素材未修改'
        task.error = {
          code,
          title: '素材分析未完成',
          action: '检查分析引擎、依赖和服务状态后重试',
          stage: 'materials',
          recoverable: true,
          ...(diagnosticDetail ? { detail: diagnosticDetail } : {}),
        }
      })
      if (error instanceof WorkbenchOperationError) throw error
      throw new WorkbenchOperationError(code, Number.isInteger(localError.status) ? /** @type {number} */ (localError.status) : 503)
    }
  }
  /** @param {string} id @param {any} input */
  const search = async (id, input) => {
    const project = readProject(id)
    if (
      !hasUsableWorkbenchMaterials(project?.materials) ||
      !input ||
      !safeText(input.query, 8000) ||
      !input.query.trim()
    ) {
      return null
    }
    if (typeof capabilities.searchCandidates !== 'function') {
      throw new WorkbenchOperationError(materialAnalysisProviderErrorCodes.searchUnavailable)
    }
    const scopes = await collectWorkbenchSearchScopes(id, project.materials)
    if (scopes.length === 0) return null
    const allowedAssetIds = referencedAssetIdSet(id)
    const localAuthorizationId = safeLabel(project.materials.authorizationId, 160)
      ? project.materials.authorizationId
      : null
    /** @type {Map<string, Record<string, any>>} */
    const foundById = new Map()
    /** @type {unknown} */
    let primarySearchError = null
    for (const [scopeIndex, scope] of scopes.entries()) {
      try {
        const found = assertSafeCapabilityResult(await capabilities.searchCandidates({
          authorizationId: scope.authorizationId,
          projectId: scope.projectId,
          query: input.query.trim(),
        }))
        if (
          !Array.isArray(found) ||
          found.length > 3 ||
          found.some((candidate) => !validSearchCandidate(candidate))
        ) {
          throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
        }
        for (const candidate of found) {
          if (!isProjectScopedCandidate(scope, candidate, localAuthorizationId, allowedAssetIds)) continue
          const existing = foundById.get(candidate.id)
          if (!existing || candidate.matchScore > existing.matchScore) {
            foundById.set(candidate.id, candidate)
          }
        }
      } catch (error) {
        if (scopeIndex === 0 && !primarySearchError) primarySearchError = error
      }
    }
    if (foundById.size === 0) {
      if (primarySearchError instanceof WorkbenchOperationError) throw primarySearchError
      if (primarySearchError) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
      return []
    }
    return clone([...foundById.values()]
      .sort((left, right) => Number(right.matchScore) - Number(left.matchScore))
      .slice(0, 3))
  }
  /** @param {string} id @param {any} input */
  const saveBrief = async (id, input) => {
    assertProjectMutationAvailable(id)
    if (!input || !isRecord(input)) return null
    const briefInput = { ...input }
    const hasExpectedProjectUpdatedAt = Object.prototype.hasOwnProperty.call(
      briefInput,
      'expectedProjectUpdatedAt',
    )
    const expectedProjectUpdatedAt = briefInput.expectedProjectUpdatedAt
    delete briefInput.expectedProjectUpdatedAt
    delete briefInput.packagingCapabilities
    delete briefInput.savedAt
    if (hasExpectedProjectUpdatedAt && !isTimestamp(expectedProjectUpdatedAt)) return null
    const normalized = normalizeBrief({
      ...briefInput,
      packaging: normalizePackaging(briefInput.packaging),
    })
    const packaging = normalized.packaging
    if (
      !safeText(normalized.theme, 300) ||
      !safeText(normalized.script, 8000) ||
      !safeText(normalized.style || '', 800) ||
      !Number.isInteger(normalized.durationSeconds) ||
      normalized.durationSeconds < 5 ||
      normalized.durationSeconds > 180 ||
      !['portrait', 'landscape', 'square'].includes(normalized.orientation) ||
      !['none', 'required'].includes(normalized.voiceover) ||
      !['none', 'auto'].includes(normalized.captions) ||
      !Array.isArray(normalized.sellingPoints) ||
      normalized.sellingPoints.length > 64 ||
      normalized.sellingPoints.some((/** @type {unknown} */ point) => !safeText(point, 160)) ||
      !validBriefExtensions(normalized) ||
      !validPackaging(packaging) ||
      (normalized.voiceover === 'required' && normalized.voiceId !== null && !isVoiceId(normalized.voiceId)) ||
      (packaging.bgmAuthorizationId !== null && !safeLabel(packaging.bgmAuthorizationId, 160)) ||
      (packaging.bgmLabel !== null && !safeBgmLabel(packaging.bgmLabel, 100)) ||
      (packaging.sfxAuthorizationId !== null && !safeLabel(packaging.sfxAuthorizationId, 160)) ||
      (packaging.sfxLabel !== null && !safeBgmLabel(packaging.sfxLabel, 100))
    ) return null
    assertProjectMutationAvailable(id)
    if (!readProject(id)) return null
    const owner = Symbol(id)
    projectMutationLocks.set(id, owner)
    try {
      if (readProject(id)?.pendingOutputInvalidation) {
        await drainProjectOutputInvalidation(id, owner)
      }
      const project = readProject(id)
      if (!project) return null
      if (
        hasExpectedProjectUpdatedAt &&
        project.updatedAt !== expectedProjectUpdatedAt
      ) {
        throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
      }
      if (
        project.templateBinding &&
        project.templateBinding.orientation !== normalized.orientation
      ) {
        throw new WorkbenchOperationError(
          'WORKBENCH_TEMPLATE_ORIENTATION_INCOMPATIBLE',
          409,
        )
      }
      const nextBrief = {
        ...normalizeBrief(project.brief),
        ...normalized,
        theme: normalized.theme.trim(),
        script: normalized.script.trim(),
        style: (normalized.style || '').trim(),
        title: typeof normalized.title === 'string' ? normalized.title.trim().slice(0, 160) : '',
        sellingPoints: normalized.sellingPoints.map((/** @type {string} */ point) => point.trim()).filter(Boolean),
        packaging,
        savedAt: timestamp(),
      }
      const changed = JSON.stringify({ ...normalizeBrief(project.brief), savedAt: null }) !==
        JSON.stringify({ ...nextBrief, savedAt: null })
      update(id, (current) => {
        if (changed) stageProjectOutputInvalidation(current)
        current.brief = nextBrief
        current.currentStage = 'brief'
      }, owner)
      return changed
        ? await drainProjectOutputInvalidation(id, owner)
        : publicProject(/** @type {any} */ (readProject(id)))
    } finally {
      if (projectMutationLocks.get(id) === owner) projectMutationLocks.delete(id)
    }
  }
  /** @param {string} id @param {any} input */
  const authorizeBgm = async (id, input) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    if (!project || input?.readOnlyConfirmed !== true) return null
    if (typeof capabilities.authorizeBgm !== 'function') throw new WorkbenchOperationError('WORKBENCH_BGM_AUTHORIZATION_UNAVAILABLE')
    const result = assertSafeCapabilityResult(await capabilities.authorizeBgm({
      projectId: id,
      readOnlyConfirmed: true,
      ...(safeLabel(input.sessionId, 160) && safeLabel(input.nodeId, 160)
        ? { sessionId: input.sessionId, nodeId: input.nodeId }
        : {}),
    }))
    if (
      !result ||
      !safeLabel(result.authorizationId, 160) ||
      !safeBgmLabel(result.bgmLabel, 100)
    ) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    const nextPackaging = normalizePackaging({
      ...project.brief.packaging,
      bgm: 'local_authorized',
      bgmAuthorizationId: result.authorizationId,
      bgmLabel: result.bgmLabel,
    })
    if (!validPackaging(nextPackaging)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    await deletePreviewBeforeInvalidation(project)
    return update(id, (current) => {
      invalidateBriefOutputs(current)
      current.brief = {
        ...normalizeBrief(current.brief),
        packaging: nextPackaging,
      }
      current.currentStage = 'brief'
    })
  }
  /** @param {string} id @param {{trackId?: unknown}} input */
  const detachAudioTrack = async (id, input) => {
    assertProjectMutationAvailable(id)
    if (!safeLabel(input?.trackId, 160)) return null
    const project = readProject(id)
    if (!project) return null
    const packaging = normalizePackaging(project.brief?.packaging)
    const clearsBgm = packaging.bgmAuthorizationId === input.trackId
    const clearsSfx = packaging.sfxAuthorizationId === input.trackId
    if (!clearsBgm && !clearsSfx) return publicProject(project)
    return saveBrief(id, {
      ...project.brief,
      packaging: {
        ...packaging,
        ...(clearsBgm
          ? { bgm: 'none', bgmAuthorizationId: null, bgmLabel: null }
          : {}),
        ...(clearsSfx
          ? { sfxAuthorizationId: null, sfxLabel: null }
          : {}),
      },
    })
  }
  /** @param {string} id @param {any} input */
  const authorizeReferenceVideo = async (id, input) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    if (!project || input?.readOnlyConfirmed !== true) return null
    if (typeof capabilities.authorizeReferenceVideo !== 'function') throw new WorkbenchOperationError('WORKBENCH_REFERENCE_VIDEO_AUTHORIZATION_UNAVAILABLE')
    const result = assertSafeCapabilityResult(await capabilities.authorizeReferenceVideo({
      projectId: id,
      readOnlyConfirmed: true,
      ...(safeLabel(input.sessionId, 160) && safeLabel(input.nodeId, 160)
        ? { sessionId: input.sessionId, nodeId: input.nodeId }
        : {}),
    }))
    if (
      !result ||
      !safeLabel(result.authorizationId, 160) ||
      !safeReferenceVideoLabel(result.label)
    ) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return result
  }
  /** @param {string} id @param {{file?: any, sessionId?: string, nodeId?: string, readOnlyConfirmed?: boolean}} input */
  const uploadReferenceVideo = async (id, input) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    if (!project) return null
    if (typeof capabilities.uploadReferenceVideo !== 'function') throw new WorkbenchOperationError('WORKBENCH_REFERENCE_VIDEO_UPLOAD_UNAVAILABLE')
    const usesPicker = safeLabel(input?.sessionId, 160) && safeLabel(input?.nodeId, 160) && input?.readOnlyConfirmed === true
    const usesNativeDialog = input?.readOnlyConfirmed === true && !input?.file && !usesPicker
    if (!usesPicker && !input?.file && !usesNativeDialog) return null
    const result = assertSafeCapabilityResult(await capabilities.uploadReferenceVideo(
      usesPicker
        ? {
            projectId: id,
            sessionId: input.sessionId,
            nodeId: input.nodeId,
            readOnlyConfirmed: true,
          }
        : usesNativeDialog
          ? { projectId: id, readOnlyConfirmed: true }
          : { projectId: id, file: input.file },
    ))
    if (
      !result ||
      !safeLabel(result.authorizationId, 160) ||
      !safeReferenceVideoLabel(result.label)
    ) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return result
  }
  /** @param {string} id @param {{idempotencyKey?: string}} [options] */
  const generate = async (id, options = {}) => {
    assertProjectMutationAvailable(id)
    if (!synthetic) {
      return requireJobCoordinator().createJob({
        projectId: id,
        type: 'storyboard_generation',
        idempotencyKey: options.idempotencyKey ??
          createHash('sha256').update(`${id}\u0000storyboard_generation`).digest('hex'),
      })
    }
    const project = readProject(id)
    const hasUsableMaterials = Boolean(project?.materials.authorized) ||
      hasLibraryMaterialReferences(project?.materials)
    if (!hasUsableMaterials || !project.brief.script.trim()) return null
    if (typeof capabilities.generateStoryboard !== 'function') throw new WorkbenchOperationError('WORKBENCH_DIRECTOR_UNAVAILABLE')
    const generatedStoryboard = assertSafeCapabilityResult(await capabilities.generateStoryboard({ projectId: id, project: clone(project) }))
    if (!generatedStoryboard || !Array.isArray(generatedStoryboard.sentences)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    await deletePreviewBeforeInvalidation(project)
    return update(id, (current) => { current.storyboard = clone(generatedStoryboard); invalidateStoryboardOutputs(current); current.currentStage = 'storyboard'; current.tasks.unshift({ id: 'task-storyboard-' + taskNumber++, type: 'storyboard', label: '智能分镜', state: 'completed', progressPercent: 100, detail: 'Director 已返回候选镜头', error: null }) })
  }
  /** @param {string} id @param {string} sentenceId @param {string} candidateId */
  const select = async (id, sentenceId, candidateId) => {
    assertProjectMutationAvailable(id)
    if (!readProject(id)) return null
    const owner = Symbol(id)
    projectMutationLocks.set(id, owner)
    try {
      if (readProject(id)?.pendingOutputInvalidation) {
        await drainProjectOutputInvalidation(id, owner)
      }
      const project = readProject(id)
      const sentence = project?.storyboard?.sentences.find(
        (/** @type {any} */ item) => item.id === sentenceId,
      )
      if (
        !sentence ||
        !sentence.candidates.some((/** @type {any} */ candidate) => candidate.id === candidateId)
      ) return null
      let changed = false
      const selectedProject = update(id, (current) => {
        const selected = current.storyboard?.sentences.find(
          (/** @type {any} */ item) => item.id === sentenceId,
        )
        if (
          !selected ||
          !selected.candidates.some((/** @type {any} */ candidate) => candidate.id === candidateId)
        ) {
          throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
        }
        const sceneAlreadySelected = current.storyboard.sentences.some(
          (/** @type {any} */ item) =>
            item.id !== sentenceId && (() => {
              if (item.selectedCandidateId === candidateId) return true
               const selectedCandidate = item.candidates?.find((/** @type {Record<string, any>} */ candidate) => candidate.id === item.selectedCandidateId)
               const nextCandidate = selected.candidates?.find((/** @type {Record<string, any>} */ candidate) => candidate.id === candidateId)
              if (!selectedCandidate || !nextCandidate) return false
              const sameSource = (selectedCandidate.assetId && nextCandidate.assetId)
                ? selectedCandidate.assetId === nextCandidate.assetId
                : selectedCandidate.assetLabel === nextCandidate.assetLabel
              if (!sameSource) return false
              const left = Math.max(Number(selectedCandidate.start), Number(nextCandidate.start))
              const right = Math.min(Number(selectedCandidate.end), Number(nextCandidate.end))
              const gap = left > right ? left - right : 0
              return Number.isFinite(left) && Number.isFinite(right) && gap <= 2
            })(),
        )
        if (sceneAlreadySelected) {
          throw new WorkbenchOperationError('WORKBENCH_STORYBOARD_SCENE_CONFLICT', 409)
        }
        changed = selected.selectedCandidateId !== candidateId
        if (changed) stageStoryboardOutputInvalidation(current)
        selected.selectedCandidateId = candidateId
        selected.status = 'selected'
      }, owner)
      return changed
        ? await drainProjectOutputInvalidation(id, owner)
        : selectedProject
    } finally {
      if (projectMutationLocks.get(id) === owner) projectMutationLocks.delete(id)
    }
  }
  /** @param {Record<string, any>} candidate */
  const toAttachedStoryboardCandidate = (candidate) => ({
    id: candidate.id,
    assetLabel: candidate.assetLabel,
    start: candidate.start,
    end: candidate.end,
    summary: candidate.summary,
    matchScore: candidate.matchScore,
    reason: candidate.reason,
    rankingSource: 'search_refill',
    ...(candidate.shotPurpose
      ? {
          shotPurpose: candidate.shotPurpose,
          recommendedUse: candidate.recommendedUse,
          confidence: candidate.confidence,
          needsReview: candidate.semanticFallback === true || candidate.needsReview === true,
          semanticFallback: candidate.semanticFallback === true,
        }
      : {}),
  })
  /** @param {string} id @param {{sentenceId?: string, query?: string, replace?: boolean}} input */
  const searchMore = async (id, input) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    const sentenceId = typeof input?.sentenceId === 'string' ? input.sentenceId : ''
    const sentence = project?.storyboard?.sentences.find(
      (/** @type {any} */ item) => item.id === sentenceId,
    )
    if (
      !project?.storyboard ||
      !sentence ||
      !hasUsableWorkbenchMaterials(project.materials)
    ) {
      return null
    }
    const requestedQuery = typeof input?.query === 'string' ? input.query.trim() : ''
    const query = (requestedQuery && safeText(requestedQuery, 8000) ? requestedQuery : sentence.text).trim()
    if (!query) return null
    if (typeof capabilities.searchCandidates !== 'function') {
      throw new WorkbenchOperationError(materialAnalysisProviderErrorCodes.searchUnavailable)
    }
    const scopes = await collectWorkbenchSearchScopes(id, project.materials)
    if (scopes.length === 0) return null
    const allowedAssetIds = referencedAssetIdSet(id)
    const localAuthorizationId = safeLabel(project.materials.authorizationId, 160)
      ? project.materials.authorizationId
      : null
    const searchLimit = allowedAssetIds.size > 0
      ? Math.min(50, Math.max(10, allowedAssetIds.size))
      : 10
    const analyzerLimit = 10
    /** @type {Map<string, Record<string, any>>} */
    const foundById = new Map()
    /** @type {unknown} */
    let primarySearchError = null
    for (const [scopeIndex, scope] of scopes.entries()) {
      try {
        const found = assertSafeCapabilityResult(await capabilities.searchCandidates({
          authorizationId: scope.authorizationId,
          projectId: scope.projectId,
          query,
          limit: analyzerLimit,
          allowSemanticFallback: true,
        }))
        if (
          !Array.isArray(found) ||
          found.length > analyzerLimit ||
          found.some((candidate) => !validSearchCandidate(candidate))
        ) {
          throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
        }
        for (const candidate of found) {
          if (!isProjectScopedCandidate(scope, candidate, localAuthorizationId, allowedAssetIds)) continue
          const existing = foundById.get(candidate.id)
          if (!existing || candidate.matchScore > existing.matchScore) {
            foundById.set(candidate.id, candidate)
          }
        }
      } catch (error) {
        if (scopeIndex === 0 && !primarySearchError) primarySearchError = error
      }
    }
    if (foundById.size === 0 && primarySearchError) {
      if (primarySearchError instanceof WorkbenchOperationError) throw primarySearchError
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    const occupiedIds = new Set(
      project.storyboard.sentences
        .filter((/** @type {any} */ item) => item.id !== sentenceId && item.selectedCandidateId)
        .map((/** @type {any} */ item) => item.selectedCandidateId),
    )
    const occupiedScenes = new Set(
      project.storyboard.sentences
        .filter((/** @type {any} */ item) => item.id !== sentenceId && item.selectedCandidateId)
        .flatMap((/** @type {any} */ item) => {
          const selected = item.candidates?.find((/** @type {any} */ candidate) =>
            candidate.id === item.selectedCandidateId)
          return selected ? [`${selected.assetLabel}\u0000${selected.start}\u0000${selected.end}`] : []
        }),
    )
    const replaceCurrentBeat = input?.replace === true
    const existingIds = new Set(sentence.candidates.map((/** @type {any} */ candidate) => candidate.id))
    const ranked = [...foundById.values()]
      .filter((candidate) =>
        !occupiedIds.has(candidate.id) &&
        !occupiedScenes.has(`${candidate.assetLabel}\u0000${candidate.start}\u0000${candidate.end}`) &&
        (replaceCurrentBeat || !existingIds.has(candidate.id)))
      .sort((left, right) =>
        right.matchScore - left.matchScore ||
        left.id.localeCompare(right.id))
      .map(toAttachedStoryboardCandidate)
    const nextCandidates = replaceCurrentBeat
      ? ranked.slice(0, 3)
      : [...sentence.candidates, ...ranked].slice(0, 6)
    if (nextCandidates.length === 0) return publicProject(project)
    if (
      !replaceCurrentBeat &&
      nextCandidates.length === sentence.candidates.length &&
      nextCandidates.every((candidate, index) => candidate.id === sentence.candidates[index]?.id)
    ) {
      return publicProject(project)
    }
    return update(id, (current) => {
      const target = current.storyboard?.sentences.find(
        (/** @type {any} */ item) => item.id === sentenceId,
      )
      if (!target) throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
      const previousSelected = target.selectedCandidateId
      target.candidates = nextCandidates
      if (replaceCurrentBeat) {
        const keepSelected = nextCandidates.some((candidate) => candidate.id === previousSelected)
        target.selectedCandidateId = keepSelected
          ? previousSelected
          : nextCandidates[0]?.id ?? null
        target.status = target.selectedCandidateId ? 'selected' : 'needs_capture'
        if (target.selectedCandidateId !== previousSelected) {
          stageStoryboardOutputInvalidation(current)
        }
      }
    })
  }
  /** @param {string} id @param {{idempotencyKey?: string}} [options] */
  const preview = async (id, options = {}) => {
    assertProjectMutationAvailable(id)
    if (!synthetic) {
      return requireJobCoordinator().createJob({
        projectId: id,
        type: 'preview_generation',
        idempotencyKey: options.idempotencyKey ??
          createHash('sha256').update(`${id}\u0000preview_generation`).digest('hex'),
      })
    }
    const project = readProject(id)
    if (!project?.storyboard || project.storyboard.sentences.some((/** @type {any} */ sentence) => !sentence.selectedCandidateId)) return null
    if (typeof capabilities.generatePreview !== 'function') throw new WorkbenchOperationError('WORKBENCH_PREVIEW_GENERATOR_UNAVAILABLE')
    const generatedPreview = assertSafeCapabilityResult(await capabilities.generatePreview({ projectId: id, project: clone(project) }))
    if (!generatedPreview || generatedPreview.status !== 'ready' || !safeLabel(generatedPreview.resourceId, 160)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return update(id, (current) => { current.preview = clone(generatedPreview); current.delivery = emptyDelivery(); current.currentStage = 'preview' })
  }
  /** @param {string} id */
  const finalizeVideo = async (id) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    if (!project || project.preview.status !== 'ready' || !project.preview.resourceId) return null
    if (!synthetic) {
      const coordinator = requireJobCoordinator()
      if (
        typeof coordinator.isCurrentEditorPreviewResource !== 'function' ||
        !await coordinator.isCurrentEditorPreviewResource(id, project.preview.resourceId)
      ) {
        throw new WorkbenchOperationError('WORKBENCH_EDITOR_BOUND_OUTPUT_REQUIRED', 409)
      }
    }
    if (project.delivery.finalVideo?.status === 'ready') return publicProject(project)
    if (typeof capabilities.finalizeVideo !== 'function') {
      throw new WorkbenchOperationError('WORKBENCH_FINAL_VIDEO_UNAVAILABLE')
    }
    const sourcePreviewResourceId = project.preview.resourceId
    const finalVideo = assertSafeCapabilityResult(await capabilities.finalizeVideo({
      projectId: id,
      previewResourceId: sourcePreviewResourceId,
      durationSeconds: project.preview.durationSeconds,
    }))
    if (
      !finalVideo ||
      finalVideo.status !== 'ready' ||
      !safeLabel(finalVideo.resourceId, 160) ||
      finalVideo.resourceId === project.preview.resourceId ||
      typeof finalVideo.durationSeconds !== 'number' ||
      finalVideo.durationSeconds <= 0 ||
      Number.isNaN(Date.parse(finalVideo.updatedAt))
    ) {
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    let committed = false
    const updated = update(id, (current) => {
      if (
        current.preview.status !== 'ready' ||
        current.preview.resourceId !== sourcePreviewResourceId
      ) return
      current.delivery.finalVideo = clone(finalVideo)
      current.currentStage = 'delivery'
      committed = true
    })
    if (committed) return updated
    const current = readProject(id)
    if (current?.delivery?.finalVideo?.resourceId !== finalVideo.resourceId) {
      if (typeof capabilities.deletePreviewResource !== 'function') {
        throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_UNAVAILABLE', 503)
      }
      const deleted = await capabilities.deletePreviewResource({
        projectId: id,
        resourceId: finalVideo.resourceId,
      })
      if (deleted !== true) {
        throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_FAILED', 500)
      }
    }
    throw new WorkbenchOperationError('WORKBENCH_FINAL_VIDEO_SUPERSEDED', 409)
  }
  /** @param {string} id */
  const preflight = async (id) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    if (!project?.storyboard || project.preview.status !== 'ready') return null
    if (typeof capabilities.preflight !== 'function') throw new WorkbenchOperationError('WORKBENCH_JIANYING_PREFLIGHT_UNAVAILABLE')
    const result = assertSafeCapabilityResult(await capabilities.preflight({ projectId: id, project: clone(project) }))
    if (!result?.template || !result?.preflight) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return update(id, (current) => { current.delivery.template = clone(result.template); current.delivery.preflight = clone(result.preflight); current.currentStage = 'delivery' })
  }
  /** @param {string} id */
  const exportDraft = async (id) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    if (!project || project.delivery.preflight.status !== 'ready') return null
    if (typeof capabilities.exportDraft !== 'function') throw new WorkbenchOperationError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE')
    const jobId = 'jy002-' + id + '-' + taskNumber++
    const exportJob = assertSafeCapabilityResult(await capabilities.exportDraft({ projectId: id, project: clone(project), jobId }))
    if (!exportJob || !workbenchJobStates.includes(exportJob.state)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return update(id, (current) => { current.delivery.exportJob = clone(exportJob); current.currentStage = 'delivery' })
  }
  /** @param {string} id @param {any} input */
  const recoverDelivery = async (id, input) => {
    assertProjectMutationAvailable(id)
    const project = readProject(id)
    const code = input?.code
    if (!project || typeof code !== 'string' || !Object.hasOwn(recoveryDefinitions, code)) return null
    const definition = recoveryDefinitions[/** @type {keyof typeof recoveryDefinitions} */ (code)]
    if (definition.stage !== 'delivery') return null
    if (typeof capabilities.recoverDelivery !== 'function') throw new WorkbenchOperationError('WORKBENCH_RECOVERY_HOST_UNAVAILABLE')
    const taskId = 'task-recovery-' + taskNumber++
    const recovery = assertSafeCapabilityResult(await capabilities.recoverDelivery({ projectId: id, project: clone(project), code, taskId }))
    if (!recovery || !safeText(recovery.detail, 500)) throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    return update(id, (current) => {
      if (recovery.preflight) current.delivery.preflight = clone(recovery.preflight)
      if (recovery.exportJob) current.delivery.exportJob = clone(recovery.exportJob)
      current.tasks.unshift({ id: taskId, type: 'recovery', label: definition.action, state: 'completed', progressPercent: 100, detail: recovery.detail, error: null })
    })
  }
  /** @param {string} type */
  const jobKind = (type) => type === 'material_analysis'
    ? { taskType: 'analysis', label: '素材分析', title: '素材分析未完成', stage: 'materials' }
    : type === 'storyboard_generation'
      ? { taskType: 'storyboard', label: '智能分镜', title: '智能分镜未完成', stage: 'storyboard' }
      : type === 'preview_generation'
        ? { taskType: 'preview', label: '正式预览', title: '正式预览未完成', stage: 'preview' }
        : type === 'reference_template_generation'
          ? { taskType: 'reference_template', label: '参考模板', title: '参考模板生成未完成', stage: 'delivery' }
          : type === 'editor_agent'
            ? { taskType: 'editor_agent', label: 'AI Editor', title: 'AI Editor 未完成', stage: 'editor' }
            : type === 'jianying_draft_export'
              ? { taskType: 'jianying_export', label: '剪映草稿导出', title: '剪映草稿导出未完成', stage: 'delivery' }
              : { taskType: 'unknown', label: '未知任务', title: '未知任务失败', stage: 'overview' }
  const jobTask = /** @param {{jobId: string, type: string, status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled', createdAt?: number, updatedAt?: number, progressPercent?: number, result?: {summary?: string}, error?: {code: string, recoverable?: boolean} | null, detail?: string}} job */ (job) => {
    const kind = jobKind(job.type)
    return {
    id: job.jobId,
    type: kind.taskType,
    label: kind.label,
    state: job.status === 'succeeded' ? 'completed' : job.status,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    progressPercent: job.progressPercent,
    detail: job.result?.summary ??
      (job.error
        ? `${job.error.code} · ${job.error.recoverable ? '可以重试' : '需要检查项目输入'}`
        : (typeof job.detail === 'string' && job.detail.trim())
            ? job.detail
            : job.status === 'queued'
              ? '任务已排队'
              : job.status === 'running'
                ? '任务正在执行'
                : '任务状态已更新'),
    error: job.error
      ? {
          code: job.error.code,
          title: kind.title,
          action: job.error.recoverable ? '重试此任务' : '检查项目输入后重新创建任务',
          stage: kind.stage,
          recoverable: job.error.recoverable,
        }
      : null,
    }
  }
  /** @param {any} job */
  const exportJobFromJianyingJob = (job) => {
    if (!job || job.type !== 'jianying_draft_export') return null
    const state = job.status === 'succeeded'
      ? 'ready_to_open'
      : job.status === 'failed' || job.status === 'timed_out'
        ? 'failed'
        : job.status === 'cancelled'
          ? 'cancelled'
          : null
    if (!state) return null
    const result = state === 'ready_to_open' && job.result
      ? {
          draftLabel: job.result.draftLabel,
          outputFingerprint: job.result.outputFingerprint,
          handoffMode: 'manual_open_required',
          desktopOpened: false,
          manualOpenHint: job.result.manualOpenHint,
          ...(job.result.writerProjectionFingerprint
            ? { writerProjectionFingerprint: job.result.writerProjectionFingerprint }
            : {}),
          ...(Array.isArray(job.result.writerDegradations) && job.result.writerDegradations.length > 0
            ? { writerDegradations: structuredClone(job.result.writerDegradations) }
            : {}),
        }
      : null
    return {
      id: job.jobId,
      state,
      progressPercent: job.progressPercent,
      recoverable: Boolean(job.error?.recoverable),
      error: job.error?.code ? safeError(job.error.code) : null,
      result,
    }
  }
  /** @param {string} projectId @param {{type: string, idempotencyKey: string, assetId?: string}} input */
  const createJob = async (projectId, input) => {
    assertProjectMutationAvailable(projectId)
    if (!synthetic) return requireJobCoordinator().createJob({ projectId, ...input })
    if (
      !readProject(projectId) ||
      !safeLabel(input?.idempotencyKey, 180) ||
      (input.assetId !== undefined && (!safeLabel(input.assetId, 160) || input.type !== 'material_analysis')) ||
      !['material_analysis', 'storyboard_generation', 'preview_generation'].includes(input?.type)
    ) return null
    const key = `${projectId}\u0000${input.idempotencyKey}`
    const existingId = syntheticJobKeys.get(key)
    if (existingId) {
      const existing = syntheticJobs.get(existingId)
      if (existing?.type !== input.type) throw new WorkbenchOperationError('WORKBENCH_JOB_INPUT_INVALID', 409)
      return clone(existing)
    }
    let result
    if (input.type === 'material_analysis') result = await analyze(projectId, { assetId: input.assetId })
    if (input.type === 'storyboard_generation') result = await generate(projectId)
    if (input.type === 'preview_generation') result = await preview(projectId)
    if (!result) return null
    const now = timestamp()
    const job = {
      jobId: `job-synthetic-${taskNumber++}`,
      projectId,
      type: input.type,
      status: 'succeeded',
      progressPercent: 100,
      detail: `${jobKind(input.type).label}已完成`,
      createdAt: now,
      updatedAt: now,
      cancelRequested: false,
      attempt: { generation: 1, status: 'succeeded', deadlineAt: now },
      result: {
        resourceId: `synthetic-${input.type}-${projectId}`,
        summary: `${jobKind(input.type).label}已完成`,
      },
      error: null,
    }
    syntheticJobs.set(job.jobId, job)
    syntheticJobKeys.set(key, job.jobId)
    return clone(job)
  }
  /** @param {string} projectId @param {string} jobId */
  const getJob = async (projectId, jobId) => {
    if (!synthetic) return requireJobCoordinator().getJob(projectId, jobId)
    const job = syntheticJobs.get(jobId)
    return job?.projectId === projectId ? clone(job) : null
  }
  /** @param {string} projectId */
  const listJobs = async (projectId) => {
    if (!synthetic) return requireJobCoordinator().listJobs(projectId)
    return [...syntheticJobs.values()]
      .filter((job) => job.projectId === projectId)
      .map(clone)
  }
  /** @param {string[]} projectIds */
  const listJobsForProjects = async (projectIds) => {
    if (!synthetic) return requireJobCoordinator().listJobsForProjects(projectIds)
    const allowed = new Set(Array.isArray(projectIds) ? projectIds : [])
    return [...syntheticJobs.values()]
      .filter((job) => allowed.has(job.projectId))
      .map(clone)
  }
  /** @param {any} project @param {string} expectedUpdatedAt */
  const stageProjectDeletion = (project, expectedUpdatedAt) => {
    project.pendingProjectDeletion = {
      resourceIds: [...new Set([
        project.preview?.resourceId,
        project.delivery?.finalVideo?.resourceId,
      ].filter(Boolean))],
      jobsPending: Boolean(repositories && !synthetic),
      projectDataPending: Boolean(repositories && !synthetic),
      referenceTemplatesPending: Boolean(repositories && !synthetic),
      expectedUpdatedAt,
      createdAt: timestamp(),
    }
  }
  /** @param {string} projectId @param {symbol} owner */
  const drainProjectDeletion = async (projectId, owner) => {
    let project = readProject(projectId)
    if (!project?.pendingProjectDeletion) return project ? null : { deletedProjectId: projectId }
    const coordinator = repositories && !synthetic ? requireJobCoordinator() : null

    if (project.pendingProjectDeletion.jobsPending) {
      if (
        typeof coordinator?.assertProjectIdle !== 'function' ||
        typeof coordinator?.deleteProjectData !== 'function'
      ) throw new WorkbenchOperationError('WORKBENCH_PROJECT_CLEANUP_UNAVAILABLE', 503)
      await coordinator.assertProjectIdle(projectId)
      await coordinator.deleteProjectData(projectId)
      update(projectId, (current) => {
        current.pendingProjectDeletion.jobsPending = false
      }, owner)
      project = readProject(projectId)
    }

    while (project?.pendingProjectDeletion?.resourceIds.length > 0) {
      if (typeof capabilities.deletePreviewResource !== 'function') {
        throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_UNAVAILABLE', 503)
      }
      const resourceId = project.pendingProjectDeletion.resourceIds[0]
      const deleted = await capabilities.deletePreviewResource({ projectId, resourceId })
      if (deleted !== true) {
        throw new WorkbenchOperationError('WORKBENCH_PREVIEW_CLEANUP_FAILED', 500)
      }
      update(projectId, (current) => {
        current.pendingProjectDeletion.resourceIds =
          current.pendingProjectDeletion.resourceIds.filter(
            (/** @type {string} */ item) => item !== resourceId,
          )
      }, owner)
      project = readProject(projectId)
    }

    if (project?.pendingProjectDeletion?.projectDataPending) {
      if (typeof capabilities.deleteProjectData !== 'function') {
        throw new WorkbenchOperationError('WORKBENCH_PROJECT_CLEANUP_UNAVAILABLE', 503)
      }
      const cleaned = await capabilities.deleteProjectData({ projectId })
      if (cleaned !== true) {
        throw new WorkbenchOperationError('WORKBENCH_PROJECT_CLEANUP_FAILED', 500)
      }
      update(projectId, (current) => {
        current.pendingProjectDeletion.projectDataPending = false
      }, owner)
      project = readProject(projectId)
    }

    if (project?.pendingProjectDeletion?.referenceTemplatesPending) {
      if (typeof referenceTemplateRepository?.removeByProject !== 'function') {
        throw new WorkbenchOperationError('WORKBENCH_PROJECT_CLEANUP_UNAVAILABLE', 503)
      }
      await referenceTemplateRepository.removeByProject(projectId)
      update(projectId, (current) => {
        current.pendingProjectDeletion.referenceTemplatesPending = false
      }, owner)
    }

    // References are project-scoped opaque pointers. Remove them before the
    // project record disappears, including pointers that use this project as
    // their source, so a deleted project ID cannot serve media indirectly.
    if (typeof materialLibraryService?.removeProjectReferences === 'function') {
      await materialLibraryService.removeProjectReferences(projectId)
    }

    if (repositories && !synthetic) {
      for (const task of repositories.taskRepository.listByProject(projectId)) {
        repositories.taskRepository.remove(task.id)
      }
      repositories.projectRepository.remove(projectId)
    } else {
      for (const [jobId, job] of syntheticJobs.entries()) {
        if (job.projectId === projectId) syntheticJobs.delete(jobId)
      }
      for (const [key, jobId] of syntheticJobKeys.entries()) {
        if (!syntheticJobs.has(jobId)) syntheticJobKeys.delete(key)
      }
    }
    projects.delete(projectId)
    return { deletedProjectId: projectId }
  }
  /** @param {string} projectId @param {{expectedUpdatedAt: string}} input */
  const deleteProject = async (projectId, input) => {
    assertProjectDeletionAvailable(projectId)
    const owner = Symbol(projectId)
    projectMutationLocks.set(projectId, owner)
    try {
      let project = readProject(projectId)
      if (!project) return null
      const pending = project.pendingProjectDeletion
      if (
        pending &&
        ![pending.expectedUpdatedAt, project.updatedAt].includes(input.expectedUpdatedAt)
      ) throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
      if (!pending) {
        const jobs = await listJobs(projectId)
        const busy = jobs.some((/** @type {any} */ job) =>
          ['queued', 'running', 'cancelling'].includes(job.status)) ||
          project.tasks.some((/** @type {any} */ task) =>
            ['queued', 'running', 'cancelling'].includes(task.state))
        if (busy) throw new WorkbenchOperationError('WORKBENCH_PROJECT_BUSY', 409)
        if (repositories && !synthetic) {
          const coordinator = requireJobCoordinator()
          if (
            typeof coordinator.assertProjectIdle !== 'function' ||
            typeof coordinator.deleteProjectData !== 'function' ||
            typeof capabilities.deleteProjectData !== 'function' ||
            typeof referenceTemplateRepository?.removeByProject !== 'function' ||
            ([project.preview?.resourceId, project.delivery?.finalVideo?.resourceId].some(Boolean) &&
              typeof capabilities.deletePreviewResource !== 'function')
          ) throw new WorkbenchOperationError('WORKBENCH_PROJECT_CLEANUP_UNAVAILABLE', 503)
          await coordinator.assertProjectIdle(projectId)
        }
        const stageDeletion = () => {
          const current = readProject(projectId)
          if (!current) return null
          if (current.pendingProjectDeletion) return current
          return updateIfCurrent(projectId, current.updatedAt, (next) => {
            stageProjectDeletion(next, current.updatedAt)
          }, owner)
        }
        try {
          if (!stageDeletion()) return null
        } catch (error) {
          if (!(error instanceof WorkbenchOperationError) || error.code !== 'WORKBENCH_PROJECT_REVISION_CONFLICT') {
            throw error
          }
          if (!stageDeletion()) return null
        }
        project = readProject(projectId)
      }
      return await drainProjectDeletion(projectId, owner)
    } finally {
      if (projectMutationLocks.get(projectId) === owner) {
        projectMutationLocks.delete(projectId)
      }
    }
  }
  /** @param {string} projectId @param {{name: string, expectedUpdatedAt: string}} input */
  const renameProject = async (projectId, input) => {
    if (!input || !safeLabel(input.name, 100) || !isTimestamp(input.expectedUpdatedAt)) return null
    return updateIfCurrent(projectId, input.expectedUpdatedAt, (project) => {
      // Keep existing material references and already-created outputs intact.
      project.name = input.name.trim()
    })
  }
  /** @param {string} projectId @param {string} jobId */
  const cancelJob = async (projectId, jobId) => {
    assertProjectMutationAvailable(projectId)
    if (!synthetic) return requireJobCoordinator().cancelJob(projectId, jobId)
    return getJob(projectId, jobId)
  }
  /** @param {string} projectId @param {string} jobId */
  const retryJob = async (projectId, jobId) => {
    assertProjectMutationAvailable(projectId)
    if (!synthetic) return requireJobCoordinator().retryJob(projectId, jobId)
    return getJob(projectId, jobId)
  }
  /** @param {string} projectId @param {string[]} jobIds */
  const dismissJobs = async (projectId, jobIds) => {
    assertProjectMutationAvailable(projectId)
    if (!Array.isArray(jobIds) || jobIds.length === 0) {
      throw new WorkbenchOperationError('WORKBENCH_JOB_INPUT_INVALID', 400)
    }
    if (!synthetic) {
      const coordinator = requireJobCoordinator()
      if (typeof coordinator.dismissJobs !== 'function') {
        throw new WorkbenchOperationError('WORKBENCH_JOB_DISMISS_UNAVAILABLE', 503)
      }
      return coordinator.dismissJobs(projectId, jobIds)
    }
    const dismissed = []
    for (const jobId of jobIds) {
      const job = syntheticJobs.get(jobId)
      if (!job || job.projectId !== projectId) {
        throw new WorkbenchOperationError('WORKBENCH_JOB_NOT_FOUND', 404)
      }
      if (!['failed', 'cancelled', 'timed_out'].includes(job.status)) {
        throw new WorkbenchOperationError('WORKBENCH_JOB_NOT_DISMISSIBLE', 409)
      }
      syntheticJobs.delete(jobId)
      dismissed.push(jobId)
    }
    return dismissed
  }
  /** @param {string} projectId */
  const dismissFailedJobs = async (projectId) => {
    assertProjectMutationAvailable(projectId)
    if (!synthetic) {
      const coordinator = requireJobCoordinator()
      if (typeof coordinator.dismissFailedJobs !== 'function') {
        throw new WorkbenchOperationError('WORKBENCH_JOB_DISMISS_UNAVAILABLE', 503)
      }
      return coordinator.dismissFailedJobs(projectId)
    }
    const jobIds = [...syntheticJobs.values()]
      .filter((job) =>
        job.projectId === projectId &&
        ['failed', 'cancelled', 'timed_out'].includes(job.status))
      .map((job) => job.jobId)
    return jobIds.length ? dismissJobs(projectId, jobIds) : []
  }
  /** @param {string} projectId @param {any} input @param {{idempotencyKey?: string}} [options] */
  const createReferenceTemplate = async (projectId, input, options = {}) => {
    assertProjectMutationAvailable(projectId)
    const project = readProject(projectId)
    const usesAsset = input && exactBody(input, ['assetId', 'templateSelectionRequest'])
    const usesReferenceAuthorization = input && exactBody(input, ['referenceAuthorizationId', 'templateSelectionRequest'])
    if (
      !project ||
      !input ||
      (!usesAsset && !usesReferenceAuthorization) ||
      (usesAsset && (
        !safeLabel(input.assetId, 160) ||
        !project.materials.assets.some((/** @type {any} */ asset) => asset.id === input.assetId)
      )) ||
      (usesReferenceAuthorization && !safeLabel(input.referenceAuthorizationId, 160)) ||
      !jobCoordinator ||
      typeof jobCoordinator.createReferenceTemplateJob !== 'function'
    ) {
      if (project && (!jobCoordinator || typeof jobCoordinator.createReferenceTemplateJob !== 'function')) {
        throw new WorkbenchOperationError('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE')
      }
      return null
    }
    return jobCoordinator.createReferenceTemplateJob({
      projectId,
      ...(usesAsset ? { assetId: input.assetId } : { referenceAuthorizationId: input.referenceAuthorizationId }),
      templateSelectionRequest: clone(input.templateSelectionRequest),
      idempotencyKey: options.idempotencyKey ?? randomUUID(),
    })
  }
  /** @param {string} projectId @param {any} input @param {{idempotencyKey?: string}} [options] */
  const createJianyingDraft = async (projectId, input, options = {}) => {
    assertProjectMutationAvailable(projectId)
    if (
      !readProject(projectId) ||
      !exactBody(input, []) ||
      !jobCoordinator ||
      typeof jobCoordinator.createJianyingDraftJob !== 'function'
    ) {
      if (readProject(projectId) && (!jobCoordinator || typeof jobCoordinator.createJianyingDraftJob !== 'function')) {
        throw new WorkbenchOperationError('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE')
      }
      return null
    }
    return jobCoordinator.createJianyingDraftJob({
      projectId,
      idempotencyKey: options.idempotencyKey ?? randomUUID(),
    })
  }
  /** @param {string} projectId @param {any} input @param {{idempotencyKey?: string}} [options] */
  const createEditorAgent = async (projectId, input, options = {}) => {
    assertProjectMutationAvailable(projectId)
    if (synthetic) {
      const project = readProject(projectId)
      const timeline = project ? createSyntheticEditorTimeline(project) : null
      if (!timeline) throw new WorkbenchOperationError('WORKBENCH_EDITOR_STORYBOARD_INCOMPLETE', 409)
      const now = timestamp()
      return {
        jobId: `job-editor-${projectId}`,
        projectId,
        type: 'editor_agent',
        status: 'succeeded',
        progressPercent: 100,
        detail: 'AI 剪辑已完成',
        createdAt: now,
        updatedAt: now,
        cancelRequested: false,
        attempt: { generation: 1, status: 'succeeded', deadlineAt: now },
        result: {
          resourceId: `editor-${projectId}`,
          summary: 'AI 已完成镜头编排',
          timelineId: timeline.timelineId,
          timelineRevision: timeline.revision,
          timelineRevisionFingerprint: timeline.revisionFingerprint,
        },
        error: null,
      }
    }
    if (
      !readProject(projectId) ||
      !jobCoordinator ||
      typeof jobCoordinator.createEditorAgentJob !== 'function'
    ) {
      if (readProject(projectId) && (!jobCoordinator || typeof jobCoordinator.createEditorAgentJob !== 'function')) {
        throw new WorkbenchOperationError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE')
      }
      return null
    }
    const editorAgentInputKeys = isRecord(input)
      ? Object.keys(input).sort().join('\u0000')
      : ''
    const acceptsFreshRetry = (
      editorAgentInputKeys === ['automaticPackaging', 'baseTimeline', 'fresh', 'instruction', 'mode'].sort().join('\u0000') ||
      editorAgentInputKeys === ['automaticPackaging', 'baseTimeline', 'fresh', 'instruction', 'mode', 'packagingFeedbackHandle'].sort().join('\u0000')
    ) &&
      typeof input.automaticPackaging === 'boolean' &&
      typeof input.fresh === 'boolean' &&
      (input.packagingFeedbackHandle === undefined || input.packagingFeedbackHandle === null || typeof input.packagingFeedbackHandle === 'string')
    const acceptsStandardCreate = (
      editorAgentInputKeys === ['automaticPackaging', 'baseTimeline', 'instruction', 'mode'].sort().join('\u0000') ||
      editorAgentInputKeys === ['automaticPackaging', 'baseTimeline', 'instruction', 'mode', 'packagingFeedbackHandle'].sort().join('\u0000')
    ) && typeof input.automaticPackaging === 'boolean' &&
      (input.packagingFeedbackHandle === undefined || input.packagingFeedbackHandle === null || typeof input.packagingFeedbackHandle === 'string')
    const acceptsLegacyFreshRetry = editorAgentInputKeys ===
      ['baseTimeline', 'fresh', 'instruction', 'mode'].sort().join('\u0000') &&
      typeof input.fresh === 'boolean'
    const acceptsLegacyStandardCreate = editorAgentInputKeys ===
      ['baseTimeline', 'instruction', 'mode'].sort().join('\u0000')
    if (!isRecord(input) || (!acceptsStandardCreate && !acceptsFreshRetry && !acceptsLegacyStandardCreate && !acceptsLegacyFreshRetry)) {
      throw new WorkbenchOperationError('WORKBENCH_JOB_INPUT_INVALID')
    }
    const idempotencyKey = options.idempotencyKey ?? randomUUID()
    return jobCoordinator.createEditorAgentJob({
      idempotencyKey,
      automaticPackaging: input.automaticPackaging === true,
      packagingFeedbackHandle: input.packagingFeedbackHandle ?? null,
      ...(input.fresh === true ? { fresh: true } : {}),
      instruction: {
        projectId,
        instruction: input.instruction,
        baseTimeline: input.baseTimeline,
        mode: input.mode,
        idempotencyKey,
      },
    })
  }
  /** @param {string} projectId */
  const getEditorTimeline = async (projectId) => {
    if (synthetic) {
      const project = readProject(projectId)
      return project ? createSyntheticEditorTimeline(project) : null
    }
    if (!readProject(projectId)) return null
    if (
      !jobCoordinator ||
      typeof jobCoordinator.getCurrentEditorTimeline !== 'function'
    ) {
      throw new WorkbenchOperationError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE')
    }
    return jobCoordinator.getCurrentEditorTimeline(projectId)
  }
  /**
   * @param {'preview'|'jianying'} kind
   * @param {string} projectId
   * @param {any} input
   * @param {{idempotencyKey?: string}} [options]
   */
  const createEditorOutput = async (kind, projectId, input, options = {}) => {
    assertProjectMutationAvailable(projectId)
    if (synthetic) {
      const project = readProject(projectId)
      const timeline = project ? createSyntheticEditorTimeline(project) : null
      if (!timeline || timeline.timelineId !== input?.timelineId || timeline.revision !== input?.revision) return null
      const now = timestamp()
      const resourceId = kind === 'preview'
        ? `preview-${projectId}-editor-synthetic`
        : `draft-${projectId}-editor-synthetic`
      if (kind === 'preview') {
        update(projectId, (current) => {
          current.preview = {
            status: 'ready',
            resourceId,
            durationSeconds: timeline.durationUs / 1_000_000,
            updatedAt: now,
            timelineId: timeline.timelineId,
            timelineRevision: timeline.revision,
            timelineRevisionFingerprint: timeline.revisionFingerprint,
          }
          current.currentStage = 'preview'
        })
      }
      return {
        jobId: `job-${kind}-${projectId}`,
        projectId,
        type: kind === 'preview' ? 'preview_generation' : 'jianying_draft_export',
        status: 'succeeded',
        progressPercent: 100,
        detail: kind === 'preview' ? '预览已生成' : '剪映草稿已导出',
        createdAt: now,
        updatedAt: now,
        cancelRequested: false,
        attempt: { generation: 1, status: 'succeeded', deadlineAt: now },
        result: kind === 'preview'
          ? { resourceId, summary: '预览已生成' }
          : { resourceId, summary: '剪映草稿已导出', outputFingerprint: createHash('sha256').update(`${projectId}:${timeline.revisionFingerprint}`).digest('hex') },
        error: null,
      }
    }
    if (
      !readProject(projectId) ||
      !exactBody(input, ['revision', 'revisionFingerprint', 'timelineId']) ||
      !safeLabel(input.timelineId, 200) ||
      !Number.isSafeInteger(input.revision) ||
      input.revision < 1 ||
      typeof input.revisionFingerprint !== 'string' ||
      !/^[a-f0-9]{64}$/u.test(input.revisionFingerprint)
    ) {
      return null
    }
    const method = kind === 'preview'
      ? 'createEditorTimelinePreviewJob'
      : 'createEditorTimelineExportJob'
    if (!jobCoordinator || typeof jobCoordinator[method] !== 'function') {
      throw new WorkbenchOperationError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE')
    }
    return jobCoordinator[method]({
      projectId,
      timelineId: input.timelineId,
      revision: input.revision,
      revisionFingerprint: input.revisionFingerprint,
      idempotencyKey: options.idempotencyKey ?? randomUUID(),
    })
  }
  /** @param {string} projectId @param {any} input @param {{idempotencyKey?: string}} [options] */
  const createEditorPreview = (projectId, input, options = {}) =>
    createEditorOutput('preview', projectId, input, options)
  /** @param {string} projectId @param {any} input @param {{idempotencyKey?: string}} [options] */
  const createEditorDraft = (projectId, input, options = {}) =>
    createEditorOutput('jianying', projectId, input, options)
  /**
   * Route the delivery action to the canonical editor-bound writer whenever a
   * current RichTimeline exists. Legacy projects are the only callers that
   * may still use the project-scoped Jianying job.
   * @param {string} projectId
   * @param {any} input
   * @param {{idempotencyKey?: string}} [options]
   */
  const createDeliveryExport = async (projectId, input, options = {}) => {
    assertProjectMutationAvailable(projectId)
    if (!readProject(projectId) || !exactBody(input, [])) return null
    if (!jobCoordinator || typeof jobCoordinator.getCurrentEditorTimeline !== 'function') {
      throw new WorkbenchOperationError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE')
    }
    const timeline = await getEditorTimeline(projectId)
    if (timeline) {
      if (timeline.status !== 'finalized') {
        throw new WorkbenchOperationError('WORKBENCH_EDITOR_BOUND_OUTPUT_REQUIRED', 409)
      }
      return createEditorDraft(projectId, {
        timelineId: timeline.timelineId,
        revision: timeline.revision,
        revisionFingerprint: timeline.revisionFingerprint,
      }, options)
    }
    return createJianyingDraft(projectId, input, options)
  }
  const requireReferenceRepository = () => {
    if (
      !referenceTemplateRepository ||
      ['get', 'list', 'review', 'getApproved'].some(
        (method) => typeof referenceTemplateRepository[method] !== 'function',
      )
    ) throw new WorkbenchOperationError('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE')
    return referenceTemplateRepository
  }
  /** @param {string} projectId */
  const listReferenceTemplates = async (projectId) =>
    readProject(projectId) ? requireReferenceRepository().list(projectId) : null
  /** @param {string} projectId @param {string} referenceTemplateId */
  const getReferenceTemplate = async (projectId, referenceTemplateId) =>
    readProject(projectId)
      ? requireReferenceRepository().get(projectId, referenceTemplateId)
      : null
  /** @param {string} projectId @param {string} referenceTemplateId @param {any} input */
  const reviewReferenceTemplate = async (projectId, referenceTemplateId, input) => {
    if (
      !readProject(projectId) ||
      !exactBody(input, ['command', 'expectedRevision']) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1
    ) return null
    return requireReferenceRepository().review({
      projectId,
      referenceTemplateId,
      expectedRevision: input.expectedRevision,
      command: clone(input.command),
    })
  }
  const requireReusableTemplateLibrary = () => {
    if (
      !reusableTemplateLibraryService ||
      ['list', 'get', 'upload', 'create', 'review', 'deactivate'].some(
        (method) => typeof reusableTemplateLibraryService[method] !== 'function',
      )
    ) throw new WorkbenchOperationError('REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE')
    return reusableTemplateLibraryService
  }
  const listReusableTemplates = async () => {
    void ensureWindowsNativePickerHost()
    return requireReusableTemplateLibrary().list()
  }
  /** @param {string} libraryTemplateId */
  const getReusableTemplate = async (libraryTemplateId) =>
    requireReusableTemplateLibrary().get(libraryTemplateId)
  /** @param {{file: any}} input */
  const uploadReusableTemplateVideo = async (input) =>
    requireReusableTemplateLibrary().upload(input)
  /** @param {{sessionId: string, nodeId: string, readOnlyConfirmed: true}} input */
  const authorizeReusableTemplateDraft = async (input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.authorizeDraft !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_DRAFT_UNAUTHORIZED', 503)
    }
    return library.authorizeDraft(input)
  }
  /** @param {any} input */
  const createReusableTemplate = async (input) =>
    requireReusableTemplateLibrary().create(input)
  /** @param {string} libraryTemplateId @param {any} input */
  const reviewReusableTemplate = async (libraryTemplateId, input) =>
    requireReusableTemplateLibrary().review(libraryTemplateId, input)
  /** @param {string} libraryTemplateId @param {any} input */
  const deactivateReusableTemplate = async (libraryTemplateId, input) =>
    requireReusableTemplateLibrary().deactivate(libraryTemplateId, input)
  /** @param {string} libraryTemplateId */
  const templateIsBoundToProject = (libraryTemplateId) => {
    const projects = readProjects()
    return projects.some((project) => {
      const binding = project?.templateBinding
      if (!binding || typeof binding !== 'object') return false
      if (binding.libraryTemplateId === libraryTemplateId) return true
      return Array.isArray(binding.blendSources) &&
        binding.blendSources.some((/** @type {Record<string, any>} */ source) => source?.libraryTemplateId === libraryTemplateId)
    })
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const removeReusableTemplate = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.remove !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_REMOVE_UNAVAILABLE', 503)
    }
    if (templateIsBoundToProject(libraryTemplateId)) {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_IN_USE', 409)
    }
    return library.remove(libraryTemplateId, input)
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const relabelReusableTemplate = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.relabel !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_RELABEL_UNAVAILABLE', 503)
    }
    return library.relabel(libraryTemplateId, input)
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const reactivateReusableTemplate = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.reactivate !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE')
    }
    return library.reactivate(libraryTemplateId, input)
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const createEditableReusableTemplateRevision = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.createEditableRevision !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_REVISION_UNAVAILABLE', 503)
    }
    return library.createEditableRevision(libraryTemplateId, input)
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const refreshReusableTemplateAssets = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.refreshAssets !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_REFRESH_UNAVAILABLE', 503)
    }
    return library.refreshAssets(libraryTemplateId, input)
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const bindReusableTemplateVoice = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.bindVoice !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_VOICE_UNAVAILABLE', 503)
    }
    return library.bindVoice(libraryTemplateId, input)
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const bindReusableTemplateAudio = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.bindAudio !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_AUDIO_UNAVAILABLE', 503)
    }
    const backingAuthorizationId = typeof bgmLibrary?.getBackingAuthorizationId === 'function'
      ? bgmLibrary.getBackingAuthorizationId({
          projectId: libraryTemplateId,
          trackId: input?.sourceAuthorizationId,
        })
      : null
    return library.bindAudio(libraryTemplateId, {
      ...input,
      sourceAuthorizationId: backingAuthorizationId ?? input?.sourceAuthorizationId,
    })
  }
  /** @param {string} libraryTemplateId @param {any} input */
  const attachReusableTemplateReference = async (libraryTemplateId, input) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.attachReference !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_ATTACH_UNAVAILABLE', 503)
    }
    return library.attachReference(libraryTemplateId, input)
  }
  /**
   * @param {string} libraryTemplateId
   * @param {'reference' | 'demo'} kind
   */
  const resolveReusableTemplateMedia = async (libraryTemplateId, kind) => {
    const library = requireReusableTemplateLibrary()
    if (typeof library.resolveMedia !== 'function') {
      throw new WorkbenchOperationError('TEMPLATE_MEDIA_UNAVAILABLE', 503)
    }
    return library.resolveMedia(libraryTemplateId, kind)
  }
  /** @param {string} projectId @param {any} input */
  const bindTemplate = async (projectId, input) => {
    const hasBlend = isRecord(input) && (
      input.blendLibraryTemplateId !== undefined ||
      input.expectedBlendRevision !== undefined
    )
    if (
      !isRecord(input) ||
      !safeLabel(input.libraryTemplateId, 200) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1 ||
      typeof input.expectedProjectUpdatedAt !== 'string' ||
      (hasBlend && (
        !safeLabel(input.blendLibraryTemplateId, 200) ||
        input.blendLibraryTemplateId === input.libraryTemplateId ||
        !Number.isSafeInteger(input.expectedBlendRevision) ||
        input.expectedBlendRevision < 1
      ))
    ) throw new WorkbenchOperationError('WORKBENCH_TEMPLATE_BINDING_INPUT_INVALID', 400)
    const project = readProject(projectId)
    if (!project) return null
    const library = requireReusableTemplateLibrary()
    if (typeof library.withApprovedForUse !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE')
    }
    const bindApproved = async (
      /** @type {Record<string, any>} */ approved,
      /** @type {Record<string, any> | null} */ blendApproved = null,
    ) => {
        // Same-material A/B is an optional verification tool after storyboard selections exist.
        // Binding must not require A/B confirm, or users cannot use a template to drive storyboard generation.
        const binding = blendApproved
          ? createBlendedProjectTemplateBinding(approved, blendApproved)
          : createProjectTemplateBinding(approved)
        const currentProject = readProject(projectId)
        if (!currentProject) return null
        if (binding.orientation !== currentProject.brief.orientation) {
          throw new WorkbenchOperationError(
            'WORKBENCH_TEMPLATE_ORIENTATION_INCOMPATIBLE',
            409,
          )
        }
        if (
          currentProject.templateBinding?.libraryTemplateId === binding.libraryTemplateId &&
          currentProject.templateBinding?.revision === binding.revision &&
          currentProject.templateBinding?.fingerprint === binding.fingerprint
        ) {
          return currentProject.pendingOutputInvalidation
            ? resumeProjectOutputInvalidation(projectId)
            : publicProject(currentProject)
        }
        if (currentProject.updatedAt !== input.expectedProjectUpdatedAt) {
          throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
        }
        const packaging = normalizePackaging(currentProject.brief.packaging)
        const bgmCue = Array.isArray(binding.replicationRecipe?.audioCues)
          ? binding.replicationRecipe.audioCues.find(
              (/** @type {Record<string, any>} */ cue) =>
                cue?.role === 'bgm' && safeLabel(cue.audioToken, 200),
            )
          : null
        const owner = Symbol(projectId)
        projectMutationLocks.set(projectId, owner)
        try {
          let materializedBgmTrackId = null
          if (
            !(packaging.bgm === 'local_authorized' && packaging.bgmAuthorizationId) &&
            bgmCue &&
            typeof resolveTemplateAudioPath === 'function' &&
            typeof authorizeProjectBgmFromPath === 'function'
          ) {
            try {
              const absolutePath = await resolveTemplateAudioPath({
                libraryTemplateId: binding.libraryTemplateId,
                audioToken: bgmCue.audioToken,
              })
              if (typeof absolutePath === 'string' && absolutePath.length > 0) {
                const authorized = await authorizeProjectBgmFromPath({
                  projectId,
                  absolutePath,
                })
                const trackId = typeof authorized === 'string'
                  ? authorized
                  : authorized?.authorizationId ?? authorized?.trackId
                if (safeLabel(trackId, 160)) materializedBgmTrackId = trackId
              }
            } catch {
              // Template binding remains usable when private BGM materialization is unavailable.
            }
          }
          return await updateTemplateBinding(projectId, input.expectedProjectUpdatedAt, (current) => {
            current.templateBinding = binding
            current.currentStage = 'brief'
            const voiceProfileId = binding.replicationRecipe?.voiceProfileId
            if (
              typeof voiceProfileId === 'string' &&
              voiceProfileId.length > 0 &&
              (
                !current.brief.voiceId ||
                current.brief.voiceover === 'none'
              )
            ) {
              current.brief = {
                ...current.brief,
                voiceover: 'required',
                voiceId: voiceProfileId,
              }
            }
            if (materializedBgmTrackId) {
              current.brief = {
                ...current.brief,
                packaging: normalizePackaging({
                  ...packaging,
                  bgm: 'local_authorized',
                  bgmAuthorizationId: materializedBgmTrackId,
                }),
              }
            }
          }, owner)
        } finally {
          if (projectMutationLocks.get(projectId) === owner) {
            projectMutationLocks.delete(projectId)
          }
        }
    }
    return library.withApprovedForUse(
      input.libraryTemplateId,
      input.expectedRevision,
      async (/** @type {Record<string, any>} */ approved) => hasBlend
        ? library.withApprovedForUse(
            input.blendLibraryTemplateId,
            input.expectedBlendRevision,
            (/** @type {Record<string, any>} */ blendApproved) =>
              bindApproved(approved, blendApproved),
          )
        : bindApproved(approved),
    )
  }
  /** @param {string} projectId @param {any} input */
  const unbindTemplate = async (projectId, input) => {
    if (
      !isRecord(input) ||
      typeof input.expectedProjectUpdatedAt !== 'string'
    ) throw new WorkbenchOperationError('WORKBENCH_TEMPLATE_BINDING_INPUT_INVALID', 400)
    const project = readProject(projectId)
    if (!project) return null
    if (!project.templateBinding) {
      return project.pendingOutputInvalidation
        ? resumeProjectOutputInvalidation(projectId)
        : publicProject(project)
    }
    if (project.updatedAt !== input.expectedProjectUpdatedAt) {
      throw new WorkbenchOperationError('WORKBENCH_PROJECT_REVISION_CONFLICT', 409)
    }
    return updateTemplateBinding(projectId, input.expectedProjectUpdatedAt, (current) => {
      current.templateBinding = null
      current.currentStage = 'brief'
    })
  }
  const recoverPendingProjectDeletions = async () => {
    const failures = []
    for (const project of readProjects()) {
      if (!project.pendingProjectDeletion) continue
      const owner = Symbol(project.id)
      try {
        assertProjectLockAvailable(project.id)
        projectMutationLocks.set(project.id, owner)
        await drainProjectDeletion(project.id, owner)
      } catch (error) {
        const localError = error && typeof error === 'object'
          ? /** @type {{code?: unknown}} */ (error)
          : {}
        failures.push({
          projectId: project.id,
          code: typeof localError.code === 'string'
            ? localError.code
            : 'WORKBENCH_PROJECT_DELETE_RECOVERY_FAILED',
        })
      } finally {
        if (projectMutationLocks.get(project.id) === owner) {
          projectMutationLocks.delete(project.id)
        }
      }
    }
    return {
      pendingProjectIds: readProjects()
        .filter((project) => project.pendingProjectDeletion)
        .map((project) => project.id),
      failures,
    }
  }

  /**
   * @param {string} projectId
   * @param {{ libraryTemplateId: string, expectedRevision: number }} input
   */
  const generateTemplateAbPreview = async (projectId, input) => {
    if (
      !projectTemplateAbPreviewStore ||
      typeof projectTemplateAbPreviewStore.generate !== 'function'
    ) {
      throw new WorkbenchOperationError('TEMPLATE_AB_UNAVAILABLE', 503)
    }
    if (
      !isRecord(input) ||
      !safeLabel(input.libraryTemplateId, 200) ||
      !Number.isSafeInteger(input.expectedRevision) ||
      input.expectedRevision < 1
    ) {
      throw new WorkbenchOperationError('TEMPLATE_AB_INPUT_INVALID', 400)
    }
    const project = readProject(projectId)
    if (!project) return null
    if (!project.storyboard?.sentences?.length) {
      throw new WorkbenchOperationError('TEMPLATE_AB_STORYBOARD_REQUIRED', 409)
    }
    const library = requireReusableTemplateLibrary()
    if (typeof library.withApprovedForUse !== 'function') {
      throw new WorkbenchOperationError('REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE')
    }
    return library.withApprovedForUse(
      input.libraryTemplateId,
      input.expectedRevision,
      async (/** @type {Record<string, any>} */ approved) => {
        const binding = createProjectTemplateBinding(approved)
        if (binding.orientation !== project.brief.orientation) {
          throw new WorkbenchOperationError('WORKBENCH_TEMPLATE_ORIENTATION_INCOMPATIBLE', 409)
        }
        const selections = project.storyboard.sentences
          .map((/** @type {Record<string, any>} */ sentence) => {
            const selected = sentence.candidates?.find(
              (/** @type {Record<string, any>} */ candidate) =>
                candidate.id === sentence.selectedCandidateId,
            )
            if (!selected) return null
            return {
              candidateId: selected.id,
              start: selected.start,
              end: selected.end,
            }
          })
          .filter(Boolean)
        if (selections.length < 1) {
          throw new WorkbenchOperationError('TEMPLATE_AB_SELECTIONS_REQUIRED', 409)
        }
        // Match preview jobs: trim candidate windows to adapted template slot
        // durations before resolving sources. Otherwise full scene lengths
        // (often >> 180s total) make the baseline A/B side fail closed.
        let guidance
        let timedSelections
        try {
          guidance = adaptTemplateGuidanceToCount(
            createTemplateGuidance(binding),
            selections.length,
          )
          timedSelections = applyTemplateGuidanceToSelections(selections, guidance)
        } catch (error) {
          if (error instanceof TemplateBindingConsumptionError) {
            throw new WorkbenchOperationError(
              error.code || 'WORKBENCH_TEMPLATE_BINDING_INVALID',
              Number.isInteger(error.status) ? error.status : 409,
            )
          }
          throw error
        }
        let clips = timedSelections
        if (typeof capabilities.resolvePreviewSources === 'function') {
          clips = await capabilities.resolvePreviewSources({
            projectId,
            authorizationId: project.materials.authorizationId,
            selections: timedSelections,
          })
        }
        // Preview provider fails closed when voiceover is required without voiceId /
        // voiceoverSegments. A/B must reuse the same brief voice contract as preview jobs.
        const voiceoverSegments = project.storyboard.sentences
          .filter((/** @type {Record<string, any>} */ sentence) =>
            Boolean(sentence.selectedCandidateId) &&
            typeof sentence.text === 'string' &&
            sentence.text.trim())
          .map((/** @type {Record<string, any>} */ sentence) => ({
            sentenceId: sentence.id,
            text: sentence.text.trim(),
          }))
        return projectTemplateAbPreviewStore.generate(projectId, {
          brief: {
            orientation: project.brief.orientation,
            script: project.brief.script || project.brief.title || '模板对比',
            title: typeof project.brief.title === 'string' ? project.brief.title : '',
            voiceover: project.brief.voiceover || 'none',
            voiceId: project.brief.voiceId ?? null,
            voiceRate: Number.isFinite(project.brief.voiceRate) ? project.brief.voiceRate : 0,
            captions: project.brief.captions || 'auto',
            durationSeconds: project.brief.durationSeconds || binding.targetDurationSeconds,
            packaging: project.brief.packaging || emptyPackaging(),
          },
          clips,
          voiceoverSegments,
          templateGuidance: guidance,
          templateFingerprint: binding.fingerprint,
          templateRevision: binding.revision,
          libraryTemplateId: binding.libraryTemplateId,
        })
      },
    )
  }

  /** @param {string} projectId */
  const getTemplateAbPreview = async (projectId) => {
    if (!projectTemplateAbPreviewStore || typeof projectTemplateAbPreviewStore.get !== 'function') {
      throw new WorkbenchOperationError('TEMPLATE_AB_UNAVAILABLE', 503)
    }
    const project = readProject(projectId)
    if (!project) return null
    return projectTemplateAbPreviewStore.get(projectId)
  }

  /**
   * @param {string} projectId
   * @param {{ expectedJobId: string, expectedContentFingerprint: string }} input
   */
  const confirmTemplateAbPreview = async (projectId, input) => {
    if (
      !projectTemplateAbPreviewStore ||
      typeof projectTemplateAbPreviewStore.confirm !== 'function'
    ) {
      throw new WorkbenchOperationError('TEMPLATE_AB_UNAVAILABLE', 503)
    }
    if (
      !isRecord(input) ||
      typeof input.expectedJobId !== 'string' ||
      typeof input.expectedContentFingerprint !== 'string'
    ) {
      throw new WorkbenchOperationError('TEMPLATE_AB_INPUT_INVALID', 400)
    }
    const project = readProject(projectId)
    if (!project) return null
    return projectTemplateAbPreviewStore.confirm(projectId, input)
  }

  /**
   * @param {string} projectId
   * @param {'baseline' | 'template'} side
   */
  const resolveTemplateAbMedia = async (projectId, side) => {
    if (
      !projectTemplateAbPreviewStore ||
      typeof projectTemplateAbPreviewStore.resolveResource !== 'function'
    ) {
      throw new WorkbenchOperationError('TEMPLATE_AB_UNAVAILABLE', 503)
    }
    const project = readProject(projectId)
    if (!project) return null
    return projectTemplateAbPreviewStore.resolveResource(projectId, side)
  }

  const recoverPendingOutputInvalidations = async () => {
    const failures = []
    for (const project of readProjects()) {
      if (!project.pendingOutputInvalidation || project.pendingProjectDeletion) continue
      try {
        await resumeProjectOutputInvalidation(project.id)
      } catch (error) {
        const localError = error && typeof error === 'object'
          ? /** @type {{code?: unknown}} */ (error)
          : {}
        failures.push({
          projectId: project.id,
          code: typeof localError.code === 'string'
            ? localError.code
            : 'WORKBENCH_OUTPUT_INVALIDATION_RECOVERY_FAILED',
        })
      }
    }
    const pendingProjectIds = readProjects()
      .filter((project) => project.pendingOutputInvalidation)
      .map((project) => project.id)
    return {
      ready: pendingProjectIds.length === 0,
      pendingProjectIds,
      failures,
    }
  }
  const recoverPendingProjectMaintenance = async () => {
    const deletionRecovery = recoverPendingProjectDeletions()
    const invalidationRecovery = recoverPendingOutputInvalidations()
    const [deletion, invalidation] = await Promise.all([
      deletionRecovery,
      invalidationRecovery,
    ])
    const pendingProjectIds = [...new Set([
      ...deletion.pendingProjectIds,
      ...invalidation.pendingProjectIds,
    ])]
    return {
      ready: pendingProjectIds.length === 0,
      pendingProjectIds,
      failures: [...deletion.failures, ...invalidation.failures],
    }
  }
  const startupRecovery = recoverPendingProjectMaintenance()
  /** @param {string} projectId */
  const getWithJobs = async (projectId) => {
    let internalProject = readProject(projectId)
    if (!internalProject) return null
    if (!jobCoordinator || typeof jobCoordinator.listJobs !== 'function') {
      // Seeded synthetic projects already expose a ready preview. Materialize
      // the matching canonical timeline on the first authoritative read so
      // downstream preview/preflight controls see the same evidence as a
      // freshly completed AI edit.
      const timelineProject = internalProject
      const timeline = syntheticEditorTimelines.get(projectId) ?? (
        timelineProject.preview?.status === 'ready' ? createSyntheticEditorTimeline(timelineProject) : null
      )
      return {
        ...reviewedPublicProject(internalProject),
        ...(timeline ? {
          editorState: {
            status: 'complete',
            jobId: `job-editor-${projectId}`,
            summary: 'AI 已完成镜头编排',
            timeline: clone(timeline),
          },
          previewState: { status: timelineProject.preview?.status === 'ready' ? 'complete' : 'not_started' },
          deliveryState: {
            status: timelineProject.delivery?.exportJob?.state === 'ready_to_open' ? 'complete' : 'not_started',
            jobId: timelineProject.delivery?.exportJob?.id ?? null,
          },
        } : {}),
      }
    }
    const jobs = (await jobCoordinator.listJobs(projectId))
      .filter((/** @type {any} */ job) => job?.projectId === projectId)
      .filter((/** @type {any} */ job) =>
        !(
          outputTaskTypes.has(job.type) &&
          job.error?.code === 'WORKBENCH_JOB_INPUT_INVALIDATED'
        ))
      .sort((/** @type {any} */ left, /** @type {any} */ right) =>
        Date.parse(right.updatedAt) - Date.parse(left.updatedAt))
    // listJobs reconciles split job/project state. Re-read the project so the
    // same HTTP response reflects that repair instead of one stale poll.
    internalProject = readProject(projectId)
    if (!internalProject) return null
    const project = reviewedPublicProject(internalProject)
    const jobIds = new Set(jobs.map((/** @type {any} */ job) => job.jobId))
    const [editorState, previewState, deliveryState] = await Promise.all([
      typeof jobCoordinator.getEditorStageState === 'function'
        ? jobCoordinator.getEditorStageState(projectId)
        : null,
      typeof jobCoordinator.getPreviewStageState === 'function'
        ? jobCoordinator.getPreviewStageState(projectId, project.preview.resourceId)
        : null,
      typeof jobCoordinator.getDeliveryStageState === 'function'
        ? jobCoordinator.getDeliveryStageState(projectId, project.delivery.exportJob?.id)
        : null,
    ])
    const currentDeliveryJob = deliveryState?.jobId
      ? jobs.find((/** @type {any} */ job) =>
        job.jobId === deliveryState.jobId &&
        job.type === 'jianying_draft_export')
      : null
    const currentExportJob = project.delivery.exportJob?.id === deliveryState?.jobId
      ? project.delivery.exportJob
      : exportJobFromJianyingJob(currentDeliveryJob)
    // A successful, current Jianying job is stronger evidence than a stale
    // preflight snapshot from an earlier desktop detection failure. Keep the
    // public project state internally consistent so the overview does not
    // keep showing an impossible recovery action after a draft is ready.
    const deliveryCompleted =
      deliveryState?.status === 'complete' &&
      currentExportJob?.state === 'ready_to_open' &&
      Boolean(currentExportJob.result)
    const resolvedDelivery = deliveryCompleted
      ? {
          ...project.delivery,
          preflight: {
            ...project.delivery.preflight,
            status: 'ready',
            checks: project.delivery.preflight.checks.map((/** @type {any} */ check) => ({ ...check, status: 'pass' })),
          },
          exportJob: currentExportJob,
        }
      : {
          ...project.delivery,
          exportJob: currentExportJob ?? project.delivery.exportJob,
        }
    return {
      ...project,
      delivery: resolvedDelivery,
      editorState,
      previewState,
      deliveryState,
      tasks: [
        ...jobs.map(jobTask),
        ...project.tasks.filter((/** @type {any} */ task) => !jobIds.has(task.id)),
      ],
    }
  }
  /** @param {string} projectId */
  const launchJianyingDesktop = async (projectId) => {
    const project = await getWithJobs(projectId)
    if (!project) return null
    const exportJob = project.delivery?.exportJob
    if (
      project.deliveryState?.jobId !== exportJob?.id ||
      project.deliveryState?.status !== 'complete' ||
      exportJob?.state !== 'ready_to_open' ||
      !exportJob.result
    ) {
      throw new WorkbenchOperationError('JIANYING_DRAFT_NOT_READY', 409)
    }
    if (typeof capabilities.launchJianyingDesktop !== 'function') {
      throw new WorkbenchOperationError('JIANYING_DESKTOP_UNAVAILABLE', 503)
    }
    let launched
    try {
      launched = await capabilities.launchJianyingDesktop()
    } catch (error) {
      const candidate = error && typeof error === 'object'
        ? /** @type {{code?: unknown}} */ (error)
        : {}
      const code = ['JIANYING_DESKTOP_UNAVAILABLE', 'JIANYING_DESKTOP_LAUNCH_FAILED'].includes(String(candidate.code))
        ? String(candidate.code)
        : 'JIANYING_DESKTOP_LAUNCH_FAILED'
      throw new WorkbenchOperationError(code, 503)
    }
    if (
      !launched ||
      launched.schema_version !== 1 ||
      !['launched', 'already_running'].includes(launched.status) ||
      !safeText(launched.message, 200)
    ) {
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    const draftLabel = safeText(exportJob.result.draftLabel, 160) ? exportJob.result.draftLabel.trim() : ''
    const prefix = launched.message.includes('已切换到前台')
      ? '剪映已切换到前台。'
      : launched.message.includes('已在运行')
        ? '剪映已在运行。'
        : '剪映已启动。'
    const namedMessage = draftLabel ? `${prefix}请在首页点开「${draftLabel}」。` : launched.message
    if (!safeText(namedMessage, 200)) {
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    return {
      schema_version: 1,
      status: launched.status,
      message: namedMessage,
    }
  }
  /** @param {string} projectId @param {string} resourceId */
  const isCurrentEditorPreviewResource = async (projectId, resourceId) => {
    if (synthetic) return true
    const coordinator = requireJobCoordinator()
    return typeof coordinator.isCurrentEditorPreviewResource === 'function' &&
      await coordinator.isCurrentEditorPreviewResource(projectId, resourceId)
  }
  const listVoices = async () => {
    const curated = listCuratedVoices()
    if (synthetic || typeof capabilities.listVoices !== 'function') return curated
    const custom = await capabilities.listVoices()
    if (!Array.isArray(custom)) {
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    const normalized = custom.filter((voice) =>
      voice &&
      typeof voice === 'object' &&
      isVoiceId(voice.id) &&
      safeLabel(voice.label, 100) &&
      voice.gender === 'custom' &&
      voice.locale === 'zh-CN' &&
      (
        (
          voice.source === 'runninghub' &&
          voice.kind === 'cloned' &&
          (voice.referenceLabel == null || safeLabel(voice.referenceLabel, 100)) &&
          typeof voice.consentConfirmedAt === 'string' &&
          voice.ready === true
        ) ||
        (
          voice.source === 'jianying-preset' &&
          voice.kind === 'preset' &&
          voice.referenceLabel == null &&
          voice.consentConfirmedAt == null &&
          voice.ready === true
        )
      ))
      .map((voice) => {
        const publicVoice = structuredClone(voice)
        // Always emit exact WorkbenchVoice keys (jianying presets historically omitted nulls).
        if (!('referenceLabel' in publicVoice)) publicVoice.referenceLabel = null
        if (!('consentConfirmedAt' in publicVoice)) publicVoice.consentConfirmedAt = null
        // Strip legacy `（.m4a）` style labels before the public response gate.
        if (typeof publicVoice.referenceLabel === 'string') {
          publicVoice.referenceLabel = publicVoice.referenceLabel.replace(
            /（\.(aac|flac|m4a|mp3|ogg|wav)）/giu,
            '（$1）',
          )
        }
        return publicVoice
      })
    if (normalized.length !== custom.length) {
      throw new WorkbenchOperationError('WORKBENCH_CAPABILITY_RESPONSE_INVALID', 502)
    }
    return [...normalized, ...curated]
  }
  return {
    isSynthetic: synthetic,
    get,
    getWithJobs,
    launchJianyingDesktop,
    isCurrentEditorPreviewResource,
    list,
    listWithDeliveryJobs,
    listMaterialLibrary,
    getMaterialLibraryAsset,
    saveMaterialLibraryPreferences,
    addMaterialLibraryReference,
    addMaterialLibraryReferences,
    getMaterialLibraryReferenceState,
    importMaterialLibrary,
    listMaterialLibraryImportJobs,
    cancelMaterialLibraryImportJob,
    retryMaterialLibraryImportJob,
    dismissMaterialLibraryImportJob,
    reviewMaterialScene,
    listVoices,
    create,
    authorize: withActiveProjectMutation(authorize),
    authorizeBgm: withActiveProjectMutation(authorizeBgm),
    detachAudioTrack: withActiveProjectMutation(detachAudioTrack),
    authorizeReferenceVideo: withActiveProjectMutation(authorizeReferenceVideo),
    uploadReferenceVideo: withActiveProjectMutation(uploadReferenceVideo),
    analyze: withActiveProjectMutation(analyze),
    search,
    providerStatus,
    saveBrief: withActiveProjectMutation(saveBrief),
    generate: withActiveProjectMutation(generate),
    select: withActiveProjectMutation(select),
    searchMore: withActiveProjectMutation(searchMore),
    preview: withActiveProjectMutation(preview),
    finalizeVideo: withActiveProjectMutation(finalizeVideo),
    preflight: withActiveProjectMutation(preflight),
    exportDraft: withActiveProjectMutation(exportDraft),
    createDeliveryExport: withActiveProjectMutation(createDeliveryExport),
    recoverDelivery: withActiveProjectMutation(recoverDelivery),
    createJob: withActiveProjectMutation(createJob),
    getJob,
    listJobs,
    listJobsForProjects,
    cancelJob: withActiveProjectMutation(cancelJob),
    retryJob: withActiveProjectMutation(retryJob),
    dismissJobs: withActiveProjectMutation(dismissJobs),
    dismissFailedJobs: withActiveProjectMutation(dismissFailedJobs),
    deleteProject,
    renameProject: withActiveProjectMutation(renameProject),
    createJianyingDraft: withActiveProjectMutation(createJianyingDraft),
    createEditorAgent: withActiveProjectMutation(createEditorAgent),
    getEditorTimeline,
    createEditorPreview: withActiveProjectMutation(createEditorPreview),
    createEditorDraft: withActiveProjectMutation(createEditorDraft),
    createReferenceTemplate: withActiveProjectMutation(createReferenceTemplate),
    listReferenceTemplates,
    getReferenceTemplate,
    reviewReferenceTemplate: withActiveProjectMutation(reviewReferenceTemplate),
    listReusableTemplates,
    getReusableTemplate,
    uploadReusableTemplateVideo,
    authorizeReusableTemplateDraft,
    createReusableTemplate,
    reviewReusableTemplate,
    deactivateReusableTemplate,
    removeReusableTemplate,
    relabelReusableTemplate,
    reactivateReusableTemplate,
    createEditableReusableTemplateRevision,
    refreshReusableTemplateAssets,
    bindReusableTemplateVoice,
    bindReusableTemplateAudio,
    attachReusableTemplateReference,
    resolveReusableTemplateMedia,
    bindTemplate: withActiveProjectMutation(bindTemplate),
    unbindTemplate: withActiveProjectMutation(unbindTemplate),
    generateTemplateAbPreview: withActiveProjectMutation(generateTemplateAbPreview),
    getTemplateAbPreview,
    confirmTemplateAbPreview: withActiveProjectMutation(confirmTemplateAbPreview),
    resolveTemplateAbMedia,
    recoverPendingProjectMaintenance,
    recoverPendingOutputInvalidations,
    startupRecovery,
  }
}

/** @param {unknown} body @param {number} [status] @param {{allowAnalyzedMaterialsRoot?: boolean}} [options] */
const response = (body, status = 200, options = {}) => {
  const unsafe = status < 400 && hasForbiddenPublicField(body, [], options.allowAnalyzedMaterialsRoot === true)
  const payload = unsafe ? { error: { code: 'WORKBENCH_RESPONSE_UNSAFE', message: 'The workbench response was blocked.' } } : body
  return new Response(JSON.stringify(payload), { status: unsafe ? 500 : status, headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8', 'x-content-type-options': 'nosniff' } })
}
/** @param {Request} request @returns {Promise<any>} */
const readJson = async (request) => { try { return await request.json() } catch { return null } }
/** @param {unknown} value @param {string[]} keys */
const exactBody = (value, keys) =>
  Boolean(value) &&
  typeof value === 'object' &&
  !Array.isArray(value) &&
  Object.keys(/** @type {object} */ (value)).sort().join('\u0000') ===
    [...keys].sort().join('\u0000')
/** @param {unknown} value */
const exactEditorAgentJobBody = (value) => {
  const record = /** @type {Record<string, unknown>} */ (value)
  return (exactBody(value, ['instruction', 'baseTimeline', 'mode', 'automaticPackaging']) &&
    typeof record.automaticPackaging === 'boolean') ||
    (exactBody(value, ['instruction', 'baseTimeline', 'mode', 'automaticPackaging', 'packagingFeedbackHandle']) &&
      typeof record.automaticPackaging === 'boolean' &&
      (record.packagingFeedbackHandle === null || typeof record.packagingFeedbackHandle === 'string')) ||
    (
      exactBody(value, ['instruction', 'baseTimeline', 'mode', 'fresh', 'automaticPackaging']) &&
      typeof record.automaticPackaging === 'boolean' &&
      typeof record.fresh === 'boolean'
    ) || (
      exactBody(value, ['instruction', 'baseTimeline', 'mode', 'fresh', 'automaticPackaging', 'packagingFeedbackHandle']) &&
      typeof record.automaticPackaging === 'boolean' &&
      typeof record.fresh === 'boolean' &&
      (record.packagingFeedbackHandle === null || typeof record.packagingFeedbackHandle === 'string')
    ) ||
    exactBody(value, ['instruction', 'baseTimeline', 'mode']) ||
    (
      exactBody(value, ['instruction', 'baseTimeline', 'mode', 'fresh']) &&
      typeof record.fresh === 'boolean'
    )
}
/** @param {string} value */
const decodeRouteSegment = (value) => {
  try {
    const decoded = decodeURIComponent(value)
    return safeLabel(decoded, 200) ? decoded : null
  } catch {
    return null
  }
}
/** @param {Request} request @param {string} projectId @param {string} type */
const requestIdempotencyKey = (request, projectId, type) => {
  const supplied = request.headers.get('idempotency-key')
  if (supplied !== null) {
    if (!safeLabel(supplied, 160)) throw new WorkbenchOperationError('WORKBENCH_IDEMPOTENCY_KEY_INVALID', 400)
    return supplied.trim()
  }
  return randomUUID()
}
/** @param {unknown} error */
const workbenchErrorResponse = (error) => {
  const candidate = error && typeof error === 'object'
    ? /** @type {{code?: unknown, status?: unknown}} */ (error)
    : {}
  const code = typeof candidate.code === 'string' &&
    /^[A-Z][A-Z0-9_]{0,159}$/u.test(candidate.code)
    ? candidate.code
    : 'WORKBENCH_INTERNAL_FAILURE'
  const status = Number.isInteger(candidate.status) &&
    /** @type {number} */ (candidate.status) >= 400 &&
    /** @type {number} */ (candidate.status) <= 599
    ? /** @type {number} */ (candidate.status)
    : 500
  return response({
    error: {
      code,
      message: status === 404
        ? 'The requested workbench resource was not found.'
        : status === 409
          ? 'The workbench action conflicts with the current state.'
          : status < 500
            ? 'The workbench request is invalid.'
            : 'The workbench action failed safely.',
    },
  }, status)
}

/**
 * @param {{
 *   runtime: any,
 *   previewResourceProvider?: (input: any) => Promise<any>,
 *   candidateClipResourceProvider?: (input: {
 *     projectId: string,
 *     sentenceId: string,
 *     candidateId: string,
 *     project: any,
 *   }) => Promise<any>,
 *   candidatePosterResourceProvider?: (input: {
 *     projectId: string,
 *     sentenceId: string,
 *     candidateId: string,
 *     project: any,
 *   }) => Promise<any>,
 *   editorShotClipResourceProvider?: (input: {
 *     projectId: string,
 *     shotId: string,
 *     candidateId: string,
 *     sourceRange: {startUs: number, durationUs: number},
 *     project: any,
 *   }) => Promise<any>,
 * }} dependencies
 */
export const createWorkbenchHandler = ({
  runtime,
  previewResourceProvider,
  candidateClipResourceProvider,
  candidatePosterResourceProvider,
  editorShotClipResourceProvider,
}) => async (/** @type {Request} */ request) => {
  const requestUrl = new URL(request.url)
  const pathname = requestUrl.pathname
  const referenceTemplatesCollection = /^\/api\/workbench\/projects\/[^/]+\/reference-templates$/u.test(pathname)
  if (referenceTemplatesCollection && !['GET', 'POST'].includes(request.method)) {
    return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  }
  if (request.method === 'POST' || request.method === 'PUT') {
    const mediaType = request.headers.get('content-type')?.split(';', 1)[0].trim().toLowerCase()
    const acceptsMultipart = /\/(?:reference-templates)\/upload$/u.test(pathname) &&
      mediaType === 'multipart/form-data'
    if (mediaType !== 'application/json' && !acceptsMultipart) {
      return response({ error: { code: 'UNSUPPORTED_MEDIA_TYPE', message: 'Content type must be application/json.' } }, 415)
    }
  }
  if (pathname === '/api/workbench/material-analysis/status' && request.method === 'GET') {
    try {
      return response(runtime.providerStatus())
    } catch (error) {
      if (error instanceof WorkbenchOperationError) return response({ error: { code: error.code, message: 'The trusted local capability could not report its status.' } }, error.status)
      return response({ error: { code: 'WORKBENCH_INTERNAL_FAILURE', message: 'The workbench action failed safely.' } }, 500)
    }
  }
  if (pathname === '/api/workbench/voices' && request.method === 'GET') return response({ schema_version: 1, voices: await runtime.listVoices() })
  if (pathname === '/api/workbench/jobs' && request.method === 'GET') {
    const projectIds = requestUrl.searchParams.getAll('projectId')
      .flatMap((value) => value.split(','))
      .map((value) => value.trim())
      .filter(Boolean)
    if (!projectIds.length || projectIds.length > 20 || projectIds.some((id) => !safeLabel(id, 200))) {
      return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    if (typeof runtime.listJobsForProjects !== 'function') {
      return response({ error: { code: 'WORKBENCH_JOBS_UNAVAILABLE', message: 'The trusted local capability could not report task status.' } }, 503)
    }
    try {
      return response({ schema_version: 1, jobs: await runtime.listJobsForProjects(projectIds) })
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (pathname === '/api/workbench/material-library' && request.method === 'GET') {
    try {
      const url = new URL(request.url)
      const suppliedLimit = url.searchParams.get('limit')
      const limit = suppliedLimit === null ? undefined : Number(suppliedLimit)
      const cursor = url.searchParams.get('cursor')
      const refresh = url.searchParams.get('refresh')
      if ((suppliedLimit !== null && !Number.isSafeInteger(limit)) || (cursor !== null && !safeLabel(cursor, 200)) || (refresh !== null && !['0', '1'].includes(refresh))) {
        return response({ error: { code: 'MATERIAL_LIBRARY_PAGE_INVALID', message: 'Material library page is invalid.' } }, 400)
      }
      return response(await runtime.listMaterialLibrary({ limit, cursor, refresh: refresh === '1' }), 200, { allowAnalyzedMaterialsRoot: true })
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const materialLibraryAssetMatch = pathname.match(/^\/api\/workbench\/material-library\/assets\/([^/]+)$/u)
  if (materialLibraryAssetMatch && request.method === 'GET') {
    const assetId = decodeRouteSegment(materialLibraryAssetMatch[1])
    if (!assetId) return response({ error: { code: 'MATERIAL_LIBRARY_ASSET_INVALID', message: 'Material asset is invalid.' } }, 400)
    try {
      const result = await runtime.getMaterialLibraryAsset(assetId)
      return result
        ? response(result, 200, { allowAnalyzedMaterialsRoot: true })
        : response({ error: { code: 'MATERIAL_LIBRARY_UNAVAILABLE', message: 'The material library is unavailable.' } }, 503)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (pathname === '/api/workbench/material-library/import' && request.method === 'POST') {
    const body = await readJson(request)
    const valid = body && typeof body === 'object' && !Array.isArray(body) &&
      Object.keys(body).every((key) => ['folderLabel', 'sourceType', 'sessionId', 'nodeId'].includes(key)) &&
      (body.sourceType === undefined || body.sourceType === 'folder' || body.sourceType === 'file' || body.sourceType === 'auto') &&
      (body.folderLabel === undefined || safeLabel(body.folderLabel, 100)) &&
      (body.sessionId === undefined || safeLabel(body.sessionId, 160)) &&
      (body.nodeId === undefined || safeLabel(body.nodeId, 160))
    if (!valid) return response({ error: { code: 'MATERIAL_LIBRARY_IMPORT_INVALID', message: 'Material import selection is invalid.' } }, 400)
    try {
      const result = await runtime.importMaterialLibrary(body)
      return response(result, 202)
    } catch (error) {
      const typedError = /** @type {{code?: unknown, status?: unknown}} */ (error)
      const code = typeof typedError?.code === 'string' ? typedError.code : 'MATERIAL_LIBRARY_IMPORT_FAILED'
      const status = Number.isInteger(typedError?.status) ? Number(typedError.status) : 503
      return response({ error: { code, message: 'Material library import failed safely.' } }, status)
    }
  }
  if (pathname === '/api/workbench/material-library/import-jobs' && request.method === 'GET') {
    try {
      return response(await runtime.listMaterialLibraryImportJobs())
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const materialLibraryImportJobMatch = pathname.match(/^\/api\/workbench\/material-library\/import-jobs\/([^/]+)\/(cancel|retry|dismiss)$/u)
  if (materialLibraryImportJobMatch && request.method === 'POST') {
    const jobId = decodeRouteSegment(materialLibraryImportJobMatch[1])
    if (!jobId) return response({ error: { code: 'MATERIAL_LIBRARY_IMPORT_JOB_INVALID', message: 'Import job is invalid.' } }, 400)
    try {
      const action = materialLibraryImportJobMatch[2]
      const job = action === 'cancel'
        ? await runtime.cancelMaterialLibraryImportJob(jobId)
        : action === 'retry'
          ? await runtime.retryMaterialLibraryImportJob(jobId)
          : await runtime.dismissMaterialLibraryImportJob(jobId)
      return response({ schema_version: 1, job })
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (pathname === '/api/workbench/material-library/preferences' && request.method === 'POST') {
    try {
      const body = await readJson(request)
      if (!body || typeof body !== 'object' || Array.isArray(body) || !Object.hasOwn(body, 'preferences')) {
        return response({ error: { code: 'MATERIAL_LIBRARY_PREFERENCES_INVALID', message: 'Library preferences are invalid.' } }, 400)
      }
      return response(await runtime.saveMaterialLibraryPreferences(body.preferences))
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const materialLibraryReferenceMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/material-library\/references$/u,
  )
  if (materialLibraryReferenceMatch && request.method === 'POST') {
    const projectId = decodeRouteSegment(materialLibraryReferenceMatch[1])
    if (!projectId) return response({ error: { code: 'WORKBENCH_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    try {
      const body = await readJson(request)
      const result = isRecord(body) && Array.isArray(body.references)
        ? await runtime.addMaterialLibraryReferences(projectId, body)
        : await runtime.addMaterialLibraryReference(projectId, body)
      return result
        ? response(result, 201)
        : response({ error: { code: 'MATERIAL_LIBRARY_UNAVAILABLE', message: 'The material library is unavailable.' } }, 503)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (materialLibraryReferenceMatch && request.method === 'GET') {
    const projectId = decodeRouteSegment(materialLibraryReferenceMatch[1])
    if (!projectId) return response({ error: { code: 'WORKBENCH_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    try {
      return response(await runtime.getMaterialLibraryReferenceState(projectId))
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const materialReviewMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/materials\/assets\/([^/]+)\/scenes\/([^/]+)\/review$/u,
  )
  if (materialReviewMatch && request.method === 'POST') {
    const projectId = decodeRouteSegment(materialReviewMatch[1])
    const assetId = decodeRouteSegment(materialReviewMatch[2])
    const sceneId = decodeRouteSegment(materialReviewMatch[3])
    const body = await readJson(request)
    if (
      !projectId || !assetId || !sceneId ||
      !exactBody(body, ['status', 'correction']) ||
      !['confirmed', 'needsReview', 'unavailable'].includes(body.status) ||
      !body.correction || typeof body.correction !== 'object' || Array.isArray(body.correction)
    ) {
      return response({ error: { code: 'MATERIAL_REVIEW_INPUT_INVALID', message: 'Material review input is invalid.' } }, 400)
    }
    try {
      return response(await runtime.reviewMaterialScene(projectId, assetId, sceneId, body))
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (pathname === '/api/workbench/projects' && request.method === 'GET') {
    const projects = typeof runtime.listWithDeliveryJobs === 'function'
      ? await runtime.listWithDeliveryJobs()
      : runtime.list()
    return response({ schema_version: 1, projects })
  }
  if (pathname === '/api/workbench/projects' && request.method === 'POST') { const project = runtime.create(await readJson(request)); return project ? response(project, 201) : response({ error: { code: 'PROJECT_INPUT_INVALID', message: 'Project details need attention.' } }, 400) }
  const jianyingLaunchMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/delivery\/jianying\/launch$/u,
  )
  if (jianyingLaunchMatch) {
    if (request.method !== 'POST') {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const projectId = decodeRouteSegment(jianyingLaunchMatch[1])
    if (!projectId) {
      return response({ error: { code: 'WORKBENCH_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    const body = await readJson(request)
    if (!exactBody(body, [])) {
      return response({ error: { code: 'WORKBENCH_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    try {
      const result = await runtime.launchJianyingDesktop(projectId)
      return result
        ? response(result)
        : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const reusableTemplateMatch = pathname.match(
    /^\/api\/workbench\/template-library(?:\/([^/]+)(?:\/(review|deactivate|remove|relabel|reactivate|create-editable-revision|refresh-assets|bind-voice|bind-audio|attach-reference|reference|demo)(?:\/(content))?)?)?$/u,
  )
  if (reusableTemplateMatch) {
    const rawTemplateId = reusableTemplateMatch[1] ?? null
    const libraryTemplateId = rawTemplateId &&
      rawTemplateId !== 'upload' &&
      rawTemplateId !== 'authorize-draft'
      ? decodeRouteSegment(rawTemplateId)
      : null
    const action = reusableTemplateMatch[2] ?? null
    const mediaAction = reusableTemplateMatch[3] ?? null
    if (
      rawTemplateId &&
      rawTemplateId !== 'upload' &&
      rawTemplateId !== 'authorize-draft' &&
      !libraryTemplateId
    ) {
      return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    try {
      if (!rawTemplateId && request.method === 'GET') {
        return response({
          schema_version: 1,
          templates: await runtime.listReusableTemplates(),
        })
      }
      if (!rawTemplateId && request.method === 'POST') {
        const body = await readJson(request)
        if (!isReusableTemplateCreateCommand(body)) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.createReusableTemplate(body), 201)
      }
      if (rawTemplateId === 'upload' && request.method === 'POST') {
        const body = await readJson(request)
        const pickerBody = exactBody(body, ['nodeId', 'readOnlyConfirmed', 'sessionId'])
        const nativeBody = exactBody(body, ['readOnlyConfirmed'])
        if (!pickerBody && !nativeBody) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_UPLOAD_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.uploadReusableTemplateVideo(body), 201)
      }
      if (rawTemplateId === 'authorize-draft' && request.method === 'POST') {
        const body = await readJson(request)
        const pickerBody = exactBody(body, ['nodeId', 'readOnlyConfirmed', 'sessionId'])
        const nativeBody = exactBody(body, ['readOnlyConfirmed'])
        if (!pickerBody && !nativeBody) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_DRAFT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.authorizeReusableTemplateDraft(body), 201)
      }
      if (
        libraryTemplateId &&
        (action === 'reference' || action === 'demo') &&
        mediaAction === 'content' &&
        (request.method === 'GET' || request.method === 'HEAD')
      ) {
        const resource = await runtime.resolveReusableTemplateMedia(
          libraryTemplateId,
          action,
        )
        return createPreviewMediaResponse({
          resource,
          rangeHeader: request.headers.get('range'),
          method: request.method,
        })
      }
      if (libraryTemplateId && !action && request.method === 'GET') {
        const detail = await runtime.getReusableTemplate(libraryTemplateId)
        return detail
          ? response(detail)
          : response({ error: { code: 'REUSABLE_TEMPLATE_NOT_FOUND', message: 'The requested workbench resource was not found.' } }, 404)
      }
      if (libraryTemplateId && action === 'review' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['decision', 'expectedRevision'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_REVIEW_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.reviewReusableTemplate(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'deactivate' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_DEACTIVATE_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.deactivateReusableTemplate(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'remove' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_REMOVE_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.removeReusableTemplate(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'relabel' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision', 'label'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_RELABEL_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.relabelReusableTemplate(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'reactivate' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_REACTIVATE_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.reactivateReusableTemplate(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'create-editable-revision' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_REVISION_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.createEditableReusableTemplateRevision(libraryTemplateId, body), 201)
      }
      if (libraryTemplateId && action === 'refresh-assets' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_REFRESH_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.refreshReusableTemplateAssets(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'bind-voice' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision', 'voiceProfileId'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_VOICE_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.bindReusableTemplateVoice(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'bind-audio' && request.method === 'POST') {
        const body = await readJson(request)
        if (
          !exactBody(body, ['expectedRevision', 'role', 'sourceAuthorizationId']) ||
          (body.role !== 'bgm' && body.role !== 'sfx')
        ) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_AUDIO_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.bindReusableTemplateAudio(libraryTemplateId, body))
      }
      if (libraryTemplateId && action === 'attach-reference' && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision', 'sourceAuthorizationId'])) {
          return response({ error: { code: 'REUSABLE_TEMPLATE_ATTACH_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response(await runtime.attachReusableTemplateReference(libraryTemplateId, body))
      }
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const referenceAuthorizationMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/reference-templates\/(authorize-local|upload)$/u,
  )
  if (referenceAuthorizationMatch) {
    const projectId = decodeRouteSegment(referenceAuthorizationMatch[1])
    if (!projectId) return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    try {
      if (request.method !== 'POST') return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
      if (referenceAuthorizationMatch[2] === 'authorize-local') {
        const body = await readJson(request)
        const pickerBody = exactBody(body, ['nodeId', 'readOnlyConfirmed', 'sessionId'])
        const nativeBody = exactBody(body, ['readOnlyConfirmed'])
        if (!pickerBody && !nativeBody) {
          return response({ error: { code: 'WORKBENCH_REFERENCE_VIDEO_AUTHORIZATION_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        const authorized = await runtime.authorizeReferenceVideo(projectId, body)
        return authorized
          ? response(authorized)
          : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
      }
      const contentType = request.headers.get('content-type') ?? ''
      if (contentType.includes('application/json')) {
        const jsonBody = await readJson(request)
        const pickerBody = exactBody(jsonBody, ['nodeId', 'readOnlyConfirmed', 'sessionId'])
        const nativeBody = exactBody(jsonBody, ['readOnlyConfirmed'])
        if (!pickerBody && !nativeBody) {
          return response({ error: { code: 'WORKBENCH_REFERENCE_VIDEO_UPLOAD_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        const uploaded = await runtime.uploadReferenceVideo(projectId, jsonBody)
        return uploaded
          ? response(uploaded, 201)
          : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
      }
      if (runtime.isSynthetic) {
        const formData = await request.formData().catch(() => null)
        const file = formData?.get('file')
        if (file && typeof file === 'object' && typeof file.arrayBuffer === 'function') {
          const uploaded = await runtime.uploadReferenceVideo(projectId, { file })
          return uploaded
            ? response(uploaded, 201)
            : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
        }
      }
      return response({ error: { code: 'WORKBENCH_REFERENCE_VIDEO_UPLOAD_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const referenceTemplatesMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/reference-templates(?:\/([^/]+)(?:\/review)?)?$/u,
  )
  if (referenceTemplatesMatch) {
    const projectId = decodeRouteSegment(referenceTemplatesMatch[1])
    const referenceTemplateId = referenceTemplatesMatch[2]
      ? decodeRouteSegment(referenceTemplatesMatch[2])
      : null
    if (!projectId || (referenceTemplatesMatch[2] && !referenceTemplateId)) {
      return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    try {
      const isReview = pathname.endsWith('/review')
      if (!referenceTemplateId && request.method === 'GET') {
        const templates = await runtime.listReferenceTemplates(projectId)
        return templates
          ? response({ schema_version: 1, referenceTemplates: templates })
          : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
      }
      if (!referenceTemplateId && request.method === 'POST') {
        const body = await readJson(request)
        if (
          !exactBody(body, ['assetId', 'templateSelectionRequest']) &&
          !exactBody(body, ['referenceAuthorizationId', 'templateSelectionRequest'])
        ) {
          return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        const job = await runtime.createReferenceTemplate(projectId, body, {
          idempotencyKey: requestIdempotencyKey(
            request,
            projectId,
            'reference_template_generation',
          ),
        })
        return job
          ? response(job, 202)
          : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
      }
      if (referenceTemplateId && !isReview && request.method === 'GET') {
        const detail = await runtime.getReferenceTemplate(projectId, referenceTemplateId)
        return detail
          ? response(detail)
          : response({ error: { code: 'REFERENCE_TEMPLATE_NOT_FOUND', message: 'The requested workbench resource was not found.' } }, 404)
      }
      if (referenceTemplateId && isReview && request.method === 'POST') {
        const reviewed = await runtime.reviewReferenceTemplate(
          projectId,
          referenceTemplateId,
          await readJson(request),
        )
        return reviewed
          ? response(reviewed)
          : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
      }
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const editorOutputMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/editor\/(preview|jianying)\/jobs$/u,
  )
  if (editorOutputMatch) {
    const projectId = decodeRouteSegment(editorOutputMatch[1])
    const kind = editorOutputMatch[2]
    if (!projectId) {
      return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    if (request.method !== 'POST') {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    try {
      const body = await readJson(request)
      if (!exactBody(body, ['revision', 'revisionFingerprint', 'timelineId'])) {
        return response({
          error: {
            code: 'WORKBENCH_JOB_INPUT_INVALID',
            message: 'The workbench request is invalid.',
          },
        }, 400)
      }
      const options = {
        idempotencyKey: requestIdempotencyKey(
          request,
          projectId,
          kind === 'preview' ? 'editor_preview' : 'editor_jianying',
        ),
      }
      const job = kind === 'preview'
        ? await runtime.createEditorPreview(projectId, body, options)
        : await runtime.createEditorDraft(projectId, body, options)
      return job
        ? response(job, 202)
        : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const editorTimelineMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/editor\/timeline$/u,
  )
  if (editorTimelineMatch) {
    const projectId = decodeRouteSegment(editorTimelineMatch[1])
    if (!projectId) {
      return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    if (request.method !== 'GET') {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    try {
      const timeline = await runtime.getEditorTimeline(projectId)
      return timeline
        ? response(timeline)
        : response({ schema_version: 1, timeline: null })
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const editorJobsMatch = pathname.match(/^\/api\/workbench\/projects\/([^/]+)\/editor\/jobs$/u)
  if (editorJobsMatch) {
    const projectId = decodeRouteSegment(editorJobsMatch[1])
    if (!projectId) {
      return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    if (request.method !== 'POST') {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    try {
      const body = await readJson(request)
      if (!exactEditorAgentJobBody(body)) {
        return response({
          error: {
            code: 'WORKBENCH_JOB_INPUT_INVALID',
            message: 'The workbench request is invalid.',
          },
        }, 400)
      }
      const job = await runtime.createEditorAgent(projectId, body, {
        idempotencyKey: requestIdempotencyKey(request, projectId, 'editor_agent'),
      })
      return job
        ? response(job, 202)
        : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const jobsMatch = pathname.match(/^\/api\/workbench\/projects\/([^/]+)\/jobs(?:\/([^/]+)(?:\/(cancel|retry|dismiss))?)?$/u)
  if (jobsMatch) {
    const projectId = decodeRouteSegment(jobsMatch[1])
    const jobId = jobsMatch[2] ? decodeRouteSegment(jobsMatch[2]) : null
    const action = jobsMatch[3] ?? null
    if (!projectId || (jobsMatch[2] && !jobId)) {
      return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
    }
    try {
      if (!jobId && !action && request.method === 'GET') {
        return response({ schema_version: 1, jobs: await runtime.listJobs(projectId) })
      }
      if (!jobId && !action && request.method === 'POST') {
        const body = await readJson(request)
        if (
          !(exactBody(body, ['type']) || exactBody(body, ['type', 'assetId'])) ||
          !['material_analysis', 'storyboard_generation', 'preview_generation'].includes(body.type)
          || (body.assetId !== undefined && (!safeLabel(body.assetId, 160) || body.type !== 'material_analysis'))
        ) {
          return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        const job = await runtime.createJob(projectId, {
          type: body.type,
          ...(body.assetId ? { assetId: body.assetId } : {}),
          idempotencyKey: requestIdempotencyKey(request, projectId, body.type),
        })
        return response(job, 202)
      }
      if (jobId === 'dismiss-failed' && !action && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, [])) {
          return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        return response({
          schema_version: 1,
          dismissedJobIds: await runtime.dismissFailedJobs(projectId),
        })
      }
      if (jobId && !action && request.method === 'GET') {
        const job = await runtime.getJob(projectId, jobId)
        return job
          ? response(job)
          : response({ error: { code: 'WORKBENCH_JOB_NOT_FOUND', message: 'The requested workbench resource was not found.' } }, 404)
      }
      if (jobId && action && request.method === 'POST') {
        const body = await readJson(request)
        if (!exactBody(body, [])) {
          return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        if (action === 'dismiss') {
          return response({
            schema_version: 1,
            dismissedJobIds: await runtime.dismissJobs(projectId, [jobId]),
          })
        }
        const job = action === 'cancel'
          ? await runtime.cancelJob(projectId, jobId)
          : await runtime.retryJob(projectId, jobId)
        return job
          ? response(job)
          : response({ error: { code: 'WORKBENCH_JOB_NOT_FOUND', message: 'The requested workbench resource was not found.' } }, 404)
      }
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const editorShotClipMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/editor\/timeline\/shots\/([^/]+)\/content$/u,
  )
  if (editorShotClipMatch) {
    if (!['GET', 'HEAD'].includes(request.method)) {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const projectId = decodeRouteSegment(editorShotClipMatch[1])
    const shotId = decodeRouteSegment(editorShotClipMatch[2])
    if (!projectId || !shotId) {
      return response({ error: { code: 'EDITOR_SHOT_CLIP_INPUT_INVALID', message: 'Shot preview request is invalid.' } }, 400)
    }
    const project = runtime.get(projectId)
    if (!project) return response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    const timeline = await runtime.getEditorTimeline(projectId)
    const shot = timeline?.status === 'finalized'
      ? timeline.shots?.find((/** @type {any} */ item) => item.shotId === shotId)
      : null
    if (!shot || !safeLabel(shot.candidateId, 160)) {
      return response({ error: { code: 'EDITOR_SHOT_CLIP_NOT_FOUND', message: 'Shot preview is unavailable.' } }, 404)
    }
    if (!editorShotClipResourceProvider) {
      return response({ error: { code: 'EDITOR_SHOT_CLIP_UNAVAILABLE', message: 'Shot preview is unavailable.' } }, 503)
    }
    try {
      const resource = await editorShotClipResourceProvider({
        projectId,
        shotId,
        candidateId: shot.candidateId,
        sourceRange: shot.sourceRange,
        project,
      })
      if (!resource) return response({ error: { code: 'EDITOR_SHOT_CLIP_UNAVAILABLE', message: 'Shot preview is unavailable.' } }, 503)
      return createPreviewMediaResponse({
        resource,
        rangeHeader: request.headers.get('range'),
        method: request.method,
        cacheControl: 'private, no-cache',
        ifNoneMatch: request.headers.get('if-none-match'),
      })
    } catch {
      return response({ error: { code: 'EDITOR_SHOT_CLIP_UNAVAILABLE', message: 'Shot preview is unavailable.' } }, 503)
    }
  }
  const candidateMediaMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/storyboard\/candidates\/([^/]+)\/(content|poster)$/u,
  )
  if (candidateMediaMatch) {
    if (!['GET', 'HEAD'].includes(request.method)) {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const kind = candidateMediaMatch[3]
    const poster = kind === 'poster'
    const inputCode = poster ? 'CANDIDATE_POSTER_INPUT_INVALID' : 'CANDIDATE_CLIP_INPUT_INVALID'
    const missingCode = poster ? 'CANDIDATE_POSTER_NOT_FOUND' : 'CANDIDATE_CLIP_NOT_FOUND'
    const unavailableCode = poster ? 'CANDIDATE_POSTER_UNAVAILABLE' : 'CANDIDATE_CLIP_UNAVAILABLE'
    const projectId = decodeURIComponent(candidateMediaMatch[1])
    const candidateId = decodeURIComponent(candidateMediaMatch[2])
    const sentenceId = new URL(request.url).searchParams.get('sentenceId')
    if (
      !safeLabel(projectId, 160) ||
      !safeLabel(candidateId, 160) ||
      !sentenceId ||
      !safeLabel(sentenceId, 160)
    ) {
      return response({ error: { code: inputCode, message: 'Candidate preview request is invalid.' } }, 400)
    }
    const project = runtime.get(projectId)
    if (!project) return response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    const sentence = project.storyboard?.sentences?.find((/** @type {any} */ item) => item.id === sentenceId)
    if (!sentence?.candidates?.some((/** @type {any} */ item) => item.id === candidateId)) {
      return response({ error: { code: missingCode, message: 'Candidate preview is unavailable.' } }, 404)
    }
    const provider = poster
      ? candidatePosterResourceProvider
        ?? (async ({ candidateId: id }) => createSyntheticCandidatePosterResource({ candidateId: id }))
      : candidateClipResourceProvider
        ?? (async ({ candidateId: id }) => createSyntheticCandidateClipResource({ candidateId: id }))
    try {
      const resource = await provider({
        projectId,
        sentenceId,
        candidateId,
        project,
      })
      if (!resource) {
        return response({ error: { code: unavailableCode, message: 'Candidate preview is unavailable.' } }, 503)
      }
      return createPreviewMediaResponse({
        resource,
        rangeHeader: request.headers.get('range'),
        method: request.method,
        cacheControl: 'private, no-cache',
        ifNoneMatch: request.headers.get('if-none-match'),
      })
    } catch (error) {
      if (error instanceof WorkbenchPreviewError) {
        return response({ error: { code: error.code, message: 'Candidate preview is unavailable.' } }, 503)
      }
      return response({ error: { code: unavailableCode, message: 'Candidate preview is unavailable.' } }, 503)
    }
  }
  const templateBindingMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/template-binding$/u,
  )
  if (templateBindingMatch) {
    if (!['POST', 'DELETE'].includes(request.method)) {
      return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    }
    const projectId = decodeRouteSegment(templateBindingMatch[1])
    if (!projectId) {
      return response({ error: { code: 'WORKBENCH_TEMPLATE_BINDING_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    const body = await readJson(request)
    const validPostBody = request.method === 'POST' && (
      exactBody(body, ['expectedProjectUpdatedAt', 'expectedRevision', 'libraryTemplateId']) ||
      exactBody(body, [
        'blendLibraryTemplateId',
        'expectedBlendRevision',
        'expectedProjectUpdatedAt',
        'expectedRevision',
        'libraryTemplateId',
      ])
    )
    const validDeleteBody = request.method === 'DELETE' &&
      exactBody(body, ['expectedProjectUpdatedAt'])
    if (!validPostBody && !validDeleteBody) {
      return response({ error: { code: 'WORKBENCH_TEMPLATE_BINDING_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    try {
      const result = request.method === 'POST'
        ? await runtime.bindTemplate(projectId, body)
        : await runtime.unbindTemplate(projectId, body)
      return result
        ? response(result)
        : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  const templateAbMatch = pathname.match(
    /^\/api\/workbench\/projects\/([^/]+)\/template-ab(?:\/(confirm|baseline\/content|template\/content))?$/u,
  )
  if (templateAbMatch) {
    const projectId = decodeRouteSegment(templateAbMatch[1])
    const action = templateAbMatch[2] || ''
    if (!projectId) {
      return response({ error: { code: 'TEMPLATE_AB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    if (!action) {
      if (!['GET', 'POST'].includes(request.method)) {
        return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
      }
      try {
        if (request.method === 'GET') {
          const result = await runtime.getTemplateAbPreview(projectId)
          return result
            ? response(result)
            : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
        }
        const body = await readJson(request)
        if (!exactBody(body, ['expectedRevision', 'libraryTemplateId'])) {
          return response({ error: { code: 'TEMPLATE_AB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
        }
        const result = await runtime.generateTemplateAbPreview(projectId, body)
        return result
          ? response(result)
          : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
      } catch (error) {
        return workbenchErrorResponse(error)
      }
    }
    if (action === 'confirm') {
      if (request.method !== 'POST') {
        return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
      }
      const body = await readJson(request)
      if (!exactBody(body, ['expectedContentFingerprint', 'expectedJobId'])) {
        return response({ error: { code: 'TEMPLATE_AB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      }
      try {
        const result = await runtime.confirmTemplateAbPreview(projectId, body)
        return result
          ? response(result)
          : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
      } catch (error) {
        return workbenchErrorResponse(error)
      }
    }
    if (action === 'baseline/content' || action === 'template/content') {
      if (!['GET', 'HEAD'].includes(request.method)) {
        return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
      }
      try {
        const resource = await runtime.resolveTemplateAbMedia(
          projectId,
          action.startsWith('baseline') ? 'baseline' : 'template',
        )
        if (!resource) {
          return response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
        }
        return createPreviewMediaResponse({
          resource,
          rangeHeader: request.headers.get('range'),
          method: request.method,
        })
      } catch (error) {
        return workbenchErrorResponse(error)
      }
    }
  }
  const previewMatch = pathname.match(/^\/api\/workbench\/projects\/([^/]+)\/preview\/content$/u)
  if (previewMatch) {
    if (!['GET', 'HEAD'].includes(request.method)) return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    const id = decodeURIComponent(previewMatch[1])
    const project = runtime.get(id)
    if (!project) return response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    if (project.preview.status !== 'ready' || !project.preview.resourceId) return response({ error: { code: 'PREVIEW_NOT_READY', message: 'Preview is not ready.' } }, 409)
    if (
      runtime.isSynthetic === false &&
      (
        typeof runtime.isCurrentEditorPreviewResource !== 'function' ||
        !await runtime.isCurrentEditorPreviewResource(id, project.preview.resourceId)
      )
    ) return response({ error: { code: 'WORKBENCH_EDITOR_BOUND_OUTPUT_REQUIRED', message: 'The current editor preview is required.' } }, 409)
    if (!previewResourceProvider) return response({ error: { code: 'PREVIEW_RESOURCE_UNAVAILABLE', message: 'Preview playback is unavailable.' } }, 503)
    try {
      const resource = await previewResourceProvider({ projectId: id, resourceId: project.preview.resourceId, durationSeconds: project.preview.durationSeconds })
      if (!resource) return response({ error: { code: 'PREVIEW_RESOURCE_UNAVAILABLE', message: 'Preview playback is unavailable.' } }, 503)
      return createPreviewMediaResponse({ resource, rangeHeader: request.headers.get('range'), method: request.method })
    } catch (error) {
      if (error instanceof WorkbenchPreviewError) return response({ error: { code: error.code, message: 'Preview playback is unavailable.' } }, 503)
      return response({ error: { code: 'PREVIEW_RESOURCE_UNAVAILABLE', message: 'Preview playback is unavailable.' } }, 503)
    }
  }
  const finalMatch = pathname.match(/^\/api\/workbench\/projects\/([^/]+)\/final\/content$/u)
  if (finalMatch) {
    if (!['GET', 'HEAD'].includes(request.method)) return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
    const id = decodeURIComponent(finalMatch[1])
    const project = runtime.get(id)
    if (!project) return response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    // The current preview is the canonical final output. Keep the legacy
    // finalized artifact as a fallback for persisted projects without one.
    const finalVideo = project.preview?.status === 'ready' && project.preview.resourceId
      ? project.preview
      : project.delivery?.finalVideo?.status === 'ready'
        ? project.delivery.finalVideo
        : null
    if (!finalVideo?.resourceId) return response({ error: { code: 'FINAL_VIDEO_NOT_READY', message: 'Final video is not ready.' } }, 409)
    if (
      runtime.isSynthetic === false &&
      (
        project.preview?.status !== 'ready' ||
        !project.preview.resourceId ||
        typeof runtime.isCurrentEditorPreviewResource !== 'function' ||
        !await runtime.isCurrentEditorPreviewResource(id, project.preview.resourceId)
      )
    ) return response({ error: { code: 'WORKBENCH_EDITOR_BOUND_OUTPUT_REQUIRED', message: 'The current editor preview is required.' } }, 409)
    if (!previewResourceProvider) return response({ error: { code: 'FINAL_VIDEO_RESOURCE_UNAVAILABLE', message: 'Final video download is unavailable.' } }, 503)
    try {
      const resource = await previewResourceProvider({
        projectId: id,
        resourceId: finalVideo.resourceId,
        durationSeconds: finalVideo.durationSeconds,
      })
      if (!resource) return response({ error: { code: 'FINAL_VIDEO_RESOURCE_UNAVAILABLE', message: 'Final video download is unavailable.' } }, 503)
      return createPreviewMediaResponse({
        resource,
        rangeHeader: request.headers.get('range'),
        method: request.method,
        contentDisposition: 'attachment; filename="openvideo-final.mp4"',
      })
    } catch {
      return response({ error: { code: 'FINAL_VIDEO_RESOURCE_UNAVAILABLE', message: 'Final video download is unavailable.' } }, 503)
    }
  }
  const match = pathname.match(/^\/api\/workbench\/projects\/([^/]+)(?:\/(materials|brief|storyboard|preview|delivery))?(?:\/(authorize|authorize-bgm|analyze|search|save|generate|selection|preflight|export|recover|finalize))?$/u)
  if (!match) return response({ error: { code: 'NOT_FOUND', message: 'Route not found.' } }, 404)
  // The project response is the source of truth for the workflow UI. Prefer
  // the reconciled job/timeline projection after a restart or refresh, while
  // preserving navigation if that optional projection is transiently offline.
  const id = decodeURIComponent(match[1])
  if (request.method === 'GET' && !match[2]) {
    let project
    if (requestUrl.searchParams.get('view') === 'navigation') {
      // Route entry only needs the persisted project snapshot. ProjectPage
      // immediately reconciles jobs and requests the authoritative aggregate
      // in the background when newer activity exists.
      project = await runtime.get(id)
    } else if (typeof runtime.getWithJobs === 'function') {
      try {
        project = await runtime.getWithJobs(id)
      } catch {
        // Keep project navigation available when the optional live-job
        // projection is temporarily unavailable. The next poll retries it.
        project = runtime.get(id)
      }
    } else {
      project = runtime.get(id)
    }
    return project
      ? response(project)
      : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
  }
  if (request.method === 'DELETE' && !match[2]) {
    const body = await readJson(request)
    if (
      !exactBody(body, ['expectedUpdatedAt']) ||
      !isTimestamp(body.expectedUpdatedAt)
    ) {
      return response({ error: { code: 'WORKBENCH_PROJECT_DELETE_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    try {
      const deleted = await runtime.deleteProject(id, body)
      return deleted
        ? response({ schema_version: 1, ...deleted })
        : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (request.method === 'PUT' && !match[2]) {
    const body = await readJson(request)
    if (
      !exactBody(body, ['name', 'expectedUpdatedAt']) ||
      !safeLabel(body.name, 100) ||
      !isTimestamp(body.expectedUpdatedAt)
    ) {
      return response({ error: { code: 'WORKBENCH_PROJECT_RENAME_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
    }
    try {
      const project = await runtime.renameProject(id, body)
      return project
        ? response(project)
        : response({ error: { code: 'PROJECT_NOT_FOUND', message: 'Project not found.' } }, 404)
    } catch (error) {
      return workbenchErrorResponse(error)
    }
  }
  if (request.method !== 'POST') return response({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  const body = await readJson(request); let result = null
  try {
    if (match[2] === 'materials' && match[3] === 'authorize') {
      const nativeBody = exactBody(body, ['folderLabel', 'readOnlyConfirmed']) ||
        exactBody(body, ['folderLabel', 'readOnlyConfirmed', 'sourceType'])
      const pickerBody = exactBody(body, ['folderLabel', 'nodeId', 'readOnlyConfirmed', 'sessionId', 'sourceType'])
      if (!nativeBody && !pickerBody) {
        return response({ error: { code: 'WORKBENCH_MATERIAL_AUTHORIZATION_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      }
      result = await runtime.authorize(id, body)
    }
    if (match[2] === 'brief' && match[3] === 'authorize-bgm') {
      const pickerBody = exactBody(body, ['nodeId', 'readOnlyConfirmed', 'sessionId'])
      const nativeBody = exactBody(body, ['readOnlyConfirmed'])
      if (!pickerBody && !nativeBody) {
        return response({ error: { code: 'WORKBENCH_BGM_AUTHORIZATION_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      }
      result = await runtime.authorizeBgm(id, body)
    }
    if (match[2] === 'materials' && match[3] === 'analyze') {
      if (!(exactBody(body, []) || (exactBody(body, ['assetId']) && safeLabel(body.assetId, 160)))) return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      result = await runtime.analyze(id, {
        ...(body.assetId ? { assetId: body.assetId } : {}),
        idempotencyKey: requestIdempotencyKey(request, id, 'material_analysis'),
      })
    }
    if (match[2] === 'materials' && match[3] === 'search') result = await runtime.search(id, body)
    if (match[2] === 'brief' && match[3] === 'save') result = await runtime.saveBrief(id, body)
    if (match[2] === 'storyboard' && match[3] === 'generate') {
      if (!exactBody(body, [])) return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      result = await runtime.generate(id, {
        idempotencyKey: requestIdempotencyKey(request, id, 'storyboard_generation'),
      })
    }
    if (match[2] === 'storyboard' && match[3] === 'selection' && body) result = await runtime.select(id, body.sentenceId, body.candidateId)
    if (match[2] === 'storyboard' && match[3] === 'search' && body) {
      if (!safeLabel(body.sentenceId, 160)) {
        return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      }
      if (body.query !== undefined && !safeText(body.query, 8000)) {
        return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      }
      if (body.replace !== undefined && body.replace !== true) {
        return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      }
      result = await runtime.searchMore(id, body)
    }
    if (match[2] === 'preview' && match[3] === 'generate') {
      result = await runtime.preview(id, {
        idempotencyKey: requestIdempotencyKey(request, id, 'preview_generation'),
      })
    }
    if (match[2] === 'delivery' && match[3] === 'finalize') {
      if (!exactBody(body, [])) return response({ error: { code: 'WORKBENCH_FINAL_VIDEO_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
      result = await runtime.finalizeVideo(id)
    }
    if (match[2] === 'delivery' && match[3] === 'preflight') {
      result = await runtime.preflight(id)
      if (result && typeof runtime.getWithJobs === 'function') {
        result = await runtime.getWithJobs(id)
      }
    }
      if (match[2] === 'delivery' && match[3] === 'export') {
        if (!runtime.isSynthetic) {
          if (!exactBody(body, [])) {
            return response({ error: { code: 'WORKBENCH_JOB_INPUT_INVALID', message: 'The workbench request is invalid.' } }, 400)
          }
          const idempotencyKey = requestIdempotencyKey(request, id, 'jianying_draft_export')
          if (typeof runtime.createDeliveryExport === 'function') {
            result = await runtime.createDeliveryExport(id, body, { idempotencyKey })
          } else {
            throw new WorkbenchOperationError('WORKBENCH_EDITOR_AGENT_UNAVAILABLE')
          }
        } else {
          result = await runtime.exportDraft(id)
        }
      }
    if (match[2] === 'delivery' && match[3] === 'recover') result = await runtime.recoverDelivery(id, body)
  } catch (error) {
    if (error instanceof WorkbenchOperationError && !error.code.startsWith('WORKBENCH_JOB_')) {
      return response({ error: { code: error.code, message: 'The trusted local capability could not complete this action.' } }, error.status)
    }
    return workbenchErrorResponse(error)
  }
  return result
    ? response(result, !runtime.isSynthetic && (
      (match[2] === 'materials' && match[3] === 'analyze') ||
      (match[2] === 'storyboard' && match[3] === 'generate') ||
      (match[2] === 'preview' && match[3] === 'generate') ||
      (match[2] === 'delivery' && match[3] === 'export')
    ) ? 202 : 200)
    : response({ error: { code: 'WORKBENCH_ACTION_INVALID', message: 'The workbench action could not be completed.' } }, 400)
}
