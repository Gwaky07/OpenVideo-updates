﻿import { createHash, randomUUID } from 'node:crypto'
import { mkdir, readdir, readFile, stat, writeFile } from 'node:fs/promises'
import { basename, dirname, extname, join, relative, resolve } from 'node:path'

import { loadGatewayConfig } from '../apps/gateway/src/config.mjs'
import { createDirector } from '../apps/gateway/src/director.mjs'
import {
  hasSensitiveDirectorText,
  isDirectorCandidate,
} from '../apps/gateway/src/director-contracts.mjs'
import { adaptEditPlanToTimeline } from '../apps/gateway/src/edit-plan-timeline-adapter.mjs'
import { createGateway } from '../apps/gateway/src/gateway.mjs'
import { createLlmSettingsService } from '../apps/gateway/src/llm-settings.mjs'
import { createJsonRepositories, createLocalAuthorizationCapability } from '../apps/gateway/src/local-runtime.mjs'
import { createPermissiveMaterialAnalyzer } from '../apps/gateway/src/permissive-material-analyzer.mjs'
import {
  candidateIsBoundedSourceRange,
  candidateIsInternalLongVideoRange,
  candidateIsWholeAssetRange,
  createQa009ReportClassification,
  evaluateQa009Query,
  evaluateQa009RQuality,
  parseQa009RunArguments,
  QA009_MAXIMUM_SHORT_SCENE_SECONDS,
  QA009R_QUALITY_PROFILE,
  rerankCandidateIdsAreApplicable,
  selectedCandidateIsBenchmarkHit,
  validateQa009BenchmarkSpec,
} from './qa009-acceptance-policy.mjs'

const {
  runMode,
  acceptanceEligible,
  dataRootArgument,
  materialRootArgument,
  benchmarkSpecArgument,
  projectId: configuredProjectId,
  evidenceFileName,
} = parseQa009RunArguments(process.argv.slice(2))

const dataRoot = resolve(dataRootArgument)
const materialSelectionPath = resolve(materialRootArgument)
const materialSelectionMetadata = await stat(materialSelectionPath)
const materialSelectionIsFile = materialSelectionMetadata.isFile()
const materialRoot = materialSelectionIsFile ? dirname(materialSelectionPath) : materialSelectionPath
const selectedMaterialFileName = materialSelectionIsFile ? basename(materialSelectionPath) : null
const mediaExtensions = new Set(['.mp4', '.mov', '.mkv', '.avi', '.webm', '.m4v', '.mpg', '.mpeg'])
const qa009EducationKeywordAuditTerms = Object.freeze(['圆柱', '圆锥', '总复习', '培优', '综合复习', '专题'])

const benchmarkSpecBytes = await readFile(resolve(benchmarkSpecArgument))
const benchmarkSpecSha256 = createHash('sha256').update(benchmarkSpecBytes).digest('hex')
const benchmarkSpec = await Promise.resolve(benchmarkSpecBytes.toString('utf8'))
  .then((text) => JSON.parse(text))
  .catch(() => { throw new Error('QA009_BENCHMARK_SPEC_INVALID') })
const queries = validateQa009BenchmarkSpec(benchmarkSpec, { runMode })

const loadPrivateProvider = async () => {
  const legacyProviderPath = resolve(dataRoot, 'gateway/provider.json')
  const legacyProvider = await readFile(legacyProviderPath, 'utf8')
    .then((text) => JSON.parse(text))
    .catch((error) => {
      if (error?.code === 'ENOENT') return null
      throw error
    })
  if (legacyProvider) {
    if (
      legacyProvider?.schema_version !== 1 ||
      legacyProvider?.provider !== 'openai-compatible' ||
      typeof legacyProvider.base_url !== 'string' ||
      typeof legacyProvider.api_key !== 'string' ||
      typeof legacyProvider.text_model !== 'string' ||
      typeof legacyProvider.vision_model !== 'string' ||
      typeof legacyProvider.json_model !== 'string'
    ) {
      throw new Error('QA009_GATEWAY_CONFIG_INVALID')
    }
    return {
      provider: legacyProvider.provider,
      baseUrl: legacyProvider.base_url,
      apiKey: legacyProvider.api_key,
      textModel: legacyProvider.text_model,
      visionModel: legacyProvider.vision_model,
      jsonModel: legacyProvider.json_model,
    }
  }

  const privateConfigRoot = dirname(dataRoot)
  const llmSettings = createLlmSettingsService({
    configPath: resolve(privateConfigRoot, 'config.json'),
    privateConfigRoot,
  })
  const runtime = await llmSettings.resolveRuntimeConfig()
  if (!runtime) throw new Error('QA009_GATEWAY_CONFIG_MISSING')
  return runtime
}

const privateProvider = await loadPrivateProvider()

process.env.OPENVIDEO_LLM_PROVIDER = privateProvider.provider
process.env.OPENVIDEO_LLM_BASE_URL = privateProvider.baseUrl
process.env.OPENVIDEO_LLM_API_KEY = privateProvider.apiKey
process.env.OPENVIDEO_LLM_TEXT_MODEL = privateProvider.textModel
process.env.OPENVIDEO_LLM_VISION_MODEL = privateProvider.visionModel
process.env.OPENVIDEO_LLM_JSON_MODEL = privateProvider.jsonModel

const sha256File = async (path) => {
  const hash = createHash('sha256')
  hash.update(await readFile(path))
  return hash.digest('hex')
}

const snapshotMedia = async (root, selectedFileName = null) => {
  const records = []
  const visit = async (directory) => {
    const entries = await readdir(directory, { withFileTypes: true })
    entries.sort((left, right) => left.name.localeCompare(right.name, 'zh-CN'))
    for (const entry of entries) {
      const path = join(directory, entry.name)
      if (entry.isDirectory() && !selectedFileName) {
        await visit(path)
        continue
      }
      if (selectedFileName && (directory !== root || entry.name !== selectedFileName)) continue
      if (!entry.isFile() || !mediaExtensions.has(extname(entry.name).toLowerCase())) continue
      const metadata = await stat(path)
      records.push({
        relativePath: relative(root, path),
        name: entry.name,
        size: metadata.size,
        mtimeMs: metadata.mtimeMs,
        sha256: await sha256File(path),
      })
    }
  }
  await visit(root)
  return records
}

const snapshotDigest = (records) => createHash('sha256').update(JSON.stringify(records)).digest('hex')

const countEntries = async (root) => {
  let count = 0
  const visit = async (directory) => {
    const entries = await readdir(directory, { withFileTypes: true }).catch((error) => {
      if (error?.code === 'ENOENT') return []
      throw error
    })
    for (const entry of entries) {
      count += 1
      if (entry.isDirectory()) await visit(join(directory, entry.name))
    }
  }
  await visit(root)
  return count
}

const containsPrivatePath = (value) => {
  const serialized = JSON.stringify(value).toLowerCase()
  return (
    serialized.includes(materialRoot.toLowerCase()) ||
    serialized.includes(dataRoot.toLowerCase()) ||
    serialized.includes(privateProvider.apiKey.toLowerCase()) ||
    serialized.includes(privateProvider.baseUrl.toLowerCase()) ||
    /\b[a-z]:[\\/]/iu.test(serialized) ||
    serialized.includes('file://')
  )
}

const safeDirectorText = (value, maximum = 500) => {
  const text = String(value ?? '')
    .replace(/[\u0000-\u001f]+/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
    .slice(0, maximum)
    .trim()
  return text && !hasSensitiveDirectorText(text) ? text : ''
}

const directorSummary = (parts) => {
  const summary = parts
    .map((part) => safeDirectorText(part))
    .filter(Boolean)
    .join(' | ')
    .slice(0, 500)
    .trim()
  return summary && !hasSensitiveDirectorText(summary)
    ? summary
    : 'Relevant education scene.'
}

const before = await snapshotMedia(materialRoot, selectedMaterialFileName)
if (before.length === 0) throw new Error('QA009_REAL_MEDIA_NOT_FOUND')
const benchmarkTargetPaths = [...new Set(
  queries
    .filter((query) => query.expectation === 'positive')
    .map((query) => query.targetRelativePath),
)]
const benchmarkTargets = benchmarkTargetPaths.map((targetRelativePath) => {
  const target = before.find((entry) => entry.relativePath === targetRelativePath)
  if (!target) throw new Error('QA009_BENCHMARK_TARGET_NOT_FOUND')
  return target
})

const repositories = await createJsonRepositories({ dataRoot })
let projectId = configuredProjectId
let qaProject = await repositories.projectRepository.get(projectId)
if (!qaProject) {
  const scaffold = (await repositories.projectRepository.list())[0]
  if (!scaffold) throw new Error('QA009_PROJECT_SCAFFOLD_MISSING')
  const now = new Date().toISOString()
  qaProject = await repositories.projectRepository.save({
    ...scaffold,
    id: projectId,
    name: 'QA-009 真实素材验收',
    notes: '系统临时验收项目，报告写入后自动清理。',
    status: 'active',
    currentStage: 'materials',
    createdAt: now,
    updatedAt: now,
    materials: {
      ...scaffold.materials,
      authorizationId: null,
      authorized: false,
      readOnlyConfirmed: false,
      folderLabel: null,
      total: 0,
      analyzed: 0,
      queued: 0,
      failed: 0,
      analysisStatus: 'not_started',
      analysisProgress: null,
      lastScanAt: null,
      assets: [],
    },
    tasks: [],
  })
}
const authorizations = await repositories.authorizationRepository.list()
const existingAuthorization = authorizations.find((record) => (
  record.projectId === projectId &&
  record.status === 'authorized' &&
  record.readOnly === true &&
  resolve(record.absolutePath) === materialRoot &&
  (record.selectedFileName ?? null) === selectedMaterialFileName
))
const authorizationCapability = createLocalAuthorizationCapability({
  authorizationRepository: repositories.authorizationRepository,
  dataRoot,
})
const authorizationResult = existingAuthorization
  ? { authorizationId: existingAuthorization.id }
  : await authorizationCapability.authorizeMaterials({
    projectId,
    folderLabel: 'QA-009 只读真实素材',
    readOnlyConfirmed: true,
    absolutePath: materialSelectionPath,
    ...(materialSelectionIsFile ? { sourceType: 'file' } : {}),
})
const authorizationId = authorizationResult.authorizationId
const authorization = existingAuthorization ?? await repositories.authorizationRepository.get(authorizationId)
if (!authorization) throw new Error('QA009_AUTHORIZATION_NOT_PERSISTED')
qaProject = await repositories.projectRepository.save({
  ...qaProject,
  updatedAt: new Date().toISOString(),
  materials: {
    ...qaProject.materials,
    authorizationId,
    authorized: true,
    readOnlyConfirmed: true,
    folderLabel: authorization.label,
    total: authorization.total,
    analyzed: 0,
    queued: authorization.total,
    failed: 0,
    analysisStatus: authorization.total > 0 ? 'queued' : 'ready',
    analysisProgress: null,
    lastScanAt: new Date().toISOString(),
    assets: [],
  },
})

const gatewayEvents = []
const rejectedEvidence = []
const rerankEvidence = []
const baseGateway = createGateway({
  config: loadGatewayConfig(),
  logger: (event) => gatewayEvents.push(event),
})
const auditedGateway = {
  async generate(request, options) {
    let result
    try {
      result = await baseGateway.generate(request, options)
    } catch (error) {
      if (request?.capability === 'json' && request?.jsonSchema?.name === 'material_scene_rerank') {
        rerankEvidence.push({ status: 'gateway_failed' })
      }
      throw error
    }
    if (request?.capability === 'json' && request?.jsonSchema?.name === 'material_scene_rerank') {
      const candidateIds = result?.outputJson?.candidateIds
      const submittedCandidateIds = (() => {
        try {
          const payload = JSON.parse(request.messages?.[1]?.parts?.[0]?.text ?? '{}')
          return Array.isArray(payload?.candidates)
            ? payload.candidates.map((candidate) => candidate?.id).filter((id) => typeof id === 'string')
            : []
        } catch {
          return []
        }
      })()
      rerankEvidence.push({
        status: rerankCandidateIdsAreApplicable(candidateIds, submittedCandidateIds)
          ? 'accepted'
          : 'schema_rejected',
      })
    }
    const rankings = result?.outputJson?.rankings
    if (Array.isArray(rankings)) {
      for (const ranking of rankings) {
        if (!Array.isArray(ranking?.rejected_candidates)) continue
        rejectedEvidence.push(...ranking.rejected_candidates.map((candidate) => ({
          candidateId: candidate.candidate_id,
          reason: candidate.reason,
        })))
      }
    }
    return result
  },
}

const analyzer = await createPermissiveMaterialAnalyzer({
  dataRoot,
  authorizationRepository: repositories.authorizationRepository,
  gateway: auditedGateway,
})
const providerStatus = analyzer.getStatus()
if (!providerStatus.available) throw new Error('QA009_PROVIDER_BLOCKED:' + providerStatus.code)

let analysisSource = 'restored-valid-index'
const analyzed = await analyzer.restoreAnalysis({ authorizationId, projectId }).catch(async (error) => {
  if (error?.code !== 'MATERIAL_ANALYSIS_RESCAN_REQUIRED') throw error
  analysisSource = 'fresh-analysis'
  await analyzer.deleteProjectAnalysis({ projectId })
  return analyzer.analyzeMaterials({ authorizationId, projectId })
})
const privateAsrEvidence = await analyzer.inspectAsrHallucinationsForAcceptance({
  authorizationId,
  projectId,
  phrases: benchmarkSpec.asrHallucinationPhrases,
})
const expectedAssetIdForPath = (targetRelativePath) => `asset-${createHash('sha256')
  .update([projectId, authorizationId, targetRelativePath].join('\u0000'))
  .digest('hex')
  .slice(0, 24)}`
const benchmarkAssets = new Map(benchmarkTargetPaths.map((targetRelativePath) => {
  const expectedAssetId = expectedAssetIdForPath(targetRelativePath)
  const asset = analyzed.assets.find((candidateAsset) => candidateAsset.id === expectedAssetId)
  if (!asset) throw new Error('QA009_BENCHMARK_ASSET_NOT_ANALYZED')
  return [expectedAssetId, asset]
}))
const queryEvidence = []
for (const query of queries) {
  const candidates = await analyzer.searchCandidatesForAcceptance({
    authorizationId,
    projectId,
    query: query.text,
    limit: 10,
  })
  queryEvidence.push(evaluateQa009Query({
    query,
    candidates,
    expectedAssetId: query.expectation === 'positive'
      ? expectedAssetIdForPath(query.targetRelativePath)
      : undefined,
    negativeConfidenceThreshold: benchmarkSpec.negativeConfidenceThreshold,
  }))
}

const primaryQuery = queryEvidence.find((entry) => entry.expectation === 'positive' && entry.top3Hit)
if (!primaryQuery?.candidates.length) throw new Error('QA009_NO_PRIMARY_CANDIDATES')
const directorCandidates = primaryQuery.allCandidates.map((candidate) => ({
  candidate_id: candidate.id,
  asset_id: candidate.assetId,
  scene_id: candidate.id,
  source: `materials/${candidate.assetId}`,
  start: candidate.start,
  end: candidate.end,
  summary: directorSummary([
    candidate.summary,
    candidate.ocrText ? 'OCR: ' + candidate.ocrText : '',
    candidate.asrSummary ? 'ASR: ' + candidate.asrSummary : '',
    candidate.shotPurpose ? 'Purpose: ' + candidate.shotPurpose : '',
    candidate.recommendedUse ? 'Use: ' + candidate.recommendedUse : '',
  ]),
  tags: [...new Set([
    ...(candidate.tags ?? []),
    ...(candidate.domainTags ?? []),
    ...(candidate.visualTags ?? []),
    ...(candidate.actionTags ?? []),
  ].map((tag) => safeDirectorText(tag, 80)).filter(Boolean))].slice(0, 12),
  search_score: Math.max(0, Math.min(1, Number(candidate.matchScore ?? 0))),
}))
if (!directorCandidates.every(isDirectorCandidate)) {
  throw new Error('QA009_DIRECTOR_CANDIDATE_MAPPING_INVALID')
}

const directorEvents = []
const director = createDirector({
  gateway: auditedGateway,
  logger: (event) => directorEvents.push(event),
})
const editPlan = await director.createEditPlan({
  schema_version: 1,
  project_id: projectId,
  script: primaryQuery.query,
  candidates: directorCandidates,
})
const timeline = adaptEditPlanToTimeline({
  editPlan,
  authorizationId,
  projectId,
})

const restartedAnalyzer = await createPermissiveMaterialAnalyzer({
  dataRoot,
  authorizationRepository: repositories.authorizationRepository,
  gateway: auditedGateway,
})
const restored = await restartedAnalyzer.restoreAnalysis({ authorizationId, projectId })
const after = await snapshotMedia(materialRoot, selectedMaterialFileName)
const temporaryEntryCount = await countEntries(resolve(dataRoot, 'material-analysis/tmp'))
const permanentSlices = after.filter((entry) => /(^|[\\/])scene-[^\\/]*\.mp4$/i.test(entry.relativePath))

const selectedItem = editPlan.items.find((item) => item.status === 'selected')
const selectedCandidate = selectedItem?.candidates.find(
  (candidate) => candidate.candidate_id === selectedItem.selected_candidate_id,
)
const timelineVideoSegment = timeline.tracks
  .find((track) => track.kind === 'video' && track.role === 'primary')
  ?.segments.find((segment) => segment.sourceRange)
const expectedDurationUs = selectedCandidate
  ? Math.round((selectedCandidate.end - selectedCandidate.start) * 1_000_000)
  : null
const sourceRangeWritten = Boolean(
  selectedCandidate &&
  timelineVideoSegment?.asset?.authorizationId === authorizationId &&
  timelineVideoSegment?.asset?.assetId === selectedCandidate.asset_id &&
  timelineVideoSegment?.asset?.sceneId === selectedCandidate.scene_id &&
  timelineVideoSegment?.sourceRange?.startUs === Math.round(selectedCandidate.start * 1_000_000) &&
  timelineVideoSegment?.sourceRange?.durationUs === expectedDurationUs
)
const selectedDirectorCandidateBenchmarkHit = selectedCandidateIsBenchmarkHit({
  selectedCandidate,
  benchmarkCandidates: primaryQuery.candidates,
})

const publicArtifacts = { analyzed, queryEvidence, editPlan, timeline, logs: [...gatewayEvents, ...directorEvents] }
const pathLeakCount = containsPrivatePath(publicArtifacts) ? 1 : 0
const beforeDigest = snapshotDigest(before)
const afterDigest = snapshotDigest(after)
const positiveQueryEvidence = queryEvidence.filter((entry) => entry.expectation === 'positive')
const negativeQueryEvidence = queryEvidence.filter((entry) => entry.expectation === 'negative')
const top1Hits = positiveQueryEvidence.filter((entry) => entry.top1Hit).length
const top3Hits = positiveQueryEvidence.filter((entry) => entry.top3Hit).length
const negativeCorrectRejections = negativeQueryEvidence.filter((entry) => entry.correctlyRejected).length
const negativeReturnedCandidateCount = negativeQueryEvidence.reduce(
  (count, entry) => count + entry.negativeReturnedCandidateCount,
  0,
)
const negativeUnsafeCandidateCount = negativeQueryEvidence.reduce(
  (count, entry) => count + entry.negativeUnsafeCandidateCount,
  0,
)
const rate = (numerator, denominator) => denominator > 0 ? numerator / denominator : null
const ocrQueryEvidence = positiveQueryEvidence.filter((entry) => entry.evidenceChannel === 'ocr')
const asrQueryEvidence = positiveQueryEvidence.filter((entry) => entry.evidenceChannel === 'asr')
const hardQueryEvidence = positiveQueryEvidence.filter((entry) => entry.difficulty === 'hard')
const hardQueryRangeIous = hardQueryEvidence.map((entry) => Math.max(
  0,
  ...entry.candidates
    .filter((candidate) => candidate.benchmark?.hit)
    .map((candidate) => candidate.benchmark.intersectionOverUnion),
))
const normalizedHallucinationPhrases = (benchmarkSpec.asrHallucinationPhrases || [])
  .map((phrase) => phrase.trim().toLocaleLowerCase('zh-CN'))
const maximumCandidateDurationFor = (entry) => Math.max(
  QA009_MAXIMUM_SHORT_SCENE_SECONDS,
  Number(entry.expectedWindow?.end ?? 0) - Number(entry.expectedWindow?.start ?? 0),
)
const allCandidateRangesShort = positiveQueryEvidence.every((entry) =>
  entry.candidates.every((candidate) => candidateIsBoundedSourceRange({
    candidate,
    assetDurationSeconds: benchmarkAssets.get(candidate.assetId)?.durationSeconds,
    maximumDurationSeconds: maximumCandidateDurationFor(entry),
  })),
)
const sceneCards = analyzed.assets.flatMap((asset) => asset.scenes)
const acceptedAsrHallucinationSceneCount = privateAsrEvidence.acceptedCount
const benchmarkPositiveHits = positiveQueryEvidence.map((entry) => ({
  entry,
  candidate: entry.candidates.find((candidate) => candidate.benchmark?.hit),
}))
const retrievedBenchmarkPositiveHits = benchmarkPositiveHits.filter(({ candidate }) => candidate)
const boundedBenchmarkSourceRanges = (
  retrievedBenchmarkPositiveHits.length > 0 &&
  retrievedBenchmarkPositiveHits.every(({ entry, candidate }) => candidateIsBoundedSourceRange({
    candidate,
    assetDurationSeconds: benchmarkAssets.get(candidate.assetId)?.durationSeconds,
    maximumDurationSeconds: maximumCandidateDurationFor(entry),
  }))
)
const internalLongVideoSourceRanges = runMode === 'long-acceptance'
  ? sourceRangeWritten && selectedDirectorCandidateBenchmarkHit && candidateIsInternalLongVideoRange({
      candidate: selectedCandidate,
      assetDurationSeconds: benchmarkAssets.get(selectedCandidate?.asset_id)?.durationSeconds,
      minimumAssetDurationSeconds: benchmarkSpec.minimumAssetDurationSeconds,
    })
  : false
const wholeAssetFallbackCount = retrievedBenchmarkPositiveHits
  .filter(({ candidate }) => candidateIsWholeAssetRange({
    candidate,
    assetDurationSeconds: benchmarkAssets.get(candidate.assetId)?.durationSeconds,
  }))
  .length
const sceneCardFieldsComplete = sceneCards.every((scene) => (
  typeof scene.id === 'string' &&
  Number.isFinite(scene.start) &&
  Number.isFinite(scene.end) &&
  typeof scene.summary === 'string' &&
  typeof scene.ocrText === 'string' &&
  // EM-011 accepted OCR sources: scene.ocrSource must be one of ocr_engine, llm_vision, taxonomy_fallback.
  ['ocr_engine', 'llm_vision', 'taxonomy_fallback'].includes(scene.ocrSource) &&
  typeof scene.asrTranscript === 'string' &&
  typeof scene.asrSummary === 'string' &&
  Array.isArray(scene.domainTags) &&
  Array.isArray(scene.visualTags) &&
  Array.isArray(scene.actionTags) &&
  typeof scene.shotPurpose === 'string' &&
  typeof scene.recommendedUse === 'string' &&
  Number.isFinite(scene.confidence) &&
  Array.isArray(scene.evidenceReferences) &&
  typeof scene.needsReview === 'boolean'
))
const localFallbackUsed = directorEvents.some((event) => event.event === 'director_ranking_local_fallback')
const qa009rQuality = evaluateQa009RQuality({
  ocrKeywordRecallRate: rate(ocrQueryEvidence.filter((entry) => entry.top3Hit).length, ocrQueryEvidence.length),
  asrSceneHitRate: rate(asrQueryEvidence.filter((entry) => entry.top3Hit).length, asrQueryEvidence.length),
  top1HitRate: rate(top1Hits, positiveQueryEvidence.length),
  top3HitRate: rate(top3Hits, positiveQueryEvidence.length),
  hardQueryRangeIou: rate(
    hardQueryRangeIous.reduce((total, value) => total + value, 0),
    hardQueryRangeIous.length,
  ),
  negativeFalseRecallRate: rate(
    negativeQueryEvidence.length - negativeCorrectRejections,
    negativeQueryEvidence.length,
  ),
  acceptedAsrHallucinationCount: acceptedAsrHallucinationSceneCount,
})
const checks = {
  realMediaCountMatchesAuthorization: analyzed.total === before.length,
  analysisReady: analyzed.analysisStatus === 'ready' && analyzed.analyzed === analyzed.total,
  sceneCardsComplete: sceneCards.length > 0 && sceneCardFieldsComplete,
  // EM-011: at least some scenes have OCR from an engine or LLM vision, not only taxonomy fallback.
  ocrSourceNonTrivial: sceneCards.some((scene) => scene.ocrSource !== 'taxonomy_fallback'),
  // EM-012: at least some scenes have reliable scene-level ASR instead of silence fallback only.
  asrReliableScenes: sceneCards.some((scene) => scene.asrSummary !== 'No reliable speech detected'),
  top1HitRate: top1Hits / positiveQueryEvidence.length,
  top3HitRate: top3Hits / positiveQueryEvidence.length,
  negativeQueryRejectionRate: negativeCorrectRejections / negativeQueryEvidence.length,
  negativeReturnedCandidateCount,
  negativeUnsafeCandidateCount,
  shortCandidateRanges: allCandidateRangesShort,
  boundedBenchmarkSourceRanges,
  internalLongVideoSourceRanges,
  wholeAssetFallbackCount,
  rerankSuccessRate: rerankEvidence.length > 0
    ? rerankEvidence.filter((entry) => entry.status === 'accepted').length / rerankEvidence.length
    : 0,
  rerankFallbackCount: rerankEvidence.filter((entry) => entry.status !== 'accepted').length,
  llmGatewayJsonSchemaRerank: rerankEvidence.length > 0 && rerankEvidence.every((entry) => entry.status === 'accepted'),
  recommendationReasonsPresent: Boolean(selectedCandidate?.reason),
  rejectionReasonsPresent: rejectedEvidence.length > 0 && rejectedEvidence.every((entry) => typeof entry.reason === 'string' && entry.reason.length > 0),
  selectedDirectorCandidateBenchmarkHit,
  // EM-013: edit plan items include structured rejectReasons.
  editPlanRejectReasons: editPlan.items.every((item) => Array.isArray(item.rejectReasons)),
  canonicalRichTimelineSourceRange: sourceRangeWritten,
  restartRecovery: JSON.stringify(restored) === JSON.stringify(analyzed),
  originalMediaUnchanged: beforeDigest === afterDigest,
  permanentSceneSlices: permanentSlices.length,
  temporaryEntryCount,
  publicPathLeakCount: pathLeakCount,
  qualityProfile: benchmarkSpec.qualityProfile ?? 'qa009-bounded-v1',
  qa009rQuality,
}
const hardSafetyPassed = (
  checks.originalMediaUnchanged &&
  checks.permanentSceneSlices === 0 &&
  checks.temporaryEntryCount === 0 &&
  checks.publicPathLeakCount === 0 &&
  checks.canonicalRichTimelineSourceRange
)
const commonQualityPassed = (
  checks.analysisReady &&
  checks.sceneCardsComplete &&
  checks.ocrSourceNonTrivial &&
  checks.asrReliableScenes &&
  checks.shortCandidateRanges &&
  checks.boundedBenchmarkSourceRanges &&
  checks.wholeAssetFallbackCount === 0 &&
  checks.llmGatewayJsonSchemaRerank &&
  checks.recommendationReasonsPresent &&
  checks.rejectionReasonsPresent &&
  checks.selectedDirectorCandidateBenchmarkHit &&
  checks.editPlanRejectReasons &&
  checks.restartRecovery
)
const qualityPassed = commonQualityPassed && (
  benchmarkSpec.qualityProfile === QA009R_QUALITY_PROFILE
    ? qa009rQuality.passed
    : checks.top1HitRate >= 0.75 &&
      checks.top3HitRate === 1 &&
      checks.negativeQueryRejectionRate === 1
)
// Formal QA-009 verdict states remain PASS / PARTIAL / FAIL through createQa009ReportClassification.
const reportClassification = createQa009ReportClassification({
  runMode,
  hardSafetyPassed,
  qualityPassed,
  longVideoGatePassed: checks.internalLongVideoSourceRanges,
})
const { qa009Verdict, regressionVerdict } = reportClassification

const evidenceRoot = resolve(dataRoot, 'evidence/qa-009')
await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
const evidence = {
  schemaVersion: 2,
  runId: randomUUID(),
  completedAt: new Date().toISOString(),
  runMode,
  acceptanceEligible,
  verdict: qa009Verdict,
  qa009Verdict,
  regressionVerdict,
  providerStatus,
  analysisSource,
  authorization: { projectId, authorizationId, readOnly: true, total: before.length },
  benchmark: {
    ...reportClassification.benchmark,
    specSha256: benchmarkSpecSha256,
    specSchemaVersion: benchmarkSpec.schemaVersion,
    qualityProfile: checks.qualityProfile,
    educationKeywordAuditTermsSha256: createHash('sha256')
      .update(JSON.stringify(qa009EducationKeywordAuditTerms))
      .digest('hex'),
    targetAssets: [...benchmarkAssets.entries()].map(([assetId, asset]) => ({
      assetId,
      durationSeconds: asset.durationSeconds,
    })),
    minimumAssetDurationSeconds: benchmarkSpec.minimumAssetDurationSeconds ?? null,
    negativeConfidenceThreshold: benchmarkSpec.negativeConfidenceThreshold,
    asrHallucinationPhrasesSha256: createHash('sha256')
      .update(JSON.stringify(benchmarkSpec.asrHallucinationPhrases || []))
      .digest('hex'),
    queries: queries.map((query) => ({
      text: query.text,
      expectation: query.expectation,
      targetAssetId: query.expectation === 'positive'
        ? expectedAssetIdForPath(query.targetRelativePath)
        : undefined,
      expectedWindow: query.expectation === 'positive' ? query.expectedWindow : undefined,
      minimumOverlapSeconds: query.expectation === 'positive' ? query.minimumOverlapSeconds : undefined,
      evidenceKeywordsSha256: createHash('sha256')
        .update(JSON.stringify(query.evidenceKeywords))
        .digest('hex'),
      evidenceChannel: query.evidenceChannel,
      difficulty: query.difficulty,
    })),
  },
  checks,
  before: { count: before.length, digest: beforeDigest, files: before },
  after: { count: after.length, digest: afterDigest, files: after },
  analyzed,
  queries: queryEvidence,
  director: { editPlan, rejectedCandidates: rejectedEvidence, events: directorEvents },
  materialSearch: { rerankEvidence },
  richTimeline: timeline,
  gatewayEvents,
}
await writeFile(
  resolve(evidenceRoot, evidenceFileName),
  JSON.stringify(evidence, null, 2) + '\n',
  { encoding: 'utf8', mode: 0o600 },
)
// The project exists only to keep the authorization valid while the live
// Workbench reconciles its own state. Evidence is already private and durable.
await repositories.projectRepository.remove(projectId)

console.log(JSON.stringify({
  runMode,
  acceptanceEligible,
  qa009Verdict,
  regressionVerdict,
  evidenceFileName,
  materialCount: before.length,
  sceneCount: sceneCards.length,
  top1Hits: String(top1Hits) + '/' + positiveQueryEvidence.length,
  top3Hits: String(top3Hits) + '/' + positiveQueryEvidence.length,
  negativeCorrectRejections: String(negativeCorrectRejections) + '/' + negativeQueryEvidence.length,
  negativeReturnedCandidateCount,
  negativeUnsafeCandidateCount,
  ocrSourceNonTrivial: checks.ocrSourceNonTrivial,
  asrReliableScenes: checks.asrReliableScenes,
  qualityProfile: checks.qualityProfile,
  qa009rQuality,
  editPlanRejectReasons: checks.editPlanRejectReasons,
  boundedBenchmarkSourceRanges,
  internalLongVideoSourceRanges,
  wholeAssetFallbackCount,
  selectedDirectorCandidateBenchmarkHit,
  sourceRangeWritten,
  originalMediaUnchanged: checks.originalMediaUnchanged,
  permanentSceneSlices: checks.permanentSceneSlices,
  temporaryEntryCount: checks.temporaryEntryCount,
  publicPathLeakCount: checks.publicPathLeakCount,
  llmRerank: checks.llmGatewayJsonSchemaRerank,
  restartRecovery: checks.restartRecovery,
}, null, 2))
