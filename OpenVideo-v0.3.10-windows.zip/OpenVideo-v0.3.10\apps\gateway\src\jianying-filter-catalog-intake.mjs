import { createHash } from 'node:crypto'
import { open, lstat, realpath, readlink } from 'node:fs/promises'
import { constants as fsConstants } from 'node:fs'
import { isAbsolute, relative, resolve } from 'node:path'
import { createRequire } from 'node:module'
import { resolveJianyingCompatibility, inspectPyJianyingUpstream } from './jianying-local-environment.mjs'
import { readFileNoReparse } from './jianying-native-safe-file.mjs'

const require = createRequire(import.meta.url)
const compatibilityManifest = require('../../../config/jianying-compatibility.json')
const upstreamManifest = require('../../../config/pyjianyingdraft-upstream.json')

const CAPABILITIES = new Set(['filter.video.named', 'filter.video.track_named'])
const TOKEN = /^ovjflt_v1_(?:segment|track)_[A-Za-z0-9_-]{32,160}$/u
const SHA256 = /^[a-f0-9]{64}$/u
const SEMVER = /^\d+\.\d+\.\d+(?:\.\d+)?$/u

export class JianyingFilterCatalogIntakeError extends Error {
  /** @param {string} code */
  constructor(code) { super(code); this.name = 'JianyingFilterCatalogIntakeError'; this.code = code }
}
/** @param {string} code @returns {never} */
const fail = (code) => { throw new JianyingFilterCatalogIntakeError(code) }
/** @param {unknown} v @returns {v is Record<string, any>} */
const record = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v)
/** @param {unknown} v @param {string[]} keys */
const exact = (v, keys) => record(v) && Object.keys(v).length === keys.length && keys.every((k) => Object.hasOwn(v, k))

/** @param {string} candidate @param {string} root */
async function safePath(candidate, root) {
  if (typeof candidate !== 'string' || !isAbsolute(candidate)) fail('JY017_CATALOG_PATH_INVALID')
  const rootAbs = resolve(root)
  const candidateAbs = resolve(candidate)
  const rel = relative(rootAbs, candidateAbs)
  if (rel.startsWith('..') || isAbsolute(rel)) fail('JY017_CATALOG_OUTSIDE_RUNTIME_ROOT')
  let current = candidateAbs
  while (true) {
    /** @type {import('node:fs').Stats} */
    let st
    try { st = await lstat(current) } catch { fail('JY017_CATALOG_PATH_MISSING') }
    if (st.isSymbolicLink() || (st.mode & 0o170000) === 0o120000) fail('JY017_CATALOG_REPARSE_REJECTED')
    if (current.toLowerCase() === rootAbs.toLowerCase()) break
    const parent = resolve(current, '..')
    if (parent === current) fail('JY017_CATALOG_OUTSIDE_RUNTIME_ROOT')
    current = parent
  }
  const [rootReal, candidateReal] = await Promise.all([realpath(rootAbs), realpath(candidateAbs)])
  const realRel = relative(rootReal, candidateReal)
  if (realRel.startsWith('..') || isAbsolute(realRel)) fail('JY017_CATALOG_REPARSE_REJECTED')
  return candidateReal
}

/** @param {import('node:fs/promises').FileHandle} handle @returns {Promise<string>} */
async function handlePath(handle) {
  if (process.platform !== 'linux') fail('JY017_CATALOG_READ_FAILED')
  return readlink(`/proc/self/fd/${handle.fd}`)
}

/** @param {string} path @param {string} runtimeRoot @returns {Promise<string>} */
async function readCatalogFromValidatedHandles(path, runtimeRoot) {
  const rootHandle = await open(runtimeRoot, fsConstants.O_RDONLY | fsConstants.O_DIRECTORY | fsConstants.O_NOFOLLOW)
  try {
    const rootTarget = await handlePath(rootHandle)
    const handle = await open(path, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW)
    try {
      const target = await handlePath(handle)
      const rel = relative(rootTarget, target)
      if (rel.startsWith('..') || isAbsolute(rel)) fail('JY017_CATALOG_REPARSE_REJECTED')
      const before = await handle.stat()
      const source = await handle.readFile({ encoding: 'utf8' })
      const after = await handle.stat()
      if (before.dev !== after.dev || before.ino !== after.ino) fail('JY017_CATALOG_REPARSE_REJECTED')
      return source
    } finally { await handle.close() }
  } finally { await rootHandle.close() }
}

/** @param {any} value @param {string} pinnedCommit */
function validateDocument(value, pinnedCommit, includePrivateEntries = false) {
  const keys = ['schema_version', 'kind', 'catalog_version', 'catalog_fingerprint', 'upstream_commit', 'entries']
  if (!exact(value, keys) || value.schema_version !== 1 || value.kind !== 'jy017_filter_catalog' ||
      typeof value.catalog_version !== 'string' || !SEMVER.test(value.catalog_version) ||
      typeof value.catalog_fingerprint !== 'string' || !SHA256.test(value.catalog_fingerprint) ||
      value.upstream_commit !== pinnedCommit || !Array.isArray(value.entries) || value.entries.length > 32) {
    fail('JY017_CATALOG_SCHEMA_INVALID')
  }
  const seen = new Set()
  const seenCapabilities = new Set()
  const privateEntries = value.entries.map((/** @type {any} */ entry) => {
    const entryKeys = ['capability_id', 'filter_token', 'resource_id']
    if (!exact(entry, entryKeys) || !CAPABILITIES.has(entry.capability_id) || !TOKEN.test(entry.filter_token) ||
        typeof entry.resource_id !== 'string' || !/^[A-Za-z0-9_-]{4,80}$/u.test(entry.resource_id) || seen.has(entry.filter_token) || seenCapabilities.has(entry.capability_id)) {
      fail('JY017_CATALOG_ENTRY_INVALID')
    }
    seen.add(entry.filter_token)
    seenCapabilities.add(entry.capability_id)
    return Object.freeze({ filterToken: entry.filter_token, capabilityId: entry.capability_id, resourceId: entry.resource_id })
  })
  const canonical = JSON.stringify({ schema_version: value.schema_version, kind: value.kind, catalog_version: value.catalog_version, upstream_commit: value.upstream_commit, entries: value.entries })
  if (createHash('sha256').update(canonical).digest('hex') !== value.catalog_fingerprint) fail('JY017_CATALOG_FINGERPRINT_INVALID')
  const bindings = Object.freeze(privateEntries.map((/** @type {{filterToken: string, capabilityId: string}} */ entry) => Object.freeze({ filterToken: entry.filterToken, capabilityId: entry.capabilityId })))
  const result = {
    catalogVersion: value.catalog_version,
    catalogFingerprint: value.catalog_fingerprint,
    upstreamCommit: value.upstream_commit,
    bindings,
  }
  if (includePrivateEntries) {
    // This is writer-side only. Callers must never propagate this object into
    // a public DTO, log entry, or model/tool payload.
    return Object.freeze({ ...result, privateEntries: Object.freeze(privateEntries) })
  }
  return Object.freeze(result)
}

/** @param {{runtimeRoot: string, catalogPath: string, desktopVersion: string, upstreamRoot: string}} input @param {{inspectUpstream?: typeof inspectPyJianyingUpstream, readCatalogNoReparse?: (path: string, root: string) => Promise<string>}} [testDeps] */
async function intakeJianyingFilterCatalogInternal({ runtimeRoot, catalogPath, desktopVersion, upstreamRoot }, testDeps = {}, includePrivateEntries = false) {
  if (typeof desktopVersion !== 'string' || !SEMVER.test(desktopVersion) || typeof upstreamRoot !== 'string') fail('JY017_SUPPORTED_VERSION_REQUIRED')
  const profile = resolveJianyingCompatibility(desktopVersion, compatibilityManifest)
  const exactEvidenceProfile = profile?.profileId === 'jianying-11-1-provisional'
  if (!profile || (profile.provisional && !exactEvidenceProfile) || !profile.capabilities?.draft_generation || !profile.capabilities?.manual_open) fail('JY017_SUPPORTED_VERSION_REQUIRED')
  let upstream
  const inspectUpstream = testDeps.inspectUpstream ?? inspectPyJianyingUpstream
  try { upstream = await inspectUpstream({ upstreamRoot, manifest: upstreamManifest }) } catch { fail('JY017_UPSTREAM_INTEGRITY_REQUIRED') }
  if (!upstream?.available || upstream.commit !== upstreamManifest.commit) fail('JY017_UPSTREAM_INTEGRITY_REQUIRED')
  const path = await safePath(catalogPath, runtimeRoot)
  let source
  try {
    if (process.platform === 'win32') {
      source = await (testDeps.readCatalogNoReparse ?? readFileNoReparse)(path, runtimeRoot)
    } else {
      source = await readCatalogFromValidatedHandles(path, runtimeRoot)
    }
  } catch (error) { if (error instanceof JianyingFilterCatalogIntakeError) throw error; fail('JY017_CATALOG_READ_FAILED') }
  let parsed
  try { parsed = JSON.parse(source) } catch { fail('JY017_CATALOG_READ_FAILED') }
  return validateDocument(parsed, upstreamManifest.commit, includePrivateEntries)
}

/** @param {{runtimeRoot: string, catalogPath: string, desktopVersion: string, upstreamRoot: string}} input */
export const intakeJianyingFilterCatalog = (input) => intakeJianyingFilterCatalogInternal(input)

/** Writer-only private catalog loader. It uses the exact same reparse-safe read
 * as public intake, but retains resource IDs solely at the writer boundary. */
/** @param {{runtimeRoot: string, catalogPath: string, desktopVersion: string, upstreamRoot: string}} input */
export const loadJianyingFilterCatalogForWriter = (input) =>
  intakeJianyingFilterCatalogInternal(input, {}, true)

/** Test-only seam; never pass this through a runtime request or public adapter. */
/** @param {{runtimeRoot: string, catalogPath: string, desktopVersion: string, upstreamRoot: string}} input @param {{inspectUpstream?: typeof inspectPyJianyingUpstream, readCatalogNoReparse?: (path: string, root: string) => Promise<string>}} deps */
export const __testIntakeJianyingFilterCatalog = (input, deps) => intakeJianyingFilterCatalogInternal(input, deps)

export const __private = Object.freeze({ validateDocument, safePath })
