import { createHash, randomUUID } from 'node:crypto'
import { lstat, mkdir, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises'
import { basename, dirname, isAbsolute, relative, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

import {
  evaluateCreativeTechniqueRolloutWindow,
  loadCreativeTechniqueReceiptHistory,
} from '../apps/gateway/src/creative-technique-receipts.mjs'

const fingerprintPattern = /^[a-f0-9]{64}$/u
const terminalStatuses = new Set(['succeeded', 'failed', 'cancelled', 'timed_out'])
const unsafePublicPattern = /(?:[A-Za-z]:\\|file:\/\/|\/Users\/|absolutePath|source_path|privateInput|api_key)/iu
const mediaExtensionPattern = /\.(?:mp4|mov|mkv|avi|webm|m4v)$/iu
const generatedScenePattern = /^Scene-.*\.mp4$/iu
const pollIntervalMs = 1_000
const timeoutMs = 30 * 60_000

const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const wait = (milliseconds) => new Promise((accept) => setTimeout(accept, milliseconds))
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)

const requestClient = ({ origin, token }) => {
  const publicPayloads = []
  const request = async (method, pathname, body, headers = {}) => {
    const response = await fetch(`${origin}${pathname}`, {
      method,
      headers: {
        accept: 'application/json',
        origin,
        ...(method === 'GET' ? {} : { 'x-openvideo-local-token': token }),
        ...(body === undefined ? {} : { 'content-type': 'application/json; charset=utf-8' }),
        ...headers,
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    const text = await response.text()
    const payload = text ? JSON.parse(text) : null
    publicPayloads.push(payload)
    if (!response.ok) {
      throw new Error(`CREATIVE_TECHNIQUE_HTTP_${response.status}:${payload?.error?.code ?? 'UNKNOWN'}`)
    }
    return payload
  }
  return { request, publicPayloads }
}

const loadToken = async (dataRoot) => {
  const token = JSON.parse(await readFile(resolve(dataRoot, 'local-api-token.json'), 'utf8')).token
  if (typeof token !== 'string' || !fingerprintPattern.test(token)) {
    throw new Error('CREATIVE_TECHNIQUE_LOCAL_TOKEN_INVALID')
  }
  return token
}

const walkFiles = async (root) => {
  const files = []
  const visit = async (directory) => {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = resolve(directory, entry.name)
      const metadata = await lstat(path, { bigint: true })
      if (metadata.isSymbolicLink()) throw new Error('CREATIVE_TECHNIQUE_SOURCE_REPARSE_FORBIDDEN')
      if (metadata.isDirectory()) await visit(path)
      else if (metadata.isFile()) files.push({ path, metadata })
    }
  }
  await visit(root)
  return files
}

const snapshotSources = async (sourcePaths) => {
  const roots = [...new Set(sourcePaths.map((path) => dirname(resolve(path))))].sort()
  const records = []
  let permanentSceneClipCount = 0
  for (const root of roots) {
    for (const { path, metadata } of await walkFiles(root)) {
      if (generatedScenePattern.test(basename(path))) permanentSceneClipCount += 1
      records.push({
        root: sha256(root.toLowerCase()),
        relativeName: sha256(relative(root, path).replaceAll('\\', '/')),
        size: metadata.size.toString(),
        mtimeNs: metadata.mtimeNs.toString(),
      })
    }
  }
  const selected = []
  for (const sourcePath of [...new Set(sourcePaths.map((path) => resolve(path)))].sort()) {
    const metadata = await stat(sourcePath, { bigint: true })
    selected.push({
      identity: sha256(sourcePath.toLowerCase()),
      size: metadata.size.toString(),
      mtimeNs: metadata.mtimeNs.toString(),
      contentFingerprint: sha256(await readFile(sourcePath)),
    })
  }
  return {
    fingerprint: sha256(JSON.stringify({ records, selected })),
    fileCount: records.length,
    selectedCount: selected.length,
    permanentSceneClipCount,
  }
}

const snapshotTemporaryEntries = async (dataRoot) => {
  const entries = []
  const visit = async (directory) => {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = resolve(directory, entry.name)
      const metadata = await lstat(path, { bigint: true })
      if (metadata.isSymbolicLink()) continue
      const relativeName = relative(dataRoot, path).replaceAll('\\', '/')
      if (/\.tmp(?:$|[./])/iu.test(relativeName) || /(?:^|\/)work-[^/]+(?:\/|$)/u.test(relativeName)) {
        entries.push(sha256(`${relativeName}\u0000${metadata.size}\u0000${metadata.mtimeNs}`))
      }
      if (metadata.isDirectory()) await visit(path)
    }
  }
  await visit(dataRoot)
  return new Set(entries)
}

const loadPrivateAnalysisIndex = async (dataRoot) => {
  const index = JSON.parse(await readFile(resolve(dataRoot, 'material-analysis', 'analysis-index.json'), 'utf8'))
  if (!Number.isSafeInteger(index?.schema_version) || index.schema_version < 1 || !Array.isArray(index.records)) {
    throw new Error('CREATIVE_TECHNIQUE_ANALYSIS_INDEX_INVALID')
  }
  const sources = new Map()
  for (const record of index.records) {
    for (const asset of Array.isArray(record.assets) ? record.assets : []) {
      if (typeof asset?.id === 'string' && typeof asset?.source_path === 'string' && isAbsolute(asset.source_path)) {
        sources.set(asset.id, asset.source_path)
      }
    }
  }
  return { index, sources }
}

const selectLibraryScenes = async (request) => {
  const catalog = await request('GET', '/api/workbench/material-library?limit=40')
  if (!Array.isArray(catalog?.assets)) throw new Error('CREATIVE_TECHNIQUE_LIBRARY_INVALID')
  const selected = []
  for (const summary of catalog.assets) {
    if (summary?.libraryState !== 'ready' || typeof summary.id !== 'string') continue
    const detail = await request('GET', `/api/workbench/material-library/assets/${encodeURIComponent(summary.id)}`)
    const asset = detail?.asset
    const scene = asset?.scenes?.find((candidate) =>
      Number.isFinite(candidate?.start) && Number.isFinite(candidate?.end) &&
      candidate.end - candidate.start >= 4 && candidate.needsReview !== true)
    if (!scene) continue
    selected.push({ assetId: asset.id, sceneId: scene.id, start: scene.start, end: scene.end })
    if (selected.length === 5) break
  }
  if (selected.length < 4) throw new Error('CREATIVE_TECHNIQUE_LIBRARY_SCENES_INSUFFICIENT')
  return selected
}

const pollJob = async ({ request, projectId, jobId }) => {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const job = await request('GET', `/api/workbench/projects/${encodeURIComponent(projectId)}/jobs/${encodeURIComponent(jobId)}`)
    if (job?.projectId !== projectId || typeof job.type !== 'string') {
      throw new Error('CREATIVE_TECHNIQUE_JOB_IDENTITY_INVALID')
    }
    if (terminalStatuses.has(job.status)) {
      if (job.status !== 'succeeded') {
        throw new Error(`CREATIVE_TECHNIQUE_JOB_FAILED:${job.type}:${job.error?.code ?? job.status}`)
      }
      return job
    }
    await wait(pollIntervalMs)
  }
  throw new Error('CREATIVE_TECHNIQUE_JOB_TIMEOUT')
}

const waitForAutomaticJobs = async ({ request, projectId, notBefore = null }) => {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const response = await request('GET', `/api/workbench/projects/${encodeURIComponent(projectId)}/jobs`)
    const jobs = (Array.isArray(response?.jobs) ? response.jobs : []).filter((job) =>
      notBefore === null || (typeof job?.createdAt === 'string' && job.createdAt >= notBefore))
    const latest = (type) => [...jobs].reverse().find((job) => job.type === type)
    const editor = latest('editor_agent')
    const preview = latest('preview_generation')
    const jianying = latest('jianying_draft_export')
    const selected = [editor, preview, jianying]
    const failure = selected.find((job) => job && terminalStatuses.has(job.status) && job.status !== 'succeeded')
    if (failure) throw new Error(`CREATIVE_TECHNIQUE_AUTOMATIC_JOB_FAILED:${failure.type}:${failure.error?.code ?? failure.status}`)
    if (selected.every((job) => job?.status === 'succeeded')) return { editor, preview, jianying }
    await wait(pollIntervalMs)
  }
  throw new Error('CREATIVE_TECHNIQUE_AUTOMATIC_OUTPUT_TIMEOUT')
}

const loadPrivateTimeline = async ({ dataRoot, projectId, publicTimeline }) => {
  const document = JSON.parse(await readFile(resolve(dataRoot, 'rich-timelines.json'), 'utf8'))
  const current = document.current?.find((entry) => entry.projectId === projectId)
  const timeline = document.revisions?.find((entry) =>
    entry.projectId === projectId && entry.timelineId === current?.timelineId && entry.revision === current?.revision)
  if (!timeline || timeline.revisionFingerprint !== publicTimeline.revisionFingerprint) {
    throw new Error('CREATIVE_TECHNIQUE_PRIVATE_TIMELINE_MISMATCH')
  }
  return timeline
}

const validateTechniqueTimeline = ({ timeline, analysisIndex }) => {
  const markers = Array.isArray(timeline.markers)
    ? timeline.markers.filter((marker) => marker.kind === 'beat' && /^semantic_cadence:(?:steady|accelerate|decelerate|rest)$/u.test(marker.label))
    : []
  const primarySegments = timeline.tracks?.find((track) => track.role === 'primary')?.segments ?? []
  const sceneBounds = new Map()
  for (const record of analysisIndex.records ?? []) {
    for (const asset of record.assets ?? []) {
      for (const scene of asset.scenes ?? []) {
        sceneBounds.set(`${asset.id}\u0000${scene.id}`, scene)
      }
    }
  }
  const rangesValid = primarySegments.length > 0 && primarySegments.every((segment) => {
    const scene = sceneBounds.get(`${segment.asset?.assetId}\u0000${segment.asset?.sceneId}`)
    const start = segment.sourceRange?.startUs
    const duration = segment.sourceRange?.durationUs
    return scene && Number.isSafeInteger(start) && Number.isSafeInteger(duration) && duration > 0 &&
      start >= Math.round(scene.start * 1_000_000) &&
      start + duration <= Math.round(scene.end * 1_000_000) + 1
  })
  if (markers.length !== primarySegments.length || !rangesValid) {
    throw new Error('CREATIVE_TECHNIQUE_REALIZATION_INVALID')
  }
  return { markerCount: markers.length, primarySegmentCount: primarySegments.length, rangesValid }
}

const publishReceipt = async (dataRoot, receipt) => {
  const root = resolve(dataRoot, 'evidence', 'creative-technique', 'real-acceptance')
  await mkdir(root, { recursive: true, mode: 0o700 })
  const path = resolve(root, `receipt-${Date.now()}-${randomUUID()}.json`)
  await writeFile(path, `${JSON.stringify(receipt)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
}

export const runCreativeTechniqueRealAcceptance = async ({ origin, dataRoot, projectId = null }) => {
  if (typeof origin !== 'string' || !/^http:\/\/127\.0\.0\.1:\d+$/u.test(origin) || !isAbsolute(dataRoot)) {
    throw new Error('CREATIVE_TECHNIQUE_ACCEPTANCE_INPUT_INVALID')
  }
  const token = await loadToken(dataRoot)
  const { request, publicPayloads } = requestClient({ origin, token })
  const live = await request('GET', '/api/live')
  if (live?.ready !== true) throw new Error('CREATIVE_TECHNIQUE_GATEWAY_NOT_READY')
  const benchmarkRoot = resolve(dataRoot, 'evidence', 'creative-technique', 'benchmark-v1')
  const benchmarkHistory = await loadCreativeTechniqueReceiptHistory(benchmarkRoot)
  const rollout = evaluateCreativeTechniqueRolloutWindow(benchmarkHistory.runs, benchmarkHistory)
  if (rollout.verdict !== 'ELIGIBLE') throw new Error('CREATIVE_TECHNIQUE_BENCHMARK_NOT_ELIGIBLE')

  const { index: analysisIndex, sources: sourceMap } = await loadPrivateAnalysisIndex(dataRoot)
  const selectedScenes = projectId ? [] : await selectLibraryScenes(request)
  const existingRecord = projectId
    ? analysisIndex.records.find((record) => record.project_id === projectId)
    : null
  const selectedSourcePaths = projectId
    ? (existingRecord?.assets ?? []).map((asset) => asset.source_path)
    : selectedScenes.map((scene) => sourceMap.get(scene.assetId))
  if (selectedSourcePaths.some((path) => typeof path !== 'string')) {
    throw new Error('CREATIVE_TECHNIQUE_SOURCE_IDENTITY_MISSING')
  }
  const sourceBefore = await snapshotSources(selectedSourcePaths)
  const temporaryBefore = await snapshotTemporaryEntries(dataRoot)
  let project = null
  const ownsProject = projectId === null
  let receipt = null
  try {
    if (ownsProject) {
      project = await request('POST', '/api/workbench/projects', {
        name: `技巧节奏自动内测 ${new Date().toISOString().slice(0, 10)}`,
        notes: 'CREATIVE-KNOWLEDGE-002 isolated automatic acceptance',
      })
      for (const scene of selectedScenes) {
        await request(
          'POST',
          `/api/workbench/projects/${encodeURIComponent(project.id)}/material-library/references`,
          scene,
        )
      }
    } else {
      project = await request('GET', `/api/workbench/projects/${encodeURIComponent(projectId)}`)
    }
    const brief = {
      ...project.brief,
      theme: '数学学习中的精准复习与逐步提升',
      title: '从薄弱点到稳定提升',
      sellingPoints: ['定位薄弱知识点', '分步骤专项练习', '复盘形成稳定节奏'],
      script: [
        '先快速定位真正薄弱的知识点。',
        '再通过清晰的课程步骤逐项练习。',
        '操作过程中留出时间看清关键反馈。',
        '最后放慢节奏复盘，形成稳定提升。',
      ].join('\n'),
      style: '清晰克制，开场紧凑，中段稳定，结尾留出阅读停顿',
      durationSeconds: 24,
      orientation: 'portrait',
      voiceover: 'none',
      voiceId: null,
      voiceRate: 0,
      captions: 'none',
      savedAt: new Date().toISOString(),
    }
    delete brief.packagingCapabilities
    project = await request(
      'POST',
      `/api/workbench/projects/${encodeURIComponent(project.id)}/brief/save`,
      brief,
    )
    const storyboardAccepted = await request(
      'POST',
      `/api/workbench/projects/${encodeURIComponent(project.id)}/jobs`,
      { type: 'storyboard_generation' },
      { 'idempotency-key': randomUUID() },
    )
    const storyboardJob = await pollJob({ request, projectId: project.id, jobId: storyboardAccepted.jobId })
    const automaticJobs = await waitForAutomaticJobs({
      request,
      projectId: project.id,
      notBefore: storyboardJob.updatedAt ?? storyboardJob.createdAt ?? null,
    })
    project = await request('GET', `/api/workbench/projects/${encodeURIComponent(project.id)}`)
    const timeline = await request('GET', `/api/workbench/projects/${encodeURIComponent(project.id)}/editor/timeline`)
    if (timeline?.status !== 'finalized' || !fingerprintPattern.test(timeline.revisionFingerprint ?? '')) {
      throw new Error('CREATIVE_TECHNIQUE_PUBLIC_TIMELINE_INVALID')
    }
    const privateTimeline = await loadPrivateTimeline({ dataRoot, projectId: project.id, publicTimeline: timeline })
    const realization = validateTechniqueTimeline({ timeline: privateTimeline, analysisIndex })
    const allAutomaticallySelected = project.storyboard?.sentences?.length > 0 &&
      project.storyboard.sentences.every((sentence) => sentence.status === 'selected' && typeof sentence.selectedCandidateId === 'string')
    if (!allAutomaticallySelected || project.storyboard.sentences.length !== realization.primarySegmentCount ||
        automaticJobs.jianying.result?.writerProjectionFingerprint !== timeline.revisionFingerprint) {
      throw new Error('CREATIVE_TECHNIQUE_AUTOMATIC_CHAIN_INVALID')
    }
    const sourceAfter = await snapshotSources(selectedSourcePaths)
    const temporaryAfter = await snapshotTemporaryEntries(dataRoot)
    const newTemporaryEntries = [...temporaryAfter].filter((entry) => !temporaryBefore.has(entry)).length
    const publicResponseLeakCount = publicPayloads.filter((value) => unsafePublicPattern.test(JSON.stringify(value))).length
    if (sourceAfter.fingerprint !== sourceBefore.fingerprint ||
        sourceAfter.permanentSceneClipCount !== sourceBefore.permanentSceneClipCount ||
        newTemporaryEntries !== 0 || publicResponseLeakCount !== 0) {
      throw new Error('CREATIVE_TECHNIQUE_SAFETY_EVIDENCE_FAILED')
    }
    const benchmark = benchmarkHistory.runs.at(-1)
    receipt = {
      schema_version: 1,
      completed_at: new Date().toISOString(),
      benchmark_fingerprint: benchmark.benchmark_fingerprint,
      knowledge_fingerprint: benchmark.knowledge_fingerprint,
      capability_registry_fingerprint: benchmark.capability_registry_fingerprint,
      adapter_revision: benchmark.adapter_revision,
      project_id_hash: sha256(project.id),
      timeline_revision_fingerprint: timeline.revisionFingerprint,
      preview_output_fingerprint: automaticJobs.preview.result?.outputFingerprint,
      jianying_output_fingerprint: automaticJobs.jianying.result?.outputFingerprint,
      writer_projection_fingerprint: automaticJobs.jianying.result?.writerProjectionFingerprint,
      automatic_selection: true,
      automatic_outputs: true,
      marker_count: realization.markerCount,
      primary_segment_count: realization.primarySegmentCount,
      source_ranges_valid: realization.rangesValid,
      source_manifest_unchanged: true,
      source_file_count: sourceAfter.fileCount,
      selected_source_count: sourceAfter.selectedCount,
      permanent_scene_clip_delta: 0,
      new_temporary_entry_count: 0,
      public_response_leak_count: 0,
    }
    if (![receipt.preview_output_fingerprint, receipt.jianying_output_fingerprint]
      .every((value) => fingerprintPattern.test(value ?? ''))) {
      throw new Error('CREATIVE_TECHNIQUE_OUTPUT_FINGERPRINT_INVALID')
    }
    await publishReceipt(dataRoot, receipt)
    return receipt
  } finally {
    if (ownsProject && project?.id) {
      const latest = await request('GET', `/api/workbench/projects/${encodeURIComponent(project.id)}`).catch(() => null)
      if (latest?.updatedAt) {
        await request('DELETE', `/api/workbench/projects/${encodeURIComponent(project.id)}`, {
          expectedUpdatedAt: latest.updatedAt,
        }).catch(() => null)
      }
    }
  }
}

const invokedPath = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : null
if (invokedPath === import.meta.url) {
  const origin = process.env.OPENVIDEO_ORIGIN || 'http://127.0.0.1:8787'
  const dataRoot = process.env.OPENVIDEO_RUNTIME_DATA_ROOT
  if (!dataRoot) throw new Error('OPENVIDEO_RUNTIME_DATA_ROOT_REQUIRED')
  const receipt = await runCreativeTechniqueRealAcceptance({
    origin,
    dataRoot,
    projectId: process.env.OPENVIDEO_PROJECT_ID || null,
  })
  console.log(JSON.stringify({ ...receipt, evidence_file: 'private-runtime/creative-technique' }))
}
