import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

import {
  createJianyingBatchTextPackagingCatalog,
  parseJianyingBatchTextPackagingCatalog,
} from '../apps/gateway/src/jianying-batch-text-packaging-catalog.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const safeLabel = (value, fallback) => {
  const label = typeof value === 'string' ? value.trim().slice(0, 80) : ''
  return /^[\p{L}\p{N}][\p{L}\p{N} ._()（）·-]{0,79}$/u.test(label) ? label : fallback
}

const tokenFor = (kind, ...privateIds) =>
  `ovjpack_v1_${createHash('sha256').update([kind, ...privateIds].join('\0')).digest('base64url')}`

const unique = (items, key) => [...new Map(items.map((item) => [item?.[key], item])).values()]
const uniqueBy = (items, toKey) => [...new Map(items.map((item) => [toKey(item), item])).values()]

export const extractJianyingBatchTextPackagingEntries = (content) => {
  const stickers = unique(
    (content?.materials?.stickers ?? []).filter(
      (item) => item?.type === 'sticker' && typeof item.resource_id === 'string',
    ),
    'resource_id',
  )
  const sourceFlowers = (content?.materials?.effects ?? []).filter(
    (item) =>
      item?.type === 'text_effect' &&
      typeof item.resource_id === 'string' &&
      typeof item.effect_id === 'string',
  )
  const flowers = uniqueBy(
    sourceFlowers,
    (item) => `${item.effect_id}\0${item.resource_id}`,
  )
  const bubbles = uniqueBy(
    (content?.materials?.effects ?? []).filter(
      (item) =>
        item?.type === 'text_shape' &&
        typeof item.resource_id === 'string' &&
        typeof item.effect_id === 'string',
    ),
    (item) => `${item.effect_id}\0${item.resource_id}`,
  )
  const entries = [
    ...flowers.map((item, index) => ({
      kind: 'flower',
      capability_id: 'text.flower.private',
      packaging_token: tokenFor('flower', item.effect_id, item.resource_id),
      label: safeLabel(item.name, `花字候选 ${index + 1}`),
      semantic_tags: ['emphasis', 'flower'],
      resource_id: item.resource_id,
      effect_id: item.effect_id,
    })),
    ...bubbles.map((item, index) => ({
      kind: 'bubble',
      capability_id: 'text.bubble.private',
      packaging_token: tokenFor('bubble', item.effect_id, item.resource_id),
      label: safeLabel(item.name, `气泡候选 ${index + 1}`),
      semantic_tags: ['emphasis', 'bubble'],
      resource_id: item.resource_id,
      effect_id: item.effect_id,
    })),
    ...stickers.map((item, index) => ({
      kind: 'sticker',
      capability_id: 'sticker.named',
      packaging_token: tokenFor('sticker', item.resource_id),
      label: safeLabel(item.name, `贴纸候选 ${index + 1}`),
      semantic_tags: ['sticker'],
      resource_id: item.resource_id,
      effect_id: null,
    })),
  ]
  return { entries, flowers, bubbles, stickers, sourceFlowers }
}

export const mergeJianyingBatchTextPackagingEntries = (...groups) => {
  const merged = new Map()
  for (const entries of groups) {
    for (const entry of entries) {
      const prior = merged.get(entry.packaging_token)
      if (prior && (
        prior.kind !== entry.kind ||
        prior.resource_id !== entry.resource_id ||
        prior.effect_id !== entry.effect_id
      )) throw new Error('JY131_CANDIDATE_TOKEN_CONFLICT')
      if (!prior) merged.set(entry.packaging_token, entry)
    }
  }
  return [...merged.values()]
}

const assertDraftName = (value) => {
  if (
    typeof value !== 'string' ||
    value !== path.basename(value) ||
    value.includes('/') ||
    value.includes('\\') ||
    value.length < 1 ||
    value.length > 180
  ) throw new Error('JY130_PRIVATE_INTAKE_REQUIRED')
  return value
}

const main = async () => {
  const draftName = assertDraftName(process.argv[2])
  const countOnly = process.argv.includes('--count-only')
  const mergeCandidate = process.argv.includes('--merge-candidate')
  const candidateCatalog = process.argv.includes('--candidate-catalog') || mergeCandidate
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true || typeof desktop.profileId !== 'string' || typeof desktop.version !== 'string') {
    throw new Error('JY130_PROFILE_UNAVAILABLE')
  }
  const draftFolder = path.resolve(desktop.draftRoot, draftName)
  if (path.dirname(draftFolder) !== path.resolve(desktop.draftRoot)) {
    throw new Error('JY130_PRIVATE_INTAKE_REQUIRED')
  }
  const temporary = await mkdtemp(path.join(tmpdir(), 'openvideo-jy130-intake-'))
  try {
    const sourceSnapshot = path.join(temporary, 'draft_content.encrypted')
    const plaintext = path.join(temporary, 'draft_content.json')
    const draftContentPath = path.join(draftFolder, 'draft_content.json')
    const encryptedSource = await readFileNoReparseBuffer(draftContentPath, desktop.draftRoot)
    await writeFile(sourceSnapshot, encryptedSource, { mode: 0o600 })
    const decryptor = createJianyingDraftDecryptor({
      installRoot: desktop.installRoot,
      appVersion: desktop.version,
    })
    const meta = await decryptor.ensurePlaintextFile(
      sourceSnapshot,
      plaintext,
    )
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') {
      throw new Error('JY130_ENCRYPT_V2_REQUIRED')
    }
    const contentBytes = encryptedSource
    const content = JSON.parse(await readFile(plaintext, 'utf8'))
    const { entries, flowers, bubbles, stickers, sourceFlowers } =
      extractJianyingBatchTextPackagingEntries(content)
    if (entries.length < 2) throw new Error('JY130_BATCH_CATALOG_TOO_SMALL')
    if (countOnly) {
      process.stdout.write(
        `${JSON.stringify({
          ok: true,
          count_only: true,
          entry_count: entries.length,
          flower_count: flowers.length,
          bubble_count: bubbles.length,
          sticker_count: stickers.length,
          source_flower_count: sourceFlowers.length,
          distinct_flower_effect_count: new Set(sourceFlowers.map((item) => item.effect_id)).size,
          distinct_flower_resource_count: new Set(sourceFlowers.map((item) => item.resource_id)).size,
          distinct_flower_pair_count: flowers.length,
          manual_verified: false,
        })}\n`,
      )
      return
    }
    const catalogRoot = path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs')
    const catalogFileName = candidateCatalog
      ? 'jy131-batch-sticker-bubble-candidate.json'
      : 'jy130-batch-text-packaging-catalog.json'
    let catalogEntries = entries
    let sourceFingerprint = createHash('sha256').update(contentBytes).digest('hex')
    if (mergeCandidate) {
      const existing = parseJianyingBatchTextPackagingCatalog(
        JSON.parse(await readFileNoReparse(path.join(catalogRoot, catalogFileName), catalogRoot)),
      )
      if (
        existing.profile_id !== desktop.profileId ||
        existing.evidence_profile.app_version !== desktop.version ||
        existing.evidence_profile.manual_verified !== false
      ) throw new Error('JY131_CANDIDATE_PROFILE_MISMATCH')
      catalogEntries = mergeJianyingBatchTextPackagingEntries(existing.entries, entries)
      sourceFingerprint = createHash('sha256')
        .update(existing.evidence_profile.draft_fingerprint)
        .update('\0')
        .update(sourceFingerprint)
        .digest('hex')
    }
    const catalog = createJianyingBatchTextPackagingCatalog(catalogEntries, {
      profileId: desktop.profileId,
      evidenceProfile: {
        manual_verified: false,
        scheme: 'encrypt_v2',
        app_version: desktop.version,
        draft_fingerprint: sourceFingerprint,
      },
    })
    await mkdir(catalogRoot, { recursive: true, mode: 0o700 })
    await securePrivateRuntimeRoot(catalogRoot)
    await writeFile(
      path.join(catalogRoot, catalogFileName),
      `${JSON.stringify(catalog)}\n`,
      { encoding: 'utf8', mode: 0o600 },
    )
    process.stdout.write(
      `${JSON.stringify({
        ok: true,
        entry_count: catalog.entries.length,
        flower_count: catalog.entries.filter((entry) => entry.kind === 'flower').length,
        bubble_count: catalog.entries.filter((entry) => entry.kind === 'bubble').length,
        sticker_count: catalog.entries.filter((entry) => entry.kind === 'sticker').length,
        catalog_fingerprint: catalog.catalog_fingerprint,
        catalog_mode: candidateCatalog ? 'candidate' : 'active',
        manual_verified: false,
      })}\n`,
    )
  } finally {
    await rm(temporary, { recursive: true, force: true })
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch((error) => {
    process.stdout.write(
      `${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY130_PRIVATE_INTAKE_FAILED' })}\n`,
    )
    process.exitCode = 1
  })
}
