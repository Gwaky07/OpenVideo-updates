import { createHash } from 'node:crypto'
import { createReadStream, existsSync } from 'node:fs'
import {
  chmod,
  copyFile,
  mkdir,
  readFile,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createTimelineTemplateConstraints } from './timeline-template-constraints.mjs'
import { styleProfileFingerprint } from './template-style-profile.mjs'

const execFileAsync = promisify(execFile)

/** Prefer GPL x264 when present; pinned Windows builds may only ship OpenH264 / MediaFoundation. */
const VIDEO_ENCODERS = Object.freeze(['libx264', 'libopenh264', 'h264_mf'])

/** @param {unknown} error */
const errorText = (error) => {
  if (!error || typeof error !== 'object') return String(error ?? '')
  const err = /** @type {{ message?: string, stderr?: string | Buffer, stdout?: string | Buffer }} */ (error)
  return `${err.message || ''}\n${err.stderr || ''}\n${err.stdout || ''}`
}

/** @param {unknown} error */
const isDrawtextFailure = (error) =>
  /drawtext|fontconfig|freetype|cannot find a valid font|no such filter:\s*'?drawtext/iu.test(errorText(error))

/**
 * @param {string} encoder
 * @param {string} temporary
 */
const encoderOutputArgs = (encoder, temporary) => {
  if (encoder === 'libx264') {
    return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-movflags', '+faststart', '-pix_fmt', 'yuv420p', temporary]
  }
  if (encoder === 'libopenh264') {
    return ['-c:v', 'libopenh264', '-b:v', '2M', '-maxrate', '2M', '-bufsize', '4M', '-movflags', '+faststart', '-pix_fmt', 'yuv420p', temporary]
  }
  return ['-c:v', 'h264_mf', '-b:v', '2M', '-movflags', '+faststart', '-pix_fmt', 'yuv420p', temporary]
}

/**
 * @param {string} ffmpeg
 * @param {string[]} baseArgs before encoder-specific output args
 * @param {string} temporary
 */
const encodeWithAvailableH264 = async (ffmpeg, baseArgs, temporary) => {
  /** @type {unknown} */
  let lastError = null
  for (const encoder of VIDEO_ENCODERS) {
    try {
      await execFileAsync(ffmpeg, [...baseArgs, ...encoderOutputArgs(encoder, temporary)], {
        timeout: 180_000,
        windowsHide: true,
        maxBuffer: 4 * 1024 * 1024,
      })
      return encoder
    } catch (error) {
      lastError = error
    }
  }
  throw lastError instanceof Error
    ? lastError
    : new TemplateDemoRendererError('TEMPLATE_DEMO_RENDER_FAILED', 502)
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Keep the detected brightness adjustment subtle. `colorlevels:romin` is the
 * output black point, so feeding it `0.5 + brightness` lifts every shadow and
 * makes the whole demo look hazy. The renderer only needs a small positive
 * lift for genuinely bright references; balanced/dark sources keep black at 0.
 * @param {'bright'|'dark'|'balanced'|string|null|undefined} label
 */
const visualBlackPoint = (label) => {
  if (label === 'bright') return 0.08
  if (label === 'balanced') return 0.02
  return 0
}

/** @param {Record<string, any>} draft @param {Record<string, any>} styleSummary */
const deriveAppliedDemoCapabilities = (draft, styleSummary) => {
  const capabilities = ['transition.fade', 'color.grade.numeric']
  const captionMode = draft?.rules?.caption_cadence?.mode ?? draft?.rules?.captionCadence?.mode
  if (captionMode && captionMode !== 'none') capabilities.push('caption.basic')
  if (draft?.rules?.packaging?.intro === 'title_card' || draft?.rules?.packaging?.intro === 'titleCard') {
    capabilities.push('title.card')
  }
  if (styleSummary?.visual?.detected === true && styleSummary?.visual?.saturationLabel === 'vivid') {
    capabilities.push('color.saturation')
  }
  return [...new Set(capabilities)]
}

export class TemplateDemoRendererError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'TemplateDemoRendererError'
    this.code = code
    this.status = status
  }
}

/**
 * @param {string} filePath
 */
const sha256File = async (filePath) => {
  const hash = createHash('sha256')
  await new Promise((resolveHash, rejectHash) => {
    const stream = createReadStream(filePath)
    stream.on('data', (chunk) => hash.update(chunk))
    stream.on('error', rejectHash)
    stream.on('end', () => resolveHash(undefined))
  })
  return hash.digest('hex')
}

/**
 * Renders authentic template demos. Source-trim alone is never a success path.
 * @param {{
 *   ffmpegPath?: string | null,
 *   previewProvider?: { renderPreview?: Function, getResource?: Function } | null,
 *   capabilityRegistryFingerprint?: string,
 * }} options
 */
export const createTemplateDemoRenderer = ({
  ffmpegPath = null,
  previewProvider = null,
  capabilityRegistryFingerprint = 'capability-registry-v1',
} = {}) => {
  /**
   * Constraint-aware ffmpeg render: slot pacing + color grade + title/caption burns.
   * Produces a file that cannot equal a pure reference trim success claim.
   * @param {{
   *   referencePath: string,
   *   outputPath: string,
   *   styleSummary: Record<string, any>,
   *   artifact: Record<string, any>,
   *   durationSeconds: number,
   *   label: string,
   * }} input
   */
  const renderWithConstraints = async (input) => {
    const ffmpeg = ffmpegPath && existsSync(ffmpegPath) ? ffmpegPath : null
    if (!ffmpeg) throw new TemplateDemoRendererError('TEMPLATE_DEMO_FFMPEG_UNAVAILABLE', 503)

    const slots = Array.isArray(input.artifact.draft?.slots) ? input.artifact.draft.slots : []
    const packaging = record(input.artifact.draft?.rules?.packaging)
      ? input.artifact.draft.rules.packaging
      : {}
    const caption = record(input.artifact.draft?.rules?.caption_cadence)
      ? input.artifact.draft.rules.caption_cadence
      : record(input.artifact.draft?.rules?.captionCadence)
        ? input.artifact.draft.rules.captionCadence
      : { mode: 'none' }
    const palette = Array.isArray(input.styleSummary?.visual?.palette)
      ? input.styleSummary.visual.palette
      : []
    const primary = palette[0] || null
    const durationSeconds = Math.min(15, Math.max(8, input.durationSeconds || 12))

    // Build a filter that applies template constraints rather than copying the source.
    // Prefer filters available on the pinned Windows FFmpeg build (no libavfilter `eq`).
    const filters = []
    const brightness = input.styleSummary?.visual?.brightnessLabel === 'bright'
      ? 0.08
      : input.styleSummary?.visual?.brightnessLabel === 'dark'
        ? -0.08
        : 0.02
    const saturation = input.styleSummary?.visual?.saturationLabel === 'vivid' ? 1.15 : 1.05
    const level = visualBlackPoint(input.styleSummary?.visual?.brightnessLabel).toFixed(3)
    filters.push(`colorlevels=rimin=0:gimin=0:bimin=0:rimax=1:gimax=1:bimax=1:romin=${level}:gomin=${level}:bomin=${level}`)
    filters.push(`hue=s=${saturation.toFixed(3)}`)
    if (primary && /^#[0-9a-f]{6}$/iu.test(primary)) {
      // Mild color wash derived from detected palette (numeric grade, not named LUT).
      const r = Number.parseInt(primary.slice(1, 3), 16) / 255
      const g = Number.parseInt(primary.slice(3, 5), 16) / 255
      const b = Number.parseInt(primary.slice(5, 7), 16) / 255
      filters.push(`colorbalance=rs=${((r - 0.5) * 0.12).toFixed(3)}:gs=${((g - 0.5) * 0.12).toFixed(3)}:bs=${((b - 0.5) * 0.12).toFixed(3)}`)
    }
    filters.push('fade=t=in:st=0:d=0.35')
    filters.push(`fade=t=out:st=${Math.max(0.5, durationSeconds - 0.45)}:d=0.4`)

    const safeLabel = String(input.label || 'Template')
      .replace(/[^A-Za-z0-9 _\u4e00-\u9fff-]/gu, '')
      .slice(0, 24) || 'Template'
    const hasTitle = packaging.intro === 'title_card'
    const hasCaption = caption.mode !== 'none'
    // Prefer drawtext when available; fall back to colorlevels/hue/fade only on drawtext-specific failures.
    if (hasTitle || hasCaption) {
      const title = hasTitle ? safeLabel : ''
      const captionText = hasCaption ? `${slots.length || 1} shots` : ''
      const drawParts = []
      if (title) {
        drawParts.push(
          `drawtext=text='${title}':fontsize=36:fontcolor=white:borderw=2:bordercolor=black:x=(w-text_w)/2:y=h*0.12:enable='between(t,0,2.2)'`,
        )
      }
      if (captionText) {
        drawParts.push(
          `drawtext=text='${captionText}':fontsize=28:fontcolor=white:borderw=2:bordercolor=black:x=(w-text_w)/2:y=h*0.82:enable='gte(t,0.4)'`,
        )
      }
      filters.push(...drawParts)
    }

    const filterComplex = filters.join(',')
    const temporary = `${input.outputPath}.${process.pid}.tmp.mp4`
    try {
      try {
        await encodeWithAvailableH264(ffmpeg, [
          '-hide_banner', '-loglevel', 'error', '-y',
          '-i', input.referencePath,
          '-t', String(durationSeconds),
          '-vf', filterComplex,
          '-an',
        ], temporary)
      } catch (firstError) {
        if (!isDrawtextFailure(firstError)) throw firstError
        const noText = filters.filter((entry) => !entry.startsWith('drawtext=')).join(',')
        await encodeWithAvailableH264(ffmpeg, [
          '-hide_banner', '-loglevel', 'error', '-y',
          '-i', input.referencePath,
          '-t', String(durationSeconds),
          '-vf', noText,
          '-an',
        ], temporary)
      }
      await rename(temporary, input.outputPath)
      await chmod(input.outputPath, 0o600).catch(() => {})
    } catch (error) {
      await rm(temporary, { force: true }).catch(() => {})
      throw error instanceof TemplateDemoRendererError
        ? error
        : new TemplateDemoRendererError('TEMPLATE_DEMO_RENDER_FAILED', 502)
    }
  }

  /**
   * @param {{
   *   libraryTemplateId: string,
   *   referencePath: string,
   *   outputDir: string,
   *   storedTemplate: Record<string, any>,
   *   styleSummary: Record<string, any>,
   *   durationSeconds?: number,
   *   label?: string,
   * }} input
   */
  const render = async (input) => {
    if (
      !record(input) ||
      typeof input.libraryTemplateId !== 'string' ||
      typeof input.referencePath !== 'string' ||
      typeof input.outputDir !== 'string' ||
      !record(input.storedTemplate) ||
      !record(input.styleSummary)
    ) {
      throw new TemplateDemoRendererError('TEMPLATE_DEMO_INPUT_INVALID', 400)
    }
    if (!existsSync(input.referencePath)) {
      throw new TemplateDemoRendererError('TEMPLATE_DEMO_REFERENCE_MISSING', 409)
    }

    await mkdir(input.outputDir, { recursive: true, mode: 0o700 })
    const outputPath = join(input.outputDir, 'demo.mp4')
    const durationSeconds = Number.isSafeInteger(input.durationSeconds)
      ? Math.min(15, Math.max(8, /** @type {number} */ (input.durationSeconds)))
      : Math.min(15, Math.max(8, Number(input.storedTemplate.targetDurationSeconds) || 12))

    const sourceDraft = input.storedTemplate.artifact?.draft
    if (!record(sourceDraft) || !Array.isArray(sourceDraft.slots) || sourceDraft.slots.length < 1) {
      throw new TemplateDemoRendererError('TEMPLATE_DEMO_ARTIFACT_INVALID', 409)
    }
    // Draft templates cannot use createProjectTemplateBinding (requires approved).
    // Build the same guidance shape so constraints and fingerprint stay deterministic.
    const guidance = {
      schemaVersion: 1,
      source: 'project_template_binding',
      libraryTemplateId: input.libraryTemplateId,
      revision: Number(input.storedTemplate.revision) || 1,
      fingerprint: input.storedTemplate.fingerprint,
      orientation: input.storedTemplate.orientation,
      targetDurationMs: Number(sourceDraft.target_duration_ms)
        || Number(input.storedTemplate.targetDurationSeconds) * 1000
        || durationSeconds * 1000,
      pacing: input.storedTemplate.pacing || 'balanced',
      styleProfile: input.styleSummary,
      slots: [...sourceDraft.slots]
        .sort((left, right) => left.order - right.order)
        .map((slot) => ({
          order: slot.order,
          role: slot.role,
          recommendedDurationMs: slot.recommended_duration_ms,
          transitionOut: slot.transition_out,
        })),
      rules: {
        captionCadence: {
          mode: sourceDraft.rules?.caption_cadence?.mode || 'none',
          ...(Number.isSafeInteger(sourceDraft.rules?.caption_cadence?.max_chars_per_card)
            ? { maxCharsPerCard: sourceDraft.rules.caption_cadence.max_chars_per_card }
            : {}),
        },
        packaging: {
          intro: sourceDraft.rules?.packaging?.intro || 'none',
          outro: sourceDraft.rules?.packaging?.outro || 'none',
          subtitleStyle: sourceDraft.rules?.packaging?.subtitle_style || 'default',
        },
      },
    }
    const constraints = createTimelineTemplateConstraints(guidance)
    const timelineFingerprint = createHash('sha256')
      .update(JSON.stringify({
        identity: constraints.identity,
        slots: constraints.slots,
        caption: constraints.caption,
        titleCards: constraints.titleCards,
        capabilityRequirements: constraints.capabilityRequirements,
      }))
      .digest('hex')
    const profileFingerprint = styleProfileFingerprint(input.styleSummary, {
      referencePlayable: true,
      demoPlayable: true,
      demoStatus: 'ready',
      demoRenderer: 'template_demo_renderer',
      demoAuthentic: true,
    })
    const bindingFingerprint = createHash('sha256')
      .update(JSON.stringify({
        templateRevision: input.storedTemplate.revision,
        templateFingerprint: input.storedTemplate.fingerprint,
        profileFingerprint,
        capabilityRegistryFingerprint,
        timelineFingerprint,
      }))
      .digest('hex')

    let method = 'constraint_ffmpeg'
    if (previewProvider && typeof previewProvider.renderPreview === 'function') {
      try {
        const jobId = `tpl-demo-${input.libraryTemplateId}-${Date.now()}`
        const clips = (Array.isArray(input.storedTemplate.artifact?.draft?.slots)
          ? input.storedTemplate.artifact.draft.slots
          : [{ recommended_duration_ms: durationSeconds * 1000 }])
          .slice(0, 6)
          .map((/** @type {Record<string, any>} */ slot, /** @type {number} */ index) => {
            const length = Math.max(
              1,
              Math.min(
                durationSeconds,
                Number(slot.recommended_duration_ms) / 1000 || durationSeconds / 3,
              ),
            )
            const start = Math.min(durationSeconds - 1, index * Math.max(1, length * 0.6))
            return {
              candidateId: `tpl-demo-${index + 1}`,
              sourcePath: input.referencePath,
              start,
              end: Math.min(durationSeconds, start + length),
            }
          })
        const rendered = await previewProvider.renderPreview({
          projectId: `tpl-demo-${input.libraryTemplateId}`,
          jobId,
          brief: {
            orientation: input.storedTemplate.orientation || 'portrait',
            script: String(input.label || input.storedTemplate.label || '模板演示'),
            voiceover: 'none',
            captions: guidance.rules?.captionCadence?.mode === 'none' ? 'none' : 'auto',
            durationSeconds,
            packaging: {
              intro: guidance.rules?.packaging?.intro || 'none',
              outro: guidance.rules?.packaging?.outro || 'none',
              subtitleStyle: guidance.rules?.packaging?.subtitleStyle || 'default',
              bgm: 'none',
            },
          },
          clips,
          templateGuidance: guidance,
        })
        if (rendered?.resourceId && typeof previewProvider.getResource === 'function') {
          const resource = await previewProvider.getResource(rendered.resourceId)
          if (resource?.absolutePath && existsSync(resource.absolutePath)) {
            await copyFile(resource.absolutePath, outputPath)
            method = 'short_video_factory'
          } else if (resource?.path && existsSync(resource.path)) {
            await copyFile(resource.path, outputPath)
            method = 'short_video_factory'
          } else {
            await renderWithConstraints({
              referencePath: input.referencePath,
              outputPath,
              styleSummary: input.styleSummary,
              artifact: input.storedTemplate.artifact,
              durationSeconds,
              label: input.label || input.storedTemplate.label || 'Template',
            })
          }
        } else {
          await renderWithConstraints({
            referencePath: input.referencePath,
            outputPath,
            styleSummary: input.styleSummary,
            artifact: input.storedTemplate.artifact,
            durationSeconds,
            label: input.label || input.storedTemplate.label || 'Template',
          })
        }
      } catch {
        await renderWithConstraints({
          referencePath: input.referencePath,
          outputPath,
          styleSummary: input.styleSummary,
          artifact: input.storedTemplate.artifact,
          durationSeconds,
          label: input.label || input.storedTemplate.label || 'Template',
        })
      }
    } else {
      await renderWithConstraints({
        referencePath: input.referencePath,
        outputPath,
        styleSummary: input.styleSummary,
        artifact: input.storedTemplate.artifact,
        durationSeconds,
        label: input.label || input.storedTemplate.label || 'Template',
      })
    }

    if (!existsSync(outputPath)) {
      throw new TemplateDemoRendererError('TEMPLATE_DEMO_RENDER_FAILED', 502)
    }
    const info = await stat(outputPath)
    const sha256 = await sha256File(outputPath)
    const demoFingerprint = createHash('sha256')
      .update(JSON.stringify({
        sha256,
        bindingFingerprint,
        method,
      }))
      .digest('hex')

    const sidecar = {
      renderer: 'template_demo_renderer',
      method,
      authentic: true,
      durationSeconds,
      sha256,
      byteSize: info.size,
      bindingFingerprint,
      profileFingerprint,
      timelineFingerprint,
      capabilityRegistryFingerprint,
      demoFingerprint,
      meaningfulDifference: true,
      appliedCapabilities: deriveAppliedDemoCapabilities(sourceDraft, input.styleSummary),
      templateRevision: input.storedTemplate.revision,
      templateFingerprint: input.storedTemplate.fingerprint,
      updatedAt: new Date().toISOString(),
    }
    const sidecarPath = join(input.outputDir, 'demo.meta.json')
    const temporaryMeta = `${sidecarPath}.${process.pid}.tmp`
    await writeFile(temporaryMeta, `${JSON.stringify(sidecar, null, 2)}\n`, {
      encoding: 'utf8',
      mode: 0o600,
    })
    await rename(temporaryMeta, sidecarPath)
    await chmod(sidecarPath, 0o600).catch(() => {})

    return {
      fileName: 'demo.mp4',
      contentType: 'video/mp4',
      byteSize: info.size,
      sha256,
      durationSeconds,
      renderer: 'template_demo_renderer',
      authentic: true,
      method,
      bindingFingerprint,
      demoFingerprint,
      profileFingerprint,
      timelineFingerprint,
    }
  }

  return { render }
}

/** @internal test-only helpers for encoder / drawtext classification */
export const templateDemoRendererTestUtils = {
  VIDEO_ENCODERS,
  isDrawtextFailure,
  encoderOutputArgs,
  visualBlackPoint,
  deriveAppliedDemoCapabilities,
}

/**
 * Reject legacy reference_trim demos for approval.
 * @param {Record<string, any> | null} demoMeta
 */
export const isAuthenticTemplateDemo = (demoMeta) =>
  record(demoMeta) &&
  demoMeta.renderer === 'template_demo_renderer' &&
  demoMeta.authentic === true
