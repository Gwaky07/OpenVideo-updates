import { randomUUID } from 'node:crypto'
import { lstat, mkdir, realpath, rename, rm } from 'node:fs/promises'
import path from 'node:path'

const PROVIDER = /^[a-z][a-z0-9_-]{2,63}$/u
const ownedLeases = new WeakMap()

/** @param {string} root @param {string} candidate */
const inside = (root, candidate) => {
  const relative = path.relative(path.resolve(root), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

/** @param {string} code */
const fail = (code) => {
  const error = /** @type {Error & {code: string}} */ (new Error(code))
  error.code = code
  throw error
}

/** @param {import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/** @param {string} requested @param {string} actual @param {import('node:fs').BigIntStats} requestedMetadata */
const sameResolvedDirectory = async (requested, actual, requestedMetadata) => {
  if (path.resolve(requested) === path.resolve(actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && actualMetadata.isDirectory() && !actualMetadata.isSymbolicLink() &&
    objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}

/** @param {string} target */
const readDirectoryIdentity = async (target) => {
  const metadata = await lstat(target, { bigint: true })
  const actual = await realpath(target)
  if (!metadata.isDirectory() || metadata.isSymbolicLink() ||
      !await sameResolvedDirectory(target, actual, metadata)) {
    fail('JY200_STAGING_ROOT_UNSAFE')
  }
  return objectIdentity(metadata)
}

/** @param {string} target @param {string} expected */
const assertDirectoryIdentity = async (target, expected) => {
  let current
  try { current = await readDirectoryIdentity(target) } catch { fail('JY200_STAGING_ROOT_REPLACED') }
  if (current !== expected) fail('JY200_STAGING_ROOT_REPLACED')
}

/**
 * Gateway-owned filesystem leases. Public callers receive only an opaque
 * object; only the trusted adapter can resolve it to an owned staging path.
 * @param {{runtimeRoot: string, liveDraftRoot: string, repositoryRoot: string}} input
 */
export const createGatewayOwnedStagingLeaseManager = async ({ runtimeRoot, liveDraftRoot, repositoryRoot }) => {
  if (![runtimeRoot, liveDraftRoot, repositoryRoot].every((value) => typeof value === 'string' && path.isAbsolute(value))) {
    fail('JY200_STAGING_ROOT_INVALID')
  }
  const runtime = path.resolve(runtimeRoot)
  const live = path.resolve(liveDraftRoot)
  const repository = path.resolve(repositoryRoot)
  if (inside(repository, runtime) || inside(runtime, repository) || inside(live, runtime) || inside(runtime, live)) {
    fail('JY200_STAGING_ROOT_INVALID')
  }
  await mkdir(runtime, { recursive: true })
  const [runtimeMetadata, liveMetadata, repositoryMetadata, runtimeReal, liveReal, repositoryReal] = await Promise.all([
    lstat(runtime, { bigint: true }), lstat(live, { bigint: true }), lstat(repository, { bigint: true }),
    realpath(runtime), realpath(live), realpath(repository),
  ])
  if (![runtimeMetadata, liveMetadata, repositoryMetadata].every((metadata) => metadata.isDirectory() && !metadata.isSymbolicLink()) ||
      !await sameResolvedDirectory(runtime, runtimeReal, runtimeMetadata) ||
      !await sameResolvedDirectory(live, liveReal, liveMetadata) ||
      !await sameResolvedDirectory(repository, repositoryReal, repositoryMetadata)) fail('JY200_STAGING_ROOT_UNSAFE')
  const runtimeIdentity = objectIdentity(runtimeMetadata)
  const quarantineRoot = path.join(runtime, '.gateway-quarantine')
  try {
    await mkdir(quarantineRoot)
  } catch (error) {
    if (!(error && typeof error === 'object' && /** @type {{code?: string}} */ (error).code === 'EEXIST')) throw error
  }
  const quarantineIdentity = await readDirectoryIdentity(quarantineRoot)
  /** @type {Map<string, string>} */
  const providerIdentities = new Map()

  const manager = Object.freeze({
    /** @param {{providerId: string}} input */
    async create({ providerId }) {
      if (typeof providerId !== 'string' || !PROVIDER.test(providerId)) fail('JY200_PROVIDER_INVALID')
      await assertDirectoryIdentity(runtime, runtimeIdentity)
      const providerRoot = path.join(runtime, providerId)
      // Create the provider container as one new directory. A pre-existing
      // entry could have been replaced after manager construction; validate it
      // before creating any child so a junction cannot redirect mkdir outside.
      try {
        await mkdir(providerRoot)
      } catch (error) {
        if (!(error && typeof error === 'object' && /** @type {{code?: string}} */ (error).code === 'EEXIST')) throw error
      }
      const providerIdentity = await readDirectoryIdentity(providerRoot)
      const retainedProviderIdentity = providerIdentities.get(providerId)
      if (retainedProviderIdentity && retainedProviderIdentity !== providerIdentity) {
        fail('JY200_STAGING_ROOT_REPLACED')
      }
      providerIdentities.set(providerId, providerIdentity)
      const root = path.join(providerRoot, `lease-${randomUUID()}`)
      await mkdir(root)
      const [providerMetadata, rootMetadata, providerReal, rootReal] = await Promise.all([
        lstat(providerRoot, { bigint: true }), lstat(root, { bigint: true }), realpath(providerRoot), realpath(root),
      ])
      if (!providerMetadata.isDirectory() || providerMetadata.isSymbolicLink() ||
          !rootMetadata.isDirectory() || rootMetadata.isSymbolicLink() ||
          !await sameResolvedDirectory(providerRoot, providerReal, providerMetadata) ||
          !await sameResolvedDirectory(root, rootReal, rootMetadata) || !inside(runtimeReal, rootReal)) {
        await rm(root, { recursive: true, force: true }).catch(() => {})
        fail('JY200_STAGING_ROOT_UNSAFE')
      }
      await assertDirectoryIdentity(providerRoot, providerIdentity)
      const rootIdentity = await readDirectoryIdentity(root)
      const lease = Object.freeze({ lease_id: `lease_${randomUUID().replaceAll('-', '')}` })
      ownedLeases.set(lease, {
        manager,
        root,
        providerRoot,
        providerId,
        runtimeIdentity,
        providerIdentity,
        rootIdentity,
        sealed: false,
        active: true,
      })
      return lease
    },
    /** @param {unknown} lease */
    async resolve(lease) {
      const state = lease && typeof lease === 'object' ? ownedLeases.get(lease) : null
      if (!state || state.manager !== manager || state.active !== true) fail('JY200_STAGING_LEASE_NOT_OWNED')
      try {
        await assertDirectoryIdentity(runtime, state.runtimeIdentity)
        if (state.sealed) await assertDirectoryIdentity(quarantineRoot, quarantineIdentity)
        else await assertDirectoryIdentity(state.providerRoot, state.providerIdentity)
        await assertDirectoryIdentity(state.root, state.rootIdentity)
      } catch (error) {
        state.active = false
        throw error
      }
      return state.root
    },
    /**
     * Move completed Provider output behind a Gateway-private unpredictable
     * name before independent readback. The Provider runner must have fully
     * quiesced before this method is called.
     * @param {unknown} lease
     */
    async seal(lease) {
      const state = lease && typeof lease === 'object' ? ownedLeases.get(lease) : null
      if (!state || state.manager !== manager || state.active !== true || state.sealed === true) {
        fail('JY200_STAGING_LEASE_NOT_OWNED')
      }
      await manager.resolve(lease)
      await assertDirectoryIdentity(quarantineRoot, quarantineIdentity)
      const sealedRoot = path.join(quarantineRoot, `sealed-${randomUUID()}`)
      await rename(state.root, sealedRoot)
      let sealedIdentity
      try {
        await assertDirectoryIdentity(quarantineRoot, quarantineIdentity)
        sealedIdentity = await readDirectoryIdentity(sealedRoot)
      } catch {
        state.active = false
        fail('JY200_STAGING_ROOT_REPLACED')
      }
      if (sealedIdentity !== state.rootIdentity) {
        state.active = false
        fail('JY200_STAGING_ROOT_REPLACED')
      }
      state.root = sealedRoot
      state.sealed = true
      return manager.resolve(lease)
    },
    /** @param {unknown} lease */
    owns(lease) {
      const state = lease && typeof lease === 'object' ? ownedLeases.get(lease) : null
      return Boolean(state && state.manager === manager && state.active === true)
    },
    /** @param {unknown} lease */
    async release(lease) {
      const state = lease && typeof lease === 'object' ? ownedLeases.get(lease) : null
      if (!state || state.manager !== manager || state.active !== true) return false
      await manager.resolve(lease)
      await assertDirectoryIdentity(quarantineRoot, quarantineIdentity)
      // Move to an unpredictable Gateway-private tombstone before deletion.
      // A same-path replacement is detected by the retained object identity
      // and is never recursively removed.
      const tombstone = path.join(quarantineRoot, `delete-${randomUUID()}`)
      await rename(state.root, tombstone)
      state.root = tombstone
      state.sealed = true
      let tombstoneIdentity
      try {
        await assertDirectoryIdentity(quarantineRoot, quarantineIdentity)
        tombstoneIdentity = await readDirectoryIdentity(tombstone)
      } catch {
        state.active = false
        fail('JY200_STAGING_ROOT_REPLACED')
      }
      if (tombstoneIdentity !== state.rootIdentity) {
        state.active = false
        fail('JY200_STAGING_ROOT_REPLACED')
      }
      await rm(tombstone, { recursive: true, force: true })
      state.active = false
      return true
    },
  })
  return manager
}
