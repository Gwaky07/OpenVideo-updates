import { normalizeBrief, isCuratedVoiceId } from './brief-packaging.mjs'
import { isJianyingPresetVoiceId } from './jianying-tts-presets.mjs'
import { isRunningHubVoiceId } from './tts-studio.mjs'
import {
  assertTemplateGuidanceExecutable,
  createTemplateGuidance,
} from './template-binding-consumption.mjs'

const timestamp = () => new Date().toISOString()

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * @param {{
 *   referenceTemplateRepository?: {getApproved?: Function} | null,
 *   jianyingDraftCapability?: object | null,
 *   authorizationRepository?: {get?: Function} | null,
 *   bgmLibrary?: {isAuthorizedTrack?: Function} | null,
 *   ttsStudio?: {isProfileReady?: Function} | null,
 *   jianyingTtsPresetsService?: {get?: Function} | null,
 *   now?: () => string,
 * }} [dependencies]
 */
export const createProductionWorkbenchPreflight = ({
  jianyingDraftCapability = null,
  authorizationRepository = null,
  bgmLibrary = null,
  ttsStudio = null,
  jianyingTtsPresetsService = null,
  now = timestamp,
} = {}) => {
  /** @param {{projectId: string, project: any}} input */
  const preflight = async (input) => {
    const project = input?.project
    if (!isRecord(project) || project.id !== input.projectId) {
      return {
        template: {
          status: 'not_started',
          name: null,
          version: null,
          reason: '项目状态不可用，无法完成导出预检。',
        },
        preflight: {
          status: 'failed',
          checkedAt: now(),
          checks: [{ label: '项目状态', status: 'fail' }],
        },
      }
    }

    const brief = normalizeBrief(project.brief ?? {})
    const packaging = brief.packaging
    const storyboardReady =
      isRecord(project.storyboard) &&
      Array.isArray(project.storyboard.sentences) &&
      project.storyboard.sentences.length > 0 &&
      project.storyboard.sentences.every(
        (/** @type {unknown} */ sentence) =>
          isRecord(sentence) &&
          typeof sentence.selectedCandidateId === 'string' &&
          sentence.selectedCandidateId.length > 0,
      )
    const previewReady =
      isRecord(project.preview) &&
      project.preview.status === 'ready' &&
      typeof project.preview.resourceId === 'string' &&
      project.preview.resourceId.length > 0
    const materialsReady =
      isRecord(project.materials) &&
      (
        (
          project.materials.authorized === true &&
          typeof project.materials.authorizationId === 'string' &&
          project.materials.authorizationId.length > 0 &&
          Number(project.materials.total) > 0
        ) ||
        (
          Number.isSafeInteger(project.materials.referencedAssetCount) &&
          Number(project.materials.referencedAssetCount) > 0
        )
      )

    let templateGuidance = null
    let templateReady = true
    let templateFailure = 'invalid'
    try {
      templateGuidance = createTemplateGuidance(project.templateBinding ?? null)
      assertTemplateGuidanceExecutable(templateGuidance)
      if (templateGuidance && templateGuidance.orientation !== brief.orientation) {
        templateReady = false
        templateFailure = 'orientation'
      }
    } catch (error) {
      templateReady = false
      templateFailure =
        isRecord(error) && error.code === 'WORKBENCH_TEMPLATE_TRANSITION_UNSUPPORTED'
          ? 'unsupported'
          : 'invalid'
    }

    let voiceoverReady = brief.voiceover !== 'required' || isCuratedVoiceId(brief.voiceId)
    if (
      !voiceoverReady &&
      isRunningHubVoiceId(brief.voiceId) &&
      typeof ttsStudio?.isProfileReady === 'function'
    ) {
      try {
        voiceoverReady = await ttsStudio.isProfileReady(brief.voiceId) === true
      } catch {
        voiceoverReady = false
      }
    }
    if (
      !voiceoverReady &&
      isJianyingPresetVoiceId(brief.voiceId) &&
      typeof jianyingTtsPresetsService?.get === 'function'
    ) {
      try {
        const preset = await jianyingTtsPresetsService.get(brief.voiceId)
        voiceoverReady = isRecord(preset) && preset.id === brief.voiceId
      } catch {
        voiceoverReady = false
      }
    }

    let bgmReady = true
    if (packaging?.bgm === 'local_authorized') {
      bgmReady = false
      if (
        packaging.bgmAuthorizationId &&
        typeof bgmLibrary?.isAuthorizedTrack === 'function'
      ) {
        try {
          bgmReady = await bgmLibrary.isAuthorizedTrack({
            projectId: input.projectId,
            trackId: packaging.bgmAuthorizationId,
          }) === true
        } catch {
          bgmReady = false
        }
      }
    }

    const jianyingReady = Boolean(
      jianyingDraftCapability &&
      ['exportDraft', 'cleanupDraft', 'commitDraft'].every(
        (method) =>
          typeof /** @type {Record<string, any>} */ (jianyingDraftCapability)[method] ===
          'function',
      ),
    )

    /** @type {Array<{label: string, status: 'pass' | 'fail'}>} */
    const checks = [
      { label: '分镜完整性', status: storyboardReady ? 'pass' : 'fail' },
      { label: '预览成片', status: previewReady ? 'pass' : 'fail' },
      { label: '素材绑定', status: materialsReady ? 'pass' : 'fail' },
      { label: '模板绑定快照', status: templateReady ? 'pass' : 'fail' },
      { label: '配音音频', status: voiceoverReady ? 'pass' : 'fail' },
      { label: '背景音乐授权', status: bgmReady ? 'pass' : 'fail' },
      { label: '剪映导出环境', status: jianyingReady ? 'pass' : 'fail' },
    ]
    const ready = checks.every((check) => check.status === 'pass')

    const templateFailureReason = templateFailure === 'unsupported'
      ? '当前模板包含尚未由预览与剪映 writer 实现的转场，暂不可执行。'
      : templateFailure === 'orientation'
        ? '当前模板画幅与创作要求不一致，请重新选择兼容模板。'
        : '当前模板绑定快照已损坏或 fingerprint 不匹配，请重新选择模板。'
    const template = !templateReady
      ? {
          status: 'not_started',
          name: null,
          version: null,
          reason: templateFailureReason,
        }
      : templateGuidance
      ? {
          status: 'confirmed',
          name: project.templateBinding.label,
          version: `revision ${templateGuidance.revision}`,
          reason: `项目绑定快照 ${templateGuidance.fingerprint.slice(0, 12)} 已通过完整性校验。`,
        }
      : {
          status: 'confirmed',
          name: '自动创作',
          version: 'automatic',
          reason: '项目未绑定模板，将使用自动创作默认规则导出。',
        }

    return {
      template,
      preflight: {
        status: ready ? 'ready' : 'failed',
        checkedAt: now(),
        checks,
      },
    }
  }

  return { preflight }
}
