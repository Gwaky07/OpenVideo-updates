import { isCreativeBeatIntent } from './creative-retrieval.mjs'

const maxBeats = 30
const maxSourceRules = 8
const safeIdPattern = /^[A-Za-z0-9._:-]{1,200}$/u
const rhythmClasses = new Set(['steady', 'accelerate', 'decelerate', 'rest'])
const transitionCapabilities = new Set(['transition.cut', 'transition.none'])
const soundFamilies = new Set(['camera', 'foley', 'impact', 'riser', 'sparkle', 'text', 'transition', 'whoosh'])
const soundAnchors = new Set(['shot_start', 'action', 'settle', 'seam', 'shot_end'])
const importanceLevels = new Set(['low', 'medium', 'high'])
const decisionKeys = [
  'beat_id', 'hold_budget_us', 'rhythm_class', 'transition_capability_id',
  'transition_duration_us', 'global_technique_id', 'degradation_reason', 'source_rule_ids',
]
const audioCueDecisionKeys = [
  'beat_id', 'semantic_family', 'anchor', 'importance', 'desired_duration_us',
  'tags', 'source_rule_id', 'degradation_reason',
]

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
export const isCreativeTechniqueDecision = (value) => isRecord(value) &&
  Object.keys(value).length === decisionKeys.length && decisionKeys.every((key) => Object.hasOwn(value, key)) &&
  typeof value.beat_id === 'string' && safeIdPattern.test(value.beat_id) &&
  Number.isSafeInteger(value.hold_budget_us) && value.hold_budget_us >= 0 && value.hold_budget_us <= 10_000_000 &&
  rhythmClasses.has(value.rhythm_class) &&
  (value.transition_capability_id === null || transitionCapabilities.has(value.transition_capability_id)) &&
  Number.isSafeInteger(value.transition_duration_us) && value.transition_duration_us >= 0 && value.transition_duration_us <= 5_000_000 &&
  (value.global_technique_id === null || (typeof value.global_technique_id === 'string' && safeIdPattern.test(value.global_technique_id))) &&
  (value.degradation_reason === null || (typeof value.degradation_reason === 'string' && safeIdPattern.test(value.degradation_reason))) &&
  Array.isArray(value.source_rule_ids) && value.source_rule_ids.length <= maxSourceRules &&
  new Set(value.source_rule_ids).size === value.source_rule_ids.length &&
  value.source_rule_ids.every((id) => typeof id === 'string' && safeIdPattern.test(id))

/** @param {unknown} value */
export const isCreativeAudioCueDecision = (value) => isRecord(value) &&
  Object.keys(value).length === audioCueDecisionKeys.length &&
  audioCueDecisionKeys.every((key) => Object.hasOwn(value, key)) &&
  typeof value.beat_id === 'string' && safeIdPattern.test(value.beat_id) &&
  soundFamilies.has(value.semantic_family) && soundAnchors.has(value.anchor) &&
  importanceLevels.has(value.importance) &&
  Number.isSafeInteger(value.desired_duration_us) && value.desired_duration_us >= 100_000 &&
  value.desired_duration_us <= 2_000_000 &&
  Array.isArray(value.tags) && value.tags.length <= 6 && new Set(value.tags).size === value.tags.length &&
  value.tags.every((tag) => typeof tag === 'string' && /^[a-z0-9][a-z0-9._-]{0,39}$/u.test(tag)) &&
  typeof value.source_rule_id === 'string' && safeIdPattern.test(value.source_rule_id) &&
  (value.degradation_reason === null ||
    (typeof value.degradation_reason === 'string' && safeIdPattern.test(value.degradation_reason)))

/** @param {Record<string, any>} rule @param {Record<string, any>} intent */
const appliesTo = (rule, intent) =>
  rule.applicableShotRoles.includes(intent.shot_role) && rule.applicableEnergies.includes(intent.energy)

/** @param {string[]} values */
const boundedRuleIds = (values) => [...new Set(values)].sort().slice(0, maxSourceRules)

/** @param {Record<string, any>} input */
const validBeatInput = (input) => Array.isArray(input?.beats) && input.beats.length > 0 &&
  input.beats.length <= maxBeats &&
  input.beats.every((/** @type {Record<string, any>} */ beat) => typeof beat?.sentence_id === 'string' && safeIdPattern.test(beat.sentence_id) &&
    isCreativeBeatIntent(beat.beat_intent))

/**
 * Builds an output-neutral, sequence-level proposal. It never returns segments,
 * source ranges, provider identities or media references.
 * @param {{knowledge: Record<string, any>}} dependencies
 */
export const createCreativeTechniquePolicy = ({ knowledge }) => {
  if (knowledge?.summary?.schemaVersion !== 2 || !Array.isArray(knowledge?.snapshot?.technique_rules)) {
    throw new Error('CREATIVE_TECHNIQUE_POLICY_DEPENDENCY_INVALID')
  }
  const rules = /** @type {Record<string, any>[]} */ (knowledge.snapshot.technique_rules)
  const holdRules = rules.filter((rule) => rule.family === 'hold_budget')
  const rhythmRules = rules.filter((rule) => rule.family === 'rhythm_pattern')
  const seamRules = rules.filter((rule) => rule.family === 'transition_seam')
  const limitRules = rules.filter((rule) => rule.family === 'global_limit')
  const audioRules = rules.filter((rule) => rule.family === 'audio_cue')
  const recipeSources = new Map(knowledge.snapshot.recipes.map(
    (/** @type {Record<string, any>} */ recipe) => [recipe.recipeId, recipe.sourceCard],
  ))

  return Object.freeze({
    /** @param {{beats: Record<string, any>[], allowedCapabilityIds?: string[]}} input */
    plan(input) {
      if (!validBeatInput(input)) {
        throw new Error('CREATIVE_TECHNIQUE_POLICY_INPUT_INVALID')
      }
      const allowed = new Set((input.allowedCapabilityIds ?? []).filter((id) => transitionCapabilities.has(id)))
      const globalCounts = new Map()
      const globalLastBeat = new Map()
      let lastHeroBeat = Number.NEGATIVE_INFINITY
      let consecutiveHighEnergy = 0
      const decisions = input.beats.map((beat, index) => {
        const intent = beat.beat_intent
        const matchingHold = holdRules.find((rule) => appliesTo(rule, intent)) ?? null
        const matchingRhythm = rhythmRules.find((rule) => appliesTo(rule, intent)) ?? null
        const matchingLimits = limitRules.filter((rule) => appliesTo(rule, intent))
        let degradationReason = null
        let holdBudgetUs = 0
        if (matchingHold) {
          if (intent.desired_duration_us < matchingHold.minSourceUs) {
            degradationReason = 'hold_source_budget_unavailable'
          } else {
            holdBudgetUs = Math.min(
              matchingHold.maxHoldUs,
              Math.max(matchingHold.minHoldUs, Math.round(intent.desired_duration_us * 0.2)),
            )
          }
        }

        let rhythmClass = matchingRhythm?.rhythmClass ??
          (intent.energy === 'high' ? 'accelerate' : intent.energy === 'low' ? 'rest' : 'steady')
        if (intent.energy === 'high') {
          consecutiveHighEnergy += 1
          const maximum = matchingRhythm?.maxConsecutiveHighEnergy ?? 2
          if (consecutiveHighEnergy > maximum) {
            rhythmClass = 'rest'
            consecutiveHighEnergy = 0
            degradationReason ??= 'rhythm_high_energy_run_bounded'
          }
        } else {
          consecutiveHighEnergy = 0
        }

        let globalTechniqueId = null
        let selectedLimit = null
        for (const rule of matchingLimits) {
          const count = globalCounts.get(rule.techniqueClass) ?? 0
          const lastBeat = globalLastBeat.get(rule.techniqueClass) ?? Number.NEGATIVE_INFINITY
          const heroTechnique = rule.techniqueClass.startsWith('hero_')
          if (count >= rule.maxOccurrences || index - lastBeat <= rule.minRestBeats ||
              (heroTechnique && index - lastHeroBeat <= 2)) continue
          selectedLimit = rule
          globalTechniqueId = rule.techniqueClass
          globalCounts.set(rule.techniqueClass, count + 1)
          globalLastBeat.set(rule.techniqueClass, index)
          if (heroTechnique) lastHeroBeat = index
          break
        }
        if (matchingLimits.length > 0 && !selectedLimit) degradationReason ??= 'global_technique_budget_exhausted'

        let transitionCapabilityId = null
        let selectedSeam = null
        if (index < input.beats.length - 1) {
          selectedSeam = seamRules.find((rule) => !rule.requiresSemanticRelation || intent.shot_role === 'transition') ?? seamRules[0] ?? null
          if (selectedSeam && allowed.has(selectedSeam.capabilityId)) {
            transitionCapabilityId = selectedSeam.capabilityId
          } else if (allowed.has('transition.cut')) {
            transitionCapabilityId = 'transition.cut'
          } else if (allowed.has('transition.none')) {
            transitionCapabilityId = 'transition.none'
          } else {
            degradationReason ??= 'transition_capability_unavailable'
          }
        }

        const sourceRuleIds = boundedRuleIds([
          matchingHold?.ruleId,
          matchingRhythm?.ruleId,
          selectedLimit?.ruleId ?? matchingLimits[0]?.ruleId,
          selectedSeam?.ruleId,
        ].filter(Boolean))
        const decision = {
          beat_id: beat.sentence_id,
          hold_budget_us: holdBudgetUs,
          rhythm_class: rhythmClass,
          transition_capability_id: transitionCapabilityId,
          transition_duration_us: 0,
          global_technique_id: globalTechniqueId,
          degradation_reason: degradationReason,
          source_rule_ids: sourceRuleIds,
        }
        if (!isCreativeTechniqueDecision(decision)) throw new Error('CREATIVE_TECHNIQUE_POLICY_OUTPUT_INVALID')
        return Object.freeze(decision)
      })
      return Object.freeze(decisions)
    },

    /**
     * Produces semantic, token-free sound intent. Catalog authorization and
     * exact placement are deliberately owned by the coordinator.
     * @param {{beats: Record<string, any>[]}} input
     */
    planAudioCues(input) {
      if (!validBeatInput(input)) throw new Error('CREATIVE_AUDIO_CUE_POLICY_INPUT_INVALID')
      const familyCounts = new Map()
      const cues = []
      const importanceRank = new Map([['high', 0], ['medium', 1], ['low', 2]])
      for (const beat of input.beats) {
        const sourceCard = recipeSources.get(beat.selected_recipe_id)
        if (typeof sourceCard !== 'string') continue
        const matches = audioRules
          .filter((rule) => rule.sourceCard === sourceCard && appliesTo(rule, beat.beat_intent))
          .sort((left, right) =>
            (importanceRank.get(left.importance) ?? 9) - (importanceRank.get(right.importance) ?? 9) ||
            left.soundFamily.localeCompare(right.soundFamily) || left.ruleId.localeCompare(right.ruleId))
        const selected = matches.find((rule) =>
          (familyCounts.get(rule.soundFamily) ?? 0) < rule.maxOccurrences)
        if (!selected) continue
        familyCounts.set(selected.soundFamily, (familyCounts.get(selected.soundFamily) ?? 0) + 1)
        const desiredDurationUs = selected.importance === 'high'
          ? 700_000
          : selected.importance === 'low' ? 350_000 : 500_000
        const cue = {
          beat_id: beat.sentence_id,
          semantic_family: selected.soundFamily,
          anchor: selected.anchor,
          importance: selected.importance,
          desired_duration_us: Math.min(desiredDurationUs, beat.beat_intent.desired_duration_us),
          tags: [beat.beat_intent.shot_role, beat.beat_intent.energy, selected.anchor].sort(),
          source_rule_id: selected.ruleId,
          degradation_reason: null,
        }
        if (!isCreativeAudioCueDecision(cue)) throw new Error('CREATIVE_AUDIO_CUE_POLICY_OUTPUT_INVALID')
        cues.push(Object.freeze(cue))
        if (cues.length >= 12) break
      }
      return Object.freeze(cues)
    },
  })
}

export const creativeTechniquePolicyContract = Object.freeze({
  maxBeats,
  maxSourceRules,
  rhythmClasses: Object.freeze([...rhythmClasses]),
  transitionCapabilities: Object.freeze([...transitionCapabilities]),
  soundFamilies: Object.freeze([...soundFamilies].sort()),
  soundAnchors: Object.freeze([...soundAnchors]),
})
