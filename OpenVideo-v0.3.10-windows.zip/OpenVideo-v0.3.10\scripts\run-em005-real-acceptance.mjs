import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { isAbsolute, resolve } from 'node:path'

import { loadGatewayConfig } from '../apps/gateway/src/config.mjs'
import { createGateway } from '../apps/gateway/src/gateway.mjs'
import { createJsonRepositories } from '../apps/gateway/src/local-runtime.mjs'
import { createPermissiveMaterialAnalyzer } from '../apps/gateway/src/permissive-material-analyzer.mjs'

const dataRoot = process.argv[2]
if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('EM005_RUNTIME_ROOT_INVALID')

const providerPath = resolve(dataRoot, 'gateway/provider.json')
const privateProvider = JSON.parse(await readFile(providerPath, 'utf8'))
if (
  privateProvider?.schema_version !== 1 ||
  privateProvider?.provider !== 'openai-compatible' ||
  typeof privateProvider.base_url !== 'string' ||
  typeof privateProvider.api_key !== 'string' ||
  typeof privateProvider.text_model !== 'string' ||
  typeof privateProvider.vision_model !== 'string' ||
  typeof privateProvider.json_model !== 'string'
) throw new Error('EM005_GATEWAY_CONFIG_INVALID')

process.env.OPENVIDEO_LLM_PROVIDER = privateProvider.provider
process.env.OPENVIDEO_LLM_BASE_URL = privateProvider.base_url
process.env.OPENVIDEO_LLM_API_KEY = privateProvider.api_key
process.env.OPENVIDEO_LLM_TEXT_MODEL = privateProvider.text_model
process.env.OPENVIDEO_LLM_VISION_MODEL = privateProvider.vision_model
process.env.OPENVIDEO_LLM_JSON_MODEL = privateProvider.json_model

const repositories = await createJsonRepositories({ dataRoot })
const authorizationDocument = JSON.parse(await readFile(resolve(dataRoot, 'authorizations.json'), 'utf8'))
const authorization = authorizationDocument.records
  .filter((record) => record.status === 'authorized' && record.readOnly === true && record.total >= 20)
  .sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))[0]
if (!authorization) throw new Error('EM005_AUTHORIZATION_NOT_FOUND')

const gateway = createGateway({
  config: loadGatewayConfig(),
  logger: () => {},
})
const analyzer = await createPermissiveMaterialAnalyzer({
  dataRoot,
  authorizationRepository: repositories.authorizationRepository,
  gateway,
})
const initialStatus = analyzer.getStatus()
if (!initialStatus.available) throw new Error(`EM005_PROVIDER_BLOCKED:${initialStatus.code}`)

const materials = await analyzer.analyzeMaterials({
  authorizationId: authorization.id,
  projectId: authorization.projectId,
})
if (materials.total < 20 || materials.analyzed !== materials.total || materials.analysisStatus !== 'ready') {
  throw new Error('EM005_ANALYSIS_INCOMPLETE')
}

const queries = [
  '人物面对镜头讲解产品',
  '产品外观和材质近景细节',
  '手部操作或使用产品',
  '室内生活场景中的产品',
  '包装打开和产品展示',
  '镜头移动展示整体环境',
  '人物与产品互动',
  '自然光下的产品特写',
]
const queryResults = []
for (const query of queries) {
  const candidates = await analyzer.searchCandidates({
    authorizationId: authorization.id,
    projectId: authorization.projectId,
    query,
  })
  queryResults.push({
    query,
    usable: candidates.length === 3 && candidates[0].matchScore >= 0.15,
    candidates,
  })
}
const usableCount = queryResults.filter((entry) => entry.usable).length
const usabilityRate = usableCount / queryResults.length
if (usabilityRate < 0.8) throw new Error('EM005_TOP3_QUALITY_BELOW_THRESHOLD')

const restartedAnalyzer = await createPermissiveMaterialAnalyzer({
  dataRoot,
  authorizationRepository: repositories.authorizationRepository,
  gateway,
})
const restored = await restartedAnalyzer.restoreAnalysis({
  authorizationId: authorization.id,
  projectId: authorization.projectId,
})
if (JSON.stringify(restored) !== JSON.stringify(materials)) throw new Error('EM005_RESTART_RECOVERY_FAILED')

const temporaryEntries = await readdir(resolve(dataRoot, 'material-analysis/tmp'))
if (temporaryEntries.length !== 0) throw new Error('EM005_TEMPORARY_FILES_REMAIN')

const serializedPublic = JSON.stringify({ materials, queryResults }).toLowerCase()
for (const forbidden of [
  authorization.absolutePath.toLowerCase(),
  privateProvider.api_key.toLowerCase(),
  'source_path',
  'relative_path',
  'transcript',
  'provider',
  'api_key',
  'file://',
]) {
  if (serializedPublic.includes(forbidden)) throw new Error('EM005_PUBLIC_RESPONSE_LEAK')
}

const evidenceRoot = resolve(dataRoot, 'evidence/em-005')
await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
await writeFile(resolve(evidenceRoot, 'acceptance.json'), `${JSON.stringify({
  schema_version: 1,
  completed_at: new Date().toISOString(),
  provider_status: restartedAnalyzer.getStatus(),
  material_count: materials.total,
  scene_count: materials.assets.reduce((total, asset) => total + asset.sceneCount, 0),
  query_count: queries.length,
  usable_query_count: usableCount,
  usability_rate: usabilityRate,
  restart_recovery: true,
  temporary_file_count: temporaryEntries.length,
  public_response_leak_count: 0,
  queries: queryResults,
}, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 })

console.log(JSON.stringify({
  material_count: materials.total,
  query_count: queries.length,
  usable_query_count: usableCount,
  usability_rate: usabilityRate,
  restart_recovery: true,
  temporary_file_count: temporaryEntries.length,
}))
