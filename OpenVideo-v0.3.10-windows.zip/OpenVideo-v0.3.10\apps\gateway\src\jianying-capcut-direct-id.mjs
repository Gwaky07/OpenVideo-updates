import {
  assertPackagingWriterBinding,
  computePackagingResourceToken,
} from './jianying-packaging-resource-index.mjs'

const supportedFamilies = new Set(['flower', 'sticker', 'video_effect'])

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** Convert one importer-private identity into the narrow Native Writer binding. */
/** @param {Record<string, any>} sourceEntry */
export const projectCapCutDirectIdBinding = (sourceEntry) => {
  if (!isRecord(sourceEntry) || !supportedFamilies.has(sourceEntry.family)) return null
  if (typeof sourceEntry.private_binding?.resourceId === 'string') {
    try { return assertPackagingWriterBinding(sourceEntry.family, sourceEntry.private_binding) } catch { return null }
  }
  const components = isRecord(sourceEntry.private_binding?.raw_identity_components)
    ? sourceEntry.private_binding.raw_identity_components
    : {}
  const flowerId = sourceEntry.family === 'flower' && typeof components.id === 'string'
    ? components.id
    : null
  const resourceId = typeof components.resource_id === 'string'
    ? components.resource_id
    : flowerId
      ? flowerId
    : typeof sourceEntry.private_binding?.raw_identity === 'string'
      ? sourceEntry.private_binding.raw_identity
      : null
  const effectId = typeof components.effect_id === 'string' ? components.effect_id : flowerId
  const entity = sourceEntry.private_binding?.entity
  const binding = sourceEntry.family === 'sticker'
    ? { resourceId }
    : sourceEntry.family === 'flower'
      ? { resourceId, effectId }
      : { resourceId, effectId, entity }
  try {
    return assertPackagingWriterBinding(sourceEntry.family, binding)
  } catch { return null }
}

/** @param {{sourceEntry: Record<string, any>, profileId: string, appVersion: string}} input */
export const projectCapCutDirectIdWriterEntry = ({ sourceEntry, profileId, appVersion }) => {
  const privateBinding = projectCapCutDirectIdBinding(sourceEntry)
  if (!privateBinding) return null
  const packagingToken = computePackagingResourceToken({
    family: sourceEntry.family,
    profileId,
    appVersion,
    privateBinding,
  })
  return Object.freeze({
    family: sourceEntry.family,
    label: typeof sourceEntry.label === 'string' && sourceEntry.label ? sourceEntry.label : '未命名包装资源',
    tags: Object.freeze(Array.isArray(sourceEntry.tags) ? sourceEntry.tags.slice(0, 16) : []),
    state: 'writer_eligible',
    writer_eligible: true,
    packaging_token: packagingToken,
    parameter_schema: Object.freeze({}),
    private_binding: Object.freeze(structuredClone(privateBinding)),
    resource_mode: 'direct_id',
  })
}
