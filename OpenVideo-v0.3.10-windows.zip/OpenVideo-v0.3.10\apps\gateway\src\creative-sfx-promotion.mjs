import { randomBytes } from 'node:crypto'
import { lstat, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, relative, resolve } from 'node:path'

import { fingerprintCanonical } from './editor-agent-contracts.mjs'

const schemaVersion = 1
const integrityRevision = 1
const capabilityId = 'audio.sfx.local'
const adapterRevision = 'creative-sfx-dual-output-v1'
const receiptRelativePath = 'evidence/creative-sfx/promotion-v1.json'
const fingerprintPattern = /^[a-f0-9]{64}$/u
const profilePattern = /^jianying-[a-z0-9-]{1,80}$/u
const receiptIdPattern = /^ovjypromotion_v1_creative-sfx-[a-f0-9]{16,64}$/u
const codecPattern = /^(?:h264|hevc)$/u
/** @param {unknown} value @param {readonly string[]} keys */
const exactKeys = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) &&
  Object.keys(value).sort().join('\0') === [...keys].sort().join('\0')
/** @param {unknown} value */
const finite = (value) => typeof value === 'number' && Number.isFinite(value)
/** @param {unknown} value */
const safeTime = (value) => Number.isSafeInteger(value) && Number(value) >= 0 && Number(value) <= 24 * 60 * 60 * 1_000_000
/** @param {unknown} value */
const safeDuration = (value) => Number.isSafeInteger(value) && Number(value) > 0 && Number(value) <= 60 * 1_000_000

const receiptKeys = Object.freeze([
  'schemaVersion', 'kind', 'receiptId', 'capabilityId', 'profileId',
  'desktopFingerprint', 'catalogFingerprint', 'adapterRevision',
  'timelineFingerprint', 'cue', 'preview', 'jianying', 'lifecycle', 'runs',
  'automaticPlacementVerified', 'integrityRevision', 'integrityFingerprint',
])
const cueKeys = Object.freeze(['startUs', 'durationUs', 'volume'])
const previewKeys = Object.freeze([
  'mediaFingerprint', 'durationUs', 'videoCodec', 'audioCodec', 'cueStartUs',
  'cueDurationUs', 'sourceFingerprint', 'detectedStartUs', 'offsetDeltaUs',
  'correlationPeak', 'offsetVerified',
])
const jianyingKeys = Object.freeze([
  'draftFingerprint', 'cueStartUs', 'cueDurationUs', 'canonicalVolume',
  'encodedVolume', 'expectedEncodedVolume', 'volumeDelta', 'editable',
])
const lifecycleKeys = Object.freeze([
  'opened', 'edited', 'saved', 'closed', 'reopened', 'sameDraft',
  'initialDraftFingerprint', 'editedDraftFingerprint', 'restoredDraftFingerprint',
])
const runKeys = Object.freeze([
  'bootFingerprint', 'previewJobFingerprint', 'jianyingJobFingerprint',
  'timelineFingerprint', 'previewSucceeded', 'jianyingSucceeded',
])

/** @param {Record<string, unknown>} receipt */
const integrityFingerprint = (receipt) => fingerprintCanonical(Object.fromEntries(
  Object.entries(receipt).filter(([key]) => key !== 'integrityFingerprint'),
))

/** @param {{profileId?: unknown, version?: unknown, dllFingerprint?: unknown}} desktop */
export const fingerprintCreativeSfxDesktop = (desktop) => {
  if (!profilePattern.test(String(desktop?.profileId ?? '')) ||
      typeof desktop?.version !== 'string' || desktop.version.length < 1 || desktop.version.length > 80 ||
      !fingerprintPattern.test(String(desktop?.dllFingerprint ?? ''))) return null
  return fingerprintCanonical({
    profileId: desktop.profileId,
    version: desktop.version,
    dllFingerprint: desktop.dllFingerprint,
  })
}

/** @param {unknown} value */
export const parseCreativeSfxPromotionReceipt = (value) => {
  if (!exactKeys(value, receiptKeys)) return null
  const receipt = /** @type {Record<string, any>} */ (value)
  if (receipt.schemaVersion !== schemaVersion ||
      receipt.kind !== 'creative_sfx_dual_output_promotion_receipt' ||
      receipt.capabilityId !== capabilityId ||
      !receiptIdPattern.test(receipt.receiptId ?? '') ||
      !profilePattern.test(receipt.profileId ?? '') ||
      ![receipt.desktopFingerprint, receipt.catalogFingerprint, receipt.timelineFingerprint]
        .every((entry) => fingerprintPattern.test(entry ?? '')) ||
      receipt.adapterRevision !== adapterRevision ||
      !exactKeys(receipt.cue, cueKeys) || !safeTime(receipt.cue.startUs) ||
      !safeDuration(receipt.cue.durationUs) || !finite(receipt.cue.volume) ||
      receipt.cue.volume < 0 || receipt.cue.volume > 1 ||
      !exactKeys(receipt.preview, previewKeys) ||
      !fingerprintPattern.test(receipt.preview.mediaFingerprint ?? '') ||
      !safeDuration(receipt.preview.durationUs) || !codecPattern.test(receipt.preview.videoCodec ?? '') ||
      receipt.preview.audioCodec !== 'aac' || !safeTime(receipt.preview.cueStartUs) ||
      !safeDuration(receipt.preview.cueDurationUs) ||
      !fingerprintPattern.test(receipt.preview.sourceFingerprint ?? '') ||
      !safeTime(receipt.preview.detectedStartUs) || !safeTime(receipt.preview.offsetDeltaUs) ||
      !finite(receipt.preview.correlationPeak) || Math.abs(receipt.preview.correlationPeak) < 0.35 ||
      Math.abs(receipt.preview.correlationPeak) > 1 || receipt.preview.offsetDeltaUs > 20_000 ||
      receipt.preview.offsetVerified !== true ||
      !exactKeys(receipt.jianying, jianyingKeys) ||
      !fingerprintPattern.test(receipt.jianying.draftFingerprint ?? '') ||
      !safeTime(receipt.jianying.cueStartUs) || !safeDuration(receipt.jianying.cueDurationUs) ||
      ![receipt.jianying.canonicalVolume, receipt.jianying.encodedVolume,
        receipt.jianying.expectedEncodedVolume, receipt.jianying.volumeDelta].every(finite) ||
      receipt.jianying.canonicalVolume < 0 || receipt.jianying.canonicalVolume > 1 ||
      receipt.jianying.volumeDelta < 0 || receipt.jianying.volumeDelta > 1e-6 ||
      receipt.jianying.editable !== true || !exactKeys(receipt.lifecycle, lifecycleKeys) ||
      [receipt.lifecycle.opened, receipt.lifecycle.edited, receipt.lifecycle.saved,
        receipt.lifecycle.closed, receipt.lifecycle.reopened, receipt.lifecycle.sameDraft]
        .some((entry) => entry !== true) ||
      ![receipt.lifecycle.initialDraftFingerprint, receipt.lifecycle.editedDraftFingerprint,
        receipt.lifecycle.restoredDraftFingerprint]
        .every((entry) => fingerprintPattern.test(entry ?? '')) ||
      receipt.lifecycle.initialDraftFingerprint === receipt.lifecycle.editedDraftFingerprint ||
      receipt.lifecycle.editedDraftFingerprint === receipt.lifecycle.restoredDraftFingerprint ||
      !Array.isArray(receipt.runs) || receipt.runs.length !== 3 ||
      receipt.automaticPlacementVerified !== true || receipt.integrityRevision !== integrityRevision ||
      !fingerprintPattern.test(receipt.integrityFingerprint ?? '') ||
      integrityFingerprint(receipt) !== receipt.integrityFingerprint) return null
  if (receipt.preview.cueStartUs !== receipt.cue.startUs ||
      receipt.preview.cueDurationUs !== receipt.cue.durationUs ||
      Math.abs(receipt.preview.detectedStartUs - receipt.cue.startUs) !== receipt.preview.offsetDeltaUs ||
      receipt.jianying.cueStartUs !== receipt.cue.startUs ||
      receipt.jianying.cueDurationUs !== receipt.cue.durationUs ||
      Math.abs(receipt.jianying.canonicalVolume - receipt.cue.volume) > 1e-9 ||
      Math.abs(receipt.jianying.encodedVolume - receipt.jianying.expectedEncodedVolume) > 1e-6) return null
  const bootFingerprints = new Set()
  for (const run of receipt.runs) {
    if (!exactKeys(run, runKeys) ||
        ![run.bootFingerprint, run.previewJobFingerprint, run.jianyingJobFingerprint,
          run.timelineFingerprint].every((entry) => fingerprintPattern.test(entry ?? '')) ||
        run.timelineFingerprint !== receipt.timelineFingerprint ||
        run.previewSucceeded !== true || run.jianyingSucceeded !== true) return null
    bootFingerprints.add(run.bootFingerprint)
  }
  if (bootFingerprints.size !== 3) return null
  return Object.freeze(structuredClone(receipt))
}

/**
 * Build the private receipt only from already-inspected, path-free evidence.
 * Raw media paths and draft identifiers are deliberately not accepted.
 */
/** @param {Record<string, any>} input */
export const createCreativeSfxPromotionReceipt = (input) => {
  const receipt = {
    schemaVersion,
    kind: 'creative_sfx_dual_output_promotion_receipt',
    receiptId: input.receiptId ?? `ovjypromotion_v1_creative-sfx-${randomBytes(12).toString('hex')}`,
    capabilityId,
    profileId: input.profileId,
    desktopFingerprint: input.desktopFingerprint,
    catalogFingerprint: input.catalogFingerprint,
    adapterRevision,
    timelineFingerprint: input.timelineFingerprint,
    cue: structuredClone(input.cue),
    preview: structuredClone(input.preview),
    jianying: structuredClone(input.jianying),
    lifecycle: structuredClone(input.lifecycle),
    runs: structuredClone(input.runs),
    automaticPlacementVerified: input.automaticPlacementVerified === true,
    integrityRevision,
  }
  const signed = { ...receipt, integrityFingerprint: integrityFingerprint(receipt) }
  const parsed = parseCreativeSfxPromotionReceipt(signed)
  if (!parsed) throw new Error('CREATIVE_SFX_PROMOTION_RECEIPT_INVALID')
  return parsed
}

/** @param {string} dataRoot @param {string} path */
const assertOwnedPath = (dataRoot, path) => {
  const root = resolve(dataRoot)
  const output = resolve(path)
  const child = relative(root, output)
  if (!child || child.startsWith('..') || resolve(root, child) !== output) {
    throw new Error('CREATIVE_SFX_PROMOTION_STORAGE_INVALID')
  }
  return output
}

/** @param {{dataRoot: string, receipt: unknown, securePrivateRoot?: (path: string) => Promise<void>}} input */
export const publishCreativeSfxPromotionReceipt = async ({
  dataRoot,
  receipt,
  securePrivateRoot = async () => {},
}) => {
  const parsed = parseCreativeSfxPromotionReceipt(receipt)
  if (!parsed) throw new Error('CREATIVE_SFX_PROMOTION_RECEIPT_INVALID')
  const output = assertOwnedPath(dataRoot, resolve(dataRoot, receiptRelativePath))
  const root = dirname(output)
  await mkdir(root, { recursive: true, mode: 0o700 })
  const metadata = await lstat(root)
  if (!metadata.isDirectory() || metadata.isSymbolicLink()) throw new Error('CREATIVE_SFX_PROMOTION_STORAGE_INVALID')
  await securePrivateRoot(root)
  const temporary = `${output}.${randomBytes(8).toString('hex')}.tmp`
  try {
    await writeFile(temporary, `${JSON.stringify(parsed)}\n`, { flag: 'wx', mode: 0o600 })
    await rm(output, { force: true })
    await rename(temporary, output)
  } finally {
    await rm(temporary, { force: true }).catch(() => {})
  }
  return Object.freeze({ stored: true, receiptId: parsed.receiptId })
}

/**
 * Load and rebind the private evidence to the current desktop and catalog.
 * The returned projection is the only shape allowed to reach the registry.
 */
/** @param {{dataRoot: string, desktop: Record<string, unknown>, catalogFingerprint: unknown}} input */
export const loadCreativeSfxPromotionProjection = async ({ dataRoot, desktop, catalogFingerprint }) => {
  const currentDesktopFingerprint = fingerprintCreativeSfxDesktop(desktop)
  if (!currentDesktopFingerprint || typeof catalogFingerprint !== 'string' ||
      !fingerprintPattern.test(catalogFingerprint)) return null
  const path = assertOwnedPath(dataRoot, resolve(dataRoot, receiptRelativePath))
  try {
    const metadata = await lstat(path)
    if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size <= 0 || metadata.size > 256 * 1024) return null
    const parsed = parseCreativeSfxPromotionReceipt(JSON.parse(await readFile(path, 'utf8')))
    if (!parsed || parsed.profileId !== desktop.profileId ||
        parsed.desktopFingerprint !== currentDesktopFingerprint ||
        parsed.catalogFingerprint !== catalogFingerprint) return null
    return Object.freeze({
      receiptId: parsed.receiptId,
      capabilityId,
      profileId: parsed.profileId,
      exactProfileMatch: true,
      writerReady: true,
      catalogReady: true,
      openEvidence: true,
      editEvidence: true,
      saveEvidence: true,
      reopenEvidence: true,
      previewReady: true,
      dualOutputReady: true,
      stableReceiptCount: parsed.runs.length,
      automaticPlacementReady: parsed.automaticPlacementVerified,
      catalogFingerprint: parsed.catalogFingerprint,
    })
  } catch {
    return null
  }
}

export const creativeSfxPromotionContract = Object.freeze({
  schemaVersion,
  capabilityId,
  adapterRevision,
  receiptRelativePath,
})
