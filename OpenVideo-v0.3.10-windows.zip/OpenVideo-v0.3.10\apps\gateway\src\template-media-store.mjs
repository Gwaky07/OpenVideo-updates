import { createHash } from 'node:crypto'
import { execFile } from 'node:child_process'
import { createReadStream, existsSync, realpathSync } from 'node:fs'
import {
  chmod,
  copyFile,
  lstat,
  mkdir,
  open,
  readFile,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { basename, dirname, extname, isAbsolute, join, relative, resolve } from 'node:path'
import { Readable } from 'node:stream'
import { promisify } from 'node:util'
import { isAuthenticTemplateDemo } from './template-demo-renderer.mjs'
import { isReplicationRecipe } from './replication-recipe.mjs'

const templateAudioExtensions = Object.freeze(['.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg'])

const execFileAsync = promisify(execFile)

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const identifier = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {string} value */
const canonicalizePotentialPath = (value) => {
  let existingAncestor = resolve(value)
  const missingSegments = []
  while (!existsSync(existingAncestor)) {
    const parent = dirname(existingAncestor)
    if (parent === existingAncestor) break
    missingSegments.unshift(basename(existingAncestor))
    existingAncestor = parent
  }
  const canonicalAncestor = existsSync(existingAncestor)
    ? realpathSync.native(existingAncestor)
    : existingAncestor
  return resolve(canonicalAncestor, ...missingSegments)
}
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const fragment = relative(canonicalizePotentialPath(parent), canonicalizePotentialPath(child))
  return fragment === '' || (!fragment.startsWith('..') && !isAbsolute(fragment))
}

export class TemplateMediaStoreError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'TemplateMediaStoreError'
    this.code = code
    this.status = status
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   ffmpegPath?: string | null,
 *   demoRenderer?: { render: Function } | null,
 *   styleAnalyzer?: { analyze: Function } | null,
 * }} options
 */
export const createTemplateMediaStore = ({
  dataRoot,
  ffmpegPath = null,
  demoRenderer = null,
  styleAnalyzer = null,
}) => {
  if (!dataRoot || !isAbsolute(dataRoot)) {
    throw new TemplateMediaStoreError('TEMPLATE_MEDIA_ROOT_INVALID', 503)
  }
  const root = resolve(dataRoot, 'template-library-media')
  /** @type {Map<string, Promise<any>>} */
  const queues = new Map()

  /** @template T @param {string} libraryTemplateId @param {() => Promise<T>} operation */
  const serializeTemplateMutation = async (libraryTemplateId, operation) => {
    const previous = queues.get(libraryTemplateId) || Promise.resolve()
    const next = previous.catch(() => {}).then(operation)
    queues.set(libraryTemplateId, next)
    try {
      return await next
    } finally {
      if (queues.get(libraryTemplateId) === next) queues.delete(libraryTemplateId)
    }
  }

  /** @param {string} libraryTemplateId */
  const templateDir = (libraryTemplateId) => {
    if (!identifier(libraryTemplateId)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_ID_INVALID', 400)
    }
    return resolve(root, libraryTemplateId)
  }

  /** @param {string} libraryTemplateId */
  const metaPath = (libraryTemplateId) => join(templateDir(libraryTemplateId), 'media.json')

  /** @param {string} libraryTemplateId */
  const readMeta = async (libraryTemplateId) => {
    try {
      const raw = JSON.parse(await readFile(metaPath(libraryTemplateId), 'utf8'))
      return record(raw) ? raw : null
    } catch (error) {
      if (record(error) && error.code === 'ENOENT') return null
      throw error
    }
  }

  /** @param {string} libraryTemplateId @param {Record<string, any>} meta */
  const writeMeta = async (libraryTemplateId, meta) => {
    const directory = templateDir(libraryTemplateId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const temporary = join(directory, `media.${process.pid}.${Date.now()}.tmp`)
    await writeFile(temporary, `${JSON.stringify(meta, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 })
    await rename(temporary, metaPath(libraryTemplateId))
    await chmod(metaPath(libraryTemplateId), 0o600).catch(() => {})
  }

  /**
   * @param {string} libraryTemplateId
   * @param {string} sourcePath
   * @param {{contentType?: string}} [options]
   */
  const ingestReference = async (libraryTemplateId, sourcePath, options = {}) =>
    serializeTemplateMutation(libraryTemplateId, () => ingestReferenceUnlocked(libraryTemplateId, sourcePath, options))

  /**
   * @param {string} libraryTemplateId
   * @param {string} sourcePath
   * @param {{contentType?: string}} options
   */
  const ingestReferenceUnlocked = async (libraryTemplateId, sourcePath, options) => {
    if (!isAbsolute(sourcePath) || !existsSync(sourcePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_SOURCE_MISSING', 409)
    }
    const previousMeta = await readMeta(libraryTemplateId)
    const directory = templateDir(libraryTemplateId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const extension = extname(sourcePath).toLowerCase()
    if (!['.mp4', '.mov', '.webm', '.mkv', '.m4v'].includes(extension)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_SOURCE_INVALID', 400)
    }
    const safeExtension = extension
    const target = join(directory, `reference${safeExtension}`)
    const temporary = join(directory, `reference.${process.pid}.tmp`)
    await copyFile(sourcePath, temporary)
    await rename(temporary, target)
    await chmod(target, 0o600).catch(() => {})
    const info = await stat(target)
    const hash = createHash('sha256')
    await new Promise((resolveHash, rejectHash) => {
      const stream = createReadStream(target)
      stream.on('data', (chunk) => hash.update(chunk))
      stream.on('error', rejectHash)
      stream.on('end', () => resolveHash(undefined))
    })
    const meta = {
      libraryTemplateId,
      reference: {
        fileName: `reference${safeExtension}`,
        contentType: options.contentType || 'video/mp4',
        byteSize: info.size,
        sha256: hash.digest('hex'),
      },
      demo: {
        status: 'pending',
        fileName: null,
        contentType: null,
        byteSize: null,
        sha256: null,
        renderer: null,
        authentic: false,
      },
      styleAnalysis: {
        analysisComplete: false,
        analyzerVersion: null,
      },
      ...(record(previousMeta?.audioAssets)
        ? { audioAssets: structuredClone(previousMeta.audioAssets) }
        : {}),
      updatedAt: new Date().toISOString(),
    }
    await writeMeta(libraryTemplateId, meta)
    return meta
  }

  /**
   * @param {string} libraryTemplateId
   * @param {{
   *   durationSeconds?: number,
   *   label?: string,
   *   storedTemplate?: Record<string, any>,
   *   styleSummary?: Record<string, any>,
   * }} [options]
   */
  const generateDemo = async (libraryTemplateId, options = {}) => {
    return serializeTemplateMutation(libraryTemplateId, () => generateDemoUnlocked(libraryTemplateId, options))
  }

  /**
   * @param {string} libraryTemplateId
   * @param {Record<string, any>} [options]
   */
  const generateDemoUnlocked = async (libraryTemplateId, options = {}) => {
    const meta = await readMeta(libraryTemplateId)
    if (!meta?.reference?.fileName) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_MISSING', 409)
    }
    const directory = templateDir(libraryTemplateId)
    const referencePath = join(directory, meta.reference.fileName)
    if (!inside(directory, referencePath) || !existsSync(referencePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_MISSING', 409)
    }

    let styleSummary = options.styleSummary || null
    let analysisComplete = false
    if (styleAnalyzer && typeof styleAnalyzer.analyze === 'function' && record(options.storedTemplate?.artifact)) {
      try {
        const report = await styleAnalyzer.analyze({
          sourcePath: referencePath,
          artifact: options.storedTemplate.artifact,
          libraryTemplateId,
        })
        styleSummary = report.styleSummary
        analysisComplete = report.analysisComplete === true
        meta.styleAnalysis = {
          analysisComplete,
          analyzerVersion: report.analyzerVersion,
          sampleCount: report.sampleCount,
        }
        await writeFile(
          join(directory, 'style-analysis.json'),
          `${JSON.stringify({
            analyzerVersion: report.analyzerVersion,
            analysisComplete,
            sampleCount: report.sampleCount,
            styleSummary,
            updatedAt: new Date().toISOString(),
          }, null, 2)}\n`,
          { encoding: 'utf8', mode: 0o600 },
        )
      } catch {
        meta.styleAnalysis = {
          analysisComplete: false,
          analyzerVersion: null,
          errorCode: 'TEMPLATE_STYLE_ANALYSIS_FAILED',
        }
      }
    }

    if (!demoRenderer || typeof demoRenderer.render !== 'function' || !record(options.storedTemplate) || !styleSummary) {
      meta.demo = {
        status: 'failed',
        fileName: null,
        contentType: null,
        byteSize: null,
        sha256: null,
        renderer: null,
        authentic: false,
        errorCode: 'TEMPLATE_DEMO_RENDERER_REQUIRED',
      }
      meta.updatedAt = new Date().toISOString()
      await writeMeta(libraryTemplateId, meta)
      return { meta, styleSummary }
    }

    try {
      const rendered = await demoRenderer.render({
        libraryTemplateId,
        referencePath,
        outputDir: directory,
        storedTemplate: options.storedTemplate,
        styleSummary,
        durationSeconds: options.durationSeconds,
        label: options.label,
      })
      if (!isAuthenticTemplateDemo(rendered)) {
        throw new TemplateMediaStoreError('TEMPLATE_DEMO_NOT_AUTHENTIC', 502)
      }
      meta.demo = {
        status: 'ready',
        fileName: rendered.fileName,
        contentType: rendered.contentType,
        byteSize: rendered.byteSize,
        sha256: rendered.sha256,
        durationSeconds: rendered.durationSeconds,
        renderer: 'template_demo_renderer',
        authentic: true,
        method: rendered.method,
        bindingFingerprint: rendered.bindingFingerprint,
        demoFingerprint: rendered.demoFingerprint,
      }
      meta.updatedAt = new Date().toISOString()
      await writeMeta(libraryTemplateId, meta)
      return { meta, styleSummary }
    } catch (error) {
      meta.demo = {
        status: 'failed',
        fileName: null,
        contentType: null,
        byteSize: null,
        sha256: null,
        renderer: null,
        authentic: false,
        errorCode: error instanceof TemplateMediaStoreError
          ? error.code
          : 'TEMPLATE_DEMO_RENDER_FAILED',
      }
      meta.updatedAt = new Date().toISOString()
      await writeMeta(libraryTemplateId, meta)
      throw error instanceof TemplateMediaStoreError
        ? error
        : new TemplateMediaStoreError('TEMPLATE_DEMO_RENDER_FAILED', 502)
    }
  }

  /**
   * @param {string} libraryTemplateId
   * @param {'reference' | 'demo'} kind
   */
  const resolveResource = async (libraryTemplateId, kind) => {
    const meta = await readMeta(libraryTemplateId)
    if (!meta) throw new TemplateMediaStoreError('TEMPLATE_MEDIA_NOT_FOUND', 404)
    const entry = kind === 'demo' ? meta.demo : meta.reference
    if (!entry?.fileName || (kind === 'demo' && entry.status !== 'ready')) {
      throw new TemplateMediaStoreError(
        kind === 'demo' ? 'TEMPLATE_DEMO_UNAVAILABLE' : 'TEMPLATE_MEDIA_REFERENCE_MISSING',
        409,
      )
    }
    const directory = templateDir(libraryTemplateId)
    const filePath = join(directory, entry.fileName)
    if (!inside(directory, filePath) || !existsSync(filePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_FILE_MISSING', 409)
    }
    const info = await stat(filePath)
    return {
      size: info.size,
      contentType: entry.contentType || 'video/mp4',
      etag: `"${entry.sha256 || info.mtimeMs}"`,
      createStream: ({ start = 0, end = info.size - 1 } = {}) =>
        /** @type {ReadableStream} */ (
          /** @type {unknown} */ (Readable.toWeb(createReadStream(filePath, { start, end })))
        ),
    }
  }

  /** @param {string} libraryTemplateId */
  const readStyleSummary = async (libraryTemplateId) => {
    try {
      const raw = JSON.parse(await readFile(join(templateDir(libraryTemplateId), 'style-analysis.json'), 'utf8'))
      return record(raw?.styleSummary) ? raw.styleSummary : null
    } catch {
      return null
    }
  }

  /** @param {string} libraryTemplateId @param {unknown} recipe */
  const writeReplicationRecipe = async (libraryTemplateId, recipe) => {
    if (!isReplicationRecipe(recipe)) {
      throw new TemplateMediaStoreError('TEMPLATE_REPLICATION_RECIPE_INVALID', 400)
    }
    const directory = templateDir(libraryTemplateId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const target = join(directory, 'replication-recipe.json')
    const temporary = join(directory, `replication-recipe.${process.pid}.${Date.now()}.tmp`)
    await writeFile(
      temporary,
      `${JSON.stringify({ schema_version: 1, recipe, updatedAt: new Date().toISOString() }, null, 2)}\n`,
      { encoding: 'utf8', mode: 0o600 },
    )
    await rename(temporary, target)
    await chmod(target, 0o600).catch(() => {})
    return structuredClone(recipe)
  }

  /** @param {string} libraryTemplateId */
  const readReplicationRecipe = async (libraryTemplateId) => {
    try {
      const raw = JSON.parse(
        await readFile(join(templateDir(libraryTemplateId), 'replication-recipe.json'), 'utf8'),
      )
      return raw?.schema_version === 1 && isReplicationRecipe(raw.recipe)
        ? structuredClone(raw.recipe)
        : null
    } catch {
      return null
    }
  }

  /**
   * Ingest a trusted local audio file into the template private media store.
   * @param {string} libraryTemplateId
   * @param {{ sourcePath: string, role: 'bgm' | 'sfx' }} input
   */
  const ingestAudio = async (libraryTemplateId, input) =>
    serializeTemplateMutation(libraryTemplateId, () => ingestAudioUnlocked(libraryTemplateId, input))

  /**
   * @param {string} libraryTemplateId
   * @param {{sourcePath: string, role: 'bgm'|'sfx'}} input
   */
  const ingestAudioUnlocked = async (libraryTemplateId, input) => {
    if (!record(input) || (input.role !== 'bgm' && input.role !== 'sfx')) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_INVALID', 400)
    }
    if (!isAbsolute(input.sourcePath) || !existsSync(input.sourcePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_SOURCE_MISSING', 409)
    }
    const extension = extname(input.sourcePath).toLowerCase()
    if (!templateAudioExtensions.includes(extension)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_INVALID', 400)
    }
    const directory = templateDir(libraryTemplateId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const hash = createHash('sha256')
    await new Promise((resolveHash, rejectHash) => {
      const stream = createReadStream(input.sourcePath)
      stream.on('data', (chunk) => hash.update(chunk))
      stream.on('error', rejectHash)
      stream.on('end', () => resolveHash(undefined))
    })
    const digest = hash.digest('hex')
    const audioToken = `tma_${input.role}_${digest.slice(0, 24)}`
    const fileName = `${audioToken}${extension}`
    const target = join(directory, fileName)
    if (!inside(directory, target)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_ROOT_INVALID', 503)
    }
    if (!existsSync(target)) {
      const temporary = join(directory, `${audioToken}.${process.pid}.tmp`)
      await copyFile(input.sourcePath, temporary)
      await rename(temporary, target)
      await chmod(target, 0o600).catch(() => {})
    }
    const info = await stat(target)
    const meta = (await readMeta(libraryTemplateId)) || {
      libraryTemplateId,
      updatedAt: new Date().toISOString(),
    }
    const audioAssets = record(meta.audioAssets) ? meta.audioAssets : {}
    audioAssets[audioToken] = {
      role: input.role,
      fileName,
      contentType: extension === '.mp3' ? 'audio/mpeg' : `audio/${extension.slice(1)}`,
      byteSize: info.size,
      sha256: digest,
    }
    meta.audioAssets = audioAssets
    meta.updatedAt = new Date().toISOString()
    await writeMeta(libraryTemplateId, meta)
    return { audioToken, role: input.role, fileName, sha256: digest }
  }

  /**
   * Extract the first audio stream from this template's already-private reference video.
   * The source video is never modified; the temporary extraction is removed after ingestion.
   * @param {string} libraryTemplateId
   * @param {{ role?: 'bgm' }} [input]
   */
  const ingestReferenceAudio = async (libraryTemplateId, input = {}) => {
    if (!record(input) || (input.role !== undefined && input.role !== 'bgm')) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_INVALID', 400)
    }
    const ffmpeg = typeof ffmpegPath === 'string' && existsSync(ffmpegPath)
      ? ffmpegPath
      : null
    if (!ffmpeg) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_EXTRACTOR_UNAVAILABLE', 503)
    }
    const meta = await readMeta(libraryTemplateId)
    const directory = templateDir(libraryTemplateId)
    const referenceFileName = meta?.reference?.fileName
    const referencePath = typeof referenceFileName === 'string'
      ? join(directory, referenceFileName)
      : null
    if (!referencePath || !inside(directory, referencePath) || !existsSync(referencePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_AUDIO_UNAVAILABLE', 409)
    }
    const temporary = join(directory, `reference-audio.${process.pid}.${Date.now()}.m4a`)
    try {
      await execFileAsync(ffmpeg, [
        '-nostdin', '-y', '-i', referencePath,
        '-map', '0:a:0', '-vn', '-c:a', 'aac', '-b:a', '192k', temporary,
      ], { windowsHide: true, timeout: 120_000, maxBuffer: 64 * 1024 })
      if (!existsSync(temporary)) {
        throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_AUDIO_UNAVAILABLE', 409)
      }
      return await ingestAudio(libraryTemplateId, { sourcePath: temporary, role: 'bgm' })
    } catch (error) {
      if (error instanceof TemplateMediaStoreError) throw error
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_AUDIO_UNAVAILABLE', 409)
    } finally {
      await rm(temporary, { force: true }).catch(() => {})
    }
  }

  /**
   * Resolve a private absolute path for a template audio token.
   * @param {string} libraryTemplateId
   * @param {string} audioToken
   */
  const resolveAudioPath = async (libraryTemplateId, audioToken) => {
    if (!identifier(audioToken) || !audioToken.startsWith('tma_')) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_INVALID', 400)
    }
    const meta = await readMeta(libraryTemplateId)
    const entry = meta?.audioAssets?.[audioToken]
    if (!record(entry) || typeof entry.fileName !== 'string') {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_MISSING', 409)
    }
    const directory = templateDir(libraryTemplateId)
    const filePath = join(directory, entry.fileName)
    if (!inside(directory, filePath) || !existsSync(filePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_MISSING', 409)
    }
    return filePath
  }

  /**
   * Acquire a content-bound private lease for one template audio asset. The
   * open handle pins the verified file while its bytes are copied to owned
   * staging; callers must release it on every path.
   * @param {string} libraryTemplateId
   * @param {string} audioToken
   * @param {'bgm'|'sfx'} expectedRole
   */
  const acquireAudioLease = async (libraryTemplateId, audioToken, expectedRole) => {
    const tokenMatch = typeof audioToken === 'string'
      ? /^tma_(bgm|sfx)_([a-f0-9]{24})$/u.exec(audioToken)
      : null
    if (!['bgm', 'sfx'].includes(expectedRole) || tokenMatch?.[1] !== expectedRole) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_ROLE_MISMATCH', 409)
    }
    const meta = await readMeta(libraryTemplateId)
    const entry = meta?.audioAssets?.[audioToken]
    const extension = record(entry) && typeof entry.fileName === 'string'
      ? extname(entry.fileName).toLowerCase()
      : ''
    if (!record(entry) || entry.role !== expectedRole ||
        !templateAudioExtensions.includes(extension) || entry.fileName !== `${audioToken}${extension}` ||
        typeof entry.byteSize !== 'number' || !Number.isSafeInteger(entry.byteSize) || entry.byteSize < 0 ||
        typeof entry.sha256 !== 'string' || !/^[a-f0-9]{64}$/u.test(entry.sha256) ||
        !entry.sha256.startsWith(tokenMatch[2])) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_ROLE_MISMATCH', 409)
    }
    const directory = templateDir(libraryTemplateId)
    const filePath = join(directory, entry.fileName)
    if (!inside(directory, filePath) || !existsSync(filePath)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_MISSING', 409)
    }
    const linkInfo = await lstat(filePath)
    if (!linkInfo.isFile() || linkInfo.isSymbolicLink()) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_STALE', 409)
    }
    const handle = await open(filePath, 'r')
    let released = false
    const digestHandle = async () => {
      const hash = createHash('sha256')
      await new Promise((resolveHash, rejectHash) => {
        const stream = handle.createReadStream({ autoClose: false, start: 0 })
        stream.on('data', (chunk) => hash.update(chunk))
        stream.on('error', rejectHash)
        stream.on('end', () => resolveHash(undefined))
      })
      return hash.digest('hex')
    }
    try {
      const handleInfo = await handle.stat()
      if (!handleInfo.isFile() || handleInfo.size !== entry.byteSize || await digestHandle() !== entry.sha256) {
        throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_STALE', 409)
      }
      return Object.freeze({
        extension,
        sha256: entry.sha256,
        size: entry.byteSize,
        createStream: () => {
          if (released) throw new TemplateMediaStoreError('TEMPLATE_MEDIA_AUDIO_LEASE_RELEASED', 409)
          return handle.createReadStream({ autoClose: false, start: 0 })
        },
        verifyIntegrity: async () => {
          if (released) return false
          const current = await handle.stat()
          return current.isFile() && current.size === entry.byteSize && await digestHandle() === entry.sha256
        },
        release: async () => {
          if (released) return
          released = true
          await handle.close()
        },
      })
    } catch (error) {
      await handle.close().catch(() => {})
      throw error
    }
  }

  /**
   * Private packaging token map (resource_id never leaves this sidecar).
   * @param {string} libraryTemplateId
   * @param {Array<Record<string, any>>} entries
   */
  const writePackagingMap = async (libraryTemplateId, entries) => {
    if (!Array.isArray(entries)) {
      throw new TemplateMediaStoreError('TEMPLATE_PACKAGING_MAP_INVALID', 400)
    }
    const directory = templateDir(libraryTemplateId)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    const normalized = entries.map((entry) => {
      if (
        !record(entry) ||
        !identifier(entry.token) ||
        !['sticker', 'effect', 'flower', 'bubble'].includes(entry.kind) ||
        typeof entry.resourceId !== 'string' ||
        !/^[A-Za-z0-9_-]{4,80}$/u.test(entry.resourceId) ||
        (entry.kind === 'bubble' && (
          typeof entry.effectId !== 'string' ||
          !/^[A-Za-z0-9_-]{4,80}$/u.test(entry.effectId)
        )) ||
        (entry.effectId !== undefined && (
          !['flower', 'bubble', 'effect'].includes(entry.kind) ||
          typeof entry.effectId !== 'string' ||
          !/^[A-Za-z0-9_-]{4,80}$/u.test(entry.effectId)
        ))
      ) {
        throw new TemplateMediaStoreError('TEMPLATE_PACKAGING_MAP_INVALID', 400)
      }
      /** @type {Record<string, any>} */
      const normalized = {
        token: entry.token,
        kind: entry.kind,
        resourceId: entry.resourceId,
        fingerprint: typeof entry.fingerprint === 'string' ? entry.fingerprint : null,
      }
      if (entry.kind === 'bubble' || (entry.kind === 'effect' && entry.effectId)) {
        normalized.effectId = entry.effectId
      }
      return normalized
    })
    const target = join(directory, 'packaging-map.json')
    const temporary = join(directory, `packaging-map.${process.pid}.${Date.now()}.tmp`)
    await writeFile(
      temporary,
      `${JSON.stringify({ schema_version: 1, entries: normalized, updatedAt: new Date().toISOString() }, null, 2)}\n`,
      { encoding: 'utf8', mode: 0o600 },
    )
    await rename(temporary, target)
    await chmod(target, 0o600).catch(() => {})
    return structuredClone(normalized)
  }

  /** @param {string} libraryTemplateId */
  const readPackagingMap = async (libraryTemplateId) => {
    try {
      const raw = JSON.parse(
        await readFile(join(templateDir(libraryTemplateId), 'packaging-map.json'), 'utf8'),
      )
      return raw?.schema_version === 1 && Array.isArray(raw.entries)
        ? structuredClone(raw.entries)
        : []
    } catch {
      return []
    }
  }

  /**
   * Resolve private packaging resource for Jianying writer only.
   * @param {string} libraryTemplateId
   * @param {string} token
   */
  const resolvePackagingToken = async (libraryTemplateId, token) => {
    const entries = await readPackagingMap(libraryTemplateId)
    const match = entries.find((/** @type {Record<string, any>} */ entry) => entry.token === token)
    if (!match) {
      throw new TemplateMediaStoreError('TEMPLATE_PACKAGING_TOKEN_MISSING', 409)
    }
    return structuredClone(match)
  }

  /** @param {string} libraryTemplateId */
  const previewAvailability = async (libraryTemplateId) => {
    const meta = await readMeta(libraryTemplateId)
    if (!meta?.reference?.fileName) {
      return {
        referencePlayable: false,
        demoPlayable: false,
        demoStatus: 'unavailable',
        demoRenderer: null,
        demoAuthentic: false,
        demoMeaningful: false,
        demoAppliedCapabilities: [],
        styleAnalysisComplete: false,
        approveReady: false,
      }
    }
    const directory = templateDir(libraryTemplateId)
    const referencePath = join(directory, meta.reference.fileName)
    const referencePlayable = inside(directory, referencePath) && existsSync(referencePath)
    const demoStatus = meta.demo?.status === 'ready' && meta.demo?.fileName
      ? 'ready'
      : meta.demo?.status === 'pending'
        ? 'pending'
        : meta.demo?.status === 'failed'
          ? 'failed'
          : 'unavailable'
    const demoAuthentic = meta.demo?.renderer === 'template_demo_renderer' && meta.demo?.authentic === true
    let demoMeaningful = false
    let demoAppliedCapabilities = []
    if (demoStatus === 'ready') {
      try {
        const sidecar = JSON.parse(await readFile(join(directory, 'demo.meta.json'), 'utf8'))
        demoMeaningful = sidecar?.meaningfulDifference === true
        demoAppliedCapabilities = Array.isArray(sidecar?.appliedCapabilities)
          ? sidecar.appliedCapabilities.filter(/** @param {unknown} value */ (value) => typeof value === 'string').slice(0, 32)
          : []
      } catch {
        demoMeaningful = false
      }
    }
    const styleAnalysisComplete = meta.styleAnalysis?.analysisComplete === true
    const demoPlayable = demoStatus === 'ready'
    return {
      referencePlayable,
      demoPlayable,
      demoStatus,
      demoRenderer: meta.demo?.renderer || null,
      demoAuthentic,
      demoMeaningful,
      demoAppliedCapabilities,
      styleAnalysisComplete,
      approveReady: referencePlayable && demoPlayable && demoAuthentic && styleAnalysisComplete,
    }
  }

  /**
   * Copy the private reference and reusable assets into a new editable template.
   * The rendered demo is deliberately not copied: it is regenerated against the
   * destination template so its binding fingerprint remains truthful.
   * @param {string} sourceTemplateId
   * @param {string} targetTemplateId
   */
  const cloneAssetsToTemplate = async (sourceTemplateId, targetTemplateId) => {
    const sourceMeta = await readMeta(sourceTemplateId)
    if (!sourceMeta?.reference?.fileName) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_MISSING', 409)
    }
    const sourceDirectory = templateDir(sourceTemplateId)
    const targetDirectory = templateDir(targetTemplateId)
    const referenceName = sourceMeta.reference.fileName
    const sourceReference = join(sourceDirectory, referenceName)
    if (!inside(sourceDirectory, sourceReference) || !existsSync(sourceReference)) {
      throw new TemplateMediaStoreError('TEMPLATE_MEDIA_REFERENCE_MISSING', 409)
    }
    await mkdir(targetDirectory, { recursive: true, mode: 0o700 })
    /** @param {string} fileName */
    const copyPrivateFile = async (fileName) => {
      const source = join(sourceDirectory, fileName)
      const target = join(targetDirectory, fileName)
      if (!inside(sourceDirectory, source) || !inside(targetDirectory, target) || !existsSync(source)) {
        throw new TemplateMediaStoreError('TEMPLATE_MEDIA_FILE_MISSING', 409)
      }
      await copyFile(source, target)
      await chmod(target, 0o600).catch(() => {})
    }
    await copyPrivateFile(referenceName)
    const audioAssets = record(sourceMeta.audioAssets) ? sourceMeta.audioAssets : {}
    for (const entry of Object.values(audioAssets)) {
      if (record(entry) && typeof entry.fileName === 'string') await copyPrivateFile(entry.fileName)
    }
    const copiedMeta = structuredClone(sourceMeta)
    copiedMeta.libraryTemplateId = targetTemplateId
    copiedMeta.demo = {
      status: 'pending', fileName: null, contentType: null, byteSize: null,
      sha256: null, renderer: null, authentic: false,
    }
    copiedMeta.styleAnalysis = { analysisComplete: false, analyzerVersion: null }
    copiedMeta.updatedAt = new Date().toISOString()
    await writeMeta(targetTemplateId, copiedMeta)
    const sourcePackaging = join(sourceDirectory, 'packaging-map.json')
    if (existsSync(sourcePackaging)) await copyPrivateFile('packaging-map.json')
    const recipe = await readReplicationRecipe(sourceTemplateId)
    if (recipe) await writeReplicationRecipe(targetTemplateId, recipe)
    return { copiedReference: true, copiedAudioAssetCount: Object.keys(audioAssets).length }
  }

  /**
   * Remove only a validated, direct child owned by this private media store.
   * @param {string} libraryTemplateId
   */
  const removeTemplateAssets = async (libraryTemplateId) =>
    serializeTemplateMutation(libraryTemplateId, async () => {
      const directory = templateDir(libraryTemplateId)
      if (!inside(root, directory) || dirname(directory) !== resolve(root)) {
        throw new TemplateMediaStoreError('TEMPLATE_MEDIA_ID_INVALID', 400)
      }
      await rm(directory, { recursive: true, force: true })
      return true
    })

  return {
    ingestReference,
    ingestAudio,
    ingestReferenceAudio,
    generateDemo,
    resolveResource,
    resolveAudioPath,
    acquireAudioLease,
    resolvePackagingToken,
    previewAvailability,
    readMeta,
    readPackagingMap,
    readReplicationRecipe,
    readStyleSummary,
    templateDir,
    cloneAssetsToTemplate,
    removeTemplateAssets,
    writePackagingMap,
    writeReplicationRecipe,
  }
}
