import { createHash } from 'node:crypto'

const hex64 = /^[a-f0-9]{64}$/u
const adapterRevisionPattern = /^[a-z0-9][a-z0-9._-]{2,95}$/u
const allowedFamilies = new Set(['flower', 'sticker', 'video_effect'])
/** @type {WeakMap<object, {records: WeakMap<object, Record<string, any>>, inputs: WeakMap<object, Record<string, any>>, revoked: WeakSet<object>, consumed: WeakSet<object>}>} */
const qualificationAuthorities = new WeakMap()

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @returns {unknown} */
const sortJson = (value) => {
  if (Array.isArray(value)) return value.map(sortJson)
  if (!isRecord(value)) return value
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, sortJson(value[key])]))
}
/** @param {unknown} value @returns {string} */
const stable = (value) => JSON.stringify(sortJson(value))
/** @param {unknown} value @returns {string} */
const fingerprint = (value) => createHash('sha256').update(typeof value === 'string' ? value : stable(value)).digest('hex')
/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => { const error = new Error(code); Object.assign(error, { code, status }); throw error }

/** @param {Record<string, any>} receipt */
const receiptUnsigned = (receipt) => ({
  schema_version: receipt.schema_version,
  catalog_fingerprint: receipt.catalog_fingerprint,
  family: receipt.family,
  binding_fingerprint: receipt.binding_fingerprint,
  profile_id: receipt.profile_id,
  app_version: receipt.app_version,
  desktop_binding_fingerprint: receipt.desktop_binding_fingerprint,
  adapter_revision: receipt.adapter_revision,
  entitlement_observation_fingerprint: receipt.entitlement_observation_fingerprint,
  cache_observation_fingerprint: receipt.cache_observation_fingerprint,
  probe_receipt_fingerprint: receipt.probe_receipt_fingerprint,
  projected_binding_fingerprint: receipt.projected_binding_fingerprint,
})

/** @param {unknown} receipt @returns {Record<string, any>} */
const assertReceiptIntegrity = (receipt) => {
  if (!isRecord(receipt) || receipt.schema_version !== 1 || !allowedFamilies.has(receipt.family) ||
      !hex64.test(receipt.catalog_fingerprint ?? '') || !hex64.test(receipt.binding_fingerprint ?? '') ||
      typeof receipt.profile_id !== 'string' || typeof receipt.app_version !== 'string' ||
      !hex64.test(receipt.desktop_binding_fingerprint ?? '') ||
      typeof receipt.adapter_revision !== 'string' || !adapterRevisionPattern.test(receipt.adapter_revision) ||
      !hex64.test(receipt.entitlement_observation_fingerprint ?? '') ||
      !hex64.test(receipt.cache_observation_fingerprint ?? '') ||
      !hex64.test(receipt.probe_receipt_fingerprint ?? '') ||
      !hex64.test(receipt.projected_binding_fingerprint ?? '') ||
      !hex64.test(receipt.qualification_fingerprint ?? '') || !isRecord(receipt.private_projected_binding) ||
      fingerprint(receipt.private_projected_binding) !== receipt.projected_binding_fingerprint ||
      fingerprint(receiptUnsigned(receipt)) !== receipt.qualification_fingerprint) {
    fail('PACKAGING_BINDING_RECEIPT_INVALID')
  }
  return receipt
}

/**
 * Revalidate a request-scoped qualification against the exact current catalog
 * entry before it can enter the ephemeral writer-ready index.
 * @param {{receipt: unknown, catalog: unknown, entry: unknown}} input
 * @returns {Record<string, any>}
 */
export const assertPackagingBindingQualificationReceipt = ({ receipt, catalog, entry }) => {
  const exact = assertReceiptIntegrity(receipt)
  if (!isRecord(catalog) || !isRecord(entry) || !isRecord(entry.private_binding) ||
      exact.catalog_fingerprint !== catalog.catalogFingerprint ||
      exact.profile_id !== catalog.profileId || exact.app_version !== catalog.appVersion ||
      exact.family !== entry.family ||
      exact.binding_fingerprint !== fingerprint({ family: entry.family, private_binding: entry.private_binding })) {
    fail('PACKAGING_BINDING_RECEIPT_INVALID')
  }
  return exact
}

/**
 * Qualify exactly one selected binding. Family qualification is a prerequisite
 * for adapter compatibility only and never admits siblings or mutates a shard.
 * @param {{
 *   catalogFingerprint: string,
 *   entry: Record<string, any>,
 *   desktop: {profileId: string, appVersion: string, bindingFingerprint: string},
 *   adapter: {revision: string, qualifiedFamilies: readonly string[], validateEntity: Function, projectBinding: Function},
 *   inspectEntitlement: Function,
 *   inspectCache: Function,
 *   probe: Function,
 * }} input
 */
export const qualifyPackagingBinding = async ({
  catalogFingerprint,
  entry,
  desktop,
  adapter,
  inspectEntitlement,
  inspectCache,
  probe,
}) => {
  if (!hex64.test(catalogFingerprint ?? '') || !isRecord(entry) || entry.state !== 'discoverable' ||
      entry.writer_eligible === true || !allowedFamilies.has(entry.family) || !isRecord(entry.private_binding) ||
      !isRecord(desktop) || typeof desktop.profileId !== 'string' || typeof desktop.appVersion !== 'string' ||
      !hex64.test(desktop.bindingFingerprint ?? '') || !isRecord(adapter) ||
      typeof adapter.revision !== 'string' || !adapterRevisionPattern.test(adapter.revision) ||
      !Array.isArray(adapter.qualifiedFamilies) || !adapter.qualifiedFamilies.includes(entry.family) ||
      typeof adapter.validateEntity !== 'function' || typeof adapter.projectBinding !== 'function' ||
      typeof inspectEntitlement !== 'function' || typeof inspectCache !== 'function' ||
      typeof probe !== 'function') fail('PACKAGING_BINDING_GATE_INVALID')

  const bindingFingerprint = fingerprint({ family: entry.family, private_binding: entry.private_binding })
  const context = Object.freeze({
    family: entry.family,
    privateBinding: entry.private_binding,
    profileId: desktop.profileId,
    appVersion: desktop.appVersion,
    bindingFingerprint,
  })
  if (await adapter.validateEntity(context) !== true) fail('PACKAGING_BINDING_ENTITY_UNAVAILABLE')
  const entitlement = await inspectEntitlement(context)
  if (!isRecord(entitlement) || entitlement.available !== true || typeof entitlement.observationFingerprint !== 'string' ||
      !hex64.test(entitlement.observationFingerprint)) fail('PACKAGING_BINDING_ENTITLEMENT_UNAVAILABLE')
  const cache = await inspectCache(context)
  if (!isRecord(cache) || cache.available !== true || typeof cache.observationFingerprint !== 'string' ||
      !hex64.test(cache.observationFingerprint)) fail('PACKAGING_BINDING_CACHE_UNAVAILABLE')
  const probeReceipt = await probe(context)
  if (!isRecord(probeReceipt) || probeReceipt.passed !== true || typeof probeReceipt.receiptFingerprint !== 'string' ||
      !hex64.test(probeReceipt.receiptFingerprint)) fail('PACKAGING_BINDING_PROBE_FAILED')
  const projected = await adapter.projectBinding(context)
  if (!isRecord(projected) || Object.keys(projected).length === 0) fail('PACKAGING_BINDING_PROJECTION_INVALID')
  const unsigned = {
    schema_version: 1,
    catalog_fingerprint: catalogFingerprint,
    family: entry.family,
    binding_fingerprint: bindingFingerprint,
    profile_id: desktop.profileId,
    app_version: desktop.appVersion,
    desktop_binding_fingerprint: desktop.bindingFingerprint,
    adapter_revision: adapter.revision,
    entitlement_observation_fingerprint: entitlement.observationFingerprint,
    cache_observation_fingerprint: cache.observationFingerprint,
    probe_receipt_fingerprint: probeReceipt.receiptFingerprint,
    projected_binding_fingerprint: fingerprint(projected),
  }
  return Object.freeze({
    ...unsigned,
    qualification_fingerprint: fingerprint(unsigned),
    private_projected_binding: Object.freeze(structuredClone(projected)),
  })
}

/**
 * Create one process-private qualification authority. Handles are empty frozen
 * objects and cannot be reconstructed from a serialized receipt.
 */
export const createPackagingBindingQualificationAuthority = () => {
  /** @type {WeakMap<object, Record<string, any>>} */
  const records = new WeakMap()
  /** @type {WeakMap<object, Record<string, any>>} */
  const inputs = new WeakMap()
  const revoked = new WeakSet()
  const consumed = new WeakSet()
  const registry = Object.freeze({})
  qualificationAuthorities.set(registry, { records, inputs, revoked, consumed })
  return Object.freeze({
    registry,
    /** @param {Parameters<typeof qualifyPackagingBinding>[0]} input */
    async qualify(input) {
      const receipt = await qualifyPackagingBinding(input)
      const handle = Object.freeze({})
      records.set(handle, receipt)
      inputs.set(handle, input)
      return handle
    },
    /** @param {unknown} handle */
    revoke(handle) {
      if (!handle || typeof handle !== 'object' || !records.has(/** @type {object} */ (handle))) return false
      revoked.add(/** @type {object} */ (handle))
      return true
    },
  })
}

/**
 * Resolve a handle only when it came from this module's process-private
 * authority and still matches the exact current catalog entry.
 * @param {{registry: unknown, handle: unknown, catalog: unknown, entry: unknown}} input
 */
export const resolvePackagingBindingQualification = async ({ registry, handle, catalog, entry }) => {
  if (!registry || typeof registry !== 'object' || !handle || typeof handle !== 'object') return null
  const authority = qualificationAuthorities.get(/** @type {object} */ (registry))
  if (!authority || authority.revoked.has(/** @type {object} */ (handle)) || authority.consumed.has(/** @type {object} */ (handle))) return null
  const receipt = authority.records.get(/** @type {object} */ (handle))
  const originalInput = authority.inputs.get(/** @type {object} */ (handle))
  if (!receipt || !originalInput) return null
  authority.consumed.add(/** @type {object} */ (handle))
  try {
    const currentCatalog = /** @type {{catalogFingerprint: string, profileId: string, appVersion: string}} */ (catalog)
    const original = /** @type {Record<string, any>} */ (originalInput)
    const revalidatedReceipt = await qualifyPackagingBinding(/** @type {any} */ ({
      ...original,
      catalogFingerprint: currentCatalog.catalogFingerprint,
      entry: /** @type {Record<string, any>} */ (entry),
      desktop: {
        ...original.desktop,
        profileId: currentCatalog.profileId,
        appVersion: currentCatalog.appVersion,
      },
    }))
    return assertPackagingBindingQualificationReceipt({ receipt: revalidatedReceipt, catalog, entry })
  } catch { return null }
}

/** Public projection intentionally excludes every binding and evidence identity. */
/** @param {unknown} receipt */
export const projectPackagingBindingQualification = (receipt) => {
  const exact = assertReceiptIntegrity(receipt)
  return Object.freeze({ family: exact.family, status: 'qualified', writer_eligible: false })
}
