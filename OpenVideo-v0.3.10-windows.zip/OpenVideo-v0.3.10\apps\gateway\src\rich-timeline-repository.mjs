import { randomUUID } from 'node:crypto'
import { existsSync, realpathSync } from 'node:fs'
import { chmod, copyFile, mkdir, open, readFile, rename, rm, stat } from 'node:fs/promises'
import { basename, dirname, isAbsolute, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import {
  assertRichTimeline,
  computeCapabilityRequirements,
  contentFingerprint,
  finalizeRichTimeline,
  revisionFingerprint,
  sealRichTimeline,
} from './rich-timeline-contracts.mjs'
import { securePrivateRuntimeRoot } from './local-runtime.mjs'

const schemaVersion = 1
const storeFileName = 'rich-timelines.json'
const defaultRepositoryRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const activeOwnerTokens = new Set()
const transientWindowsDeleteCodes = new Set(['EPERM', 'EBUSY', 'EACCES'])

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} error */
const errorCode = (error) =>
  error && typeof error === 'object' && 'code' in error
    ? /** @type {{code?: unknown}} */ (error).code
    : undefined

/** @param {string} candidate */
const canonicalizePotentialPath = (candidate) => {
  let existingAncestor = resolve(candidate)
  /** @type {string[]} */
  const missingSegments = []
  while (!existsSync(existingAncestor)) {
    const parent = dirname(existingAncestor)
    if (parent === existingAncestor) break
    missingSegments.unshift(basename(existingAncestor))
    existingAncestor = parent
  }
  const canonicalAncestor = existsSync(existingAncestor)
    ? realpathSync.native(existingAncestor)
    : existingAncestor
  return resolve(canonicalAncestor, ...missingSegments)
}

/** @param {string} parent @param {string} candidate */
const isInside = (parent, candidate) => {
  const child = relative(canonicalizePotentialPath(parent), canonicalizePotentialPath(candidate))
  return child === '' || (!child.startsWith('..') && !isAbsolute(child))
}

export class RichTimelineRepositoryError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'RichTimelineRepositoryError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] */
const repositoryError = (code, status) => new RichTimelineRepositoryError(code, status)

/** @param {number} milliseconds */
const delay = (milliseconds) =>
  new Promise((resolveDelay) => setTimeout(resolveDelay, milliseconds))

/**
 * @param {string} source
 * @param {string} destination
 * @param {number} [maximumAttempts]
 */
const renameWithTransientRetries = async (source, destination, maximumAttempts = 20) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    try {
      await rename(source, destination)
      return
    } catch (error) {
      if (
        !transientWindowsDeleteCodes.has(String(errorCode(error))) ||
        attempt + 1 >= maximumAttempts
      ) throw error
      await delay(10)
    }
  }
}

/** @param {string} filePath @param {unknown} document */
const writeAtomic = async (filePath, document) => {
  const temporaryPath = `${filePath}.${randomUUID()}.tmp`
  const backupPath = `${filePath}.bak`
  await mkdir(dirname(filePath), { recursive: true, mode: 0o700 })
  const handle = await open(temporaryPath, 'wx', 0o600)
  try {
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  try {
    await copyFile(filePath, backupPath)
    await chmod(backupPath, 0o600).catch(() => {})
  } catch (error) {
    if (errorCode(error) !== 'ENOENT') {
      await rm(temporaryPath, { force: true })
      throw error
    }
  }
  try {
    await renameWithTransientRetries(temporaryPath, filePath)
    await chmod(filePath, 0o600).catch(() => {})
  } catch (error) {
    await rm(temporaryPath, { force: true })
    throw error
  }
}

/** @param {string} filePath @param {unknown} document */
const repairPrimary = async (filePath, document) => {
  const temporaryPath = `${filePath}.${randomUUID()}.repair`
  const handle = await open(temporaryPath, 'wx', 0o600)
  try {
    await handle.writeFile(`${JSON.stringify(document, null, 2)}\n`, 'utf8')
    await handle.sync()
  } finally {
    await handle.close()
  }
  await renameWithTransientRetries(temporaryPath, filePath)
  await chmod(filePath, 0o600).catch(() => {})
}

/**
 * Reconcile metadata introduced by newer capability inventories without
 * weakening validation of the timeline structure or media references.
 * @param {Record<string, any>} value
 */
const migrateCapabilityRequirements = (value) => {
  const migrated = clone(value)
  migrated.capabilityRequirements = computeCapabilityRequirements(migrated.tracks)
  migrated.contentFingerprint = contentFingerprint(migrated)
  const { revisionFingerprint: _ignored, ...withoutRevisionFingerprint } = migrated
  migrated.revisionFingerprint = revisionFingerprint(withoutRevisionFingerprint)
  return migrated
}

/** @param {unknown} value @returns {Record<string, any>} */
const normalizeRevision = (value) => {
  try {
    return assertRichTimeline(value)
  } catch (error) {
    if (!(error instanceof Error) || error.message !== 'capability_requirements_mismatch') throw error
    const migrated = migrateCapabilityRequirements(/** @type {Record<string, any>} */ (value))
    return assertRichTimeline(migrated)
  }
}

/** @param {unknown} value */
const validPointer = (value) =>
  isRecord(value) &&
  typeof value.projectId === 'string' &&
  typeof value.timelineId === 'string' &&
  Number.isSafeInteger(value.revision) &&
  value.revision > 0

/** @param {unknown} value */
const validDocument = (value) => {
  if (
    !isRecord(value) ||
    value.schema_version !== schemaVersion ||
    !Array.isArray(value.revisions) ||
    !Array.isArray(value.current)
  ) {
    return false
  }
  try {
    const identities = new Set()
    for (const revision of value.revisions) {
      normalizeRevision(revision)
      const identity = `${revision.projectId}\u0000${revision.timelineId}\u0000${revision.revision}`
      if (identities.has(identity)) return false
      identities.add(identity)
    }
    const projects = new Set()
    for (const pointer of value.current) {
      if (!validPointer(pointer) || projects.has(pointer.projectId)) return false
      projects.add(pointer.projectId)
      const exists = value.revisions.some((revision) =>
        revision.projectId === pointer.projectId &&
        revision.timelineId === pointer.timelineId &&
        revision.revision === pointer.revision)
      if (!exists) return false
    }
    return true
  } catch {
    return false
  }
}

/**
 * @param {string} filePath
 * @param {boolean} [allowCreate]
 * @param {{bytes: Buffer | null, document: any}} [validatedPrimary]
 */
const readDocument = async (filePath, allowCreate = false, validatedPrimary) => {
  try {
    // Always read the primary. Only exact bytes already fully validated by
    // this repository may reuse a parsed object; timestamps are not evidence.
    const bytes = await readFile(filePath)
    if (validatedPrimary?.bytes?.equals(bytes)) return validatedPrimary.document
    if (validatedPrimary) {
      validatedPrimary.bytes = null
      validatedPrimary.document = null
    }
    const primary = JSON.parse(bytes.toString('utf8'))
    if (!validDocument(primary)) throw new Error('invalid_primary')
    let migrated = false
    const revisions = primary.revisions.map((/** @type {unknown} */ revision) => {
      try { return assertRichTimeline(revision) } catch (error) {
        if (!(error instanceof Error) || error.message !== 'capability_requirements_mismatch') throw error
        migrated = true
        return normalizeRevision(revision)
      }
    })
    if (!migrated) {
      if (validatedPrimary) {
        validatedPrimary.bytes = bytes
        validatedPrimary.document = primary
      }
      return primary
    }
    const next = { ...primary, revisions }
    await repairPrimary(filePath, next)
    return next
  } catch (primaryError) {
    if (validatedPrimary) {
      validatedPrimary.bytes = null
      validatedPrimary.document = null
    }
    try {
      const backup = JSON.parse(await readFile(`${filePath}.bak`, 'utf8'))
      if (!validDocument(backup)) throw new Error('invalid_backup')
      await repairPrimary(filePath, backup)
      return backup
    } catch (backupError) {
      if (allowCreate && errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') {
        return { schema_version: schemaVersion, revisions: [], current: [] }
      }
      throw repositoryError('RICH_TIMELINE_STORAGE_CORRUPT')
    }
  }
}

/**
 * Removes only the lock content observed by the caller. A changed owner is never removed.
 * @param {string} lockPath
 * @param {string} expectedOwner
 * @param {number} [maximumAttempts]
 */
const removeOwnedLock = async (lockPath, expectedOwner, maximumAttempts = 20) => {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    const currentOwner = await readFile(lockPath, 'utf8').catch((error) => {
      if (errorCode(error) === 'ENOENT') return null
      throw error
    })
    if (currentOwner === null || currentOwner !== expectedOwner) return true
    try {
      await rm(lockPath)
      return true
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return true
      if (!transientWindowsDeleteCodes.has(String(errorCode(error)))) throw error
      if (attempt + 1 < maximumAttempts) await delay(10)
    }
  }
  return false
}

/** @param {string} lockPath */
const acquireLock = async (lockPath) => {
  const token = randomUUID()
  const owner = `${JSON.stringify({ token, pid: process.pid })}\n`
  for (let attempt = 0; attempt < 500; attempt += 1) {
    /** @type {import('node:fs/promises').FileHandle | null} */
    let handle = null
    try {
      handle = await open(lockPath, 'wx', 0o600)
      activeOwnerTokens.add(token)
      await handle.writeFile(owner, 'utf8')
      await handle.sync()
      return { handle, owner, token }
    } catch (error) {
      if (handle) {
        await handle.close().catch(() => {})
        const failedOwner = await readFile(lockPath, 'utf8').catch(() => null)
        if (failedOwner !== null) {
          await removeOwnedLock(lockPath, failedOwner).catch(() => false)
        }
        activeOwnerTokens.delete(token)
      }
      if (
        process.platform === 'win32' &&
        transientWindowsDeleteCodes.has(String(errorCode(error)))
      ) {
        await delay(10)
        continue
      }
      if (errorCode(error) !== 'EEXIST') throw error
      const existingOwner = await readFile(lockPath, 'utf8').catch(() => null)
      const metadata = await stat(lockPath).catch(() => null)
      let processAlive = true
      /** @type {number | null} */
      let parsedPid = null
      /** @type {string | null} */
      let parsedToken = null
      let validOwner = false
      try {
        const parsed = JSON.parse(existingOwner ?? '')
        if (
          !Number.isSafeInteger(parsed?.pid) ||
          parsed.pid < 1 ||
          typeof parsed.token !== 'string' ||
          parsed.token.length === 0
        ) throw new Error('invalid_lock')
        const pid = Number(parsed.pid)
        parsedPid = pid
        parsedToken = parsed.token
        validOwner = true
        process.kill(pid, 0)
      } catch (processError) {
        processAlive = errorCode(processError) !== 'ESRCH'
      }
      const orphanedCurrentProcessOwner =
        parsedPid === process.pid &&
        parsedToken !== null &&
        !activeOwnerTokens.has(parsedToken)
      if (
        existingOwner !== null &&
        metadata &&
        (
          orphanedCurrentProcessOwner ||
          (
            Date.now() - metadata.mtimeMs > 5 * 60_000 &&
            (!validOwner || !processAlive)
          )
        ) &&
        await readFile(lockPath, 'utf8').catch(() => null) === existingOwner
      ) {
        if (await removeOwnedLock(lockPath, existingOwner)) continue
      }
      await delay(10)
    }
  }
  throw repositoryError('RICH_TIMELINE_STORAGE_LOCKED', 503)
}

/** @param {string} lockPath @param {{handle: import('node:fs/promises').FileHandle, owner: string, token: string}} lock */
const releaseLock = async (lockPath, lock) => {
  try {
    await lock.handle.close().catch(() => {})
    await removeOwnedLock(lockPath, lock.owner)
  } finally {
    activeOwnerTokens.delete(lock.token)
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   repositoryRoot?: string,
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 * }} options
 */
const createLockedStore = async ({
  dataRoot,
  repositoryRoot = defaultRepositoryRoot,
  securePrivateRoot = securePrivateRuntimeRoot,
}) => {
  if (!isAbsolute(dataRoot)) throw repositoryError('RICH_TIMELINE_DATA_ROOT_REQUIRED')
  if (isInside(repositoryRoot, dataRoot)) throw repositoryError('RICH_TIMELINE_DATA_ROOT_UNSAFE')
  await mkdir(dataRoot, { recursive: true, mode: 0o700 })
  await securePrivateRoot(dataRoot)
  const filePath = resolve(dataRoot, storeFileName)
  const lockPath = `${filePath}.lock`
  /** @type {Promise<unknown>} */
  let writeQueue = Promise.resolve()

  /** @template T @param {(document: {schema_version: number, revisions: any[], current: any[]}) => Promise<{document: any, result: T}>} operation */
  const mutate = (operation) => {
    const run = async () => {
      const lock = await acquireLock(lockPath)
      try {
        const document = await readDocument(filePath, true)
        const output = await operation(clone(document))
        if (!validDocument(output.document)) throw repositoryError('RICH_TIMELINE_DOCUMENT_INVALID')
        await writeAtomic(filePath, output.document)
        // Reads started after this write must not join an older in-flight read.
        readInFlight = null
        return clone(output.result)
      } finally {
        await releaseLock(lockPath, lock)
      }
    }
    const result = writeQueue.then(run, run)
    writeQueue = result.then(() => undefined, () => undefined)
    return result
  }

  /** @type {{bytes: Buffer | null, document: any}} */
  const validatedPrimary = { bytes: null, document: null }
  /** @type {Promise<any> | null} */
  let readInFlight = null
  // Readers never modify this internal snapshot. Public queries clone only
  // their selected result; mutate independently reads and clones its document.
  const read = () => {
    if (!readInFlight) {
      const pending = readDocument(filePath, true, validatedPrimary)
        .finally(() => {
          if (readInFlight === pending) readInFlight = null
        })
      readInFlight = pending
    }
    return readInFlight
  }

  const initialize = await acquireLock(lockPath)
  try {
    const document = await readDocument(filePath, true)
    const persisted = await readFile(filePath, 'utf8').catch(() => null)
    if (
      persisted === null ||
      JSON.stringify(JSON.parse(persisted)) !== JSON.stringify(document)
    ) {
      await writeAtomic(filePath, document)
    }
  } finally {
    await releaseLock(lockPath, initialize)
  }
  return { mutate, read }
}

/**
 * @param {{schema_version: number, revisions: any[], current: any[]}} document
 * @param {string} projectId
 * @param {{timelineId: string, revision: number} | null | undefined} expectedCurrent
 * @param {boolean} enforceCas
 */
const assertCurrentCas = (document, projectId, expectedCurrent, enforceCas) => {
  if (!enforceCas) return
  const current = document.current.find(
    (/** @type {Record<string, any>} */ pointer) => pointer.projectId === projectId,
  ) ?? null
  const expected = expectedCurrent ?? null
  if (expected === null) {
    if (current !== null) throw repositoryError('RICH_TIMELINE_CAS_CONFLICT', 409)
    return
  }
  if (
    current === null ||
    current.timelineId !== expected.timelineId ||
    current.revision !== expected.revision
  ) {
    throw repositoryError('RICH_TIMELINE_CAS_CONFLICT', 409)
  }
}

/**
 * @param {{schema_version: number, revisions: any[], current: any[]}} document
 * @param {{projectId: string, timelineId: string, revision: number}} pointer
 */
const writeCurrentPointer = (document, pointer) => {
  const index = document.current.findIndex(
    (/** @type {Record<string, any>} */ entry) => entry.projectId === pointer.projectId,
  )
  if (index >= 0) document.current[index] = pointer
  else document.current.push(pointer)
}

/**
 * @param {{
 *   dataRoot: string,
 *   repositoryRoot?: string,
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 * }} options
 */
export const createRichTimelineRepository = async (options) => {
  const store = await createLockedStore(options)

  return {
    /** @param {Record<string, any>} timeline */
    async saveRevision(timeline) {
      const sealed = sealRichTimeline(timeline)
      return store.mutate(async (document) => {
        const exists = document.revisions.some(
          (/** @type {Record<string, any>} */ revision) =>
            revision.projectId === sealed.projectId &&
            revision.timelineId === sealed.timelineId &&
            revision.revision === sealed.revision,
        )
        if (exists) throw repositoryError('RICH_TIMELINE_REVISION_EXISTS', 409)
        document.revisions.push(sealed)
        return { document, result: sealed }
      })
    },

    /**
     * Atomically insert a draft revision and update the project current pointer.
     * @param {{
     *   timeline: Record<string, any>,
     *   expectedCurrent: {timelineId: string, revision: number} | null,
     * }} input
     */
    async saveDraftAndSetCurrent(input) {
      if (!isRecord(input) || !Object.hasOwn(input, 'expectedCurrent')) {
        throw repositoryError('RICH_TIMELINE_CAS_REQUIRED', 400)
      }
      const sealed = sealRichTimeline(input.timeline)
      if (sealed.status !== 'draft') {
        throw repositoryError('RICH_TIMELINE_SAVE_REQUIRES_DRAFT', 409)
      }
      return store.mutate(async (document) => {
        assertCurrentCas(document, sealed.projectId, input.expectedCurrent, true)
        const exists = document.revisions.some(
          (/** @type {Record<string, any>} */ revision) =>
            revision.projectId === sealed.projectId &&
            revision.timelineId === sealed.timelineId &&
            revision.revision === sealed.revision,
        )
        if (exists) throw repositoryError('RICH_TIMELINE_REVISION_EXISTS', 409)
        document.revisions.push(sealed)
        writeCurrentPointer(document, {
          projectId: sealed.projectId,
          timelineId: sealed.timelineId,
          revision: sealed.revision,
        })
        return { document, result: sealed }
      })
    },

    /** @param {{projectId: string, timelineId: string, revision: number}} query */
    async getRevision(query) {
      const document = await store.read()
      const record = document.revisions.find(
        (/** @type {Record<string, any>} */ revision) =>
          revision.projectId === query.projectId &&
          revision.timelineId === query.timelineId &&
          revision.revision === query.revision,
      )
      return record ? clone(record) : null
    },

    /** @param {{projectId: string, timelineId: string, revision: number, revisionFingerprint: string}} query */
    async getRevisionByFingerprint(query) {
      const record = await this.getRevision(query)
      if (!record) return null
      if (record.revisionFingerprint !== query.revisionFingerprint) {
        throw repositoryError('RICH_TIMELINE_FINGERPRINT_MISMATCH', 409)
      }
      return record
    },

    /** @param {{projectId: string, timelineId: string}} query */
    async listRevisions(query) {
      const document = await store.read()
      return clone(
        document.revisions
          .filter(
            (/** @type {Record<string, any>} */ revision) =>
              revision.projectId === query.projectId &&
              revision.timelineId === query.timelineId,
          )
          .sort(
            (
              /** @type {Record<string, any>} */ left,
              /** @type {Record<string, any>} */ right,
            ) => left.revision - right.revision,
          ),
      )
    },

    /**
     * @param {{
     *   projectId: string,
     *   timelineId: string,
     *   revision: number,
     *   expectedCurrent?: {timelineId: string, revision: number} | null,
     * }} input
     */
    async setCurrent(input) {
      if (!isRecord(input) || !Object.hasOwn(input, 'expectedCurrent')) {
        throw repositoryError('RICH_TIMELINE_CAS_REQUIRED', 400)
      }
      return store.mutate(async (document) => {
        const target = document.revisions.find((revision) =>
          revision.projectId === input.projectId &&
          revision.timelineId === input.timelineId &&
          revision.revision === input.revision)
        if (!target) throw repositoryError('RICH_TIMELINE_REVISION_NOT_FOUND', 404)
        assertCurrentCas(document, input.projectId, input.expectedCurrent, true)
        const pointer = {
          projectId: input.projectId,
          timelineId: input.timelineId,
          revision: input.revision,
        }
        writeCurrentPointer(document, pointer)
        return { document, result: clone(pointer) }
      })
    },

    /** @param {{projectId: string}} query */
    async getCurrent(query) {
      const document = await store.read()
      const pointer = document.current.find(
        (/** @type {Record<string, any>} */ entry) => entry.projectId === query.projectId,
      )
      return pointer ? clone(pointer) : null
    },

    /**
     * Invalidates only the mutable project pointer. Immutable revisions remain
     * available for frozen jobs and audit recovery.
     * @param {{
     *   projectId: string,
     *   expectedCurrent: {timelineId: string, revision: number} | null,
     * }} input
     */
    async clearCurrent(input) {
      if (!isRecord(input) || !Object.hasOwn(input, 'expectedCurrent')) {
        throw repositoryError('RICH_TIMELINE_CAS_REQUIRED', 400)
      }
      return store.mutate(async (document) => {
        assertCurrentCas(document, input.projectId, input.expectedCurrent, true)
        document.current = document.current.filter(
          (/** @type {Record<string, any>} */ pointer) =>
            pointer.projectId !== input.projectId,
        )
        return { document, result: null }
      })
    },

    /** @param {{projectId: string}} query */
    async removeByProject(query) {
      if (!isRecord(query) || typeof query.projectId !== 'string' || query.projectId.length === 0) {
        throw repositoryError('RICH_TIMELINE_PROJECT_INVALID', 400)
      }
      return store.mutate(async (document) => {
        const retainedRevisions = document.revisions.filter(
          (/** @type {Record<string, any>} */ revision) => revision.projectId !== query.projectId,
        )
        const removed = document.revisions.length - retainedRevisions.length
        document.revisions = retainedRevisions
        document.current = document.current.filter(
          (/** @type {Record<string, any>} */ pointer) => pointer.projectId !== query.projectId,
        )
        return { document, result: removed }
      })
    },

    /**
     * @param {{
     *   projectId: string,
     *   timelineId: string,
     *   revision: number,
     *   revisionFingerprint: string,
     *   instructionFingerprint?: string,
     *   expectedCurrent: {timelineId: string, revision: number} | null,
     * }} input
     */
    async finalize(input) {
      if (!isRecord(input) || !Object.hasOwn(input, 'expectedCurrent')) {
        throw repositoryError('RICH_TIMELINE_CAS_REQUIRED', 400)
      }
      return store.mutate(async (document) => {
        assertCurrentCas(document, input.projectId, input.expectedCurrent, true)
        const draft = document.revisions.find((revision) =>
          revision.projectId === input.projectId &&
          revision.timelineId === input.timelineId &&
          revision.revision === input.revision)
        if (!draft) throw repositoryError('RICH_TIMELINE_REVISION_NOT_FOUND', 404)
        if (draft.revisionFingerprint !== input.revisionFingerprint) {
          throw repositoryError('RICH_TIMELINE_FINGERPRINT_MISMATCH', 409)
        }
        if (draft.status !== 'draft') {
          throw repositoryError('RICH_TIMELINE_FINALIZE_REQUIRES_DRAFT', 409)
        }
        const finalized = typeof input.instructionFingerprint === 'string'
          ? finalizeRichTimeline(draft, {
              instructionFingerprint: input.instructionFingerprint,
            })
          : finalizeRichTimeline(draft)
        const exists = document.revisions.some((revision) =>
          revision.projectId === finalized.projectId &&
          revision.timelineId === finalized.timelineId &&
          revision.revision === finalized.revision)
        if (exists) throw repositoryError('RICH_TIMELINE_REVISION_EXISTS', 409)
        document.revisions.push(finalized)
        writeCurrentPointer(document, {
          projectId: input.projectId,
          timelineId: finalized.timelineId,
          revision: finalized.revision,
        })
        return { document, result: finalized }
      })
    },
  }
}
