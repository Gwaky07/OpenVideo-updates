# Write-REL007TemplateDemoEvidence.ps1
# 在 authentic demo 文件哈希与预览门禁均通过后写入私有证据。
# 必须配合 -PlaybackConfirmed；禁止在未验证时写入。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$RuntimeDataRoot = "$env:LOCALAPPDATA\OpenVideo\data",

    [Parameter(Mandatory = $true)]
    [string]$LibraryTemplateId,

    [Parameter(Mandatory = $false)]
    [string]$ManualEvidencePath = "$env:LOCALAPPDATA\OpenVideo\data\evidence\rel-007\template-demo-playback.json",

    [Parameter(Mandatory = $true)]
    [switch]$PlaybackConfirmed
)

$ErrorActionPreference = 'Stop'
if (-not $PlaybackConfirmed.IsPresent) {
    throw 'Refusing to write template demo evidence without -PlaybackConfirmed.'
}

function Assert-NoReparseBoundary {
    param(
        [Parameter(Mandatory = $true)][string]$CandidatePath,
        [Parameter(Mandatory = $true)][string]$BoundaryPath
    )
    $candidate = [IO.Path]::GetFullPath($CandidatePath)
    $boundary = [IO.Path]::GetFullPath($BoundaryPath).TrimEnd('\')
    if (
        $candidate -ne $boundary `
        -and -not $candidate.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)
    ) {
        throw 'REL-007 template evidence escaped its private boundary.'
    }
    $currentPath = $candidate
    while ($true) {
        $current = Get-Item -LiteralPath $currentPath -Force
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'REL-007 template evidence cannot traverse a reparse point.'
        }
        if ([IO.Path]::GetFullPath($currentPath).TrimEnd('\') -eq $boundary) { break }
        $currentPath = [IO.Path]::GetDirectoryName($currentPath.TrimEnd('\'))
        if ([string]::IsNullOrWhiteSpace($currentPath)) {
            throw 'REL-007 template evidence boundary could not be verified.'
        }
    }
}

$runtimeRoot = [IO.Path]::GetFullPath($RuntimeDataRoot).TrimEnd('\') + '\'
$manualPath = [IO.Path]::GetFullPath($ManualEvidencePath)
$evidenceRoot = [IO.Path]::GetFullPath((Join-Path $runtimeRoot 'evidence\rel-007'))
Assert-NoReparseBoundary -CandidatePath $evidenceRoot -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $manualPath -BoundaryPath $runtimeRoot
if (-not $manualPath.StartsWith($evidenceRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'REL-007 template evidence must live under evidence/rel-007.'
}

$mediaPath = Join-Path $runtimeRoot "template-library-media\$LibraryTemplateId\media.json"
$templatesPath = Join-Path $runtimeRoot 'reusable-templates.json'
Assert-NoReparseBoundary -CandidatePath $mediaPath -BoundaryPath $runtimeRoot
Assert-NoReparseBoundary -CandidatePath $templatesPath -BoundaryPath $runtimeRoot

$media = Get-Content -LiteralPath $mediaPath -Raw -Encoding UTF8 | ConvertFrom-Json
$store = Get-Content -LiteralPath $templatesPath -Raw -Encoding UTF8 | ConvertFrom-Json
$record = @($store.records) |
    Where-Object { $_.libraryTemplateId -eq $LibraryTemplateId } |
    Sort-Object revision -Descending |
    Select-Object -First 1
if ($null -eq $record) { throw "Template record not found: $LibraryTemplateId" }

$demoFileName = [string]$media.demo.fileName
if ([string]::IsNullOrWhiteSpace($demoFileName)) { throw 'Template demo fileName missing.' }
$demoPath = Join-Path $runtimeRoot "template-library-media\$LibraryTemplateId\$demoFileName"
Assert-NoReparseBoundary -CandidatePath $demoPath -BoundaryPath $runtimeRoot
if (-not (Test-Path -LiteralPath $demoPath)) { throw 'Template demo media file missing.' }

$fileHash = (Get-FileHash -LiteralPath $demoPath -Algorithm SHA256).Hash.ToLowerInvariant()
$sidecarHash = ([string]$media.demo.sha256).ToLowerInvariant()
if ($fileHash -ne $sidecarHash) {
    throw 'Template demo.mp4 SHA256 does not match media.json sidecar.'
}

$styleComplete = ($media.styleAnalysis.analysisComplete -eq $true)
$approveReady = (
    $media.demo.status -eq 'ready' `
    -and $media.demo.renderer -eq 'template_demo_renderer' `
    -and $media.demo.authentic -eq $true `
    -and $styleComplete
)
if (-not $approveReady) {
    throw 'Template previewAvailability is not approve-ready; refuse to write evidence.'
}

$manual = [ordered]@{
    schema_version = 1
    kind = 'rel007_template_authentic_demo_playback_evidence'
    library_template_id = [string]$LibraryTemplateId
    template_revision = [int]$record.revision
    template_fingerprint = [string]$record.fingerprint
    demo_sha256 = $fileHash
    demo_duration_seconds = [double]$media.demo.durationSeconds
    demo_renderer = 'template_demo_renderer'
    demo_authentic = $true
    approve_ready = $true
    style_analysis_complete = $true
    binding_fingerprint = [string]$media.demo.bindingFingerprint
    playback_confirmed = $true
    confirmed_at = (Get-Date).ToUniversalTime().ToString('o')
}

New-Item -ItemType Directory -Force -Path $evidenceRoot | Out-Null
$json = ($manual | ConvertTo-Json -Depth 5)
[IO.File]::WriteAllText($manualPath, $json + "`n", [Text.UTF8Encoding]::new($false))
Write-Host 'Wrote REL-007 template demo evidence under evidence/rel-007 (private runtime path omitted).'
