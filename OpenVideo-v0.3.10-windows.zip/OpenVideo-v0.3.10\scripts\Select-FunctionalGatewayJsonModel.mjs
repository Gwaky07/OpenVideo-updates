import { copyFile, readFile, rename, writeFile } from 'node:fs/promises'
import { isAbsolute, resolve } from 'node:path'

import { createRankingSchema, createSegmentationSchema } from '../apps/gateway/src/director-contracts.mjs'

const dataRoot = process.argv[2]
if (!dataRoot || !isAbsolute(dataRoot)) throw new Error('GATEWAY_RUNTIME_ROOT_INVALID')

const providerPath = resolve(dataRoot, 'gateway/provider.json')
const provider = JSON.parse(await readFile(providerPath, 'utf8'))
if (
  provider?.schema_version !== 1 ||
  provider?.provider !== 'openai-compatible' ||
  typeof provider.base_url !== 'string' ||
  typeof provider.api_key !== 'string' ||
  typeof provider.text_model !== 'string' ||
  typeof provider.vision_model !== 'string' ||
  typeof provider.json_model !== 'string'
) throw new Error('GATEWAY_PROVIDER_CONFIG_INVALID')

const headers = {
  authorization: `Bearer ${provider.api_key}`,
  'content-type': 'application/json',
}
const baseUrl = provider.base_url.replace(/\/$/u, '')
const modelsResponse = await fetch(`${baseUrl}/models`, {
  headers: { authorization: headers.authorization },
  signal: AbortSignal.timeout(30_000),
})
if (!modelsResponse.ok) throw new Error('GATEWAY_MODEL_CATALOG_UNAVAILABLE')
const catalog = await modelsResponse.json()
const catalogModels = Array.isArray(catalog?.data)
  ? catalog.data
    .map((entry) => entry?.id)
    .filter((id) => typeof id === 'string' && id.length > 0 && id.length <= 300)
  : []
const candidates = [
  provider.text_model,
  provider.vision_model,
  provider.json_model,
  ...catalogModels,
].filter((model, index, values) => values.indexOf(model) === index).slice(0, 20)

const segmentationSchema = createSegmentationSchema()
const rankingSchema = createRankingSchema()
const script = '展示产品外观和材质细节。人物在室内使用产品。最后给出完整产品展示。'

const extractOutput = (message) => {
  const primary = typeof message?.content === 'string' && message.content.trim() ? message.content : null
  const reasoning = typeof message?.reasoning_content === 'string' && message.reasoning_content.trim()
    ? message.reasoning_content
    : null
  return primary ?? reasoning
}

const probe = async (model, body, formats) => {
  for (const format of formats) {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model,
        ...body,
        response_format: format === 'json_schema'
          ? body.response_format
          : { type: 'json_object' },
      }),
      signal: AbortSignal.timeout(60_000),
    })
    if (response.status === 429) throw new Error('GATEWAY_MODEL_SELECTION_RATE_LIMITED')
    if (!response.ok) continue
    const payload = await response.json()
    const output = extractOutput(payload?.choices?.[0]?.message)
    if (!output) continue
    try {
      return JSON.parse(output)
    } catch {
      continue
    }
  }
  return null
}

const validatesSegmentation = (value) =>
  value &&
  typeof value === 'object' &&
  Array.isArray(value.sentences) &&
  value.sentences.length >= 1 &&
  value.sentences.every((entry) => entry && typeof entry.text === 'string' && entry.text.trim().length > 0) &&
  value.sentences.map((entry) => entry.text).join('') === script

const validatesRanking = (value) =>
  value &&
  typeof value === 'object' &&
  Array.isArray(value.rankings) &&
  value.rankings.length === 1 &&
  typeof value.rankings[0]?.sentence_id === 'string' &&
  Array.isArray(value.rankings[0]?.candidates)

let selected = null
let tested = 0
for (const model of candidates) {
  tested += 1
  try {
    const segmentation = await probe(
      model,
      {
        messages: [
          { role: 'system', content: 'Segment the supplied script without adding, deleting, or rewriting any content. Return only JSON matching {"sentences":[{"text":"..."}]}.' },
          { role: 'user', content: script },
        ],
        response_format: {
          type: 'json_schema',
          json_schema: { name: segmentationSchema.name, strict: true, schema: segmentationSchema.schema },
        },
      },
      ['json_schema', 'json_object'],
    )
    if (!validatesSegmentation(segmentation)) continue

    const ranking = await probe(
      model,
      {
        messages: [
          { role: 'system', content: 'Rank up to three visual candidates for each sentence. Return every sentence exactly once and only use allowed candidate IDs. Return JSON matching {"rankings":[{"sentence_id":"...","candidates":[{"candidate_id":"...","score":0,"reason":"..."}]}]}.' },
          {
            role: 'user',
            content: JSON.stringify({
              sentences: [{
                sentence_id: 'sentence-001',
                text: '展示产品外观和材质细节。',
                allowed_candidates: [{ candidate_id: 'cand-1', summary: 'product closeup', tags: ['product'], search_score: 0.9 }],
              }],
            }),
          },
        ],
        response_format: {
          type: 'json_schema',
          json_schema: { name: rankingSchema.name, strict: true, schema: rankingSchema.schema },
        },
      },
      ['json_schema', 'json_object'],
    )
    if (!validatesRanking(ranking)) continue

    selected = model
    break
  } catch (error) {
    if (error instanceof Error && error.message === 'GATEWAY_MODEL_SELECTION_RATE_LIMITED') throw error
  }
}

if (!selected) throw new Error('GATEWAY_FUNCTIONAL_JSON_MODEL_NOT_FOUND')

const updated = { ...provider, json_model: selected }
const temporaryPath = `${providerPath}.tmp`
await copyFile(providerPath, `${providerPath}.bak`)
await writeFile(temporaryPath, `${JSON.stringify(updated, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 })
await rename(temporaryPath, providerPath)

console.log(JSON.stringify({
  tested_model_count: tested,
  json_model_selected: true,
  configuration_updated: selected !== provider.json_model,
}))
