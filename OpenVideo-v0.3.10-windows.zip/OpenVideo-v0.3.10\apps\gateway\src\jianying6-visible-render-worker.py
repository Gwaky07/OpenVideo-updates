"""Fail-closed visible UI automation for the pinned Jianying 6.x spike."""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
from ctypes import wintypes
from pathlib import Path
from typing import Iterable

import uiautomation as automation


class WorkerError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TH32CS_SNAPPROCESS = 0x00000002
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9
FILE_ATTRIBUTE_REPARSE_POINT = 0x400


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260),
    ]


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong),
        ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong),
        ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong),
        ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_longlong),
        ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
kernel32.Process32FirstW.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(PROCESSENTRY32W),
]
kernel32.Process32FirstW.restype = wintypes.BOOL
kernel32.Process32NextW.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(PROCESSENTRY32W),
]
kernel32.Process32NextW.restype = wintypes.BOOL
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.QueryFullProcessImageNameW.argtypes = [
    wintypes.HANDLE,
    wintypes.DWORD,
    wintypes.LPWSTR,
    ctypes.POINTER(wintypes.DWORD),
]
kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
kernel32.CreateJobObjectW.restype = wintypes.HANDLE
kernel32.SetInformationJobObject.argtypes = [
    wintypes.HANDLE,
    ctypes.c_int,
    ctypes.c_void_p,
    wintypes.DWORD,
]
kernel32.SetInformationJobObject.restype = wintypes.BOOL
kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL
user32.GetForegroundWindow.restype = wintypes.HWND


def _process_snapshot() -> list[tuple[int, int, str]]:
    snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snapshot == INVALID_HANDLE_VALUE:
        raise WorkerError("JY007_PROCESS_INSPECTION_FAILED")
    entries: list[tuple[int, int, str]] = []
    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        more = kernel32.Process32FirstW(snapshot, ctypes.byref(entry))
        while more:
            pid = int(entry.th32ProcessID)
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            path = ""
            if handle:
                try:
                    capacity = wintypes.DWORD(32768)
                    buffer = ctypes.create_unicode_buffer(capacity.value)
                    if kernel32.QueryFullProcessImageNameW(
                        handle, 0, buffer, ctypes.byref(capacity)
                    ):
                        path = buffer.value
                finally:
                    kernel32.CloseHandle(handle)
            entries.append((pid, int(entry.th32ParentProcessID), path))
            more = kernel32.Process32NextW(snapshot, ctypes.byref(entry))
    finally:
        kernel32.CloseHandle(snapshot)
    return entries


def _descendant_pids(root_pid: int) -> set[int]:
    result = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, parent, _ in _process_snapshot():
            if parent in result and pid not in result:
                result.add(pid)
                changed = True
    return result


def _assert_no_conflicting_instance(executable: Path) -> None:
    expected = os.path.normcase(str(executable.resolve()))
    for _, _, path in _process_snapshot():
        if Path(path).name.lower() != "jianyingpro.exe":
            continue
        if os.path.normcase(os.path.abspath(path)) == expected:
            raise WorkerError("JY007_RENDERER_ALREADY_RUNNING")
        raise WorkerError("JY007_CONFLICTING_JIANYING_INSTANCE")


def _create_kill_on_close_job(process: subprocess.Popen[bytes]) -> int:
    job = kernel32.CreateJobObjectW(None, None)
    if not job:
        process.terminate()
        raise WorkerError("JY007_PROCESS_OWNERSHIP_FAILED")
    limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not kernel32.SetInformationJobObject(
        job,
        JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
        ctypes.byref(limits),
        ctypes.sizeof(limits),
    ) or not kernel32.AssignProcessToJobObject(job, wintypes.HANDLE(process._handle)):
        kernel32.CloseHandle(job)
        process.terminate()
        raise WorkerError("JY007_PROCESS_OWNERSHIP_FAILED")
    return int(job)


def _controls_for(pids: set[int], max_depth: int = 6) -> list[automation.Control]:
    values: list[automation.Control] = []
    roots: list[automation.Control] = []
    for control in automation.GetRootControl().GetChildren():
        try:
            if control.ProcessId in pids:
                roots.append(control)
        except Exception:
            continue
    for root in roots:
        for control, _ in automation.WalkControl(
            root, includeTop=True, maxDepth=max_depth
        ):
            try:
                if control.ProcessId in pids and not control.IsOffscreen:
                    values.append(control)
            except Exception:
                continue
    return values


def _wait_controls(
    pids: set[int], predicate, deadline: float
) -> list[automation.Control]:
    while time.monotonic() < deadline:
        matches = [control for control in _controls_for(pids) if predicate(control)]
        if matches:
            return matches
        time.sleep(0.5)
    return []


def _unique(controls: Iterable[automation.Control], code: str) -> automation.Control:
    values = list(controls)
    if len(values) != 1:
        raise WorkerError(code)
    return values[0]


def _click_draft(pids: set[int], draft_name: str, deadline: float) -> None:
    matches = _wait_controls(
        pids,
        lambda control: control.Name.strip() == draft_name,
        deadline,
    )
    target = _unique(matches, "JY007_DRAFT_CONTROL_UNAVAILABLE")
    for _ in range(6):
        if target.ControlTypeName in {
            "ListItemControl",
            "ButtonControl",
            "PaneControl",
            "GroupControl",
        }:
            target.Click()
            return
        target = target.GetParentControl()
    raise WorkerError("JY007_DRAFT_CONTROL_UNAVAILABLE")


def _click_unique_button(
    pids: set[int], names: set[str], deadline: float, missing_code: str
) -> None:
    matches = _wait_controls(
        pids,
        lambda control: (
            control.ControlTypeName == "ButtonControl"
            and control.Name.strip() in names
            and control.IsEnabled
        ),
        deadline,
    )
    _unique(matches, missing_code).Click()


def _configure_export(pids: set[int], output: Path, deadline: float) -> None:
    modal_markers = _wait_controls(
        pids,
        lambda control: control.Name.strip() in {"导出设置", "导出视频"},
        deadline,
    )
    if not modal_markers:
        raise WorkerError("JY007_EXPORT_DIALOG_UNAVAILABLE")
    controls = _controls_for(pids)
    edits = [
        control
        for control in controls
        if control.ControlTypeName == "EditControl" and control.IsEnabled
    ]
    name_edits = [
        control
        for control in edits
        if any(token in control.Name for token in ("名称", "标题", "文件名"))
    ]
    path_edits = [
        control
        for control in edits
        if any(token in control.Name for token in ("位置", "保存", "路径"))
    ]
    try:
        _unique(name_edits, "JY007_EXPORT_NAME_CONTROL_UNAVAILABLE").GetValuePattern().SetValue(
            output.stem
        )
        _unique(path_edits, "JY007_OUTPUT_PATH_CONTROL_UNAVAILABLE").GetValuePattern().SetValue(
            str(output.parent)
        )
    except WorkerError:
        raise
    except Exception as error:
        raise WorkerError("JY007_EXPORT_CONTROL_REJECTED") from error


def _wait_stable_output(output: Path, deadline: float) -> None:
    previous_size = -1
    stable = 0
    while time.monotonic() < deadline:
        if output.is_file():
            size = output.stat().st_size
            stable = stable + 1 if size > 0 and size == previous_size else 0
            previous_size = size
            if stable >= 3:
                return
        time.sleep(1.0)
    raise WorkerError("JY007_OUTPUT_MISSING")


def _read_manifest() -> dict:
    raw = sys.stdin.buffer.read(64 * 1024 + 1)
    if not raw or len(raw) > 64 * 1024:
        raise WorkerError("JY007_DRIVER_JSON_INVALID")
    value = None
    for encoding in ("utf-8-sig", "utf-16"):
        try:
            value = json.loads(raw.decode(encoding))
            break
        except (UnicodeError, json.JSONDecodeError):
            continue
    if value is None:
        raise WorkerError("JY007_DRIVER_JSON_INVALID")
    expected = {
        "draft_path",
        "executable_path",
        "executable_sha256",
        "output_path",
        "schema_version",
        "timeout_ms",
    }
    if not isinstance(value, dict) or set(value) != expected:
        raise WorkerError("JY007_DRIVER_KEYS_INVALID")
    if value["schema_version"] != 1:
        raise WorkerError("JY007_DRIVER_SCHEMA_INVALID")
    if not isinstance(value["timeout_ms"], int) or not 1 <= value["timeout_ms"] <= 1_800_000:
        raise WorkerError("JY007_DRIVER_TIMEOUT_INVALID")
    for key in ("draft_path", "executable_path", "output_path"):
        if not isinstance(value[key], str) or not os.path.isabs(value[key]):
            raise WorkerError("JY007_DRIVER_PATH_INVALID")
    if (
        not isinstance(value["executable_sha256"], str)
        or len(value["executable_sha256"]) != 64
        or any(character not in "0123456789abcdef" for character in value["executable_sha256"])
    ):
        raise WorkerError("JY007_DRIVER_HASH_INVALID")
    return value


def _reject_reparse_tree(path: Path, code: str) -> None:
    current = path
    while True:
        try:
            metadata = current.lstat()
        except OSError as error:
            raise WorkerError(code) from error
        if metadata.is_symlink() or (
            getattr(metadata, "st_file_attributes", 0) & FILE_ATTRIBUTE_REPARSE_POINT
        ):
            raise WorkerError(code)
        parent = current.parent
        if parent == current:
            break
        current = parent


def _run() -> dict:
    manifest = _read_manifest()
    executable = Path(manifest["executable_path"])
    draft = Path(manifest["draft_path"])
    output = Path(manifest["output_path"])
    if executable.name.lower() != "jianyingpro.exe" or not executable.is_file():
        raise WorkerError("JY007_RENDERER_EXECUTABLE_INVALID")
    if not draft.is_dir():
        raise WorkerError("JY007_DRAFT_ARTIFACT_INVALID")
    _reject_reparse_tree(draft, "JY007_DRAFT_ARTIFACT_INVALID")
    if (
        output.suffix.lower() != ".mp4"
        or output.exists()
        or not output.parent.is_dir()
    ):
        raise WorkerError("JY007_OUTPUT_TARGET_INVALID")
    _reject_reparse_tree(output.parent, "JY007_OUTPUT_TARGET_INVALID")
    digest = hashlib.sha256()
    with executable.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != manifest["executable_sha256"]:
        raise WorkerError("JY007_RENDERER_IDENTITY_MISMATCH")

    _assert_no_conflicting_instance(executable)
    foreground_before = int(user32.GetForegroundWindow())
    process = subprocess.Popen(
        [str(executable)],
        cwd=str(executable.parent),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
    )
    job = _create_kill_on_close_job(process)
    def hard_timeout() -> None:
        kernel32.CloseHandle(job)
        os.write(2, b"JY007_RENDER_TIMEOUT")
        os._exit(4)

    watchdog = threading.Timer(manifest["timeout_ms"] / 1000 + 5, hard_timeout)
    watchdog.daemon = True
    watchdog.start()
    try:
        deadline = time.monotonic() + manifest["timeout_ms"] / 1000
        time.sleep(1.0)
        pids = _descendant_pids(process.pid)
        windows = _wait_controls(
            pids,
            lambda control: control.ControlTypeName == "WindowControl",
            min(deadline, time.monotonic() + 30),
        )
        if not windows:
            raise WorkerError("JY007_RENDERER_WINDOW_UNAVAILABLE")
        pids = _descendant_pids(process.pid)
        foreground_after = int(user32.GetForegroundWindow())
        _click_draft(pids, draft.name, deadline)
        _click_unique_button(
            pids, {"导出", "导出视频"}, deadline, "JY007_EXPORT_CONTROL_UNAVAILABLE"
        )
        _configure_export(pids, output, deadline)
        _click_unique_button(
            pids, {"导出"}, deadline, "JY007_EXPORT_CONFIRM_UNAVAILABLE"
        )
        _wait_stable_output(output, deadline)
        return {
            "focusStealObserved": (
                foreground_before != foreground_after and foreground_after != 0
            ),
            "schema_version": 1,
            "status": "completed",
        }
    finally:
        watchdog.cancel()
        kernel32.CloseHandle(job)


def main() -> int:
    try:
        result = _run()
    except WorkerError as error:
        sys.stderr.write(error.code)
        return 2
    except Exception:
        sys.stderr.write("JY007_VISIBLE_RENDER_FAILED")
        return 3
    sys.stdout.write(json.dumps(result, ensure_ascii=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
