import { containsPrivateReference } from './editor-agent-contracts.mjs'

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {number} max */
const isText = (value, max) => typeof value === 'string' && value.length <= max
/** @param {string} value */
const isMojibakePlaceholder = (value) => /^[?\s()[\]（）]+$/u.test(value)
/** @param {unknown} value */
export const isVoiceId = (value) =>
  typeof value === 'string' && /^[A-Za-z][A-Za-z0-9_-]{1,79}$/u.test(value)

/**
 * @typedef {'none' | 'local_authorized'} PackagingBgm
 * @typedef {'none' | 'title_card'} PackagingIntroOutro
 * @typedef {'default' | 'bottom_safe'} PackagingSubtitleStyle
 * @typedef {'follow_template' | 'clean' | 'energetic' | 'knowledge' | 'tech'} PackagingVisualStyle
 * @typedef {'light' | 'balanced' | 'rich'} PackagingDensity
 * @typedef {'follow_template' | 'flower_text' | 'bubble' | 'caption'} PackagingEmphasisStyle
 * @typedef {'none' | 'follow_template'} PackagingStickerMode
 * @typedef {'follow_template' | 'cut' | 'dissolve'} PackagingTransitionStyle
 * @typedef {'flower' | 'bubble' | 'sticker' | 'filter' | 'video_effect' | 'video_animation' | 'mask' | 'blend'} PackagingFamily
 * @typedef {{
 *   enabled: boolean,
 *   bgm: PackagingBgm,
 *   bgmAuthorizationId: string | null,
 *   bgmLabel: string | null,
 *   bgmVolume: number,
 *   sfxAuthorizationId: string | null,
 *   sfxLabel: string | null,
 *   sfxVolume: number,
 *   sfxStartUs: number,
 *   sfxDurationUs: number,
 *   keywordHighlights: string[],
 *   intro: PackagingIntroOutro,
 *   outro: PackagingIntroOutro,
 *   subtitleStyle: PackagingSubtitleStyle,
 *   visualStyle: PackagingVisualStyle,
 *   packagingDensity: PackagingDensity,
 *   emphasisStyle: PackagingEmphasisStyle,
 *   stickerMode: PackagingStickerMode,
 *   transitionStyle: PackagingTransitionStyle,
 *   packagingNotes: string,
 * }} Packaging
 */

/** Curated Chinese Edge TTS voices for short-video-factory preview. */
export const CURATED_EDGE_TTS_VOICES = Object.freeze([
  { id: 'zh-CN-XiaoxiaoNeural', label: '晓晓（女声 · 明亮）', gender: 'female', locale: 'zh-CN' },
  { id: 'zh-CN-YunxiNeural', label: '云希（男声 · 清朗）', gender: 'male', locale: 'zh-CN' },
  { id: 'zh-CN-YunyangNeural', label: '云扬（男声 · 稳重）', gender: 'male', locale: 'zh-CN' },
  { id: 'zh-CN-XiaoyiNeural', label: '晓伊（女声 · 柔和）', gender: 'female', locale: 'zh-CN' },
  { id: 'zh-CN-YunjianNeural', label: '云健（男声 · 活力）', gender: 'male', locale: 'zh-CN' },
  { id: 'zh-CN-XiaochenNeural', label: '晓辰（女声 · 沉稳）', gender: 'female', locale: 'zh-CN' },
  { id: 'zh-CN-XiaohanNeural', label: '晓涵（女声 · 亲和）', gender: 'female', locale: 'zh-CN' },
  { id: 'zh-CN-XiaomengNeural', label: '晓梦（女声 · 甜感）', gender: 'female', locale: 'zh-CN' },
])

const CURATED_VOICE_IDS = new Set(CURATED_EDGE_TTS_VOICES.map((voice) => voice.id))

const PACKAGING_VISUAL_STYLES = new Set(['follow_template', 'clean', 'energetic', 'knowledge', 'tech'])
const PACKAGING_DENSITIES = new Set(['light', 'balanced', 'rich'])
const PACKAGING_EMPHASIS_STYLES = new Set(['follow_template', 'flower_text', 'bubble', 'caption'])
const PACKAGING_STICKER_MODES = new Set(['none', 'follow_template'])
const PACKAGING_TRANSITION_STYLES = new Set(['follow_template', 'cut', 'dissolve'])
const FULL_PACKAGING_REQUEST = /(?:全部(?:包装|都加|加入)|所有包装|全都(?:加上|加入)|尽量多(?:加|一些)?包装|丰富(?:包装|一些)?|多种包装|不要只[^。；,，]{0,20}包装)/u
/** @type {ReadonlyArray<readonly [PackagingFamily, RegExp]>} */
const NOTE_FAMILY_PATTERNS = Object.freeze([
  ['flower', /花字|艺术字|动感文字/u],
  ['bubble', /气泡/u],
  ['sticker', /贴纸/u],
  ['filter', /滤镜/u],
  ['video_effect', /特效/u],
  ['video_animation', /动画/u],
  ['mask', /蒙版|遮罩/u],
  ['blend', /混合|叠加/u],
])

/** @type {Record<string, string>} */
const PACKAGING_VISUAL_STYLE_LABELS = Object.freeze({
  follow_template: '跟随模板',
  clean: '清爽克制',
  energetic: '明快有活力',
  knowledge: '清晰讲解',
  tech: '现代科技',
})

/** @type {Record<string, string>} */
const PACKAGING_DENSITY_LABELS = Object.freeze({
  light: '克制',
  balanced: '适中',
  rich: '丰富',
})

const EDITOR_PACKAGING_STYLE_PHRASES = Object.freeze({
  follow_template: ['继续跟随模板', '跟随模板', '跟随已选模板'],
  clean: ['清爽克制'],
  energetic: ['明快有活力', '活力动感'],
  knowledge: ['清晰讲解'],
  tech: ['现代科技'],
})

const EDITOR_PACKAGING_DENSITY_PHRASES = Object.freeze({
  light: ['克制点缀', '克制'],
  balanced: ['均衡重点', '适中'],
  rich: ['丰富强调', '丰富'],
})

/** @param {string} text @param {string} phrase */
const instructionNamesPhrase = (text, phrase) =>
  text.includes(`“${phrase}”`) || text.includes(`"${phrase}"`)

/**
 * Map AI-editor packaging dropdown text onto the same brief keys used by
 * recommend_packaging. Empty / unmatched instructions stay null so the
 * current project brief is preserved.
 * @param {unknown} instruction
 * @returns {{visualStyle: 'follow_template' | 'clean' | 'energetic' | 'knowledge' | 'tech' | null, packagingDensity: 'light' | 'balanced' | 'rich' | null}}
 */
export const resolvePackagingIntentFromEditorInstruction = (instruction) => {
  const text = typeof instruction === 'string' ? instruction : ''
  /** @type {'follow_template' | 'clean' | 'energetic' | 'knowledge' | 'tech' | null} */
  let visualStyle = null
  /** @type {'light' | 'balanced' | 'rich' | null} */
  let packagingDensity = null
  if (text.includes('包装风格')) {
    for (const [key, phrases] of Object.entries(EDITOR_PACKAGING_STYLE_PHRASES)) {
      if (phrases.some((phrase) => instructionNamesPhrase(text, phrase))) {
        visualStyle = /** @type {'follow_template' | 'clean' | 'energetic' | 'knowledge' | 'tech'} */ (key)
        break
      }
    }
  }
  if (text.includes('包装强度')) {
    for (const [key, phrases] of Object.entries(EDITOR_PACKAGING_DENSITY_PHRASES)) {
      if (phrases.some((phrase) => instructionNamesPhrase(text, phrase))) {
        packagingDensity = /** @type {'light' | 'balanced' | 'rich'} */ (key)
        break
      }
    }
  }
  return { visualStyle, packagingDensity }
}

/** @param {string} value */
export const redactBriefText = (value) => {
  let decoded = value
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const next = decodeURIComponent(decoded)
      if (next === decoded) break
      decoded = next
    } catch {
      break
    }
  }
  if (
    containsPrivateReference(value) ||
    containsPrivateReference(decoded) ||
    /(?:^|[^\p{L}\p{N}._~%+\/-])(?:~\/|\/(?!\/))\S+/u.test(decoded) ||
    /\b(?:github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9_]+|xox[baprs]-[A-Za-z0-9-]+|sk_live_[A-Za-z0-9_]+)\b/u.test(decoded)
  ) {
    return '[已移除敏感内容]'
  }
  return decoded
    .replace(/\b(?:https?:\/\/|www\.)\S+/giu, '[已移除链接]')
    .replace(/\b(?:authorization|bearer)(?:\s*[:=]\s*|\s+)\S+/giu, 'Bearer [已移除凭据]')
    .replace(/\b(?:api[_-]?key|github[_-]?token|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|secret|token)\s*[:=]\s*\S+/giu, '[已移除凭据]')
    .replace(/\bgh[pousr]_[A-Za-z0-9_]+\b/gu, '[已移除凭据]')
    .replace(/\bsk-[A-Za-z0-9_-]{8,}\b/gu, '[已移除凭据]')
    .replace(/(?:[A-Za-z]:[\\/]|\\\\)[^\s；，,]+/gu, '[已移除本机路径]')
}

/** @returns {Packaging} */
export const emptyPackaging = () => ({
  enabled: true,
  bgm: 'none',
  bgmAuthorizationId: null,
  bgmLabel: null,
  bgmVolume: 0.12,
  sfxAuthorizationId: null,
  sfxLabel: null,
  sfxVolume: 0.35,
  sfxStartUs: 500_000,
  sfxDurationUs: 800_000,
  keywordHighlights: [],
  intro: 'none',
  outro: 'none',
  subtitleStyle: 'default',
  visualStyle: 'follow_template',
  packagingDensity: 'balanced',
  emphasisStyle: 'follow_template',
  stickerMode: 'none',
  transitionStyle: 'follow_template',
  packagingNotes: '',
})

/**
 * @param {unknown} value
 * @returns {{
 *   enabled: boolean,
 *   bgm: 'none' | 'local_authorized',
 *   bgmAuthorizationId: string | null,
 *   bgmLabel: string | null,
 *   bgmVolume: number,
 *   sfxAuthorizationId: string | null,
 *   sfxLabel: string | null,
 *   sfxVolume: number,
 *   sfxStartUs: number,
 *   sfxDurationUs: number,
 *   keywordHighlights: string[],
 *   intro: 'none' | 'title_card',
 *   outro: 'none' | 'title_card',
 *   subtitleStyle: 'default' | 'bottom_safe',
 *   visualStyle: 'follow_template' | 'clean' | 'energetic' | 'knowledge' | 'tech',
 *   packagingDensity: 'light' | 'balanced' | 'rich',
 *   emphasisStyle: 'follow_template' | 'flower_text' | 'bubble' | 'caption',
 *   stickerMode: 'none' | 'follow_template',
 *   transitionStyle: 'follow_template' | 'cut' | 'dissolve',
 *   packagingNotes: string,
 * }}
 */
export const normalizePackaging = (value) => {
  const source = isRecord(value) ? value : {}
  const keywords = Array.isArray(source.keywordHighlights)
    ? source.keywordHighlights
      .filter((item) => typeof item === 'string')
      .map((item) => item.trim())
      .filter((item) => Boolean(item) && !isMojibakePlaceholder(item))
      .slice(0, 12)
    : []
  const bgm = source.bgm === 'local_authorized' ? 'local_authorized' : 'none'
  const bgmAuthorizationId =
    bgm === 'local_authorized' &&
    typeof source.bgmAuthorizationId === 'string' &&
    source.bgmAuthorizationId.trim()
      ? source.bgmAuthorizationId.trim().slice(0, 160)
      : null
  const bgmLabel =
    bgm === 'local_authorized' &&
    typeof source.bgmLabel === 'string' &&
    source.bgmLabel.trim()
      ? source.bgmLabel.trim().slice(0, 100)
      : null
  const bgmVolume = typeof source.bgmVolume === 'number' && Number.isFinite(source.bgmVolume)
    ? Math.max(0, Math.min(1, source.bgmVolume))
    : 0.12
  const sfxAuthorizationId = typeof source.sfxAuthorizationId === 'string' && source.sfxAuthorizationId.trim()
    ? source.sfxAuthorizationId.trim().slice(0, 160)
    : null
  const sfxLabel = sfxAuthorizationId && typeof source.sfxLabel === 'string' && source.sfxLabel.trim()
    ? source.sfxLabel.trim().slice(0, 100)
    : null
  const sfxVolume = typeof source.sfxVolume === 'number' && Number.isFinite(source.sfxVolume)
    ? Math.max(0, Math.min(1, source.sfxVolume))
    : 0.35
  const sfxStartUs = Number.isSafeInteger(source.sfxStartUs) && source.sfxStartUs >= 0
    ? Math.min(source.sfxStartUs, 180_000_000)
    : 500_000
  const sfxDurationUs = Number.isSafeInteger(source.sfxDurationUs) && source.sfxDurationUs > 0
    ? Math.min(source.sfxDurationUs, 10_000_000)
    : 800_000
  /** @type {Packaging} */
  const normalized = {
    enabled: source.enabled !== false,
    bgm,
    bgmAuthorizationId,
    bgmLabel,
    bgmVolume,
    sfxAuthorizationId,
    sfxLabel,
    sfxVolume,
    sfxStartUs,
    sfxDurationUs,
    keywordHighlights: keywords,
    intro: source.intro === 'title_card' ? 'title_card' : 'none',
    outro: source.outro === 'title_card' ? 'title_card' : 'none',
    subtitleStyle: source.subtitleStyle === 'bottom_safe' ? 'bottom_safe' : 'default',
    visualStyle: typeof source.visualStyle === 'string' && PACKAGING_VISUAL_STYLES.has(source.visualStyle) ? /** @type {PackagingVisualStyle} */ (source.visualStyle) : 'follow_template',
    packagingDensity: typeof source.packagingDensity === 'string' && PACKAGING_DENSITIES.has(source.packagingDensity) ? /** @type {PackagingDensity} */ (source.packagingDensity) : 'balanced',
    emphasisStyle: typeof source.emphasisStyle === 'string' && PACKAGING_EMPHASIS_STYLES.has(source.emphasisStyle) ? /** @type {PackagingEmphasisStyle} */ (source.emphasisStyle) : 'follow_template',
    stickerMode: typeof source.stickerMode === 'string' && PACKAGING_STICKER_MODES.has(source.stickerMode) ? /** @type {PackagingStickerMode} */ (source.stickerMode) : 'none',
    transitionStyle: typeof source.transitionStyle === 'string' && PACKAGING_TRANSITION_STYLES.has(source.transitionStyle) ? /** @type {PackagingTransitionStyle} */ (source.transitionStyle) : 'follow_template',
    packagingNotes: typeof source.packagingNotes === 'string' && !isMojibakePlaceholder(source.packagingNotes.trim())
      ? source.packagingNotes.trim().slice(0, 2000)
      : '',
  }
  return normalized
}

/**
 * @param {unknown} brief
 * @returns {Record<string, any>}
 */
export const normalizeBrief = (brief) => {
  const source = isRecord(brief) ? brief : {}
  const voiceRate = Number.isInteger(source.voiceRate)
    ? Math.max(-100, Math.min(100, source.voiceRate))
    : 0
  const voiceId =
    typeof source.voiceId === 'string' && source.voiceId.trim()
      ? source.voiceId.trim()
      : null
  return {
    ...source,
    voiceId,
    voiceRate,
    packaging: normalizePackaging(source.packaging),
  }
}

/** @param {unknown} packaging */
export const validPackaging = (packaging) => {
  if (!isRecord(packaging)) return false
  return (
    typeof packaging.enabled === 'boolean' &&
    ['none', 'local_authorized'].includes(packaging.bgm) &&
    (packaging.bgmAuthorizationId === null ||
      (typeof packaging.bgmAuthorizationId === 'string' &&
        packaging.bgmAuthorizationId.length > 0 &&
        packaging.bgmAuthorizationId.length <= 160)) &&
    (packaging.bgmLabel === null ||
      (typeof packaging.bgmLabel === 'string' && packaging.bgmLabel.length <= 100)) &&
    typeof packaging.bgmVolume === 'number' &&
    Number.isFinite(packaging.bgmVolume) &&
    packaging.bgmVolume >= 0 &&
    packaging.bgmVolume <= 1 &&
    (packaging.sfxAuthorizationId === null ||
      (typeof packaging.sfxAuthorizationId === 'string' && packaging.sfxAuthorizationId.length > 0 && packaging.sfxAuthorizationId.length <= 160)) &&
    (packaging.sfxLabel === null || (typeof packaging.sfxLabel === 'string' && packaging.sfxLabel.length <= 100)) &&
    typeof packaging.sfxVolume === 'number' && Number.isFinite(packaging.sfxVolume) && packaging.sfxVolume >= 0 && packaging.sfxVolume <= 1 &&
    Number.isSafeInteger(packaging.sfxStartUs) && packaging.sfxStartUs >= 0 && packaging.sfxStartUs <= 180_000_000 &&
    Number.isSafeInteger(packaging.sfxDurationUs) && packaging.sfxDurationUs > 0 && packaging.sfxDurationUs <= 10_000_000 &&
    Array.isArray(packaging.keywordHighlights) &&
    packaging.keywordHighlights.length <= 12 &&
    packaging.keywordHighlights.every((item) => isText(item, 160)) &&
    ['none', 'title_card'].includes(packaging.intro) &&
    ['none', 'title_card'].includes(packaging.outro) &&
    ['default', 'bottom_safe'].includes(packaging.subtitleStyle) &&
    PACKAGING_VISUAL_STYLES.has(packaging.visualStyle) &&
    PACKAGING_DENSITIES.has(packaging.packagingDensity) &&
    PACKAGING_EMPHASIS_STYLES.has(packaging.emphasisStyle) &&
    PACKAGING_STICKER_MODES.has(packaging.stickerMode) &&
    PACKAGING_TRANSITION_STYLES.has(packaging.transitionStyle) &&
    isText(packaging.packagingNotes, 2000) &&
    (packaging.bgm !== 'local_authorized' ||
      packaging.bgmAuthorizationId === null ||
      typeof packaging.bgmAuthorizationId === 'string')
  )
}

/**
 * Convert structured UI choices into the constrained intent the AI Editor is
 * allowed to consume. This is deterministic, opaque-resource free, and keeps
 * legacy free-form notes as an auditable supplement rather than the planner.
 * @param {ReturnType<typeof normalizePackaging>} packaging
 */
export const buildPackagingPlan = (packaging) => {
  const normalized = resolvePackagingForExecution(packaging)
  return {
    enabled: normalized.enabled,
    visualStyle: normalized.visualStyle,
    packagingDensity: normalized.packagingDensity,
    emphasisStyle: normalized.emphasisStyle,
    stickerMode: normalized.stickerMode,
    transitionStyle: normalized.transitionStyle,
    keywordHighlights: normalized.keywordHighlights.map(redactBriefText),
    packagingNotes: redactBriefText(normalized.packagingNotes),
  }
}

/** @param {unknown} packaging */
export const resolvePackagingForExecution = (packaging) => {
  const normalized = normalizePackaging(packaging)
  if (!normalized.enabled || !FULL_PACKAGING_REQUEST.test(normalized.packagingNotes)) {
    return normalized
  }
  return /** @type {ReturnType<typeof normalizePackaging>} */ ({ ...normalized, packagingDensity: 'rich' })
}

/** @param {unknown} packaging */
export const buildPackagingResourceIntent = (packaging) => {
  const resolved = resolvePackagingForExecution(packaging)
  const completeRequested = FULL_PACKAGING_REQUEST.test(resolved.packagingNotes)
  /** @type {PackagingFamily[]} */
  const families = []
  /** @param {PackagingFamily} family */
  const add = (family) => { if (!families.includes(family)) families.push(family) }
  if (!resolved.enabled) return { packaging: resolved, families, queryTerms: [] }
  if (resolved.emphasisStyle === 'flower_text') add('flower')
  if (resolved.emphasisStyle === 'bubble') add('bubble')
  if (resolved.stickerMode === 'follow_template') add('sticker')
  /** @type {PackagingFamily[]} */
  const allFamilies = ['flower', 'bubble', 'sticker', 'filter', 'video_effect', 'video_animation', 'mask', 'blend']
  /** @type {Array<Exclude<PackagingFamily, 'flower' | 'bubble' | 'sticker'>>} */
  const richFamilies = ['filter', 'video_effect', 'video_animation', 'mask', 'blend']
  if (completeRequested) {
    for (const family of allFamilies) add(family)
  } else if (resolved.packagingDensity === 'rich' && resolved.visualStyle !== 'clean') {
    for (const family of richFamilies) add(family)
  }
  const notesWantArtFlower = /艺术字|动感文字/u.test(resolved.packagingNotes)
  const notesWantGenericFlower = /花字/u.test(resolved.packagingNotes)
  for (const [family, pattern] of NOTE_FAMILY_PATTERNS) {
    if (family === 'flower') {
      // Generic “花字” plus explicit keywords writes leftover text.rich.
      // Do not also request catalog flower tokens on that path.
      if (notesWantArtFlower || (notesWantGenericFlower && resolved.keywordHighlights.length === 0)) {
        add('flower')
      }
      continue
    }
    if (pattern.test(resolved.packagingNotes)) add(family)
  }
  if (resolved.visualStyle === 'energetic') {
    add('video_effect')
    add('video_animation')
  } else if (resolved.visualStyle === 'tech') {
    add('filter')
    add('video_effect')
  }
  const noteRuns = resolved.packagingNotes
    .replace(/[\u0000-\u001f]/gu, ' ')
    .split(/[\s,，。！？；：:、/|()[\]{}]+/u)
    .map((term) => term.trim())
    .filter((term) => term.length >= 2)
  const noteTerms = []
  for (const run of noteRuns) {
    if (run.length <= 8) noteTerms.push(run)
    // Natural Chinese notes often contain several semantic words without
    // spaces. Bounded n-grams let deterministic fallback find labels such as
    // “重点/公式/花字” without sending the whole sentence as a query.
    if (/^[\u3400-\u9fff]+$/u.test(run)) {
      for (let length = Math.min(4, run.length); length >= 2; length -= 1) {
        for (let start = 0; start + length <= run.length; start += 1) {
          noteTerms.push(run.slice(start, start + length))
          if (noteTerms.length >= 24) break
        }
        if (noteTerms.length >= 24) break
      }
    }
    if (noteTerms.length >= 24) break
  }
  const filteredNoteTerms = [...new Set(noteTerms)]
    .filter((term) => !/^(?:不要|不能|避免|请|需要|希望|可以|帮我|自动|添加|使用|放在|画面|视频|素材|只在|出现)$/u.test(term))
    .slice(0, 8)
  return {
    packaging: resolved,
    families,
    queryTerms: [resolved.visualStyle, ...resolved.keywordHighlights.map(redactBriefText)]
      .concat(filteredNoteTerms.map(redactBriefText))
      .filter((value) => typeof value === 'string' && value.trim())
      .slice(0, 12),
  }
}

/**
 * @param {ReturnType<typeof normalizePackaging>} packaging
 */
export const buildPackagingIntent = (packaging) => {
  const normalized = resolvePackagingForExecution(packaging)
  const plan = buildPackagingPlan(normalized)
  const labels = {
    visualStyle: { follow_template: '跟随已选模板', clean: '简洁专业', energetic: '活力动感', knowledge: '知识讲解', tech: '科技感' },
    packagingDensity: { light: '克制', balanced: '适中', rich: '丰富' },
    emphasisStyle: { follow_template: '跟随模板花字', flower_text: '重点内容使用花字', bubble: '重点内容使用气泡强调', caption: '只做重点字幕强调' },
    stickerMode: { none: '不添加贴纸', follow_template: '跟随模板贴纸' },
    transitionStyle: { follow_template: '跟随模板转场', cut: '以硬切为主', dissolve: '以叠化为主' },
  }
  const lines = [
    `智能包装：${plan.enabled ? '启用' : '不启用'}`,
    `包装风格：${labels.visualStyle[plan.visualStyle]}`,
    `包装密度：${labels.packagingDensity[plan.packagingDensity]}`,
    `重点花字：${plan.keywordHighlights.length ? plan.keywordHighlights.join('、') : '未指定'}`,
    `重点内容呈现：${labels.emphasisStyle[plan.emphasisStyle]}`,
    `贴纸：${labels.stickerMode[plan.stickerMode]}`,
    `转场：${labels.transitionStyle[plan.transitionStyle]}`,
  ]
  if (normalized.intro === 'title_card') lines.push('片头：标题卡')
  if (normalized.outro === 'title_card') lines.push('片尾：标题卡')
  if (plan.packagingNotes) lines.push(`补充要求（仅在能力允许时执行）：${plan.packagingNotes}`)
  return lines.join('；')
}

/** @param {unknown} brief */
export const validBriefExtensions = (brief) => {
  if (!isRecord(brief)) return false
  if (brief.voiceId !== null && brief.voiceId !== undefined && !isVoiceId(brief.voiceId)) {
    return false
  }
  if (
    brief.voiceRate !== undefined &&
    (!Number.isInteger(brief.voiceRate) || brief.voiceRate < -100 || brief.voiceRate > 100)
  ) {
    return false
  }
  if (brief.packaging !== undefined && !validPackaging(normalizePackaging(brief.packaging))) {
    return false
  }
  return true
}

/** @param {string | null | undefined} voiceId */
export const isCuratedVoiceId = (voiceId) =>
  typeof voiceId === 'string' && CURATED_VOICE_IDS.has(voiceId)

/** @param {unknown} voiceId */
const isRunningHubAuditVoiceId = (voiceId) =>
  typeof voiceId === 'string' && /^rh_[a-f0-9]{24}$/u.test(voiceId)

/** @param {unknown} voiceId */
const isJianyingPresetAuditVoiceId = (voiceId) =>
  typeof voiceId === 'string' && /^jy_[a-f0-9]{24}$/u.test(voiceId)

/**
 * @param {Record<string, any>} brief
 * @param {{fallbackVoice?: string | null}} [options]
 */
export const resolvePreviewVoice = (brief, { fallbackVoice = null } = {}) => {
  const normalized = normalizeBrief(brief)
  if (normalized.voiceover !== 'required') {
    return { enabled: false, voice: null, rate: 0 }
  }
  const selected =
    (normalized.voiceId && isVoiceId(normalized.voiceId) ? normalized.voiceId : null) ||
    (fallbackVoice && isVoiceId(fallbackVoice) ? fallbackVoice : null)
  return {
    enabled: true,
    voice: selected,
    rate: normalized.voiceRate,
  }
}

/**
 * @param {string} script
 * @param {string[]} keywords
 */
export const enhanceScriptWithKeywords = (script, keywords) => {
  const list = Array.isArray(keywords)
    ? keywords.map((item) => String(item).trim()).filter(Boolean).slice(0, 12)
    : []
  if (!list.length) return String(script ?? '')
  const highlight = `【卖点】${list.join(' · ')}`
  const base = String(script ?? '').trim()
  if (!base) return highlight
  if (base.includes(highlight)) return base
  return `${base}\n${highlight}`
}

const UNSUPPORTED_NOTE_PATTERNS = Object.freeze([
  { pattern: /花字|动感文字|艺术字/u, label: '任意花字 / 艺术字动画' },
  { pattern: /贴纸|表情包/u, label: '贴纸 / 表情包' },
  { pattern: /复杂转场|闪白|叠化|推拉/u, label: '复杂转场效果' },
  { pattern: /曲库|在线音乐|抖音音乐|剪映音乐/u, label: '剪映在线曲库自动搜索/替换' },
  { pattern: /特效|粒子|滤镜包/u, label: '自由特效引擎' },
  { pattern: /弹幕|滚动字幕/u, label: '弹幕 / 滚动字幕' },
])

/**
 * @param {Record<string, any>} brief
 */
export const auditPackagingCapabilities = (brief) => {
  const normalized = normalizeBrief(brief)
  const packaging = normalized.packaging
  /** @type {string[]} */
  const supported = []
  /** @type {string[]} */
  const unsupported = []

  if (normalized.voiceover === 'required') {
    if (normalized.voiceId) {
      if (isRunningHubAuditVoiceId(normalized.voiceId)) {
        supported.push('RunningHub 在线克隆音色（预览与剪映共用同一音频资产）')
      } else if (isJianyingPresetAuditVoiceId(normalized.voiceId)) {
        supported.push('剪映本机预设音色（预览与剪映共用同一音频资产）')
      } else if (isCuratedVoiceId(normalized.voiceId)) {
        supported.push('中文 Edge TTS 配音人声（预览）')
        unsupported.push('剪映草稿配音使用系统语音，可能与预览 Edge TTS 音色不同')
      } else {
        supported.push('已选择配音人声')
        unsupported.push('当前人声来源未识别，预览与剪映音色可能不一致')
      }
    } else {
      unsupported.push('需要配音但未选择人声（将阻止生成预览）')
    }
  } else {
    supported.push('不配音')
  }

  if (normalized.captions === 'auto') {
    supported.push('自动字幕按成片可读字号导出，不再使用过小的白字')
    if (packaging.subtitleStyle === 'bottom_safe') {
      supported.push('草稿字幕样式：底部安全区（可读字号）')
    } else {
      supported.push('草稿字幕样式：默认可读字号')
    }
  } else {
    supported.push('不添加字幕')
  }

  if (packaging.bgm === 'local_authorized') {
    if (packaging.bgmAuthorizationId) {
      supported.push('本机授权 BGM 混音（预览与草稿音轨；剪映曲库需手动替换）')
    } else {
      unsupported.push('已选择本机 BGM 但尚未完成音频授权')
    }
  } else {
    supported.push('不添加 BGM')
  }

  if (!packaging.enabled) {
    supported.push('智能包装未启用（AI 不规划额外包装）')
  } else {
    if (packaging.keywordHighlights.length) {
      supported.push('重点花字按原文写入上传模板的花字样式；音效由模型按画面选择，不循环硬贴')
    }
    if (packaging.visualStyle === 'follow_template') supported.push('包装风格：跟随模板')
    else {
      supported.push(`包装风格“${PACKAGING_VISUAL_STYLE_LABELS[packaging.visualStyle]}”已作为包装检索与资源族偏好`)
    }
    supported.push(`模板包装密度：${PACKAGING_DENSITY_LABELS[packaging.packagingDensity] ?? PACKAGING_DENSITY_LABELS.balanced}（只筛选已绑定令牌）`)
    if (packaging.emphasisStyle === 'flower_text') unsupported.push('花字效果需要已绑定且通过预检的剪映模板能力')
    else if (packaging.emphasisStyle === 'bubble') unsupported.push('气泡花字需要模板提供对应的 text.rich 资源')
    else if (packaging.emphasisStyle === 'caption') supported.push('重点内容使用可执行字幕强调')
    if (packaging.stickerMode === 'follow_template') unsupported.push('贴纸仅在模板提供可执行贴纸资源时写入剪映草稿')
    else supported.push('不添加贴纸')
    if (packaging.transitionStyle === 'cut') supported.push('AI 剪辑转场：硬切（受控写入 canonical RichTimeline）')
    else if (packaging.transitionStyle === 'dissolve') unsupported.push('叠化当前禁止由 AI 自动写入；可通过已批准模板保留')
    else supported.push('AI 剪辑转场偏好：跟随模板')
  }
  if (packaging.intro === 'title_card') {
    supported.push('片头标题卡（成片预览隐藏；剪映草稿写入标题文本轨）')
  }
  if (packaging.outro === 'title_card') {
    supported.push('片尾标题卡（成片预览隐藏；剪映草稿写入标题文本轨）')
  }

  for (const entry of UNSUPPORTED_NOTE_PATTERNS) {
    if (entry.pattern.test(packaging.packagingNotes)) {
      if (
        entry.label === '任意花字 / 艺术字动画' &&
        packaging.keywordHighlights.length > 0 &&
        !/动感文字|艺术字/u.test(packaging.packagingNotes)
      ) continue
      unsupported.push(entry.label)
    }
  }
  if (packaging.packagingNotes && unsupported.length === 0 &&
    !/配音|人声|字幕|BGM|背景音乐|标题|片头|片尾|卖点|关键词/u.test(packaging.packagingNotes)
  ) {
    unsupported.push('自然语言包装说明中含有未映射指令（仅作审计记录，不会自动生效）')
  } else if (
    packaging.packagingNotes &&
    UNSUPPORTED_NOTE_PATTERNS.every((entry) => !entry.pattern.test(packaging.packagingNotes)) &&
    packaging.packagingNotes.length > 0
  ) {
    // Keep notes visible even when no pattern hit: treat as advisory only.
    supported.push('包装说明已保存（可审计；未识别为禁止项）')
  }

  return {
    supported: [...new Set(supported)],
    unsupported: [...new Set(unsupported)],
    previewSubtitleNote: '成片预览默认显示字幕；剪映草稿按所选样式导出',
    jianyingBgmNote: '剪映在线曲库无法自动搜索；导出后可在草稿中手动替换 BGM 音轨',
  }
}

export const listCuratedVoices = () =>
  CURATED_EDGE_TTS_VOICES.map((voice) => ({
    ...voice,
    source: 'edge-tts',
    kind: 'stock',
    referenceLabel: null,
    consentConfirmedAt: null,
    ready: true,
  }))

/**
 * @param {Record<string, any>} brief
 * @param {{fallbackVoice?: string | null}} [options]
 */
export const assertVoiceReadyForPreview = (brief, { fallbackVoice = null } = {}) => {
  const resolved = resolvePreviewVoice(brief, { fallbackVoice })
  if (!resolved.enabled) return resolved
  if (!resolved.voice) {
    const error = Object.assign(new Error('WORKBENCH_VOICE_REQUIRED'), {
      code: 'WORKBENCH_VOICE_REQUIRED',
      status: 409,
    })
    throw error
  }
  return resolved
}
