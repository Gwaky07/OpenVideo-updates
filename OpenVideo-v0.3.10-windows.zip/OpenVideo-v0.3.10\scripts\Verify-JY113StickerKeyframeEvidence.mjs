import { createHash } from 'node:crypto'
import { lstat, mkdtemp, readFile, realpath, rename, rm, rmdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { parseJianyingTextPackagingCatalog } from '../apps/gateway/src/jianying-text-packaging-catalog.mjs'
import { integrityRevision, loadJianyingStickerKeyframeIntegrityKey, signJianyingStickerKeyframeEvidence } from '../apps/gateway/src/jianying-sticker-keyframe-evidence.mjs'

const manifestUrl = new URL('../config/jianying-compatibility.json', import.meta.url)
const safePoint = (point, offset, value, id) => point && point.id === id && (point.time_offset === offset || point.timeOffset === offset) && point.values?.[0] === value
const main = async () => {
  if (!process.argv.includes('--manual-attestation=opened-edited-saved-reopened')) throw new Error('JY113_MANUAL_ATTESTATION_REQUIRED')
  const dataRoot = loadLocalRuntimeConfig().dataRoot; const root = path.join(dataRoot, 'evidence', 'jy113-sticker-keyframe'); const pendingPath = path.join(root, 'pending.json')
  const pending = JSON.parse(await readFile(pendingPath, 'utf8')); const keys = ['schema_version', 'draft_id', 'draft_root', 'media_root', 'media_owner', 'profile_id', 'app_version', 'catalog_fingerprint', 'target_start_us', 'target_duration_us', 'keyframe_ids', 'pre_open_fingerprint']
  const desktop = await detectJianyingDesktop({ compatibilityManifest: JSON.parse(await readFile(manifestUrl, 'utf8')) })
  const catalog = parseJianyingTextPackagingCatalog(JSON.parse(await readFile(path.join(dataRoot, 'catalogs', 'jy063-text-packaging-catalog.json'), 'utf8')) )
  const validProfile = pending.profile_id === 'jianying-11-2-provisional' && pending.app_version === '11.2.0.14339'
  const integrityKey = await loadJianyingStickerKeyframeIntegrityKey({ evidenceRoot: root })
  if (Object.keys(pending).sort().join('\0') !== keys.sort().join('\0') || pending.schema_version !== 1 || !validProfile || pending.catalog_fingerprint !== catalog?.fingerprint || desktop?.profileId !== pending.profile_id || desktop.version !== pending.app_version || path.resolve(desktop.draftRoot) !== path.resolve(pending.draft_root) || pending.target_start_us !== 0 || pending.target_duration_us !== 4_000_000 || !Array.isArray(pending.keyframe_ids) || pending.keyframe_ids.length !== 2 || pending.keyframe_ids.some((point, index) => typeof point?.id !== 'string' || !/^[a-f0-9]{32}$/u.test(point.id) || point.offset_us !== (index === 0 ? 500_000 : 1_000_000) || point.initial_value !== (index === 0 ? 1 : 1.2)) || !/^[a-f0-9]{64}$/u.test(pending.pre_open_fingerprint)) throw new Error('JY113_EVIDENCE_BINDING_INVALID')
  const canonicalTemp = await realpath(tmpdir()); const canonicalMedia = await realpath(pending.media_root); const relative = path.relative(canonicalTemp, canonicalMedia); const metadata = await lstat(canonicalMedia); const ownerPath = path.join(canonicalMedia, '.openvideo-jy113-owner')
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative) || !path.basename(canonicalMedia).startsWith('openvideo-jy113-sticker-keyframe-') || !metadata.isDirectory() || metadata.isSymbolicLink() || await readFile(ownerPath, 'utf8') !== pending.media_owner) throw new Error('JY113_TEMP_OWNERSHIP_INVALID')
  const encryptedPath = path.join(desktop.draftRoot, pending.draft_id, 'draft_content.json'); const encrypted = await readFile(encryptedPath); if (createHash('sha256').update(encrypted).digest('hex') === pending.pre_open_fingerprint) throw new Error('JY113_MANUAL_EDIT_NOT_PERSISTED')
  const inspectRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy113-verify-'))
  try {
    const plain = path.join(inspectRoot, 'draft_content.json'); const meta = await createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version }).ensurePlaintextFile(encryptedPath, plain)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY113_ENCRYPT_V2_REQUIRED')
    const content = JSON.parse(await readFile(plain, 'utf8')); const segments = content?.tracks?.filter((track) => track?.name === 'sticker-1').flatMap((track) => track.segments ?? []) ?? []
    const matched = segments.filter((segment) => (segment?.target_timerange?.start ?? 0) === 0 && segment?.target_timerange?.duration === 4_000_000 && Array.isArray(segment?.common_keyframes) && segment.common_keyframes.filter((list) => list?.property_type === 'KFTypeScaleX').length === 1 && (() => { const points = segment.common_keyframes.find((list) => list?.property_type === 'KFTypeScaleX')?.keyframe_list; return Array.isArray(points) && points.length === 2 && safePoint(points[0], 500_000, 1, pending.keyframe_ids[0].id) && safePoint(points[1], 1_000_000, 1.4, pending.keyframe_ids[1].id) })())
    if (matched.length !== 1) throw new Error('JY113_STICKER_KEYFRAME_PERSISTENCE_INVALID')
    const postSaveFingerprint = createHash('sha256').update(encrypted).digest('hex')
    const unsigned = { schema_version: 1, manual_evidence_verified: true, manual_attestation: 'opened-edited-saved-reopened', profile_id: pending.profile_id, app_version: pending.app_version, catalog_fingerprint: pending.catalog_fingerprint, scheme: 'encrypt_v2', opened: true, edited: true, saved: true, reopened: true, matching_keyframe_count: 2, temporary_media_cleaned: true, draft_id: pending.draft_id, target_start_us: 0, target_duration_us: 4_000_000, keyframe_ids: [{ id: pending.keyframe_ids[0].id, offset_us: 500_000, value: 1 }, { id: pending.keyframe_ids[1].id, offset_us: 1_000_000, value: 1.4 }], pre_open_fingerprint: pending.pre_open_fingerprint, post_save_fingerprint: postSaveFingerprint, integrity_revision: integrityRevision }
    const record = { ...unsigned, integrity_signature: signJianyingStickerKeyframeEvidence(unsigned, integrityKey) }
    await securePrivateRuntimeRoot(root); const staged = path.join(root, 'post-save.pending.json'); await writeFile(staged, `${JSON.stringify(record)}\n`, { encoding: 'utf8', mode: 0o600 }); await rm(path.join(canonicalMedia, 'video.mp4'), { force: true }); await rm(path.join(canonicalMedia, 'voice.wav'), { force: true }); await rm(ownerPath, { force: true }); await rmdir(canonicalMedia); await rename(staged, path.join(root, 'post-save.json')); await rm(pendingPath, { force: true })
    process.stdout.write(`${JSON.stringify({ ok: true, capability: 'transform.sticker.keyframe', scheme: 'encrypt_v2', matchingKeyframeCount: 2, temporaryMediaCleaned: true })}\n`)
  } finally { await rm(inspectRoot, { recursive: true, force: true }) }
}
main().catch((error) => { const code = typeof error?.message === 'string' && /^JY113_[A-Z_]+$/u.test(error.message) ? error.message : 'JY113_VERIFY_FAILED'; process.stdout.write(`${JSON.stringify({ ok: false, code })}\n`); process.exitCode = 1 })
