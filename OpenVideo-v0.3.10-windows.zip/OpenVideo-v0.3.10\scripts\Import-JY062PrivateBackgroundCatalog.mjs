import { createHash } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { createJianyingBackgroundCatalog } from '../apps/gateway/src/jianying-background-catalog.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'

const token = (label) => `ovjbg_v1_${createHash('sha256').update(`background.video\0${label}`).digest('base64url')}`

const main = async () => {
  const root = path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs')
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(root)
  const catalog = createJianyingBackgroundCatalog([
    { fill_token: token('blur-soft'), fill_type: 'blur', blur: 0.375, color: '#00000000' },
    { fill_token: token('color-black'), fill_type: 'color', blur: 0, color: '#000000FF' },
  ])
  const output = path.join(root, 'jy062-background-catalog.json')
  await writeFile(output, `${JSON.stringify(catalog)}\n`, { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(`${JSON.stringify({ ok: true, entries: catalog.entries.length, fingerprint: catalog.fingerprint })}\n`)
}

main().catch((error) => {
  process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? 'JY062_BACKGROUND_CATALOG_FAILED' })}\n`)
  process.exitCode = 1
})
