[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$QueryManifestPath,
    [Parameter(Mandatory)][string]$AnalysisResultsPath,
    [Parameter(Mandatory)][string]$RuntimeDataRoot,
    [Parameter(Mandatory)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$pathComparison = [StringComparison]::OrdinalIgnoreCase
$utf8 = New-Object Text.UTF8Encoding($false)

function Get-FullPath {
    param([string]$Path, [string]$Name, [bool]$MustExist)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw ($Name + ' is required.') }
    if (-not [IO.Path]::IsPathRooted($Path) -or $Path -match '^[A-Za-z]:[^\\/]') {
        throw ($Name + ' must be an absolute path.')
    }
    $fullPath = [IO.Path]::GetFullPath($Path)
    if ($MustExist -and -not (Test-Path -LiteralPath $fullPath)) { throw ($Name + ' does not exist: ' + $fullPath) }
    $root = [IO.Path]::GetPathRoot($fullPath)
    if ($fullPath.Equals($root, $pathComparison)) { return $root }
    return $fullPath.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
}

function Test-Within {
    param([string]$Root, [string]$Candidate)
    $trimmedRoot = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
    $prefix = $trimmedRoot + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($trimmedRoot, $pathComparison) -or $Candidate.StartsWith($prefix, $pathComparison)
}

function Assert-NoReparseAncestors {
    param([string]$Path, [string]$Name)
    $cursor = $Path
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force
        $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
            throw ($Name + ' crosses a symbolic-link or reparse-point boundary: ' + $cursor)
        }
        $parent = Split-Path -Parent $cursor
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-NotReparsePath {
    param([string]$Path, [string]$Name)
    $item = Get-Item -LiteralPath $Path -Force
    $hasLinkType = $null -ne $item.PSObject.Properties['LinkType'] -and [bool]$item.LinkType
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $hasLinkType) {
        throw "$Name must not be a symbolic link or reparse point: $Path"
    }
}

function Get-PrivatePath {
    param([string]$Path, [string]$Name, [string]$RuntimeRoot, [bool]$MustExist)
    $fullPath = Get-FullPath -Path $Path -Name $Name -MustExist $MustExist
    if (-not (Test-Within -Root $RuntimeRoot -Candidate $fullPath)) { throw ($Name + ' must be inside RuntimeDataRoot.') }
    $existingPath = if (Test-Path -LiteralPath $fullPath) { $fullPath } else { Split-Path -Parent $fullPath }
    if (-not $existingPath -or -not (Test-Path -LiteralPath $existingPath)) { throw ($Name + ' must have an existing parent inside RuntimeDataRoot.') }
    if (Test-Path -LiteralPath $fullPath -PathType Container) { throw ($Name + ' must be a file path.') }
    Assert-NoReparseAncestors -Path $existingPath -Name $Name
    return $fullPath
}

function Get-TermSet {
    param([string]$Text)
    $terms = @{}
    $normalized = $Text.ToLowerInvariant().Normalize([Text.NormalizationForm]::FormKC)
    foreach ($match in [regex]::Matches($normalized, '[\p{L}\p{Nd}]+')) {
        if ($match.Value.Length -ge 2) { $terms[$match.Value] = $true }
    }
    $cjk = -join ([regex]::Matches($normalized, '[\p{IsCJKUnifiedIdeographs}]') | ForEach-Object Value)
    foreach ($character in $cjk.ToCharArray()) {
        $terms[[string]$character] = $true
    }
    for ($index = 0; $index -lt ($cjk.Length - 1); $index++) {
        $terms[$cjk.Substring($index, 2)] = $true
    }
    return $terms
}

function Get-OverlapScore {
    param([hashtable]$QueryTerms, [hashtable]$DocumentTerms)
    if ($QueryTerms.Count -eq 0 -or $DocumentTerms.Count -eq 0) { return 0.0 }
    $matched = 0
    foreach ($term in $QueryTerms.Keys) {
        if ($DocumentTerms.ContainsKey($term)) { $matched++ }
    }
    return [double]$matched / [math]::Sqrt([double]($QueryTerms.Count * $DocumentTerms.Count))
}

$repositoryPath = Get-FullPath -Path (Split-Path -Parent $PSScriptRoot) -Name 'RepositoryRoot' -MustExist $true
$runtimePath = Get-FullPath -Path $RuntimeDataRoot -Name 'RuntimeDataRoot' -MustExist $true
Assert-NotReparsePath -Path $repositoryPath -Name 'RepositoryRoot'
if ((Test-Within -Root $repositoryPath -Candidate $runtimePath) -or (Test-Within -Root $runtimePath -Candidate $repositoryPath)) {
    throw 'RuntimeDataRoot and the repository must be separate and must not contain one another.'
}
Assert-NoReparseAncestors -Path $runtimePath -Name 'RuntimeDataRoot'

$queryPath = Get-PrivatePath -Path $QueryManifestPath -Name 'QueryManifestPath' -RuntimeRoot $runtimePath -MustExist $true
$analysisPath = Get-PrivatePath -Path $AnalysisResultsPath -Name 'AnalysisResultsPath' -RuntimeRoot $runtimePath -MustExist $true
$outputPathFull = Get-PrivatePath -Path $OutputPath -Name 'OutputPath' -RuntimeRoot $runtimePath -MustExist $false
$expectedAnalysisPath = Join-Path $runtimePath 'evidence/em-002/private-analysis-results.json'
if (-not $analysisPath.Equals($expectedAnalysisPath, $pathComparison)) {
    throw 'AnalysisResultsPath must be the verified EM-002 private analysis results file.'
}
if ($outputPathFull.Equals($queryPath, $pathComparison) -or $outputPathFull.Equals($analysisPath, $pathComparison)) {
    throw 'OutputPath must not overwrite an input file.'
}

$sourceVerificationPath = Join-Path $runtimePath 'evidence/em-002/source-verification.json'
$analysisVerificationPath = Join-Path $runtimePath 'evidence/em-002/analysis-verification.json'
$querySnapshotPath = Join-Path $runtimePath 'evidence/em-003/private/search-query-snapshot.json'
$queryVerificationPath = Join-Path $runtimePath 'evidence/em-003/search-query-verification.json'
foreach ($requiredEvidence in @($sourceVerificationPath, $analysisVerificationPath, $querySnapshotPath, $queryVerificationPath)) {
    if (-not (Test-Path -LiteralPath $requiredEvidence -PathType Leaf)) {
        throw 'Verified EM-002 analysis and EM-003 query preflight evidence are required before search.'
    }
    Assert-NoReparseAncestors -Path $requiredEvidence -Name 'Search prerequisite evidence'
}

$sourceVerification = Get-Content -LiteralPath $sourceVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
if ($sourceVerification.unchanged -ne $true -or [int]$sourceVerification.sample_count -ne 5) {
    throw 'EM-002 source verification must confirm five unchanged files.'
}
$analysisVerification = Get-Content -LiteralPath $analysisVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
if ([int]$analysisVerification.sample_count -ne 5 -or [int]$analysisVerification.indexed_count -ne 5) {
    throw 'EM-002 analysis verification must confirm five indexed samples.'
}
if ([string]$analysisVerification.scene_representation -ne 'source+start+end' -or [int]$analysisVerification.permanent_scene_clips -ne 0) {
    throw 'EM-002 analysis verification must confirm logical scenes and zero permanent clips.'
}

$queryManifest = Get-Content -LiteralPath $queryPath -Raw -Encoding utf8 | ConvertFrom-Json
if ($queryManifest.schema_version -ne 1 -or $queryManifest.authorization -ne 'read_only_search') {
    throw 'Query manifest must use schema_version 1 and read_only_search authorization.'
}
$sentences = @($queryManifest.sentences | ForEach-Object { ([string]$_).Trim() })
if ($sentences.Count -ne 8) { throw 'Query manifest must contain exactly eight sentences.' }
$seenSentences = @{}
foreach ($sentence in $sentences) {
    if ([string]::IsNullOrWhiteSpace($sentence) -or $sentence -match '[\r\n]') { throw 'Every search sentence must be a non-empty single line.' }
    $key = $sentence.ToLowerInvariant()
    if ($seenSentences.ContainsKey($key)) { throw 'Search sentences must be unique.' }
    $seenSentences[$key] = $true
}
$querySnapshot = Get-Content -LiteralPath $querySnapshotPath -Raw -Encoding utf8 | ConvertFrom-Json
$queryVerification = Get-Content -LiteralPath $queryVerificationPath -Raw -Encoding utf8 | ConvertFrom-Json
$snapshotSentences = @($querySnapshot.sentences | ForEach-Object { ([string]$_).Trim() })
if (($sentences | ConvertTo-Json -Compress) -ne ($snapshotSentences | ConvertTo-Json -Compress)) {
    throw 'Search query snapshot does not match the manifest.'
}
if ([int]$queryVerification.sentence_count -ne 8 -or $queryVerification.query_text_private -ne $true) {
    throw 'Search query verification must confirm eight private sentences.'
}

$analysisResults = Get-Content -LiteralPath $analysisPath -Raw -Encoding utf8 | ConvertFrom-Json
if ($analysisResults.schema_version -ne 1) { throw 'Analysis results schema_version must be 1.' }
$samples = @($analysisResults.samples)
if ($samples.Count -ne 5) { throw 'Analysis results must contain exactly five samples.' }

$documents = @()
$seenSources = @{}
foreach ($sample in $samples) {
    if ([string]$sample.status -ne 'indexed') { throw 'Every analysis sample must be indexed before search.' }
    $source = Get-FullPath -Path ([string]$sample.source) -Name 'Analysis source' -MustExist $false
    if ($seenSources.ContainsKey($source)) { throw 'Analysis results contain duplicate sources.' }
    $seenSources[$source] = $true
    $duration = [double]$sample.duration
    if ($duration -le 0) { throw 'Every analysis sample must have a positive duration.' }
    $parts = @([string]$sample.summary)
    if ($null -ne $sample.PSObject.Properties['tags']) {
        $parts += @($sample.tags | ForEach-Object { [string]$_ })
    }
    if ($null -ne $sample.PSObject.Properties['key_facts']) {
        $parts += @($sample.key_facts | ForEach-Object { [string]$_ })
    }
    $scenes = @($sample.scenes)
    if ($scenes.Count -eq 0) { throw 'Every analysis sample must contain at least one indexed scene.' }
    foreach ($scene in $scenes) {
        $sceneSource = Get-FullPath -Path ([string]$scene.source) -Name 'Analysis scene source' -MustExist $false
        $start = [double]$scene.start
        $end = [double]$scene.end
        if (-not $sceneSource.Equals($source, $pathComparison) -or $start -lt 0 -or $end -le $start -or $end -gt $duration) {
            throw 'Analysis scene bounds are invalid.'
        }
    }
    $terms = Get-TermSet -Text ($parts -join ' ')
    if ($terms.Count -eq 0) { throw 'Every analysis sample must contain searchable summary, tags or key facts.' }
    $documents += [pscustomobject]@{
        source = $source
        terms = $terms
        scenes = $scenes
    }
}

$queryResults = @()
foreach ($sentence in $sentences) {
    $queryTerms = Get-TermSet -Text $sentence
    $ranked = @(
        $documents |
            ForEach-Object {
                [pscustomobject]@{
                    document = $_
                    score = Get-OverlapScore -QueryTerms $queryTerms -DocumentTerms $_.terms
                }
            } |
            Where-Object { $_.score -gt 0.0 } |
            Sort-Object @{ Expression = 'score'; Descending = $true }, @{ Expression = { $_.document.source }; Descending = $false } |
            Select-Object -First 3
    )
    $candidates = @()
    foreach ($match in $ranked) {
        $scene = @($match.document.scenes)[0]
        $candidates += [ordered]@{
            scene = [ordered]@{
                source = [string]$scene.source
                start = [double]$scene.start
                end = [double]$scene.end
            }
            score = [math]::Round([double]$match.score, 6)
        }
    }
    $queryResults += [ordered]@{
        sentence = $sentence
        status = 'searched'
        usable_in_top3 = $candidates.Count -gt 0
        top_candidates = $candidates
    }
}

$outputDirectory = Split-Path -Parent $outputPathFull
New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
$payload = [ordered]@{ schema_version = 1; queries = $queryResults }
[IO.File]::WriteAllText($outputPathFull, ($payload | ConvertTo-Json -Depth 12), $utf8)
[pscustomobject]@{ query_count = 8; output_path = $outputPathFull }
