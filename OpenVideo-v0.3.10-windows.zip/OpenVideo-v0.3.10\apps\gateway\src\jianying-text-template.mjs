/** Shared Jianying text_template resolution for overlay, clone, and recipes. */

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

const textMaterialBuckets = Object.freeze(['texts', 'text_templates'])

/** @param {unknown} value */
export const isJianyingTextMaterialContent = (value) => typeof value === 'string' || record(value)

/** @param {Record<string, any>} material */
export const jianyingTextMaterialContentString = (material) => {
  if (typeof material.content === 'string') return material.content
  if (record(material.content)) return JSON.stringify(material.content)
  return null
}

/** A flower card whose visible copy lives on nested texts, not this id. */
export const isJianyingTextTemplateMaterial = (material) =>
  record(material) &&
  (material.type === 'text_template' || Array.isArray(material.text_info_resources))

/** @param {Record<string, any>} materials @param {unknown} materialId */
export const locateJianyingMaterialById = (materials, materialId) => {
  if (!record(materials) || typeof materialId !== 'string' || !materialId) return null
  const preferred = textMaterialBuckets
    .map((arrayName) => ({
      arrayName,
      entry: Array.isArray(materials[arrayName])
        ? materials[arrayName].find((candidate) => record(candidate) && candidate.id === materialId)
        : null,
    }))
    .find(({ entry }) => entry)
  if (preferred) return preferred
  return Object.entries(materials)
    .filter(([, entries]) => Array.isArray(entries))
    .map(([arrayName, entries]) => ({
      arrayName,
      entry: entries.find((candidate) => record(candidate) && candidate.id === materialId),
    }))
    .find(({ entry }) => entry) ?? null
}

/** Collect every nested `text_material_id` on a text_template (and future sibling fields). */
export const collectJianyingNestedTextMaterialIds = (material) => {
  /** @type {string[]} */
  const ids = []
  const seen = new Set()
  const visit = (/** @type {unknown} */ value) => {
    if (Array.isArray(value)) {
      for (const entry of value) visit(entry)
      return
    }
    if (!record(value)) return
    if (typeof value.text_material_id === 'string' && value.text_material_id && !seen.has(value.text_material_id)) {
      seen.add(value.text_material_id)
      ids.push(value.text_material_id)
    }
    for (const entry of Object.values(value)) visit(entry)
  }
  visit(material)
  return ids
}

/**
 * Resolve the editable text materials for one flower/caption slot.
 * Plain texts keep their own content. text_template cards follow nested
 * `text_material_id` fields, then any extra refs that already resolve to texts.
 * @param {Record<string, any>} materials
 * @param {unknown} materialId
 * @param {unknown[]} [extraIds]
 */
export const resolveJianyingEditableTextMaterials = (materials, materialId, extraIds = []) => {
  const located = locateJianyingMaterialById(materials, materialId)
  if (!located) return []
  if (isJianyingTextMaterialContent(located.entry.content)) return [located.entry]
  const nestedIds = [
    ...collectJianyingNestedTextMaterialIds(located.entry),
    ...extraIds.filter((id) => typeof id === 'string' && id),
  ]
  const seen = new Set()
  /** @type {Record<string, any>[]} */
  const resolved = []
  for (const id of nestedIds) {
    if (seen.has(id)) continue
    seen.add(id)
    const nested = locateJianyingMaterialById(materials, id)
    if (!nested || !isJianyingTextMaterialContent(nested.entry.content)) continue
    resolved.push(nested.entry)
  }
  return resolved
}
