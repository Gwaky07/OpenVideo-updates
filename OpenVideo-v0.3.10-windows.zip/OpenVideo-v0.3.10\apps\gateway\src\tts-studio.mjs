import { execFile } from 'node:child_process'
import { createHash, randomUUID } from 'node:crypto'
import { createReadStream } from 'node:fs'
import {
  copyFile,
  mkdir,
  readFile,
  rename,
  rm,
  stat,
  writeFile,
} from 'node:fs/promises'
import { basename, extname, isAbsolute, relative, resolve } from 'node:path'
import { promisify } from 'node:util'
import { Readable } from 'node:stream'

import { LocalRuntimeError, pickWindowsAudioFile, securePrivateRuntimeRoot } from './local-runtime.mjs'
import { createRunningHubClient, RunningHubClientError } from './runninghub-client.mjs'
import { createPreviewMediaResponse } from './workbench-preview.mjs'

const execFileAsync = promisify(execFile)
const schemaVersion = 1
const profilePrefix = 'rh_'
const audioExtensions = new Set(['.aac', '.flac', '.m4a', '.mp3', '.ogg', '.wav'])
const maxReferenceBytes = 10 * 1024 * 1024
const maxSegments = 100
const idPattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,179}$/u
const shaPattern = /^[a-f0-9]{64}$/u

/**
 * @typedef {{
 *   id: string,
 *   label: string,
 *   authorizationId: string,
 *   referenceLabel: string,
 *   consentConfirmedAt: string,
 *   createdAt: string,
 *   updatedAt: string,
 * }} TtsProfileRecord
 * @typedef {{
 *   sentenceId: string,
 *   textHash: string,
 *   status: 'pending'|'submitted'|'succeeded'|'failed'|'cancelled',
 *   remoteTaskId: string|null,
 *   attempts: number,
 *   relativePath: string|null,
 *   sha256: string|null,
 *   errorCode: string|null,
 * }} TtsSegmentRecord
 * @typedef {{
 *   assetId: string,
 *   projectId: string,
 *   profileId: string,
 *   rate: number,
 *   settingsRevision: string,
 *   inputFingerprint: string,
 *   status: 'pending'|'running'|'succeeded'|'failed'|'cancelled',
 *   segments: TtsSegmentRecord[],
 *   narrationRelativePath: string|null,
 *   narrationSha256: string|null,
 *   createdAt: string,
 *   updatedAt: string,
 * }} TtsAssetRecord
 * @typedef {{schema_version: number, records: TtsProfileRecord[]}} TtsProfileStore
 * @typedef {{schema_version: number, records: TtsAssetRecord[]}} TtsAssetStore
 * @typedef {{projectId: string, voiceId: string, rate: number, segments: Array<{sentenceId: string, text: string}>, signal?: AbortSignal, onProgress?: (progress: {completed: number, total: number}) => unknown, onRemoteStatus?: (status: {sentenceId: string, status: string}) => unknown}} TtsBundleInput
 */

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const identifier = (value) => typeof value === 'string' && idPattern.test(value)
/** @param {unknown} value @param {number} max */
const safeLabel = (value, max) =>
  typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max &&
  !/[\u0000-\u001f\u007f]/u.test(value)

/** @param {unknown} value */
export const toPublicVoiceReferenceLabel = (value) => {
  if (value == null) return null
  if (typeof value !== 'string') return null
  // Legacy profiles stored `已授权参考音频（.m4a）`; strip the leading dot so
  // `/api/workbench/voices` does not trip WORKBENCH_RESPONSE_UNSAFE.
  const normalized = value.replace(/（\.(aac|flac|m4a|mp3|ogg|wav)）/giu, '（$1）')
  return safeLabel(normalized, 100) ? normalized : null
}

/** @param {string} value */
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
/** @param {string} path */
const sha256File = async (path) => {
  const buffer = await readFile(path)
  return createHash('sha256').update(buffer).digest('hex')
}
/** @param {string} parent @param {string} child */
const inside = (parent, child) => {
  const value = relative(parent, child)
  return value === '' || (!value.startsWith('..') && !isAbsolute(value))
}
/** @param {unknown} value */
export const isRunningHubVoiceId = (value) =>
  typeof value === 'string' && /^rh_[a-f0-9]{24}$/u.test(value)

export class TtsStudioError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'TtsStudioError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value @returns {value is TtsProfileRecord} */
const validProfile = (value) => isRecord(value) &&
  isRunningHubVoiceId(value.id) &&
  safeLabel(value.label, 80) &&
  identifier(value.authorizationId) &&
  safeLabel(value.referenceLabel, 100) &&
  typeof value.consentConfirmedAt === 'string' &&
  typeof value.createdAt === 'string' &&
  typeof value.updatedAt === 'string'

/** @param {unknown} value @returns {value is TtsSegmentRecord} */
const validSegmentRecord = (value) => isRecord(value) &&
  identifier(value.sentenceId) &&
  typeof value.textHash === 'string' && shaPattern.test(value.textHash) &&
  ['pending', 'submitted', 'succeeded', 'failed', 'cancelled'].includes(value.status) &&
  (value.remoteTaskId === null || identifier(value.remoteTaskId)) &&
  Number.isSafeInteger(value.attempts) && value.attempts >= 0 &&
  (value.relativePath === null || (typeof value.relativePath === 'string' && !isAbsolute(value.relativePath))) &&
  (value.sha256 === null || (typeof value.sha256 === 'string' && shaPattern.test(value.sha256))) &&
  (value.errorCode === null || safeLabel(value.errorCode, 120))

/** @param {unknown} value @returns {value is TtsAssetRecord} */
const validAsset = (value) => isRecord(value) &&
  identifier(value.assetId) &&
  identifier(value.projectId) &&
  isRunningHubVoiceId(value.profileId) &&
  Number.isInteger(value.rate) && value.rate >= -100 && value.rate <= 100 &&
  typeof value.settingsRevision === 'string' && value.settingsRevision.length <= 128 &&
  typeof value.inputFingerprint === 'string' && shaPattern.test(value.inputFingerprint) &&
  ['pending', 'running', 'succeeded', 'failed', 'cancelled'].includes(value.status) &&
  Array.isArray(value.segments) && value.segments.length > 0 && value.segments.length <= maxSegments &&
  value.segments.every(validSegmentRecord) &&
  (value.narrationRelativePath === null ||
    (typeof value.narrationRelativePath === 'string' && !isAbsolute(value.narrationRelativePath))) &&
  (value.narrationSha256 === null ||
    (typeof value.narrationSha256 === 'string' && shaPattern.test(value.narrationSha256))) &&
  (value.status !== 'succeeded' ||
    (
      typeof value.narrationRelativePath === 'string' &&
      typeof value.narrationSha256 === 'string' &&
      value.segments.every((segment) =>
        segment.status === 'succeeded' &&
        typeof segment.relativePath === 'string' &&
        typeof segment.sha256 === 'string')
    )) &&
  typeof value.createdAt === 'string' &&
  typeof value.updatedAt === 'string'

/** @param {unknown} error */
const errorCode = (error) => error && typeof error === 'object' && 'code' in error
  ? String(error.code)
  : null

/** @template T @param {string} path @param {(value: unknown) => value is T} validate @returns {Promise<{schema_version: number, records: T[]}>} */
const readStoreFile = async (path, validate) => {
  const document = JSON.parse(await readFile(path, 'utf8'))
  if (
    !isRecord(document) ||
    document.schema_version !== schemaVersion ||
    !Array.isArray(document.records) ||
    !document.records.every(validate)
  ) throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
  return {
    schema_version: schemaVersion,
    records: document.records,
  }
}

/** @param {string} path @param {Record<string, any>} document @param {{preservePrimaryAsBackup?: boolean}} [options] */
async function writeStore(path, document, { preservePrimaryAsBackup = true } = {}) {
  const temporaryPath = `${path}.${randomUUID()}.tmp`
  await writeFile(temporaryPath, `${JSON.stringify(document, null, 2)}\n`, {
    encoding: 'utf8',
    flag: 'wx',
    mode: 0o600,
  })
  try {
    if (preservePrimaryAsBackup) {
      await copyFile(path, `${path}.bak`).catch((error) => {
        if (errorCode(error) !== 'ENOENT') throw error
      })
    }
    await rename(temporaryPath, path)
    await copyFile(path, `${path}.bak`).catch(() => {})
  } finally {
    await rm(temporaryPath, { force: true })
  }
}

/** @template T @param {string} path @param {(value: unknown) => value is T} validate @returns {Promise<{schema_version: number, records: T[]}>} */
const readStore = async (path, validate) => {
  try {
    return await readStoreFile(path, validate)
  } catch (primaryError) {
    try {
      const backup = await readStoreFile(`${path}.bak`, validate)
      await writeStore(path, backup, { preservePrimaryAsBackup: false })
      return backup
    } catch (backupError) {
      if (errorCode(primaryError) === 'ENOENT' && errorCode(backupError) === 'ENOENT') {
        return { schema_version: schemaVersion, records: [] }
      }
      throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
    }
  }
}

/** @param {string} path */
const existingFile = async (path) => {
  const metadata = await stat(path).catch(() => null)
  return Boolean(metadata?.isFile() && metadata.size > 0)
}

/** @param {TtsAssetStore} assets @param {string} assetId */
const requireAssetRecord = (assets, assetId) => {
  const asset = assets.records.find((entry) => entry.assetId === assetId)
  if (!asset) throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
  return asset
}

/** @param {TtsAssetRecord} asset @param {number} index */
const requireSegmentRecord = (asset, index) => {
  const segment = asset.segments[index]
  if (!segment) throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
  return segment
}

/** @param {TtsAssetRecord} asset @param {string} root */
const resolvedBundleSegments = (asset, root) => asset.segments.map((segment) => {
  if (typeof segment.relativePath !== 'string') {
    throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
  }
  return {
    sentenceId: segment.sentenceId,
    audioId: `${asset.assetId}_${segment.sentenceId}`,
    path: resolve(root, segment.relativePath),
  }
})

/** @param {unknown} error */
const normalizedError = (error) => {
  if (error instanceof TtsStudioError) return error
  if (error instanceof RunningHubClientError) return new TtsStudioError(error.code, error.status)
  if (error instanceof LocalRuntimeError) {
    return new TtsStudioError(error.code, error.status)
  }
  if (error && typeof error === 'object' && 'name' in error && error.name === 'AbortError') {
    return new TtsStudioError('TTS_STUDIO_CANCELLED', 409)
  }
  return new TtsStudioError('TTS_STUDIO_SYNTHESIS_FAILED', 502)
}

/** @param {TtsBundleInput} input */
const assertBundleInput = (input) => {
  if (
    !identifier(input?.projectId) ||
    !isRunningHubVoiceId(input?.voiceId) ||
    !Number.isInteger(input?.rate) || input.rate < -100 || input.rate > 100 ||
    !Array.isArray(input?.segments) || input.segments.length === 0 || input.segments.length > maxSegments ||
    input.segments.some((segment) =>
      !isRecord(segment) ||
      !identifier(segment.sentenceId) ||
      typeof segment.text !== 'string' ||
      segment.text.trim().length === 0 ||
      segment.text.length > 20_000)
  ) throw new TtsStudioError('TTS_STUDIO_INPUT_INVALID', 400)
}

/**
 * @param {{
 *   dataRoot: string,
 *   authorizationRepository: {save: Function, get: Function, remove: Function},
 *   settingsService: {readPublic: Function, readPrivate: Function},
 *   ffmpegPath: string,
 *   pickAudioFile?: () => Promise<string>,
 *   resolveAudioPath?: (input: {sessionId: string, nodeId: string}) => string,
 *   securePrivateRoot?: (path: string) => Promise<void>,
 *   clientFactory?: typeof createRunningHubClient,
 *   runFfmpeg?: (args: string[], signal?: AbortSignal) => Promise<void>,
 * }} input
 */
export const createTtsStudio = async ({
  dataRoot,
  authorizationRepository,
  settingsService,
  ffmpegPath,
  pickAudioFile = pickWindowsAudioFile,
  resolveAudioPath,
  securePrivateRoot = securePrivateRuntimeRoot,
  clientFactory = createRunningHubClient,
  runFfmpeg = async (args, signal) => {
    await execFileAsync(ffmpegPath, args, {
      signal,
      timeout: 10 * 60_000,
      windowsHide: true,
      maxBuffer: 4 * 1024 * 1024,
    })
  },
}) => {
  if (
    !isAbsolute(dataRoot) ||
    typeof authorizationRepository?.save !== 'function' ||
    typeof authorizationRepository?.get !== 'function' ||
    typeof authorizationRepository?.remove !== 'function' ||
    typeof settingsService?.readPublic !== 'function' ||
    typeof settingsService?.readPrivate !== 'function' ||
    typeof ffmpegPath !== 'string' || !ffmpegPath
  ) throw new TtsStudioError('TTS_STUDIO_CONFIGURATION_INVALID')
  const root = resolve(dataRoot, 'tts-studio')
  const audioRoot = resolve(root, 'audio')
  const profilesPath = resolve(root, 'profiles.json')
  const assetsPath = resolve(root, 'assets.json')
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRoot(root)
  await mkdir(audioRoot, { recursive: true, mode: 0o700 })
  let storeQueue = Promise.resolve()
  const active = new Map()
  const sampleControllers = new Map()

  /** @template T @param {(stores: {profiles: TtsProfileStore, assets: TtsAssetStore}) => Promise<{value: T, writeProfiles?: boolean, writeAssets?: boolean}> | {value: T, writeProfiles?: boolean, writeAssets?: boolean}} operation @returns {Promise<T>} */
  const withStores = (operation) => {
    const result = storeQueue.then(async () => {
      const stores = {
        profiles: await readStore(profilesPath, validProfile),
        assets: await readStore(assetsPath, validAsset),
      }
      const outcome = await operation(stores)
      if (outcome.writeProfiles) await writeStore(profilesPath, stores.profiles)
      if (outcome.writeAssets) await writeStore(assetsPath, stores.assets)
      return outcome.value
    })
    storeQueue = result.then(() => {}, () => {})
    return result
  }

  /** @param {string} profileId */
  const getProfile = (profileId) => withStores(({ profiles }) => ({
    value: profiles.records.find((profile) => profile.id === profileId) ?? null,
  }))

  /** @param {TtsAssetRecord} asset */
  const publicSampleStatus = (asset) => ({
    schema_version: 1,
    sampleId: asset.assetId,
    profileId: asset.profileId,
    status: asset.status,
    progress: {
      completed: asset.segments.filter((segment) => segment.status === 'succeeded').length,
      total: asset.segments.length,
    },
    errorCode: asset.segments.find((segment) => segment.errorCode)?.errorCode ?? null,
    contentPath: asset.status === 'succeeded'
      ? `/api/tts-studio/samples/${encodeURIComponent(asset.assetId)}/content`
      : null,
  })
  /** @param {string} authorizationId */
  const getAuthorization = async (authorizationId) => {
    const authorization = await authorizationRepository.get(authorizationId)
    if (
      !isRecord(authorization) ||
      authorization.status !== 'authorized' ||
      authorization.purpose !== 'voice_reference' ||
      authorization.projectId !== 'tts-studio' ||
      authorization.readOnly !== true ||
      typeof authorization.sha256 !== 'string' ||
      !shaPattern.test(authorization.sha256) ||
      typeof authorization.absolutePath !== 'string' ||
      !isAbsolute(authorization.absolutePath)
    ) throw new TtsStudioError('TTS_STUDIO_REFERENCE_AUDIO_UNAVAILABLE', 409)
    const extension = extname(authorization.absolutePath).toLowerCase()
    const metadata = await stat(authorization.absolutePath).catch(() => null)
    if (
      !audioExtensions.has(extension) ||
      !metadata?.isFile() ||
      metadata.size <= 0 ||
      metadata.size > maxReferenceBytes
    ) throw new TtsStudioError('TTS_STUDIO_REFERENCE_AUDIO_CHANGED', 409)
    const currentSha256 = await sha256File(authorization.absolutePath).catch(() => null)
    if (currentSha256 !== authorization.sha256) {
      throw new TtsStudioError('TTS_STUDIO_REFERENCE_AUDIO_CHANGED', 409)
    }
    return authorization
  }

  /** @param {{cancel: Function}} client @param {TtsSegmentRecord[]} segments */
  const cancelRemoteSegments = async (client, segments) => {
    const entries = await Promise.all(segments
      .filter((segment) => segment.remoteTaskId && segment.status === 'submitted')
      .map(async (segment) => /** @type {[string, boolean]} */ ([
        /** @type {string} */ (segment.remoteTaskId),
        await client.cancel(/** @type {string} */ (segment.remoteTaskId)) === true,
      ])))
    return new Map(entries)
  }

  /** @param {string} sourcePath @param {string} outputPath @param {number} rate @param {AbortSignal | undefined} signal */
  const normalizeAudio = async (sourcePath, outputPath, rate, signal) => {
    const temporaryPath = `${outputPath}.${randomUUID()}.tmp.wav`
    const speed = Math.max(0.5, Math.min(2, 1 + rate / 100))
    try {
      await runFfmpeg([
        '-hide_banner', '-loglevel', 'error', '-y',
        '-i', sourcePath,
        '-vn', '-ac', '1', '-ar', '44100',
        ...(speed === 1 ? [] : ['-af', `atempo=${speed.toFixed(3)}`]),
        '-c:a', 'pcm_s16le',
        temporaryPath,
      ], signal)
      if (!await existingFile(temporaryPath)) throw new TtsStudioError('TTS_STUDIO_AUDIO_NORMALIZATION_FAILED')
      await rename(temporaryPath, outputPath)
    } catch (error) {
      throw normalizedError(error)
    } finally {
      await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }

  /** @param {string[]} paths @param {string} outputPath @param {AbortSignal | undefined} signal */
  const combineAudio = async (paths, outputPath, signal) => {
    if (paths.length === 1) {
      await copyFile(paths[0], outputPath)
      return
    }
    const temporaryPath = `${outputPath}.${randomUUID()}.tmp.wav`
    const labels = paths.map((_, index) => `[${index}:a]`).join('')
    try {
      await runFfmpeg([
        '-hide_banner', '-loglevel', 'error', '-y',
        ...paths.flatMap((path) => ['-i', path]),
        '-filter_complex', `${labels}concat=n=${paths.length}:v=0:a=1[outa]`,
        '-map', '[outa]', '-c:a', 'pcm_s16le', temporaryPath,
      ], signal)
      if (!await existingFile(temporaryPath)) throw new TtsStudioError('TTS_STUDIO_AUDIO_COMBINE_FAILED')
      await rename(temporaryPath, outputPath)
    } catch (error) {
      throw normalizedError(error)
    } finally {
      await rm(temporaryPath, { force: true }).catch(() => {})
    }
  }

  /** @param {TtsBundleInput} input */
  const prepareBundle = async (input) => {
    const profile = await getProfile(input.voiceId)
    if (!profile) throw new TtsStudioError('TTS_STUDIO_PROFILE_NOT_FOUND', 404)
    const authorization = await getAuthorization(profile.authorizationId)
    const settings = await settingsService.readPrivate()
    const fingerprintInput = {
      projectId: input.projectId,
      profileId: profile.id,
      settingsRevision: settings.revision,
      rate: input.rate,
      segments: input.segments.map((segment) => ({
        sentenceId: segment.sentenceId,
        textHash: sha256(segment.text),
      })),
    }
    const inputFingerprint = sha256(JSON.stringify(fingerprintInput))
    const assetId = `tts_${inputFingerprint.slice(0, 32)}`
    const assetRoot = resolve(audioRoot, assetId)
    if (!inside(audioRoot, assetRoot)) throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
    return {
      profile,
      authorization,
      settings,
      client: clientFactory({ settings }),
      inputFingerprint,
      assetId,
      assetRoot,
    }
  }

  /** @param {Awaited<ReturnType<typeof prepareBundle>>} prepared @param {TtsBundleInput} input */
  const ensureAssetRecord = async (prepared, input) => {
    await mkdir(prepared.assetRoot, { recursive: true, mode: 0o700 })
    const createdAt = new Date().toISOString()
    return withStores(({ profiles, assets }) => {
      const existing = assets.records.find((entry) => entry.assetId === prepared.assetId)
      if (existing) return { value: existing }
      /** @type {TtsAssetRecord} */
      const record = {
        assetId: prepared.assetId,
        projectId: input.projectId,
        profileId: prepared.profile.id,
        rate: input.rate,
        settingsRevision: prepared.settings.revision ?? 'unversioned',
        inputFingerprint: prepared.inputFingerprint,
        status: 'pending',
        segments: input.segments.map((segment) => ({
          sentenceId: segment.sentenceId,
          textHash: sha256(segment.text),
          status: 'pending',
          remoteTaskId: null,
          attempts: 0,
          relativePath: null,
          sha256: null,
          errorCode: null,
        })),
        narrationRelativePath: null,
        narrationSha256: null,
        createdAt,
        updatedAt: createdAt,
      }
      assets.records.push(record)
      return { value: record, writeAssets: true }
    })
  }

  /** @param {TtsBundleInput} input */
  const resolveBundleInternal = async (input) => {
    const prepared = await prepareBundle(input)
    const { profile, authorization, client, assetId, assetRoot } = prepared
    /** @type {TtsAssetRecord} */
    let asset = await ensureAssetRecord(prepared, input)
    const narrationPath = resolve(assetRoot, 'narration.wav')
    if (
      asset.status === 'succeeded' &&
      asset.narrationRelativePath &&
      await existingFile(narrationPath) &&
      await sha256File(narrationPath) === asset.narrationSha256
    ) {
      return {
        assetId,
        profileId: profile.id,
        narrationPath,
        segments: resolvedBundleSegments(asset, root),
      }
    }
    await withStores(({ profiles, assets }) => {
      const stored = requireAssetRecord(assets, assetId)
      stored.status = 'running'
      stored.updatedAt = new Date().toISOString()
      asset = stored
      return { value: null, writeAssets: true }
    })
    let reference = null
    try {
      for (const [index, segmentInput] of input.segments.entries()) {
        input.signal?.throwIfAborted()
        let segment = requireSegmentRecord(asset, index)
        const outputPath = resolve(assetRoot, `${String(index + 1).padStart(3, '0')}-${segment.sentenceId}.wav`)
        if (
          segment.status === 'succeeded' &&
          segment.relativePath &&
          await existingFile(outputPath) &&
          await sha256File(outputPath) === segment.sha256
        ) {
          input.onProgress?.({ completed: index + 1, total: input.segments.length })
          continue
        }
        if (!segment.remoteTaskId || segment.status === 'failed' || segment.status === 'cancelled') {
          reference ??= await client.uploadReference(authorization.absolutePath, input.signal)
          const submitted = await client.submitSynthesis({
            text: segmentInput.text,
            reference,
            voiceId: `ov_${sha256(profile.id).slice(0, 24)}`,
            signal: input.signal,
          })
          await withStores(({ profiles, assets }) => {
            const stored = requireAssetRecord(assets, assetId)
            segment = requireSegmentRecord(stored, index)
            segment.status = 'submitted'
            segment.remoteTaskId = submitted.taskId
            segment.attempts += 1
            segment.errorCode = null
            stored.updatedAt = new Date().toISOString()
            asset = stored
            return { value: null, writeAssets: true }
          })
        }
        if (!segment.remoteTaskId) throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
        const remote = await client.waitForResult(segment.remoteTaskId, {
          signal: input.signal,
          onStatus: (status) => input.onRemoteStatus?.({
            sentenceId: segment.sentenceId,
            status,
          }),
        })
        const downloadedPath = resolve(assetRoot, `${String(index + 1).padStart(3, '0')}.remote`)
        await rm(downloadedPath, { force: true }).catch(() => {})
        try {
          await client.download(remote.url, downloadedPath, input.signal)
          await normalizeAudio(downloadedPath, outputPath, input.rate, input.signal)
        } finally {
          await rm(downloadedPath, { force: true }).catch(() => {})
        }
        const outputSha = await sha256File(outputPath)
        await withStores(({ profiles, assets }) => {
          const stored = requireAssetRecord(assets, assetId)
          segment = requireSegmentRecord(stored, index)
          segment.status = 'succeeded'
          segment.relativePath = relative(root, outputPath)
          segment.sha256 = outputSha
          segment.errorCode = null
          stored.updatedAt = new Date().toISOString()
          asset = stored
          return { value: null, writeAssets: true }
        })
        input.onProgress?.({ completed: index + 1, total: input.segments.length })
      }
      const segmentPaths = asset.segments.map((/** @type {TtsSegmentRecord} */ segment) => {
        if (typeof segment.relativePath !== 'string') {
          throw new TtsStudioError('TTS_STUDIO_STORAGE_INVALID')
        }
        return resolve(root, segment.relativePath)
      })
      await rm(narrationPath, { force: true }).catch(() => {})
      await combineAudio(segmentPaths, narrationPath, input.signal)
      const narrationSha = await sha256File(narrationPath)
      await withStores(({ profiles, assets }) => {
        const stored = requireAssetRecord(assets, assetId)
        stored.status = 'succeeded'
        stored.narrationRelativePath = relative(root, narrationPath)
        stored.narrationSha256 = narrationSha
        stored.updatedAt = new Date().toISOString()
        asset = stored
        return { value: null, writeAssets: true }
      })
      return {
        assetId,
        profileId: profile.id,
        narrationPath,
        segments: resolvedBundleSegments(asset, root),
      }
    } catch (error) {
      const normalized = normalizedError(error)
      const remoteCancellation = await cancelRemoteSegments(client, asset.segments)
      const terminalRemoteFailure = new Set([
        'RUNNINGHUB_AUDIO_OUTPUT_MISSING',
        'RUNNINGHUB_AUDIO_OUTPUT_TOO_LARGE',
        'RUNNINGHUB_DOWNLOAD_FAILED',
        'RUNNINGHUB_OUTPUT_URL_INVALID',
        'RUNNINGHUB_TASK_FAILED',
      ]).has(normalized.code)
      await withStores(({ profiles, assets }) => {
        const stored = requireAssetRecord(assets, assetId)
        stored.status = input.signal?.aborted ? 'cancelled' : 'failed'
        for (const segment of stored.segments) {
          if (segment.status === 'succeeded') continue
          const cancelled = segment.remoteTaskId
            ? remoteCancellation.get(segment.remoteTaskId) === true
            : false
          if (input.signal?.aborted) segment.status = 'cancelled'
          else if (segment.status !== 'submitted' || cancelled || terminalRemoteFailure) {
            segment.status = 'failed'
          }
          segment.errorCode = normalized.code
        }
        stored.updatedAt = new Date().toISOString()
        return { value: null, writeAssets: true }
      })
      throw normalized
    }
  }

  /** @param {TtsBundleInput} input */
  const resolveBundle = (input) => {
    assertBundleInput(input)
    const key = sha256(JSON.stringify({
      projectId: input.projectId,
      voiceId: input.voiceId,
      rate: input.rate,
      segments: input.segments,
    }))
    const existing = active.get(key)
    if (existing) return existing
    const operation = resolveBundleInternal(input).finally(() => active.delete(key))
    active.set(key, operation)
    return operation
  }

  /** @param {string} assetId @param {TtsBundleInput} input */
  const launchSample = (assetId, input) => {
    const existing = sampleControllers.get(assetId)
    if (existing) return existing.operation
    const controller = new AbortController()
    const operation = resolveBundle({ ...input, signal: controller.signal })
    sampleControllers.set(assetId, { controller, operation })
    void operation.catch(() => {}).finally(() => sampleControllers.delete(assetId))
    return operation
  }

  return {
    async getStatus() {
      const settings = await settingsService.readPublic()
      return {
        schema_version: 1,
        provider: 'runninghub',
        configured: settings.configured === true,
        mode: settings.mode,
        modelId: settings.modelId,
        workflowId: settings.workflowId,
        sharedAudioAssets: true,
      }
    },
    async listProfiles() {
      return withStores(({ profiles, assets }) => ({
        value: profiles.records.map((profile) => ({
          id: profile.id,
          label: profile.label,
          gender: 'custom',
          locale: 'zh-CN',
          source: 'runninghub',
          kind: 'cloned',
          referenceLabel: toPublicVoiceReferenceLabel(profile.referenceLabel),
          consentConfirmedAt: profile.consentConfirmedAt,
          ready: true,
        })),
      }))
    },
    /** @param {string} profileId */
    async isProfileReady(profileId) {
      if (!isRunningHubVoiceId(profileId)) return false
      const profile = await getProfile(profileId)
      if (!profile) return false
      try {
        await settingsService.readPrivate()
        await getAuthorization(profile.authorizationId)
        return true
      } catch {
        return false
      }
    },
    /** @param {{label: string, consentConfirmed: boolean, readOnlyConfirmed: boolean, sessionId?: string, nodeId?: string, absolutePath?: string}} input */
    async createProfile(input) {
      if (
        !safeLabel(input?.label, 80) ||
        input.consentConfirmed !== true ||
        input.readOnlyConfirmed !== true
      ) throw new TtsStudioError('TTS_STUDIO_PROFILE_INPUT_INVALID', 400)
      try {
        await settingsService.readPrivate()
      } catch (error) {
        throw new TtsStudioError(
          error && typeof error === 'object' && 'code' in error
            ? String(error.code)
            : 'RUNNINGHUB_CONFIGURATION_REQUIRED',
          error && typeof error === 'object' && 'status' in error &&
            typeof error.status === 'number' && Number.isInteger(error.status)
            ? error.status
            : 409,
        )
      }
      let absolutePath
      if (typeof input.absolutePath === 'string' && isAbsolute(input.absolutePath)) {
        absolutePath = resolve(input.absolutePath)
      } else if (
        typeof resolveAudioPath === 'function' &&
        typeof input.sessionId === 'string' &&
        typeof input.nodeId === 'string'
      ) {
        try {
          absolutePath = resolveAudioPath({
            sessionId: input.sessionId,
            nodeId: input.nodeId,
          })
        } catch (error) {
          throw new TtsStudioError(
            error && typeof error === 'object' && 'code' in error
              ? String(error.code)
              : 'TTS_STUDIO_REFERENCE_AUDIO_INVALID',
            error && typeof error === 'object' && 'status' in error &&
              typeof error.status === 'number' && Number.isInteger(error.status)
              ? error.status
              : 400,
          )
        }
      } else {
        try {
          absolutePath = await pickAudioFile()
        } catch (error) {
          throw normalizedError(error)
        }
      }
      if (!isAbsolute(absolutePath) || !audioExtensions.has(extname(absolutePath).toLowerCase())) {
        throw new TtsStudioError('TTS_STUDIO_REFERENCE_AUDIO_INVALID', 400)
      }
      const metadata = await stat(absolutePath).catch(() => null)
      if (!metadata?.isFile() || metadata.size <= 0 || metadata.size > maxReferenceBytes) {
        throw new TtsStudioError('TTS_STUDIO_REFERENCE_AUDIO_INVALID', 400)
      }
      const authorizationId = randomUUID()
      const now = new Date().toISOString()
      // Public DTO must not embed `.m4a`/`.wav` etc.; the response safety gate
      // treats media extensions as private leakage even inside ordinary labels.
      const extensionName = extname(absolutePath).toLowerCase().replace(/^\./u, '') || 'audio'
      const referenceLabel = `已授权参考音频（${extensionName}）`
      await authorizationRepository.save({
        id: authorizationId,
        projectId: 'tts-studio',
        absolutePath: resolve(absolutePath),
        label: referenceLabel,
        purpose: 'voice_reference',
        sha256: await sha256File(absolutePath),
        status: 'authorized',
        total: 1,
        readOnly: true,
        createdAt: now,
      })
      /** @type {TtsProfileRecord} */
      const profile = {
        id: `${profilePrefix}${randomUUID().replaceAll('-', '').slice(0, 24)}`,
        label: input.label.trim(),
        authorizationId,
        referenceLabel,
        consentConfirmedAt: now,
        createdAt: now,
        updatedAt: now,
      }
      try {
        await withStores(({ profiles, assets }) => {
          profiles.records.push(profile)
          return { value: null, writeProfiles: true }
        })
      } catch (error) {
        await Promise.resolve(authorizationRepository.remove(authorizationId)).catch(() => {})
        throw error
      }
      return {
        id: profile.id,
        label: profile.label,
        gender: 'custom',
        locale: 'zh-CN',
        source: 'runninghub',
        kind: 'cloned',
        referenceLabel: profile.referenceLabel,
        consentConfirmedAt: profile.consentConfirmedAt,
        ready: true,
      }
    },
    /** @param {string} profileId */
    async deleteProfile(profileId) {
      if (!isRunningHubVoiceId(profileId)) return false
      const removed = await withStores(({ profiles, assets }) => {
        const index = profiles.records.findIndex((profile) => profile.id === profileId)
        if (index < 0) return { value: null }
        if (assets.records.some((asset) =>
          asset.profileId === profileId && ['pending', 'running'].includes(asset.status))) {
          throw new TtsStudioError('TTS_STUDIO_PROFILE_BUSY', 409)
        }
        const [profile] = profiles.records.splice(index, 1)
        const removedAssets = assets.records.filter((asset) => asset.profileId === profileId)
        assets.records = assets.records.filter((asset) => asset.profileId !== profileId)
        return {
          value: { profile, removedAssets },
          writeProfiles: true,
          writeAssets: removedAssets.length > 0,
        }
      })
      if (!removed) return false
      await authorizationRepository.remove(removed.profile.authorizationId)
      await Promise.all(removed.removedAssets.map((/** @type {TtsAssetRecord} */ asset) =>
        rm(resolve(audioRoot, asset.assetId), { recursive: true, force: true })))
      return true
    },
    resolveBundle,
    /**
     * Resolve an opaque audio token to a private absolute path within this project.
     * Accepts single-segment bare assetId or `${assetId}_${sentenceId}`.
     * @param {string | {audioToken: string, projectId?: string}} input
     * @returns {Promise<string | null>}
     */
    async resolveAudioToken(input) {
      const audioToken = typeof input === 'string' ? input : input?.audioToken
      const projectId = typeof input === 'string' ? null : input?.projectId ?? null
      if (!identifier(audioToken)) return null
      if (projectId !== null && !identifier(projectId)) return null
      const asset = await withStores(({ assets }) => {
        const candidates = assets.records.filter((entry) =>
          projectId === null || entry.projectId === projectId,
        )
        const exact = candidates.find((entry) => entry.assetId === audioToken)
        if (exact) return { value: exact }
        const prefixed = candidates.find((entry) =>
          entry.segments.some((segment) => `${entry.assetId}_${segment.sentenceId}` === audioToken),
        )
        return { value: prefixed ?? null }
      })
      if (!asset || asset.status !== 'succeeded' || !Array.isArray(asset.segments) || asset.segments.length === 0) {
        return null
      }
      if (projectId !== null && asset.projectId !== projectId) return null
      /** @type {string | null} */
      let relativePath = null
      if (asset.assetId === audioToken) {
        if (asset.segments.length !== 1) return null
        relativePath = asset.segments[0].relativePath
      } else {
        const segment = asset.segments.find(
          (/** @type {TtsSegmentRecord} */ entry) =>
            `${asset.assetId}_${entry.sentenceId}` === audioToken,
        )
        relativePath = segment?.relativePath ?? null
      }
      if (typeof relativePath !== 'string') return null
      const absolute = resolve(audioRoot, relativePath)
      if (!inside(audioRoot, absolute)) return null
      return absolute
    },
    /** @param {{projectId: string, voiceId: string, rate: number, text: string}} input */
    async startSample(input) {
      const bundleInput = {
        projectId: input.projectId,
        voiceId: input.voiceId,
        rate: input.rate,
        segments: [{ sentenceId: 'sample', text: input.text }],
      }
      assertBundleInput(bundleInput)
      const prepared = await prepareBundle(bundleInput)
      let asset = await ensureAssetRecord(prepared, bundleInput)
      if (asset.status !== 'succeeded') {
        asset = await withStores(({ profiles, assets }) => {
          const stored = requireAssetRecord(assets, prepared.assetId)
          stored.status = 'running'
          stored.updatedAt = new Date().toISOString()
          return { value: stored, writeAssets: true }
        })
        launchSample(prepared.assetId, bundleInput)
      }
      return publicSampleStatus(asset)
    },
    /** @param {string} assetId */
    async getSampleStatus(assetId) {
      if (!identifier(assetId)) return null
      let asset = await withStores(({ profiles, assets }) => ({
        value: assets.records.find((entry) => entry.assetId === assetId) ?? null,
      }))
      if (asset && ['pending', 'running'].includes(asset.status) && !sampleControllers.has(assetId)) {
        let client = null
        try {
          client = clientFactory({ settings: await settingsService.readPrivate() })
        } catch {
          client = null
        }
        const remoteCancellation = client
          ? await cancelRemoteSegments(client, asset.segments)
          : new Map()
        asset = await withStores(({ profiles, assets }) => {
          const stored = requireAssetRecord(assets, assetId)
          stored.status = 'failed'
          for (const segment of stored.segments) {
            if (segment.status === 'pending') segment.status = 'failed'
            if (
              segment.status === 'submitted' &&
              segment.remoteTaskId &&
              remoteCancellation.get(segment.remoteTaskId) === true
            ) segment.status = 'failed'
            if (segment.status !== 'succeeded') {
              segment.errorCode = 'TTS_STUDIO_RESTART_RETRY_REQUIRED'
            }
          }
          stored.updatedAt = new Date().toISOString()
          return { value: stored, writeAssets: true }
        })
      }
      return asset ? publicSampleStatus(asset) : null
    },
    /** @param {string} assetId */
    async cancelSample(assetId) {
      if (!identifier(assetId)) return false
      const running = sampleControllers.get(assetId)
      if (running) {
        running.controller.abort()
        await running.operation.catch(() => {})
        return true
      }
      const asset = await withStores(({ profiles, assets }) => ({
        value: assets.records.find((entry) => entry.assetId === assetId) ?? null,
      }))
      if (!asset || !['pending', 'running'].includes(asset.status)) return false
      const client = clientFactory({ settings: await settingsService.readPrivate() })
      await Promise.all(asset.segments
        .filter((/** @type {TtsSegmentRecord} */ segment) => segment.remoteTaskId && segment.status === 'submitted')
        .map((/** @type {TtsSegmentRecord} */ segment) => client.cancel(/** @type {string} */ (segment.remoteTaskId))))
      await withStores(({ profiles, assets }) => {
        const stored = requireAssetRecord(assets, assetId)
        stored.status = 'cancelled'
        for (const segment of stored.segments) {
          if (['pending', 'submitted'].includes(segment.status)) {
            segment.status = 'cancelled'
            segment.errorCode = 'TTS_STUDIO_CANCELLED'
          }
        }
        stored.updatedAt = new Date().toISOString()
        return { value: null, writeAssets: true }
      })
      return true
    },
    /** @param {string} assetId */
    async getSampleResource(assetId) {
      if (!identifier(assetId)) return null
      const asset = await withStores(({ profiles, assets }) => ({
        value: assets.records.find((entry) => entry.assetId === assetId) ?? null,
      }))
      if (!asset || asset.status !== 'succeeded' || !asset.narrationRelativePath) return null
      const path = resolve(root, asset.narrationRelativePath)
      if (!inside(root, path) || !await existingFile(path)) return null
      const metadata = await stat(path)
      return {
        contentType: 'audio/wav',
        etag: JSON.stringify(asset.narrationSha256),
        size: metadata.size,
        createStream: ({ start = 0, end = metadata.size - 1 } = {}) =>
          /** @type {ReadableStream<any>} */ (
            /** @type {unknown} */ (Readable.toWeb(createReadStream(path, { start, end })))
          ),
      }
    },
  }
}

/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) => isRecord(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} body @param {number} [status] */
const jsonResponse = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  },
})

/** @param {{studio: Awaited<ReturnType<typeof createTtsStudio>>}} input */
export const createTtsStudioHandler = ({ studio }) => async (/** @type {Request} */ request) => {
  const pathname = new URL(request.url).pathname
  try {
    if (pathname === '/api/tts-studio/status' && request.method === 'GET') {
      return jsonResponse(await studio.getStatus())
    }
    if (pathname === '/api/tts-studio/profiles' && request.method === 'GET') {
      return jsonResponse({ schema_version: 1, profiles: await studio.listProfiles() })
    }
    if (pathname === '/api/tts-studio/profiles' && request.method === 'POST') {
      const body = await request.json()
      if (
        !exactKeys(body, ['consentConfirmed', 'label', 'readOnlyConfirmed']) &&
        !exactKeys(body, ['consentConfirmed', 'label', 'nodeId', 'readOnlyConfirmed', 'sessionId'])
      ) {
        throw new TtsStudioError('TTS_STUDIO_PROFILE_INPUT_INVALID', 400)
      }
      return jsonResponse(await studio.createProfile(body), 201)
    }
    const profileMatch = pathname.match(/^\/api\/tts-studio\/profiles\/([^/]+)$/u)
    if (profileMatch && request.method === 'DELETE') {
      const deleted = await studio.deleteProfile(decodeURIComponent(profileMatch[1]))
      return deleted
        ? jsonResponse({ schema_version: 1, deleted: true })
        : jsonResponse({ error: { code: 'TTS_STUDIO_PROFILE_NOT_FOUND', message: 'Voice profile not found.' } }, 404)
    }
    if (pathname === '/api/tts-studio/samples' && request.method === 'POST') {
      const body = await request.json()
      if (!exactKeys(body, ['projectId', 'rate', 'text', 'voiceId'])) {
        throw new TtsStudioError('TTS_STUDIO_INPUT_INVALID', 400)
      }
      return jsonResponse(await studio.startSample(body), 202)
    }
    const sampleStatusMatch = pathname.match(/^\/api\/tts-studio\/samples\/([^/]+)$/u)
    if (sampleStatusMatch && request.method === 'GET') {
      const status = await studio.getSampleStatus(decodeURIComponent(sampleStatusMatch[1]))
      return status
        ? jsonResponse(status)
        : jsonResponse({ error: { code: 'TTS_STUDIO_SAMPLE_NOT_FOUND', message: 'Voice sample not found.' } }, 404)
    }
    if (sampleStatusMatch && request.method === 'DELETE') {
      const cancelled = await studio.cancelSample(decodeURIComponent(sampleStatusMatch[1]))
      return cancelled
        ? jsonResponse({ schema_version: 1, cancelled: true }, 202)
        : jsonResponse({ error: { code: 'TTS_STUDIO_SAMPLE_NOT_CANCELLABLE', message: 'Voice sample is not cancellable.' } }, 409)
    }
    const sampleMatch = pathname.match(/^\/api\/tts-studio\/samples\/([^/]+)\/content$/u)
    if (sampleMatch && ['GET', 'HEAD'].includes(request.method)) {
      const resource = await studio.getSampleResource(decodeURIComponent(sampleMatch[1]))
      if (!resource) {
        return jsonResponse({ error: { code: 'TTS_STUDIO_SAMPLE_NOT_FOUND', message: 'Voice sample not found.' } }, 404)
      }
      return createPreviewMediaResponse({
        resource,
        rangeHeader: request.headers.get('range'),
        method: request.method,
      })
    }
    return jsonResponse({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' } }, 405)
  } catch (error) {
    const normalized = normalizedError(error)
    return jsonResponse({
      error: {
        code: normalized.code,
        message: 'TTS Studio operation failed safely.',
      },
    }, normalized.status)
  }
}
