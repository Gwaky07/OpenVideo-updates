import { createJianyingDesktopBinding } from './jianying-packaging-resource-index.mjs'
import { createProviderAssistedCatalogIntake } from './jianying-provider-assisted-catalog.mjs'
import { createProviderAssistedCatalogService } from './jianying-provider-assisted-catalog-service.mjs'

const providerIds = new Set(['user_draft', 'duo_video_probe'])
const profilePattern = /^jianying-[a-z0-9-]{1,80}$/u
const versionPattern = /^\d{1,3}(?:\.\d{1,8}){1,4}$/u
const fingerprintPattern = /^[a-f0-9]{64}$/u
const draftAuthorizationPattern = /^ovauth_[A-Za-z0-9_-]{8,160}$/u
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 503) => {
  const error = /** @type {Error & {code?: string, status?: number}} */ (new Error(code))
  error.code = code
  error.status = status
  throw error
}

/** @param {unknown} providerId @returns {string} */
const assertProviderId = (providerId) => {
  if (typeof providerId !== 'string' || !providerIds.has(providerId)) fail('NATIVE016_PROVIDER_UNAVAILABLE', 503)
  return providerId
}

/**
 * Build the only server-owned route from a provider label to NATIVE-015.
 * Provider adapters receive the detected desktop context and private runtime
 * state only; no browser payload is forwarded to them.
 *
 * @param {{detectDesktop: Function, providers?: Record<string, any>, persist: Function}} options
 */
export const createServerOwnedProviderCatalogInvocation = ({ detectDesktop, providers = {}, persist }) => {
  if (typeof detectDesktop !== 'function' || !isRecord(providers) || typeof persist !== 'function') {
    fail('NATIVE016_DEPENDENCIES_INVALID', 500)
  }
  return Object.freeze({
    /** @param {{providerId: unknown, draftAuthorizationId?: unknown}} request */
    invoke: async ({ providerId: rawProviderId, draftAuthorizationId: rawDraftAuthorizationId = undefined }) => {
      const providerId = assertProviderId(rawProviderId)
      const draftAuthorizationId = rawDraftAuthorizationId === undefined || rawDraftAuthorizationId === null
        ? null
        : typeof rawDraftAuthorizationId === 'string' && draftAuthorizationPattern.test(rawDraftAuthorizationId)
          ? rawDraftAuthorizationId
          : fail('NATIVE017_DRAFT_AUTHORIZATION_INVALID', 400)
      if (providerId === 'user_draft' && draftAuthorizationId === null) fail('NATIVE017_DRAFT_AUTHORIZATION_REQUIRED', 400)
      if (providerId === 'duo_video_probe' && draftAuthorizationId !== null) fail('NATIVE017_DRAFT_AUTHORIZATION_INVALID', 400)
      const provider = providers[providerId]
      if (!isRecord(provider) || typeof provider.prepare !== 'function') fail('NATIVE016_PROVIDER_UNAVAILABLE', 503)
      /** @type {Record<string, any> | null} */
      let desktop = null
      try { desktop = await detectDesktop() } catch { fail('NATIVE016_DESKTOP_UNAVAILABLE', 503) }
      if (!isRecord(desktop) || desktop.available !== true || !profilePattern.test(desktop.profileId ?? '') || !versionPattern.test(desktop.version ?? '')) {
        fail('NATIVE016_DESKTOP_UNAVAILABLE', 503)
      }
      /** @type {any} */
      let binding = null
      try {
        binding = createJianyingDesktopBinding({
          profileId: desktop.profileId,
          version: desktop.version,
          executablePath: desktop.executablePath,
          installRoot: desktop.installRoot,
          dllFingerprint: desktop.dllFingerprint,
        })
      } catch { fail('NATIVE016_DESKTOP_BINDING_UNAVAILABLE', 503) }
      /** @type {Record<string, any> | null} */
      let prepared = null
      try { prepared = await provider.prepare({ desktop: { ...desktop, binding }, draftAuthorizationId }) } catch (error) {
        const candidate = /** @type {{code?: unknown, status?: unknown}} */ (error)
        const code = typeof candidate?.code === 'string' && /^NATIVE017_[A-Z_]+$/u.test(candidate.code) ? candidate.code : null
        if (code) fail(code, typeof candidate.status === 'number' ? candidate.status : 503)
        fail('NATIVE016_PROVIDER_PREPARE_FAILED', 503)
      }
      if (!isRecord(prepared) || typeof prepared.catalogFingerprint !== 'string' || !fingerprintPattern.test(prepared.catalogFingerprint) || typeof prepared.ingest !== 'function') {
        fail('NATIVE016_PROVIDER_PREPARE_INVALID', 503)
      }
      const intake = createProviderAssistedCatalogIntake({
        providerId,
        profileId: desktop.profileId,
        appVersion: desktop.version,
        desktopBinding: binding,
        catalogFingerprint: prepared.catalogFingerprint,
        assertCurrentDesktop: async () => {
          try {
            const current = await detectDesktop()
            if (!isRecord(current) || current.available !== true || current.profileId !== desktop.profileId || current.version !== desktop.version) return false
            const currentBinding = createJianyingDesktopBinding({
              profileId: current.profileId,
              version: current.version,
              executablePath: current.executablePath,
              installRoot: current.installRoot,
              dllFingerprint: current.dllFingerprint,
            })
            return currentBinding.binding_fingerprint === binding.binding_fingerprint &&
              JSON.stringify(currentBinding) === JSON.stringify(binding)
          } catch { return false }
        },
        ingest: prepared.ingest,
      })
      return createProviderAssistedCatalogService({ intake, persist: /** @type {any} */ (persist) }).ingest({})
    },
  })
}
