import { execFile, spawn } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { createServer } from 'node:http'
import { isAbsolute, join } from 'node:path'
import { once } from 'node:events'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { ShortVideoFactoryError } from './short-video-factory-provider.mjs'

const execFileAsync = promisify(execFile)
/** @param {import('node:http').ServerResponse} response @param {number} status @param {unknown} value */
const json = (response, status, value) => {
  const body = Buffer.from(JSON.stringify(value))
  response.writeHead(status, {
    'cache-control': 'no-store',
    'content-length': String(body.length),
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  })
  response.end(body)
}
/** @param {number} seconds */
const formatSrtTime = (seconds) => {
  const milliseconds = Math.max(0, Math.round(seconds * 1000))
  const hours = Math.floor(milliseconds / 3_600_000)
  const minutes = Math.floor(milliseconds % 3_600_000 / 60_000)
  const secs = Math.floor(milliseconds % 60_000 / 1000)
  const ms = milliseconds % 1000
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')},${String(ms).padStart(3, '0')}`
}
/** @param {string} script */
const sentences = (script) => {
  const values = script.match(/[^。！？!?\n]+[。！？!?]?/gu)?.map((/** @type {string} */ value) => value.trim()).filter(Boolean)
  return values?.length ? values : [script.trim()]
}
/** @param {string} script @param {{start: number, end: number}[]} clips */
const captionsFor = (script, clips) => {
  const values = sentences(script)
  let cursor = 0
  return clips.map((clip, index) => {
    const duration = clip.end - clip.start
    const start = cursor
    cursor += duration
    return `${index + 1}\n${formatSrtTime(start)} --> ${formatSrtTime(cursor)}\n${values[index] ?? values.at(-1)}\n`
  }).join('\n')
}
const emptyCaptions = () => `1\n00:00:00,000 --> 00:00:00,001\n\u200b\n`
/** @param {string | null} value */
const mediaPath = (value) => value === null ? null : value.replaceAll('\\', '/')

/** @param {string} path @param {number} durationSeconds */
const writeSilentWave = async (path, durationSeconds) => {
  const sampleRate = 16_000
  const samples = Math.max(1, Math.ceil(durationSeconds * sampleRate))
  const dataSize = samples * 2
  const output = Buffer.alloc(44 + dataSize)
  output.write('RIFF', 0)
  output.writeUInt32LE(36 + dataSize, 4)
  output.write('WAVE', 8)
  output.write('fmt ', 12)
  output.writeUInt32LE(16, 16)
  output.writeUInt16LE(1, 20)
  output.writeUInt16LE(1, 22)
  output.writeUInt32LE(sampleRate, 24)
  output.writeUInt32LE(sampleRate * 2, 28)
  output.writeUInt16LE(2, 32)
  output.writeUInt16LE(16, 34)
  output.write('data', 36)
  output.writeUInt32LE(dataSize, 40)
  await writeFile(path, output)
}

/** @param {string} token */
const bridgeHtml = (token) => `<!doctype html>
<meta charset="utf-8">
<title>OpenVideo preview bridge</title>
<script>
const endpoint = ${JSON.stringify(token)};
const post = async (name, value) => fetch('/' + name + '/' + endpoint, {
  method: 'POST',
  headers: {'content-type': 'application/json'},
  body: JSON.stringify(value)
});
(async () => {
  let stage = 'request';
  try {
    const request = await fetch('/request/' + endpoint, {cache: 'no-store'}).then((r) => r.json());
    window.electron.winMin();
    window.ipcRenderer.on('render-video-progress', (_event, progress) => {
      post('progress', {progress: Number(progress)}).catch(() => {});
    });
    if (request.tts) {
      stage = 'tts';
      await window.electron.edgeTtsSynthesizeToFile({
        text: request.script,
        voice: request.tts.voice,
        options: {rate: request.tts.rate},
        withCaption: request.captions,
        outputPath: request.voicePath
      });
    }
    stage = 'render';
    await window.electron.renderVideo({
      videoFiles: request.videoFiles,
      timeRanges: request.timeRanges,
      audioFiles: {
        voice: request.voicePath,
        ...(request.bgmPath ? {bgm: request.bgmPath} : {})
      },
      subtitleFile: request.subtitlePath,
      outputSize: request.outputSize,
      outputPath: request.outputPath,
      outputDuration: String(request.outputDurationSeconds)
    });
    await post('result', {ok: true, stage: 'complete'});
  } catch {
    await post('result', {ok: false, stage}).catch(() => {});
  } finally {
    window.electron.winClose();
  }
})();
</script>`

/** @param {NodeJS.ProcessEnv} source @param {Record<string, string>} overrides */
const minimalEnvironment = (source, overrides) => {
  const allowed = [
    'APPDATA',
    'COMSPEC',
    'HOMEDRIVE',
    'HOMEPATH',
    'LOCALAPPDATA',
    'PATH',
    'PATHEXT',
    'PROCESSOR_ARCHITECTURE',
    'SYSTEMDRIVE',
    'SYSTEMROOT',
    'TEMP',
    'TMP',
    'USERPROFILE',
    'WINDIR',
  ]
  return Object.fromEntries([
    ...allowed.filter((key) => source[key]).map((key) => [key, source[key]]),
    ...Object.entries(overrides),
  ])
}

/** @param {import('node:child_process').ChildProcess} child */
const terminateTree = async (child) => {
  if (!child || child.exitCode !== null) return
  child.kill()
  if (process.platform === 'win32' && child.pid) {
    await execFileAsync('taskkill', ['/PID', String(child.pid), '/T', '/F'], {
      windowsHide: true,
      timeout: 10_000,
    }).catch(() => {})
  }
}

/**
 * Invoke the unmodified upstream Electron preload IPC across a child-process boundary.
 * @param {{
 *   request: Record<string, any>,
 *   upstreamRoot: string,
 *   workRoot: string,
 *   outputPath: string,
 *   signal?: AbortSignal,
 *   onProgress?: (progress: number) => void,
 *   onStarted?: () => void | Promise<void>,
 *   timeoutMs?: number,
 *   spawnProcess?: typeof spawn,
 * }} input
 */
export const runShortVideoFactoryElectronBridge = async ({
  request,
  upstreamRoot,
  workRoot,
  outputPath,
  signal,
  onProgress,
  onStarted,
  timeoutMs = 5 * 60_000,
  spawnProcess = spawn,
}) => {
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1) {
    throw new ShortVideoFactoryError('SHORT_VIDEO_FACTORY_BRIDGE_FAILED', 500)
  }
  signal?.throwIfAborted()
  const token = randomBytes(32).toString('hex')
  const externalVoicePath = request.voiceover.enabled && typeof request.voiceover.audioPath === 'string'
    ? request.voiceover.audioPath
    : null
  if (externalVoicePath !== null && !isAbsolute(externalVoicePath)) {
    throw new ShortVideoFactoryError('SHORT_VIDEO_FACTORY_TTS_FAILED', 502)
  }
  const voicePath = externalVoicePath ?? join(
    workRoot,
    request.voiceover.enabled ? 'voice.mp3' : 'silence.wav',
  )
  const subtitlePath = join(
    workRoot,
    request.voiceover.enabled && request.captions.enabled ? 'voice.srt' : 'captions.srt',
  )
  if (!request.voiceover.enabled) {
    await writeSilentWave(voicePath, request.outputDurationSeconds)
  }
  if (externalVoicePath || !request.voiceover.enabled || !request.captions.enabled) {
    await writeFile(
      subtitlePath,
      request.captions.enabled ? captionsFor(request.script, request.clips) : emptyCaptions(),
      'utf8',
    )
  }
  const privateRequest = {
    script: request.script,
    tts: request.voiceover.enabled && !externalVoicePath
      ? { voice: request.voiceover.voice, rate: request.voiceover.rate }
      : null,
    captions: request.captions.enabled,
    voicePath: mediaPath(voicePath),
    subtitlePath: mediaPath(subtitlePath),
    bgmPath: mediaPath(request.bgmPath),
    videoFiles: request.clips.map((/** @type {Record<string, any>} */ clip) => mediaPath(clip.sourcePath)),
    timeRanges: request.clips.map((/** @type {Record<string, any>} */ clip) => [String(clip.start), String(clip.end)]),
    outputSize: request.outputSize,
    outputDurationSeconds: request.outputDurationSeconds,
    outputPath: mediaPath(outputPath),
  }
  const appDataRoot = join(workRoot, 'appdata')
  const roamingRoot = join(appDataRoot, 'roaming')
  const localRoot = join(appDataRoot, 'local')
  const homeRoot = join(appDataRoot, 'home')
  const userDataRoot = join(appDataRoot, 'user-data')
  await Promise.all([
    mkdir(roamingRoot, { recursive: true }),
    mkdir(localRoot, { recursive: true }),
    mkdir(homeRoot, { recursive: true }),
    mkdir(userDataRoot, { recursive: true }),
  ])
  const bootstrapPath = join(workRoot, 'electron-bootstrap.cjs')
  await writeFile(
    bootstrapPath,
    [
      "const { app } = require('electron')",
      "app.on('browser-window-created', (_event, window) => { if (typeof window.setSkipTaskbar === 'function') window.setSkipTaskbar(true) })",
      `app.setPath('userData', ${JSON.stringify(userDataRoot)})`,
      `import(${JSON.stringify(pathToFileURL(join(upstreamRoot, 'dist-electron', 'main.js')).href)}).catch(() => app.exit(1))`,
      '',
    ].join('\n'),
    { encoding: 'utf8', mode: 0o600 },
  )

  let settled = false
  /** @type {(result: {ok: boolean, stage: string}) => void} */
  let resolveResult = () => {}
  /** @type {Promise<{ok: boolean, stage: string}>} */
  const resultPromise = new Promise((resolve) => { resolveResult = resolve })
  const server = createServer(async (incoming, outgoing) => {
    const path = incoming.url ?? ''
    if (incoming.method === 'GET' && path === `/bridge/${token}`) {
      const body = Buffer.from(bridgeHtml(token))
      outgoing.writeHead(200, {
        'cache-control': 'no-store',
        'content-length': String(body.length),
        'content-security-policy': "default-src 'none'; script-src 'unsafe-inline'; connect-src http://127.0.0.1:*",
        'content-type': 'text/html; charset=utf-8',
        'x-content-type-options': 'nosniff',
      })
      outgoing.end(body)
      return
    }
    if (incoming.method === 'GET' && path === `/request/${token}`) {
      json(outgoing, 200, privateRequest)
      return
    }
    if (incoming.method === 'POST' && path === `/progress/${token}`) {
      const chunks = []
      for await (const chunk of incoming) chunks.push(chunk)
      try {
        const value = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        if (Number.isFinite(value.progress)) {
          // The upstream FFmpeg adapter reports elapsed seconds, not a ratio.
          // Convert against the requested output duration before exposing the
          // provider-neutral percentage to the workbench.
          const durationSeconds = Number(privateRequest.outputDurationSeconds)
          const elapsedSeconds = Number(value.progress)
          const percentage = durationSeconds > 0 && elapsedSeconds <= durationSeconds + 0.5
            ? elapsedSeconds / durationSeconds * 100
            : elapsedSeconds
          onProgress?.(Math.max(0, Math.min(99, Math.round(percentage))))
        }
      } catch {}
      json(outgoing, 200, { ok: true })
      return
    }
    if (incoming.method === 'POST' && path === `/result/${token}`) {
      const chunks = []
      for await (const chunk of incoming) chunks.push(chunk)
      let result = { ok: false, stage: 'unknown' }
      try {
        const value = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        result = {
          ok: value.ok === true,
          stage: ['request', 'tts', 'render', 'complete'].includes(value.stage)
            ? value.stage
            : 'unknown',
        }
      } catch {}
      if (!settled) {
        settled = true
        resolveResult(result)
      }
      json(outgoing, 200, { ok: true })
      return
    }
    json(outgoing, 404, { ok: false })
  })

  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const address = server.address()
  if (!address || typeof address === 'string') {
    server.close()
    throw new ShortVideoFactoryError('SHORT_VIDEO_FACTORY_RENDER_FAILED', 502)
  }
  const child = spawnProcess(
    join(upstreamRoot, 'node_modules', 'electron', 'dist', 'electron.exe'),
    [bootstrapPath],
    {
      cwd: upstreamRoot,
      env: minimalEnvironment(process.env, {
        ANALYTICS_IN_DEV: '0',
        APPDATA: roamingRoot,
        HOME: homeRoot,
        LOCALAPPDATA: localRoot,
        TEMP: workRoot,
        TMP: workRoot,
        USERPROFILE: homeRoot,
        VITE_DEV_SERVER_URL: `http://127.0.0.1:${address.port}/bridge/${token}`,
      }),
      stdio: 'ignore',
      windowsHide: true,
    },
  )
  /** @type {(spawned: boolean) => void} */
  let resolveSpawned = () => {}
  /** @type {Promise<boolean>} */
  const spawnedPromise = new Promise((resolve) => { resolveSpawned = resolve })
  child.once('spawn', () => resolveSpawned(true))
  const onAbort = () => {
    resolveSpawned(false)
    if (!settled) {
      settled = true
      resolveResult({ ok: false, stage: 'cancelled' })
    }
    terminateTree(child).catch(() => {})
  }
  signal?.addEventListener('abort', onAbort, { once: true })
  const resultTimer = setTimeout(() => {
    if (!settled) {
      settled = true
      resolveResult({ ok: false, stage: 'timeout' })
    }
  }, timeoutMs)
  child.once('error', () => {
    resolveSpawned(false)
    if (!settled) {
      settled = true
      resolveResult({ ok: false, stage: 'process' })
    }
  })
  child.once('exit', () => {
    resolveSpawned(false)
    if (!settled) {
      settled = true
      resolveResult({ ok: false, stage: 'process' })
    }
  })
  try {
    if (await spawnedPromise) await onStarted?.()
    const result = await resultPromise
    if (!result.ok || signal?.aborted) {
      throw new ShortVideoFactoryError(
        signal?.aborted
          ? 'SHORT_VIDEO_FACTORY_CANCELLED'
          : result.stage === 'tts'
            ? 'SHORT_VIDEO_FACTORY_TTS_FAILED'
            : result.stage === 'render'
              ? 'SHORT_VIDEO_FACTORY_RENDER_FAILED'
              : result.stage === 'timeout'
                ? 'SHORT_VIDEO_FACTORY_TIMED_OUT'
              : result.stage === 'process'
                ? 'SHORT_VIDEO_FACTORY_PROCESS_FAILED'
                : 'SHORT_VIDEO_FACTORY_BRIDGE_FAILED',
        signal?.aborted ? 409 : result.stage === 'timeout' ? 504 : 502,
      )
    }
    onProgress?.(100)
  } finally {
    clearTimeout(resultTimer)
    signal?.removeEventListener('abort', onAbort)
    await terminateTree(child)
    server.close()
    await once(server, 'close').catch(() => {})
  }
}
