import { createHash } from 'node:crypto'

import {
  createReferenceTemplateAdapterRequest,
  createReferenceTemplateDraft,
  isReferenceTemplateAnalysis,
  preflightReferenceTemplateDraft,
} from './reference-template-contracts.mjs'
import {
  createTemplateDraftRequest,
  isTemplateSelectionRequest,
  listFixedTemplates,
  selectFixedTemplate,
} from './template-library.mjs'

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const sha256 = (value) => createHash('sha256').update(JSON.stringify(value)).digest('hex')

export class ReferenceTemplateAdapterError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 503) {
    super(code)
    this.name = 'ReferenceTemplateAdapterError'
    this.code = code
    this.status = status
  }
}

const MIN_TEMPORAL_SLOT_MS = 500

/**
 * When scene detection returns fewer cuts than the fixed template needs,
 * synthesize equal temporal slots across the reference duration so continuous
 * product takes can still produce a reviewable draft.
 * @param {Record<string, any>[]} scenes
 * @param {number} durationMs
 * @param {number} minimum
 */
const ensureSceneCapacity = (scenes, durationMs, minimum) => {
  if (!Array.isArray(scenes) || scenes.length >= minimum) return scenes
  if (
    !Number.isSafeInteger(durationMs) ||
    !Number.isSafeInteger(minimum) ||
    minimum < 1 ||
    durationMs < minimum * MIN_TEMPORAL_SLOT_MS
  ) {
    throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_SCENES_INSUFFICIENT', 409)
  }
  const slotMs = Math.floor(durationMs / minimum)
  return Array.from({ length: minimum }, (_, index) => {
    const startMs = index * slotMs
    const endMs = index === minimum - 1 ? durationMs : (index + 1) * slotMs
    return {
      sceneId: `temporal-slot-${index + 1}`,
      startMs,
      endMs,
    }
  })
}

/** @param {Record<string, any>[]} scenes @param {number} maximum */
const mergeScenes = (scenes, maximum) => {
  const groups = scenes.map((scene) => [scene])
  while (groups.length > maximum) {
    let mergeAt = 0
    let shortest = Number.POSITIVE_INFINITY
    for (let index = 0; index < groups.length - 1; index += 1) {
      const rightEnd = groups[index + 1]?.at(-1)?.endMs
      const leftStart = groups[index]?.[0]?.startMs
      if (typeof rightEnd !== 'number' || typeof leftStart !== 'number') {
        throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_SCENE_INVALID', 502)
      }
      const duration = rightEnd - leftStart
      if (duration < shortest) {
        shortest = duration
        mergeAt = index
      }
    }
    groups.splice(mergeAt, 2, [...groups[mergeAt], ...groups[mergeAt + 1]])
  }
  return groups
}

/** @param {number} index @param {number} length */
const roleFor = (index, length) => {
  if (index === 0) return 'hook'
  if (index === length - 1) return 'cta'
  const middle = ['context', 'detail', 'process', 'proof']
  return middle[Math.min(middle.length - 1, Math.floor((index - 1) * middle.length / Math.max(1, length - 2)))]
}

/** @param {string} transcript @param {number} durationMs @param {boolean} required */
const captionCadence = (transcript, durationMs, required) => {
  const text = transcript.trim()
  // A request for captions is not evidence that captions exist in the source.
  // Empty ASR/OCR evidence must remain unavailable; otherwise a timing-only
  // reference video is incorrectly presented as a learned caption template.
  if (!text) return { mode: 'none', max_chars_per_card: 0, cards_per_minute: 0 }
  const characters = text.length
  const cards = Math.max(1, Math.ceil(characters / 16))
  return {
    mode: characters / Math.max(1, durationMs / 1_000) > 5 ? 'burst' : 'steady',
    max_chars_per_card: 16,
    cards_per_minute: Math.max(1, Math.min(120, Math.round(cards * 60_000 / durationMs))),
  }
}

/**
 * @param {{
 *   materialAnalysisProvider: {inspectReferenceAsset: Function, inspectAuthorizedReferenceFile?: Function},
 * }} [dependencies]
 */
export const createReferenceTemplateAdapter = (dependencies = /** @type {any} */ ({})) => {
  const { materialAnalysisProvider } = dependencies
  if (!materialAnalysisProvider || typeof materialAnalysisProvider.inspectReferenceAsset !== 'function') {
    throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE')
  }
  return {
    /**
     * @param {{projectId: string, authorizationId: string, assetId?: string, referenceAuthorizationId?: string, templateSelectionRequest: unknown, signal?: AbortSignal}} input
     */
    async generate(input) {
      if (
        !isTemplateSelectionRequest(input?.templateSelectionRequest) ||
        input.templateSelectionRequest.project_id !== input.projectId
      ) throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_REQUEST_INVALID', 400)
      if (input.referenceAuthorizationId && typeof materialAnalysisProvider.inspectAuthorizedReferenceFile !== 'function') {
        throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE')
      }
      const inspectAuthorizedReferenceFile =
        materialAnalysisProvider.inspectAuthorizedReferenceFile
      const inspected = input.referenceAuthorizationId
        ? await /** @type {Function} */ (inspectAuthorizedReferenceFile)({
            projectId: input.projectId,
            authorizationId: input.referenceAuthorizationId,
            signal: input.signal,
          })
        : await materialAnalysisProvider.inspectReferenceAsset({
            projectId: input.projectId,
            authorizationId: input.authorizationId,
            assetId: input.assetId,
            signal: input.signal,
          })
      input.signal?.throwIfAborted()
      if (
        !isRecord(inspected) ||
        !/^[A-Za-z0-9][A-Za-z0-9_-]*$/u.test(inspected.referenceId) ||
        !Number.isSafeInteger(inspected.durationMs) ||
        !['portrait', 'landscape', 'square'].includes(inspected.orientation) ||
        !Array.isArray(inspected.scenes) ||
        typeof inspected.transcript !== 'string'
      ) throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_INSPECTION_INVALID', 502)
      // The inspected reference owns its orientation. The requested output
      // duration remains the product decision; source timing is retained in
      // the reference descriptor and analysis rather than rewriting it here.
      const selectionRequest = inspected.orientation === input.templateSelectionRequest.orientation
        ? input.templateSelectionRequest
        : {
            ...clone(input.templateSelectionRequest),
            orientation: inspected.orientation,
          }
      let selection
      try {
        selection = selectFixedTemplate(selectionRequest)
      } catch (error) {
        if (
          error &&
          typeof error === 'object' &&
          /** @type {{code?: unknown}} */ (error).code === 'no_compatible_fixed_template'
        ) {
          throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_NO_COMPATIBLE_FIXED_TEMPLATE', 409)
        }
        throw error
      }
      const fixedDraft = createTemplateDraftRequest(selectionRequest, selection)
      const template = listFixedTemplates().find((entry) =>
        entry.template_id === selection.selected_template.template_id &&
        entry.version === selection.selected_template.version)
      if (!template) throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_SELECTION_INVALID', 500)
      const usableScenes = ensureSceneCapacity(
        clone(inspected.scenes),
        inspected.durationMs,
        template.slot_count.min,
      )
      const groups = mergeScenes(usableScenes, template.slot_count.max)
      const descriptor = {
        schema_version: 1,
        kind: 'reference_video_descriptor',
        reference_id: inspected.referenceId,
        duration_ms: inspected.durationMs,
        orientation: inspected.orientation,
        source_kind: 'external_reference',
        access_mode: 'external_read_only',
        privacy: 'sanitized_metadata_only',
      }
      const adapterRequest = createReferenceTemplateAdapterRequest(
        selectionRequest,
        fixedDraft,
        descriptor,
      )
      const shots = groups.map((group, index) => {
        const first = group[0]
        const last = group.at(-1)
        if (!first || !last) {
          throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_SCENE_INVALID', 502)
        }
        return {
          shot_id: `shot-${sha256(group.map((scene) => scene.sceneId)).slice(0, 20)}`,
          order: index + 1,
          start_ms: first.startMs,
          end_ms: last.endMs,
          role: roleFor(index, groups.length),
          transition_out: index === groups.length - 1 ? 'none' : 'cut',
        }
      })
      const analysis = {
        schema_version: 1,
        kind: 'reference_template_analysis',
        request_id: adapterRequest.request_id,
        reference_id: inspected.referenceId,
        duration_ms: inspected.durationMs,
        orientation: inspected.orientation,
        shots,
        caption_cadence: captionCadence(
          inspected.transcript,
          inspected.durationMs,
          input.templateSelectionRequest.captions_required,
        ),
        audio_emphasis: [],
        evidence_codes: [
          'shot_timing',
          'visual_role',
          'transition_pattern',
          'caption_cadence',
          'audio_emphasis',
        ],
      }
      if (!isReferenceTemplateAnalysis(adapterRequest, analysis)) {
        throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_ANALYSIS_INVALID', 502)
      }
      const draft = createReferenceTemplateDraft(
        selectionRequest,
        adapterRequest,
        analysis,
      )
      const preflight = preflightReferenceTemplateDraft(
        selectionRequest,
        adapterRequest,
        analysis,
        draft,
      )
      if (!preflight.ready) throw new ReferenceTemplateAdapterError('REFERENCE_TEMPLATE_PREFLIGHT_FAILED', 502)
      return {
        templateSelectionRequest: clone(selectionRequest),
        adapterRequest,
        analysis,
        draft,
        preflight,
      }
    },
  }
}
