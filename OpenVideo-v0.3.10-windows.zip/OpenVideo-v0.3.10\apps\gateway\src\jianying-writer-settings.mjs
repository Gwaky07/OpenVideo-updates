const writerStates = new Set(['ready', 'go', 'technical_go', 'deferred', 'unavailable'])

/** @param {unknown} value */
const publicWriter = (value) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const writer = /** @type {Record<string, unknown>} */ (value)
  if (typeof writer.id !== 'string' || !/^[a-z][a-z0-9_-]{2,63}$/u.test(writer.id) ||
      typeof writer.state !== 'string' || !writerStates.has(writer.state) ||
      typeof writer.enabled !== 'boolean' || typeof writer.selected !== 'boolean' ||
      typeof writer.reprobe_allowed !== 'boolean' ||
      !(writer.last_probe === null || (typeof writer.last_probe === 'string' && /^\d{4}-\d{2}-\d{2}$/u.test(writer.last_probe))) ||
      !(writer.reason === null || (typeof writer.reason === 'string' && /^JY200_[A-Z0-9_]+$/u.test(writer.reason)))) return null
  return Object.freeze({
    id: writer.id,
    state: writer.state,
    enabled: writer.enabled,
    selected: writer.selected,
    reprobe_allowed: writer.reprobe_allowed,
    last_probe: writer.last_probe,
    reason: writer.reason,
  })
}

/**
 * Safe settings-only projection. It never exposes commits, paths, resource
 * identities, remote URLs, device data or private evidence fingerprints.
 * @param {{nativeReady: boolean, duoState?: {state?: string, enabled?: boolean, selected?: boolean, reason?: string|null, last_probe?: string|null}}} input
 */
export const createJianyingWriterSettingsSnapshot = ({ nativeReady, duoState = undefined }) => {
  const duoStateName = duoState?.state
  const duo = {
    state: typeof duoStateName === 'string' && ['ready', 'go', 'technical_go'].includes(duoStateName)
      ? duoStateName
      : 'technical_go',
    enabled: duoState?.enabled === true,
    selected: duoState?.selected === true,
    reprobe_allowed: true,
    last_probe: typeof duoState?.last_probe === 'string' ? duoState.last_probe : '2026-08-28',
    reason: duoState?.reason === null
      ? null
      : typeof duoState?.reason === 'string'
        ? duoState.reason
        : 'JY200_RESOURCE_RIGHTS_AND_ADMISSION_PENDING',
  }
  return Object.freeze({
  schema_version: 1,
  selected_writer: duo.selected ? 'duo-video' : (nativeReady ? 'native-writer' : null),
  writers: Object.freeze([
    publicWriter({
      id: 'native-writer',
      state: nativeReady ? 'ready' : 'unavailable',
      enabled: nativeReady,
      selected: nativeReady && !duo.selected,
      reprobe_allowed: false,
      last_probe: null,
      reason: nativeReady ? null : 'JY200_NATIVE_WRITER_UNAVAILABLE',
    }),
    publicWriter({ id: 'duo-video', ...duo }),
    publicWriter({
      id: 'vectcutapi',
      state: 'deferred',
      enabled: false,
      selected: false,
      reprobe_allowed: true,
      last_probe: '2026-08-27',
      reason: 'JY200_VECTCUT_PROVENANCE_AND_ENVIRONMENT_PENDING',
    }),
  ]),
  })
}

/** @param {{read: () => Record<string, unknown> | Promise<Record<string, unknown>>}} input */
export const createJianyingWriterSettingsHandler = ({ read }) => async (/** @type {Request} */ request) => {
  if (request.method !== 'GET') {
    return new Response(JSON.stringify({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Use GET to inspect Writer state.' } }), {
      status: 405,
      headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
    })
  }
  return new Response(JSON.stringify(await read()), {
    status: 200,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  })
}
