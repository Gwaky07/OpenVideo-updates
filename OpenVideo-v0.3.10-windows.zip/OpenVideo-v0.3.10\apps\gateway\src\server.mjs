import { execFile } from 'node:child_process'
import { createHash, createHmac, randomUUID } from 'node:crypto'
import { once } from 'node:events'
import { mkdir, readFile, stat, unlink } from 'node:fs/promises'
import { appendFileSync, createWriteStream, existsSync } from 'node:fs'
import { createServer } from 'node:http'
import { toJianyingPackagingResolution } from './jianying-template-packaging-resolution.mjs'
import { isAbsolute, join, resolve } from 'node:path'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import { loadOptionalGatewayConfig, parseGatewayPort } from './config.mjs'
import { createProductUpdateHandler, createProductUpdateService } from './product-update.mjs'
import { loadCreativeKnowledge } from './creative-knowledge-loader.mjs'
import { createCreativeDecisionTraceRepository } from './creative-decision-trace-repository.mjs'
import { createCreativeShadowPlanner } from './creative-retrieval.mjs'
import { createCreativeTechniquePolicy } from './creative-technique-policy.mjs'
import { allowedCreativeCapabilityIds, createCreativePlanningContext } from './creative-realization-policy.mjs'
import { createEditorCapabilityRegistry } from './editor-capability-registry.mjs'
import { createBgmLibrary, createBgmLibraryHandler, createFfprobeAudioProbe, purgeBgmProjectResiduals } from './bgm-library.mjs'
import { createFfprobeSfxInspector, createSfxCatalog, createSfxCatalogHandler } from './sfx-catalog.mjs'
import { createGeneratedSfxLibrary, generatedSfxProjectId } from './generated-sfx-library.mjs'
import { loadCreativeSfxPromotionProjection } from './creative-sfx-promotion.mjs'
import { isCuratedVoiceId } from './brief-packaging.mjs'
import { createDirector } from './director.mjs'
import { createGateway, GatewayError } from './gateway.mjs'
import { createDirectorHandler, createGatewayHandler, createJianyingDraftHandler, createJianyingDraftMinerHandler, createJianyingNativeEvidencePreflightHandler, createWorkbenchHandler } from './http.mjs'
import { jianyingDraftRuntime } from './jianying-draft-server-runtime.mjs'
import { createJianyingDraftRuntime } from './jianying-draft-runtime.mjs'
import {
  detectJianyingDesktop,
  inspectPyJianyingUpstream,
} from './jianying-local-environment.mjs'
import { createJianyingDesktopLauncher } from './jianying-desktop-launcher.mjs'
import { createJY200DuoCurrentAdmissionResolver, readJY200DuoAdmissionReceipt } from './jianying-duo-current-admission.mjs'
import { fingerprintJY200DuoProductRuntime } from './jianying-duo-direct-probe-evidence.mjs'
import {
  createJY200DuoProbationaryWorkbenchCapability,
  createJY200DuoServerPrivateWriterCapability,
  resolveJY200DuoProbationaryMaterialRequest,
} from './jianying-duo-workbench-server-integration.mjs'
import { createJY200DuoProductRunner } from './jianying-duo-product-runner.mjs'
import { createJianyingWriterPublicationRepository } from './jianying-writer-publication-repository.mjs'
import { createRecoverableJianyingWriterOwnerCapability } from './jianying-writer-owner-capability.mjs'
import { createJianyingWriterSettingsHandler, createJianyingWriterSettingsSnapshot } from './jianying-writer-settings.mjs'
import { createCapCutCatalogHandler, createCapCutCatalogService } from './jianying-capcut-catalog-service.mjs'
import { exactNativeEntry } from './jianying-capcut-packaging-provider.mjs'
import {
  createCapCutCatalogPackagingExportSnapshotResolver,
  createCapCutCatalogPackagingProviderResolver,
  defaultDirectIdProbe,
} from './jianying-capcut-packaging-provider.mjs'
import { createDirectIdResolutionProbe } from './jianying-direct-id-resolution-evidence.mjs'
import {
  createJianyingPrivateResourceCatalogHandler,
  createJianyingPrivateResourceCatalogService,
} from './jianying-private-resource-catalog-service.mjs'
import { createServerOwnedProviderCatalogInvocation } from './jianying-provider-assisted-catalog-invocation.mjs'
import { createUserDraftCatalogProvider } from './jianying-user-draft-provider.mjs'
import {
  createJianyingPrivateDraftDecoder,
  createJianyingPrivateDraftSourceFingerprintValidator,
} from './jianying-private-draft-decoder.mjs'
import { NATIVE018_PRIVATE_DRAFT_CATALOG_FILENAME, persistJianyingPrivateResourceCatalog } from './jianying-private-resource-scanner.mjs'
import {
  createJianyingResourceRootSettingsHandler,
  createJianyingResourceRootSettingsService,
} from './jianying-resource-root-settings.mjs'
import {
  createJianying6RendererSettingsHandler,
  createJianying6RendererSettingsService,
} from './jianying6-renderer-settings.mjs'
import {
  createJianyingDraftDecryptor,
  resolveVideoEditorInstallDir,
} from './jianying-draft-decrypt.mjs'
import { createJianyingVoiceoverProvider } from './jianying-voiceover-provider.mjs'
import { parseJianyingBlendCatalog } from './jianying-blend-catalog.mjs'
import { parseJianyingBackgroundCatalog, parseJianyingBackgroundEvidence } from './jianying-background-catalog.mjs'
import {
  admitJianyingTextPackagingCatalog,
  parseJianyingTextPackagingCatalog,
  parseJianyingTextPackagingEvidence,
  resolveJianyingTextPackagingToken,
} from './jianying-text-packaging-catalog.mjs'
import {
  admitJianyingBatchTextPackagingCatalog,
  intakeJianyingBatchTextPackagingCatalog,
  parseJianyingBatchTextPackagingEvidence,
  resolveJianyingBatchTextPackagingToken,
} from './jianying-batch-text-packaging-catalog.mjs'
import { readFileNoReparse } from './jianying-native-safe-file.mjs'
import { parseJianyingVideoFadeEvidence } from './jianying-video-fade-evidence.mjs'
import { loadJianyingChromaEvidenceCapability } from './jianying-chroma-evidence.mjs'
import { parseJianyingAudioEffectCatalog, parseJianyingAudioEffectEvidence, resolveJianyingAudioEffectToken } from './jianying-audio-effect-catalog.mjs'
import { parseJianyingTextAnimationCatalog, parseJianyingTextAnimationEvidence, resolveJianyingTextAnimationToken } from './jianying-text-animation-catalog.mjs'
import { loadJianyingVideoAnimationCapability, resolveJianyingVideoAnimationToken } from './jianying-video-animation-catalog.mjs'
import { loadJianyingMaskCapability, resolveJianyingMaskToken } from './jianying-mask-catalog.mjs'
import { parseJianyingTextKeyframeEvidence } from './jianying-text-keyframe-evidence.mjs'
import { loadJianyingStickerKeyframeIntegrityKey, verifyJianyingStickerKeyframeEvidence } from './jianying-sticker-keyframe-evidence.mjs'
import { parseJianyingTrackInsertEvidence } from './jianying-track-insert-evidence.mjs'
import { resolvePrivatePackagingResourceToken } from './jianying-packaging-resource-index.mjs'
import { selectWriterEligiblePackagingFamilies } from './jianying-packaging-family-selection.mjs'
import {
  createCapabilityPromotionReceiptsFromAdmittedPackagingIndex,
  loadPackagingResourceEvidenceIntegrityKey,
  loadPackagingResourceIndexForProduction,
} from './jianying-packaging-resource-evidence.mjs'
import { loadJianyingFilterProduction } from './jianying-filter-production.mjs'
import { createJianyingWorkbenchBridge } from './jianying-workbench-bridge.mjs'
import { createLlmSettingsHandler, createLlmSettingsService, LlmSettingsError } from './llm-settings.mjs'
import {
  createOrLoadLocalApiToken,
  isAuthorizedLocalApiWrite,
  isLocalApiWriteRequest,
  localApiSessionCookie,
} from './local-api-token.mjs'
import {
  createBootPrivateRootSecurer,
  createJsonRepositories,
  createLocalAuthorizationCapability,
  isTrustedLocalHttpRequest,
  loadLocalRuntimeConfig,
  LocalRuntimeError,
  pickWindowsFolder,
  warmupWindowsNativePickers,
  ensureWindowsNativePickerHost,
} from './local-runtime.mjs'
import { createLocalPickerHandler, createLocalPickerService, LocalPickerError } from './local-picker.mjs'
import { createEditorMaterialTools } from './editor-material-tools.mjs'
import { createMaterialMediaRequestHandler } from './material-media-http.mjs'
import { createMaterialLibraryService } from './material-library.mjs'
import { applyMaterialReviewOverlayToProvider, createMaterialReviewOverlay } from './material-review-overlay.mjs'
import { createPermissiveMaterialAnalyzer } from './permissive-material-analyzer.mjs'
import { createReferenceTemplateAdapter } from './reference-template-adapter.mjs'
import { createReferenceTemplateRepository } from './reference-template-repository.mjs'
import {
  createReusableTemplateLibraryService,
  createReusableTemplateRepository,
} from './reusable-template-repository.mjs'
import { createJianyingTemplateReader } from './jianying-template-reader.mjs'
import { createTemplateBlueprintStore } from './template-blueprint-store.mjs'
import { createTemplateMediaStore } from './template-media-store.mjs'
import { createTemplateStyleAnalyzer } from './template-style-analyzer.mjs'
import { createTemplateDemoRenderer } from './template-demo-renderer.mjs'
import { createProjectTemplateAbPreviewStore } from './project-template-ab-preview-store.mjs'
import { createWorkbenchJobCoordinator, createWorkbenchPackagingRecommendationProvider } from './workbench-job-coordinator.mjs'
import { createLlmGatewayPackagingRanker } from './jianying-packaging-recommender.mjs'
import {
  createEditPlanRepository,
  createWorkbenchJobRepository,
} from './workbench-job-repository.mjs'
import { createRichTimelineRepository } from './rich-timeline-repository.mjs'
import { createRuntimeDiagnostics, recordSafeWorkbenchDiagnostic } from './runtime-diagnostics.mjs'
import { createSyntheticWorkbenchCapabilities, createWorkbenchRuntime } from './workbench.mjs'
import { createProductionWorkbenchPreflight } from './workbench-preflight.mjs'
import {
  createCandidateClipResourceCache,
  createCandidateClipResourceLoader,
  createEphemeralCandidateClipResource,
  createSyntheticCandidateClipResource,
  createSyntheticCandidatePosterResource,
  createSyntheticPreviewProvider,
} from './workbench-preview.mjs'
import { runShortVideoFactoryElectronBridge } from './short-video-factory-electron-bridge.mjs'
import {
  createShortVideoFactoryProvider,
  ShortVideoFactoryError,
} from './short-video-factory-provider.mjs'
import { createStaticWebHandler } from './static-web.mjs'
import { createRunningHubClient } from './runninghub-client.mjs'
import {
  createRunningHubSettingsHandler,
  createRunningHubSettingsService,
} from './runninghub-settings.mjs'
import {
  createJianyingTtsPresetsHandler,
  createJianyingTtsPresetsService,
} from './jianying-tts-presets.mjs'
import { createJianyingLocalTts } from './jianying-local-tts.mjs'
import { createJianyingPresetNarration } from './jianying-preset-narration.mjs'
import { createJianyingVoiceCatalogHandler, createJianyingVoiceCatalogService } from './jianying-voice-catalog.mjs'
import { isJianyingPresetVoiceId } from './jianying-tts-presets.mjs'
import { createTtsStudio, createTtsStudioHandler } from './tts-studio.mjs'
import { createDraftMinerJobRepository, createDraftMinerJobService } from './jianying-draft-miner-jobs.mjs'
import {
  adoptCurrentNativeEvidenceStartupReceipt,
  createStableNativeEvidenceIdentityReader,
  createNativeEvidenceRefreshGate,
  isNativeEvidencePreflightReceiptCurrent,
  loadNativeEvidencePreflightReceipt,
  publishNativeEvidencePreflightReceipt,
  runNativeEvidenceStartupRecovery,
  runNativeEvidencePreflight,
} from './jianying-native-evidence-preflight.mjs'

/** @typedef {import('./llm-settings.mjs').LlmRuntimeConfig} LlmRuntimeConfig */

const maxRequestBytes = 1_048_576
const maxReferenceUploadBytes = 512 * 1024 * 1024
const execFileAsync = promisify(execFile)
const JY200_PROBATIONARY_ERROR_CODE = /^[A-Z][A-Z0-9_]{2,159}$/u

/**
 * Keep probationary failures machine-readable without reflecting paths,
 * arbitrary status values, or upstream exception text into the public API.
 * @param {unknown} error
 * @returns {{status: number, code: string}}
 */
export const normalizeJY200DuoProbationaryFailure = (error) => {
  const record = error && typeof error === 'object' ? /** @type {Record<string, any>} */ (error) : {}
  const candidateCode = typeof record.code === 'string' && JY200_PROBATIONARY_ERROR_CODE.test(record.code)
    ? record.code
    : typeof record.message === 'string' && JY200_PROBATIONARY_ERROR_CODE.test(record.message)
      ? record.message
      : 'JY200_DUO_PROBATIONARY_FAILED'
  const status = Number.isInteger(record.status) && record.status >= 400 && record.status <= 599
    ? record.status
    : 409
  return Object.freeze({ status, code: candidateCode })
}

// Keep the optional Duo helper scripts outside the Gateway typecheck graph;
// they are runtime assets with their own strict validation and are loaded only
// when a private product admission receipt is present.
const loadDuoRuntimeHelpers = async () => {
  const dynamicImport = Function('specifier', 'return import(specifier)')
  const root = fileURLToPath(new URL('../../..', import.meta.url))
  const installer = await dynamicImport(pathToFileURL(resolve(root, 'scripts', 'Install-JY200DuoWriterRuntime.mjs')).href)
  const probe = await dynamicImport(pathToFileURL(resolve(root, 'scripts', 'Probe-JY200DuoLocalResources.mjs')).href)
  return { inspectJY200DuoInstalledRuntime: installer.inspectJY200DuoInstalledRuntime, runVerifiedJY200DuoRuntime: probe.runVerifiedJY200DuoRuntime, publishJY200DuoExecutionReceipt: probe.publishJY200DuoExecutionReceipt }
}

/**
 * Resolve one execution-scoped provider from the current private catalog.
 * The snapshot is intentionally re-read for every Workbench request so the
 * recommendation path cannot retain a stale catalog or desktop binding.
 * @param {{
 *   snapshotResolver?: (() => Promise<Record<string, any> | null>) | null,
 *   ranker?: ((input: Record<string, any>, options?: {signal?: AbortSignal | null}) => Promise<unknown> | unknown) | null,
 *   qualifyCandidate?: ((input: {entry: Record<string, any>, catalog: Record<string, any>, signal: AbortSignal | null}) => Promise<unknown> | unknown) | null,
 *   qualificationRegistry?: Record<string, any> | null,
 * }} input
 * @returns {() => Promise<{recommend: Function, index: Record<string, any>} | null>}
 */
export const createDynamicJianyingPackagingProviderResolver = ({ snapshotResolver = null, ranker = null, qualifyCandidate = null, qualificationRegistry = null } = {}) => async () => {
  if (typeof snapshotResolver !== 'function') return null
  let snapshot = null
  try { snapshot = await snapshotResolver() } catch { snapshot = null }
  if (
    snapshot?.ready !== true ||
    !snapshot.packagingIndex ||
    typeof snapshot.packagingIndex !== 'object' ||
    Array.isArray(snapshot.packagingIndex) ||
    typeof snapshot.profileId !== 'string' ||
    !/^jianying-[a-z0-9-]{1,60}$/u.test(snapshot.profileId) ||
    typeof snapshot.appVersion !== 'string' ||
    !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(snapshot.appVersion) ||
    typeof snapshot.catalogFingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(snapshot.catalogFingerprint) ||
    snapshot.packagingIndex.profileId !== snapshot.profileId ||
    snapshot.packagingIndex.appVersion !== snapshot.appVersion ||
    snapshot.packagingIndex.catalogFingerprint !== snapshot.catalogFingerprint ||
    snapshot.packagingIndex.catalogRevisionToken !== `ovjcatalog_v1_${snapshot.catalogFingerprint.slice(0, 24)}`
  ) return null
  return createWorkbenchPackagingRecommendationProvider({
    index: snapshot.packagingIndex,
    ranker,
    profileId: snapshot.profileId,
    appVersion: snapshot.appVersion,
    qualifyCandidate,
    qualificationRegistry,
  })
}

/**
 * Media elements regularly cancel metadata and range requests while the user
 * switches stages. That is a normal client-side cancellation, not a gateway
 * failure and must never take the HTTP server down with it.
 * @param {unknown} error
 * @param {import('node:http').IncomingMessage} incoming
 * @param {import('node:http').ServerResponse} outgoing
 */
const isExpectedClientDisconnect = (error, incoming, outgoing) => {
  const code = typeof /** @type {{code?: unknown}} */ (error)?.code === 'string'
    ? /** @type {{code: string}} */ (error).code
    : null
  return Boolean(
    incoming.aborted ||
    incoming.destroyed ||
    outgoing.destroyed ||
    (['ERR_STREAM_PREMATURE_CLOSE', 'ERR_STREAM_UNABLE_TO_PIPE', 'ERR_STREAM_DESTROYED'].includes(code ?? '') &&
      (incoming.complete || outgoing.headersSent)),
  )
}

export const createUnconfiguredGateway = () => ({
  async generate() {
    throw new GatewayError(
      'LLM_CONFIGURATION_REQUIRED',
      'Configure the local LLM Gateway before using AI capabilities.',
      409,
    )
  },
})

/**
 * @param {{
 *   bootId?: string,
 *   llmRevision?: string | null,
 *   getLlmRevision?: (() => string | null | undefined) | null,
 *   releaseRevision?: string | null,
 *   launcherSecret?: string | null,
 *   getStartupState?: (() => {ready: boolean, phase: string, progress: number}) | null,
 * }} [options]
 * @returns {(request: Request) => Promise<Response>}
 */
export const createLivenessHandler = ({
  bootId = randomUUID(),
  llmRevision = null,
  getLlmRevision = null,
  releaseRevision = null,
  launcherSecret = null,
  getStartupState = null,
} = {}) => async (request) => {
  if (!['GET', 'HEAD'].includes(request.method)) {
    return new Response(JSON.stringify({
      error: { code: 'METHOD_NOT_ALLOWED', message: 'Method not allowed.' },
    }), {
      status: 405,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    })
  }
  const activeLlmRevision = typeof getLlmRevision === 'function'
    ? getLlmRevision()
    : llmRevision
  const startup = typeof getStartupState === 'function'
    ? getStartupState()
    : { ready: true, phase: 'ready', progress: 100 }
  const payload = {
    live: true,
    ready: startup.ready === true,
    mode: 'production',
    bootId,
    llmRevision: activeLlmRevision,
    startup: {
      phase: String(startup.phase || 'starting'),
      progress: Math.max(0, Math.min(100, Math.round(startup.progress))),
    },
    ...(releaseRevision ? { releaseRevision } : {}),
  }
  const headers = /** @type {Record<string, string>} */ ({
    'cache-control': 'no-store',
    'content-type': 'application/json; charset=utf-8',
    'x-content-type-options': 'nosniff',
  })
  const launcherNonce = request.headers.get('x-openvideo-launcher-nonce')
  const launcherKey = launcherSecret && /^[A-Za-z0-9+/]{43}=$/u.test(launcherSecret)
    ? Buffer.from(launcherSecret, 'base64')
    : null
  if (
    launcherKey?.length === 32 &&
    launcherNonce &&
    /^[0-9a-f]{64}$/u.test(launcherNonce)
  ) {
    headers['x-openvideo-launcher-proof'] = createHmac('sha256', launcherKey)
      .update(launcherNonce, 'utf8')
      .digest('hex')
  }
  return new Response(
    request.method === 'HEAD'
      ? null
      : JSON.stringify(payload),
    {
      status: 200,
      headers,
    },
  )
}

/**
 * @param {{
 *   syntheticWorkbench: boolean,
 *   llmGatewayReady?: boolean,
 *   materialAnalysisReady?: boolean,
 *   previewProviderReady?: boolean,
 *   jianyingDraftReady?: boolean,
 *   referenceTemplatesReady?: boolean,
 *   reusableTemplatesReady?: boolean,
 *   workbenchRecoveryReady?: boolean,
 *   materialAnalysisProvider?: {getStatus?: Function},
 *   previewProvider?: {getStatus?: Function},
 *   jianyingDraftCapability?: object,
 *   referenceTemplateRepository?: object,
 *   reusableTemplateLibraryService?: object,
 * }} input
 */
export const createProductionReadiness = ({
  syntheticWorkbench,
  llmGatewayReady,
  materialAnalysisReady,
  previewProviderReady,
  jianyingDraftReady,
  referenceTemplatesReady,
  reusableTemplatesReady,
  workbenchRecoveryReady,
  materialAnalysisProvider,
  previewProvider,
  jianyingDraftCapability,
  referenceTemplateRepository,
  reusableTemplateLibraryService,
}) => {
  const capabilities = {
    llm_gateway: !syntheticWorkbench && llmGatewayReady === true,
    material_analysis: materialAnalysisReady ??
      (materialAnalysisProvider?.getStatus?.()?.available === true),
    preview_and_final: previewProviderReady ??
      (previewProvider?.getStatus?.()?.available === true),
    jianying_draft: jianyingDraftReady ?? Boolean(jianyingDraftCapability),
    reference_templates: referenceTemplatesReady ?? Boolean(referenceTemplateRepository),
    reusable_templates: reusableTemplatesReady ?? Boolean(reusableTemplateLibraryService),
    ...(workbenchRecoveryReady === undefined
      ? {}
      : { workbench_recovery: workbenchRecoveryReady === true }),
  }
  return {
    ready: Object.values(capabilities).every(Boolean),
    mode: syntheticWorkbench ? 'synthetic' : 'production',
    capabilities,
  }
}

/** @param {ReturnType<typeof createProductionReadiness> | (() => ReturnType<typeof createProductionReadiness> | Promise<ReturnType<typeof createProductionReadiness>>)} readinessSource */
export const createReadinessHandler = (readinessSource) =>
  /** @param {Request} request */
  async (request) => {
    if (!['GET', 'HEAD'].includes(request.method)) {
      return new Response(JSON.stringify({ error: { code: 'METHOD_NOT_ALLOWED' } }), {
        status: 405,
        headers: {
          allow: 'GET, HEAD',
          'content-type': 'application/json; charset=utf-8',
          'x-content-type-options': 'nosniff',
        },
      })
    }
    let readiness
    try {
      readiness = typeof readinessSource === 'function'
        ? await readinessSource()
        : readinessSource
    } catch {
      readiness = {
        ready: false,
        mode: 'production',
        capabilities: {
          llm_gateway: false,
          material_analysis: false,
          preview_and_final: false,
          jianying_draft: false,
          reference_templates: false,
          reusable_templates: false,
        },
      }
    }
    return new Response(
      request.method === 'HEAD' ? null : JSON.stringify(readiness),
      {
        status: readiness.ready ? 200 : 503,
        headers: {
          'cache-control': 'no-store',
          'content-type': 'application/json; charset=utf-8',
          'x-content-type-options': 'nosniff',
        },
      },
    )
  }

/**
 * @param {() => Promise<ReturnType<typeof createProductionReadiness>>} evaluate
 * @param {{ttlMs?: number, failedTtlMs?: number, now?: () => number}} [options]
 */
export const createCachedReadinessSource = (
  evaluate,
  { ttlMs = 15_000, failedTtlMs = 1_000, now = Date.now } = {},
) => {
  /** @type {ReturnType<typeof createProductionReadiness> | undefined} */
  let cached
  let expiresAt = 0
  /** @type {Promise<ReturnType<typeof createProductionReadiness>> | undefined} */
  let inFlight
  return async () => {
    if (cached && now() < expiresAt) return cached
    if (!inFlight) {
      inFlight = evaluate()
        .then((readiness) => {
          cached = readiness
          // A positive result can be shared briefly. A failed probe must be
          // refreshed on the next check so a recovered upstream is not shown
          // as unavailable for the successful-result cache duration.
          expiresAt = now() + (readiness.ready === false ? failedTtlMs : ttlMs)
          return readiness
        })
        .finally(() => {
          inFlight = undefined
        })
    }
    return inFlight
  }
}

/**
 * Bound one readiness dependency so an unavailable provider cannot hang the
 * aggregate `/api/ready` response or trigger a launcher restart.
 * @param {{timeoutMs?: number}} [options]
 */
// The launcher and release gate both use a strict 15-second request budget.
// Leave one second for HTTP serialization/cancellation so a single dependency
// cannot turn readiness into an unbounded (or late) success claim.
const strictReadinessDependencyDeadlineMs = 14_000

export const createBoundedReadinessProbe = ({ timeoutMs = strictReadinessDependencyDeadlineMs } = {}) => {
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > strictReadinessDependencyDeadlineMs) {
    throw new Error('READINESS_PROBE_TIMEOUT_INVALID')
  }
  return async (/** @type {() => Promise<unknown> | unknown} */ operation) => {
    if (typeof operation !== 'function') return false
    let timer = null
    try {
      const result = await Promise.race([
        Promise.resolve().then(operation),
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error('READINESS_PROBE_TIMEOUT')), timeoutMs)
        }),
      ])
      // Most readiness probes are void and resolve `undefined` on success.
      // A boolean probe, such as the LLM connectivity check, uses explicit
      // `false` to report an unavailable dependency and must remain fail
      // closed rather than becoming healthy merely because it resolved.
      return result !== false
    } catch {
      return false
    } finally {
      if (timer) clearTimeout(timer)
    }
  }
}

const llmReadinessAttemptTimeoutMs = 12_000
const llmReadinessSuccessTtlMs = 5 * 60_000
const llmReadinessGraceMs = 15 * 60_000
const llmReadinessRetryDelayMs = 250
const transientLlmReadinessCodes = new Set([
  'REQUEST_CANCELLED',
  'REQUEST_TIMEOUT',
  'UPSTREAM_UNAVAILABLE',
  'RATE_LIMITED',
])

/**
 * Probe provider reachability and credentials without consuming a completion
 * slot. Structured generation is verified separately by the settings test and
 * remains fail-closed in every production request.
 * @param {{baseUrl: string, credential: string}} config
 * @param {typeof fetch} [fetchImpl]
 */
export const createOpenAiCompatibleReadinessProbe = (
  config,
  fetchImpl = globalThis.fetch.bind(globalThis),
) => async (/** @type {{signal: AbortSignal}} */ { signal }) => {
  let response
  try {
    response = await fetchImpl(`${config.baseUrl}/models`, {
      method: 'GET',
      headers: { authorization: `Bearer ${config.credential}` },
      signal,
    })
  } catch (error) {
    const code = signal.aborted || (error instanceof Error && error.name === 'TimeoutError')
      ? 'REQUEST_TIMEOUT'
      : 'UPSTREAM_UNAVAILABLE'
    throw new GatewayError(code, 'The LLM provider readiness check failed.')
  }
  response.body?.cancel().catch(() => {})
  if (response.ok) return true
  const code = response.status === 401 || response.status === 403
    ? 'PROVIDER_AUTH_FAILED'
    : response.status === 408
      ? 'REQUEST_TIMEOUT'
      : response.status === 429
        ? 'RATE_LIMITED'
        : response.status >= 500
          ? 'UPSTREAM_UNAVAILABLE'
          : 'UPSTREAM_REJECTED'
  throw new GatewayError(code, 'The LLM provider readiness check failed.')
}

/**
 * Keep LLM health checks independent from production generation traffic and
 * tolerate only a short, previously-healthy upstream interruption. Permanent
 * configuration/authentication failures still fail closed immediately.
 * @param {{
 *   generate?: (request: any, options: {signal: AbortSignal}) => Promise<Record<string, any>>,
 *   probe?: (input: {signal: AbortSignal}) => Promise<boolean>,
 *   workbenchMode?: string,
 *   logger?: (event: Record<string, unknown>) => void,
 *   now?: () => number,
 *   attempts?: number,
 *   attemptTimeoutMs?: number,
 *   successTtlMs?: number,
 *   graceMs?: number,
 *   retryDelayMs?: number,
 *   sleep?: (milliseconds: number) => Promise<void>,
 * }} input
 */
export const createLlmReadinessProbe = ({
  generate,
  probe,
  workbenchMode = 'production',
  logger = () => {},
  now = Date.now,
  attempts = 2,
  attemptTimeoutMs = llmReadinessAttemptTimeoutMs,
  successTtlMs = llmReadinessSuccessTtlMs,
  graceMs = llmReadinessGraceMs,
  retryDelayMs = llmReadinessRetryDelayMs,
  sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)),
}) => {
  if ((typeof generate !== 'function' && typeof probe !== 'function') || !Number.isSafeInteger(attempts) || attempts < 1 || attempts > 3 ||
      !Number.isSafeInteger(attemptTimeoutMs) || attemptTimeoutMs < 1 || attemptTimeoutMs > strictReadinessDependencyDeadlineMs - 1_000 ||
      !Number.isSafeInteger(successTtlMs) || successTtlMs < 0 || successTtlMs > 15 * 60_000 ||
      !Number.isSafeInteger(graceMs) || graceMs < 0 || graceMs > 15 * 60_000 ||
      !Number.isSafeInteger(retryDelayMs) || retryDelayMs < 0 || retryDelayMs > 1_000 ||
      typeof now !== 'function' || typeof sleep !== 'function') {
    throw new Error('LLM_READINESS_PROBE_CONFIG_INVALID')
  }
  /** @type {number | null} */
  let lastSuccessAt = null

  return async () => {
    if (workbenchMode === 'synthetic') return false
    if (successTtlMs > 0 && lastSuccessAt !== null && now() - lastSuccessAt <= successTtlMs) return true
    let lastCode = 'LLM_GATEWAY_UNAVAILABLE'
    let transientFailure = false
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      const controller = new AbortController()
      const timeout = setTimeout(() => controller.abort(), attemptTimeoutMs)
      try {
        const result = typeof probe === 'function'
          ? await probe({ signal: controller.signal })
          : typeof generate === 'function'
            ? await generate({
              // Basic text connectivity must not depend on optional JSON-schema
              // support from an OpenAI-compatible provider.
              capability: 'text',
              messages: [{
                role: 'user',
                parts: [{ type: 'text', text: 'Reply with a short connectivity confirmation.' }],
              }],
            }, { signal: controller.signal })
            : false
        let probeSucceeded = result !== false
        if (typeof probe !== 'function' && probeSucceeded) {
          probeSucceeded = typeof result === 'object'
            && result !== null
            && result.capability === 'text'
            && typeof result.outputText === 'string'
            && Boolean(result.outputText.trim())
        }
        if (probeSucceeded) {
          lastSuccessAt = now()
          return true
        }
        lastCode = 'LLM_GATEWAY_RESPONSE_INVALID'
        transientFailure = false
        break
      } catch (error) {
        const reportedCode = error && typeof error === 'object' && 'code' in error
          ? String(error.code)
          : 'LLM_GATEWAY_UNAVAILABLE'
        // This controller is owned by the health probe. Its cancellation means
        // the provider attempt timed out, not that a user cancelled a job.
        lastCode = controller.signal.aborted ? 'REQUEST_TIMEOUT' : reportedCode
        transientFailure = transientLlmReadinessCodes.has(lastCode)
        if (attempt < attempts && transientFailure) await sleep(retryDelayMs)
        else break
      } finally {
        clearTimeout(timeout)
      }
    }

    const withinGrace = transientFailure && lastSuccessAt !== null && now() - lastSuccessAt <= graceMs
    logger({
      event: withinGrace ? 'llm_gateway_readiness_degraded' : 'llm_gateway_readiness_blocked',
      code: lastCode,
    })
    return withinGrace
  }
}

// External desktop discovery must be bounded so a stalled process cannot block the whole local
// workbench. The fallback remains unavailable and fail-closed; it never fabricates a writer.
const jianyingStartupCapabilityDeadlineMs = 45_000

/** @template T @param {Promise<T>} capabilityPromise @param {{timeoutMs?: number}} [options] */
export const awaitBoundedJianyingStartupCapability = async (
  capabilityPromise,
  { timeoutMs = jianyingStartupCapabilityDeadlineMs } = {},
) => {
  if (!capabilityPromise || typeof capabilityPromise.then !== 'function') {
    throw new Error('JY_STARTUP_CAPABILITY_PROMISE_INVALID')
  }
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0 || timeoutMs > jianyingStartupCapabilityDeadlineMs) {
    throw new Error('JY_STARTUP_CAPABILITY_TIMEOUT_INVALID')
  }
  let timer
  try {
    return await Promise.race([
      capabilityPromise,
      new Promise((resolve) => {
        timer = setTimeout(
          () => resolve({ capability: undefined, error: null, timedOut: true }),
          timeoutMs,
        )
      }),
    ])
  } finally {
    if (timer) clearTimeout(timer)
  }
}

class WorkbenchJobConfigError extends Error {
  constructor() {
    super('WORKBENCH_JOB_CONFIG_INVALID')
    this.name = 'WorkbenchJobConfigError'
    this.code = 'WORKBENCH_JOB_CONFIG_INVALID'
  }
}

/**
 * @param {string | undefined} value
 * @param {number} fallback
 * @param {number} minimum
 * @param {number} maximum
 */
const boundedInteger = (value, fallback, minimum, maximum) => {
  if (value === undefined || value === '') return fallback
  if (!/^\d+$/u.test(value)) throw new WorkbenchJobConfigError()
  const parsed = Number(value)
  if (!Number.isSafeInteger(parsed) || parsed < minimum || parsed > maximum) {
    throw new WorkbenchJobConfigError()
  }
  return parsed
}

/** @param {string | undefined} value @param {number} fallback @param {number} minimum @param {number} maximum */
const boundedSignedInteger = (value, fallback, minimum, maximum) => {
  if (value === undefined || value === '') return fallback
  if (!/^-?\d+$/u.test(value)) throw new WorkbenchJobConfigError()
  const parsed = Number(value)
  if (!Number.isSafeInteger(parsed) || parsed < minimum || parsed > maximum) {
    throw new WorkbenchJobConfigError()
  }
  return parsed
}

/** @param {NodeJS.ProcessEnv | Record<string, string | undefined>} [environment] */
export const loadWorkbenchJobConfig = (environment = process.env) => {
  const concurrency = boundedInteger(
    environment.OPENVIDEO_WORKBENCH_JOB_CONCURRENCY,
    2,
    1,
    32,
  )
  const leaseDurationMs = boundedInteger(
    environment.OPENVIDEO_WORKBENCH_JOB_LEASE_MS,
    30_000,
    1_000,
    24 * 60 * 60_000,
  )
  const heartbeatIntervalMs = boundedInteger(
    environment.OPENVIDEO_WORKBENCH_JOB_HEARTBEAT_MS,
    10_000,
    100,
    60 * 60_000,
  )
  const jobTimeoutMs = boundedInteger(
    environment.OPENVIDEO_WORKBENCH_JOB_TIMEOUT_MS,
    30 * 60_000,
    1_000,
    24 * 60 * 60_000,
  )
  if (heartbeatIntervalMs >= leaseDurationMs) throw new WorkbenchJobConfigError()
  return { concurrency, leaseDurationMs, heartbeatIntervalMs, jobTimeoutMs }
}

/** @param {unknown} value @returns {'off' | 'shadow' | 'active'} */
export const parseCreativePlanningMode = (value) => {
  const normalized = typeof value === 'string' ? value.trim().toLowerCase() : ''
  return normalized === 'shadow' || normalized === 'active' ? normalized : 'off'
}

/** @param {unknown} value @param {'off' | 'shadow' | 'active'} planningMode */
export const parseCreativeAutoOutputs = (value, planningMode) => {
  const normalized = typeof value === 'string' ? value.trim().toLowerCase() : ''
  return normalized === 'on' && planningMode === 'active'
}

/** @param {unknown} value @returns {'off' | 'shadow' | 'active'} */
export const parseCreativeTechniqueMode = (value) => {
  const normalized = typeof value === 'string' ? value.trim().toLowerCase() : ''
  return normalized === 'shadow' || normalized === 'active' ? normalized : 'off'
}

/** @param {unknown} value @returns {'off' | 'shadow' | 'active'} */
export const parseCreativeAudioCueMode = (value) => parseCreativeTechniqueMode(value)

/** @param {NodeJS.ProcessEnv | Record<string, string | undefined>} environment */
export const resolveCreativePlanningConfig = (environment) => {
  const planningModeValue = environment.OPENVIDEO_CREATIVE_PLANNING_MODE?.trim().toLowerCase() || 'active'
  const planningMode = parseCreativePlanningMode(planningModeValue)
  const autoOutputsValue = environment.OPENVIDEO_CREATIVE_AUTO_OUTPUTS?.trim().toLowerCase() || 'on'
  const techniqueModeValue = environment.OPENVIDEO_CREATIVE_TECHNIQUES_MODE?.trim().toLowerCase() || 'active'
  const audioCueModeValue = environment.OPENVIDEO_CREATIVE_AUDIO_CUES_MODE?.trim().toLowerCase() || 'active'
  return {
    planningModeValue,
    planningMode,
    autoOutputsValue,
    autoOutputs: parseCreativeAutoOutputs(autoOutputsValue, planningMode),
    techniqueModeValue,
    techniqueMode: parseCreativeTechniqueMode(techniqueModeValue),
    audioCueModeValue,
    audioCueMode: parseCreativeAudioCueMode(audioCueModeValue),
  }
}

const shortVideoFactoryManifestUrl = new URL(
  '../../../config/short-video-factory-upstream.json',
  import.meta.url,
)
const pyJianyingDraftManifestUrl = new URL(
  '../../../config/pyjianyingdraft-upstream.json',
  import.meta.url,
)
const jianyingCompatibilityManifestUrl = new URL(
  '../../../config/jianying-compatibility.json',
  import.meta.url,
)

/** @param {string} code */
const blockedPreviewProvider = (code) => ({
  getStatus: () => ({
    available: false,
    state: 'blocked',
    code,
    provider: 'short-video-factory',
    commit: '9ad4c1df201538a3bdd05760e65153a8ce714bf8',
    license: 'AGPL-3.0',
  }),
  async renderPreview() {
    throw new ShortVideoFactoryError(code, 503)
  },
  async getResource() {
    return null
  },
  async publishFinal() {
    throw new ShortVideoFactoryError(code, 503)
  },
  async deleteResource() {
    return true
  },
})

/**
 * Resolve only audio already owned by the current project boundary. Template
 * audio is validated against the project's active template binding; ordinary
 * BGM and SFX continue through their dedicated private stores.
 * @param {{
 *   narrationProvider?: {resolveAudioToken?: Function} | null,
 *   bgmLibrary?: {acquireTrackLease: Function} | null,
 *   sfxCatalog?: {acquireAudio: Function} | null,
 *   templateMediaStore?: {acquireAudioLease: Function} | null,
 *   projectRepository: {get: Function},
 * }} dependencies
 */
export const createJY200DuoAudioSourceResolver = ({
  narrationProvider = null,
  bgmLibrary = null,
  sfxCatalog = null,
  templateMediaStore = null,
  projectRepository,
}) => async (/** @type {{stagingRoot: string, writePlan: Record<string, any>}} */ { stagingRoot, writePlan }) => {
  const placements = Array.isArray(writePlan?.audioPlacements) ? writePlan.audioPlacements : []
  if (placements.length === 0) return Object.freeze([])
  const projectId = typeof writePlan.projectId === 'string' ? writePlan.projectId : null
  if (!projectId) throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
  const project = await projectRepository.get(projectId)
  const libraryTemplateId = project?.templateBinding?.libraryTemplateId
  const audioRoot = resolve(stagingRoot, '.openvideo-audio')
  await mkdir(audioRoot, { recursive: true, mode: 0o700 })
  const sources = []
  for (const [index, placement] of placements.entries()) {
    if (placement?.role === 'voiceover') {
      const sourcePath = typeof narrationProvider?.resolveAudioToken === 'function'
        ? await narrationProvider.resolveAudioToken({ audioToken: placement.audioToken, projectId })
        : null
      if (typeof sourcePath !== 'string' || !isAbsolute(sourcePath)) {
        throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
      }
      sources.push(Object.freeze({ audioToken: placement.audioToken, sourcePath }))
      continue
    }
    if (!['bgm', 'sfx'].includes(placement?.role)) {
      throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
    }
    if (typeof placement.audioToken === 'string' && placement.audioToken.startsWith('tma_')) {
      if (typeof libraryTemplateId !== 'string' ||
          typeof templateMediaStore?.acquireAudioLease !== 'function') {
        throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
      }
      const lease = await templateMediaStore.acquireAudioLease(
        libraryTemplateId,
        placement.audioToken,
        placement.role,
      )
      if (!lease || typeof lease.extension !== 'string' || typeof lease.sha256 !== 'string' ||
          typeof lease.size !== 'number' || typeof lease.createStream !== 'function' ||
          typeof lease.verifyIntegrity !== 'function' || typeof lease.release !== 'function') {
        await lease?.release?.().catch(() => {})
        throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
      }
      const sourcePath = resolve(audioRoot, `${placement.role}-${index + 1}${lease.extension}`)
      const hash = createHash('sha256')
      try {
        const stream = lease.createStream()
        stream.on('data', (/** @type {Buffer} */ chunk) => hash.update(chunk))
        await pipeline(stream, createWriteStream(sourcePath, { flags: 'wx', mode: 0o600 }))
        const copied = await stat(sourcePath)
        if (copied.size !== lease.size || hash.digest('hex') !== lease.sha256 ||
            !await lease.verifyIntegrity()) {
          await unlink(sourcePath).catch(() => {})
          throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
        }
      } finally {
        await lease.release().catch(() => {})
      }
      sources.push(Object.freeze({ audioToken: placement.audioToken, sourcePath }))
      continue
    }
    const lease = placement.role === 'sfx'
      ? await sfxCatalog?.acquireAudio({ projectId, audioToken: placement.audioToken })
      : await bgmLibrary?.acquireTrackLease({ projectId, trackId: placement.audioToken })
    if (!lease || typeof lease.extension !== 'string' || typeof lease.createStream !== 'function' ||
        typeof lease.release !== 'function') {
      await lease?.release?.().catch(() => {})
      throw new Error('JY200_DUO_PRODUCT_AUDIO_AUTHORIZATION_REQUIRED')
    }
    const sourcePath = resolve(audioRoot, `${placement.role}-${index + 1}${lease.extension}`)
    try {
      await pipeline(lease.createStream(), createWriteStream(sourcePath, { flags: 'wx', mode: 0o600 }))
    } finally {
      await lease.release().catch(() => {})
    }
    sources.push(Object.freeze({ audioToken: placement.audioToken, sourcePath }))
  }
  return Object.freeze(sources)
}

/**
 * @param {{
 *   dataRoot: string,
 *   environment: NodeJS.ProcessEnv,
 *   warn: (event: Record<string, unknown>) => void,
 * }} input
 */
/**
 * @param {{
 *   dataRoot: string,
 *   securePrivateRoot?: (dataRoot: string) => Promise<void>,
 *   environment: NodeJS.ProcessEnv,
 *   warn: Function,
 *   authorizationRepository?: {get: Function},
 *   acquireBgmLease?: (input: {projectId: string, authorizationId: string}) => Promise<{extension: string, sha256: string, size: number, acquireFileDescriptor: () => number, createStream: () => import('node:stream').Readable, verifyIntegrity: () => Promise<boolean>, release: () => Promise<void>} | null>,
 *   ttsStudio?: {
 *     resolveBundle: Function,
 *     resolveAudioToken?: (input: {audioToken: string, projectId?: string} | string) => Promise<string | null>,
 *   },
 *   jianyingPresetNarration?: ReturnType<typeof createJianyingPresetNarration> | null,
 *   narrationProvider?: {resolveAudioToken: Function} | null,
 *   resolveSfxAudio?: ((input: {audioToken: string, projectId: string}) => Promise<string | {path?: string, extension?: string, sha256?: string, size?: number, createStream?: () => import('node:stream').Readable, verifyIntegrity?: () => Promise<boolean>, release?: () => Promise<void>} | null>) | null,
 * }} input
 */
const loadProductionPreviewProvider = async ({
  dataRoot,
  securePrivateRoot,
  environment,
  warn,
  authorizationRepository,
  acquireBgmLease,
  ttsStudio,
  jianyingPresetNarration = null,
  narrationProvider = null,
  resolveSfxAudio = null,
}) => {
  const upstreamRoot = environment.OPENVIDEO_SHORT_VIDEO_FACTORY_ROOT
  if (!upstreamRoot || !isAbsolute(upstreamRoot)) {
    return blockedPreviewProvider('SHORT_VIDEO_FACTORY_UNAVAILABLE')
  }
  try {
    const manifest = JSON.parse(await readFile(shortVideoFactoryManifestUrl, 'utf8'))
    /** @param {any} input */
    const resolveVoiceoverAudio = async (input) => {
      if (jianyingPresetNarration && isJianyingPresetVoiceId(input.voiceId)) {
        return jianyingPresetNarration.resolveBundle({
          projectId: input.projectId,
          voiceId: input.voiceId,
          segments: input.segments,
          signal: input.signal,
        })
      }
      if (typeof ttsStudio?.resolveBundle === 'function') {
        return ttsStudio.resolveBundle(input)
      }
      throw new Error('SHORT_VIDEO_FACTORY_UNAVAILABLE')
    }
    return await createShortVideoFactoryProvider({
      dataRoot,
      ...(securePrivateRoot ? { securePrivateRoot } : {}),
      upstreamRoot,
      manifest,
      bridge: /** @type {any} */ (runShortVideoFactoryElectronBridge),
      voice: environment.OPENVIDEO_SHORT_VIDEO_FACTORY_VOICE || null,
      voiceRate: boundedSignedInteger(
        environment.OPENVIDEO_SHORT_VIDEO_FACTORY_VOICE_RATE,
        0,
        -100,
        100,
      ),
      bgmPath: environment.OPENVIDEO_SHORT_VIDEO_FACTORY_BGM_PATH || null,
      acquireBgmLease: acquireBgmLease ?? null,
      resolveVoiceoverAudio,
      resolveAudioToken: (() => {
        const resolveToken = ttsStudio?.resolveAudioToken
        return async (input) => {
          if (typeof narrationProvider?.resolveAudioToken === 'function') {
            const resolved = await narrationProvider.resolveAudioToken(input)
            if (resolved) return resolved
          }
          return typeof resolveToken === 'function' ? resolveToken(input) : null
        }
      })(),
      resolveSfxAudio,
    })
  } catch (error) {
    const code = error && typeof error === 'object' && 'code' in error
      ? String(error.code)
      : 'SHORT_VIDEO_FACTORY_UNAVAILABLE'
    warn({ event: 'short_video_factory_blocked', code })
    return blockedPreviewProvider(code)
  }
}

/** @param {NodeJS.ProcessEnv} environment */
const inspectProductionJianyingEnvironment = async (environment) => {
  const upstreamRoot =
    environment.OPENVIDEO_PYJIANYINGDRAFT_ROOT ||
    environment.OPENVIDEO_JY002_PYTHON_MODULE_ROOT
  if (!upstreamRoot || !isAbsolute(upstreamRoot)) throw new Error('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE')
  const manifest = JSON.parse(await readFile(pyJianyingDraftManifestUrl, 'utf8'))
  const compatibilityManifest = JSON.parse(
    await readFile(jianyingCompatibilityManifestUrl, 'utf8'),
  )
  await inspectPyJianyingUpstream({ upstreamRoot, manifest })
  await execFileAsync(
    environment.OPENVIDEO_JY002_PYTHON_EXECUTABLE || 'python',
    ['-c', 'import pyJianYingDraft'],
    {
      cwd: upstreamRoot,
      env: { ...process.env, PYTHONPATH: upstreamRoot },
      timeout: 15_000,
      windowsHide: true,
    },
  )
  return {
    upstreamRoot,
    desktop: await detectJianyingDesktop({ compatibilityManifest }),
  }
}

/**
 * @param {{
 *   dataRoot: string,
 *   environment: NodeJS.ProcessEnv,
 *   materialAnalysisProvider: {resolvePreviewSources: Function},
 *   warn: (event: Record<string, unknown>) => void,
 * }} input
 */
/**
 * @param {{
 *   dataRoot: string,
 *   environment: NodeJS.ProcessEnv,
 *   materialAnalysisProvider: object,
 *   authorizationRepository?: {get: Function},
 *   acquireBgmLease?: (input: {projectId: string, authorizationId: string}) => Promise<{extension: string, sha256: string, size: number, acquireFileDescriptor: () => number, createStream: () => import('node:stream').Readable, verifyIntegrity: () => Promise<boolean>, release: () => Promise<void>} | null>,
 *   resolveSfxAudio?: ((input: {audioToken: string, projectId: string, workId: string, signal: AbortSignal}) => Promise<{path: string, release: () => Promise<void>} | null>) | null,
 *   ttsStudio?: {
 *     resolveBundle: Function,
 *     resolveAudioToken?: (input: {audioToken: string, projectId?: string} | string) => Promise<string | null>,
 *   },
 *   jianyingPresetNarration?: ReturnType<typeof createJianyingPresetNarration> | null,
 *   voiceoverProvider?: Awaited<ReturnType<typeof createJianyingVoiceoverProvider>> | null,
 *   resolveTemplateAudioPath?: (input: {libraryTemplateId: string, audioToken: string}) => Promise<string | null>,
 *   resolveTemplatePackagingToken?: (input: {libraryTemplateId: string, packagingToken: string}) => Promise<{kind: string, resourceId: string, effectId?: string} | null>,
 *   resolveTemplateBlueprint?: (input: {blueprintId: string, fingerprint: string}) => Promise<string | null>,
 *   resolvePackagingSnapshot?: ((input?: {packagingTokens?: string[]}) => Promise<Record<string, any> | null>) | null,
 *   readProjectTemplateBinding?: (projectId: string) => Promise<{libraryTemplateId?: string} | null> | {libraryTemplateId?: string} | null,
 *   sfxCatalogSnapshot?: {fingerprint?: string} | null,
 *   packagingResourceVerificationCache: Map<string, {evidence: Record<string, any>, admitted: any}>,
 *   warn: Function,
 * }} input
 */
const loadProductionJianyingCapability = async ({
  dataRoot,
  environment,
  materialAnalysisProvider,
  authorizationRepository,
  acquireBgmLease,
  resolveSfxAudio = null,
  ttsStudio,
  jianyingPresetNarration = null,
  voiceoverProvider: providedVoiceoverProvider = null,
  resolveTemplateAudioPath,
  resolveTemplatePackagingToken,
  resolveTemplateBlueprint,
  resolvePackagingSnapshot: providedPackagingSnapshotResolver = null,
  readProjectTemplateBinding,
  sfxCatalogSnapshot = null,
  packagingResourceVerificationCache,
  warn,
}) => {
  try {
    const { upstreamRoot, desktop } = await inspectProductionJianyingEnvironment(environment)
    /** @type {Map<string, Record<string, any>>} */
    const renderOptionsByRequestId = new Map()
    /** @type {Record<string, any> | null} */
    let writerPackagingResourceIndex = null
    /** @param {string} packagingToken @returns {Record<string, any> | null} */
    const resolveWriterPackagingToken = (packagingToken) =>
      resolvePrivatePackagingResourceToken(writerPackagingResourceIndex, packagingToken)
    const runtime = createJianyingDraftRuntime({
      draftRoot: desktop.draftRoot,
      pythonModuleRoot: upstreamRoot,
      pythonExecutable: environment.OPENVIDEO_JY002_PYTHON_EXECUTABLE || 'python',
      captions: true,
      bgmPath: null,
      /** @param {{request_id?: string}} [input={}] */
      getRenderOptions: (input = {}) => renderOptionsByRequestId.get(String(input.request_id ?? '')) ?? null,
      resolvePrivatePackagingToken: resolveWriterPackagingToken,
      resolveTemplateBlueprint,
    })
    const voiceoverProvider = providedVoiceoverProvider ?? await createJianyingVoiceoverProvider({
      dataRoot,
      voice: environment.OPENVIDEO_JY002_SYSTEM_SPEECH_VOICE || null,
      ttsStudio,
      jianyingPresetNarration: jianyingPresetNarration ?? undefined,
    })
    /** @type {string[]} */
    let privateCatalogCapabilities = []
    /** @type {string[]} */
    let evidencedCapabilities = []
    /** @type {ReadonlyArray<Record<string, any>>} */
    /** @type {ReadonlyArray<Record<string, any>>} */
    let promotionReceipts = []
    let audioEffectCatalog = null
    let textAnimationCatalog = null
    let videoAnimationCatalog = null
    let maskCatalog = null
    let batchTextCatalog = null
    let packagingResourceIndex = null
    let legacyTextCatalog = null
    let filterResolver = null
    try {
      packagingResourceIndex = await loadPackagingResourceIndexForProduction({ dataRoot, desktop, verificationCache: packagingResourceVerificationCache })
      if (!packagingResourceIndex) throw new Error('JY132_EVIDENCE_UNAVAILABLE')
      promotionReceipts = createCapabilityPromotionReceiptsFromAdmittedPackagingIndex({
        index: packagingResourceIndex,
        desktop,
      })
      writerPackagingResourceIndex = packagingResourceIndex
      const familyCapabilities = new Map([
        ['flower', 'text.flower.private'],
        ['bubble', 'text.bubble.private'],
        ['sticker', 'sticker.named'],
        ['video_effect', 'effect.video.named'],
        ['video_animation', 'animation.video.named'],
        ['mask', 'mask.video.named'],
        ['blend', 'blend.video.named'],
      ])
      for (const entry of packagingResourceIndex.entries) {
        const capabilityId = familyCapabilities.get(entry.family)
        if (entry.state === 'writer_eligible' && typeof capabilityId === 'string') {
          privateCatalogCapabilities.push(capabilityId)
        }
      }
    } catch (error) {
      if (!error || typeof error !== 'object' || !('code' in error) || error.code !== 'ENOENT') {
        warn({ event: 'jianying_packaging_resource_catalog_unavailable', code: 'JY132_PRIVATE_CATALOG_INVALID' })
      }
      /* Missing or invalid broad catalogs remain discovery-only or fail closed. */
    }
    try {
      const filterProduction = await loadJianyingFilterProduction({
        dataRoot,
        desktop,
        upstreamRoot,
      })
      if (filterProduction) {
        filterResolver = filterProduction.filterResolver
        privateCatalogCapabilities.push(...filterProduction.capabilities)
      }
    } catch { /* unavailable catalog/evidence remains fail-closed */ }
    try {
      const catalog = parseJianyingBlendCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy046-blend-catalog.json'), 'utf8')))
      if (catalog) privateCatalogCapabilities.push('blend.video.named')
    } catch { /* unavailable catalog remains fail-closed */ }
    try {
      const catalog = parseJianyingBackgroundCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy062-background-catalog.json'), 'utf8')))
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy062-background', 'post-save.json'), 'utf8'))
      if (catalog && parseJianyingBackgroundEvidence(evidence, catalog.fingerprint, desktop)) {
        privateCatalogCapabilities.push('background.video')
      }
    } catch { /* unavailable catalog remains fail-closed */ }
    try {
      const catalog = parseJianyingTextPackagingCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy063-text-packaging-catalog.json'), 'utf8')))
      if (!catalog) throw new Error('JY063_TEXT_PACKAGING_CATALOG_UNAVAILABLE')
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy063-text-packaging', 'post-save.json'), 'utf8'))
      const required = ['sticker.named', 'text.flower.private', 'text.bubble.private']
      legacyTextCatalog = admitJianyingTextPackagingCatalog(
        catalog,
        parseJianyingTextPackagingEvidence(evidence, catalog.fingerprint, desktop),
      )
      if (legacyTextCatalog && required.length === 3) privateCatalogCapabilities.push(...required)
    } catch { /* unavailable catalog or evidence remains fail-closed */ }
    try {
      const catalog = await intakeJianyingBatchTextPackagingCatalog({
        runtimeRoot: dataRoot,
        catalogPath: join(dataRoot, 'catalogs', 'jy130-batch-text-packaging-catalog.json'),
        desktopVersion: desktop.version,
        profileId: desktop.profileId,
      })
      const evidence = parseJianyingBatchTextPackagingEvidence(
        JSON.parse(await readFileNoReparse(join(dataRoot, 'evidence', 'jy130-batch-text', 'post-save.json'), dataRoot)),
        catalog.catalog_fingerprint,
        desktop,
      )
      const admittedCatalog = admitJianyingBatchTextPackagingCatalog(catalog, evidence)
      if (
        admittedCatalog !== null
      ) {
        batchTextCatalog = admittedCatalog
        for (const capabilityId of ['sticker.named', 'text.flower.private', 'text.bubble.private']) {
          if (admittedCatalog.entries.some((/** @type {Record<string, unknown>} */ entry) => entry.capability_id === capabilityId)) {
            privateCatalogCapabilities.push(capabilityId)
          }
        }
      }
    } catch { /* unavailable, stale, or mismatched batch catalog remains fail-closed */ }
    try {
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy084-text-keyframe', 'post-save.json'), 'utf8'))
      if (parseJianyingTextKeyframeEvidence(evidence, desktop)) privateCatalogCapabilities.push('transform.text.keyframe')
    } catch { /* unavailable evidence remains fail-closed */ }
    try {
      const catalog = parseJianyingTextPackagingCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy063-text-packaging-catalog.json'), 'utf8')))
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy113-sticker-keyframe', 'post-save.json'), 'utf8'))
      const evidenceRoot = join(dataRoot, 'evidence', 'jy113-sticker-keyframe')
      const integrityKey = await loadJianyingStickerKeyframeIntegrityKey({ evidenceRoot })
      if (catalog && await verifyJianyingStickerKeyframeEvidence({ evidence, desktop, catalogFingerprint: catalog.fingerprint, integrityKey })) {
        privateCatalogCapabilities.push('sticker.named', 'transform.sticker.keyframe')
        evidencedCapabilities.push('transform.sticker.keyframe')
      }
    } catch { /* unavailable catalog or exact same-draft evidence remains fail-closed */ }
    try {
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy092-track-insert', 'post-save.json'), 'utf8'))
      if (parseJianyingTrackInsertEvidence(evidence, desktop)) privateCatalogCapabilities.push('track.insert')
    } catch { /* unavailable evidence remains fail-closed */ }
    try {
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy074-video-fade', 'post-save.json'), 'utf8'))
      if (parseJianyingVideoFadeEvidence(evidence, desktop)) privateCatalogCapabilities.push('audio.video.fade')
    } catch { /* unavailable evidence remains fail-closed */ }
    if (await loadJianyingChromaEvidenceCapability({ dataRoot, desktop, readEvidence: (filePath) => readFile(filePath, 'utf8'), joinPath: join })) privateCatalogCapabilities.push('chroma.video')
    videoAnimationCatalog = await loadJianyingVideoAnimationCapability({ dataRoot, desktop, readFile, joinPath: join })
    if (videoAnimationCatalog) privateCatalogCapabilities.push('animation.video.named')
    maskCatalog = await loadJianyingMaskCapability({ dataRoot, desktop, readFile, joinPath: join })
    if (maskCatalog) privateCatalogCapabilities.push('mask.video.named')
    try {
      const catalog = parseJianyingTextAnimationCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy083-text-animation-catalog.json'), 'utf8')))
      const evidence = JSON.parse(await readFile(join(dataRoot, 'evidence', 'jy083-text-animation', 'post-save.json'), 'utf8'))
      if (catalog && parseJianyingTextAnimationEvidence(evidence, catalog.fingerprint, desktop)) {
        textAnimationCatalog = catalog
        privateCatalogCapabilities.push('animation.text.named')
      }
    } catch { /* unavailable catalog or evidence remains fail-closed */ }
    const creativeSfxPromotion = await loadCreativeSfxPromotionProjection({
      dataRoot,
      desktop,
      catalogFingerprint: sfxCatalogSnapshot?.fingerprint ?? null,
    })
    if (creativeSfxPromotion) promotionReceipts = [...promotionReceipts, creativeSfxPromotion]
    audioEffectCatalog = await loadProductionJianyingAudioEffectCatalog({ dataRoot, desktop })
    if (audioEffectCatalog) privateCatalogCapabilities.push('audio.effect.named')
    /** @param {string | undefined} projectId */
    const libraryTemplateIdsForProject = async (projectId) => {
      if (typeof projectId !== 'string' || typeof readProjectTemplateBinding !== 'function') return []
      const binding = await readProjectTemplateBinding(projectId)
      if (typeof binding?.libraryTemplateId !== 'string') return []
      const blendSources = Array.isArray(/** @type {Record<string, any>} */ (binding).blendSources)
        ? /** @type {Record<string, any>} */ (binding).blendSources
        : []
      return [
        binding.libraryTemplateId,
        ...blendSources
          .map((/** @type {Record<string, any>} */ source) => source?.libraryTemplateId)
          .filter((/** @type {unknown} */ value) => typeof value === 'string'),
      ]
    }
    return createJianyingWorkbenchBridge({
      runtime,
      desktopProfile: {
        version: desktop.version,
        profileId: desktop.profileId,
        provisional: desktop.provisional,
        capabilities: desktop.capabilities,
      },
      privateCatalogCapabilities,
      evidencedCapabilities,
      promotionReceipts,
      batchTextCatalog,
      packagingResourceIndex,
      packagingDesktopBinding: {
        profileId: desktop.profileId,
        version: desktop.version,
        executablePath: desktop.executablePath,
        installRoot: desktop.installRoot,
        dllFingerprint: desktop.dllFingerprint,
      },
      packagingRecommendationFamilies: selectWriterEligiblePackagingFamilies(packagingResourceIndex),
      materialAnalysisProvider: /** @type {any} */ (materialAnalysisProvider),
      voiceoverProvider,
      setRenderOptions: (/** @type {Record<string, any> | null} */ value, /** @type {string | null} */ requestId = null) => {
        if (typeof requestId !== 'string' || requestId.length === 0) return
        if (value === null) renderOptionsByRequestId.delete(requestId)
        else renderOptionsByRequestId.set(requestId, value)
      },
      resolvePackagingSnapshot: async (input = {}) => {
        let current = null
        try {
          current = typeof providedPackagingSnapshotResolver === 'function'
            ? await providedPackagingSnapshotResolver(input)
            : null
        } catch { current = null }
        return current
          ? {
              ready: current.ready === true,
              profileId: current.profileId,
              appVersion: current.appVersion,
              catalogFingerprint: current.catalogFingerprint,
              packagingIndex: current.packagingIndex,
            }
          : {
              ready: false,
              profileId: desktop.profileId,
              appVersion: desktop.version,
              catalogFingerprint: null,
              packagingIndex: null,
            }
      },
      resolveAudioPath: async ({ audioToken, projectId }) => {
        if (
          typeof audioToken === 'string' &&
          audioToken.startsWith('tma_') &&
          typeof resolveTemplateAudioPath === 'function'
        ) {
          const [libraryTemplateId] = await libraryTemplateIdsForProject(projectId)
          if (libraryTemplateId) {
            try {
              const path = await resolveTemplateAudioPath({ libraryTemplateId, audioToken })
              if (typeof path === 'string' && path.length > 0) return path
            } catch {
              return null
            }
          }
        }
        if (typeof voiceoverProvider?.resolveAudioToken === 'function') {
          const path = await voiceoverProvider.resolveAudioToken({ audioToken, projectId })
          if (typeof path === 'string' && path.length > 0) return path
        }
        const resolve = ttsStudio?.resolveAudioToken
        if (typeof resolve !== 'function') return null
        return resolve({ audioToken, projectId })
      },
      resolvePackagingToken: async ({ packagingToken, projectId }) => {
        if (typeof packagingToken === 'string') {
          try {
            if (packagingToken.startsWith('ovjmask_v2_')) {
              const entry = resolveJianyingMaskToken(maskCatalog, packagingToken)
              if (entry) return { kind: 'mask', resourceId: entry.resourceId, commonMaskTemplate: entry.commonMaskTemplate }
            }
            if (packagingToken.startsWith('ovjanim_v1_')) {
              const entry = resolveJianyingVideoAnimationToken(videoAnimationCatalog, packagingToken)
              if (entry) return { kind: 'animation', resourceId: entry.resourceId, durationUs: entry.durationUs }
            }
            if (packagingToken.startsWith('ovjblend_v1_')) {
              const catalog = parseJianyingBlendCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy046-blend-catalog.json'), 'utf8')))
              const entries = Array.isArray(catalog?.entries) ? /** @type {ReadonlyArray<Record<string, any>>} */ (catalog.entries) : []
              const entry = entries.find((/** @type {any} */ candidate) => candidate?.blend_token === packagingToken)
              if (entry?.capability_id === 'blend.video.named' && typeof entry.resource_id === 'string') return { kind: 'blend', resourceId: entry.resource_id }
            }
            if (packagingToken.startsWith('ovjbg_v1_')) {
              const catalog = parseJianyingBackgroundCatalog(JSON.parse(await readFile(join(dataRoot, 'catalogs', 'jy062-background-catalog.json'), 'utf8')))
              const entry = catalog?.entries.find((/** @type {any} */ candidate) => candidate?.fill_token === packagingToken)
              if (entry) return { kind: 'background', resourceId: 'private-background', fillType: entry.fill_type, blur: entry.blur, color: entry.color }
            }
            if (packagingToken.startsWith('ovjpack_v1_')) {
              const batchResolution = resolveJianyingBatchTextPackagingToken(batchTextCatalog, packagingToken)
              if (batchResolution) return batchResolution
              const legacyResolution = resolveJianyingTextPackagingToken(legacyTextCatalog, packagingToken)
              if (legacyResolution?.kind === 'flower') {
                return { ...legacyResolution, effectId: legacyResolution.resourceId }
              }
              return legacyResolution
            }
            const indexedResolution = resolvePrivatePackagingResourceToken(packagingResourceIndex, packagingToken)
            if (indexedResolution) return indexedResolution
          } catch { return null }
        }
        if (typeof resolveTemplatePackagingToken !== 'function') return null
        const libraryTemplateIds = await libraryTemplateIdsForProject(projectId)
        for (const libraryTemplateId of libraryTemplateIds) {
          try {
            const resolved = await resolveTemplatePackagingToken({ libraryTemplateId, packagingToken })
            if (resolved) return resolved
          } catch {
            // Continue to the next immutable template source.
          }
        }
        return null
      },
      resolveTextAnimationToken: async ({ animationToken }) => {
        if (!textAnimationCatalog) return null
        try { return resolveJianyingTextAnimationToken(textAnimationCatalog, animationToken) } catch { return null }
      },
      filterResolver,
      resolveAudioEffectToken: async ({ effectToken }) => {
        if (!audioEffectCatalog) return null
        try { return resolveJianyingAudioEffectToken(audioEffectCatalog, effectToken) } catch { return null }
      },
      acquireBgmLease: acquireBgmLease ?? null,
      resolveSfxAudio,
    })
  } catch (error) {
    warn({
      event: 'jianying_draft_capability_blocked',
      code: error && typeof error === 'object' && 'code' in error
        ? String(error.code)
        : 'WORKBENCH_JIANYING_EXPORT_UNAVAILABLE',
    })
    return undefined
  }
}

/**
 * Admit the private named-audio-effect catalog only when its same-draft
 * evidence binds it to the exact detected desktop profile.
 *
 * This stays in the production server module so the test exercises the same
 * catalog/evidence boundary used before the Workbench bridge is created.
 * @param {{dataRoot: string, desktop: {profileId: string, version: string}, readPrivateFile?: typeof readFile}} input
 */
export const loadProductionJianyingAudioEffectCatalog = async ({
  dataRoot,
  desktop,
  readPrivateFile = readFile,
}) => {
  if (!['jianying-11-1-provisional', 'jianying-11-2-provisional'].includes(desktop?.profileId)) {
    return null
  }
  try {
    const catalog = parseJianyingAudioEffectCatalog(JSON.parse(await readPrivateFile(
      join(dataRoot, 'catalogs', 'jy064-audio-effect-catalog.json'),
      'utf8',
    )))
    const evidence = JSON.parse(await readPrivateFile(
      join(dataRoot, 'evidence', 'jy067-audio-effect', 'post-save.json'),
      'utf8',
    ))
    return parseJianyingAudioEffectEvidence(evidence, catalog.fingerprint, desktop)
      ? catalog
      : null
  } catch {
    return null
  }
}


/**
 * @param {string} pathname
 * @param {{
 *   syntheticWorkbench: boolean,
 *   gatewayHandler: Function,
 *   directorHandler: Function,
 *   jianyingDraftHandler: Function,
 *   jianyingDraftMinerHandler?: Function,
 *   livenessHandler: Function,
 *   readinessHandler: Function,
 *   settingsHandler: Function,
 *   runningHubSettingsHandler: Function,
 *   jianying6RendererSettingsHandler?: Function,
 *   jianyingTtsPresetsHandler?: Function,
 *   jianyingVoiceCatalogHandler?: Function,
 *   jianyingWriterSettingsHandler?: Function,
 *   jianyingDuoProbationaryHandler?: Function,
 *   ttsStudioHandler: Function,
 *   bgmLibraryHandler?: Function,
 *   sfxCatalogHandler?: Function,
 *   localPickerHandler?: Function,
 *   runtimeDiagnosticsHandler?: Function,
 *   creativeCapabilitySnapshotHandler?: Function,
 *   jianyingResourceRootSettingsHandler?: Function,
 *   jianyingPrivateResourceCatalogHandler?: Function,
 *   jianyingCapCutCatalogHandler?: Function,
 *   jianyingNativeEvidencePreflightHandler?: Function,
   *   productUpdateHandler?: Function,
   *   workbenchHandler: Function,
   * }} handlers
   */
export const selectGatewayResponseHandler = (pathname, handlers) =>
  pathname === '/api/live'
    ? handlers.livenessHandler
    : pathname === '/api/ready'
    ? handlers.readinessHandler
    : pathname === '/api/product-update'
      || pathname === '/api/product-update/check'
      || pathname === '/api/product-update/apply'
      ? handlers.productUpdateHandler
    : pathname === '/api/settings/llm'
      || pathname === '/api/settings/llm/models'
      || pathname === '/api/settings/llm/status'
      ? handlers.settingsHandler
    : pathname.startsWith('/api/settings/runninghub')
      ? handlers.runningHubSettingsHandler
    : pathname.startsWith('/api/settings/jianying6')
      ? handlers.jianying6RendererSettingsHandler
    : pathname.startsWith('/api/settings/jianying-tts-presets')
      ? handlers.jianyingTtsPresetsHandler
    : pathname.startsWith('/api/settings/jianying-tts-voices')
      ? handlers.jianyingVoiceCatalogHandler
    : pathname === '/api/settings/jianying-writers'
      ? handlers.jianyingWriterSettingsHandler
    : pathname === '/api/workbench/jianying-duo-probationary'
      ? handlers.jianyingDuoProbationaryHandler
    : pathname.startsWith('/api/local-picker/')
      ? handlers.localPickerHandler
    : pathname.startsWith('/api/settings/jianying-resource-roots')
      ? handlers.jianyingResourceRootSettingsHandler
    : pathname.startsWith('/api/tts-studio/')
      ? handlers.ttsStudioHandler
    : pathname.startsWith('/api/bgm-library/')
      ? handlers.bgmLibraryHandler
    : pathname.startsWith('/api/sfx-catalog/')
      ? handlers.sfxCatalogHandler
    : pathname === '/api/runtime-diagnostics'
      ? handlers.runtimeDiagnosticsHandler
    : pathname === '/api/creative-planning/capability-snapshot'
      ? handlers.creativeCapabilitySnapshotHandler
    : pathname === '/api/jianying-private-resources'
      ? handlers.jianyingPrivateResourceCatalogHandler
    : pathname === '/api/jianying-capcut-catalog'
      ? handlers.jianyingCapCutCatalogHandler
    : pathname === '/api/jianying-native-evidence-preflight'
      ? handlers.jianyingNativeEvidencePreflightHandler
    : pathname.startsWith('/api/jianying-draft-miner/') || pathname === '/api/jianying-draft-miner/jobs'
      ? handlers.jianyingDraftMinerHandler
    : pathname === '/api/llm/generate'
    ? handlers.gatewayHandler
    : pathname === '/api/director/edit-plan' && handlers.syntheticWorkbench
      ? handlers.directorHandler
      : pathname.startsWith('/api/jianying-draft/')
        ? handlers.jianyingDraftHandler
        : pathname.startsWith('/api/workbench/')
          ? handlers.workbenchHandler
          : null

/**
 * @param {() => Record<string, unknown> | null} getSnapshot
 * @returns {(request: Request) => Promise<Response>}
 */
export const createCreativeCapabilitySnapshotHandler = (getSnapshot) => async (request) => {
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: { code: 'METHOD_NOT_ALLOWED', message: 'Use POST.' } }), {
      status: 405,
      headers: { allow: 'POST', 'content-type': 'application/json; charset=utf-8' },
    })
  }
  const snapshot = getSnapshot()
  if (!snapshot) {
    return new Response(JSON.stringify({
      error: {
        code: 'CREATIVE_CAPABILITY_SNAPSHOT_UNAVAILABLE',
        message: 'Creative capability snapshot is unavailable.',
      },
    }), { status: 503, headers: { 'content-type': 'application/json; charset=utf-8' } })
  }
  return new Response(JSON.stringify(snapshot), {
    headers: {
      'cache-control': 'no-store',
      'content-type': 'application/json; charset=utf-8',
      'x-content-type-options': 'nosniff',
    },
  })
}

/**
 * @param {{
 *   environment?: NodeJS.ProcessEnv,
 *   log?: (message: string) => void,
 *   warn?: (event: Record<string, unknown>) => void,
 *   creativeKnowledgeLoader?: typeof loadCreativeKnowledge,
 *   webRoot?: string,
 * }} [options]
 */
export const startGatewayServer = async ({
  environment = process.env,
  log = console.log,
  warn = (event) => console.warn(JSON.stringify(event)),
  creativeKnowledgeLoader = loadCreativeKnowledge,
  webRoot = fileURLToPath(new URL('../../web/dist/', import.meta.url)),
} = {}) => {
  const runtimeDiagnostics = createRuntimeDiagnostics()
  /** @param {Record<string, unknown>} event */
  const workbenchLogger = (event) => {
    recordSafeWorkbenchDiagnostic(runtimeDiagnostics, event)
    warn(event)
  }
  // PROD-HOTFIX-007: boot used to be a black box. The launcher could only measure "node was spawned"
  // to "node answered /api/live", so a slow phase inside boot was indistinguishable from a slow
  // health probe. These markers append to the launcher's progress log, which the visible launcher
  // window tails, so a slow launch now says which phase was slow instead of only how long it took.
  const bootStartedAt = Date.now()
  let lastPhaseAt = bootStartedAt
  const startupState = { ready: false, phase: 'gateway-starting', progress: 1 }
  const startupProgress = new Map([
    ['repositories', 8],
    ['local-api-token', 15],
    ['static-web', 22],
    ['startup-listen', 25],
    ['creative-knowledge', 29],
    ['material-analysis', 34],
    ['material-review-overlay', 38],
    ['tts-studio', 46],
    ['narration-provider', 50],
    ['preview-provider', 56],
    ['template-capabilities', 68],
    ['jianying-capability', 80],
    ['workbench-runtime', 86],
    ['startup-recovery', 91],
    ['factories', 94],
    ['runtime-root-acl-finalize', 97],
    ['workbench-ready', 100],
  ])
  const bootProgressLog = typeof environment.OPENVIDEO_LAUNCH_PROGRESS_LOG === 'string'
    && isAbsolute(environment.OPENVIDEO_LAUNCH_PROGRESS_LOG)
    ? environment.OPENVIDEO_LAUNCH_PROGRESS_LOG
    : null
  /** @param {string} phase */
  const bootPhase = (phase) => {
    const now = Date.now()
    startupState.phase = phase
    startupState.progress = startupProgress.get(phase) ?? startupState.progress
    const line = `OPENVIDEO_GATEWAY_PHASE: ${phase} took `
      + `${((now - lastPhaseAt) / 1000).toFixed(1)}s `
      + `(gateway total ${((now - bootStartedAt) / 1000).toFixed(1)}s)`
    lastPhaseAt = now
    if (!bootProgressLog) return
    // Best effort only: progress reporting must never be able to fail a launch.
    try {
      appendFileSync(bootProgressLog, `${line}\n`, 'utf8')
    } catch {
      // The launcher owns this file; if it is unavailable the launch continues unreported.
    }
  }
  const config = loadOptionalGatewayConfig(environment)
  const {
    planningModeValue: creativePlanningModeValue,
    planningMode: creativePlanningMode,
    autoOutputsValue: creativeAutoOutputsValue,
    autoOutputs: creativeAutoOutputs,
    techniqueModeValue: creativeTechniqueModeValue,
    techniqueMode: creativeTechniqueMode,
    audioCueModeValue: creativeAudioCueModeValue,
    audioCueMode: creativeAudioCueMode,
  } = resolveCreativePlanningConfig(environment)
  if (!['off', 'shadow', 'active'].includes(creativePlanningModeValue)) {
    runtimeDiagnostics.record({
      component: 'creative-planning',
      code: 'CREATIVE_PLANNING_MODE_INVALID',
      severity: 'warning',
    })
    warn({ event: 'creative_planning_disabled', code: 'CREATIVE_PLANNING_MODE_INVALID' })
  }
  if (
    !['off', 'on'].includes(creativeAutoOutputsValue) ||
    (creativeAutoOutputsValue === 'on' && creativePlanningMode !== 'active')
  ) {
    runtimeDiagnostics.record({
      component: 'creative-planning',
      code: 'CREATIVE_AUTO_OUTPUTS_MODE_INVALID',
      severity: 'warning',
    })
    warn({ event: 'creative_auto_outputs_disabled', code: 'CREATIVE_AUTO_OUTPUTS_MODE_INVALID' })
  }
  if (!['off', 'shadow', 'active'].includes(creativeTechniqueModeValue)) {
    runtimeDiagnostics.record({
      component: 'creative-techniques',
      code: 'CREATIVE_TECHNIQUES_MODE_INVALID',
      severity: 'warning',
    })
    warn({
      event: 'creative_techniques_disabled',
      code: 'CREATIVE_TECHNIQUES_MODE_INVALID',
    })
  }
  if (!['off', 'shadow', 'active'].includes(creativeAudioCueModeValue)) {
    runtimeDiagnostics.record({
      component: 'creative-audio-cues',
      code: 'CREATIVE_AUDIO_CUES_MODE_INVALID',
      severity: 'warning',
    })
    warn({ event: 'creative_audio_cues_disabled', code: 'CREATIVE_AUDIO_CUES_MODE_INVALID' })
  }
  let creativeKnowledge = null
  let creativeTechniqueKnowledge = null
  const createConfiguredLlmReadinessProbe = (/** @type {import('./config.mjs').GatewayConfig} */ configuredConfig) => {
    return createLlmReadinessProbe({
      probe: createOpenAiCompatibleReadinessProbe(configuredConfig),
      workbenchMode: environment.OPENVIDEO_WORKBENCH_MODE,
      logger: warn,
      attempts: 1,
    })
  }
  const initialGateway = config
    ? createGateway({ config, logger: warn })
    : createUnconfiguredGateway()
  /** @type {{ current: { generate: Function }, probe: () => Promise<boolean>, llmRevision: string | null }} */
  const llmRuntime = {
    current: initialGateway,
    probe: config ? createConfiguredLlmReadinessProbe(config) : async () => false,
    llmRevision: config ? environment.OPENVIDEO_LLM_REVISION?.trim() || null : null,
  }
  const gateway = {
    /** @param {any} request @param {any} [options] */
    generate: (request, options) => llmRuntime.current.generate(request, options),
  }
  // Keep the dynamic current-catalog route on the same bounded JSON ranker as
  // the startup provider. The resolver still falls back to deterministic
  // catalog selection when the Gateway is unavailable.
  const dynamicPackagingRanker = createLlmGatewayPackagingRanker({ gateway, logger: warn })
  const director = createDirector({ gateway, logger: warn })
  const probeLlmGateway = () => llmRuntime.probe()
  const gatewayHandler = createGatewayHandler({ gateway })
  const directorHandler = createDirectorHandler({ director })
  const livenessHandler = createLivenessHandler({
    bootId: randomUUID(),
    getLlmRevision: () => llmRuntime.llmRevision,
    releaseRevision: environment.OPENVIDEO_RELEASE_REVISION?.trim() || null,
    launcherSecret: environment.OPENVIDEO_LAUNCHER_INSTANCE_SECRET?.trim() || null,
    getStartupState: () => ({ ...startupState }),
  })
  const productUpdateService = createProductUpdateService({
    repositoryRoot: fileURLToPath(new URL('../../../..', import.meta.url)),
  })
  // REL-017: background update check used to fire immediately during server
  // construction.  Bootstrap-OpenVideo + Start-OpenVideo may still be writing
  // config/product-update.json (and unpacking the runtime tree) for several
  // seconds after this line runs, which made the first check race and return
  // {status:'check_failed', reason:'source_unavailable'}.  We delay the
  // background check until workbench-ready so configPath, install root and
  // release-identity are guaranteed to be readable.
  const productUpdateHandler = createProductUpdateHandler({ service: productUpdateService })
  const llmSettingsService =
    environment.OPENVIDEO_CONFIG_PATH && environment.OPENVIDEO_PRIVATE_CONFIG_ROOT
      ? createLlmSettingsService({
          configPath: environment.OPENVIDEO_CONFIG_PATH,
          privateConfigRoot: environment.OPENVIDEO_PRIVATE_CONFIG_ROOT,
          probeGenerate: () => llmRuntime.current.generate({
            capability: 'json',
            messages: [{
              role: 'user',
              parts: [{ type: 'text', text: 'Return exactly {"confirmation":"ok"}.' }],
            }],
            jsonSchema: {
              name: 'llm_connectivity_probe',
              schema: {
                type: 'object',
                additionalProperties: false,
                required: ['confirmation'],
                properties: { confirmation: { type: 'string', const: 'ok' } },
              },
            },
          }),
        })
      : null
  /** @param {LlmRuntimeConfig | null | undefined} runtime */
  const applyLlmRuntimeConfig = async (runtime) => {
    const resolved = runtime ?? (llmSettingsService
      ? await llmSettingsService.resolveRuntimeConfig()
      : null)
    if (!resolved) {
      throw new LlmSettingsError('LLM_SETTINGS_API_KEY_REQUIRED', 400)
    }
    environment.OPENVIDEO_LLM_PROVIDER = resolved.provider
    environment.OPENVIDEO_LLM_BASE_URL = resolved.baseUrl
    environment.OPENVIDEO_LLM_API_KEY = resolved.apiKey
    environment.OPENVIDEO_LLM_TEXT_MODEL = resolved.textModel
    environment.OPENVIDEO_LLM_VISION_MODEL = resolved.visionModel
    environment.OPENVIDEO_LLM_JSON_MODEL = resolved.jsonModel
    environment.OPENVIDEO_LLM_REVISION = resolved.revision
    process.env.OPENVIDEO_LLM_PROVIDER = resolved.provider
    process.env.OPENVIDEO_LLM_BASE_URL = resolved.baseUrl
    process.env.OPENVIDEO_LLM_API_KEY = resolved.apiKey
    process.env.OPENVIDEO_LLM_TEXT_MODEL = resolved.textModel
    process.env.OPENVIDEO_LLM_VISION_MODEL = resolved.visionModel
    process.env.OPENVIDEO_LLM_JSON_MODEL = resolved.jsonModel
    process.env.OPENVIDEO_LLM_REVISION = resolved.revision
    const nextConfig = loadOptionalGatewayConfig(environment)
    if (!nextConfig) {
      throw new LlmSettingsError('LLM_SETTINGS_INVALID', 400)
    }
    llmRuntime.current = createGateway({ config: nextConfig, logger: warn })
    // Health from the previous provider revision must not carry across a
    // credential, endpoint, or model change.
    llmRuntime.probe = createConfiguredLlmReadinessProbe(nextConfig)
    llmRuntime.llmRevision = resolved.revision
  }
  const settingsHandler = llmSettingsService
      ? createLlmSettingsHandler({
          service: llmSettingsService,
          applyRuntimeConfig: applyLlmRuntimeConfig,
        })
      : async () => new Response(JSON.stringify({
          error: {
            code: 'LLM_SETTINGS_UNAVAILABLE',
            message: 'The local LLM settings service is unavailable.',
          },
        }), {
          status: 503,
          headers: { 'content-type': 'application/json; charset=utf-8' },
        })
  const runningHubSettingsService = environment.OPENVIDEO_PRIVATE_CONFIG_ROOT
    ? createRunningHubSettingsService({
        privateConfigRoot: environment.OPENVIDEO_PRIVATE_CONFIG_ROOT,
        settingsPath: resolve(environment.OPENVIDEO_PRIVATE_CONFIG_ROOT, 'runninghub-settings.json'),
      })
    : null
  const runningHubSettingsHandler = runningHubSettingsService
    ? createRunningHubSettingsHandler({
        service: runningHubSettingsService,
        probe: (settings) => createRunningHubClient({ settings }).probe(),
      })
    : async () => new Response(JSON.stringify({
        error: {
          code: 'RUNNINGHUB_SETTINGS_UNAVAILABLE',
          message: 'The local RunningHub settings service is unavailable.',
        },
      }), {
        status: 503,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      })
  const jianyingTtsPresetsService = environment.OPENVIDEO_PRIVATE_CONFIG_ROOT
    ? createJianyingTtsPresetsService({
        privateConfigRoot: environment.OPENVIDEO_PRIVATE_CONFIG_ROOT,
        settingsPath: resolve(environment.OPENVIDEO_PRIVATE_CONFIG_ROOT, 'jianying-tts-presets.json'),
      })
    : null
  const jianyingTtsPresetsHandler = jianyingTtsPresetsService
    ? createJianyingTtsPresetsHandler({ service: jianyingTtsPresetsService })
    : async () => new Response(JSON.stringify({
        error: {
          code: 'JIANYING_TTS_PRESETS_UNAVAILABLE',
          message: 'The local Jianying TTS presets service is unavailable.',
        },
      }), {
        status: 503,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      })
  const jianyingVoiceCatalogHandler = jianyingTtsPresetsService
    ? createJianyingVoiceCatalogHandler({ catalog: createJianyingVoiceCatalogService(), presetsService: jianyingTtsPresetsService })
    : async () => new Response(JSON.stringify({ error: { code: 'JIANYING_TTS_VOICE_CATALOG_UNAVAILABLE' } }), { status: 503, headers: { 'content-type': 'application/json; charset=utf-8' } })
  const jianyingLocalTts = createJianyingLocalTts()
  const jianyingDraftHandler = createJianyingDraftHandler({
    service: jianyingDraftRuntime.service,
    registry: jianyingDraftRuntime.registry,
  })
  /** @type {(request: Request) => Promise<Response>} */
  let jianyingDraftMinerHandler = async () => new Response(JSON.stringify({
    error: { code: 'NATIVE004_DISCOVERY_UNAVAILABLE', message: 'Jianying draft discovery is unavailable.' },
  }), { status: 503, headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8' } })
  /** @type {(request: Request) => Promise<Response>} */
  let jianyingNativeEvidencePreflightHandler = async () => new Response(JSON.stringify({
    error: { code: 'NATIVE004_EVIDENCE_UNAVAILABLE', message: 'No valid evidence preflight receipt is available.' },
  }), { status: 503, headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8' } })
  /** @type {(() => Promise<Record<string, any>>) | null} */
  let refreshNativeEvidencePreflight = null
  /** @type {Promise<void> | null} */
  let nativeEvidenceStartupRecoveryPromise = null
  /** @type {((value?: unknown) => void) | null} */
  let resolveNativeEvidenceStartupRecoveryReady = null
  /** @type {(() => Promise<void>) | null} */
  let nativeEvidenceStartupRecoveryStart = null
  /** @type {(() => Promise<Record<string, any> | null>) | null} */
  let loadCurrentNativeEvidenceReceipt = null
  const syntheticWorkbench = environment.OPENVIDEO_WORKBENCH_MODE === 'synthetic'
  const localRuntimeConfig = syntheticWorkbench
    ? null
    : loadLocalRuntimeConfig(environment)
  // One server instance owns one byte-identity verification cache. The early
  // Writer capability check warms the exact same cache used by current-catalog
  // and Native evidence reads, avoiding a second cold decrypt without weakening
  // the loader's catalog/evidence/draft/desktop mutation invalidation.
  const runtimePackagingResourceVerificationCache = new Map()
  // PROD-HOTFIX-007: one securer for the whole boot window. It hardens the first uncovered root
  // immediately and defers the redundant same-tree walks to a single finalize() below, so the launch
  // pays two powershell.exe spawns instead of ten for the same final ACL state.
  const bootPrivateRootSecurer = createBootPrivateRootSecurer()
  const securePrivateRoot = bootPrivateRootSecurer.securePrivateRoot
  const repositories = localRuntimeConfig
    ? await createJsonRepositories({
        dataRoot: localRuntimeConfig.dataRoot,
        securePrivateRoot,
      })
    : undefined
  if (!syntheticWorkbench && !repositories) {
    throw new Error('Production workbench repositories are unavailable.')
  }
  if (localRuntimeConfig) {
    const draftMinerRepository = await createDraftMinerJobRepository({
      filePath: resolve(localRuntimeConfig.dataRoot, 'jianying-draft-miner-jobs.json'),
    })
    // NATIVE-004 deliberately wires the durable boundary before a real 11.3
    // decoder/authorization adapter exists. The capability remains fail-closed.
    const draftMinerService = createDraftMinerJobService({
      repository: draftMinerRepository,
      authorize: async () => false,
      miner: {
        async mine() {
          throw Object.assign(new Error('NATIVE004_DISCOVERY_UNAVAILABLE'), { code: 'NATIVE004_DISCOVERY_UNAVAILABLE' })
        },
      },
    })
    jianyingDraftMinerHandler = createJianyingDraftMinerHandler({ service: draftMinerService })
  }

  const localApiTokenRoot = localRuntimeConfig?.dataRoot
    || (typeof environment.OPENVIDEO_PRIVATE_CONFIG_ROOT === 'string'
      && environment.OPENVIDEO_PRIVATE_CONFIG_ROOT.trim()
      ? environment.OPENVIDEO_PRIVATE_CONFIG_ROOT.trim()
      : null)
  runtimeDiagnostics.initialize(localRuntimeConfig ? join(localRuntimeConfig.dataRoot, 'runtime-diagnostics.json') : null)
  bootPhase('repositories')
  const localApiToken = await createOrLoadLocalApiToken(localApiTokenRoot)
  // Serve the existing root StartupGate once its cookie and private boundary are safe.
  // Knowledge loading and catalog initialization do not need to delay this read-only shell.
  bootPhase('local-api-token')
  const staticWebHandler = await createStaticWebHandler({ webRoot })
  bootPhase('static-web')

  const port = parseGatewayPort(environment.OPENVIDEO_GATEWAY_PORT)
  /** @param {import('node:http').ServerResponse} outgoing @param {Response} response */
  const writeHttpResponse = async (outgoing, response) => {
    outgoing.writeHead(response.status, Object.fromEntries(response.headers.entries()))
    if (!response.body) {
      outgoing.end()
    } else {
      await pipeline(Readable.fromWeb(/** @type {any} */ (response.body)), outgoing)
    }
  }
  /** @type {(incoming: import('node:http').IncomingMessage, outgoing: import('node:http').ServerResponse) => Promise<void>} */
  let activeRequestListener = async (incoming, outgoing) => {
    try {
      /** @type {[string, string][]} */
      const headers = []
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (Array.isArray(value)) {
          for (const entry of value) headers.push([name, entry])
        } else if (value !== undefined) {
          headers.push([name, value])
        }
      }
      const requestPath = String(incoming.url ?? '/').split('?', 1)[0]
      const trustProbe = new Request(`http://127.0.0.1:${port}${requestPath}`, {
        method: incoming.method,
        headers,
      })
      if (!isTrustedLocalHttpRequest(trustProbe)) {
        await writeHttpResponse(outgoing, new Response(JSON.stringify({
          error: { code: 'UNTRUSTED_LOCAL_REQUEST', message: 'Request origin is not trusted.' },
        }), { status: 403, headers: { 'content-type': 'application/json; charset=utf-8' } }))
        return
      }
      const request = new Request(`http://localhost:${port}${incoming.url ?? '/'}`, {
        method: incoming.method,
        headers,
      })
      const pathname = new URL(request.url).pathname
      const response = pathname === '/api/live'
        ? await livenessHandler(request)
        : pathname.startsWith('/api/')
          ? new Response(JSON.stringify({
              error: {
                code: 'OPENVIDEO_STARTING',
                message: 'The workbench runtime is still starting.',
              },
              startup: { ...startupState },
            }), {
              status: 503,
              headers: {
                'cache-control': 'no-store',
                'content-type': 'application/json; charset=utf-8',
                'retry-after': '1',
              },
            })
          : await staticWebHandler(request)
      if (response.headers.get('content-type')?.startsWith('text/html')) {
        response.headers.set('set-cookie', localApiSessionCookie(localApiToken))
      }
      await writeHttpResponse(outgoing, response)
    } catch (error) {
      if (isExpectedClientDisconnect(error, incoming, outgoing)) return
      if (!outgoing.headersSent) {
        outgoing.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
      }
      outgoing.end(JSON.stringify({ error: { code: 'INTERNAL_ERROR', message: 'The gateway request failed.' } }))
    }
  }
  const server = createServer((incoming, outgoing) => {
    activeRequestListener(incoming, outgoing).catch(() => {
      if (!outgoing.headersSent) outgoing.writeHead(500)
      outgoing.end()
    })
  })
  // Establish the bounded recovery promise before the shell starts listening.
  // The actual Native service is wired below; resolving this gate then starts
  // recovery without delaying the read-only startup page.
  if (localRuntimeConfig) {
    nativeEvidenceStartupRecoveryPromise = (async () => {
      await new Promise((resolve) => {
        resolveNativeEvidenceStartupRecoveryReady = resolve
      })
      const startRecovery = /** @type {(() => Promise<void>) | null} */ (nativeEvidenceStartupRecoveryStart)
      if (startRecovery) await startRecovery()
    })()
  }
  await bootPrivateRootSecurer.verify()
  try {
    server.listen(port, '127.0.0.1')
    await once(server, 'listening')
  } catch (error) {
    throw error
  }
  bootPhase('startup-listen')
  log(`OpenVideo startup shell listening on http://127.0.0.1:${port}`)

  /** @type {ReturnType<typeof createWorkbenchJobCoordinator> | undefined} */
  let jobCoordinator
  /** @type {ReturnType<typeof createCreativeShadowPlanner> | null} */
  let creativeShadowPlanner = null
  try {

  try {
    creativeKnowledge = await creativeKnowledgeLoader()
    log(`OPENVIDEO_CREATIVE_KNOWLEDGE_READY: recipes=${creativeKnowledge.summary.recipeCount} fingerprint=${creativeKnowledge.summary.fingerprint}`)
  } catch (error) {
    const code = error && typeof error === 'object' && 'code' in error
      ? String(error.code)
      : 'CREATIVE_KNOWLEDGE_UNAVAILABLE'
    runtimeDiagnostics.record({ component: 'creative-knowledge', code, severity: 'warning' })
    warn({ event: 'creative_knowledge_unavailable', code })
  }
  if (creativeTechniqueMode !== 'off' || creativeAudioCueMode !== 'off') {
    try {
      creativeTechniqueKnowledge = await creativeKnowledgeLoader({ release: 'v2' })
      log(
        `OPENVIDEO_CREATIVE_TECHNIQUES_READY: mode=${creativeTechniqueMode} `
        + `audio_cues=${creativeAudioCueMode} `
        + `rules=${creativeTechniqueKnowledge.summary.techniqueRuleCount} `
        + `fingerprint=${creativeTechniqueKnowledge.summary.fingerprint}`,
      )
    } catch (error) {
      const code = error && typeof error === 'object' && 'code' in error
        ? String(error.code)
        : 'CREATIVE_TECHNIQUE_KNOWLEDGE_UNAVAILABLE'
      runtimeDiagnostics.record({ component: 'creative-techniques', code, severity: 'warning' })
      warn({ event: 'creative_techniques_disabled', code })
    }
  }
  bootPhase('creative-knowledge')
  const localPickerService = createLocalPickerService()
  const localPickerHandler = createLocalPickerHandler({ service: localPickerService })
  const resourceCompatibilityManifest = JSON.parse(await readFile(jianyingCompatibilityManifestUrl, 'utf8'))
  /** @type {(request: Request) => Promise<Response>} */
  let jianyingPrivateResourceCatalogHandler = async () => new Response(JSON.stringify({ error: { code: 'JY135_RESOURCE_ROOTS_REQUIRED' } }), {
    status: 503,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  })
  /** CapCut Mate is an optional import-only catalog and never gates aggregate readiness. */
  /** Server-private aggregate only; populated after Native resource service bootstraps. */
  /** @type {() => Promise<Record<string, any> | null>} */
  let exactBindingDiagnostics = async () => null
  const capCutCatalogService = localRuntimeConfig
    ? createCapCutCatalogService({
        dataRoot: localRuntimeConfig.dataRoot,
        sourceRoot: typeof environment.OPENVIDEO_CAPCUT_MATE_SNAPSHOT_ROOT === 'string' && environment.OPENVIDEO_CAPCUT_MATE_SNAPSHOT_ROOT.trim()
          ? environment.OPENVIDEO_CAPCUT_MATE_SNAPSHOT_ROOT.trim()
          : null,
        detectDesktop: () => detectJianyingDesktop({ compatibilityManifest: resourceCompatibilityManifest }),
        exactBindingDiagnostics: () => exactBindingDiagnostics(),
      })
    : null
  const jianyingCapCutCatalogHandler = capCutCatalogService
    ? createCapCutCatalogHandler({ service: capCutCatalogService })
    : async () => new Response(JSON.stringify({ error: { code: 'PACKAGING_CATALOG_RUNTIME_UNAVAILABLE' } }), {
        status: 503,
        headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8' },
      })
  /** @type {((input: {index: Record<string, any> | null, profileId: string | null, appVersion: string | null}) => Promise<{ready: boolean, profileId?: string | null, appVersion?: string | null, catalogFingerprint?: string | null}>) | null} */
  let jianyingPackagingReadinessResolver = null
  /** @type {(() => Promise<{recommend: Function, index: Record<string, any>} | null>) | null} */
  let jianyingPackagingProviderResolver = null
  /** @type {(() => Promise<Record<string, any> | null>) | null} */
  let jianyingPackagingSnapshotResolver = null
  /** @type {(() => Promise<Record<string, any> | null>) | null} */
  let jianyingDuoPackagingSnapshotResolver = null
  /** @type {(request: Request) => Promise<Response>} */
  let jianyingDuoProbationaryHandler = async () => new Response(JSON.stringify({
    error: { code: 'JY200_DUO_PROBATIONARY_UNAVAILABLE', message: 'The probationary Duo route is unavailable.' },
  }), { status: 503, headers: { 'content-type': 'application/json; charset=utf-8' } })
  /** @type {Awaited<ReturnType<typeof createJY200DuoProbationaryWorkbenchCapability>> | null} */
  let jianyingDuoProbationaryCapability = null
  /** @type {Record<string, any> | null} */
  let creativeCapabilitySnapshot = null
  /** @type {(request: Request) => Promise<Response>} */
  let jianyingResourceRootSettingsHandler = async () => new Response(JSON.stringify({ error: { code: 'JY175_SETTINGS_UNAVAILABLE' } }), {
    status: 503,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  })
  if (localRuntimeConfig && environment.OPENVIDEO_PRIVATE_CONFIG_ROOT) {
    const privateRepositories = /** @type {NonNullable<typeof repositories>} */ (repositories)
    try {
      const detectDesktop = () => detectJianyingDesktop({ compatibilityManifest: resourceCompatibilityManifest })
      const rootSettingsService = createJianyingResourceRootSettingsService({
        detectDesktop,
      })
      jianyingResourceRootSettingsHandler = createJianyingResourceRootSettingsHandler({
        service: rootSettingsService,
      })
      const providerInvocation = createServerOwnedProviderCatalogInvocation({
        detectDesktop,
        // The contract is wired at the server boundary, but the real draft
        // resolver/decoder remains an explicit private runtime dependency.
        // Until configured, user-draft intake fails closed with NATIVE017.
        providers: {
          user_draft: createUserDraftCatalogProvider({
            resolveAuthorization: async (authorizationId) => {
              const record = await privateRepositories.authorizationRepository.get(authorizationId)
              return record
                ? { ...record, authorizationId: record.id, expired: false, revoked: record.status !== 'authorized' }
                : null
            },
            extractCatalog: async ({ authorization, desktop }) => {
              const decoded = await createJianyingPrivateDraftDecoder().extract({ authorization, desktop })
              return {
                entries: decoded.entries,
                catalogFingerprint: decoded.catalogFingerprint,
                sourceFingerprint: decoded.sourceFingerprint,
              }
            },
          }),
        },
        persist: /** @type {(input: {catalog: Record<string, any>}) => Promise<unknown>} */ (({ catalog }) => persistJianyingPrivateResourceCatalog({
          catalog,
          dataRoot: localRuntimeConfig.dataRoot,
          fileName: NATIVE018_PRIVATE_DRAFT_CATALOG_FILENAME,
        })),
      })
      const privateDraftSourceFingerprintValidator = createJianyingPrivateDraftSourceFingerprintValidator()
      const resourceService = createJianyingPrivateResourceCatalogService({
        dataRoot: localRuntimeConfig.dataRoot,
        resolveRoots: async () => rootSettingsService.resolvePrivate(),
        detectDesktop,
        loadAdmittedIndex: async (desktop, candidateCatalogFingerprint, { captureEvidence, captureCatalogCandidates } = {}) => loadPackagingResourceIndexForProduction({
          dataRoot: localRuntimeConfig.dataRoot,
          candidateCatalogFingerprint,
          verificationCache: runtimePackagingResourceVerificationCache,
          desktop: {
            profileId: desktop.profileId,
            version: desktop.version,
            executablePath: desktop.executablePath,
            installRoot: desktop.installRoot,
            dllFingerprint: desktop.dllFingerprint,
            draftRoot: desktop.draftRoot,
          },
          captureEvidence,
          captureCatalogCandidates,
        }),
        validatePrivateSourceBinding: async ({ draftAuthorizationId, sourceFingerprint }) => {
          const authorization = await privateRepositories.authorizationRepository.get(draftAuthorizationId)
          if (!authorization || authorization.status !== 'authorized' || authorization.readOnly !== true ||
              typeof authorization.absolutePath !== 'string') return false
          try {
            return await privateDraftSourceFingerprintValidator.compute({
              authorizationId: draftAuthorizationId,
              draftFolder: authorization.absolutePath,
            }) === sourceFingerprint
          } catch {
            return false
          }
        },
        invokeProvider: providerInvocation.invoke,
      })
      exactBindingDiagnostics = async () => {
        const snapshot = /** @type {Record<string, any> | null} */ (await resourceService.nativeEvidenceSnapshot().catch(() => null))
        const nativeEntries = snapshot && Number.isSafeInteger(snapshot.entries) ? snapshot.entries : 0
        const packagingIndex = snapshot?.packagingIndex && typeof snapshot.packagingIndex === 'object'
          ? /** @type {Record<string, any>} */ (snapshot.packagingIndex)
          : null
        const admittedEntries = Array.isArray(packagingIndex?.entries) ? packagingIndex.entries.length : 0
        const exact = snapshot && capCutCatalogService?.exactBindingDiagnostics
          ? await capCutCatalogService.exactBindingDiagnostics({
              match: async (entry) => exactNativeEntry(entry, snapshot) !== null,
            }).catch(() => null)
          : null
        const exactDiagnostics = /** @type {{qualified?: unknown, reasons?: unknown} | null} */ (exact) ?? {}
        return {
          qualified: Number.isSafeInteger(exactDiagnostics.qualified) ? exactDiagnostics.qualified : 0,
          reasons: {
            ...(exactDiagnostics.reasons && typeof exactDiagnostics.reasons === 'object'
              ? exactDiagnostics.reasons
              : { current_native_intersection_unavailable: 1 }),
            native_discovery_entries: nativeEntries,
            native_admitted_entries: admittedEntries,
          },
        }
      }
      // Start one read-only verification before the bounded startup refresh.
      // It cannot publish a receipt; it only warms the same byte-identity cache
      // that every later observation revalidates against current private bytes.
      const nativeEvidenceVerificationWarmup = resourceService.workbenchPackagingSnapshot()
        .catch(() => null)
      /** @param {unknown} value @returns {Record<string, any> | null} */
      const toNativeEvidenceIdentity = (value) => {
        if (!value || typeof value !== 'object' || Array.isArray(value)) return null
        const evidence = /** @type {Record<string, any>} */ (value)
        const bindings = Array.isArray(evidence.admitted_bindings)
          ? evidence.admitted_bindings.map((binding) => ({
              packaging_token: binding?.packaging_token ?? null,
              family: binding?.family ?? null,
              binding_fingerprint: binding?.binding_fingerprint ?? null,
              target_start_us: binding?.target_start_us ?? null,
              target_duration_us: binding?.target_duration_us ?? null,
            })).sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))
          : []
        if (typeof evidence.evidence_id !== 'string' || typeof evidence.draft_id !== 'string' ||
            typeof evidence.catalog_fingerprint !== 'string' || typeof evidence.post_save_fingerprint !== 'string' ||
            typeof evidence.content_fingerprint !== 'string' || typeof evidence.integrity_signature !== 'string') return null
        return {
          evidenceId: evidence.evidence_id,
          draftId: evidence.draft_id,
          bundleFingerprint: evidence.bundle_fingerprint ?? null,
          preOpenFingerprint: evidence.pre_open_fingerprint ?? null,
          postSaveFingerprint: evidence.post_save_fingerprint,
          contentFingerprint: evidence.content_fingerprint,
          catalogFingerprint: evidence.catalog_fingerprint,
          integrityRevision: evidence.integrity_revision ?? null,
          integritySignature: evidence.integrity_signature,
          admittedBindings: bindings,
          admittedBindingCount: bindings.length,
        }
      }
      /** @param {Record<string, any> | null} snapshot @returns {Record<string, any> | null} */
      const nativeEvidenceIdentityFromSnapshot = (snapshot) => {
        if (!snapshot || typeof snapshot !== 'object') return null
        const evidenceIdentity = toNativeEvidenceIdentity(snapshot.packagingEvidence)
        return {
          profileId: typeof snapshot.profileId === 'string' ? snapshot.profileId : null,
          appVersion: typeof snapshot.appVersion === 'string' ? snapshot.appVersion : null,
          catalogAvailable: snapshot.catalogAvailable === true,
          entries: Number.isSafeInteger(snapshot.entries) ? Number(snapshot.entries) : 0,
          families: Array.isArray(snapshot.families) ? [...snapshot.families].sort() : [],
          catalogFingerprint: typeof snapshot.catalogFingerprint === 'string' ? snapshot.catalogFingerprint : null,
          resourceRootCount: Number.isSafeInteger(snapshot.resourceRootCount) ? Number(snapshot.resourceRootCount) : 0,
          rootSetFingerprint: typeof snapshot.rootSetFingerprint === 'string' ? snapshot.rootSetFingerprint : null,
          desktopAvailable: snapshot.desktopAvailable === true,
          draftAvailable: snapshot.draftAvailable === true,
          // A catalog/index is only an availability projection. Lifecycle
          // admission exists only when the independently verified receipt
          // identity is present and carries at least one bound placement.
          admitted: evidenceIdentity?.admittedBindingCount > 0,
          evidenceIdentity,
          admittedBindingCount: evidenceIdentity?.admittedBindingCount ?? 0,
        }
      }
      const readCurrentNativeEvidenceIdentity = createStableNativeEvidenceIdentityReader({
        readIdentity: async () => nativeEvidenceIdentityFromSnapshot(
          /** @type {Record<string, any>} */ (await resourceService.nativeEvidenceSnapshot({ forceCatalogReload: false })),
        ),
      })
      const nativeEvidenceRefreshGate = createNativeEvidenceRefreshGate({
        operation: async ({ isCurrent } = { isCurrent: () => true }) => {
            /** @type {Record<string, any> | null} */
            let snapshot = null
            /** @type {Record<string, any> | null} */
            let verifiedAdmission = null
            /** @type {Record<string, any> | null} */
            let verifiedLifecycleEvidence = null
            await nativeEvidenceVerificationWarmup
            snapshot = await resourceService.nativeEvidenceSnapshot({ forceCatalogReload: false })
            const receipt = await runNativeEvidencePreflight({
              // The initial Native snapshot already performed the trusted
              // desktop/root observation and full evidence verification. Reuse
              // only its safe state here; the complete current snapshot is read
              // again below before publication.
              detectDesktop: async () => ({
                available: snapshot?.desktopAvailable === true,
                profileId: typeof snapshot?.profileId === 'string' ? snapshot.profileId : null,
                version: typeof snapshot?.appVersion === 'string' ? snapshot.appVersion : null,
              }),
              summarizeRoots: async () => ({
                available: Number.isSafeInteger(snapshot?.resourceRootCount) && snapshot.resourceRootCount > 0,
                rootCount: Number.isSafeInteger(snapshot?.resourceRootCount) ? snapshot.resourceRootCount : 0,
                jsonFiles: 0,
                bytes: 0,
              }),
              summarizeCatalog: async () => {
                return {
                  available: snapshot?.catalogAvailable === true,
                  entries: Number.isSafeInteger(snapshot?.entries) ? Number(snapshot.entries) : 0,
                  families: Array.isArray(snapshot?.families) ? snapshot.families : [],
                  profileId: typeof snapshot?.profileId === 'string' ? snapshot.profileId : null,
                  appVersion: typeof snapshot?.appVersion === 'string' ? snapshot.appVersion : null,
                }
              },
              summarizeEvidence: async (/** @type {Record<string, any> | null} */ detectedDesktop) => {
                verifiedAdmission = /** @type {Record<string, any> | null} */ (snapshot?.packagingIndex ?? null)
                verifiedLifecycleEvidence = /** @type {Record<string, any> | null} */ (snapshot?.packagingEvidence ?? null)
                const evidence = /** @type {Record<string, any>} */ (verifiedLifecycleEvidence ?? {})
                const admitted = Boolean(verifiedAdmission) && Boolean(evidence) &&
                  snapshot?.profileId === detectedDesktop?.profileId && snapshot?.appVersion === detectedDesktop?.version &&
                  evidence.catalog_fingerprint === snapshot?.catalogFingerprint &&
                  evidence.profile_id === detectedDesktop?.profileId && evidence.app_version === detectedDesktop?.version &&
                  evidence.manual_evidence_verified === true && evidence.opened === true && evidence.edited === true &&
                  evidence.saved === true && evidence.reopened === true && evidence.same_draft === true
                return {
                  available: admitted,
                  receiptCount: admitted ? evidence.admitted_bindings.length : 0,
                  sameDraftReceipts: admitted ? (evidence.same_draft ? 1 : 0) : 0,
                  openedEditedSavedReopened: admitted,
                  profileId: admitted ? detectedDesktop?.profileId ?? null : null,
                  appVersion: admitted ? detectedDesktop?.version ?? null : null,
                }
              },
              resolveEvidenceIdentity: async () => toNativeEvidenceIdentity(verifiedLifecycleEvidence),
              resolveCodec: async (/** @type {Record<string, any> | null} */ detectedDesktop) => {
                const currentSnapshot = /** @type {Record<string, any> | null} */ (snapshot)
                const supported = Boolean(verifiedAdmission) &&
                  currentSnapshot?.profileId === detectedDesktop?.profileId && currentSnapshot?.appVersion === detectedDesktop?.version
                return { scheme: supported ? 'encrypt_v2' : null, supported }
              },
              resolveDraftAvailability: async () => snapshot?.draftAvailable === true,
              catalogFingerprint: typeof (/** @type {Record<string, any> | null} */ (snapshot))?.catalogFingerprint === 'string'
                ? /** @type {Record<string, any>} */ (snapshot).catalogFingerprint
                : null,
              rootIdentityFingerprint: typeof snapshot?.rootSetFingerprint === 'string' ? snapshot.rootSetFingerprint : null,
            })
            // A timed-out refresh must stop before a second full identity read,
            // otherwise stale background work can delay the current request.
            if (!isCurrent()) throw new Error('NATIVE004_PREFLIGHT_STALE')
            const latestSnapshot = /** @type {Record<string, any> | null} */ (
              await resourceService.nativeEvidenceSnapshot({ forceCatalogReload: false })
            )
            const initialIdentity = nativeEvidenceIdentityFromSnapshot(snapshot)
            const latestIdentity = nativeEvidenceIdentityFromSnapshot(latestSnapshot)
            if (!initialIdentity || !latestIdentity ||
                JSON.stringify(initialIdentity) !== JSON.stringify(latestIdentity) ||
                !isNativeEvidencePreflightReceiptCurrent(receipt, latestIdentity)) {
              throw new Error('NATIVE004_PREFLIGHT_STALE')
            }
            if (!isCurrent()) throw new Error('NATIVE004_PREFLIGHT_STALE')
            await publishNativeEvidencePreflightReceipt({ dataRoot: localRuntimeConfig.dataRoot, receipt, secureRoot: securePrivateRoot, isCurrent })
            return Object.freeze({ receipt, identity: latestIdentity })
        },
      })
      refreshNativeEvidencePreflight = async (timeoutMs = 15_000) => {
        const result = await nativeEvidenceRefreshGate.run({ timeoutMs })
        return result && typeof result === 'object' && 'receipt' in result ? result.receipt : result
      }
      // Start the same bounded recovery as soon as its private resource service
      // exists. It remains a release gate below, but overlaps unrelated runtime
      // construction instead of starting only after every factory is ready.
      nativeEvidenceStartupRecoveryStart = async () => {
        const nativeEvidenceReceiptRoot = join(localRuntimeConfig.dataRoot, 'evidence', 'native-004')
        await mkdir(nativeEvidenceReceiptRoot, { recursive: true, mode: 0o700 })
        await securePrivateRoot(nativeEvidenceReceiptRoot)
        try {
          const adopted = await adoptCurrentNativeEvidenceStartupReceipt({
            loadReceipt: () => loadNativeEvidencePreflightReceipt({ dataRoot: localRuntimeConfig.dataRoot }),
            readIdentity: readCurrentNativeEvidenceIdentity,
          })
          if (adopted) return
          const refresh = /** @type {((timeoutMs?: number) => Promise<Record<string, any>> | Promise<unknown>) | null} */ (refreshNativeEvidencePreflight)
          if (!refresh) throw new Error('NATIVE004_EVIDENCE_REFRESH_UNAVAILABLE')
          await runNativeEvidenceStartupRecovery({
            refresh,
            attempts: 3,
            backoffMs: 250,
          })
        } catch (error) {
          runtimeDiagnostics.record({
            component: 'jianying-native-evidence',
            code: error instanceof Error && error.message === 'NATIVE004_PREFLIGHT_TIMEOUT'
              ? 'NATIVE004_PREFLIGHT_TIMEOUT'
              : 'NATIVE004_EVIDENCE_REFRESH_FAILED',
            severity: 'warn',
          })
        }
      }
      const resolveReady = /** @type {((value?: unknown) => void) | null} */ (resolveNativeEvidenceStartupRecoveryReady)
      if (resolveReady) resolveReady()
      loadCurrentNativeEvidenceReceipt = async () => {
        // Load receipt bytes first, then make the two temporally ordered
        // observations. Starting identity reads alongside the receipt would
        // require another full post-receipt stability pass: that repeated
        // private verification can exhaust the public 14-second budget while
        // adding no stronger guarantee than a single ordered post-read.
        const receipt = await loadNativeEvidencePreflightReceipt({ dataRoot: localRuntimeConfig.dataRoot })
        if (!receipt) return null
        // The stable reader makes exactly two ordered full observations after
        // the bytes arrived. It rejects any catalog/profile/evidence drift,
        // including a mutation in flight during the first observation.
        const identity = await readCurrentNativeEvidenceIdentity()
        return isNativeEvidencePreflightReceiptCurrent(receipt, identity) ? receipt : null
      }
      jianyingNativeEvidencePreflightHandler = createJianyingNativeEvidencePreflightHandler({
        loadReceipt: async () => await loadCurrentNativeEvidenceReceipt?.() ?? null,
      })
      jianyingPrivateResourceCatalogHandler = createJianyingPrivateResourceCatalogHandler({ service: resourceService })
      jianyingPackagingReadinessResolver = () => resourceService.workbenchReadiness()
      const nativePackagingProviderResolver = createDynamicJianyingPackagingProviderResolver({
        snapshotResolver: () => resourceService.workbenchPackagingSnapshot(),
        ranker: dynamicPackagingRanker,
      })
      const currentDirectIdProbe = capCutCatalogService
        ? createDirectIdResolutionProbe({
            dataRoot: localRuntimeConfig.dataRoot,
            capCutCatalogService,
            detectDesktop,
            fallbackProbe: defaultDirectIdProbe,
          })
        : defaultDirectIdProbe
      jianyingPackagingProviderResolver = capCutCatalogService
        ? createCapCutCatalogPackagingProviderResolver({
            capCutCatalogService,
            nativeSnapshotResolver: () => resourceService.workbenchPackagingSnapshot(),
            detectDesktop,
            ranker: dynamicPackagingRanker,
            directIdProbe: currentDirectIdProbe,
          })
        : nativePackagingProviderResolver
      jianyingPackagingSnapshotResolver = capCutCatalogService
        ? createCapCutCatalogPackagingExportSnapshotResolver({
            capCutCatalogService,
            nativeSnapshotResolver: () => resourceService.workbenchPackagingSnapshot(),
            detectDesktop,
            directIdProbe: currentDirectIdProbe,
          })
        : () => resourceService.workbenchPackagingSnapshot()
      jianyingDuoPackagingSnapshotResolver = () => resourceService.workbenchDuoPackagingSnapshot()
    } catch { /* malformed or unavailable roots remain fail-closed */ }
  }
  const jianying6RendererSettingsService = environment.OPENVIDEO_PRIVATE_CONFIG_ROOT
      ? createJianying6RendererSettingsService({
        privateConfigRoot: environment.OPENVIDEO_PRIVATE_CONFIG_ROOT,
        settingsPath: resolve(environment.OPENVIDEO_PRIVATE_CONFIG_ROOT, 'jianying6-renderer.json'),
        repositoryRoot: fileURLToPath(new URL('../../..', import.meta.url)),
      })
    : null
  const jianying6RendererSettingsHandler = jianying6RendererSettingsService
      ? createJianying6RendererSettingsHandler({
        service: jianying6RendererSettingsService,
        resolveSelection: (input) => localPickerService.resolveAbsolutePath({
          sessionId: input.sessionId,
          nodeId: input.nodeId,
          expect: 'directory',
        }),
        resolveNativeSelection: pickWindowsFolder,
      })
    : async () => new Response(JSON.stringify({
        error: {
          code: 'JY006_SETTINGS_UNAVAILABLE',
          message: 'The local Jianying 6.x renderer settings service is unavailable.',
        },
      }), {
        status: 503,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      })
  /**
   * @param {{sessionId?: string, nodeId?: string}} input
   * @param {'directory' | 'audio' | 'video' | 'media'} expect
   */
  const resolvePickerAbsolutePath = (input, expect) => {
    try {
      return localPickerService.resolveAbsolutePath({
        sessionId: String(input?.sessionId ?? ''),
        nodeId: String(input?.nodeId ?? ''),
        expect,
      })
    } catch (error) {
      if (error instanceof LocalPickerError) {
        throw new LocalRuntimeError(error.code, error.status)
      }
      throw error
    }
  }

  /** @type {any} */
  let materialLibraryService
  /** @type {Awaited<ReturnType<typeof createMaterialReviewOverlay>> | undefined} */
  let materialReviewOverlay
  /** @type {any} */
  let richTimelineRepository
  /** @type {any} */
  let productionPreviewProvider = blockedPreviewProvider('SHORT_VIDEO_FACTORY_UNAVAILABLE')
  /** @type {any} */
  let referenceTemplateRepository
  /** @type {any} */
  let reusableTemplateLibraryService
  /** @type {ReturnType<typeof createTemplateMediaStore> | undefined} */
  let templateMediaStore
  /** @type {ReturnType<typeof createTemplateBlueprintStore> | null} */
  let templateBlueprintStore = null
  /** @type {any} */
  let projectTemplateAbPreviewStore
  /** @type {any} */
  let productionMaterialAnalysisProvider
  /** @type {any} */
  let productionJianyingDraftCapability
  let jianyingWriterSettingsHandler = createJianyingWriterSettingsHandler({
    read: () => createJianyingWriterSettingsSnapshot({ nativeReady: false }),
  })
  /** @type {Awaited<ReturnType<typeof createTtsStudio>> | undefined} */
  let ttsStudio
  /** @type {Awaited<ReturnType<typeof createBgmLibrary>> | undefined} */
  let bgmLibrary
  /** @type {Awaited<ReturnType<typeof createSfxCatalog>> | undefined} */
  let sfxCatalog
  /** @type {Record<string, Function>} */
  let workbenchCapabilities
  if (syntheticWorkbench) {
    workbenchCapabilities = createSyntheticWorkbenchCapabilities()
  } else {
    const productionRepositories = /** @type {NonNullable<typeof repositories>} */ (repositories)
    const productionConfig = /** @type {NonNullable<typeof localRuntimeConfig>} */ (localRuntimeConfig)
    const materialAnalysisProvider = await createPermissiveMaterialAnalyzer({
      dataRoot: productionConfig.dataRoot,
      authorizationRepository: productionRepositories.authorizationRepository,
      gateway,
    })
    bootPhase('material-analysis')
    productionMaterialAnalysisProvider = materialAnalysisProvider
    const activeMaterialReviewOverlay = await createMaterialReviewOverlay({
      dataRoot: productionConfig.dataRoot,
      securePrivateRoot,
    })
    materialReviewOverlay = activeMaterialReviewOverlay
    applyMaterialReviewOverlayToProvider({ provider: materialAnalysisProvider, overlay: activeMaterialReviewOverlay })
    bootPhase('material-review-overlay')
    const jobRepository = await createWorkbenchJobRepository({
      dataRoot: productionConfig.dataRoot,
      securePrivateRoot,
    })
    const writerPublicationRepository = await createJianyingWriterPublicationRepository({
      dataRoot: productionConfig.dataRoot,
      repositoryRoot: fileURLToPath(new URL('../../..', import.meta.url)),
      securePrivateRoot,
    })
    const editPlanRepository = await createEditPlanRepository({
      dataRoot: productionConfig.dataRoot,
      securePrivateRoot,
    })
    richTimelineRepository = await createRichTimelineRepository({
      dataRoot: productionConfig.dataRoot,
      securePrivateRoot,
    })
    if (creativePlanningMode !== 'off' && creativeKnowledge) {
      try {
        const traceRepository = await createCreativeDecisionTraceRepository({
          dataRoot: productionConfig.dataRoot,
          securePrivateRoot,
        })
        creativeShadowPlanner = createCreativeShadowPlanner({
          knowledge: creativeKnowledge,
          gateway,
          traceRepository,
          contextFactory: creativePlanningMode === 'active'
            ? createCreativePlanningContext
            : null,
          techniquePolicy: creativeTechniqueKnowledge
            ? createCreativeTechniquePolicy({ knowledge: creativeTechniqueKnowledge })
            : null,
          techniqueMode: creativeTechniqueKnowledge ? creativeTechniqueMode : 'off',
          audioCueMode: creativeTechniqueKnowledge ? creativeAudioCueMode : 'off',
          logger: workbenchLogger,
        })
        log(
          `OPENVIDEO_CREATIVE_PLANNING_READY: mode=${creativePlanningMode} `
          + `auto_outputs=${creativeAutoOutputs ? 'on' : 'off'} `
          + `techniques=${creativeTechniqueKnowledge ? creativeTechniqueMode : 'off'} `
          + `audio_cues=${creativeTechniqueKnowledge ? creativeAudioCueMode : 'off'}`,
        )
      } catch (error) {
        const code = error && typeof error === 'object' && 'code' in error
          ? String(error.code)
          : 'CREATIVE_SHADOW_UNAVAILABLE'
        runtimeDiagnostics.record({ component: 'creative-planning', code, severity: 'warning' })
        warn({ event: 'creative_planning_disabled', code })
      }
    }
    try {
      referenceTemplateRepository = await createReferenceTemplateRepository({
        dataRoot: productionConfig.dataRoot,
        securePrivateRoot,
      })
    } catch (error) {
      warn({
        event: 'reference_template_capability_blocked',
        code: error && typeof error === 'object' && 'code' in error
          ? String(error.code)
          : 'REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE',
      })
    }
    const referenceTemplateAdapter = referenceTemplateRepository
      ? createReferenceTemplateAdapter({ materialAnalysisProvider })
      : undefined
    const localAuthorizationCapability = createLocalAuthorizationCapability({
      authorizationRepository: productionRepositories.authorizationRepository,
      dataRoot: productionConfig.dataRoot,
    })
    try {
      materialLibraryService = await createMaterialLibraryService({
        dataRoot: productionConfig.dataRoot,
        projectRepository: productionRepositories.projectRepository,
        authorizationRepository: productionRepositories.authorizationRepository,
        materialAnalysisProvider,
        richTimelineRepository,
        securePrivateRoot,
        authorizeMaterialsFromPath: async (/** @type {{projectId: string, folderLabel?: string, sourceType?: 'auto' | 'file' | 'folder', sessionId?: string, nodeId?: string}} */ input) => {
          const sourceType = input.sourceType === 'file' || input.sourceType === 'folder' || input.sourceType === 'auto'
            ? input.sourceType
            : undefined
          const absolutePath = input.sessionId && input.nodeId
            ? resolvePickerAbsolutePath(input, sourceType === 'file' ? 'video' : sourceType === 'auto' ? 'media' : 'directory')
            : undefined
          return localAuthorizationCapability.authorizeMaterials({
            projectId: input.projectId,
            folderLabel: input.folderLabel,
            readOnlyConfirmed: true,
            ...(sourceType ? { sourceType } : {}),
            absolutePath,
          })
        },
      })
    } catch (error) {
      warn({
        event: 'material_library_capability_blocked',
        code: error && typeof error === 'object' && 'code' in error
          ? String(error.code)
          : 'MATERIAL_LIBRARY_UNAVAILABLE',
      })
    }
    void warmupWindowsNativePickers().then((ready) => {
      if (ready) void ensureWindowsNativePickerHost()
    })
    /**
     * Prefer opaque local-picker nodes when present; otherwise omit absolutePath so
     * local-runtime opens the native Windows Explorer-style folder/file dialog.
     * HTTP handlers must not forward absolutePath. Trusted internal callers (e.g. template
     * media rebinding) may set allowAbsolutePath.
     * @param {{sessionId?: string, nodeId?: string, absolutePath?: string}} input
     * @param {'directory' | 'audio' | 'video' | 'media'} expect
     * @param {{allowAbsolutePath?: boolean}} [options]
     */
    const optionalPickerAbsolutePath = (input, expect, options = {}) => {
      if (
        typeof input?.sessionId === 'string' &&
        input.sessionId.trim() &&
        typeof input?.nodeId === 'string' &&
        input.nodeId.trim()
      ) {
        return { absolutePath: resolvePickerAbsolutePath(input, expect) }
      }
      if (
        options.allowAbsolutePath === true &&
        typeof input?.absolutePath === 'string' &&
        isAbsolute(input.absolutePath)
      ) {
        return { absolutePath: resolve(input.absolutePath) }
      }
      return {}
    }
    const authorizeMaterialsWithPicker = async (/** @type {any} */ input) => {
      const sourceType = input.sourceType === 'file' || input.sourceType === 'folder' || input.sourceType === 'auto'
        ? input.sourceType
        : 'folder'
      return localAuthorizationCapability.authorizeMaterials({
        projectId: input.projectId,
        folderLabel: input.folderLabel,
        sourceType,
        readOnlyConfirmed: true,
        ...optionalPickerAbsolutePath(
          input,
          sourceType === 'file' ? 'video' : sourceType === 'auto' ? 'media' : 'directory',
        ),
      })
    }
    const authorizeBgmWithPicker = async (/** @type {any} */ input) =>
      localAuthorizationCapability.authorizeBgm({
        projectId: input.projectId,
        readOnlyConfirmed: true,
        ...optionalPickerAbsolutePath(input, 'audio', { allowAbsolutePath: true }),
      })
    const authorizeReferenceVideoWithPicker = async (/** @type {any} */ input) =>
      localAuthorizationCapability.authorizeReferenceVideo({
        projectId: input.projectId,
        readOnlyConfirmed: true,
        ...optionalPickerAbsolutePath(input, 'video'),
      })
    const uploadReferenceVideoWithPicker = async (/** @type {any} */ input) =>
      localAuthorizationCapability.uploadReferenceVideo({
        projectId: input.projectId,
        ...optionalPickerAbsolutePath(input, 'video', { allowAbsolutePath: true }),
      })
    const authorizeJianyingDraftWithPicker = async (/** @type {any} */ input) =>
      localAuthorizationCapability.authorizeJianyingDraft({
        projectId: input.projectId,
        purpose: 'reusable_template_draft',
        readOnlyConfirmed: true,
        ...optionalPickerAbsolutePath(input, 'directory', { allowAbsolutePath: true }),
      })
    // BGM indexing and TTS profile loading use separate stores and do not depend on one
    // another. Starting them together removes one full I/O-bound boot phase from the critical path.
    await Promise.all([
      (async () => {
        try {
          const bgmFfprobePath = resolve(
            productionConfig.dataRoot,
            'material-analysis/dependencies/ffmpeg/bin/ffprobe.exe',
          )
          bgmLibrary = await createBgmLibrary({
            dataRoot: productionConfig.dataRoot,
            authorizationRepository: productionRepositories.authorizationRepository,
            authorizeBgm: authorizeBgmWithPicker,
            securePrivateRoot,
            audioProbe: createFfprobeAudioProbe({ ffprobePath: bgmFfprobePath }),
            warn,
          })
        } catch (error) {
          warn({
            event: 'bgm_library_capability_blocked',
            code: error && typeof error === 'object' && 'code' in error
              ? String(error.code)
              : 'BGM_LIBRARY_UNAVAILABLE',
          })
        }
      })(),
      (async () => {
        if (!runningHubSettingsService) return
        try {
          ttsStudio = await createTtsStudio({
            dataRoot: productionConfig.dataRoot,
            authorizationRepository: productionRepositories.authorizationRepository,
            settingsService: runningHubSettingsService,
            securePrivateRoot,
            ffmpegPath: resolve(productionConfig.dataRoot, 'material-analysis/dependencies/ffmpeg/bin/ffmpeg.exe'),
            resolveAudioPath: (/** @type {{sessionId: string, nodeId: string}} */ input) =>
              resolvePickerAbsolutePath(input, 'audio'),
          })
        } catch (error) {
          warn({
            event: 'tts_studio_capability_blocked',
            code: error && typeof error === 'object' && 'code' in error
              ? String(error.code)
              : 'TTS_STUDIO_UNAVAILABLE',
          })
        }
      })(),
    ])
    const activeBgmLibrary = bgmLibrary
    if (activeBgmLibrary) {
      try {
        const generatedSfxLibrary = await createGeneratedSfxLibrary({
          dataRoot: productionConfig.dataRoot,
          securePrivateRoot,
        })
        const sfxAudioLibrary = Object.freeze({
          isAuthorizedTrack: (/** @type {{projectId: string, trackId: string}} */ input) =>
            input.projectId === generatedSfxProjectId
              ? generatedSfxLibrary.isAuthorizedTrack(input)
              : activeBgmLibrary.isAuthorizedTrack(input),
          acquireTrackLease: (/** @type {{projectId: string, trackId: string}} */ input) =>
            input.projectId === generatedSfxProjectId
              ? generatedSfxLibrary.acquireTrackLease(input)
              : activeBgmLibrary.acquireTrackLease(input),
          describeTrack: (/** @type {{projectId: string, trackId: string}} */ input) =>
            input.projectId === generatedSfxProjectId
              ? generatedSfxLibrary.describeTrack(input)
              : activeBgmLibrary.describeTrack(input),
        })
        sfxCatalog = await createSfxCatalog({
          dataRoot: productionConfig.dataRoot,
          audioLibrary: sfxAudioLibrary,
          globalProjectId: generatedSfxProjectId,
          inspectAudio: createFfprobeSfxInspector({
            ffprobePath: resolve(
              productionConfig.dataRoot,
              'material-analysis/dependencies/ffmpeg/bin/ffprobe.exe',
            ),
          }),
          securePrivateRoot,
        })
        for (const entry of generatedSfxLibrary.listCatalogEntries()) {
          await sfxCatalog.register(entry)
        }
      } catch (error) {
        warn({
          event: 'sfx_catalog_capability_blocked',
          code: error && typeof error === 'object' && 'code' in error
            ? String(error.code)
            : 'SFX_CATALOG_UNAVAILABLE',
        })
      }
    }
    const activeSfxCatalog = sfxCatalog
    projectTemplateAbPreviewStore = null
    const ffmpegBinary = resolve(
      productionConfig.dataRoot,
      'material-analysis/dependencies/ffmpeg/bin/ffmpeg.exe',
    )
    const jianyingPresetNarration = jianyingTtsPresetsService
      ? createJianyingPresetNarration({
          presetsService: jianyingTtsPresetsService,
          localTts: jianyingLocalTts,
          dataRoot: productionConfig.dataRoot,
          ffmpegPath: existsSync(ffmpegBinary) ? ffmpegBinary : 'ffmpeg',
        })
      : null
    bootPhase('tts-studio')
    const narrationProvider = await createJianyingVoiceoverProvider({
      dataRoot: productionConfig.dataRoot,
      securePrivateRoot,
      voice: environment.OPENVIDEO_JY002_SYSTEM_SPEECH_VOICE || null,
      ttsStudio,
      jianyingPresetNarration: jianyingPresetNarration ?? undefined,
      ffprobePath: resolve(
        productionConfig.dataRoot,
        'material-analysis/dependencies/ffmpeg/bin/ffprobe.exe',
      ),
    })
    bootPhase('narration-provider')
    productionPreviewProvider = await loadProductionPreviewProvider({
      dataRoot: productionConfig.dataRoot,
      securePrivateRoot,
      environment,
      warn,
      authorizationRepository: productionRepositories.authorizationRepository,
      acquireBgmLease: activeBgmLibrary
        ? (/** @type {{projectId: string, authorizationId: string}} */ { projectId, authorizationId }) => activeBgmLibrary.acquireTrackLease({
            projectId,
            trackId: authorizationId,
          })
        : undefined,
      ttsStudio,
      jianyingPresetNarration,
      narrationProvider,
      resolveSfxAudio: async (/** @type {{audioToken: string, projectId: string}} */ { audioToken, projectId }) => {
        if (audioToken.startsWith('tma_') && templateMediaStore) {
          const project = await productionRepositories.projectRepository.get(projectId)
          const libraryTemplateId = project?.templateBinding?.libraryTemplateId
          if (typeof libraryTemplateId === 'string') {
            const templatePath = await templateMediaStore.resolveAudioPath(libraryTemplateId, audioToken)
            if (typeof templatePath === 'string' && isAbsolute(templatePath)) return templatePath
          }
        }
        const catalogLease = await activeSfxCatalog?.acquireAudio({ projectId, audioToken })
        if (catalogLease) return catalogLease
        // Compatibility path for an explicitly authorized pre-catalog SFX.
        // Automatic semantic placement consumes only catalog resolutions.
        return activeBgmLibrary?.acquireTrackLease({ projectId, trackId: audioToken }) ?? null
      },
    })
    bootPhase('preview-provider')
    // Template-library setup and Jianying environment/catalog admission are independent during
    // boot. Start the slower Jianying work first; its template resolvers dereference the stores
    // only when an export later runs, after both initialization promises have settled.
    const jianyingDraftCapabilityResultPromise = loadProductionJianyingCapability({
      dataRoot: productionConfig.dataRoot,
      environment,
      materialAnalysisProvider,
      authorizationRepository: productionRepositories.authorizationRepository,
      acquireBgmLease: activeBgmLibrary
        ? (/** @type {{projectId: string, authorizationId: string}} */ { projectId, authorizationId }) => activeBgmLibrary.acquireTrackLease({
            projectId,
            trackId: authorizationId,
          })
        : undefined,
      resolveSfxAudio: async (/** @type {{audioToken: string, projectId: string, workId: string, signal: AbortSignal}} */ input) => {
        let materialized = await activeSfxCatalog?.materializeAudio(input)
        if (materialized || !activeSfxCatalog || !/^bgm_[a-f0-9]{24}$/u.test(input.audioToken)) return materialized ?? null
        // Existing projects may carry an explicitly authorized local SFX
        // token from before the semantic SFX catalog existed. The persisted
        // SFX selection is the rights confirmation; register it into the
        // private catalog, then use the same governed materialization path.
        await activeSfxCatalog.registerAuthorizedTrack({
          projectId: input.projectId,
          audioToken: input.audioToken,
          rightsConfirmed: true,
        })
        materialized = await activeSfxCatalog.materializeAudio(input)
        return materialized ?? null
      },
      ttsStudio,
      jianyingPresetNarration,
      voiceoverProvider: narrationProvider,
      resolveTemplateAudioPath: async (/** @type {{libraryTemplateId: string, audioToken: string}} */ input) =>
        templateMediaStore?.resolveAudioPath(input.libraryTemplateId, input.audioToken) ?? null,
      resolveTemplatePackagingToken: async (/** @type {{libraryTemplateId: string, packagingToken: string}} */ input) => {
        if (!templateMediaStore) return null
        const resolved = await templateMediaStore.resolvePackagingToken(
          input.libraryTemplateId,
          input.packagingToken,
        )
        return toJianyingPackagingResolution(resolved)
      },
      resolveTemplateBlueprint: async (/** @type {{blueprintId: string, fingerprint: string}} */ input) =>
        templateBlueprintStore?.resolvePrivateFolder(input.blueprintId, input.fingerprint) ?? null,
      resolvePackagingSnapshot: jianyingPackagingSnapshotResolver ?? undefined,
      readProjectTemplateBinding: async (/** @type {string} */ projectId) => {
        const project = await productionRepositories.projectRepository.get(projectId)
        return project?.templateBinding ?? null
      },
      sfxCatalogSnapshot: activeSfxCatalog?.snapshot(generatedSfxProjectId) ?? null,
      packagingResourceVerificationCache: runtimePackagingResourceVerificationCache,
      warn,
    }).then(
      (capability) => ({ capability, error: null }),
      (error) => ({ capability: undefined, error }),
    )
    if (referenceTemplateRepository && referenceTemplateAdapter) {
      try {
        const ffmpegPath = resolve(
          productionConfig.dataRoot,
          'material-analysis/dependencies/ffmpeg/bin/ffmpeg.exe',
        )
        const ffprobePath = resolve(
          productionConfig.dataRoot,
          'material-analysis/dependencies/ffmpeg/bin/ffprobe.exe',
        )
        const styleAnalyzer = createTemplateStyleAnalyzer({
          ffmpegPath: existsSync(ffmpegPath) ? ffmpegPath : null,
          ffprobePath: existsSync(ffprobePath) ? ffprobePath : null,
          tempRoot: resolve(productionConfig.dataRoot, 'tmp/template-style'),
        })
        const demoRenderer = createTemplateDemoRenderer({
          ffmpegPath: existsSync(ffmpegPath) ? ffmpegPath : null,
          previewProvider: productionPreviewProvider,
        })
        const activeTemplateMediaStore = createTemplateMediaStore({
          dataRoot: productionConfig.dataRoot,
          ffmpegPath: existsSync(ffmpegPath) ? ffmpegPath : null,
          demoRenderer,
          styleAnalyzer,
        })
        templateMediaStore = activeTemplateMediaStore
        /** @type {ReturnType<typeof createJianyingDraftDecryptor> | null} */
        let draftDecryptor = null
        try {
          const compatibilityManifest = JSON.parse(
            await readFile(jianyingCompatibilityManifestUrl, 'utf8'),
          )
          const desktop = await detectJianyingDesktop({ compatibilityManifest })
          const installDir = resolveVideoEditorInstallDir(desktop.installRoot, desktop.version)
          if (installDir) {
            draftDecryptor = createJianyingDraftDecryptor({
              installRoot: desktop.installRoot,
              installDir,
              appVersion: desktop.version,
              expectedDllFingerprint: desktop.dllFingerprint,
            })
          }
        } catch (error) {
          warn({
            event: 'jianying_draft_decrypt_unavailable',
            code: error && typeof error === 'object' && 'code' in error
              ? String(error.code)
              : 'JY_TEMPLATE_DECRYPT_INSTALL_MISSING',
          })
        }
        templateBlueprintStore = createTemplateBlueprintStore({
          dataRoot: productionConfig.dataRoot,
          ensurePlaintextDraftContent: draftDecryptor
            ? (absolutePath) => draftDecryptor.ensurePlaintextFile(absolutePath, absolutePath, { allowInPlace: true })
            : undefined,
        })
        const jianyingUpstreamRoot = (
          environment.OPENVIDEO_PYJIANYINGDRAFT_ROOT ||
          environment.OPENVIDEO_JY002_PYTHON_MODULE_ROOT ||
          ''
        ).trim()
        const resolvedJianyingUpstream = jianyingUpstreamRoot && isAbsolute(jianyingUpstreamRoot)
          ? resolve(jianyingUpstreamRoot)
          : resolve(
            fileURLToPath(new URL('../../../../open video/upstream/pyJianYingDraft', import.meta.url)),
          )
        const jianyingTemplateReader = createJianyingTemplateReader({
          pythonModuleRoot: resolvedJianyingUpstream,
          expectedCommit: 'c3318066d964744e2bfc66f75c71745fe8cea52a',
          decryptHelperPath: draftDecryptor?.helperPath || null,
          jianyingInstallDir: draftDecryptor?.installDir || null,
          jianyingAppVersion: draftDecryptor?.appVersion || null,
        })
        const reusableTemplateRepository = await createReusableTemplateRepository({
          dataRoot: productionConfig.dataRoot,
          securePrivateRoot,
          migrationSource: () =>
            referenceTemplateRepository.listApprovedForLibraryMigration(),
          resolvePreviewAvailability: (libraryTemplateId) =>
            activeTemplateMediaStore.previewAvailability(libraryTemplateId),
          resolveStyleSummary: (libraryTemplateId) =>
            activeTemplateMediaStore.readStyleSummary(libraryTemplateId),
          resolveReplicationRecipe: (libraryTemplateId) =>
            activeTemplateMediaStore.readReplicationRecipe(libraryTemplateId),
        })
        reusableTemplateLibraryService = createReusableTemplateLibraryService({
          repository: reusableTemplateRepository,
          authorizationRepository: productionRepositories.authorizationRepository,
          referenceTemplateAdapter,
          uploadReferenceVideo: uploadReferenceVideoWithPicker,
          authorizeJianyingDraft: authorizeJianyingDraftWithPicker,
          cleanupReferenceUpload: localAuthorizationCapability.revokeReferenceUpload,
          templateMediaStore: activeTemplateMediaStore,
          templateBlueprintStore,
          jianyingTemplateReader,
          isVoiceProfileReady: async (/** @type {unknown} */ voiceProfileId) => {
            if (typeof voiceProfileId !== 'string') return false
            if (isCuratedVoiceId(voiceProfileId)) return true
            if (isJianyingPresetVoiceId(voiceProfileId) && jianyingTtsPresetsService) {
              const voices = await jianyingTtsPresetsService.listVoices()
              return voices.some((voice) => voice.id === voiceProfileId && voice.ready === true)
            }
            return typeof ttsStudio?.isProfileReady === 'function'
              ? ttsStudio.isProfileReady(voiceProfileId)
              : false
          },
        })
        if (productionPreviewProvider && typeof productionPreviewProvider.renderPreview === 'function') {
          projectTemplateAbPreviewStore = createProjectTemplateAbPreviewStore({
            dataRoot: productionConfig.dataRoot,
            previewProvider: productionPreviewProvider,
          })
        }
      } catch (error) {
        warn({
          event: 'reusable_template_capability_blocked',
          code: error && typeof error === 'object' && 'code' in error
            ? String(error.code)
            : 'REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE',
        })
      }
    }
    bootPhase('template-capabilities')
    const jianyingDraftCapabilityResult = await awaitBoundedJianyingStartupCapability(
      jianyingDraftCapabilityResultPromise,
    )
    if (jianyingDraftCapabilityResult.timedOut) {
      runtimeDiagnostics.record({
        component: 'jianying-native',
        code: 'JY_STARTUP_CAPABILITY_TIMEOUT',
        severity: 'warning',
      })
      warn({ event: 'jianying_startup_capability_timeout', code: 'JY_STARTUP_CAPABILITY_TIMEOUT' })
    }
    if (jianyingDraftCapabilityResult.error) throw jianyingDraftCapabilityResult.error
    const nativeJianyingDraftCapability = jianyingDraftCapabilityResult.capability
    const recoverableJianyingWriter = nativeJianyingDraftCapability
      ? createRecoverableJianyingWriterOwnerCapability({
          nativeCapability: nativeJianyingDraftCapability,
          ownerRepository: writerPublicationRepository.ownerRepository,
        })
      : null
    // JY-200 product routing is receipt-bound and remains fail-closed until a
    // separately issued product admission is present. Technical-only Duo
    // lifecycle receipts therefore keep the existing Native path unchanged.
    /** @type {any} */
    let duoAdmission = null
    /** @type {any} */
    let duoProductRunner = null
    /** @type {(() => Promise<{recommend: Function, index: Record<string, any>} | null>) | null} */
    let duoPackagingProviderResolver = null
    /** @type {'GO' | null} */
    let duoGateADecision = null
    /** @type {string | null} */
    let duoLiveDraftRoot = null
    let duoRouteBound = false
    if (nativeJianyingDraftCapability && jianyingPackagingSnapshotResolver) {
      /** @type {'runtime_helpers'|'manifest'|'integrity_key'|'desktop'|'admission_resolver'|'feasibility'|'installed_runtime'|'runner'|'probationary_capability'} */
      let duoInitializationStage = 'runtime_helpers'
      const duoStartupPromise = (async () => {
          /** @type {ReturnType<typeof createJY200DuoCurrentAdmissionResolver> | null} */
          let duoAdmission = null
          /** @type {any} */
          let duoProductRunner = null
          /** @type {(() => Promise<{recommend: Function, index: Record<string, any>} | null>) | null} */
          let duoPackagingProviderResolver = null
          /** @type {'GO' | null} */
          let duoGateADecision = null
          /** @type {string | null} */
          let duoLiveDraftRoot = null
          /** @type {Awaited<ReturnType<typeof createJY200DuoProbationaryWorkbenchCapability>> | null} */
          let jianyingDuoProbationaryCapability = null
          try {
        const duoRuntimeHelpers = await loadDuoRuntimeHelpers()
        duoInitializationStage = 'manifest'
        const duoManifest = JSON.parse(await readFile(new URL('../../../config/duo-video-upstream.json', import.meta.url), 'utf8'))
        duoGateADecision = duoManifest?.direct_probe?.gate_a_decision === 'GO' ? 'GO' : null
        duoInitializationStage = 'integrity_key'
        const duoIntegrityKey = await loadPackagingResourceEvidenceIntegrityKey({
          evidenceRoot: resolve(productionConfig.dataRoot, 'evidence', 'jy132-packaging-resources'),
        })
        const runtimeResolver = async () => {
          const runtime = await duoRuntimeHelpers.inspectJY200DuoInstalledRuntime({
            dataRoot: productionConfig.dataRoot,
            manifest: duoManifest,
            executePrivateJava: true,
          })
          if (!runtime?.available || !runtime.privateJava?.inventoryFingerprint) return runtime
          return Object.freeze({
            ...runtime,
            writerBuildDigest: runtime.buildDigest,
            buildDigest: fingerprintJY200DuoProductRuntime({
              writerBuildDigest: runtime.buildDigest,
              javaInventoryFingerprint: runtime.privateJava.inventoryFingerprint,
            }),
          })
        }
        duoInitializationStage = 'desktop'
        const duoDesktop = await detectJianyingDesktop({ compatibilityManifest: resourceCompatibilityManifest })
        duoLiveDraftRoot = typeof duoDesktop?.draftRoot === 'string' ? duoDesktop.draftRoot : null
        duoInitializationStage = 'admission_resolver'
        duoAdmission = createJY200DuoCurrentAdmissionResolver({
          // Duo's current user-draft catalog is independently bound by the
          // Duo receipt. Do not make it depend on Native's unrelated JY132
          // evidence registry, which may legitimately describe another
          // scanner catalog on the same desktop.
          snapshotResolver: () => jianyingDuoPackagingSnapshotResolver?.(),
          runtimeResolver,
          integrityKey: duoIntegrityKey,
          receiptResolver: () => readJY200DuoAdmissionReceipt(
            environment.OPENVIDEO_JY200_DUO_ADMISSION_PATH ||
              resolve(productionConfig.dataRoot, 'evidence', 'jy200-duo-admission.json'),
            productionConfig.dataRoot,
          ),
        })
        duoInitializationStage = 'feasibility'
        // The catalog service is also warmed by the Native evidence path. Do
        // one Duo-scoped read before resolving admission so a concurrent
        // force-refresh cannot permanently freeze this boot as Native-only.
        // A second read is bounded and still uses the same signed identity
        // checks; it does not relax admission or expose private bindings.
        const duoSnapshotWarmup = await jianyingDuoPackagingSnapshotResolver?.()
        if (!duoSnapshotWarmup) await jianyingDuoPackagingSnapshotResolver?.()
        let admittedForProductRoute = await duoAdmission.resolveCurrentAdmission()
        // Installation and private catalog verification can finish on
        // separate asynchronous paths during Launcher startup. Retry the
        // same strict resolver a bounded number of times so a transient
        // empty snapshot does not freeze this process as Native-only.
        for (let attempt = 1; !admittedForProductRoute && attempt < 3; attempt += 1) {
          await new Promise((resolve) => setTimeout(resolve, 200))
          admittedForProductRoute = await duoAdmission.resolveCurrentAdmission()
        }
        const feasibility = admittedForProductRoute
          ? admittedForProductRoute
          : await duoAdmission.resolveCurrentFeasibility()
        // Construction must not depend on a one-time startup catalog snapshot.
        // The probationary capability revalidates current feasibility before it
        // claims an owner, so a transient startup miss remains fail-closed while
        // a later-current snapshot can recover without restarting the Gateway.
        {
          duoInitializationStage = 'installed_runtime'
          const installedRuntime = await runtimeResolver()
          if (installedRuntime?.available) {
            const runnerInput = {
              dataRoot: productionConfig.dataRoot,
              repositoryRoot: fileURLToPath(new URL('../../..', import.meta.url)),
              liveDraftRoot: /** @type {string} */ (duoLiveDraftRoot),
              manifest: duoManifest,
              installedRuntime,
              profileId: nativeJianyingDraftCapability.desktopProfile?.profileId,
              appVersion: nativeJianyingDraftCapability.desktopProfile?.version,
              integrityKey: duoIntegrityKey,
              runVerified: duoRuntimeHelpers.runVerifiedJY200DuoRuntime,
              publishReceipt: duoRuntimeHelpers.publishJY200DuoExecutionReceipt,
            }
            const resolveFrozenRuntimeBindings = async (/** @type {Record<string, any>} */ writePlan) => {
              if (!Array.isArray(writePlan?.trustedBindings) || writePlan.trustedBindings.length !== 3) {
                throw new Error('JY200_DUO_PRODUCT_BINDING_INVALID')
              }
              return writePlan.trustedBindings.map((/** @type {Record<string, any>} */ binding) => {
                const resourceId = binding?.privateBinding?.resourceId
                if (typeof resourceId !== 'string' || typeof binding?.family !== 'string' ||
                    !binding.publicBinding || typeof binding.publicBinding !== 'object') {
                  throw new Error('JY200_DUO_PRODUCT_BINDING_INVALID')
                }
                return Object.freeze({
                  family: /** @type {'flower'|'sticker'|'video_effect'} */ (binding.family),
                  resourceId,
                  ...(typeof binding.privateBinding.effectId === 'string'
                    ? { effectId: binding.privateBinding.effectId }
                    : {}),
                  relativeConfigPath: `${binding.family}/${resourceId}.json`,
                  publicEvidence: binding.publicBinding,
                })
              })
            }
            const resolveDuoAudioSources = createJY200DuoAudioSourceResolver({
              narrationProvider,
              bgmLibrary: activeBgmLibrary,
              sfxCatalog: activeSfxCatalog,
              templateMediaStore,
              projectRepository: productionRepositories.projectRepository,
            })
            Object.assign(runnerInput, { resolveAudioSources: resolveDuoAudioSources })
            duoInitializationStage = 'runner'
            const executionRunner = createJY200DuoProductRunner({
              ...runnerInput,
              resolveRuntimeBindings: resolveFrozenRuntimeBindings,
            })
            if (feasibility && duoGateADecision === 'GO') {
              // A current admitted binding set may safely narrow Workbench
              // recommendations before the optional Duo Writer route is
              // enabled. This only selects catalog tokens already covered by
              // both Native admission and Duo evidence; it does not issue a
              // Writer handle or change Settings/Router selection.
              duoPackagingProviderResolver = createDynamicJianyingPackagingProviderResolver({
                snapshotResolver: duoAdmission.resolveCurrentPackagingSnapshot,
                ranker: dynamicPackagingRanker,
              })
            }
            // Retain the installed, verified runner even when the catalog and
            // admission observations are not yet concurrent. It remains
            // unreachable from the Writer router until the strict admission
            // check in activateDuoStartupResult succeeds.
            duoProductRunner = executionRunner
            // Keep a bounded verification route available for capability expansion even
            // when an older, narrower product admission remains current. This route never
            // issues an admitted handle or changes Writer Settings/Router selection.
            duoInitializationStage = 'probationary_capability'
            jianyingDuoProbationaryCapability = await createJY200DuoProbationaryWorkbenchCapability({
              ownerRepository: writerPublicationRepository.ownerRepository,
              publicationRepository: writerPublicationRepository,
              resolveCurrentFeasibility: duoAdmission.resolveCurrentFeasibility,
              runtimeRoot: resolve(productionConfig.dataRoot, 'external-writer-staging'),
              liveDraftRoot: /** @type {string} */ (duoLiveDraftRoot),
              repositoryRoot: fileURLToPath(new URL('../../..', import.meta.url)),
              resolveCurrentBindings: async () => {
                const bindings = await duoAdmission?.resolveCurrentFeasibilityBindings()
                if (!bindings) throw new Error('JY200_DUO_PRODUCT_BINDING_INVALID')
                return /** @type {any} */ (bindings)
              },
              run: async ({ resolveLeaseRoot, writePlan }) => executionRunner.run({
                stagingRoot: await resolveLeaseRoot(),
                writePlan,
              }),
              inspectReadback: (input) => executionRunner.inspectReadback(/** @type {any} */ (input)),
            })
          }
        }
          } catch (error) {
        const privateCode = error && typeof error === 'object' && 'code' in error &&
          typeof error.code === 'string' && /^JY200_[A-Z0-9_]+$/u.test(error.code)
          ? error.code
          : error instanceof Error && /^JY200_[A-Z0-9_]+$/u.test(error.message)
            ? error.message
            : `JY200_DUO_INITIALIZATION_${duoInitializationStage.toUpperCase()}_FAILED`
        runtimeDiagnostics.record({ component: 'jianying-duo', code: privateCode, severity: 'info' })
        warn({
          event: 'jy200_duo_product_route_unavailable',
          code: privateCode,
        })
        duoAdmission = null
          duoProductRunner = null
          duoPackagingProviderResolver = null
          }
          return Object.freeze({
            duoAdmission,
            duoProductRunner,
            duoPackagingProviderResolver,
            duoGateADecision,
            duoLiveDraftRoot,
            jianyingDuoProbationaryCapability,
          })
          })()
      /** @param {Awaited<typeof duoStartupPromise>} startupResult */
      const activateDuoStartupResult = async (startupResult) => {
        if (!startupResult) return false
        duoAdmission = startupResult.duoAdmission
        duoProductRunner = startupResult.duoProductRunner
        duoPackagingProviderResolver = startupResult.duoPackagingProviderResolver
        duoGateADecision = startupResult.duoGateADecision
        duoLiveDraftRoot = startupResult.duoLiveDraftRoot
        jianyingDuoProbationaryCapability = startupResult.jianyingDuoProbationaryCapability
        const activeAdmission = duoAdmission
        const activeRunner = duoProductRunner
        const admitted = await activeAdmission?.resolveCurrentAdmission?.().catch(() => null)
        if (!admitted || !activeAdmission || !activeRunner || !recoverableJianyingWriter) return false
        const recoveredCapability = await createJY200DuoServerPrivateWriterCapability({
          nativeCapability: nativeJianyingDraftCapability,
          preferredProvider: 'duo-video',
          ownerRepository: writerPublicationRepository.ownerRepository,
          publicationRepository: writerPublicationRepository,
          resolveCurrentAdmission: activeAdmission.resolveCurrentAdmission,
          runtimeRoot: resolve(productionConfig.dataRoot, 'external-writer-staging'),
          liveDraftRoot: /** @type {string} */ (duoLiveDraftRoot),
          repositoryRoot: fileURLToPath(new URL('../../..', import.meta.url)),
          resolveCurrentBindings: activeAdmission.resolveCurrentBindings,
          run: async ({ resolveLeaseRoot, writePlan }) => activeRunner.run({
            stagingRoot: await resolveLeaseRoot(),
            writePlan,
          }),
          inspectReadback: (input) => activeRunner.inspectReadback(input),
        })
        const activated = recoverableJianyingWriter.activate(recoveredCapability)
        duoRouteBound = true
        if (activated) {
          runtimeDiagnostics.record({ component: 'jianying-duo', code: 'JY200_DUO_ROUTE_RECOVERED', severity: 'info' })
          log('JY200_DUO_ROUTE_RECOVERED')
        }
        return activated
      }
      /** @param {Awaited<typeof duoStartupPromise>} startupResult */
      const recoverDuoRoute = async (startupResult) => {
        if (await activateDuoStartupResult(startupResult)) return true
        if (!startupResult?.duoAdmission || !startupResult?.duoProductRunner) return false
        // Native catalog warmup and the independently signed Duo observation
        // can settle on different startup paths. Retry only the strict,
        // cached admission resolver; never rebuild or weaken evidence.
        for (let attempt = 0; attempt < 12; attempt += 1) {
          await new Promise((resolve) => {
            const timer = setTimeout(resolve, 5_000)
            timer.unref?.()
          })
          if (duoRouteBound || await activateDuoStartupResult(startupResult)) return true
        }
        runtimeDiagnostics.record({
          component: 'jianying-duo',
          code: 'JY200_DUO_ADMISSION_NOT_CURRENT',
          severity: 'info',
        })
        return false
      }
      // Duo is optional. Keep its signed runtime/catalog/admission checks intact,
      // but never make the Native workbench wait for them during startup.
      runtimeDiagnostics.record({
        component: 'jianying-duo',
        code: 'JY200_DUO_BACKGROUND_INITIALIZATION',
        severity: 'info',
      })
      void duoStartupPromise.then(recoverDuoRoute).catch((error) => {
        const code = error instanceof Error && /^JY200_[A-Z0-9_]+$/u.test(error.message)
          ? error.message
          : 'JY200_DUO_LATE_RECOVERY_FAILED'
        runtimeDiagnostics.record({ component: 'jianying-duo', code, severity: 'info' })
        warn({ event: 'jy200_duo_late_recovery_failed', code })
      })
    } else {
      runtimeDiagnostics.record({
        component: 'jianying-duo',
        code: nativeJianyingDraftCapability
          ? 'JY200_DUO_PACKAGING_SNAPSHOT_UNAVAILABLE'
          : 'JY200_DUO_NATIVE_CAPABILITY_UNAVAILABLE',
        severity: 'info',
      })
    }
    /** @type {any} */
    const jianyingDraftCapability = recoverableJianyingWriter?.capability
    const currentDuoAdmission = await duoAdmission?.resolveCurrentAdmission?.().catch(() => null)
    const currentDuoFeasibility = currentDuoAdmission
      ? currentDuoAdmission
      : await duoAdmission?.resolveCurrentFeasibility?.().catch(() => null)
    // Settings must never advertise Duo as ready until the recoverable Writer
    // has bound the current signed route during this boot.
    duoRouteBound = duoRouteBound || Boolean(currentDuoAdmission && duoProductRunner)
    /** @param {unknown} value */
    const json = (value) => new Response(JSON.stringify(value), {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    })
    /** @param {number} status @param {string} code */
    const errorJson = (status, code) => new Response(JSON.stringify({ error: { code } }), {
      status,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    })
    /** @param {unknown} value @param {number} [depth] @returns {boolean} */
    const containsPrivatePathField = (value, depth = 0) => {
      if (depth > 12 || value === null || typeof value !== 'object') return false
      if (Array.isArray(value)) return value.some((entry) => containsPrivatePathField(entry, depth + 1))
      return Object.entries(value).some(([key, entry]) =>
        /(?:^|_)(?:path|root|staging|lease)(?:$|_)/iu.test(key) || containsPrivatePathField(entry, depth + 1))
    }
    // This handler is intentionally stable. The background startup swaps in a
    // current capability only after the same private admission checks succeed.
    jianyingDuoProbationaryHandler = async (request) => {
      if (request.method !== 'POST') return errorJson(405, 'JY200_DUO_PROBATIONARY_METHOD_NOT_ALLOWED')
      let body
      try {
        body = await request.json()
      } catch {
        return errorJson(400, 'JY200_DUO_PROBATIONARY_INPUT_INVALID')
      }
      if (!body || typeof body !== 'object' || Array.isArray(body) || containsPrivatePathField(body) ||
          typeof body.jobId !== 'string' || typeof body.projectId !== 'string' ||
          Object.hasOwn(body, 'authorizationId') || !body.richTimeline || typeof body.richTimeline !== 'object') {
        return errorJson(400, 'JY200_DUO_PROBATIONARY_INPUT_INVALID')
      }
      const probationaryCapability = /** @type {any} */ (jianyingDuoProbationaryCapability)
      if (!probationaryCapability) {
        return errorJson(503, 'JY200_DUO_PROBATIONARY_UNAVAILABLE')
      }
      if (typeof productionMaterialAnalysisProvider?.resolvePreviewSources !== 'function') {
        return errorJson(409, 'JY200_DUO_PROBATIONARY_MATERIALS_UNAVAILABLE')
      }
      try {
        const materialRequest = resolveJY200DuoProbationaryMaterialRequest(body)
        const resolvedMaterials = await productionMaterialAnalysisProvider.resolvePreviewSources(materialRequest)
        const result = await probationaryCapability.exportDraft({
          ...body,
          resolvedMaterials,
        })
        return json(result)
      } catch (/** @type {any} */ error) {
        const { status, code: stableCode } = normalizeJY200DuoProbationaryFailure(error)
        const privateStage = typeof error?.privateStage === 'string' &&
          /^[a-z][a-z0-9_]*$/u.test(error.privateStage)
          ? error.privateStage.toUpperCase()
          : null
        runtimeDiagnostics.record({
          component: 'jianying-duo-probationary',
          code: privateStage ? `${stableCode}_${privateStage}` : stableCode,
          severity: 'warning',
        })
        return errorJson(status, stableCode)
      }
    }
    let writerSettingsSnapshot = createJianyingWriterSettingsSnapshot({
      nativeReady: Boolean(jianyingDraftCapability),
      duoState: duoRouteBound
        ? { state: 'ready', enabled: true, selected: true, reason: null }
        : currentDuoFeasibility
          ? duoGateADecision === 'GO'
            ? { state: 'go', enabled: false, selected: false, reason: 'JY200_PRODUCT_ADMISSION_PENDING' }
            : { state: 'technical_go', enabled: false, selected: false, reason: 'JY200_PRODUCT_ADMISSION_PENDING' }
          : undefined,
    })
    let writerSettingsSnapshotAt = Date.now()
    /** @type {Promise<void> | null} */
    let writerSettingsRefresh = null
    jianyingWriterSettingsHandler = createJianyingWriterSettingsHandler({
      read: async () => {
        if (Date.now() - writerSettingsSnapshotAt >= 1_000 && !writerSettingsRefresh) {
          writerSettingsRefresh = (async () => {
            const admitted = await duoAdmission?.resolveCurrentAdmission?.().catch(() => null)
            const feasibility = admitted ?? await duoAdmission?.resolveCurrentFeasibility?.().catch(() => null)
            writerSettingsSnapshot = createJianyingWriterSettingsSnapshot({
              nativeReady: Boolean(jianyingDraftCapability),
              duoState: admitted && duoRouteBound
                ? { state: 'ready', enabled: true, selected: true, reason: null }
                : feasibility
                  ? duoGateADecision === 'GO'
                    ? { state: 'go', enabled: false, selected: false, reason: 'JY200_PRODUCT_ADMISSION_PENDING' }
                    : { state: 'technical_go', enabled: false, selected: false, reason: 'JY200_PRODUCT_ADMISSION_PENDING' }
                  : undefined,
            })
            writerSettingsSnapshotAt = Date.now()
          })().catch(() => {}).finally(() => { writerSettingsRefresh = null })
        }
        return writerSettingsSnapshot
      },
    })
    bootPhase('jianying-capability')
    productionJianyingDraftCapability = jianyingDraftCapability
    const liveCreativeRegistry = createEditorCapabilityRegistry({
      jianyingProfileId: jianyingDraftCapability?.desktopProfile?.profileId ?? null,
      privateCatalogCapabilities: jianyingDraftCapability?.privateCatalogCapabilities ?? [],
      evidencedCapabilities: jianyingDraftCapability?.evidencedCapabilities ?? [],
      promotionReceipts: jianyingDraftCapability?.promotionReceipts ?? [],
    })
    creativeCapabilitySnapshot = Object.freeze({
      schema_version: 1,
      registry_fingerprint: liveCreativeRegistry.registryFingerprint,
      allowed_capability_ids: Object.freeze(allowedCreativeCapabilityIds(
        liveCreativeRegistry.list().capabilities,
      )),
    })
    const compatibilityManifest = JSON.parse(
      await readFile(jianyingCompatibilityManifestUrl, 'utf8'),
    )
    const jianyingDesktopLauncher = createJianyingDesktopLauncher({
      detectDesktop: () => detectJianyingDesktop({ compatibilityManifest }),
    })
    jobCoordinator = createWorkbenchJobCoordinator({
      jobRepository,
      editPlanRepository,
      richTimelineRepository,
      projectRepository: productionRepositories.projectRepository,
      materialAnalysisProvider,
      director,
      previewProvider: productionPreviewProvider,
      referenceTemplateAdapter,
      referenceTemplateRepository,
      jianyingDraftCapability,
      llmGateway: gateway,
      bgmLibrary: activeBgmLibrary,
      narrationProvider,
      creativeShadowPlanner,
      creativePlanningMode: creativeShadowPlanner ? creativePlanningMode : 'off',
      creativeTechniqueMode: creativeShadowPlanner ? creativeTechniqueMode : 'off',
      creativeAudioCueMode: creativeShadowPlanner ? creativeAudioCueMode : 'off',
      resolveCreativeSfxCue: activeSfxCatalog
        ? (/** @type {{projectId: string, semanticFamily: string, importance: string, desiredDurationUs: number, tags?: string[]}} */ input) => activeSfxCatalog.resolveCue(input)
        : null,
      creativeAutoOutputs: Boolean(creativeShadowPlanner && creativeAutoOutputs),
      resolveMaterialLibrarySceneBinding: materialLibraryService
        ? ({ projectId, sceneId }) => materialLibraryService.resolveSceneBinding(projectId, sceneId)
        : null,
      listStoryboardSearchScopes: materialLibraryService
        ? (projectId) => materialLibraryService.listStoryboardSearchScopes(projectId)
        : null,
      listReferencedAssetIds: materialLibraryService
        ? (projectId) => materialLibraryService.referencedAssetIds(projectId)
        : null,
      batchTextCatalog: jianyingDraftCapability?.batchTextCatalog ?? null,
      materialAnalysisRuntimeRoot: productionConfig.dataRoot,
      materialAnalysisTempRoot: resolve(productionConfig.dataRoot, 'material-analysis', 'tmp'),
      packagingResourceIndex: jianyingDraftCapability?.packagingResourceIndex ?? null,
      packagingRecommendationFamilies: jianyingDraftCapability?.packagingRecommendationFamilies ?? null,
      jianyingProfileId: jianyingDraftCapability?.desktopProfile?.profileId ?? null,
      jianyingAppVersion: jianyingDraftCapability?.desktopProfile?.version ?? null,
      readPackagingReadiness: jianyingPackagingReadinessResolver
        ? (input) => jianyingPackagingReadinessResolver(input)
        : undefined,
      resolvePackagingProvider: jianyingPackagingProviderResolver
        ? async () => jianyingPackagingProviderResolver()
        : undefined,
      privateCatalogCapabilities: jianyingDraftCapability?.privateCatalogCapabilities ?? [],
      evidencedCapabilities: jianyingDraftCapability?.evidencedCapabilities ?? [],
      promotionReceipts: jianyingDraftCapability?.promotionReceipts ?? [],
      logger: workbenchLogger,
      ...loadWorkbenchJobConfig(environment),
    })
    const productionPreflight = createProductionWorkbenchPreflight({
      referenceTemplateRepository,
      jianyingDraftCapability,
      authorizationRepository: productionRepositories.authorizationRepository,
      bgmLibrary: activeBgmLibrary,
      ttsStudio,
      jianyingTtsPresetsService,
    })
    const editorMaterialTools = createEditorMaterialTools({
      projectRepository: productionRepositories.projectRepository,
      materialAnalysisProvider,
      listSearchScopes: materialLibraryService
        ? (projectId) => materialLibraryService.listStoryboardSearchScopes(projectId)
        : null,
      resolveInspectScope: materialLibraryService
        ? async (projectId, candidateId) => {
            const binding = await materialLibraryService.resolveSceneBinding(projectId, candidateId)
            if (!binding?.projectId || !binding?.authorizationId) return null
            return {
              projectId: binding.projectId,
              authorizationId: binding.authorizationId,
            }
          }
        : null,
    })
    const productionTtsStudio = ttsStudio
    workbenchCapabilities = {
      ...localAuthorizationCapability,
      authorizeMaterials: authorizeMaterialsWithPicker,
      authorizeReferenceVideo: authorizeReferenceVideoWithPicker,
      uploadReferenceVideo: uploadReferenceVideoWithPicker,
      ...(activeBgmLibrary
        ? { authorizeBgm: (/** @type {{projectId: string, readOnlyConfirmed: true, sessionId: string, nodeId: string}} */ input) => activeBgmLibrary.authorizeTrack(input) }
        : {}),
      ...materialAnalysisProvider,
      ...productionPreflight,
      launchJianyingDesktop: () => jianyingDesktopLauncher.launch(),
      search_materials: editorMaterialTools.searchMaterials,
      inspect_candidate: editorMaterialTools.inspectCandidate,
      ...(productionTtsStudio || jianyingTtsPresetsService
        ? {
            listVoices: async () => {
              const runningHub = productionTtsStudio ? await productionTtsStudio.listProfiles() : []
              const presets = jianyingTtsPresetsService
                ? await jianyingTtsPresetsService.listVoices()
                : []
              return [...runningHub, ...presets]
            },
          }
        : {}),
      deleteProjectData: async (/** @type {{projectId: string}} */ input) => {
        const analysisDeleted = await materialAnalysisProvider.deleteProjectAnalysis(input)
        const bgmDeleted = activeBgmLibrary
          ? await activeBgmLibrary.deleteProjectTracks(input)
          : await purgeBgmProjectResiduals({
            dataRoot: productionConfig.dataRoot,
            projectId: input.projectId,
            authorizationRepository: productionRepositories.authorizationRepository,
          })
        const authorizationsDeleted = await localAuthorizationCapability.deleteProjectAuthorizations(input)
        return analysisDeleted === true && bgmDeleted === true && authorizationsDeleted === true
      },
      deletePreviewResource: (/** @type {{projectId: string, resourceId: string}} */ input) =>
        productionPreviewProvider.deleteResource(input),
      finalizeVideo: async (/** @type {{projectId: string, previewResourceId: string, durationSeconds: number}} */ input) => {
        const published = await productionPreviewProvider.publishFinal(input)
        return {
          status: 'ready',
          resourceId: published.resourceId,
          durationSeconds: input.durationSeconds,
          updatedAt: new Date().toISOString(),
        }
      },
    }
  }

  const readinessSource = createCachedReadinessSource(async () => {
    const probe = createBoundedReadinessProbe()
    const [
      llmGatewayReady,
      materialAnalysisReady,
      previewProviderReady,
      jianyingDraftReady,
      referenceTemplatesReady,
      reusableTemplatesReady,
      workbenchRecoveryReady,
    ] = await Promise.all([
      // The LLM probe has an internal retry for transient first-connect
      // failures. It must still participate in the same whole-dependency
      // deadline as every other readiness dependency; otherwise two bounded
      // attempts can outlive the strict 15-second release request budget.
      probe(probeLlmGateway),
      probe(async () => productionMaterialAnalysisProvider?.probeAvailability
        ? productionMaterialAnalysisProvider.probeAvailability()
        : Promise.reject(new Error('MATERIAL_ANALYSIS_UNAVAILABLE'))),
      probe(async () => productionPreviewProvider?.probeAvailability
        ? productionPreviewProvider.probeAvailability()
        : Promise.reject(new Error('SHORT_VIDEO_FACTORY_UNAVAILABLE'))),
      probe(async () => {
        if (!productionJianyingDraftCapability) throw new Error('WORKBENCH_JIANYING_EXPORT_UNAVAILABLE')
        await inspectProductionJianyingEnvironment(environment)
      }),
      probe(async () => referenceTemplateRepository?.probeAvailability
        ? referenceTemplateRepository.probeAvailability()
        : Promise.reject(new Error('REFERENCE_TEMPLATE_CAPABILITY_UNAVAILABLE'))),
      probe(async () => reusableTemplateLibraryService?.probeAvailability
        ? reusableTemplateLibraryService.probeAvailability()
        : Promise.reject(new Error('REUSABLE_TEMPLATE_CAPABILITY_UNAVAILABLE'))),
      probe(async () => {
        const recovery = await workbenchRuntime.recoverPendingProjectMaintenance()
        if (!recovery.ready) throw new Error('WORKBENCH_RECOVERY_PENDING')
        await jobCoordinator?.start()
      }),
    ])
    return createProductionReadiness({
      syntheticWorkbench,
      llmGatewayReady,
      materialAnalysisReady,
      previewProviderReady,
      jianyingDraftReady,
      referenceTemplatesReady,
      reusableTemplatesReady,
      workbenchRecoveryReady,
    })
  })
  const readinessHandler = createReadinessHandler(readinessSource)
  const candidateFfmpegPath = localRuntimeConfig
    ? resolve(localRuntimeConfig.dataRoot, 'material-analysis/dependencies/ffmpeg/bin/ffmpeg.exe')
    : 'ffmpeg'
  const candidateClipCache = createCandidateClipResourceCache()
  const candidateClipLoader = createCandidateClipResourceLoader({ cache: candidateClipCache, maxConcurrent: 2 })
  /** @param {unknown} error */
  const recordCandidateClipFailure = (error) => {
    const candidate = /** @type {{code?: unknown}} */ (error)
    runtimeDiagnostics.record({
      component: 'workbench',
      code: typeof candidate?.code === 'string' ? candidate.code : 'CANDIDATE_CLIP_UNAVAILABLE',
      severity: 'warning',
    })
  }
  const activeBgmLibrary = bgmLibrary
  const workbenchRuntime = createWorkbenchRuntime({
    seedDemo: syntheticWorkbench,
    synthetic: syntheticWorkbench,
    repositories,
    capabilities: workbenchCapabilities,
    jobCoordinator,
    referenceTemplateRepository,
    reusableTemplateLibraryService,
    materialLibraryService,
    materialReviewOverlay,
    projectTemplateAbPreviewStore,
    bgmLibrary: activeBgmLibrary,
    ...(activeBgmLibrary && templateMediaStore
      ? {
          resolveTemplateAudioPath: (/** @type {{libraryTemplateId: string, audioToken: string}} */ { libraryTemplateId, audioToken }) =>
            templateMediaStore.resolveAudioPath(libraryTemplateId, audioToken),
          authorizeProjectBgmFromPath: (/** @type {{projectId: string, absolutePath: string}} */ { projectId, absolutePath }) =>
            activeBgmLibrary.authorizeTrack({
              projectId,
              readOnlyConfirmed: true,
              absolutePath,
            }),
        }
      : {}),
  })
  bootPhase('workbench-runtime')
  const startupRecovery = await workbenchRuntime.startupRecovery
  if (startupRecovery.ready) await jobCoordinator?.start()
  bootPhase('startup-recovery')
  const assertMaterialSceneAvailable = (/** @type {string} */ projectId, /** @type {string} */ candidateId) => {
    materialReviewOverlay?.assertSceneAvailable(projectId, candidateId)
  }
  /**
   * @param {{projectId: string, candidateId: string, project: any}} input
   */
  const resolveCandidateClipBinding = async ({ projectId, candidateId, project }) => {
    if (!productionMaterialAnalysisProvider?.resolveCandidateClipSource) return null
    const localAuthorizationId = project?.materials?.authorized === true
      ? project.materials.authorizationId
      : null
    const hasLocalScene = typeof localAuthorizationId === 'string' && localAuthorizationId &&
      Array.isArray(project?.materials?.assets) && project.materials.assets.some((/** @type {Record<string, any>} */ asset) =>
        Array.isArray(asset?.scenes) && asset.scenes.some((/** @type {Record<string, any>} */ scene) => scene?.id === candidateId))
    if (hasLocalScene) {
      // A project-local scene always owns a colliding opaque scene ID.
      const clip = await productionMaterialAnalysisProvider.resolveCandidateClipSource({
        projectId,
        authorizationId: localAuthorizationId,
        candidateId,
      })
      return { clip, authorizationId: localAuthorizationId, bindingProjectId: projectId }
    }
    const binding = await materialLibraryService?.resolveSceneBinding?.(projectId, candidateId)
    if (!binding?.authorizationId || !binding?.projectId) return null
    const clip = await productionMaterialAnalysisProvider.resolveCandidateClipSource({
      projectId: binding.projectId,
      authorizationId: binding.authorizationId,
      candidateId,
    })
    return { clip, authorizationId: binding.authorizationId, bindingProjectId: binding.projectId }
  }
  const baseWorkbenchHandler = createWorkbenchHandler({
    runtime: workbenchRuntime,
    previewResourceProvider: syntheticWorkbench
      ? createSyntheticPreviewProvider()
      : (input) => productionPreviewProvider.getResource(input),
    candidateClipResourceProvider: async ({ projectId, candidateId, project }) => {
      if (!syntheticWorkbench) assertMaterialSceneAvailable(projectId, candidateId)
      const cacheKey = `${projectId}\u0000${candidateId}`
      let validatedClip = null
      if (!syntheticWorkbench) {
        const binding = await resolveCandidateClipBinding({ projectId, candidateId, project })
        if (!binding?.clip) return null
        validatedClip = binding.clip
      }
      const resource = await candidateClipLoader.getOrCreate(cacheKey, async () => {
        if (syntheticWorkbench) return createSyntheticCandidateClipResource({ candidateId })
        try {
          return createEphemeralCandidateClipResource({
            sourcePath: validatedClip.sourcePath, start: validatedClip.start, end: validatedClip.end,
            candidateId: validatedClip.candidateId, ffmpegPath: candidateFfmpegPath,
          })
        } catch (error) {
          recordCandidateClipFailure(error)
          throw error
        }
      })
      if (!syntheticWorkbench) assertMaterialSceneAvailable(projectId, candidateId)
      return resource
    },
    candidatePosterResourceProvider: async ({ projectId, candidateId, project }) => {
      if (syntheticWorkbench) return createSyntheticCandidatePosterResource({ candidateId })
      if (!syntheticWorkbench) assertMaterialSceneAvailable(projectId, candidateId)
      if (typeof productionMaterialAnalysisProvider?.resolveMaterialAssetThumbnail !== 'function') return null
      const binding = await resolveCandidateClipBinding({ projectId, candidateId, project })
      if (!binding?.clip?.assetId || !binding.authorizationId) return null
      const thumbnail = await productionMaterialAnalysisProvider.resolveMaterialAssetThumbnail({
        authorizationId: binding.authorizationId,
        projectId: binding.bindingProjectId,
        assetId: binding.clip.assetId,
      })
      if (!thumbnail?.bytes || !thumbnail.contentType) return null
      if (!syntheticWorkbench) assertMaterialSceneAvailable(projectId, candidateId)
      return {
        bytes: thumbnail.bytes,
        contentType: thumbnail.contentType,
        etag: thumbnail.etag ?? `"poster-${candidateId}"`,
      }
    },
    editorShotClipResourceProvider: async ({ projectId, shotId, candidateId, sourceRange, project }) => {
      if (!syntheticWorkbench) assertMaterialSceneAvailable(projectId, candidateId)
      const cacheKey = `${projectId}\u0000${shotId}\u0000${sourceRange.startUs}\u0000${sourceRange.durationUs}`
      let validatedClip = null
      if (!syntheticWorkbench) {
        if (!productionMaterialAnalysisProvider?.resolveCandidateClipSource) return null
        const localAuthorizationId = project?.materials?.authorized === true
          ? project.materials.authorizationId
          : null
        const hasLocalScene = typeof localAuthorizationId === 'string' && localAuthorizationId &&
          Array.isArray(project?.materials?.assets) && project.materials.assets.some((/** @type {Record<string, any>} */ asset) =>
            Array.isArray(asset?.scenes) && asset.scenes.some((/** @type {Record<string, any>} */ scene) => scene?.id === candidateId))
        if (hasLocalScene) {
          // Keep local project material precedence over an unrelated library
          // reference with the same opaque scene id.
          validatedClip = await productionMaterialAnalysisProvider.resolveCandidateClipSource({
            projectId,
            authorizationId: localAuthorizationId,
            candidateId,
          })
        } else {
          const binding = await materialLibraryService?.resolveSceneBinding?.(projectId, candidateId)
          if (!binding?.authorizationId || !binding?.projectId) return null
          validatedClip = await productionMaterialAnalysisProvider.resolveCandidateClipSource({
            projectId: binding.projectId,
            authorizationId: binding.authorizationId,
            candidateId,
          })
        }
      }
      const resource = await candidateClipLoader.getOrCreate(cacheKey, async () => {
        if (syntheticWorkbench) return createSyntheticCandidateClipResource({ candidateId })
        try {
          const start = sourceRange.startUs / 1_000_000
          const end = (sourceRange.startUs + sourceRange.durationUs) / 1_000_000
          return createEphemeralCandidateClipResource({
            sourcePath: validatedClip.sourcePath,
            start,
            end,
            candidateId: shotId,
            ffmpegPath: candidateFfmpegPath,
          })
        } catch (error) {
          recordCandidateClipFailure(error)
          throw error
        }
      })
      if (!syntheticWorkbench) assertMaterialSceneAvailable(projectId, candidateId)
      return resource
    },
  })
  const ttsStudioHandler = ttsStudio
    ? createTtsStudioHandler({ studio: ttsStudio })
    : async () => new Response(JSON.stringify({
        error: {
          code: 'TTS_STUDIO_UNAVAILABLE',
          message: 'TTS Studio is unavailable.',
        },
      }), {
        status: 503,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      })
  const bgmLibraryHandler = bgmLibrary
    ? createBgmLibraryHandler({
        library: bgmLibrary,
        onTrackImported: async ({ projectId, trackId, purpose, rightsConfirmed }) => {
          if (purpose !== 'sfx') return
          if (!sfxCatalog) throw Object.assign(new Error('SFX_CATALOG_UNAVAILABLE'), {
            code: 'SFX_CATALOG_UNAVAILABLE',
            status: 503,
          })
          await sfxCatalog.registerAuthorizedTrack({
            projectId,
            audioToken: trackId,
            rightsConfirmed: true,
          })
        },
        onTrackDeleted: ({ projectId, trackId }) =>
          Promise.all([
            workbenchRuntime.detachAudioTrack(projectId, { trackId }),
            sfxCatalog?.unregister({ projectId, audioToken: trackId }),
          ]),
      })
    : async () => new Response(JSON.stringify({
        error: {
          code: 'BGM_LIBRARY_UNAVAILABLE',
          message: 'BGM library is unavailable.',
        },
      }), {
        status: 503,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      })
  const sfxCatalogHandler = sfxCatalog
    ? createSfxCatalogHandler({ catalog: sfxCatalog })
    : async () => new Response(JSON.stringify({
        error: {
          code: 'SFX_CATALOG_UNAVAILABLE',
          message: 'SFX catalog is unavailable.',
        },
      }), {
        status: 503,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      })
  const materialMediaHandler = productionMaterialAnalysisProvider
      ? createMaterialMediaRequestHandler({
        runtime: workbenchRuntime,
        materialAnalyzer: productionMaterialAnalysisProvider,
        materialLibrary: materialLibraryService,
      })
    : null
  /** @param {Request} request */
  const workbenchHandler = async (request) =>
    (materialMediaHandler ? await materialMediaHandler(request) : null) ??
    baseWorkbenchHandler(request)
  /** @param {Request} request */
  const runtimeDiagnosticsHandler = async (request) => {
    if (request.method === 'DELETE') {
      runtimeDiagnostics.clear()
      return new Response(JSON.stringify({ cleared: true }), {
        headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8', 'x-content-type-options': 'nosniff' },
      })
    }
    if (!['GET', 'HEAD'].includes(request.method)) {
      return new Response(JSON.stringify({
        error: { code: 'METHOD_NOT_ALLOWED', message: 'Use GET, HEAD, or DELETE.' },
      }), {
        status: 405,
        headers: { allow: 'GET, HEAD, DELETE', 'content-type': 'application/json; charset=utf-8' },
      })
    }
    return new Response(
      JSON.stringify(runtimeDiagnostics.snapshot()),
      { headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8', 'x-content-type-options': 'nosniff' } },
    )
  }
  const creativeCapabilitySnapshotHandler = createCreativeCapabilitySnapshotHandler(
    () => creativeCapabilitySnapshot,
  )
  /** @type {(incoming: import('node:http').IncomingMessage, outgoing: import('node:http').ServerResponse) => Promise<void>} */
  const fullRequestListener = async (incoming, outgoing) => {
    try {
      /** @type {[string, string][]} */
      const headers = []
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (Array.isArray(value)) {
          for (const entry of value) headers.push([name, entry])
        } else if (value !== undefined) {
          headers.push([name, value])
        }
      }
      const requestPath = String(incoming.url ?? '/').split('?', 1)[0]
      const trustProbe = new Request(`http://127.0.0.1:${port}${requestPath}`, {
        method: incoming.method,
        headers,
      })
      if (!isTrustedLocalHttpRequest(trustProbe)) {
        outgoing.writeHead(403, { 'content-type': 'application/json; charset=utf-8' })
        outgoing.end(JSON.stringify({ error: { code: 'UNTRUSTED_LOCAL_REQUEST', message: 'Request origin is not trusted.' } }))
        return
      }
      if (isLocalApiWriteRequest(trustProbe) && !isAuthorizedLocalApiWrite(trustProbe, localApiToken)) {
        outgoing.writeHead(403, { 'content-type': 'application/json; charset=utf-8' })
        outgoing.end(JSON.stringify({
          error: {
            code: 'LOCAL_API_TOKEN_REQUIRED',
            message: 'Local API write requests require the same-origin session token.',
          },
        }))
        return
      }

      const requestByteLimit = /\/(?:reference-templates|template-library)\/upload$/u.test(requestPath)
        ? maxReferenceUploadBytes
        : maxRequestBytes
      const contentLength = Number.parseInt(incoming.headers['content-length'] ?? '0', 10)
      if (Number.isFinite(contentLength) && contentLength > requestByteLimit) {
        outgoing.writeHead(413, { 'content-type': 'application/json; charset=utf-8' })
        outgoing.end(JSON.stringify({ error: { code: 'PAYLOAD_TOO_LARGE', message: 'Request body is too large.' } }))
        return
      }

      const chunks = []
      let receivedBytes = 0
      for await (const chunk of incoming) {
        receivedBytes += chunk.length
        if (receivedBytes > requestByteLimit) {
          outgoing.writeHead(413, { 'content-type': 'application/json; charset=utf-8' })
          outgoing.end(JSON.stringify({ error: { code: 'PAYLOAD_TOO_LARGE', message: 'Request body is too large.' } }))
          return
        }
        chunks.push(chunk)
      }
      const request = new Request(`http://localhost:${port}${incoming.url ?? '/'}`, {
        method: incoming.method,
        headers,
        body: ['GET', 'HEAD'].includes(incoming.method ?? '') ? undefined : Buffer.concat(chunks),
      })
      const responseHandler = selectGatewayResponseHandler(
        new URL(request.url).pathname,
        {
          syntheticWorkbench,
          gatewayHandler,
          directorHandler,
          jianyingDraftHandler,
          jianyingDraftMinerHandler,
          livenessHandler,
          readinessHandler,
          productUpdateHandler,
          settingsHandler,
          runningHubSettingsHandler,
          jianying6RendererSettingsHandler,
          jianyingTtsPresetsHandler,
          jianyingVoiceCatalogHandler,
          jianyingWriterSettingsHandler,
          jianyingDuoProbationaryHandler,
          ttsStudioHandler,
          bgmLibraryHandler,
          sfxCatalogHandler,
          localPickerHandler,
          runtimeDiagnosticsHandler,
          creativeCapabilitySnapshotHandler,
          jianyingResourceRootSettingsHandler,
          jianyingPrivateResourceCatalogHandler,
          jianyingCapCutCatalogHandler,
          jianyingNativeEvidencePreflightHandler,
          workbenchHandler,
        },
      )
      const response = responseHandler
        ? await responseHandler(request)
        : await staticWebHandler(request)
      // The launcher still passes a one-time fragment token, but direct local
      // navigation must remain usable after a restart or an opened deep link.
      // The cookie is HttpOnly and same-site; writes still require the normal
      // trusted-loopback Origin and fetch-metadata checks above.
      if (!responseHandler && response.headers.get('content-type')?.startsWith('text/html')) {
        response.headers.set('set-cookie', localApiSessionCookie(localApiToken))
      }
      await writeHttpResponse(outgoing, response)
    } catch (error) {
      if (isExpectedClientDisconnect(error, incoming, outgoing)) return
      const candidate = /** @type {{code?: unknown}} */ (error)
      const code = typeof candidate?.code === 'string' ? candidate.code : 'GATEWAY_REQUEST_FAILED'
      runtimeDiagnostics.record({ component: 'http', code, severity: 'error' })
      if (outgoing.headersSent) {
        outgoing.destroy()
        return
      }
      if (!outgoing.headersSent) {
        outgoing.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
      }
      outgoing.end(JSON.stringify({ error: { code: 'INTERNAL_ERROR', message: 'The gateway request failed.' } }))
    }
  }

  // The startup shell is read-only. Revalidate every coalesced private root before switching the
  // same listener to the complete API surface; a changed boundary still fails closed.
  bootPhase('factories')
  if (nativeEvidenceStartupRecoveryPromise) {
    await nativeEvidenceStartupRecoveryPromise
    bootPhase('native-evidence-preflight')
  }
  // Receipt publication stays inside the coalesced boot ACL window. Revalidate
  // the root boundary before exposing the complete API; the startup shell and
  // /api/live remain available while the bounded evidence recovery runs.
  await bootPrivateRootSecurer.finalize()
  bootPhase('runtime-root-acl-finalize')
  activeRequestListener = fullRequestListener
  bootPhase('workbench-ready')
  startupState.ready = true
  log(`OpenVideo LLM Gateway listening on http://127.0.0.1:${port}`)
  // REL-017: cold-start race — perform the first background update check
  // only after the workbench is fully ready so configPath + release-identity
  // + install root are stable.
  productUpdateService.startBackgroundCheck()

  let stopping = false
  const stop = async () => {
    if (stopping) return
    stopping = true
    process.removeListener('SIGINT', onSignal)
    process.removeListener('SIGTERM', onSignal)
    const closed = once(server, 'close')
    server.close()
    await Promise.all([closed, jobCoordinator?.stop()])
  }
  const onSignal = () => {
    stop().catch(() => {
      process.exitCode = 1
    })
  }
  process.once('SIGINT', onSignal)
  process.once('SIGTERM', onSignal)
  return {
    server,
    stop,
    jobCoordinator,
    creativeKnowledge,
    creativePlanningMode: creativeShadowPlanner ? creativePlanningMode : 'off',
    creativeTechniqueMode: creativeShadowPlanner ? creativeTechniqueMode : 'off',
    creativeAudioCueMode: creativeShadowPlanner ? creativeAudioCueMode : 'off',
    creativeAutoOutputs: Boolean(creativeShadowPlanner && creativeAutoOutputs),
  }
  } catch (error) {
    startupState.ready = false
    startupState.phase = 'failed'
    await jobCoordinator?.stop()
    if (server.listening) {
      const closed = once(server, 'close')
      server.close()
      await closed
    }
    throw error
  }
}

const executedPath = process.argv[1] ? pathToFileURL(process.argv[1]).href : null
if (executedPath === import.meta.url) {
  await startGatewayServer()
}
