import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const attestation = '--manual-attestation=opened-edited-saved-reopened'
const verifier = fileURLToPath(new URL('./Verify-JY132PackagingResourceEvidence.mjs', import.meta.url))

if (!process.argv.slice(2).includes(attestation)) {
  process.stderr.write(`Usage: node scripts/Verify-JY138PrivateBatchEvidence.mjs ${attestation}\n`)
  process.exitCode = 2
} else {
  const child = spawn(process.execPath, [verifier, attestation], { stdio: 'inherit', windowsHide: true })
  child.once('error', (error) => {
    process.stderr.write('JY138_EVIDENCE_VERIFIER_FAILED\n')
    process.exitCode = 1
  })
  child.once('exit', (code, signal) => {
    process.exitCode = typeof code === 'number' ? code : 1
    if (signal) process.stderr.write('JY138_EVIDENCE_VERIFIER_FAILED\n')
  })
}
