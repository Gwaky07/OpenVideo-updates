[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$utf8 = New-Object Text.UTF8Encoding($false)
$repositoryPath = [IO.Path]::GetFullPath($RepositoryRoot)
$localTempRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Temp'
$testRoot = Join-Path $localTempRoot ("openvideo-em002-" + [Guid]::NewGuid().ToString('N'))
$materialRoot = Join-Path $testRoot 'authorized-material'
$runtimeRoot = Join-Path $testRoot 'runtime'
$outsideRoot = Join-Path $testRoot 'outside'
$preflightScript = Join-Path $RepositoryRoot 'scripts/Protect-EditMindAuthorizedSamples.ps1'
$resultScript = Join-Path $RepositoryRoot 'scripts/Test-EditMindAuthorizedAnalysisResults.ps1'

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Write-Json {
    param([string]$Path, [object]$Value)
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 12), $utf8)
}

function Assert-Fails {
    param([scriptblock]$Action, [string]$Pattern)
    $failed = $false
    try {
        $ErrorActionPreference = 'Stop'
        & $Action
    } catch {
        $failed = $true
        if ($_.Exception.Message -notmatch $Pattern) { throw }
    }
    if (-not $failed) { throw "Expected failure matching: $Pattern" }
}

try {
    New-Item -ItemType Directory -Path $materialRoot, $runtimeRoot, $outsideRoot -Force | Out-Null
    $privateEvidenceRoot = Join-Path $runtimeRoot 'evidence/em-002/private'
    New-Item -ItemType Directory -Path $privateEvidenceRoot -Force | Out-Null
    $files = @()
    foreach ($index in 1..5) {
        $path = Join-Path $materialRoot ("sample-$index.mp4")
        [IO.File]::WriteAllText($path, "synthetic-video-$index", $utf8)
        $files += $path
    }
    $outsideVideo = Join-Path $outsideRoot 'outside.mp4'
    [IO.File]::WriteAllText($outsideVideo, 'outside', $utf8)
    $nonVideo = Join-Path $materialRoot 'not-video.txt'
    [IO.File]::WriteAllText($nonVideo, 'text', $utf8)

    $manifestPath = Join-Path $privateEvidenceRoot 'authorized-samples.json'
    Write-Json $manifestPath ([ordered]@{
        schema_version = 1
        authorization = 'read_only_analysis'
        files = $files
    })

    Assert-True (Test-Path -LiteralPath $preflightScript -PathType Leaf) 'Preflight implementation script is missing.'
    Assert-True (Test-Path -LiteralPath $resultScript -PathType Leaf) 'Result validation implementation script is missing.'

    & $preflightScript -ManifestPath $manifestPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before | Out-Null
    $beforePath = Join-Path $runtimeRoot 'evidence/em-002/source-snapshot.before.json'
    Assert-True (Test-Path -LiteralPath $beforePath -PathType Leaf) 'Before snapshot was not written to the runtime root.'

    $before = Get-Content -LiteralPath $beforePath -Raw -Encoding utf8 | ConvertFrom-Json
    Assert-True ($before.files.Count -eq 5) 'Before snapshot must contain exactly five files.'

    & $preflightScript -ManifestPath $manifestPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase After | Out-Null
    $verificationPath = Join-Path $runtimeRoot 'evidence/em-002/source-verification.json'
    $verification = Get-Content -LiteralPath $verificationPath -Raw -Encoding utf8 | ConvertFrom-Json
    Assert-True ($verification.unchanged -eq $true) 'Unchanged verification was not recorded.'
    Assert-True ($verification.sample_count -eq 5) 'Verification must report five samples.'
    Assert-True (-not ($verification | ConvertTo-Json -Depth 8).Contains($materialRoot)) 'Sanitized verification leaked the material root.'

    $badCountManifest = Join-Path $privateEvidenceRoot 'bad-count.json'
    Write-Json $badCountManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = $files[0..3] })
    Assert-Fails { & $preflightScript -ManifestPath $badCountManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'exactly five'

    $duplicateManifest = Join-Path $privateEvidenceRoot 'duplicate.json'
    Write-Json $duplicateManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = @($files[0], $files[1], $files[2], $files[3], $files[0]) })
    Assert-Fails { & $preflightScript -ManifestPath $duplicateManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'duplicate'

    $wildcardManifest = Join-Path $privateEvidenceRoot 'wildcard.json'
    Write-Json $wildcardManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = @($files[0], $files[1], $files[2], $files[3], (Join-Path $materialRoot '*.mp4')) })
    Assert-Fails { & $preflightScript -ManifestPath $wildcardManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'wildcard'

    $directoryManifest = Join-Path $privateEvidenceRoot 'directory.json'
    Write-Json $directoryManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = @($files[0], $files[1], $files[2], $files[3], $materialRoot) })
    Assert-Fails { & $preflightScript -ManifestPath $directoryManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'file'

    $outsideManifest = Join-Path $privateEvidenceRoot 'outside.json'
    Write-Json $outsideManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = @($files[0], $files[1], $files[2], $files[3], $outsideVideo) })
    Assert-Fails { & $preflightScript -ManifestPath $outsideManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'outside the authorized material root'

    $nonVideoManifest = Join-Path $privateEvidenceRoot 'non-video.json'
    Write-Json $nonVideoManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = @($files[0], $files[1], $files[2], $files[3], $nonVideo) })
    Assert-Fails { & $preflightScript -ManifestPath $nonVideoManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'video extension'

    $missingVideo = Join-Path $materialRoot 'missing-video.mp4'
    $missingManifest = Join-Path $privateEvidenceRoot 'missing.json'
    Write-Json $missingManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = @($files[0], $files[1], $files[2], $files[3], $missingVideo) })
    Assert-Fails { & $preflightScript -ManifestPath $missingManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } ([regex]::Escape($missingVideo))

    $manifestOutsideRuntime = Join-Path $testRoot 'manifest-outside-runtime.json'
    Write-Json $manifestOutsideRuntime ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = $files })
    Assert-Fails { & $preflightScript -ManifestPath $manifestOutsideRuntime -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase Before } 'inside RuntimeDataRoot'

    Assert-Fails { & $preflightScript -ManifestPath $preflightScript -MaterialRoot $materialRoot -RuntimeDataRoot $repositoryPath -Phase Before } 'repository'
    Assert-Fails { & $preflightScript -ManifestPath $manifestPath -MaterialRoot $repositoryPath -RuntimeDataRoot $runtimeRoot -Phase Before } 'repository'

    $afterWithoutRuntime = Join-Path $testRoot 'after-without-runtime'
    Assert-Fails { & $preflightScript -ManifestPath $manifestPath -MaterialRoot $materialRoot -RuntimeDataRoot $afterWithoutRuntime -Phase After } 'RuntimeDataRoot must exist for After phase'

    $afterWithoutSnapshot = Join-Path $testRoot 'after-without-snapshot'
    New-Item -ItemType Directory -Path $afterWithoutSnapshot -Force | Out-Null
    $afterWithoutSnapshotManifest = Join-Path $afterWithoutSnapshot 'authorized-samples.json'
    Write-Json $afterWithoutSnapshotManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = $files })
    Assert-Fails { & $preflightScript -ManifestPath $afterWithoutSnapshotManifest -MaterialRoot $materialRoot -RuntimeDataRoot $afterWithoutSnapshot -Phase After } 'Before snapshot is required'

    $separatorRuntime = Join-Path $testRoot 'separator-runtime'
    New-Item -ItemType Directory -Path $separatorRuntime -Force | Out-Null
    $separatorManifest = Join-Path $separatorRuntime 'separator.json'
    $alternateFiles = @($files | ForEach-Object { $_.Replace('\', '/') })
    Write-Json $separatorManifest ([ordered]@{ schema_version = 1; authorization = 'read_only_analysis'; files = $alternateFiles })
    & $preflightScript -ManifestPath $separatorManifest -MaterialRoot $materialRoot.Replace('\', '/') -RuntimeDataRoot $separatorRuntime.Replace('\', '/') -Phase Before | Out-Null
    $separatorSnapshot = Get-Content -LiteralPath (Join-Path $separatorRuntime 'evidence/em-002/source-snapshot.before.json') -Raw -Encoding utf8 | ConvertFrom-Json
    Assert-True ($separatorSnapshot.files[0].path -eq [IO.Path]::GetFullPath($files[0])) 'Path separator normalization is inconsistent.'

    $nestedRuntime = Join-Path $materialRoot 'runtime-inside-material'
    Assert-Fails { & $preflightScript -ManifestPath $manifestPath -MaterialRoot $materialRoot -RuntimeDataRoot $nestedRuntime -Phase Before } 'separate'

    $runtimeLink = Join-Path $testRoot 'runtime-link'
    try {
        New-Item -ItemType Junction -Path $runtimeLink -Target $runtimeRoot -ErrorAction Stop | Out-Null
        $linkedManifest = Join-Path $runtimeLink 'evidence/em-002/private/authorized-samples.json'
        Assert-Fails { & $preflightScript -ManifestPath $linkedManifest -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeLink -Phase Before } 'symbolic-link or reparse-point'
    } catch [System.UnauthorizedAccessException] {
    } catch [System.IO.IOException] {
    } finally {
        if (Test-Path -LiteralPath $runtimeLink) {
            $resolvedLink = [IO.Path]::GetFullPath($runtimeLink)
            $resolvedTestRoot = [IO.Path]::GetFullPath($testRoot)
            if (-not $resolvedLink.StartsWith($resolvedTestRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
                throw 'Unsafe synthetic junction cleanup target.'
            }
            $linkItem = Get-Item -LiteralPath $resolvedLink -Force
            if (($linkItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) {
                throw 'Expected a synthetic junction cleanup target.'
            }
            [IO.Directory]::Delete($resolvedLink, $false)
        }
    }

    [IO.File]::AppendAllText($files[0], '-changed', $utf8)
    Assert-Fails { & $preflightScript -ManifestPath $manifestPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase After } 'changed'
    [IO.File]::WriteAllText($files[0], 'synthetic-video-1', $utf8)
    [IO.File]::SetLastWriteTimeUtc($files[0], [datetime]$before.files[0].last_write_time_utc)
    & $preflightScript -ManifestPath $manifestPath -MaterialRoot $materialRoot -RuntimeDataRoot $runtimeRoot -Phase After | Out-Null

    $resultsPath = Join-Path $runtimeRoot 'evidence/em-002/private-analysis-results.json'
    $results = [ordered]@{
        schema_version = 1
        samples = @()
    }
    for ($index = 0; $index -lt 5; $index++) {
        $results.samples += [ordered]@{
            source = $files[$index]
            status = 'indexed'
            summary = "Synthetic cup sample $($index + 1)."
            tags = @('cup', 'synthetic')
            duration = 10.0
            scenes = @(
                [ordered]@{ source = $files[$index]; start = 0.0; end = 5.0 },
                [ordered]@{ source = $files[$index]; start = 5.0; end = 10.0 }
            )
        }
    }
    Write-Json $resultsPath $results
    & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot | Out-Null
    $sanitizedResults = Get-Content -LiteralPath (Join-Path $runtimeRoot 'evidence/em-002/analysis-verification.json') -Raw -Encoding utf8
    Assert-True (-not $sanitizedResults.Contains($materialRoot)) 'Sanitized result evidence leaked the material root.'

    $sourceVerificationRaw = Get-Content -LiteralPath $verificationPath -Raw -Encoding utf8
    Remove-Item -LiteralPath $verificationPath -Force
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'Source verification is required'
    [IO.File]::WriteAllText($verificationPath, $sourceVerificationRaw, $utf8)

    [IO.File]::AppendAllText($files[0], '-changed-after-snapshot', $utf8)
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'changed since the recorded snapshot'
    [IO.File]::WriteAllText($files[0], 'synthetic-video-1', $utf8)
    [IO.File]::SetLastWriteTimeUtc($files[0], [datetime]$before.files[0].last_write_time_utc)

    $resultsOutsideRuntime = Join-Path $testRoot 'private-analysis-results-outside-runtime.json'
    Write-Json $resultsOutsideRuntime $results
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsOutsideRuntime -RuntimeDataRoot $runtimeRoot } 'inside RuntimeDataRoot'
    Assert-Fails { & $resultScript -ManifestPath $manifestOutsideRuntime -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'inside RuntimeDataRoot'
    Assert-Fails { & $resultScript -ManifestPath $resultScript -ResultsPath $resultScript -RuntimeDataRoot $repositoryPath } 'repository'

    $results.samples[0].scenes[1].end = 11.0
    Write-Json $resultsPath $results
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'duration'

    $results.samples[0].scenes[1].end = 10.0
    $results.samples[0].scenes[0].note = 'extra field'
    Write-Json $resultsPath $results
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'only contain source, start and end'
    $results.samples[0].scenes[0].Remove('note')

    $temporaryFrame = Join-Path $runtimeRoot 'tmp/background-jobs/frame-001.jpg'
    New-Item -ItemType Directory -Path (Split-Path -Parent $temporaryFrame) -Force | Out-Null
    [IO.File]::WriteAllText($temporaryFrame, 'temporary', $utf8)
    Write-Json $resultsPath $results
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'temporary files'
    Remove-Item -LiteralPath $temporaryFrame -Force

    $sceneFile = Join-Path $runtimeRoot 'Scene-001.mov'
    [IO.File]::WriteAllText($sceneFile, 'forbidden', $utf8)
    Write-Json $resultsPath $results
    Assert-Fails { & $resultScript -ManifestPath $manifestPath -ResultsPath $resultsPath -RuntimeDataRoot $runtimeRoot } 'permanent scene clip'

    Write-Host 'Edit Mind authorized sample synthetic tests passed.' -ForegroundColor Green
} finally {
    if (Test-Path -LiteralPath $testRoot) {
        $resolved = [IO.Path]::GetFullPath($testRoot)
        $temp = [IO.Path]::GetFullPath($localTempRoot)
        if (-not $resolved.StartsWith($temp, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe synthetic test cleanup target.' }
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
