import { createHash } from 'node:crypto'

/** Whitelist tool names from AGENT-TOOL-WHITELIST.md */
export const EDITOR_TOOL_NAMES = Object.freeze([
  'get_project_brief',
  'search_materials',
  'inspect_candidate',
  'get_template_constraints',
  'get_capability_matrix',
  'recommend_packaging',
  'apply_packaging_recommendation',
  'get_timeline_summary',
  'propose_timeline_patch',
  'preflight_timeline',
  'finalize_timeline',
  'request_preview',
  'request_jianying_export',
])

export const EDITOR_PATCH_OPS = Object.freeze([
  'insert_segment',
  'remove_segment',
  'replace_candidate',
  'trim_source',
  'move_segment',
  'set_text',
  'set_audio',
  'set_transition',
  'set_effect',
  'set_keyframes',
])

export const EDITOR_BUDGETS = Object.freeze({
  maxToolCallsPerTurn: 48,
  maxSearchMaterials: 24,
  maxDistinctInspectCandidates: 48,
  maxOperationsPerPatch: 200,
  maxOperationsPerJob: 500,
  defaultTimeoutMs: 15 * 60 * 1000,
  // Thinking models such as gpt-5.6-sol often need multiple tool rounds.
  // Auto-create used to die at 90s, which is shorter than one provider HTTP
  // timeout and surfaces as a user-facing failure even though the model works.
  // 12+ confirmed storyboard shots need one search turn each plus workflow tools.
  automaticCreateTimeoutMs: 10 * 60 * 1000,
  maxInstructionChars: 8_000,
  maxPrematureFinishCorrections: 3,
  maxTurnRepairAttempts: 3,
})

/** Public, provider-neutral argument contracts exposed to the model. */
export const EDITOR_TOOL_ARGUMENT_CONTRACTS = Object.freeze(
  EDITOR_TOOL_NAMES.map((tool) => {
    /** @type {Record<string, string[]>} */
    const requiredArgumentKeysByTool = {
      get_project_brief: ['projectId'],
      search_materials: ['projectId', 'query', 'desiredDurationUs', 'limit'],
      inspect_candidate: ['projectId', 'candidateId'],
      get_template_constraints: ['projectId'],
      get_capability_matrix: ['projectId'],
      recommend_packaging: ['projectId'],
      apply_packaging_recommendation: [
        'projectId',
        'timelineId',
        'revision',
        'revisionFingerprint',
        'recommendationId',
        'catalogRevisionToken',
        'idempotencyKey',
      ],
      get_timeline_summary: ['projectId', 'timelineId', 'revision'],
      propose_timeline_patch: [
        'projectId',
        'baseRevision',
        'baseRevisionFingerprint',
        'operations',
        'rationale',
        'idempotencyKey',
      ],
      preflight_timeline: ['projectId', 'timelineId', 'revision', 'revisionFingerprint'],
      finalize_timeline: [
        'projectId',
        'timelineId',
        'revision',
        'revisionFingerprint',
        'idempotencyKey',
      ],
      request_preview: [
        'projectId',
        'timelineId',
        'revision',
        'revisionFingerprint',
        'idempotencyKey',
      ],
      request_jianying_export: [
        'projectId',
        'timelineId',
        'revision',
        'revisionFingerprint',
        'idempotencyKey',
      ],
    }
    return Object.freeze({
      tool,
      requiredArgumentKeys: Object.freeze([...(requiredArgumentKeysByTool[tool] ?? [])]),
    })
  }),
)

export const EDITOR_MODEL_PATCH_OPERATION_CONTRACTS = Object.freeze([
  Object.freeze({
    op: 'replace_candidate',
    requiredKeys: Object.freeze(['op', 'segmentId', 'candidateId', 'sourceRange']),
    sourceRange: Object.freeze({
      startUs: 'non-negative integer',
      durationUs: 'positive integer',
    }),
    constraint: 'candidateId and sourceRange must come from search_materials results',
  }),
  Object.freeze({
    op: 'trim_source',
    requiredKeys: Object.freeze(['op', 'segmentId', 'sourceRange']),
    sourceRange: Object.freeze({
      startUs: 'non-negative integer',
      durationUs: 'positive integer',
    }),
    constraint: 'sourceRange may only narrow the segment current trusted sourceRange',
  }),
  Object.freeze({
    op: 'move_segment',
    requiredKeys: Object.freeze(['op', 'segmentId', 'afterSegmentId']),
    constraint: 'afterSegmentId must be null or a segment on the same track',
  }),
  Object.freeze({
    op: 'remove_segment',
    requiredKeys: Object.freeze(['op', 'segmentId']),
  }),
  Object.freeze({
    op: 'set_text',
    requiredKeys: Object.freeze(['op', 'segmentId', 'text', 'styleToken']),
  }),
  Object.freeze({
    op: 'set_transition',
    requiredKeys: Object.freeze(['op', 'segmentId', 'capabilityId', 'durationUs']),
    constraint: 'capabilityId and durationUs must be allowed by get_capability_matrix',
  }),
  Object.freeze({
    op: 'set_audio',
    requiredKeys: Object.freeze(['op', 'segmentId', 'audioToken', 'volume']),
    authorization: 'segmentId must reference the canonical BGM track and audioToken must be an already authorized opaque token',
  }),
])

export const EDITOR_JOB_TYPE = 'editor_agent'

export class EditorAgentContractError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 400) {
    super(code)
    this.name = 'EditorAgentContractError'
    this.code = code
    this.status = status
  }
}

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 400) => {
  throw new EditorAgentContractError(code, status)
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {Record<string, any>} value @param {string[]} keys */
const hasExactKeys = (value, keys) =>
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} value */
const opaqueId = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {unknown} value */
const isFingerprint = (value) => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value)
/** @param {unknown} value */
const isTimeRange = (value) =>
  isRecord(value) &&
  Number.isSafeInteger(value.startUs) &&
  value.startUs >= 0 &&
  Number.isSafeInteger(value.durationUs) &&
  value.durationUs >= 1
/** @param {unknown} value */
/** @param {string} text */
const containsSecretLike = (text) =>
  /\b(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|private[_-]?key|password|passwd|secret)\b/iu
    .test(text) ||
  /\b(?:authorization|bearer)(?:\s*[:=]\s*|\s+)\S+/iu.test(text) ||
  /-----begin (?:rsa )?private key-----/iu.test(text) ||
  /\bsk-[A-Za-z0-9]{10,}\b/u.test(text)

/** @param {unknown} value */
export const containsPrivateReference = (value) => {
  let encoded
  try {
    encoded = JSON.stringify(value)
  } catch {
    return true
  }
  let decoded = encoded
  try {
    decoded = decodeURIComponent(encoded.replace(/\+/gu, '%20'))
  } catch {
    // Keep the raw encoding when URI decoding fails.
  }
  const haystack = `${encoded}\n${decoded}`
  if (/(?:[A-Za-z]:[\\/]|\\\\|file:|https?:)/iu.test(haystack)) return true
  // Any JSON string that begins with an absolute/home Unix path.
  if (/"(?:~|\/)[^"]*"/u.test(haystack)) return true
  if (/%(?:2f|5c|3a)/iu.test(haystack)) return true
  if (/\.(?:mp4|mov|mkv|avi|mp3|wav|aac|m4a)(?:\b|$|")/iu.test(haystack)) return true
  if (containsSecretLike(haystack)) return true
  return false
}

/** @param {unknown} value */
export const fingerprintCanonical = (value) =>
  createHash('sha256').update(stableStringify(value)).digest('hex')

/** @param {unknown} value @returns {string} */
const stableStringify = (value) => {
  if (value === null || typeof value !== 'object') return JSON.stringify(value)
  if (Array.isArray(value)) {
    return `[${value.map((entry) => stableStringify(entry)).join(',')}]`
  }
  const record = /** @type {Record<string, unknown>} */ (value)
  const keys = Object.keys(record).sort()
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(',')}}`
}

/**
 * Sanitize EditorInstruction.instruction; mark path/URL/injection risks for private audit.
 * @param {unknown} value
 */
export const sanitizeEditorInstructionText = (value) => {
  if (typeof value !== 'string') fail('EDITOR_INSTRUCTION_INVALID')
  if (value.length === 0 || value.length > EDITOR_BUDGETS.maxInstructionChars) {
    fail('EDITOR_INSTRUCTION_INVALID')
  }
  if (value.includes('\u0000')) fail('EDITOR_INSTRUCTION_INVALID')
  /** @type {string[]} */
  const riskFlags = []
  const lower = value.toLowerCase()
  if (/[\\/]/.test(value) || /(?:[a-z]:\\|\\\\|file:|https?:)/iu.test(value)) {
    riskFlags.push('path_or_url')
  }
  if (
    /ignore (?:previous|all) instructions|system prompt|tool_call|<\/?(?:system|assistant)>/iu
      .test(value)
  ) {
    riskFlags.push('prompt_injection')
  }
  if (
    /\b(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|private[_-]?key|password|passwd|secret)\b/iu
      .test(lower) ||
    /\b(?:authorization|bearer)(?:\s*[:=]\s*|\s+)\S+/iu.test(lower) ||
    /-----begin (?:rsa )?private key-----/iu.test(lower)
  ) {
    riskFlags.push('secret_like')
  }
  return {
    instruction: value,
    riskFlags,
  }
}

/**
 * @param {unknown} value
 * @returns {{
 *   projectId: string,
 *   instruction: string,
 *   baseTimeline: {timelineId: string, revision: number, revisionFingerprint: string} | null,
 *   mode: 'create' | 'revise',
 *   idempotencyKey: string,
 *   riskFlags: string[],
 * }}
 */
export const assertEditorInstruction = (value) => {
  if (!isRecord(value)) fail('EDITOR_INSTRUCTION_INVALID')
  const keys = Object.keys(value).sort()
  const expected = ['baseTimeline', 'idempotencyKey', 'instruction', 'mode', 'projectId'].sort()
  if (keys.join('\u0000') !== expected.join('\u0000')) fail('EDITOR_INSTRUCTION_INVALID')
  if (!opaqueId(value.projectId)) fail('EDITOR_INSTRUCTION_PROJECT_INVALID')
  if (value.mode !== 'create' && value.mode !== 'revise') fail('EDITOR_INSTRUCTION_MODE_INVALID')
  if (!opaqueId(value.idempotencyKey)) fail('EDITOR_INSTRUCTION_IDEMPOTENCY_INVALID')
  const sanitized = sanitizeEditorInstructionText(value.instruction)
  if (
    sanitized.riskFlags.includes('path_or_url') ||
    sanitized.riskFlags.includes('secret_like')
  ) {
    fail('EDITOR_INSTRUCTION_PRIVATE_REFERENCE')
  }
  /** @type {{timelineId: string, revision: number, revisionFingerprint: string} | null} */
  let baseTimeline = null
  if (value.baseTimeline !== null) {
    if (
      !isRecord(value.baseTimeline) ||
      !hasExactKeys(value.baseTimeline, ['timelineId', 'revision', 'revisionFingerprint']) ||
      !opaqueId(value.baseTimeline.timelineId) ||
      !Number.isSafeInteger(value.baseTimeline.revision) ||
      value.baseTimeline.revision < 1 ||
      !isFingerprint(value.baseTimeline.revisionFingerprint)
    ) {
      fail('EDITOR_INSTRUCTION_BASE_TIMELINE_INVALID')
    }
    baseTimeline = {
      timelineId: value.baseTimeline.timelineId,
      revision: value.baseTimeline.revision,
      revisionFingerprint: value.baseTimeline.revisionFingerprint,
    }
  }
  if (value.mode === 'create' && baseTimeline) {
    fail('EDITOR_INSTRUCTION_BASE_TIMELINE_FORBIDDEN')
  }
  if (value.mode === 'revise' && !baseTimeline) fail('EDITOR_INSTRUCTION_BASE_TIMELINE_REQUIRED')
  return {
    projectId: value.projectId,
    instruction: sanitized.instruction,
    baseTimeline,
    mode: value.mode,
    idempotencyKey: value.idempotencyKey,
    riskFlags: sanitized.riskFlags,
  }
}

/** @param {unknown} value */
export const assertTimelinePatchOperation = (value) => {
  if (!isRecord(value) || typeof value.op !== 'string' || !EDITOR_PATCH_OPS.includes(value.op)) {
    fail('EDITOR_PATCH_OP_UNSUPPORTED')
  }
  if (containsPrivateReference(value)) fail('EDITOR_PATCH_PRIVATE_REFERENCE')
  switch (value.op) {
    case 'remove_segment':
      if (
        !hasExactKeys(value, ['op', 'segmentId']) ||
        !opaqueId(value.segmentId)
      ) fail('EDITOR_PATCH_OP_INVALID')
      return { op: 'remove_segment', segmentId: value.segmentId }
    case 'replace_candidate':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'candidateId', 'sourceRange']) ||
        !opaqueId(value.segmentId) ||
        !opaqueId(value.candidateId) ||
        !isTimeRange(value.sourceRange) ||
        !hasExactKeys(value.sourceRange, ['startUs', 'durationUs'])
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'replace_candidate',
        segmentId: value.segmentId,
        candidateId: value.candidateId,
        sourceRange: {
          startUs: value.sourceRange.startUs,
          durationUs: value.sourceRange.durationUs,
        },
      }
    case 'trim_source':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'sourceRange']) ||
        !opaqueId(value.segmentId) ||
        !isTimeRange(value.sourceRange) ||
        !hasExactKeys(value.sourceRange, ['startUs', 'durationUs'])
      ) fail('EDITOR_PATCH_OP_INVALID')
      return {
        op: 'trim_source',
        segmentId: value.segmentId,
        sourceRange: {
          startUs: value.sourceRange.startUs,
          durationUs: value.sourceRange.durationUs,
        },
      }
    case 'move_segment':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'afterSegmentId']) ||
        !opaqueId(value.segmentId) ||
        !(value.afterSegmentId === null || opaqueId(value.afterSegmentId))
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'move_segment',
        segmentId: value.segmentId,
        afterSegmentId: value.afterSegmentId,
      }
    case 'set_transition':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'capabilityId', 'durationUs']) ||
        !opaqueId(value.segmentId) ||
        !(value.capabilityId === null || opaqueId(value.capabilityId)) ||
        !(value.durationUs === null ||
          (Number.isSafeInteger(value.durationUs) && value.durationUs >= 0))
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'set_transition',
        segmentId: value.segmentId,
        capabilityId: value.capabilityId,
        durationUs: value.durationUs,
      }
    case 'set_text':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'text', 'styleToken']) ||
        !opaqueId(value.segmentId) ||
        typeof value.text !== 'string' ||
        value.text.length === 0 ||
        value.text.length > 2_000 ||
        !opaqueId(value.styleToken)
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'set_text',
        segmentId: value.segmentId,
        text: value.text,
        styleToken: value.styleToken,
      }
    case 'set_audio':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'audioToken', 'volume']) ||
        !opaqueId(value.segmentId) ||
        !opaqueId(value.audioToken) ||
        typeof value.volume !== 'number' ||
        !(value.volume >= 0 && value.volume <= 1)
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'set_audio',
        segmentId: value.segmentId,
        audioToken: value.audioToken,
        volume: value.volume,
      }
    case 'set_effect':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'binding']) ||
        !opaqueId(value.segmentId)
      ) fail('EDITOR_PATCH_OP_INVALID')
      if (value.binding !== null && !isRecord(value.binding)) fail('EDITOR_PATCH_OP_INVALID')
      return {
        op: 'set_effect',
        segmentId: value.segmentId,
        binding: value.binding === null ? null : structuredClone(value.binding),
      }
    case 'set_keyframes':
      if (
        !hasExactKeys(value, ['op', 'segmentId', 'capabilityId', 'keyframes']) ||
        !opaqueId(value.segmentId) ||
        !opaqueId(value.capabilityId) ||
        !Array.isArray(value.keyframes)
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'set_keyframes',
        segmentId: value.segmentId,
        capabilityId: value.capabilityId,
        keyframes: structuredClone(value.keyframes),
      }
    case 'insert_segment':
      if (
        !hasExactKeys(value, ['op', 'trackId', 'afterSegmentId', 'segment']) ||
        !opaqueId(value.trackId) ||
        !(value.afterSegmentId === null || opaqueId(value.afterSegmentId)) ||
        !isRecord(value.segment)
      ) {
        fail('EDITOR_PATCH_OP_INVALID')
      }
      return {
        op: 'insert_segment',
        trackId: value.trackId,
        afterSegmentId: value.afterSegmentId,
        segment: structuredClone(value.segment),
      }
    default:
      fail('EDITOR_PATCH_OP_UNSUPPORTED')
  }
}

/**
 * @param {unknown} operations
 * @param {{jobOperationsUsed?: number}} [options]
 */
export const assertTimelinePatchOperations = (operations, options = {}) => {
  if (!Array.isArray(operations) || operations.length === 0) fail('EDITOR_PATCH_OPS_INVALID')
  if (operations.length > EDITOR_BUDGETS.maxOperationsPerPatch) {
    fail('EDITOR_PATCH_OPS_LIMIT', 409)
  }
  const used = options.jobOperationsUsed ?? 0
  if (!Number.isSafeInteger(used) || used < 0) fail('EDITOR_PATCH_JOB_BUDGET_INVALID', 500)
  if (used + operations.length > EDITOR_BUDGETS.maxOperationsPerJob) {
    fail('EDITOR_PATCH_JOB_OPS_LIMIT', 409)
  }
  return operations.map((entry) => assertTimelinePatchOperation(entry))
}

/**
 * Agent model turn schema: either call a tool or finish.
 * @param {unknown} value
 */
export const assertAgentTurnDecision = (value) => {
  let decision = value
  if (
    isRecord(value) &&
    hasExactKeys(value, ['decision']) &&
    typeof value.decision === 'string' &&
    value.decision.length <= 100_000
  ) {
    try {
      decision = JSON.parse(value.decision)
    } catch {
      fail('EDITOR_AGENT_TURN_INVALID')
    }
  }
  if (!isRecord(decision) || typeof decision.type !== 'string') fail('EDITOR_AGENT_TURN_INVALID')
  if (decision.type === 'tool_call') {
    if (
      !hasExactKeys(decision, ['type', 'tool', 'arguments']) ||
      typeof decision.tool !== 'string' ||
      !EDITOR_TOOL_NAMES.includes(decision.tool) ||
      !isRecord(decision.arguments)
    ) {
      fail('EDITOR_AGENT_TOOL_CALL_INVALID')
    }
    return {
      type: 'tool_call',
      tool: decision.tool,
      arguments: structuredClone(decision.arguments),
    }
  }
  if (decision.type === 'finish') {
    if (
      !hasExactKeys(decision, ['type', 'summary']) ||
      typeof decision.summary !== 'string' ||
      decision.summary.length === 0 ||
      decision.summary.length > 2_000 ||
      containsPrivateReference(decision.summary)
    ) {
      fail('EDITOR_AGENT_FINISH_INVALID')
    }
    return { type: 'finish', summary: decision.summary }
  }
  fail('EDITOR_AGENT_TURN_INVALID')
}

export const createEditorAgentTurnSchema = () => ({
  name: 'editor_agent_turn',
  schema: {
    type: 'object',
    additionalProperties: false,
    required: ['decision'],
    properties: {
      decision: { type: 'string' },
    },
  },
})

/** @param {{instructionFingerprint: string, baseTimelineFingerprint: string | null, toolRegistryFingerprint: string, capabilityRegistryFingerprint: string, attemptGeneration: number, fencingToken: string}} input */
export const createFrozenEditorJobInput = (input) => {
  if (
    !isFingerprint(input.instructionFingerprint) ||
    !(input.baseTimelineFingerprint === null || isFingerprint(input.baseTimelineFingerprint)) ||
    !isFingerprint(input.toolRegistryFingerprint) ||
    !isFingerprint(input.capabilityRegistryFingerprint) ||
    !Number.isSafeInteger(input.attemptGeneration) ||
    input.attemptGeneration < 1 ||
    !opaqueId(input.fencingToken)
  ) {
    fail('EDITOR_JOB_INPUT_INVALID', 500)
  }
  return {
    instructionFingerprint: input.instructionFingerprint,
    baseTimelineFingerprint: input.baseTimelineFingerprint,
    toolRegistryFingerprint: input.toolRegistryFingerprint,
    capabilityRegistryFingerprint: input.capabilityRegistryFingerprint,
    attemptGeneration: input.attemptGeneration,
    fencingToken: input.fencingToken,
  }
}

/**
 * Persist only resume-safe committed executions for editor checkpoints.
 * Rejects path/URL/secret-shaped payloads before they reach durable storage.
 * @param {unknown} executions
 */
export const toEditorCheckpointCommittedExecutions = (executions) => {
  if (!Array.isArray(executions)) fail('EDITOR_CHECKPOINT_INVALID', 500)
  return executions.map((entry) => {
    if (
      !isRecord(entry) ||
      typeof entry.tool !== 'string' ||
      !EDITOR_TOOL_NAMES.includes(entry.tool) ||
      !opaqueId(entry.idempotencyKey) ||
      !isFingerprint(entry.requestHash) ||
      !('result' in entry)
    ) {
      fail('EDITOR_CHECKPOINT_INVALID', 500)
    }
    if (containsPrivateReference(entry.result)) {
      fail('EDITOR_CHECKPOINT_PRIVATE_REFERENCE', 500)
    }
    if (!validEditorCommittedExecutionResult(entry.tool, entry.result)) {
      fail('EDITOR_CHECKPOINT_INVALID', 500)
    }
    const result = structuredClone(entry.result)
    return {
      tool: entry.tool,
      idempotencyKey: entry.idempotencyKey,
      requestHash: entry.requestHash,
      resultFingerprint: fingerprintCanonical(result),
      result,
    }
  })
}

/** @param {string} tool @param {unknown} value */
export const validEditorCommittedExecutionResult = (tool, value) => {
  if (!isRecord(value)) return false
  if (tool === 'propose_timeline_patch') {
    return hasExactKeys(value, [
      'patchId',
      'validation',
      'errorCode',
      'proposedRevision',
      'proposedContentFingerprint',
      'proposedRevisionFingerprint',
    ]) &&
      opaqueId(value.patchId) &&
      value.validation === 'accepted' &&
      value.errorCode === null &&
      Number.isSafeInteger(value.proposedRevision) &&
      value.proposedRevision >= 1 &&
      isFingerprint(value.proposedContentFingerprint) &&
      isFingerprint(value.proposedRevisionFingerprint)
  }
  if (tool === 'finalize_timeline') {
    return hasExactKeys(value, [
      'status',
      'revision',
      'contentFingerprint',
      'revisionFingerprint',
    ]) &&
      value.status === 'finalized' &&
      Number.isSafeInteger(value.revision) &&
      value.revision >= 1 &&
      isFingerprint(value.contentFingerprint) &&
      isFingerprint(value.revisionFingerprint)
  }
  if (tool === 'apply_packaging_recommendation') {
    return hasExactKeys(value, [
      'patchId',
      'validation',
      'errorCode',
      'timelineId',
      'proposedRevision',
      'proposedContentFingerprint',
      'proposedRevisionFingerprint',
    ]) &&
      opaqueId(value.patchId) &&
      value.validation === 'accepted' &&
      value.errorCode === null &&
      opaqueId(value.timelineId) &&
      Number.isSafeInteger(value.proposedRevision) &&
      value.proposedRevision >= 1 &&
      isFingerprint(value.proposedContentFingerprint) &&
      isFingerprint(value.proposedRevisionFingerprint)
  }
  if (tool === 'request_preview' || tool === 'request_jianying_export') {
    return hasExactKeys(value, ['jobId', 'status']) &&
      opaqueId(value.jobId) &&
      value.status === 'queued'
  }
  return false
}

/**
 * Validate durable executions at the recovery trust boundary without regenerating evidence.
 * @param {unknown} executions
 */
export const toEditorResumeCommittedExecutions = (executions) => {
  if (!Array.isArray(executions)) fail('EDITOR_CHECKPOINT_INVALID', 500)
  const executionKeys = new Set()
  return executions.map((entry) => {
    if (
      !isRecord(entry) ||
      !hasExactKeys(entry, [
        'tool',
        'idempotencyKey',
        'requestHash',
        'resultFingerprint',
        'result',
      ]) ||
      typeof entry.tool !== 'string' ||
      ![
        'propose_timeline_patch',
        'apply_packaging_recommendation',
        'finalize_timeline',
        'request_preview',
        'request_jianying_export',
      ].includes(entry.tool) ||
      !opaqueId(entry.idempotencyKey) ||
      !isFingerprint(entry.requestHash) ||
      !isFingerprint(entry.resultFingerprint) ||
      containsPrivateReference(entry.result) ||
      !validEditorCommittedExecutionResult(entry.tool, entry.result)
    ) {
      fail('EDITOR_CHECKPOINT_INVALID', 500)
    }
    const result = structuredClone(entry.result)
    if (entry.resultFingerprint !== fingerprintCanonical(result)) {
      fail('EDITOR_CHECKPOINT_INVALID', 500)
    }
    const executionKey = `${entry.tool}\u0000${entry.idempotencyKey}`
    if (executionKeys.has(executionKey)) fail('EDITOR_CHECKPOINT_INVALID', 500)
    executionKeys.add(executionKey)
    return {
      tool: entry.tool,
      idempotencyKey: entry.idempotencyKey,
      requestHash: entry.requestHash,
      resultFingerprint: entry.resultFingerprint,
      result,
    }
  })
}

/**
 * Strip editor checkpoint payloads down to opaque IDs / fingerprints / budgets.
 * @param {unknown} data
 */
export const toEditorAgentCheckpointData = (data) => {
  if (!isRecord(data)) fail('EDITOR_CHECKPOINT_INVALID', 500)
  /** @type {Record<string, unknown>} */
  const out = {}
  if (typeof data.tool === 'string') {
    if (!EDITOR_TOOL_NAMES.includes(data.tool)) fail('EDITOR_CHECKPOINT_INVALID', 500)
    out.tool = data.tool
  }
  if (typeof data.argumentsFingerprint === 'string' && isFingerprint(data.argumentsFingerprint)) {
    out.argumentsFingerprint = data.argumentsFingerprint
  }
  if (typeof data.resultFingerprint === 'string' && isFingerprint(data.resultFingerprint)) {
    out.resultFingerprint = data.resultFingerprint
  }
  if (typeof data.instructionFingerprint === 'string' && isFingerprint(data.instructionFingerprint)) {
    out.instructionFingerprint = data.instructionFingerprint
  }
  if (Number.isSafeInteger(data.toolCalls) && data.toolCalls >= 0) {
    out.toolCalls = data.toolCalls
  }
  if (
    typeof data.detail === 'string' &&
    data.detail.trim().length > 0 &&
    data.detail.length <= 300
  ) {
    out.detail = data.detail.trim()
  }
  if (isRecord(data.frozen)) {
    out.frozen = createFrozenEditorJobInput(/** @type {any} */ (data.frozen))
  }
  if (Array.isArray(data.committedExecutions)) {
    out.committedExecutions = toEditorCheckpointCommittedExecutions(data.committedExecutions)
  }
  if (containsPrivateReference(out)) fail('EDITOR_CHECKPOINT_PRIVATE_REFERENCE', 500)
  return out
}

export const __testing = {
  stableStringify,
  isTimeRange,
}
