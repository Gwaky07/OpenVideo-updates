[CmdletBinding()]
param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$resolvedRoot = [IO.Path]::GetFullPath($RepositoryRoot)
$pnpmCommand = Get-Command pnpm.cmd -ErrorAction SilentlyContinue
$corepackCommand = Get-Command corepack.cmd -ErrorAction SilentlyContinue

if ($pnpmCommand) {
    $runner = $pnpmCommand.Source
    $runnerPrefix = @()
} elseif ($corepackCommand) {
    $runner = $corepackCommand.Source
    $runnerPrefix = @('pnpm')
} else {
    throw 'pnpm.cmd or corepack.cmd is required.'
}

Push-Location $resolvedRoot
try {
    & $runner @runnerPrefix --filter '@openvideo/gateway' exec node --test test/local-runtime.test.mjs test/workbench.test.mjs
    if ($LASTEXITCODE -ne 0) { throw 'PROD-001 Gateway tests failed.' }

    & $runner @runnerPrefix --filter '@openvideo/web' exec vitest run src/pages/ProjectMaterialsPage.test.tsx
    if ($LASTEXITCODE -ne 0) { throw 'PROD-001 web test failed.' }

    $trackedPrivateRuntime = @(& git ls-files '*projects.json' '*authorizations.json' '*tasks.json' '*.bak' '*.tmp')
    if ($LASTEXITCODE -ne 0) { throw 'Unable to inspect tracked runtime files.' }
    if ($trackedPrivateRuntime.Count -gt 0) {
        throw "Private runtime artifacts must not be tracked: $($trackedPrivateRuntime -join ', ')"
    }
}
finally {
    Pop-Location
}

Write-Host 'PROD-001 private runtime checks passed.' -ForegroundColor Green
