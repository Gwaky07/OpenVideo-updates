const fingerprintPattern = /^[a-f0-9]{64}$/u
const semverPattern = /^\d+\.\d+\.\d+(?:\.\d+)?$/u
const tokenPatterns = Object.freeze({
  'filter.video.named': /^ovjflt_v1_segment_[A-Za-z0-9_-]{32,160}$/u,
  'filter.video.track_named': /^ovjflt_v1_track_[A-Za-z0-9_-]{32,160}$/u,
})
const resourceIdPattern = /^[A-Za-z0-9_-]{4,80}$/u

export class JianyingFilterEvidenceError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'JianyingFilterEvidenceError'
    this.code = code
  }
}

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys */
const exactKeys = (value, keys) =>
  isRecord(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key))

/**
 * Validate a repository-external filter evidence pair and return only the
 * trusted binding fields needed by the writer/resolver boundary.
 */
/** @param {{generated: Record<string, any>, manual: Record<string, any>, trusted: Record<string, any>}} input */
export const validateJianyingFilterManualEvidence = ({ generated, manual, trusted }) => {
  const generatedKeys = [
    'schema_version', 'kind', 'capability_id', 'filter_token', 'desktop_version',
    'catalog_fingerprint', 'draft_fingerprint', 'opened', 'edited', 'saved',
  ]
  const manualKeys = [
    'schema_version', 'kind', 'capability_id', 'filter_token', 'desktop_version',
    'catalog_fingerprint', 'draft_fingerprint', 'opened', 'edited', 'saved',
  ]
  if (
    !exactKeys(generated, generatedKeys) || !exactKeys(manual, manualKeys) ||
    !isRecord(trusted) || !exactKeys(trusted, ['supportedVersion', 'catalogFingerprint', 'draftFingerprint'])
  ) throw new JianyingFilterEvidenceError('JY016_FILTER_EVIDENCE_SCHEMA_INVALID')
  const capabilityId = generated.capability_id
  const tokenPattern = /** @type {Record<string, RegExp>} */ (tokenPatterns)[capabilityId]
  if (
    generated.schema_version !== 1 || generated.kind !== 'jy016_filter_generated_evidence' ||
    manual.schema_version !== 1 || manual.kind !== 'jy016_filter_manual_evidence' ||
    typeof capabilityId !== 'string' || !tokenPattern || !tokenPattern.test(generated.filter_token) ||
    manual.capability_id !== capabilityId || manual.filter_token !== generated.filter_token ||
    typeof generated.desktop_version !== 'string' || !semverPattern.test(generated.desktop_version) ||
    manual.desktop_version !== generated.desktop_version || trusted.supportedVersion !== generated.desktop_version ||
    typeof generated.catalog_fingerprint !== 'string' || !fingerprintPattern.test(generated.catalog_fingerprint) ||
    manual.catalog_fingerprint !== generated.catalog_fingerprint || trusted.catalogFingerprint !== generated.catalog_fingerprint ||
    typeof generated.draft_fingerprint !== 'string' || !fingerprintPattern.test(generated.draft_fingerprint) ||
    manual.draft_fingerprint !== generated.draft_fingerprint || trusted.draftFingerprint !== generated.draft_fingerprint ||
    generated.opened !== false || generated.edited !== false || generated.saved !== false ||
    manual.opened !== true || manual.edited !== true || manual.saved !== true
  ) throw new JianyingFilterEvidenceError('JY016_FILTER_EDITABLE_EVIDENCE_MISSING')
  return Object.freeze({
    capabilityId,
    filterToken: generated.filter_token,
    supportedVersion: generated.desktop_version,
    catalogFingerprint: generated.catalog_fingerprint,
    draftFingerprint: generated.draft_fingerprint,
    opened: true,
    edited: true,
    saved: true,
  })
}

/**
 * Validate a private runtime catalog entry. The resource id never belongs in a
 * public contract; this helper returns it only to an internal writer boundary.
 */
/** @param {unknown} entry */
export const validateJianyingFilterCatalogEntry = (entry) => {
  const keys = ['schema_version', 'kind', 'capability_id', 'filter_token', 'resource_id', 'catalog_fingerprint', 'catalog_version']
  if (!exactKeys(entry, keys)) throw new JianyingFilterEvidenceError('JY016_FILTER_CATALOG_SCHEMA_INVALID')
  const record = /** @type {Record<string, any>} */ (entry)
  const tokenPattern = /** @type {Record<string, RegExp>} */ (tokenPatterns)[record.capability_id]
  if (
    record.schema_version !== 1 || record.kind !== 'jy016_filter_catalog' ||
    typeof record.capability_id !== 'string' || !tokenPattern ||
    typeof record.filter_token !== 'string' || !tokenPattern.test(record.filter_token) ||
    typeof record.resource_id !== 'string' || !resourceIdPattern.test(record.resource_id) ||
    typeof record.catalog_fingerprint !== 'string' || !fingerprintPattern.test(record.catalog_fingerprint) ||
    typeof record.catalog_version !== 'string' || !semverPattern.test(record.catalog_version)
  ) throw new JianyingFilterEvidenceError('JY016_FILTER_CATALOG_INVALID')
  return Object.freeze({
    capabilityId: record.capability_id,
    filterToken: record.filter_token,
    resourceId: record.resource_id,
    catalogFingerprint: record.catalog_fingerprint,
    catalogVersion: record.catalog_version,
  })
}
