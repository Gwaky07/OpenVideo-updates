import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { access, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import { projectRichTimelineToJianyingExport } from '../apps/gateway/src/rich-timeline-jianying-projection.mjs'
import { computeCapabilityRequirements, finalizeRichTimeline, sealRichTimeline } from '../apps/gateway/src/rich-timeline-contracts.mjs'

const run = promisify(execFile)
const profileId = 'jianying-11-2-provisional'
const durationUs = 4_000_000

const capabilityRegistry = {
  assertWriterCapability(capabilityId, target) {
    if (target !== 'jianying' || !['track.insert', 'transition.none', 'audio.voiceover.edge_tts'].includes(capabilityId)) {
      throw new Error(`JY092_UNEXPECTED_CAPABILITY:${capabilityId}`)
    }
    return {}
  },
}

const createTimeline = () => {
  const tracks = [
    {
      trackId: 'video-primary', order: 0, enabled: true, locked: false, kind: 'video', role: 'primary',
      segments: [{
        segmentId: 'jy092-video', kind: 'video',
        asset: { authorizationId: 'jy092-auth', assetId: 'jy092-video', sceneId: 'jy092-scene' },
        sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs },
        fit: 'cover', volume: 1, speed: { numerator: 1, denominator: 1 }, keyframes: [], effects: [],
        audit: { origin: 'editor', candidateId: 'jy092-candidate', instructionFingerprint: null },
        transitionOut: { capabilityId: 'transition.none', durationUs: 0, parameters: {} },
      }],
    },
    {
      trackId: 'voiceover-guide', order: 1, enabled: true, locked: false, kind: 'audio', role: 'voiceover',
      segments: [{
        segmentId: 'jy092-voiceover', kind: 'voiceover', capabilityId: 'audio.voiceover.edge_tts',
        source: { kind: 'generated', generatedAudioId: 'jy092-audio-token' },
        sourceRange: { startUs: 0, durationUs }, targetRange: { startUs: 0, durationUs },
        volume: 1, fadeInUs: 0, fadeOutUs: 0, keyframes: [], ducking: 'none',
      }],
    },
  ]
  return finalizeRichTimeline(sealRichTimeline({
    schemaVersion: 1, timelineId: 'jy092-track-insert', projectId: 'jy092', revision: 1,
    parentRevision: null, parentRevisionFingerprint: null, status: 'draft',
    createdAt: '2026-08-13T00:00:00.000Z', durationUs, orientation: 'portrait',
    fps: { numerator: 30, denominator: 1 },
    source: { kind: 'editor', editPlanFingerprint: 'a'.repeat(64), templateFingerprint: null, instructionFingerprint: null },
    tracks, markers: [], capabilityRequirements: computeCapabilityRequirements(tracks),
  }))
}

const main = async () => {
  let stage = 'desktop'
  const manifest = JSON.parse(await readFile(new URL('../config/jianying-compatibility.json', import.meta.url), 'utf8'))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true || desktop.profileId !== profileId || typeof desktop.draftRoot !== 'string') {
    throw new Error('JY092_PROFILE_UNSUPPORTED')
  }
  stage = 'projection'
  const projected = projectRichTimelineToJianyingExport(createTimeline(), { capabilityRegistry })
  const draftId = `OpenVideo-JY092-track-insert-${Date.now()}`
  const evidenceRoot = path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', 'jy092-track-insert')
  const pendingPath = path.join(evidenceRoot, 'pending.json')
  await mkdir(evidenceRoot, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(evidenceRoot)
  try {
    await access(pendingPath)
    throw new Error('JY092_PENDING_EVIDENCE_EXISTS')
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy092-track-insert-'))
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const audioPath = path.join(mediaRoot, 'voiceover.wav')
  const writer = createPyJianyingDraftWriter({
    draftRoot: desktop.draftRoot,
    pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT,
    getRenderOptions: () => ({
      captions: false, bgmPath: null, subtitleStyle: 'default', captionSegments: [], titleSegments: [], keywordHighlights: [],
      trackInsertionProfile: desktop.profileId,
      trackInsertionCapability: 'track.insert',
      timelinePackaging: { ...projected.packaging, sfx_segments: [], effect_segments: [], sticker_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 } },
    }),
  })
  const request = {
    job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId },
    export_request: { preparation: projected.preparation, packaging: projected.packaging },
    orientation: 'portrait', materials: [{ path: videoPath }], voiceovers: [{ path: audioPath }],
  }
  let result = null
  let released = false
  try {
    stage = 'media'
    await Promise.all([
      run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath]),
      run('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=16000', '-t', '4', '-ac', '1', audioPath]),
    ])
    stage = 'write'
    result = await writer.writeDraft(request)
    stage = 'verify'
    if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) {
      throw new Error('JY092_DRAFT_VERIFY_FAILED')
    }
    stage = 'evidence'
    const content = await readFile(path.join(desktop.draftRoot, draftId, 'draft_content.json'))
    await writeFile(pendingPath, `${JSON.stringify({
      schema_version: 1, draft_id: draftId, draft_root: desktop.draftRoot, media_root: mediaRoot,
      profile_id: desktop.profileId, app_version: desktop.version,
      expected_track_names: ['video-primary', 'voiceover-primary'], expected_auxiliary_volume: 1,
      pre_open_fingerprint: createHash('sha256').update(content).digest('hex'),
    })}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    stage = 'release'
    if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY092_DRAFT_RELEASE_FAILED')
    released = true
    process.stdout.write(`${JSON.stringify({
      ok: true, draft_id: draftId, manual_open_required: true, profile: desktop.profileId,
      version: desktop.version, auxiliary_track: 'voiceover-primary', change_volume_from_db: 0, change_volume_to_db: -6,
    })}\n`)
  } catch (error) {
    if (!released && result) {
      try { await writer.cleanupDraft({ job_id: request.job_id }) } catch {
        try { await writer.cleanupOwnedDraft({ requestId: request.request_id, draftId }) } catch { /* Preserve original failure. */ }
      }
    }
    if (!released) await rm(mediaRoot, { recursive: true, force: true })
    if (error && typeof error === 'object') error.jy092Stage = stage
    throw error
  }
}

main().catch((error) => {
  process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY092_DRAFT_FAILED', stage: error?.jy092Stage ?? 'startup', exception_type: error?.constructor?.name ?? 'Error' })}\n`)
  process.exitCode = 1
})
