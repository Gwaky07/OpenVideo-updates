/**
 * @typedef {{candidate_id: string, asset_id: string, scene_id: string}} SceneCandidate
 */

/** @param {SceneCandidate} candidate */
const sceneKey = (candidate) => `${candidate.asset_id}\u0000${candidate.scene_id}`

/**
 * @template {SceneCandidate} Candidate
 * @param {string[]} sentenceIds
 * @param {Map<string, Candidate[]>} candidatesBySentence
 * @param {Set<string>} blockedScenes
 */
const maximumMatchingCount = (sentenceIds, candidatesBySentence, blockedScenes) => {
  /** @type {Map<string, string>} */
  const sentenceByScene = new Map()
  /** @param {string} sentenceId @param {Set<string>} visitedScenes */
  const assign = (sentenceId, visitedScenes) => {
    for (const candidate of candidatesBySentence.get(sentenceId) ?? []) {
      const candidateSceneKey = sceneKey(candidate)
      if (blockedScenes.has(candidateSceneKey) || visitedScenes.has(candidateSceneKey)) continue
      visitedScenes.add(candidateSceneKey)
      const ownerSentenceId = sentenceByScene.get(candidateSceneKey)
      if (ownerSentenceId !== undefined && !assign(ownerSentenceId, visitedScenes)) continue
      sentenceByScene.set(candidateSceneKey, sentenceId)
      return true
    }
    return false
  }
  let count = 0
  for (const sentenceId of sentenceIds) {
    if (assign(sentenceId, new Set())) count += 1
  }
  return count
}

/**
 * Maximizes unique-scene coverage, then preserves sentence order and each
 * sentence's candidate preference order exactly.
 * @template {SceneCandidate} Candidate
 * @param {string[]} sentenceIds
 * @param {Map<string, Candidate[]>} candidatesBySentence
 * @returns {Map<string, Candidate>}
 */
export const assignUniqueSceneCandidates = (sentenceIds, candidatesBySentence) => {
  /** @type {Map<string, Candidate[]>} */
  const canonicalCandidates = new Map()
  for (const sentenceId of sentenceIds) {
    const seenScenes = new Set()
    const candidates = []
    for (const candidate of candidatesBySentence.get(sentenceId) ?? []) {
      const candidateSceneKey = sceneKey(candidate)
      if (seenScenes.has(candidateSceneKey)) continue
      seenScenes.add(candidateSceneKey)
      candidates.push(candidate)
    }
    canonicalCandidates.set(sentenceId, candidates)
  }

  const targetCount = maximumMatchingCount(sentenceIds, canonicalCandidates, new Set())
  /** @type {Map<string, Candidate>} */
  const selectedBySentence = new Map()
  const selectedScenes = new Set()
  let selectedCount = 0
  for (let index = 0; index < sentenceIds.length; index += 1) {
    const sentenceId = sentenceIds[index]
    const remainingSentenceIds = sentenceIds.slice(index + 1)
    for (const candidate of canonicalCandidates.get(sentenceId) ?? []) {
      const candidateSceneKey = sceneKey(candidate)
      if (selectedScenes.has(candidateSceneKey)) continue
      selectedScenes.add(candidateSceneKey)
      const possibleCount = selectedCount + 1 + maximumMatchingCount(
        remainingSentenceIds,
        canonicalCandidates,
        selectedScenes,
      )
      if (possibleCount === targetCount) {
        selectedBySentence.set(sentenceId, candidate)
        selectedCount += 1
        break
      }
      selectedScenes.delete(candidateSceneKey)
    }
  }
  return selectedBySentence
}
