import { execFile as execFileCallback } from 'node:child_process'
import { createHash } from 'node:crypto'
import { createReadStream, createWriteStream } from 'node:fs'
import { lstat, mkdir, open, readdir, readFile, realpath, unlink, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { pipeline } from 'node:stream/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

import {
  canonicalJY200DuoJson,
  createJY200DuoProbeExecutionReceipt,
  fingerprintJY200DuoExecutionDraft,
  fingerprintJY200DuoValue,
} from './jianying-duo-direct-probe-evidence.mjs'
import {
  validateJY200ProbeArtifactTree,
  validateJY200ProbeStagingRoot,
} from './jianying-artist-effect-probe.mjs'
import { readFileNoReparse, readFileNoReparseBuffer } from './jianying-native-safe-file.mjs'

const execFile = promisify(execFileCallback)
const FINGERPRINT = /^[a-f0-9]{64}$/u
const COMMIT = /^[a-f0-9]{40}$/u
const SAFE_RELATIVE_CONFIG = /^(?:flower|sticker|video_effect)\/[0-9]{1,19}\.json$/u
const NUMERIC_ID = /^[1-9][0-9]{0,18}$/u
const JAVA_LONG_MAX = BigInt('9223372036854775807')
const PRODUCT_CLI_CLASS = 'OpenVideoJY200DuoProductRunner'
const DRAFT_AUDIO_PLACEHOLDER = /^##_draftpath_placeholder_[A-Za-z0-9-]{8,80}_##\/Resources\/local\/audio\/([^/\\]+)$/u
const RECEIPT_BINDING_KEYS = Object.freeze([
  'schema_version', 'kind', 'family', 'packaging_token', 'binding_fingerprint',
  'source_material_fingerprint', 'payload_fingerprint', 'source_fingerprint',
  'catalog_fingerprint', 'desktop_binding_fingerprint', 'resource_mode',
  'admission', 'writer_eligible', 'probe_candidate',
])

/** @typedef {Record<string, any>} RecordValue */
/**
 * @typedef {{
 *   family: 'sticker'|'flower'|'video_effect',
 *   resourceId?: string,
 *   effectId?: string,
 *   relativeConfigPath?: string,
 *   jyResource?: RecordValue,
 *   publicEvidence?: RecordValue,
 *   privateBinding?: {resourceId?: string, effectId?: string},
 *   private_binding?: {resourceId?: string, effectId?: string},
 * }} RuntimeBinding
 */
/**
 * @typedef {{
 *   family: 'sticker'|'flower'|'video_effect',
 *   resourceId: string,
 *   effectId?: string,
 *   relativeConfigPath: string,
 *   jyResource: RecordValue,
 *   publicEvidence: RecordValue,
 * }} NormalizedRuntimeBinding
 */
/**
 * @typedef {{
 *   draftName: string,
 *   font: Readonly<{name: string, url: string}>,
 *   videos: readonly RecordValue[],
 *   texts: readonly RecordValue[],
 *   stickers: readonly RecordValue[],
 *   videoEffects: readonly RecordValue[],
 *   audios: readonly RecordValue[],
 * }} NormalizedPlan
 */

/** @param {string} code @returns {never} */
const fail = (code) => {
  const error = new Error(code)
  // @ts-expect-error OpenVideo errors expose stable machine-readable codes.
  error.code = code
  throw error
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {import('node:fs').Stats|import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`

/**
 * Windows realpath may return an 8.3 alias. Accept a different spelling only
 * when both names still identify the same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').BigIntStats} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  return objectIdentity(requestedMetadata) === objectIdentity(await lstat(actual, { bigint: true }))
}

/** @param {unknown} value @returns {value is RecordValue} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @returns {value is string} */
const safeText = (value) => typeof value === 'string' && value.length > 0 && value.length <= 200 &&
  !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(value)
/** @param {unknown} value @returns {number} */
const toMilliseconds = (value) => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value % 1_000 === 0
  ? value / 1_000
  : fail('JY200_DUO_PRODUCT_TIMING_UNSUPPORTED')
/** @param {unknown} value @returns {value is string} */
const numericResourceId = (value) => typeof value === 'string' && NUMERIC_ID.test(value) && BigInt(value) <= JAVA_LONG_MAX
/** @param {RecordValue} value */
const receiptBinding = (value) => Object.freeze(Object.fromEntries(
  RECEIPT_BINDING_KEYS.map((key) => [key, value?.[key]]),
))

/** @param {string} filePath @returns {Promise<string>} */
const sha256File = (filePath) => new Promise((resolve, reject) => {
  const hash = createHash('sha256')
  const stream = createReadStream(filePath)
  stream.on('data', (chunk) => hash.update(chunk))
  stream.on('error', reject)
  stream.on('end', () => resolve(hash.digest('hex')))
})

/**
 * Duo rewrites local material paths to a draft-relative placeholder while
 * preserving the staged source basename. Keep the check bound to the plan's
 * file URI so arbitrary placeholder paths cannot satisfy readback.
 * @param {unknown} actualPath
 * @param {unknown} expectedUrl
 * @returns {boolean}
 */
const matchesDraftAudioPath = (actualPath, expectedUrl) => {
  if (typeof actualPath !== 'string' || typeof expectedUrl !== 'string') return false
  if (actualPath === expectedUrl) return true
  const match = DRAFT_AUDIO_PLACEHOLDER.exec(actualPath)
  if (!match) return false
  let expectedBasename
  try {
    expectedBasename = path.basename(fileURLToPath(expectedUrl))
  } catch {
    return false
  }
  let placeholderBasename
  try {
    placeholderBasename = decodeURIComponent(match[1])
  } catch {
    return false
  }
  return placeholderBasename === expectedBasename
}

/** @returns {NodeJS.ProcessEnv} */
const safeEnvironment = () => {
  /** @type {NodeJS.ProcessEnv} */
  const output = {}
  for (const expected of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP']) {
    const actual = Object.keys(process.env).find((key) => key.toLowerCase() === expected.toLowerCase())
    if (actual && typeof process.env[actual] === 'string') output[expected] = process.env[actual]
  }
  return output
}

const resolveDefaultLocalFont = () => {
  const windowsRoot = process.env.SystemRoot || process.env.WINDIR
  if (typeof windowsRoot !== 'string' || !path.isAbsolute(windowsRoot)) {
    fail('JY200_DUO_PRODUCT_FONT_UNAVAILABLE')
  }
  return path.join(windowsRoot, 'Fonts', 'msyh.ttc')
}

/** @param {unknown} error */
export const classifyJY200DuoProductCliFailure = (error) => {
  const record = isRecord(error) ? error : {}
  const source = Object.keys(record).length > 0
    ? [record.stderr, record.stdout, record.message]
      .map((value) => Buffer.isBuffer(value) ? value.toString('utf8') : typeof value === 'string' ? value : '')
      .join('\n')
    : ''
  if (/prepared local material/u.test(source)) return 'local_material_binding'
  if (/font payload is unavailable|JianyingResourceUtils\.getFontFile|没有找到字体|下载字体文件失败/u.test(source)) return 'font_payload'
  if (/resource binding is unavailable/u.test(source)) return 'resource_binding'
  if (/resource payload is unavailable/u.test(source)) return 'resource_payload'
  if (/JY200_DUO_PRODUCT_(?:ARGUMENT|PLAN)_INVALID/u.test(source)) return 'plan_contract'
  return 'cli_execution'
}

/** @param {unknown} sourcePath */
const validateSourceFile = async (sourcePath) => {
  if (typeof sourcePath !== 'string' || !path.isAbsolute(sourcePath)) fail('JY200_DUO_PRODUCT_SOURCE_INVALID')
  const [metadata, actual] = await Promise.all([lstat(sourcePath, { bigint: true }), realpath(sourcePath)])
  if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size <= 0n ||
      !await sameResolvedObject(sourcePath, actual, metadata)) {
    fail('JY200_DUO_PRODUCT_SOURCE_INVALID')
  }
}

/** @param {RecordValue} writePlan @param {readonly RecordValue[]} resolvedAudioSources @param {string} localFontPath @returns {Promise<Readonly<NormalizedPlan>>} */
const normalizePlan = async (writePlan, resolvedAudioSources = [], localFontPath = resolveDefaultLocalFont()) => {
  const video = writePlan?.videoMaterials
  const titles = writePlan?.titleTexts
  const captions = writePlan?.captionTexts ?? []
  const audio = writePlan?.audioPlacements ?? []
  const placements = writePlan?.packagingPlacements
  if (!isRecord(writePlan) || writePlan.offlineOnly !== true || !safeText(writePlan.draftName)) {
    fail('JY200_DUO_PRODUCT_PLAN_HEADER_UNSUPPORTED')
  }
  if (!Array.isArray(video) || video.length === 0 || !Array.isArray(titles) || !Array.isArray(captions) ||
      !Array.isArray(audio) || resolvedAudioSources.length !== audio.length) {
    fail('JY200_DUO_PRODUCT_PLAN_TRACKS_UNSUPPORTED')
  }
  if (!isRecord(placements) || !Array.isArray(placements.sticker) ||
      !Array.isArray(placements.flower) || !Array.isArray(placements.video_effect)) {
    fail('JY200_DUO_PRODUCT_PLAN_PACKAGING_UNSUPPORTED')
  }
  if (!FINGERPRINT.test(writePlan.timelineFingerprint ?? '') || !COMMIT.test(writePlan.providerCommit ?? '')) {
    fail('JY200_DUO_PRODUCT_PLAN_IDENTITY_UNSUPPORTED')
  }
  await Promise.all(video.map((entry) => validateSourceFile(entry.sourcePath)))
  await Promise.all(resolvedAudioSources.map((entry) => validateSourceFile(entry.sourcePath)))
  await validateSourceFile(localFontPath).catch(() => fail('JY200_DUO_PRODUCT_FONT_UNAVAILABLE'))
  if (![...titles, ...captions, ...placements.flower].every((entry) => safeText(entry.text))) {
    fail('JY200_DUO_PRODUCT_PLAN_TEXT_UNSUPPORTED')
  }
  if (![...placements.sticker, ...placements.flower, ...placements.video_effect]
    .every((entry) => numericResourceId(entry.resourceId))) {
    fail('JY200_DUO_PRODUCT_PLAN_RESOURCE_UNSUPPORTED')
  }
  if (resolvedAudioSources.some((entry, index) => entry.audioToken !== audio[index]?.audioToken)) {
    fail('JY200_DUO_PRODUCT_PLAN_AUDIO_BINDING_UNSUPPORTED')
  }
  const audioPlans = await Promise.all(audio.map(async (entry, index) => {
    const sourcePath = resolvedAudioSources[index].sourcePath
    const sourceFingerprint = typeof resolvedAudioSources[index].sourceFingerprint === 'string' &&
      FINGERPRINT.test(resolvedAudioSources[index].sourceFingerprint)
      ? resolvedAudioSources[index].sourceFingerprint
      : await sha256File(sourcePath)
    return Object.freeze({
      role: entry.role,
      audioToken: entry.audioToken,
      sourceFingerprint,
      url: pathToFileURL(sourcePath).href,
      start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs),
      sourceStart: toMilliseconds(entry.sourceStartUs), sourceDuration: toMilliseconds(entry.sourceDurationUs),
      volume: Math.round(entry.volume * 100),
    })
  }))
  return Object.freeze({
    draftName: writePlan.draftName,
    font: Object.freeze({ name: 'OpenVideo Local Font', url: pathToFileURL(localFontPath).href }),
    videos: Object.freeze(video.map((entry) => Object.freeze({
      url: pathToFileURL(entry.sourcePath).href,
      start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs),
      sourceStart: toMilliseconds(entry.sourceStartUs), sourceDuration: toMilliseconds(entry.sourceDurationUs),
    }))),
    texts: Object.freeze([
      ...titles.map((entry) => Object.freeze({ text: entry.text, start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs) })),
      ...captions.map((entry) => Object.freeze({ text: entry.text, start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs) })),
      ...placements.flower.map((entry) => Object.freeze({ text: entry.text, flowerId: entry.resourceId, start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs) })),
    ]),
    stickers: Object.freeze(placements.sticker.map((entry) => Object.freeze({ resourceId: entry.resourceId, start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs) }))),
    videoEffects: Object.freeze(placements.video_effect.map((entry) => Object.freeze({ resourceId: entry.resourceId, start: toMilliseconds(entry.targetStartUs), duration: toMilliseconds(entry.targetDurationUs) }))),
    audios: audioPlans,
  })
}

const supportedAudioExtensions = new Set(['.aac', '.flac', '.m4a', '.mp3', '.ogg', '.wav'])

/** @param {string} sourcePath */
const detectOpaqueAudioExtension = async (sourcePath) => {
  const handle = await open(sourcePath, 'r')
  try {
    const header = Buffer.alloc(12)
    const { bytesRead } = await handle.read(header, 0, header.length, 0)
    if (bytesRead >= 3 && (
      header.subarray(0, 3).equals(Buffer.from('ID3')) ||
      (header[0] === 0xff && (header[1] & 0xe0) === 0xe0)
    )) return '.mp3'
    if (bytesRead >= 12 && header.subarray(0, 4).equals(Buffer.from('RIFF')) &&
        header.subarray(8, 12).equals(Buffer.from('WAVE'))) return '.wav'
    fail('JY200_DUO_PRODUCT_AUDIO_FORMAT_UNSUPPORTED')
  } finally {
    await handle.close()
  }
}

/** @param {unknown} value @returns {boolean} */
const isLocalFileUrl = (value) => {
  if (typeof value !== 'string' || !value.startsWith('file:')) return false
  try {
    const parsed = new URL(value)
    return parsed.protocol === 'file:' && parsed.hostname === '' && path.isAbsolute(fileURLToPath(parsed))
  } catch {
    return false
  }
}

/** @param {string} directory @param {string} parent @returns {Promise<void>} */
const assertOrdinaryDirectory = async (directory, parent) => {
  const [directoryStat, parentStat, directoryReal, parentReal] = await Promise.all([
    lstat(directory, { bigint: true }), lstat(parent, { bigint: true }), realpath(directory), realpath(parent),
  ])
  if (!directoryStat.isDirectory() || directoryStat.isSymbolicLink() ||
      !parentStat.isDirectory() || parentStat.isSymbolicLink() ||
      !await sameResolvedObject(directory, directoryReal, directoryStat) ||
      !await sameResolvedObject(parent, parentReal, parentStat)) {
    fail('JY200_DUO_PRODUCT_AUDIO_ALIAS_UNSAFE')
  }
}

/**
 * Narration artifacts deliberately use an opaque `.audio` suffix in private
 * storage. Duo preserves source basenames, while Jianying requires a real
 * media suffix to recognize the payload. Create an execution-owned alias only
 * after validating the file signature; never rename or rewrite the source.
 * @param {string} stagingRoot
 * @param {readonly RecordValue[]} sources
 */
const prepareDuoAudioSources = async (stagingRoot, sources) => {
  await Promise.all(sources.map((entry) => validateSourceFile(entry?.sourcePath)))
  const prepared = []
  let aliasRoot = null
  for (const [index, entry] of sources.entries()) {
    const sourcePath = entry.sourcePath
    const extension = path.extname(sourcePath).toLowerCase()
    if (supportedAudioExtensions.has(extension)) {
      prepared.push(entry)
      continue
    }
    if (extension !== '.audio') fail('JY200_DUO_PRODUCT_AUDIO_FORMAT_UNSUPPORTED')
    const detectedExtension = await detectOpaqueAudioExtension(sourcePath)
    aliasRoot ??= path.join(stagingRoot, '.openvideo-audio-alias')
    await mkdir(aliasRoot, { recursive: true, mode: 0o700 })
    await assertOrdinaryDirectory(stagingRoot, path.dirname(stagingRoot))
    await assertOrdinaryDirectory(aliasRoot, stagingRoot)
    const aliasPath = path.join(aliasRoot, `${String(index + 1).padStart(3, '0')}${detectedExtension}`)
    await pipeline(
      createReadStream(sourcePath),
      createWriteStream(aliasPath, { flags: 'wx', mode: 0o600 }),
    )
    await assertOrdinaryDirectory(aliasRoot, stagingRoot)
    const aliasStat = await lstat(aliasPath, { bigint: true })
    const aliasReal = await realpath(aliasPath)
    if (!aliasStat.isFile() || aliasStat.isSymbolicLink() ||
        !await sameResolvedObject(aliasPath, aliasReal, aliasStat)) {
      await unlink(aliasPath).catch(() => {})
      fail('JY200_DUO_PRODUCT_AUDIO_ALIAS_UNSAFE')
    }
    prepared.push(Object.freeze({ ...entry, sourcePath: aliasPath }))
  }
  return Object.freeze(prepared)
}
/**
 * @param {{runtimeRoot: string, bindings: readonly RuntimeBinding[]}} input
 * @returns {Promise<Readonly<{expectations: ReadonlyArray<Readonly<{target: string, expected: string}>>, bindings: ReadonlyArray<NormalizedRuntimeBinding>}>>}
 */
const stageRuntimeBindings = async ({ runtimeRoot, bindings }) => {
  if (!Array.isArray(bindings) || bindings.length !== 3) fail('JY200_DUO_PRODUCT_BINDING_COUNT_INVALID')
  const families = bindings.map((entry) => entry?.family).sort().join('\0')
  if (families !== 'flower\0sticker\0video_effect') fail('JY200_DUO_PRODUCT_BINDING_FAMILIES_INVALID')
  /** @type {Array<Readonly<{target: string, expected: string}>>} */
  const expectations = []
  /** @type {NormalizedRuntimeBinding[]} */
  const normalizedBindings = []
  for (const binding of bindings) {
    const resourceId = binding.resourceId ?? binding.privateBinding?.resourceId ?? binding.private_binding?.resourceId
    const effectId = binding.effectId ?? binding.privateBinding?.effectId ?? binding.private_binding?.effectId
    const relativeConfigPath = binding.relativeConfigPath ??
      (typeof resourceId === 'string' ? binding.family + '/' + resourceId + '.json' : null)
    let jyResource = binding.jyResource
    if (!isRecord(jyResource) && SAFE_RELATIVE_CONFIG.test(relativeConfigPath ?? '')) {
      try {
        jyResource = JSON.parse(await readFile(path.join(runtimeRoot, 'tmp', 'rs', ...relativeConfigPath.split('/')), 'utf8'))
      } catch { /* missing installed payload remains fail-closed below */ }
    }
    if (!SAFE_RELATIVE_CONFIG.test(relativeConfigPath ?? '')) fail('JY200_DUO_PRODUCT_BINDING_PATH_INVALID')
    if (!isRecord(jyResource)) fail('JY200_DUO_PRODUCT_BINDING_PAYLOAD_MISSING')
    if (jyResource.resourceId !== resourceId) fail('JY200_DUO_PRODUCT_BINDING_RESOURCE_MISMATCH')
    if (jyResource.type !== binding.family) fail('JY200_DUO_PRODUCT_BINDING_TYPE_MISMATCH')
    if (jyResource.status !== 1) fail('JY200_DUO_PRODUCT_BINDING_STATUS_INVALID')
    if (!Array.isArray(jyResource.resources) || jyResource.resources.length !== 0) {
      fail('JY200_DUO_PRODUCT_BINDING_NETWORK_RESOURCES_DENIED')
    }
    const target = path.join(runtimeRoot, 'tmp', 'rs', ...relativeConfigPath.split('/'))
    const expected = JSON.stringify(jyResource) + "\n"
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 })
    try {
      const current = await readFile(target, 'utf8')
      if (current !== expected) fail('JY200_DUO_LOCAL_RESOURCE_REPLACED')
    } catch (/** @type {any} */ error) {
      if (error?.code !== 'ENOENT') throw error
      await writeFile(target, expected, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    }
    expectations.push(Object.freeze({ target, expected }))
    const evidence = isRecord(binding.publicEvidence) ? binding.publicEvidence : /** @type {RecordValue} */ (binding)
    const publicEvidence = Object.freeze({
      schema_version: evidence.schema_version,
      kind: evidence.kind,
      family: evidence.family,
      packaging_token: evidence.packaging_token,
      binding_fingerprint: evidence.binding_fingerprint,
      source_material_fingerprint: evidence.source_material_fingerprint,
      payload_fingerprint: evidence.payload_fingerprint,
      source_fingerprint: evidence.source_fingerprint,
      catalog_fingerprint: evidence.catalog_fingerprint,
      desktop_binding_fingerprint: evidence.desktop_binding_fingerprint,
      resource_mode: evidence.resource_mode,
      admission: evidence.admission,
      writer_eligible: evidence.writer_eligible,
      probe_candidate: evidence.probe_candidate,
    })
    normalizedBindings.push(Object.freeze({
      ...binding,
      resourceId,
      ...(effectId ? { effectId } : {}),
      relativeConfigPath,
      jyResource,
      publicEvidence,
    }))
  }
  return Object.freeze({ expectations: Object.freeze(expectations), bindings: Object.freeze(normalizedBindings) })
}

/**
 * @param {{javaExecutable: string, runtimeRoot: string, classpath: string,
 *   productCli: RecordValue, stagingRoot: string, plan: NormalizedPlan}} input
 */
const executeCli = async ({ javaExecutable, runtimeRoot, classpath, productCli, stagingRoot, plan }) => {
  const verifyCli = async () => {
    if (productCli?.className !== PRODUCT_CLI_CLASS || !FINGERPRINT.test(productCli?.classSha256 ?? '') ||
        typeof productCli?.classFile !== 'string' || typeof productCli?.runtimeRoot !== 'string' ||
        !path.isAbsolute(productCli.classFile) || !path.isAbsolute(productCli.runtimeRoot)) {
      fail('JY200_DUO_PRODUCT_CLI_INVALID')
    }
    const bytes = await readFileNoReparseBuffer(productCli.classFile, productCli.runtimeRoot, 1024 * 1024)
    if (createHash('sha256').update(bytes).digest('hex') !== productCli.classSha256) {
      fail('JY200_DUO_PRODUCT_CLI_REPLACED')
    }
  }
  await verifyCli()
  const options = { cwd: runtimeRoot, env: safeEnvironment(), windowsHide: true, timeout: 60_000, maxBuffer: 64 * 1024 }
  const planFile = path.join(stagingRoot, `.openvideo-duo-plan-${createHash('sha256').update(JSON.stringify(plan)).digest('hex').slice(0, 24)}.json`)
  try {
    await writeFile(planFile, `${JSON.stringify(plan)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
    await execFile(javaExecutable, [
      '-cp', `${productCli.classRoot}${path.delimiter}${classpath}`,
      productCli.className, stagingRoot, planFile,
    ], options)
  } catch (error) {
    const failure = new Error('JY200_DUO_PRODUCT_CLI_FAILED')
    // This non-enumerable stage is available to private diagnostics without
    // exposing the upstream command line, local paths, or stderr.
    Object.defineProperties(failure, {
      code: { value: 'JY200_DUO_PRODUCT_CLI_FAILED', enumerable: false },
      privateStage: { value: classifyJY200DuoProductCliFailure(error), enumerable: false },
    })
    throw failure
  } finally {
    await unlink(planFile).catch(() => {})
  }
  await verifyCli()
}

/**
 * @param {{draft: RecordValue, plan: NormalizedPlan, bindings: readonly NormalizedRuntimeBinding[], artifactRoot: string}} input
 * @returns {Promise<Readonly<{tracks: number, segments: number, videos: number, titles: number,
 *   stickers: number, flowers: number, video_effects: number}>|null>}
 */
const inspectProductDraft = async ({ draft, plan, bindings, artifactRoot }) => {
  const materials = isRecord(draft?.materials) ? draft.materials : {}
  const tracks = Array.isArray(draft?.tracks) ? draft.tracks : []
  const videos = Array.isArray(materials.videos) ? materials.videos : []
  const texts = Array.isArray(materials.texts) ? materials.texts : []
  const stickers = Array.isArray(materials.stickers) ? materials.stickers : []
  const effects = Array.isArray(materials.effects) ? materials.effects : []
  const videoEffects = Array.isArray(materials.video_effects) ? materials.video_effects : []
  /** @param {string} type */
  const segmentsByType = (type) => tracks.filter((track) => track?.type === type)
    .flatMap((track) => Array.isArray(track.segments) ? track.segments : [])
  const audioSegmentsWithTrackRole = tracks.filter((track) => track?.type === 'audio')
    .flatMap((track) => (Array.isArray(track.segments) ? track.segments : [])
      .map((/** @type {RecordValue} */ segment) => ({ segment, trackRole: track?.role })))
  const expected = new Map(bindings.map((binding) => [binding.family, binding]))
  const sticker = expected.get('sticker')
  const flower = expected.get('flower')
  const videoEffect = expected.get('video_effect')
  const allSegments = tracks.flatMap((track) => Array.isArray(track?.segments) ? track.segments : [])
  const textContains = (/** @type {Record<string, any>} */ entry, /** @type {string} */ expectedText) => {
    if (typeof entry?.content !== 'string') return false
    if (entry.content === expectedText) return true
    try {
      const content = JSON.parse(entry.content)
      return isRecord(content) && content.text === expectedText
    } catch {
      return false
    }
  }
  const audios = Array.isArray(materials.audios) ? materials.audios : []
  if (videos.length !== plan.videos.length || texts.length !== plan.texts.length || stickers.length !== plan.stickers.length ||
      effects.length < plan.texts.filter((entry) => entry.flowerId).length || videoEffects.length !== plan.videoEffects.length ||
      audios.length !== plan.audios.length) fail('JY200_DUO_PRODUCT_READBACK_MATERIAL_COUNT_INVALID')
  if (segmentsByType('video').length !== plan.videos.length || segmentsByType('text').length !== plan.texts.length ||
      segmentsByType('sticker').length !== plan.stickers.length || segmentsByType('effect').length !== plan.videoEffects.length ||
      segmentsByType('audio').length !== plan.audios.length ||
      allSegments.length !== plan.videos.length + plan.texts.length + plan.stickers.length + plan.videoEffects.length + plan.audios.length) {
    fail('JY200_DUO_PRODUCT_READBACK_SEGMENT_COUNT_INVALID')
  }
  if (plan.stickers.length > 0 && stickers.some((entry) => entry?.resource_id !== sticker?.resourceId)) {
    fail('JY200_DUO_PRODUCT_READBACK_STICKER_INVALID')
  }
  if (plan.texts.some((entry) => entry.flowerId) &&
      !effects.some((/** @type {Record<string, any>} */ entry) => entry?.resource_id === flower?.resourceId &&
        (!flower?.effectId || entry?.effect_id === flower.effectId))) {
    fail('JY200_DUO_PRODUCT_READBACK_FLOWER_INVALID')
  }
  if (plan.videoEffects.length > 0 && videoEffects.some((entry) =>
    entry?.resource_id !== videoEffect?.resourceId || entry?.effect_id !== videoEffect?.effectId)) {
    fail('JY200_DUO_PRODUCT_READBACK_VIDEO_EFFECT_INVALID')
  }
  if (!plan.texts.every((entry) => texts.some((candidate) => textContains(candidate, entry.text)))) {
    fail('JY200_DUO_PRODUCT_READBACK_TITLE_INVALID')
  }
  const audioSegments = audioSegmentsWithTrackRole.map((entry) => entry.segment)
  const stagedAudioHashes = new Map()
  try {
    const audioRoot = path.join(artifactRoot, 'Resources', 'local', 'audio')
    for (const name of await readdir(audioRoot)) {
      if (!safeText(name) || name.includes('/') || name.includes('\\')) continue
      try { stagedAudioHashes.set(name, await sha256File(path.join(audioRoot, name))) } catch { /* ignore unreadable payload */ }
    }
  } catch { /* placeholder paths fail closed below when payload is absent */ }
  const invalidAudioPlacement = (await Promise.all(plan.audios.map(async (expected, index) => {
    const material = audios[index]
    const segment = audioSegmentsWithTrackRole[index]?.segment
    const trackRole = audioSegmentsWithTrackRole[index]?.trackRole
    const sourceRange = segment?.source_timerange ?? segment?.sourceTimerange
    const targetRange = segment?.target_timerange ?? segment?.targetTimerange
    const volume = segment?.volume ?? material?.volume
    const sourcePath = material?.path ?? material?.url
    const explicitRole = material?.role ?? segment?.role ?? trackRole
    // JianYing may omit role labels in exported materials. In that shape,
    // retain the finalized plan's positional role; any explicit role must
    // still match it and cannot be inferred from a filename.
    const role = explicitRole ?? expected.role
    const audioToken = material?.audio_token ?? material?.audioToken ?? segment?.audio_token ?? segment?.audioToken
    const sourceFingerprint = material?.source_fingerprint ?? material?.sourceFingerprint ??
      segment?.source_fingerprint ?? segment?.sourceFingerprint
    const sourceBasename = typeof sourcePath === 'string' &&
      (isLocalFileUrl(sourcePath) || DRAFT_AUDIO_PLACEHOLDER.test(sourcePath))
      ? sourcePath.split('/').at(-1)
      : undefined
    // JianYing's local-audio normalizer emits extract_music materials with a
    // draft-relative placeholder and strips OpenVideo's opaque metadata.  It
    // is safe to restore the executed plan only when the staged payload hash
    // and placeholder basename prove this exact material; arbitrary missing
    // bindings (including file URLs) remain fail-closed below.
    const normalizedDuoAudio = material?.type === 'extract_music' &&
      DRAFT_AUDIO_PLACEHOLDER.test(sourcePath ?? '') &&
      typeof sourceBasename === 'string' && stagedAudioHashes.get(sourceBasename) === expected.sourceFingerprint
    const sourceMatches = (isLocalFileUrl(expected.url) && matchesDraftAudioPath(sourcePath, expected.url) &&
      await sha256File(fileURLToPath(expected.url)).then((hash) => hash === expected.sourceFingerprint).catch(() => false)) ||
      ((isLocalFileUrl(sourcePath) || DRAFT_AUDIO_PLACEHOLDER.test(sourcePath ?? '')) &&
        typeof sourceBasename === 'string' && stagedAudioHashes.get(sourceBasename) === expected.sourceFingerprint)
    /** @param {any} range @param {number} start @param {number} duration */
    const rangeMatches = (range, start, duration) => isRecord(range) &&
      (range.start === start || range.start === start * 1_000) &&
      (range.duration === duration || range.duration === duration * 1_000)
    const volumeCandidates = [expected.volume, expected.volume / 100, Math.round(expected.volume / 100)]
    // Normalized plans store volume as a percentage (0..100), while Duo's
    // draft stores the linear gain converted to dB: 10^((percent/100)/20).
    const encodedVolume = Math.pow(10, expected.volume / 2_000)
    const volumeMatches = volumeCandidates.includes(volume) ||
      (Number.isFinite(encodedVolume) && typeof volume === 'number' && Math.abs(volume - encodedVolume) < 1e-6)
    const tokenMatches = audioToken === expected.audioToken || (audioToken == null && normalizedDuoAudio)
    const fingerprintMatches = sourceFingerprint === expected.sourceFingerprint ||
      (sourceFingerprint == null && normalizedDuoAudio)
    return !isRecord(material) || !isRecord(segment) || !sourceMatches ||
      role !== expected.role || !tokenMatches || !fingerprintMatches ||
      !rangeMatches(sourceRange, expected.sourceStart, expected.sourceDuration) ||
      !rangeMatches(targetRange, expected.start, expected.duration) ||
      !volumeMatches
  }))).some(Boolean)
  if (invalidAudioPlacement) fail('JY200_DUO_PRODUCT_READBACK_AUDIO_PLACEMENT_INVALID')
  return Object.freeze({ tracks: tracks.length, segments: allSegments.length, videos: videos.length, titles: plan.texts.length, audios: audios.length, stickers: stickers.length, flowers: plan.texts.filter((entry) => entry.flowerId).length, video_effects: videoEffects.length })
}

/**
 * Create the locked offline Duo runner used only behind the server-private
 * admission/lease seam.
 */
/**
 * @param {{
 *   dataRoot: string,
 *   repositoryRoot: string,
 *   liveDraftRoot: string,
 *   manifest: RecordValue,
 *   installedRuntime: RecordValue,
 *   profileId: string,
 *   appVersion: string,
 *   integrityKey: string,
 *   localFontPath?: string,
 *   resolveRuntimeBindings: (writePlan: RecordValue) => Promise<readonly RuntimeBinding[]>,
 *   resolveAudioSources?: (input: {stagingRoot: string, writePlan: RecordValue}) => Promise<readonly RecordValue[]>,
 *   runVerified: Function,
 *   runCli?: Function,
 *   publishReceipt: Function,
 * }} input
 */
export const createJY200DuoProductRunner = ({
  dataRoot,
  repositoryRoot,
  liveDraftRoot,
  manifest,
  installedRuntime,
  profileId,
  appVersion,
  integrityKey,
  localFontPath = resolveDefaultLocalFont(),
  resolveRuntimeBindings,
  resolveAudioSources = async ({ writePlan }) => (writePlan.audioPlacements ?? []).map(() => null),
  runVerified,
  runCli = executeCli,
  publishReceipt,
}) => {
  if (![dataRoot, repositoryRoot, liveDraftRoot].every((value) => typeof value === 'string' && path.isAbsolute(value)) ||
      !installedRuntime?.available || typeof resolveRuntimeBindings !== 'function' || typeof runVerified !== 'function' ||
      typeof publishReceipt !== 'function' || typeof runCli !== 'function' || typeof resolveAudioSources !== 'function' ||
      installedRuntime?.productCli?.className !== PRODUCT_CLI_CLASS ||
      !FINGERPRINT.test(installedRuntime?.productCli?.classSha256 ?? '') || !FINGERPRINT.test(integrityKey ?? '')) {
    fail('JY200_DUO_PRODUCT_RUNNER_INVALID')
  }
  /** @type {Map<string, Readonly<{plan: NormalizedPlan, bindings: readonly NormalizedRuntimeBinding[]}>>} */
  const executionContexts = new Map()
  return Object.freeze({
    /** @param {{stagingRoot: string, writePlan: RecordValue}} input */
    async run({ stagingRoot, writePlan }) {
      await validateJY200ProbeStagingRoot({ runtimeRoot: dataRoot, stagingRoot, liveDraftRoot })
      const resolvedAudioSources = await prepareDuoAudioSources(
        stagingRoot,
        await resolveAudioSources({ stagingRoot, writePlan }),
      )
      const plan = await normalizePlan(writePlan, resolvedAudioSources, localFontPath)
      const rawBindings = await resolveRuntimeBindings(writePlan)
      const stagedBindings = await stageRuntimeBindings({ runtimeRoot: installedRuntime.runtimeRoot, bindings: rawBindings })
      const bindings = stagedBindings.bindings
      const configExpectations = stagedBindings.expectations
      const validated = await runVerified({
        runtimeRoot: installedRuntime.runtimeRoot,
        manifest,
        javaRuntimeRoot: installedRuntime.privateJava.runtimeRoot,
        javaDistribution: manifest.writer_only_runtime.private_java_distribution,
        additionalExecutionRoots: [installedRuntime.productCli.runtimeRoot],
        configExpectations,
        execute: (/** @type {RecordValue} */ runtime) => runCli({
          javaExecutable: installedRuntime.privateJava.javaExecutable,
          runtimeRoot: installedRuntime.runtimeRoot,
          classpath: runtime.classpathEntries.join(path.delimiter),
          productCli: installedRuntime.productCli,
          stagingRoot,
          plan,
        }),
      })
      const artifactRoot = path.join(stagingRoot, plan.draftName)
      await validateJY200ProbeArtifactTree({ stagingRoot, artifactRoot, maxEntries: 1024 })
      const draft = JSON.parse(await readFileNoReparse(path.join(artifactRoot, 'draft_info.json'), stagingRoot, 16 * 1024 * 1024))
      if (!await inspectProductDraft({ draft, plan, bindings, artifactRoot })) fail('JY200_DUO_PRODUCT_READBACK_INVALID')
      const receiptBindings = JSON.parse(canonicalJY200DuoJson(
        bindings.map((binding) => receiptBinding(binding.publicEvidence)),
      ))
      const audioEvidence = plan.audios.map((audio) => ({
        role: audio.role,
        audio_token: audio.audioToken,
        source_fingerprint: audio.sourceFingerprint,
        source_start_us: audio.sourceStart * 1_000,
        source_duration_us: audio.sourceDuration * 1_000,
        target_start_us: audio.start * 1_000,
        target_duration_us: audio.duration * 1_000,
        volume: audio.volume,
      }))
      const receipt = createJY200DuoProbeExecutionReceipt({
        providerCommit: manifest.commit,
        buildDigest: validated.buildDigest,
        profileId,
        appVersion,
        desktopBindingFingerprint: writePlan.desktopBindingFingerprint,
        currentCatalogFingerprint: writePlan.currentCatalogFingerprint,
        draftId: plan.draftName,
        initialDraftFingerprint: fingerprintJY200DuoExecutionDraft(draft),
        bindingEvidence: receiptBindings,
        audioEvidence,
      }, integrityKey)
      await publishReceipt({
        evidenceRoot: path.join(dataRoot, 'evidence', 'jy200-duo-execution'),
        receipt,
        integrityKey,
      })
      const executionReceiptFingerprint = fingerprintJY200DuoValue(canonicalJY200DuoJson(receipt))
      executionContexts.set(executionReceiptFingerprint, Object.freeze({ plan, bindings }))
      return Object.freeze({
        draftName: plan.draftName,
        executionReceiptFingerprint,
      })
    },
    /** @param {{stagingRoot: string, providerResult: RecordValue, writePlan: RecordValue}} input */
    async inspectReadback({ stagingRoot, providerResult, writePlan }) {
      const executionReceiptFingerprint = providerResult?.executionReceiptFingerprint
      const context = typeof executionReceiptFingerprint === 'string'
        ? executionContexts.get(executionReceiptFingerprint)
        : null
      if (!context || providerResult?.draftName !== context.plan.draftName ||
          writePlan?.draftName !== context.plan.draftName) fail('JY200_DUO_PRODUCT_READBACK_INVALID')
      const { plan, bindings } = context
      const draft = JSON.parse(await readFileNoReparse(
        path.join(stagingRoot, plan.draftName, 'draft_info.json'), stagingRoot, 16 * 1024 * 1024,
      ))
      const summary = await inspectProductDraft({ draft, plan, bindings, artifactRoot: path.join(stagingRoot, plan.draftName) })
      if (!summary) fail('JY200_DUO_PRODUCT_READBACK_INVALID')
      executionContexts.delete(executionReceiptFingerprint)
      return Object.freeze({
        outputFingerprint: fingerprintJY200DuoExecutionDraft(draft),
        draftName: plan.draftName,
        trackCount: summary.tracks,
        segmentCount: summary.segments,
      })
    },
  })
}
