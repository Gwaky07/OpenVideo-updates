import { fileURLToPath } from 'node:url'
import path from 'node:path'

import { probeArtistEffectPayload, sanitizeJY200ProbeError } from '../apps/gateway/src/jianying-artist-effect-probe.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { readFileNoReparse } from '../apps/gateway/src/jianying-native-safe-file.mjs'
import { parsePrivatePackagingResourceIndex } from '../apps/gateway/src/jianying-packaging-resource-index.mjs'
import { loadLauncherRuntimeConfig } from '../apps/gateway/src/launcher-runtime-config.mjs'

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const tokenPattern = /^ovjsticker_v1_[a-f0-9]{24}$/u

/** @param {string[]} [argv] */
export const runArtistEffectCandidateProbe = async (argv = process.argv.slice(2)) => {
  const packagingToken = argv[0]
  if (argv.length !== 1 || !tokenPattern.test(packagingToken ?? '')) throw new Error('JY200_PACKAGING_TOKEN_INVALID')
  const runtime = await loadLauncherRuntimeConfig({ repositoryRoot: root })
  const manifest = JSON.parse(await readFileNoReparse(path.join(root, 'config', 'jianying-compatibility.json'), root))
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  const catalogRoot = path.join(runtime.dataRoot, 'catalogs')
  const catalog = parsePrivatePackagingResourceIndex(
    JSON.parse(await readFileNoReparse(path.join(catalogRoot, 'native018-private-draft-catalog.json'), catalogRoot, 32 * 1024 * 1024)),
    { profileId: desktop.profileId, appVersion: desktop.version },
  )
  const entry = catalog.entries.find((candidate) => candidate.packaging_token === packagingToken &&
    candidate.family === 'sticker' && candidate.writer_eligible === false && candidate.state === 'discoverable')
  if (!entry) throw new Error('JY200_STICKER_CANDIDATE_UNAVAILABLE')
  const candidate = await probeArtistEffectPayload({ desktop, resourceId: entry.private_binding.resourceId })
  if (!candidate) throw new Error('JY200_STICKER_PAYLOAD_UNAVAILABLE')
  return Object.freeze({
    status: 'probe_candidate_found',
    resourceMode: candidate.mode,
    writerEligible: false,
    admission: 'deferred',
  })
}

const main = async () => {
  try {
    process.stdout.write(`${JSON.stringify(await runArtistEffectCandidateProbe())}\n`)
  } catch (error) {
    process.stdout.write(`${JSON.stringify({ status: 'probe_candidate_unavailable', reason: sanitizeJY200ProbeError(error), writerEligible: false, admission: 'deferred' })}\n`)
    process.exitCode = 1
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) void main()
