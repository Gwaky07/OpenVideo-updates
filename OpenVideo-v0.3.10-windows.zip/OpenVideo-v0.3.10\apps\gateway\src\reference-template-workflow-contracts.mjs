import {
  isHistoricalReferenceTemplateAdapterRequest,
  isHistoricalReferenceTemplateAnalysis,
  isReferenceTemplateAdapterRequest,
  isReferenceTemplateAnalysis,
  isReferenceTemplateDraft,
  isReferenceTemplatePreflightReport,
  isReferenceTemplateReviewDecision,
  preflightHistoricalReferenceTemplateDraft,
  preflightReferenceTemplateDraft,
} from './reference-template-contracts.mjs'
import { isTemplateSelectionRequest } from './template-library.mjs'

const recordKeys = [
  'adapterRequest',
  'analysis',
  'contractVersion',
  'createdAt',
  'decision',
  'draft',
  'ownerAttemptId',
  'ownerGeneration',
  'ownerInputFingerprint',
  'ownerJobId',
  'preflight',
  'projectId',
  'publication',
  'referenceTemplateId',
  'revision',
  'status',
  'templateSelectionRequest',
  'updatedAt',
]
const publicSummaryKeys = [
  'createdAt',
  'draftId',
  'projectId',
  'referenceId',
  'referenceTemplateId',
  'revision',
  'status',
  'updatedAt',
]

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys @returns {value is Record<string, any>} */
const exact = (value, keys) =>
  isRecord(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')
/** @param {unknown} value */
const id = (value) => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,179}$/u.test(value)
/** @param {unknown} value */
const timestamp = (value) => typeof value === 'string' &&
  Number.isFinite(Date.parse(value)) &&
  new Date(value).toISOString() === value

export class ReferenceTemplateWorkflowContractError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code = 'REFERENCE_TEMPLATE_WORKFLOW_CONTRACT_INVALID', status = 500) {
    super(code)
    this.name = 'ReferenceTemplateWorkflowContractError'
    this.code = code
    this.status = status
  }
}

/** @param {unknown} value */
export const isReferenceTemplateWorkflowRecord = (value) => {
  const candidate = isRecord(value) ? value : {}
  const historical = candidate.contractVersion === 1
  const adapterValid = historical
    ? isHistoricalReferenceTemplateAdapterRequest(
        candidate.templateSelectionRequest,
        candidate.adapterRequest,
      )
    : isReferenceTemplateAdapterRequest(
        candidate.templateSelectionRequest,
        candidate.adapterRequest,
      )
  const analysisValid = historical
    ? isHistoricalReferenceTemplateAnalysis(candidate.adapterRequest, candidate.analysis)
    : isReferenceTemplateAnalysis(candidate.adapterRequest, candidate.analysis)
  if (
    !exact(value, recordKeys) ||
    ![1, 2].includes(value.contractVersion) ||
    !id(value.referenceTemplateId) ||
    !id(value.projectId) ||
    !id(value.ownerJobId) ||
    !id(value.ownerAttemptId) ||
    !Number.isSafeInteger(value.ownerGeneration) ||
    value.ownerGeneration < 1 ||
    typeof value.ownerInputFingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(value.ownerInputFingerprint) ||
    !['staged', 'prepared', 'committed'].includes(value.publication) ||
    !Number.isSafeInteger(value.revision) ||
    value.revision < 1 ||
    !['generated', 'approved', 'rejected'].includes(value.status) ||
    !timestamp(value.createdAt) ||
    !timestamp(value.updatedAt) ||
    !isTemplateSelectionRequest(value.templateSelectionRequest) ||
    value.templateSelectionRequest.project_id !== value.projectId ||
    !adapterValid ||
    !analysisValid ||
    !isReferenceTemplateDraft(value.draft) ||
    value.draft.project_id !== value.projectId ||
    !isReferenceTemplatePreflightReport(value.preflight)
  ) return false
  const canonicalPreflight = (
    value.contractVersion === 1
      ? preflightHistoricalReferenceTemplateDraft
      : preflightReferenceTemplateDraft
  )(
    value.templateSelectionRequest,
    value.adapterRequest,
    value.analysis,
    value.draft,
  )
  if (JSON.stringify(value.preflight) !== JSON.stringify(canonicalPreflight) || !value.preflight.ready) return false
  if (value.publication !== 'committed') {
    return value.status === 'generated' && value.decision === null
  }
  if (value.status === 'generated') return value.decision === null
  return (
    isReferenceTemplateReviewDecision(value.draft, value.decision) &&
    (value.status === 'approved'
      ? value.decision.decision === 'approved'
      : value.decision.decision === 'rejected')
  )
}

/** @param {unknown} value @returns {Record<string, any>} */
export const assertReferenceTemplateWorkflowRecord = (value) => {
  if (!isReferenceTemplateWorkflowRecord(value)) throw new ReferenceTemplateWorkflowContractError()
  return clone(/** @type {Record<string, any>} */ (value))
}

/** @param {unknown} value */
export const isReferenceTemplatePublicSummary = (value) =>
  exact(value, publicSummaryKeys) &&
  id(value.referenceTemplateId) &&
  id(value.projectId) &&
  id(value.referenceId) &&
  id(value.draftId) &&
  Number.isSafeInteger(value.revision) &&
  value.revision >= 1 &&
  ['generated', 'approved', 'rejected'].includes(value.status) &&
  timestamp(value.createdAt) &&
  timestamp(value.updatedAt)

/** @param {unknown} value */
export const toReferenceTemplatePublicSummary = (value) => {
  const record = assertReferenceTemplateWorkflowRecord(value)
  if (record.publication !== 'committed') {
    throw new ReferenceTemplateWorkflowContractError(
      'REFERENCE_TEMPLATE_NOT_COMMITTED',
      409,
    )
  }
  const result = {
    referenceTemplateId: record.referenceTemplateId,
    projectId: record.projectId,
    referenceId: record.analysis.reference_id,
    draftId: record.draft.draft_id,
    revision: record.revision,
    status: record.status,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
  }
  if (!isReferenceTemplatePublicSummary(result)) throw new ReferenceTemplateWorkflowContractError()
  return result
}

/** @param {unknown} value */
export const toReferenceTemplatePublicDetail = (value) => {
  const record = assertReferenceTemplateWorkflowRecord(value)
  return {
    ...toReferenceTemplatePublicSummary(record),
    draft: clone(record.draft),
    preflight: clone(record.preflight),
    decision: clone(record.decision),
  }
}
