/**
 * Project-level BGM must cover 0..durationUs for Preview and Jianying.
 * Shot retiming can leave a zero-start BGM clipped to the first shot; restore
 * the full span instead of failing the writer. Mid-timeline BGM stays invalid.
 *
 * @param {unknown} timeline
 * @returns {any}
 */
export const spanZeroStartBgmToTimeline = (timeline) => {
  if (!timeline || typeof timeline !== 'object') return timeline
  const next = structuredClone(timeline)
  const durationUs = next.durationUs
  if (!Number.isSafeInteger(durationUs) || durationUs < 1 || !Array.isArray(next.tracks)) {
    return next
  }
  for (const track of next.tracks) {
    if (track?.kind !== 'audio' || track.role !== 'bgm' || !Array.isArray(track.segments)) continue
    for (const segment of track.segments) {
      const range = segment?.targetRange
      if (
        range?.startUs !== 0 ||
        !Number.isSafeInteger(range.durationUs) ||
        range.durationUs < 1 ||
        range.durationUs === durationUs
      ) {
        continue
      }
      segment.targetRange = { startUs: 0, durationUs }
      if (Number.isSafeInteger(segment.sourceRange?.durationUs)) {
        segment.sourceRange = {
          startUs: 0,
          durationUs: Math.max(segment.sourceRange.durationUs, durationUs),
        }
      }
    }
  }
  return next
}
