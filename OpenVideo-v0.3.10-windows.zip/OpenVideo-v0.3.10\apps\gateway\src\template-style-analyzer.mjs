import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import {
  STYLE_PROFILE_ANALYZER_VERSION,
  buildStyleSummaryFromArtifact,
} from './template-style-profile.mjs'

const execFileAsync = promisify(execFile)

/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

export class TemplateStyleAnalyzerError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code, status = 500) {
    super(code)
    this.name = 'TemplateStyleAnalyzerError'
    this.code = code
    this.status = status
  }
}

/**
 * @param {Buffer} bytes
 */
const fingerprintBytes = (bytes) => createHash('sha256').update(bytes).digest('hex').slice(0, 32)

/**
 * Provider-neutral style analyzer. Reuses ffprobe/ffmpeg frame extract and optional Vision.
 * Never invents default palettes.
 * @param {{
 *   ffmpegPath?: string | null,
 *   ffprobePath?: string | null,
 *   extractFrame?: Function | null,
 *   describeFrame?: Function | null,
 *   tempRoot: string,
 * }} options
 */
export const createTemplateStyleAnalyzer = ({
  ffmpegPath = null,
  ffprobePath = null,
  extractFrame = null,
  describeFrame = null,
  tempRoot,
}) => {
  if (!tempRoot) throw new TemplateStyleAnalyzerError('TEMPLATE_STYLE_TEMP_ROOT_INVALID', 503)

  /**
   * @param {string} sourcePath
   */
  const probeDurationMs = async (sourcePath) => {
    const probe = ffprobePath && existsSync(ffprobePath)
      ? ffprobePath
      : (ffmpegPath && existsSync(ffmpegPath) ? ffmpegPath.replace(/ffmpeg(\.exe)?$/iu, 'ffprobe$1') : null)
    if (!probe || !existsSync(probe)) return null
    try {
      const { stdout } = await execFileAsync(probe, [
        '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        sourcePath,
      ], { timeout: 30_000, windowsHide: true, maxBuffer: 1024 * 1024 })
      const seconds = Number.parseFloat(String(stdout).trim())
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1000) : null
    } catch {
      return null
    }
  }

  /**
   * Decode a tiny RGB24 frame and vote dominant colors (not raw PNG bytes).
   * @param {string} sourcePath
   * @param {number} timestampSeconds
   * @param {string} workDir
   * @param {number} index
   */
  const sampleFramePalette = async (sourcePath, timestampSeconds, workDir, index) => {
    const ffmpeg = ffmpegPath && existsSync(ffmpegPath) ? ffmpegPath : null
    if (!ffmpeg) return { palette: /** @type {string[]} */ ([]), fingerprint: /** @type {string | null} */ (null) }
    const rawPath = join(workDir, `frame-${index}.rgb`)
    try {
      await execFileAsync(ffmpeg, [
        '-hide_banner', '-loglevel', 'error', '-y',
        '-ss', String(Math.max(0, timestampSeconds)),
        '-i', sourcePath,
        '-frames:v', '1',
        '-vf', 'scale=48:48',
        '-f', 'rawvideo',
        '-pix_fmt', 'rgb24',
        rawPath,
      ], { timeout: 30_000, windowsHide: true, maxBuffer: 2 * 1024 * 1024 })
      const bytes = await readFile(rawPath)
      const fingerprint = fingerprintBytes(bytes)
      const counts = new Map()
      for (let offset = 0; offset + 2 < bytes.length; offset += 3) {
        const r = bytes[offset]
        const g = bytes[offset + 1]
        const b = bytes[offset + 2]
        if ((r < 12 && g < 12 && b < 12) || (r > 243 && g > 243 && b > 243)) continue
        const qr = r & 0xf0
        const qg = g & 0xf0
        const qb = b & 0xf0
        const key = `#${qr.toString(16).padStart(2, '0')}${qg.toString(16).padStart(2, '0')}${qb.toString(16).padStart(2, '0')}`
        counts.set(key, (counts.get(key) || 0) + 1)
      }
      const palette = [...counts.entries()]
        .sort((left, right) => right[1] - left[1])
        .slice(0, 5)
        .map(([color]) => color)
      return { palette, fingerprint }
    } catch {
      return { palette: [], fingerprint: null }
    } finally {
      await rm(rawPath, { force: true }).catch(() => {})
    }
  }

  /**
   * @param {string} sourcePath
   * @param {number} timestampSeconds
   * @param {string} outputPath
   */
  const extractOneFrame = async (sourcePath, timestampSeconds, outputPath) => {
    if (typeof extractFrame === 'function') {
      await extractFrame({
        sourcePath,
        timestamp: timestampSeconds,
        outputPath,
        timeoutMs: 30_000,
      })
      return
    }
    const ffmpeg = ffmpegPath && existsSync(ffmpegPath) ? ffmpegPath : null
    if (!ffmpeg) throw new TemplateStyleAnalyzerError('TEMPLATE_STYLE_FFMPEG_UNAVAILABLE', 503)
    await execFileAsync(ffmpeg, [
      '-hide_banner', '-loglevel', 'error', '-y',
      '-ss', String(Math.max(0, timestampSeconds)),
      '-i', sourcePath,
      '-frames:v', '1',
      outputPath,
    ], { timeout: 30_000, windowsHide: true, maxBuffer: 2 * 1024 * 1024 })
  }

  /**
   * @param {{
   *   sourcePath: string,
   *   artifact: Record<string, any>,
   *   libraryTemplateId?: string,
   * }} input
   */
  const analyze = async (input) => {
    if (!record(input) || !record(input.artifact) || typeof input.sourcePath !== 'string') {
      throw new TemplateStyleAnalyzerError('TEMPLATE_STYLE_INPUT_INVALID', 400)
    }
    if (!existsSync(input.sourcePath)) {
      throw new TemplateStyleAnalyzerError('TEMPLATE_STYLE_SOURCE_MISSING', 409)
    }

    const workDir = resolve(tempRoot, `style-${Date.now()}-${process.pid}`)
    await mkdir(workDir, { recursive: true, mode: 0o700 })
    /** @type {string[]} */
    const frameFingerprints = []
    /** @type {string[]} */
    const paletteVotes = []
    /** @type {Array<Record<string, any>>} */
    const textEvidence = []
    let brightnessLabel = /** @type {string | null} */ (null)
    let contrastLabel = /** @type {string | null} */ (null)
    let saturationLabel = /** @type {string | null} */ (null)
    let colorTempLabel = /** @type {string | null} */ (null)
    let motionLabel = /** @type {string | null} */ (null)
    let voiceStyle = /** @type {string | null} */ (null)
    let speechRateLabel = /** @type {string | null} */ (null)
    const bgmBpm = /** @type {number | null} */ (null)
    let analysisComplete = false

    try {
      const durationMs = await probeDurationMs(input.sourcePath)
        ?? (Number.isFinite(input.artifact.analysis?.duration_ms)
          ? input.artifact.analysis.duration_ms
          : 12_000)
      const sampleCount = Math.min(5, Math.max(2, Math.floor(durationMs / 4_000) || 2))
      const timestamps = Array.from({ length: sampleCount }, (_, index) => {
        const ratio = (index + 1) / (sampleCount + 1)
        return Math.max(0.05, (durationMs / 1000) * ratio)
      })

      for (const [index, timestamp] of timestamps.entries()) {
        try {
          const sampled = await sampleFramePalette(input.sourcePath, timestamp, workDir, index)
          if (sampled.fingerprint) frameFingerprints.push(sampled.fingerprint)
          paletteVotes.push(...sampled.palette)

          if (typeof describeFrame === 'function') {
            const framePath = join(workDir, `frame-${index}.png`)
            try {
              await extractOneFrame(input.sourcePath, timestamp, framePath)
              const description = await describeFrame({
                framePath,
                scene: {
                  start: Math.max(0, timestamp - 0.2),
                  end: timestamp + 0.2,
                },
                sceneIndex: index,
                timeoutMs: 20_000,
              })
              if (typeof description === 'string' && description.trim()) {
                const lower = description.toLowerCase()
                if (/warm|暖/.test(lower)) colorTempLabel = 'warm'
                if (/cool|冷/.test(lower)) colorTempLabel = 'cool'
                if (/bright|亮/.test(lower)) brightnessLabel = 'bright'
                if (/dark|暗/.test(lower)) brightnessLabel = 'dark'
                if (/high.?contrast|高对比/.test(lower)) contrastLabel = 'high'
                if (/low.?contrast|低对比/.test(lower)) contrastLabel = 'low'
                if (/satura|饱和/.test(lower)) saturationLabel = 'vivid'
                if (/static|静止/.test(lower)) motionLabel = 'static'
                if (/fast|动感|运动/.test(lower)) motionLabel = 'dynamic'
                if (/title|标题|字幕|caption|text/.test(lower)) {
                  textEvidence.push({
                    startMs: Math.round(timestamp * 1000),
                    endMs: Math.round(timestamp * 1000) + 800,
                    kind: 'vision_text',
                    text: description.trim().slice(0, 40),
                  })
                }
              }
            } catch {
              // Vision is optional.
            } finally {
              await rm(framePath, { force: true }).catch(() => {})
            }
          }
        } catch {
          // Skip failed sample; do not invent colors.
        }
      }

      const paletteCounts = new Map()
      for (const color of paletteVotes) {
        paletteCounts.set(color, (paletteCounts.get(color) || 0) + 1)
      }
      const palette = [...paletteCounts.entries()]
        .sort((left, right) => right[1] - left[1])
        .slice(0, 5)
        .map(([color]) => color)

      if (!brightnessLabel && palette.length > 0) {
        const avg = palette.reduce((sum, color) => {
          const r = Number.parseInt(color.slice(1, 3), 16)
          const g = Number.parseInt(color.slice(3, 5), 16)
          const b = Number.parseInt(color.slice(5, 7), 16)
          return sum + (r + g + b) / 3
        }, 0) / palette.length
        brightnessLabel = avg > 170 ? 'bright' : avg < 85 ? 'dark' : 'balanced'
      }

      const audioEmphasis = Array.isArray(input.artifact.draft?.rules?.audio_emphasis)
        ? input.artifact.draft.rules.audio_emphasis
        : []
      if (audioEmphasis.length > 0) {
        voiceStyle = 'accented'
        speechRateLabel = 'punctuated'
      }

      analysisComplete = frameFingerprints.length >= 2 && palette.length > 0

      const styleSummary = buildStyleSummaryFromArtifact(input.artifact, {
        palette,
        brightnessLabel,
        contrastLabel,
        saturationLabel,
        colorTempLabel,
        motionLabel,
        voiceStyle,
        speechRateLabel,
        bgmBpm,
        frameFingerprints,
        textEvidence,
        analysisComplete,
        analyzerVersion: STYLE_PROFILE_ANALYZER_VERSION,
      })

      return {
        styleSummary,
        analysisComplete,
        analyzerVersion: STYLE_PROFILE_ANALYZER_VERSION,
        sampleCount: frameFingerprints.length,
      }
    } finally {
      await rm(workDir, { recursive: true, force: true }).catch(() => {})
    }
  }

  /**
   * Build a v4 profile without media when only artifact exists (incomplete).
   * @param {Record<string, any>} artifact
   */
  const analyzeArtifactOnly = (artifact) => {
    const styleSummary = buildStyleSummaryFromArtifact(artifact, {
      analysisComplete: false,
      analyzerVersion: STYLE_PROFILE_ANALYZER_VERSION,
    })
    return {
      styleSummary,
      analysisComplete: false,
      analyzerVersion: STYLE_PROFILE_ANALYZER_VERSION,
      sampleCount: 0,
    }
  }

  return {
    analyze,
    analyzeArtifactOnly,
  }
}

/**
 * Persist analyzer output next to template media for audit (no private paths).
 * @param {string} directory
 * @param {Record<string, any>} report
 */
export const writeStyleAnalysisReport = async (directory, report) => {
  const target = join(directory, 'style-analysis.json')
  const temporary = `${target}.${process.pid}.tmp`
  const safe = {
    analyzerVersion: report.analyzerVersion,
    analysisComplete: report.analysisComplete,
    sampleCount: report.sampleCount,
    styleSummary: report.styleSummary,
    updatedAt: new Date().toISOString(),
  }
  await writeFile(temporary, `${JSON.stringify(safe, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 })
  const { rename } = await import('node:fs/promises')
  await rename(temporary, target)
  return safe
}
