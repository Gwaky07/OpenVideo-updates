import { randomUUID } from 'node:crypto'
import { mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'

/** @param {unknown} value @returns {string} */
const safeCode = (value) => typeof value === 'string' && /^[A-Z0-9_]{3,80}$/u.test(value)
  ? value
  : 'RUNTIME_EVENT'

/** @param {unknown} value @returns {string} */
const safeComponent = (value) => typeof value === 'string' && /^[a-z0-9_-]{2,40}$/u.test(value)
  ? value
  : 'gateway'

const optionalOrInternalComponents = new Set([
  'creative-audio-cues',
  'creative-knowledge',
  'creative-planning',
  'creative-techniques',
  'jianying-duo',
  'jianying-duo-probationary',
  'jianying-native-evidence',
])

/**
 * Optional Writer / creative-knowledge warnings are private runtime notes.
 * They must not occupy the public status-page problem list.
 * @param {{component?: unknown, severity?: unknown}} event
 */
export const isUserFacingDiagnosticEvent = (event) => {
  if (!event || typeof event !== 'object') return false
  if (event.severity === 'info') return false
  return !optionalOrInternalComponents.has(safeComponent(event.component))
}

/**
 * Keeps a bounded, public-safe runtime summary. Raw logs remain private because
 * they may contain stack frames, machine paths, or upstream provider details.
 */
export const createRuntimeDiagnostics = ({ now = () => new Date(), maxEvents = 20 } = {}) => {
  const startedAt = now()
  const bootId = randomUUID().replaceAll('-', '').slice(0, 12)
  /** @type {{at: string, component: string, code: string, severity: 'info'|'warning'|'error'}[]} */
  const events = []

  /** @type {string | null} */
  let storagePath = null

  const persist = () => {
    if (!storagePath) return
    const temporaryPath = `${storagePath}.${randomUUID()}.tmp`
    try {
      mkdirSync(dirname(storagePath), { recursive: true, mode: 0o700 })
      writeFileSync(temporaryPath, `${JSON.stringify({ schema_version: 1, events })}\n`, 'utf8')
      renameSync(temporaryPath, storagePath)
    } catch {
      try { unlinkSync(temporaryPath) } catch {}
    }
  }

  /** @param {{component?: unknown, code?: unknown, severity?: unknown}} [input] */
  const record = ({ component = 'gateway', code = 'RUNTIME_EVENT', severity = 'info' } = {}) => {
    /** @type {{at: string, component: string, code: string, severity: 'info'|'warning'|'error'}} */
    const event = {
      at: now().toISOString(),
      component: safeComponent(component),
      code: safeCode(code),
      severity: severity === 'info' || severity === 'warning' || severity === 'error' ? severity : 'warning',
    }
    events.unshift(event)
    events.length = Math.min(events.length, maxEvents)
    persist()
    return event
  }

  return {
    record,
    clear() {
      events.length = 0
      // Keep an explicit empty receipt so cleared records cannot reappear after restart.
      persist()
    },
    /** @param {string | null | undefined} nextStoragePath */
    initialize(nextStoragePath) {
      storagePath = typeof nextStoragePath === 'string' && nextStoragePath ? nextStoragePath : null
      if (!storagePath) return
      try {
        const stored = JSON.parse(readFileSync(storagePath, 'utf8'))
        if (stored?.schema_version === 1 && Array.isArray(stored.events)) {
          for (const event of stored.events.slice(0, maxEvents).reverse()) {
            if (event && typeof event === 'object') {
              events.unshift({
                at: typeof event.at === 'string' ? event.at : now().toISOString(),
                component: safeComponent(event.component),
                code: safeCode(event.code),
                severity: event.severity === 'info' || event.severity === 'warning' || event.severity === 'error'
                  ? event.severity
                  : 'warning',
              })
            }
          }
          events.length = Math.min(events.length, maxEvents)
        }
      } catch {
        // A diagnostic receipt must never prevent the local workbench from starting.
      }
    },
    snapshot() {
      const current = now()
      return {
        schema_version: 1,
        connection: 'connected',
        bootId,
        startedAt: startedAt.toISOString(),
        uptimeSeconds: Math.max(0, Math.floor((current.getTime() - startedAt.getTime()) / 1000)),
        events: events.map((event) => ({ ...event })),
      }
    },
  }
}

/**
 * Converts coordinator events to the same small public vocabulary as the API.
 * Job, project, error-message, and stack fields are intentionally discarded.
 * @param {{record: Function}} diagnostics
 * @param {unknown} event
 */
export const recordSafeWorkbenchDiagnostic = (diagnostics, event) => {
  if (!event || typeof event !== 'object') return false
  const input = /** @type {{event?: unknown, jobType?: unknown, code?: unknown}} */ (event)
  if (input.event !== 'workbench_job_attempt_failed' && input.event !== 'workbench_job_worker_failed') return false
  diagnostics.record({
    component: input.jobType === 'material_analysis' ? 'material-analysis' : 'workbench',
    code: input.code,
    severity: 'error',
  })
  return true
}
