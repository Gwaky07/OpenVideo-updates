import { createHash, randomUUID } from 'node:crypto'
import { lstat, readFile, realpath, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'

import {
  validateJY200ProbeArtifactTree,
  validateJY200ProbeStagingRoot,
} from './jianying-artist-effect-probe.mjs'

const DRAFT_NAME = /^OpenVideo-JY200-duo-direct-[0-9]{8}-(?:[0-9]{4}|[0-9]{6})$/u
const MAX_METADATA_BYTES = 256 * 1024
const PROVIDER = /^[a-z][a-z0-9_-]{2,63}$/u
const FINGERPRINT = /^[a-f0-9]{32,128}$/u
const SAFE_ERROR = /^JY200_[A-Z0-9_]+$/u

/** @param {string} root @param {string} candidate */
const inside = (root, candidate) => {
  const relative = path.relative(path.resolve(root), path.resolve(candidate))
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

/** @param {unknown} value */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * Keep filesystem details private while retaining the exact publisher stage
 * that failed. Existing domain failures remain unchanged.
 * @template T
 * @param {string} code
 * @param {() => Promise<T>} operation
 * @returns {Promise<T>}
 */
const atPublishStage = async (code, operation) => {
  try {
    return await operation()
  } catch (error) {
    if (error instanceof Error && SAFE_ERROR.test(error.message)) throw error
    const wrapped = /** @type {Error & {code: string}} */ (new Error(code))
    wrapped.code = code
    throw wrapped
  }
}

/** @param {string} left @param {string} right */
const samePath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {import('node:fs').BigIntStats} metadata */
const objectIdentity = (metadata) => `${metadata.dev}:${metadata.ino}`
/** @param {string} requested @param {string} actual @param {import('node:fs').BigIntStats} requestedMetadata */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (samePath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  return actualMetadata !== null && objectIdentity(actualMetadata) === objectIdentity(requestedMetadata)
}
/** @param {import('node:fs').BigIntStats} metadata @param {'ctime'|'mtime'} field */
const timeIdentity = (metadata, field) => {
  const value = field === 'ctime' ? metadata.ctimeNs : metadata.mtimeNs
  return typeof value === 'bigint' ? value.toString() : String(field === 'ctime' ? metadata.ctimeMs : metadata.mtimeMs)
}
/** @param {import('node:fs').BigIntStats} metadata */
const objectGeneration = (metadata) => `${objectIdentity(metadata)}:${timeIdentity(metadata, 'ctime')}:${timeIdentity(metadata, 'mtime')}`

/** @param {string} target */
const bindDirectory = async (target) => {
  const resolved = path.resolve(target)
  const parent = path.dirname(resolved)
  const [metadata, parentMetadata, actual, actualParent] = await Promise.all([
    lstat(resolved, { bigint: true }), lstat(parent, { bigint: true }), realpath(resolved), realpath(parent),
  ])
  const [sameDirectory, sameParent] = await Promise.all([
    sameResolvedObject(resolved, actual, metadata),
    sameResolvedObject(parent, actualParent, parentMetadata),
  ])
  if (!metadata.isDirectory() || metadata.isSymbolicLink() || !sameDirectory ||
      !parentMetadata.isDirectory() || parentMetadata.isSymbolicLink() || !sameParent) {
    throw new Error('JY200_DUO_PUBLISH_ROOT_UNSAFE')
  }
  return Object.freeze({
    path: resolved,
    identity: objectIdentity(metadata),
    generation: objectGeneration(metadata),
    parent,
    parentGeneration: objectGeneration(parentMetadata),
  })
}

/** @param {{path: string, identity: string, parent: string, parentGeneration: string}} binding */
const assertDirectoryBinding = async (binding) => {
  const current = await bindDirectory(binding.path).catch(() => null)
  if (!current || current.identity !== binding.identity || current.parent !== binding.parent ||
      current.parentGeneration !== binding.parentGeneration) throw new Error('JY200_DUO_PUBLISH_ROOT_REPLACED')
  return current
}

/** @param {string} target */
const missing = async (target) => {
  try { await lstat(target); return false } catch (error) {
    if (error && typeof error === 'object' && /** @type {{code?: string}} */ (error).code === 'ENOENT') return true
    throw error
  }
}

/** @param {string} filePath */
const readMetadata = async (filePath) => {
  const metadata = await lstat(filePath, { bigint: true })
  if (!metadata.isFile() || metadata.isSymbolicLink() || metadata.size <= 0 || metadata.size > MAX_METADATA_BYTES ||
      !await sameResolvedObject(path.resolve(filePath), await realpath(filePath), metadata)) {
    throw new Error('JY200_DUO_METADATA_UNSAFE')
  }
  let value
  try { value = JSON.parse(await readFile(filePath, 'utf8')) } catch { throw new Error('JY200_DUO_METADATA_INVALID') }
  if (!isRecord(value)) throw new Error('JY200_DUO_METADATA_INVALID')
  return /** @type {Record<string, any>} */ (value)
}

/** @param {string} filePath @param {Record<string, any>} value */
const replaceMetadata = async (filePath, value) => {
  const temporary = `${filePath}.openvideo-${randomUUID()}.tmp`
  try {
    await writeFile(temporary, `${JSON.stringify(value)}\n`, { encoding: 'utf8', flag: 'wx' })
    await rename(temporary, filePath)
  } catch (error) {
    try { await rm(temporary, { force: true }) } catch { /* best effort */ }
    throw error
  }
}

/**
 * Normalize a task-owned plaintext Duo artifact before it is atomically moved
 * into Jianying's current project root. No live draft is edited in place.
 * @param {{runtimeRoot: string, stagingRoot: string, artifactRoot: string, liveDraftRoot: string, repositoryRoot: string, draftName: string, draftLabel: string, jobId: string, providerId: string, timelineFingerprint: string, publicationRepository: Record<string, any>, now?: () => number}} input
 */
export const publishJY200DuoStagingDraft = async ({
  runtimeRoot,
  stagingRoot,
  artifactRoot,
  liveDraftRoot,
  repositoryRoot,
  draftName,
  draftLabel,
  jobId,
  providerId,
  timelineFingerprint,
  publicationRepository,
  now = Date.now,
}) => {
  if (!DRAFT_NAME.test(draftName ?? '') || typeof draftLabel !== 'string' || draftLabel.trim().length === 0 ||
      draftLabel.length > 100 || /[\\/\u0000-\u001f]/u.test(draftLabel) ||
      /^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(draftLabel) ||
      !path.isAbsolute(repositoryRoot) || typeof jobId !== 'string' ||
      !PROVIDER.test(providerId ?? '') || !FINGERPRINT.test(timelineFingerprint ?? '') ||
      !publicationRepository || typeof publicationRepository.preparePublication !== 'function' ||
      typeof publicationRepository.markPublished !== 'function') throw new Error('JY200_DUO_PUBLISH_INPUT_INVALID')
  const repository = path.resolve(repositoryRoot)
  const staging = path.resolve(stagingRoot)
  const artifact = path.resolve(artifactRoot)
  const live = path.resolve(liveDraftRoot)
  if (inside(repository, staging) || inside(staging, repository) || path.basename(artifact) !== draftName) {
    throw new Error('JY200_DUO_PUBLISH_INPUT_INVALID')
  }
  await atPublishStage('JY200_DUO_PUBLISH_STAGING_PREFLIGHT_FAILED', () =>
    validateJY200ProbeStagingRoot({ runtimeRoot, stagingRoot: staging, liveDraftRoot: live }))
  await atPublishStage('JY200_DUO_PUBLISH_ARTIFACT_PREFLIGHT_FAILED', () =>
    validateJY200ProbeArtifactTree({ stagingRoot: staging, artifactRoot: artifact }))
  const [repositoryMetadata, repositoryReal, liveBinding] = await atPublishStage('JY200_DUO_PUBLISH_ROOT_BINDING_FAILED', () =>
    Promise.all([lstat(repository, { bigint: true }), realpath(repository), bindDirectory(live)]))
  if (!repositoryMetadata.isDirectory() || repositoryMetadata.isSymbolicLink() ||
      !await sameResolvedObject(repository, repositoryReal, repositoryMetadata)) {
    throw new Error('JY200_DUO_PUBLISH_INPUT_INVALID')
  }
  const destination = path.join(live, draftName)
  try { await lstat(destination); throw new Error('JY200_DUO_DRAFT_ALREADY_EXISTS') } catch (error) {
    if (error instanceof Error && error.message === 'JY200_DUO_DRAFT_ALREADY_EXISTS') throw error
    if (!(error && typeof error === 'object' && /** @type {{code?: string}} */ (error).code === 'ENOENT')) throw error
  }
  const milliseconds = now()
  if (!Number.isSafeInteger(milliseconds) || milliseconds < 1_500_000_000_000 || milliseconds > 9_000_000_000_000) {
    throw new Error('JY200_DUO_CLOCK_INVALID')
  }
  const microseconds = milliseconds * 1_000
  const metaPath = path.join(artifact, 'draft_meta_info.json')
  const infoPath = path.join(artifact, 'draft_info.json')
  const [meta, info] = await atPublishStage('JY200_DUO_PUBLISH_METADATA_READ_FAILED', () =>
    Promise.all([readMetadata(metaPath), readMetadata(infoPath)]))
  const normalizedMeta = {
    ...meta,
    draft_name: draftLabel.trim(),
    draft_fold_path: destination.replaceAll('\\', '/'),
    draft_root_path: live.replaceAll('\\', '/'),
    draft_is_invisible: false,
    tm_draft_create: microseconds,
    tm_draft_modified: microseconds,
    tm_draft_removed: 0,
  }
  const normalizedInfo = {
    ...info,
    name: String(milliseconds),
    create_time: milliseconds,
    update_time: milliseconds,
  }
  await atPublishStage('JY200_DUO_PUBLISH_METADATA_WRITE_FAILED', async () => {
    await replaceMetadata(metaPath, normalizedMeta)
    await replaceMetadata(infoPath, normalizedInfo)
  })
  await atPublishStage('JY200_DUO_PUBLISH_NORMALIZED_ARTIFACT_FAILED', () =>
    validateJY200ProbeArtifactTree({ stagingRoot: staging, artifactRoot: artifact }))
  const artifactBinding = await atPublishStage('JY200_DUO_PUBLISH_ARTIFACT_BINDING_FAILED', () => bindDirectory(artifact))
  const publicationId = `publication_${randomUUID().replaceAll('-', '')}`
  const publication = {
    publicationId,
    providerId,
    draftName,
    liveRoot: liveBinding.path,
    liveRootIdentity: liveBinding.identity,
    liveParent: liveBinding.parent,
    liveParentGeneration: liveBinding.parentGeneration,
    artifactIdentity: artifactBinding.identity,
    destinationIdentity: null,
    destinationGeneration: null,
    tombstoneName: null,
  }
  if (await publicationRepository.preparePublication({
    jobId, providerId, timelineFingerprint, publication,
  }) !== true) throw new Error('JY200_DUO_PUBLICATION_AUTHORITY_REJECTED')
  let renamed = false
  try {
    await assertDirectoryBinding(liveBinding)
    if (!await missing(destination)) throw new Error('JY200_DUO_DRAFT_ALREADY_EXISTS')
    await rename(artifact, destination)
    renamed = true
    await assertDirectoryBinding(liveBinding)
    const destinationBinding = await bindDirectory(destination)
    if (destinationBinding.identity !== artifactBinding.identity || destinationBinding.parent !== liveBinding.path) {
      throw new Error('JY200_DUO_PUBLISH_DESTINATION_REPLACED')
    }
    if (await publicationRepository.markPublished({
      jobId,
      publicationId,
      destinationIdentity: destinationBinding.identity,
      destinationGeneration: destinationBinding.generation,
    }) !== true) throw new Error('JY200_DUO_PUBLICATION_AUTHORITY_REJECTED')
    return Object.freeze({
      published: true,
      atomic: true,
      publication_id: publicationId,
      homepage_metadata_normalized: true,
      draft_fingerprint: createHash('sha256').update(JSON.stringify(normalizedInfo)).digest('hex'),
    })
  } catch (error) {
    if (renamed) await rollbackJY200DuoPublication({ publicationRepository, jobId, providerId }).catch(() => false)
    else await publicationRepository.settle({ jobId, publicationId, state: 'rolled_back' }).catch(() => false)
    throw error
  }
}

/**
 * Remove only the exact published directory retained by the durable authority.
 * The object is first moved behind an unpredictable tombstone and revalidated.
 * @param {{publicationRepository: Record<string, any>, jobId: string, providerId: string}} input
 */
export const rollbackJY200DuoPublication = async ({ publicationRepository, jobId, providerId }) => {
  const record = await publicationRepository.getPrivate(jobId)
  if (!record || record.ownerId !== providerId) return false
  if (record.state === 'rolled_back') return true
  if (record.state === 'committed') return false
  if (!record.publication) return publicationRepository.settle({ jobId, state: 'rolled_back' })
  const publication = record.publication
  const liveBinding = {
    path: publication.liveRoot,
    identity: publication.liveRootIdentity,
    parent: publication.liveParent,
    parentGeneration: publication.liveParentGeneration,
  }
  const destination = path.join(publication.liveRoot, publication.draftName)
  try {
    await assertDirectoryBinding(liveBinding)
    let tombstoneName = publication.tombstoneName
    let tombstone = tombstoneName ? path.join(publication.liveRoot, tombstoneName) : null
    const destinationExists = !await missing(destination)
    const tombstoneExists = tombstone ? !await missing(tombstone) : false
    if (destinationExists && tombstoneExists) throw new Error('JY200_DUO_PUBLISH_DESTINATION_REPLACED')
    if (!destinationExists && !tombstoneExists) {
      if (record.state === 'published') throw new Error('JY200_DUO_PUBLISH_DESTINATION_REPLACED')
      return publicationRepository.settle({ jobId, publicationId: publication.publicationId, state: 'rolled_back' })
    }
    const expectedIdentity = publication.destinationIdentity ?? publication.artifactIdentity
    if (destinationExists) {
      const current = await bindDirectory(destination)
      if (current.identity !== expectedIdentity ||
          (publication.destinationGeneration && current.generation !== publication.destinationGeneration)) {
        throw new Error('JY200_DUO_PUBLISH_DESTINATION_REPLACED')
      }
      if (!tombstoneName) {
        tombstoneName = `.openvideo-delete-${randomUUID().replaceAll('-', '')}`
        tombstone = path.join(publication.liveRoot, tombstoneName)
        if (await publicationRepository.beginRollback({
          jobId, publicationId: publication.publicationId, tombstoneName,
        }) !== true) throw new Error('JY200_DUO_PUBLICATION_AUTHORITY_REJECTED')
      }
      await rename(destination, /** @type {string} */ (tombstone))
    }
    await assertDirectoryBinding(liveBinding)
    const retained = await bindDirectory(/** @type {string} */ (tombstone))
    if (retained.identity !== expectedIdentity) throw new Error('JY200_DUO_PUBLISH_DESTINATION_REPLACED')
    await rm(/** @type {string} */ (tombstone), { recursive: true })
    return publicationRepository.settle({ jobId, publicationId: publication.publicationId, state: 'rolled_back' })
  } catch (error) {
    await publicationRepository.markRollbackFailed({
      jobId,
      code: error instanceof Error && /^JY200_[A-Z0-9_]+$/u.test(error.message)
        ? error.message
        : 'JY200_DUO_PUBLICATION_ROLLBACK_FAILED',
    }).catch(() => false)
    return false
  }
}

/** @param {{publicationRepository: Record<string, any>, jobId: string, providerId: string}} input */
export const commitJY200DuoPublication = async ({ publicationRepository, jobId, providerId }) => {
  const record = await publicationRepository.getPrivate(jobId)
  if (!record || record.ownerId !== providerId) return false
  if (record.state === 'committed') return true
  if (record.state !== 'published' || !record.publication?.destinationIdentity || !record.publication.destinationGeneration) return false
  const publication = record.publication
  try {
    await assertDirectoryBinding({
      path: publication.liveRoot,
      identity: publication.liveRootIdentity,
      parent: publication.liveParent,
      parentGeneration: publication.liveParentGeneration,
    })
    const destination = await bindDirectory(path.join(publication.liveRoot, publication.draftName))
    if (destination.identity !== publication.destinationIdentity || destination.generation !== publication.destinationGeneration) return false
    return publicationRepository.settle({ jobId, publicationId: publication.publicationId, state: 'committed' })
  } catch { return false }
}

/**
 * Bind all Provider callbacks to one durable Gateway authority.
 * @param {{publicationRepository: Record<string, any>, runtimeRoot: string, liveDraftRoot: string, repositoryRoot: string, providerId?: string}} input
 */
export const createJY200DuoPublicationAuthority = ({
  publicationRepository,
  runtimeRoot,
  liveDraftRoot,
  repositoryRoot,
  providerId = 'duo-video',
}) => Object.freeze({
  /** @param {Record<string, any>} input */
  async publish(input) {
    const providerResult = isRecord(input.providerResult) ? input.providerResult : {}
    const draftName = providerResult.draftName
    const publication = await publishJY200DuoStagingDraft({
      runtimeRoot,
      liveDraftRoot,
      repositoryRoot,
      publicationRepository,
      providerId,
      jobId: input.jobId,
      timelineFingerprint: input.timelineFingerprint,
      stagingRoot: input.stagingRoot,
      artifactRoot: typeof draftName === 'string' ? path.join(input.stagingRoot, draftName) : '',
      draftName,
      draftLabel: providerResult.draftLabel,
    })
    return Object.freeze({
      ...publication,
      draftId: draftName,
      outputFingerprint: publication.draft_fingerprint,
      summary: '剪映草稿已由受控 Writer 生成并通过独立读回，等待用户手动打开',
      handoffMode: 'manual_open_required',
      desktopOpened: false,
      draftLabel: providerResult.draftLabel,
      manualOpenHint: '请在剪映专业版首页的本地草稿列表中打开该标签。',
      writerProjectionFingerprint: input.timelineFingerprint,
    })
  },
  /** @param {{jobId: string}} input */
  rollback: ({ jobId }) => rollbackJY200DuoPublication({ publicationRepository, jobId, providerId }),
  /** @param {{jobId: string}} input */
  commit: ({ jobId }) => commitJY200DuoPublication({ publicationRepository, jobId, providerId }),
})
