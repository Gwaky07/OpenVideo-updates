import { lstat, readFile, realpath, stat } from 'node:fs/promises'
import { extname, resolve, sep } from 'node:path'

const contentTypes = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.ico', 'image/x-icon'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.webp', 'image/webp'],
  ['.woff2', 'font/woff2'],
])

class StaticWebError extends Error {
  /** @param {string} code */
  constructor(code) {
    super(code)
    this.name = 'StaticWebError'
    this.code = code
  }
}

/** @param {number} status @param {string} code @param {Record<string, string>} [headers] */
const errorResponse = (status, code, headers = {}) => new Response(
  JSON.stringify({ error: { code } }),
  {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'x-content-type-options': 'nosniff',
      ...headers,
    },
  },
)

/** @param {string} root @param {string} candidate */
const isInside = (root, candidate) =>
  candidate === root || candidate.startsWith(`${root}${sep}`)

/** @param {string} left @param {string} right */
const samePath = (left, right) =>
  process.platform === 'win32'
    ? left.toLowerCase() === right.toLowerCase()
    : left === right

/**
 * Serves the built Web application from the Gateway origin.
 * @param {{webRoot: string}} input
 */
export const createStaticWebHandler = async ({ webRoot }) => {
  const requestedRoot = resolve(webRoot)
  let canonicalRoot
  let indexPath
  let realRoot
  try {
    // A Windows packaged process can receive a virtualized path whose
    // realpath is different even though the directory itself is not a user
    // supplied junction. Resolve that benign redirection once and continue
    // serving from the canonical directory. Explicit root links remain
    // rejected; child links are checked again for every request below.
    if ((await lstat(requestedRoot)).isSymbolicLink()) throw new Error('reparse-root')
    realRoot = await realpath(requestedRoot)
    canonicalRoot = realRoot
    indexPath = resolve(canonicalRoot, 'index.html')
    if (!(await stat(indexPath)).isFile()) throw new Error('not-file')
  } catch {
    throw new StaticWebError('OPENVIDEO_WEB_BUILD_MISSING')
  }

  /** @param {Request} request */
  return async (request) => {
    if (!['GET', 'HEAD'].includes(request.method)) {
      return errorResponse(405, 'METHOD_NOT_ALLOWED', { allow: 'GET, HEAD' })
    }
    const url = new URL(request.url)

    let decodedPath
    try {
      decodedPath = decodeURIComponent(url.pathname)
    } catch {
      return errorResponse(400, 'INVALID_PATH')
    }
    if (/^\/api(?:[/\\]|$)/iu.test(decodedPath)) {
      return errorResponse(404, 'NOT_FOUND')
    }
    if (
      decodedPath.includes('\0') ||
      decodedPath.split(/[\\/]/u).some((part) => part === '..')
    ) {
      return errorResponse(400, 'INVALID_PATH')
    }

    const requestedPath = resolve(canonicalRoot, decodedPath.replace(/^[/\\]+/u, ''))
    if (!isInside(canonicalRoot, requestedPath)) {
      return errorResponse(400, 'INVALID_PATH')
    }

    let selectedPath = requestedPath
    let selectedStat
    try {
      selectedStat = await stat(selectedPath)
    } catch {
      if (extname(decodedPath) !== '') {
        return errorResponse(404, 'NOT_FOUND')
      }
      selectedPath = indexPath
      selectedStat = await stat(selectedPath)
    }
    if (!selectedStat.isFile()) {
      selectedPath = indexPath
      selectedStat = await stat(selectedPath)
    }
    const realSelectedPath = await realpath(selectedPath)
    if (
      !isInside(realRoot, realSelectedPath) ||
      !samePath(realSelectedPath, selectedPath)
    ) {
      return errorResponse(400, 'INVALID_PATH')
    }

    const extension = extname(selectedPath).toLowerCase()
    const body = request.method === 'HEAD' ? null : await readFile(selectedPath)
    // Public startup files keep their names across releases. Caching those as
    // immutable can replay an old handoff script against a new StartupGate.
    const immutableAsset = extension !== '.html' && isInside(resolve(canonicalRoot, 'assets'), selectedPath)
    return new Response(body, {
      status: 200,
      headers: {
        'cache-control': immutableAsset
          ? 'public, max-age=31536000, immutable'
          : 'no-cache',
        'content-length': String(selectedStat.size),
        'content-type': contentTypes.get(extension) ?? 'application/octet-stream',
        'cross-origin-resource-policy': 'same-origin',
        'x-content-type-options': 'nosniff',
      },
    })
  }
}
