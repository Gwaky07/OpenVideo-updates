import { assertSafePackagingText, isPackagingResourceTokenForFamily } from './jianying-packaging-resource-index.mjs'

const OPAQUE_ID = /^(?:ovreq|ovauth|ovjob|ovcat)_[A-Za-z0-9_-]{8,160}$/u
const SAFE_TEXT = /^[^\\/:*?"<>|\u0000-\u001f]{1,160}$/u
const SAFE_STATE = new Set(['queued', 'running', 'succeeded', 'failed', 'cancelled'])
const SAFE_ENTRY_STATE = new Set(['discoverable', 'blocked'])
const SAFE_JOB_ERROR = /^NATIVE00[1234]_[A-Z0-9_]{3,80}$/u

/**
 * @typedef {{
 *   request_id: string,
 *   draft_authorization_id: string,
 *   catalog_revision?: string | null,
 *   mode: 'discover',
 * }} DraftMinerRequestRecord
 * @typedef {{
 *   draft_authorization_id: string,
 *   catalog_revision?: string | null,
 *   mode: 'discover',
 *   idempotency_key: string,
 * }} DraftMinerStartRequestRecord
 * @typedef {{
 *   packaging_token: string,
 *   family: string,
 *   label: string,
 *   tags: string[],
 *   state: 'discoverable' | 'blocked',
 *   writer_eligible: false,
 * }} DraftMinerCandidateInput
 * @typedef {{
 *   packagingToken: string,
 *   family: string,
 *   label: string,
 *   tags: string[],
 *   state: 'discoverable' | 'blocked',
 *   writerEligible: false,
 * }} DraftMinerCandidateRecord
 * @typedef {{
 *   packaging_token: string,
 *   family: string,
 *   label: string,
 *   tags: string[],
 *   state: 'discoverable' | 'blocked',
 *   writer_eligible: false,
 * }} DraftMinerCandidateJobInput
 * @typedef {{
 *   job_id: string,
 *   status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled',
 *   progress: number,
 *   error_code: string | null,
 *   candidate_count: number,
 * }} DraftMinerJobRecordInput
 * @typedef {{
 *   id: string,
 *   requestId: string,
 *   authorizationId: string,
 *   idempotencyKey: string,
 *   status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled',
 *   progress: number,
 *   errorCode: string | null,
 *   catalogRevision?: string,
 *   candidateCount: number,
 *   candidates: DraftMinerCandidateRecord[],
 *   attempt: number,
 *   cancelRequested: boolean,
 *   createdAt: number,
 *   updatedAt: number,
 * }} DraftMinerJobRecordInputV4
 */

/** @param {string} code @returns {never} */
const fail = (code) => { const error = /** @type {Error & {code: string}} */ (new Error(code)); error.code = code; throw error }
/** @param {unknown} value @returns {value is Record<string, unknown>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {ReadonlyArray<string>} keys @param {string} code */
const assertExactKeys = (value, keys, code) => {
  if (!isRecord(value)) fail(code)
  const record = /** @type {Record<string, unknown>} */ (value)
  if (Object.keys(record).some((key) => !keys.includes(key))) fail(code)
}
/** @param {unknown} value @param {string} code @returns {string} */
const assertOpaque = (value, code) => {
  if (typeof value !== 'string' || !OPAQUE_ID.test(value)) fail(code)
  return /** @type {string} */ (value)
}
/** @param {unknown} value @param {string} code @returns {string} */
const assertSafeText = (value, code) => {
  if (typeof value !== 'string' || !SAFE_TEXT.test(value) || /(?:[A-Za-z]:[\\/]|\\\\|\.\.[\\/]|https?:\/\/|file:)/iu.test(value)) fail(code)
  const text = /** @type {string} */ (value.trim())
  try { return assertSafePackagingText(text, code) } catch { return fail(code) }
}

/** @param {unknown} input */
export const parseDraftMinerRequest = (input) => {
  const record = /** @type {DraftMinerRequestRecord} */ (/** @type {Record<string, unknown>} */ (input))
  assertExactKeys(input, ['request_id', 'draft_authorization_id', 'catalog_revision', 'mode'], 'NATIVE002_REQUEST_KEYS_INVALID')
  if (record.mode !== 'discover') fail('NATIVE002_MODE_UNSUPPORTED')
  const requestId = assertOpaque(record.request_id, 'NATIVE002_REQUEST_ID_INVALID')
  const authorizationId = assertOpaque(record.draft_authorization_id, 'NATIVE002_AUTHORIZATION_INVALID')
  if (record.catalog_revision !== undefined && record.catalog_revision !== null) assertOpaque(record.catalog_revision, 'NATIVE002_CATALOG_REVISION_INVALID')
  return Object.freeze({
    schema_version: 1,
    request_id: requestId,
    draft_authorization_id: authorizationId,
    ...(record.catalog_revision ? { catalog_revision: record.catalog_revision } : {}),
    mode: 'discover',
  })
}

/** @param {unknown} entry */
export const projectDraftMinerCandidate = (entry) => {
  const record = /** @type {DraftMinerCandidateInput} */ (/** @type {Record<string, unknown>} */ (entry))
  assertExactKeys(entry, ['packaging_token', 'family', 'label', 'tags', 'state', 'writer_eligible'], 'NATIVE002_CANDIDATE_PRIVATE_FIELD')
  if (typeof record.family !== 'string' || !/^[a-z][a-z0-9_]{1,48}$/u.test(record.family)) fail('NATIVE002_CANDIDATE_FAMILY_INVALID')
  if (!isPackagingResourceTokenForFamily(record.family, record.packaging_token)) fail('NATIVE002_CANDIDATE_TOKEN_INVALID')
  const label = assertSafeText(record.label, 'NATIVE002_CANDIDATE_LABEL_INVALID')
  if (!Array.isArray(record.tags) || record.tags.length > 16) fail('NATIVE002_CANDIDATE_TAGS_INVALID')
  const tags = record.tags.map((/** @type {string} */ tag) => assertSafeText(tag, 'NATIVE002_CANDIDATE_TAGS_INVALID'))
  if (!SAFE_ENTRY_STATE.has(record.state) || record.writer_eligible !== false) fail('NATIVE002_CANDIDATE_NOT_DISCOVERY_ONLY')
  return Object.freeze({ packagingToken: record.packaging_token, family: record.family, label, tags: Object.freeze(tags), state: record.state, writerEligible: false })
}

/** @param {unknown} input */
export const projectDraftMinerJob = (input) => {
  const record = /** @type {DraftMinerJobRecordInput} */ (/** @type {Record<string, unknown>} */ (input))
  assertExactKeys(input, ['job_id', 'status', 'progress', 'error_code', 'candidate_count'], 'NATIVE002_JOB_PRIVATE_FIELD')
  const jobId = assertOpaque(record.job_id, 'NATIVE002_JOB_ID_INVALID')
  if (!SAFE_STATE.has(record.status) || !Number.isInteger(record.progress) || record.progress < 0 || record.progress > 100 ||
      !Number.isInteger(record.candidate_count) || record.candidate_count < 0 || record.candidate_count > 20_000) fail('NATIVE002_JOB_INVALID')
  if (record.error_code !== null && (typeof record.error_code !== 'string' || !SAFE_JOB_ERROR.test(record.error_code))) fail('NATIVE002_JOB_ERROR_INVALID')
  return Object.freeze({ schemaVersion: 1, jobId, status: record.status, progress: record.progress, errorCode: record.error_code, candidateCount: record.candidate_count })
}

/** @param {unknown} input */
export const parseDraftMinerStartRequest = (input) => {
  const record = /** @type {DraftMinerStartRequestRecord} */ (/** @type {Record<string, unknown>} */ (input))
  assertExactKeys(input, ['draft_authorization_id', 'catalog_revision', 'mode', 'idempotency_key'], 'NATIVE004_REQUEST_KEYS_INVALID')
  if (record.mode !== 'discover') fail('NATIVE004_MODE_UNSUPPORTED')
  const authorizationId = assertOpaque(record.draft_authorization_id, 'NATIVE004_AUTHORIZATION_INVALID')
  const idempotencyKey = assertOpaque(record.idempotency_key, 'NATIVE004_IDEMPOTENCY_INVALID')
  if (record.catalog_revision !== undefined && record.catalog_revision !== null) assertOpaque(record.catalog_revision, 'NATIVE004_CATALOG_REVISION_INVALID')
  return Object.freeze({
    schema_version: 1,
    draft_authorization_id: authorizationId,
    ...(record.catalog_revision ? { catalog_revision: record.catalog_revision } : {}),
    mode: 'discover',
    idempotency_key: idempotencyKey,
  })
}

/** @param {unknown} input */
export const projectDraftMinerJobRecord = (input) => {
  const candidateInput = /** @type {Record<string, unknown>} */ (input)
  if (!isRecord(input) || Object.keys(candidateInput).some((key) => ![
    'id', 'requestId', 'authorizationId', 'idempotencyKey', 'status', 'progress', 'errorCode',
    'catalogRevision', 'candidateCount', 'candidates', 'attempt', 'cancelRequested', 'createdAt', 'updatedAt',
  ].includes(key))) fail('NATIVE004_JOB_PRIVATE_FIELD')
  const record = /** @type {DraftMinerJobRecordInputV4} */ (candidateInput)
  assertOpaque(record.id, 'NATIVE004_JOB_ID_INVALID')
  assertOpaque(record.requestId, 'NATIVE004_REQUEST_ID_INVALID')
  assertOpaque(record.authorizationId, 'NATIVE004_AUTHORIZATION_INVALID')
  assertOpaque(record.idempotencyKey, 'NATIVE004_IDEMPOTENCY_INVALID')
  if (record.catalogRevision !== undefined) assertOpaque(record.catalogRevision, 'NATIVE004_CATALOG_REVISION_INVALID')
  if (!SAFE_STATE.has(record.status) || !Number.isInteger(record.progress) || record.progress < 0 || record.progress > 100 ||
      !Number.isInteger(record.candidateCount) || record.candidateCount < 0 || record.candidateCount > 20_000 ||
      !Number.isInteger(record.attempt) || record.attempt < 0 || record.attempt > 100 ||
      typeof record.cancelRequested !== 'boolean' || !Number.isSafeInteger(record.createdAt) || record.createdAt < 0 ||
      !Number.isSafeInteger(record.updatedAt) || record.updatedAt < record.createdAt ||
      (record.errorCode !== null && (typeof record.errorCode !== 'string' || !SAFE_JOB_ERROR.test(record.errorCode))) ||
      !Array.isArray(record.candidates) || record.candidates.length > 20_000 ||
      record.candidateCount !== record.candidates.length ||
      record.candidates.some((/** @type {Record<string, unknown>} */ candidate) => !projectDraftMinerCandidate({
        packaging_token: candidate?.packagingToken,
        family: candidate?.family,
        label: candidate?.label,
        tags: candidate?.tags,
        state: candidate?.state,
        writer_eligible: candidate?.writerEligible,
      }))) fail('NATIVE004_JOB_INVALID')
  return Object.freeze({
    schemaVersion: 1,
    jobId: record.id,
    requestId: record.requestId,
    status: record.status,
    progress: record.progress,
    errorCode: record.errorCode,
    candidateCount: record.candidateCount,
    candidates: Object.freeze(record.candidates.map((/** @type {DraftMinerCandidateRecord} */ candidate) => Object.freeze({ ...candidate }))),
    attempt: record.attempt,
    cancelRequested: record.cancelRequested,
  })
}
