import {
  assertSafePackagingText,
  projectPackagingResourceCandidates,
  searchPackagingResourceCandidates,
  summarizePackagingResourceReadiness,
} from './jianying-packaging-resource-index.mjs'
import { recommendPackagingBatch } from './jianying-packaging-recommender.mjs'
import { buildPackagingResourceIntent } from './brief-packaging.mjs'
import { resolvePackagingBindingQualification } from './jianying-packaging-binding-resolver.mjs'

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * EditPlan voiceover may contain author-intended line breaks. The packaging
 * ranker only needs a single-line semantic copy; canonical narration remains
 * untouched and continues to carry its original formatting.
 * @param {unknown} value
 * @param {string} fallback
 * @param {string} field
 * @param {number} max
 */
const safeSceneContextText = (value, fallback, field, max) => {
  const normalized = typeof value === 'string'
    ? value.replace(/[\t\r\n]+/gu, ' ').replace(/ {2,}/gu, ' ').trim()
    : ''
  return assertSafePackagingText(normalized || fallback, field, max)
}

/**
 * A qualification is deliberately request-scoped.  The durable catalog stays
 * discovery-only; only its safe token and the projected writer binding enter
 * the ephemeral view consumed by the canonical timeline adapter.
 * @param {any} index
 * @param {string} family
 * @param {string} query
 * @param {Function | null} qualifyCandidate
 * @param {Record<string, any> | null} qualificationRegistry
 * @param {AbortSignal | null} signal
 */
const qualifyDiscoveryCandidates = async (index, family, query, qualifyCandidate, qualificationRegistry, signal) => {
  if (typeof qualifyCandidate !== 'function' || !qualificationRegistry || typeof qualificationRegistry !== 'object') return []
  const entriesByToken = new Map(index.entries.map((/** @type {Record<string, any>} */ entry) => [entry.packaging_token, entry]))
  let candidates = searchPackagingResourceCandidates(index, query, {
    family,
    writerEligibleOnly: false,
    limit: 6,
  })
  // Semantic context can miss a valid local label; always preserve the
  // bounded Top-N fallback so exact qualification still gets a chance.
  if (candidates.length === 0 && query) {
    candidates = searchPackagingResourceCandidates(index, '', {
      family,
      writerEligibleOnly: false,
      limit: 6,
    })
  }
  // Qualify the bounded Top-N in parallel. A single bad Direct-ID, stale
  // entitlement or unavailable resource must not prevent the next candidate
  // from being selected. These entries remain request-scoped and are never
  // written back to the durable discovery catalog.
  const qualifyOne = async (/** @type {Record<string, any>} */ candidate) => {
    if (signal?.aborted) throw signal.reason ?? new Error('ABORT_ERR')
    const entry = entriesByToken.get(candidate.packagingToken)
    if (!entry || entry.state !== 'discoverable' || entry.writer_eligible !== false) return null
    let handle = null
    try {
      handle = await qualifyCandidate({ entry, catalog: index, signal })
    } catch {
      return null
    }
    let receipt = null
    try {
      receipt = await resolvePackagingBindingQualification({ registry: qualificationRegistry, handle, catalog: index, entry })
    } catch {
      return null
    }
    if (!isRecord(receipt)) return null
    return Object.freeze({
      ...entry,
      state: 'writer_eligible',
      writer_eligible: true,
      private_binding: Object.freeze(structuredClone(receipt.private_projected_binding)),
    })
  }
  const qualified = await Promise.all(candidates.map(qualifyOne))
  return qualified.filter(Boolean)
}

/** @param {any} index @param {Array<Record<string, any>>} qualified */
const withEphemeralQualifiedEntries = (index, qualified) => {
  if (qualified.length === 0) return index
  const qualifiedByToken = new Map(qualified.map((entry) => [entry.packaging_token, entry]))
  return Object.freeze({
    ...index,
    entries: Object.freeze(index.entries.map((/** @type {Record<string, any>} */ entry) => qualifiedByToken.get(entry.packaging_token) ?? entry)),
  })
}

/** @param {Record<string, any>} editPlan */
const selectedItems = (editPlan) => (Array.isArray(editPlan?.items) ? editPlan.items : [])
  .filter((item) => isRecord(item) && item.status === 'selected')
  .sort((left, right) => Number(left.order) - Number(right.order))

/** @param {unknown} constraints @param {boolean} [requireCurrentToken] */
const templatePackagingFamilies = (constraints, requireCurrentToken = true) => {
  if (!isRecord(constraints)) return []
  const families = []
  for (const segment of Array.isArray(constraints.packagingSegments) ? constraints.packagingSegments : []) {
    if (segment?.role === 'sticker') families.push('sticker')
    if (segment?.role === 'effect') families.push('video_effect')
  }
  for (const segment of Array.isArray(constraints.richTextSegments) ? constraints.richTextSegments : []) {
    if (
      segment?.capabilityId === 'text.flower.private' &&
      (!requireCurrentToken || typeof segment.packagingToken === 'string')
    ) families.push('flower')
    if (segment?.capabilityId === 'text.rich' && segment?.styleToken === 'rich-emphasis') {
      families.push('flower')
    }
    if (
      segment?.capabilityId === 'text.bubble.private' &&
      (!requireCurrentToken || typeof segment.packagingToken === 'string')
    ) families.push('bubble')
  }
  return [...new Set(families)]
}

const FOLLOW_TEMPLATE_EXPLICIT_FAMILY_PATTERNS = Object.freeze({
  filter: /滤镜/u,
  video_effect: /(?:视频)?特效/u,
  video_animation: /动画|入场|出场/u,
  mask: /蒙版/u,
  blend: /混合|叠加/u,
})

/** Keep the model's intent explicit and bounded without exposing private catalog data. */
/** @param {Record<string, any>} packaging @param {string[]} templateCapabilityFamilies */
const publicPackagingIntent = (packaging, templateCapabilityFamilies) => ({
  visualStyle: packaging.visualStyle,
  packagingDensity: packaging.packagingDensity,
  emphasisStyle: packaging.emphasisStyle,
  stickerMode: packaging.stickerMode,
  transitionStyle: packaging.transitionStyle,
  keywordHighlights: packaging.keywordHighlights.slice(0, 12),
  packagingNotes: assertSafePackagingText(packaging.packagingNotes || '无额外备注', 'packaging_notes', 500),
  templateFamilies: [...new Set(templateCapabilityFamilies)].slice(0, 12),
})

/** Content-dependent fallback placement when the LLM ranker is unavailable.
 * Prefer an unused current-project shot so distinct packaging families do not
 * stack on one beat merely because their hashes collide.
 * @param {string} family @param {Array<Record<string, any>>} contexts @param {Set<number>} occupied
 */
const contextIndexForFamily = (family, contexts, occupied) => {
  const material = `${family}|${contexts.map((context) => `${context.voiceoverText}|${context.visualSummary}|${context.tags.join(',')}`).join('|')}`
  let hash = 2166136261
  for (const character of material) {
    hash ^= character.codePointAt(0) ?? 0
    hash = Math.imul(hash, 16777619) >>> 0
  }
  const preferred = hash % contexts.length
  for (let offset = 0; offset < contexts.length; offset += 1) {
    const index = (preferred + offset) % contexts.length
    if (!occupied.has(index)) return index
  }
  return preferred
}

/** @param {any} index @param {string} family @param {string[]} terms */
const firstMatchingSemanticQuery = (index, family, terms) => {
  const variants = []
  for (const value of [...new Set(terms.map((term) => term.trim()).filter(Boolean))]) {
    variants.push(value)
    if (/^[\u3400-\u9fff]+$/u.test(value)) {
      for (let length = Math.min(4, value.length); length >= 2; length -= 1) {
        for (let start = 0; start + length <= value.length && variants.length < 96; start += 1) {
          variants.push(value.slice(start, start + length))
        }
      }
    }
  }
  for (const term of variants) {
    if (searchPackagingResourceCandidates(index, term, { family, writerEligibleOnly: true, limit: 1 }).length > 0) {
      return term.slice(0, 200)
    }
  }
  return ''
}

/** Derive target-time ranges from the current project, never from template slots. */
/** @param {Record<string, any>} editPlan @param {{templateConstraints?: unknown, narrationSegments?: unknown}} [options] */
export const derivePackagingTargetRanges = (editPlan, { narrationSegments = null } = {}) => {
  const items = selectedItems(editPlan)
  const narration = Array.isArray(narrationSegments) ? narrationSegments : null
  const ranges = new Map()
  let cursor = 0
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index]
    const candidate = /** @type {Array<Record<string, any>>} */ (
      Array.isArray(item.candidates) ? item.candidates : []
    ).find((entry) => entry?.candidate_id === item.selected_candidate_id)
    const narrationSegment = narration?.[index] ?? null
    const narrationDurationUs = Number(narrationSegment?.durationUs)
    const durationUs = Number.isSafeInteger(narrationDurationUs) && narrationSegment?.sentenceId === item.sentence_id
      ? narrationDurationUs
      : Math.round((Number(candidate?.end) - Number(candidate?.start)) * 1_000_000)
    if (!Number.isSafeInteger(durationUs) || durationUs <= 0 || typeof item.sentence_id !== 'string') {
      throw new Error('JY132_TARGET_RANGE_INVALID')
    }
    ranges.set(item.sentence_id, Object.freeze({ startUs: cursor, durationUs }))
    cursor += durationUs
  }
  return ranges
}

/** @param {Record<string, any>} editPlan @param {unknown} sceneCards @param {Map<string, {startUs: number, durationUs: number}>} targetRanges */
export const derivePackagingSceneContexts = (editPlan, sceneCards, targetRanges) => {
  const bySceneId = new Map((Array.isArray(sceneCards) ? sceneCards : [])
    .filter(isRecord)
    .filter((scene) => typeof scene.id === 'string')
    .map((scene) => [scene.id, scene]))
  return selectedItems(editPlan).map((item) => {
    const candidate = /** @type {Array<Record<string, any>>} */ (item.candidates ?? [])
      .find((entry) => entry?.candidate_id === item.selected_candidate_id)
    const scene = bySceneId.get(candidate?.scene_id) ?? {}
    const targetRange = targetRanges.get(item.sentence_id)
    if (!targetRange) throw new Error('JY132_TARGET_RANGE_INVALID')
    const tags = [...new Set([
      ...(Array.isArray(candidate?.tags) ? candidate.tags : []),
      ...(Array.isArray(scene.tags) ? scene.tags : []),
      ...(Array.isArray(scene.domainTags) ? scene.domainTags : []),
      ...(Array.isArray(scene.visualTags) ? scene.visualTags : []),
      ...(Array.isArray(scene.actionTags) ? scene.actionTags : []),
      scene.shotPurpose,
      scene.recommendedUse,
    ].filter((value) => typeof value === 'string' && value.trim()))]
      .slice(0, 16)
      .map((tag) => assertSafePackagingText(tag, 'scene_tag', 80))
    return Object.freeze({
      targetSegmentId: assertSafePackagingText(item.sentence_id, 'scene_segment_id', 180),
      targetRange: Object.freeze({ ...targetRange }),
      voiceoverText: safeSceneContextText(item.voiceover_text, 'no voiceover', 'scene_voiceover', 500),
      visualSummary: assertSafePackagingText(scene.summary || candidate?.summary || 'no visual summary', 'scene_visual_summary', 500),
      ocrText: assertSafePackagingText(scene.ocrText || 'no visible text', 'scene_ocr', 500),
      asrSummary: assertSafePackagingText(scene.asrSummary || 'no reliable speech', 'scene_asr', 500),
      tags: Object.freeze(tags),
    })
  })
}

/**
 * Create the product-facing automatic packaging provider. It deliberately
 * uses safe labels/tags for selection and returns the private catalog only to
 * the server-side timeline adapter.
 */
/**
 * @param {{
 *   index?: any,
 *   ranker?: ((input: Record<string, any>) => Promise<unknown> | unknown) | null,
 *   supportedFamilies?: Iterable<string> | null,
 *   profileId?: string | null,
 *   appVersion?: string | null,
 *   qualifyCandidate?: ((input: {entry: Record<string, any>, catalog: Record<string, any>, signal: AbortSignal | null}) => Promise<unknown> | unknown) | null,
 *   qualificationRegistry?: Record<string, any> | null,
 * }} [input]
 */
export const createPackagingRecommendationProvider = ({ index, ranker = null, supportedFamilies = null, profileId = null, appVersion = null, qualifyCandidate = null, qualificationRegistry = null } = {}) => {
  if (!isRecord(index) || !Array.isArray(index.entries)) return null
  // The production loader already performs evidence admission. Re-check the
  // active desktop identity here so a stale, injected or recovered index can
  // never reach the Workbench recommendation path.
  if (profileId !== null && index.profileId !== profileId) return null
  if (appVersion !== null && index.appVersion !== appVersion) return null
  const allowedFamilies = new Set(supportedFamilies ?? ['flower', 'bubble', 'sticker', 'video_effect', 'video_animation', 'mask', 'blend'])
  return {
    index,
    /** Return only aggregate family/status counts; never expose private bindings. */
    readiness: () => summarizePackagingResourceReadiness(index),
    /** @param {{brief: unknown, editPlan: Record<string, any>, templateConstraints?: unknown, narrationSegments?: unknown, sceneCards?: unknown, excludedPackagingTokens?: unknown, signal?: AbortSignal | null}} input */
    async recommend({ brief, editPlan, templateConstraints = null, narrationSegments = null, sceneCards = null, excludedPackagingTokens = [], signal = null }) {
      const safeBrief = isRecord(brief) ? brief : {}
      const intent = buildPackagingResourceIntent(safeBrief.packaging)
      const packaging = intent.packaging
      if (packaging.enabled === false) return null
      const items = selectedItems(editPlan)
      if (items.length === 0) return null
      const excluded = new Set(Array.isArray(excludedPackagingTokens)
        ? excludedPackagingTokens.filter((token) => typeof token === 'string' && /^ovj[a-z0-9_]{7,159}$/iu.test(token)).slice(0, 24)
        : [])
      const filteredIndex = excluded.size === 0
        ? index
        : Object.freeze({ ...index, entries: Object.freeze(index.entries.filter((/** @type {Record<string, any>} */ entry) => !excluded.has(entry.packaging_token))) })
      const candidates = projectPackagingResourceCandidates(filteredIndex, { writerEligibleOnly: true })
      const coveredTemplateFamilies = new Set(templatePackagingFamilies(templateConstraints))
      const templateCapabilityFamilies = templatePackagingFamilies(templateConstraints, false)
      const rankerIntent = publicPackagingIntent(packaging, templateCapabilityFamilies)
      // "follow_template" means follow authored template slots. If the
      // template has no sticker slot, do not invent a sticker merely because
      // the UI mode is set to follow_template. Explicit notes can still opt
      // into stickers when the user asks for them directly.
      const requestedIntentFamilies = intent.families.filter((family) => {
        if (templateConstraints === null || templateCapabilityFamilies.includes(family)) return true
        if (family === 'sticker' && packaging.stickerMode === 'follow_template') {
          return /贴纸/u.test(packaging.packagingNotes)
        }
        const explicitPattern = Object.hasOwn(FOLLOW_TEMPLATE_EXPLICIT_FAMILY_PATTERNS, family)
          ? FOLLOW_TEMPLATE_EXPLICIT_FAMILY_PATTERNS[/** @type {keyof typeof FOLLOW_TEMPLATE_EXPLICIT_FAMILY_PATTERNS} */ (family)]
          : null
        if (packaging.visualStyle === 'follow_template' && explicitPattern) {
          return explicitPattern.test(packaging.packagingNotes)
        }
        return true
      })
      const requestedFamilies = [...new Set([
        ...requestedIntentFamilies,
        ...templateCapabilityFamilies,
      ])].filter((family) => allowedFamilies.has(family) && !coveredTemplateFamilies.has(family))
      if (requestedFamilies.length === 0) return null
      if (typeof qualifyCandidate !== 'function' &&
          !requestedFamilies.some((family) => candidates.some((candidate) => candidate.family === family))) {
        return null
      }
      const targetRanges = derivePackagingTargetRanges(editPlan, { templateConstraints, narrationSegments })
      const sceneContexts = derivePackagingSceneContexts(editPlan, sceneCards, targetRanges)
      const occupiedContextIndexes = new Set()
      const requestContexts = requestedFamilies
        .map((family) => {
          const contextIndex = contextIndexForFamily(family, sceneContexts, occupiedContextIndexes)
          occupiedContextIndexes.add(contextIndex)
          const context = sceneContexts[contextIndex]
          const semanticQuery = [...intent.queryTerms, context.voiceoverText, context.visualSummary, context.ocrText, context.asrSummary, ...context.tags]
            .filter((value) => typeof value === 'string' && value.trim())
            .join(' ')
            .slice(0, 200)
          return { family, context, semanticQuery }
        })
      const qualified = []
      for (const { family, semanticQuery } of requestContexts) {
        if (candidates.some((candidate) => candidate.family === family)) continue
        qualified.push(...await qualifyDiscoveryCandidates(filteredIndex, family, semanticQuery, qualifyCandidate, qualificationRegistry, signal))
      }
      const requestIndex = withEphemeralQualifiedEntries(filteredIndex, qualified)
      const requestCandidates = projectPackagingResourceCandidates(requestIndex, { writerEligibleOnly: true })
      const families = requestContexts
        .map((item) => item.family)
        .filter((family) => requestCandidates.some((candidate) => candidate.family === family))
      if (families.length === 0) return null
      const requests = []
      for (let position = 0; position < families.length; position += 1) {
        const family = families[position]
        const context = requestContexts.find((item) => item.family === family)?.context ?? sceneContexts[position % sceneContexts.length]
        const semanticQuery = requestContexts.find((item) => item.family === family)?.semanticQuery ?? ''
        const query = firstMatchingSemanticQuery(requestIndex, family, [
          ...intent.queryTerms,
          context.voiceoverText,
          context.visualSummary,
          context.ocrText,
          context.asrSummary,
          ...context.tags,
        ])
        const targetSegmentId = context.targetSegmentId
        const targetRange = targetRanges.get(targetSegmentId)
        if (!targetRange) throw new Error('JY132_TARGET_RANGE_INVALID')
        requests.push({
          family,
          query,
          targetSegmentId,
          startUs: targetRange.startUs,
          durationUs: targetRange.durationUs,
          ...(family === 'filter' ? { parameters: { intensity: 0.5 } } : {}),
        })
      }
      if (requests.length === 0) return null
      const recommendation = await recommendPackagingBatch({
        index: requestIndex,
        requests,
        ranker,
        sceneContexts,
        intent: rankerIntent,
        signal,
      })
      return { recommendation, catalog: requestIndex }
    },
  }
}
