import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'

const main = async () => {
  const root = loadLocalRuntimeConfig().dataRoot
  const source = JSON.parse(await readFile(path.join(root, 'catalogs', 'jy041-filter-catalog.json'), 'utf8'))
  const segment = source.entries?.find((entry) => entry.capability_id === 'filter.video.named')
  if (!segment?.resource_id) throw new Error('JY042_PRIVATE_SOURCE_MISSING')
  const entry = {
    capability_id: 'filter.video.track_named',
    filter_token: `ovjflt_v1_track_${createHash('sha256').update(String(segment.resource_id)).digest('hex')}`,
    resource_id: segment.resource_id,
  }
  const catalog = { schema_version: 1, kind: 'jy017_filter_catalog', catalog_version: '1.0.0', upstream_commit: source.upstream_commit, entries: [entry] }
  catalog.catalog_fingerprint = createHash('sha256').update(JSON.stringify(catalog)).digest('hex')
  await writeFile(path.join(root, 'catalogs', 'jy042-filter-track-catalog.json'), JSON.stringify(catalog), { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(JSON.stringify({ ok: true, capability: entry.capability_id, binding_count: 1 }) + '\n')
}
main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.message ?? 'JY042_IMPORT_FAILED' }) + '\n'); process.exitCode = 1 })
