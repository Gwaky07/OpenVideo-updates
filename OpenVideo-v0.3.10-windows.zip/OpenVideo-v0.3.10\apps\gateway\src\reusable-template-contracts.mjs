import { createHash } from 'node:crypto'

import {
  buildStyleSummaryFromArtifact,
  isPreviewAvailability,
  isStyleSummary,
  normalizeStyleSummary,
} from './template-style-profile.mjs'
import {
  blendReplicationRecipeVisuals,
  isReplicationRecipe,
  replicationRecipeFingerprint,
} from './replication-recipe.mjs'

const orientations = new Set(['portrait', 'landscape', 'square'])
const pacingValues = new Set(['calm', 'balanced', 'dynamic'])
const statuses = new Set(['draft', 'approved', 'inactive'])
const templateSourceKinds = new Set(['jianying_draft', 'video_analysis'])
const transitions = new Set(['none', 'cut', 'dissolve', 'match_cut', 'wipe'])
const slotRoles = new Set(['hook', 'context', 'detail', 'process', 'proof', 'cta', 'main'])
const captionModes = new Set(['none', 'steady', 'burst'])
const packagingCards = new Set(['none', 'title_card'])
const subtitleStyles = new Set(['default', 'bottom_safe'])
const audioEmphasisKinds = new Set(['beat', 'accent', 'drop'])

/**
 * A finished reference video may be approved only after something beyond shot
 * timing was actually detected.  This keeps an empty scene split from being
 * advertised as a learned, reusable template.
 * @param {Record<string, any> | null} recipe
 * @param {Record<string, any>} styleSummary
 */
export const hasMeaningfulVideoLearningEvidence = (recipe, styleSummary) => {
  if (!recipe || recipe.source?.kind !== 'video_analysis') return true
  const captionLearned = Array.isArray(recipe.capabilities) && recipe.capabilities.some((entry) =>
    entry?.id === 'caption.basic' && entry.learned === true)
  // Older broken recipes synthesized every source start at 0. A visual report
  // cannot repair that missing reference-cut evidence after the fact.
  const sourceStarts = Array.isArray(recipe.videoSlots)
    ? recipe.videoSlots
      .map((slot) => slot?.sourceStartUs)
      .filter((start) => Number.isSafeInteger(start) && start >= 0)
    : []
  // A single source clip naturally begins at zero. The legacy broken recipe
  // was recognisable because it fabricated *every* cut at zero; require a
  // non-zero source position only when the recipe claims multiple cuts.
  const hasReferenceCuts = sourceStarts.length === 1
    ? sourceStarts[0] === 0
    : sourceStarts.some((start) => start > 0)
  return hasReferenceCuts && (
    captionLearned ||
    styleSummary?.visual?.detected === true ||
    styleSummary?.audio?.detected === true
  )
}

/**
 * A bound Jianying draft already is the finished look. Flower/caption/SFX
 * counts in the recipe are the verifiable template evidence; do not require a
 * separately rendered fade-from-black demo to look different from that cut.
 * @param {Record<string, any> | null} recipe
 */
export const authoredJianyingDraftHasVerifiableLook = (recipe) => {
  if (!recipe || recipe.source?.kind !== 'jianying_draft') return false
  const flowerCount = Number(recipe.packaging?.flowerTextCount)
  if (Number.isFinite(flowerCount) && flowerCount > 0) return true
  if (Array.isArray(recipe.textSegments) && recipe.textSegments.some((segment) =>
    segment?.role === 'caption' || segment?.role === 'rich_text')) return true
  if (Array.isArray(recipe.audioCues) && recipe.audioCues.some((cue) =>
    cue?.role === 'sfx' || cue?.role === 'bgm')) return true
  return Array.isArray(recipe.capabilities) && recipe.capabilities.some((entry) =>
    entry?.learned === true && entry.id !== 'editing.timing')
}
const publicKeys = [
  'bindable',
  'compatibility',
  'createdAt',
  'draftSummary',
  'fingerprint',
  'label',
  'libraryTemplateId',
  'orientation',
  'pacing',
  'previewAvailability',
  'replicationRecipe',
  'revision',
  'rulesSummary',
  'status',
  'styleSummary',
  'targetDurationSeconds',
  'updatedAt',
]

const projectBindingKeys = [
  'draft',
  'fingerprint',
  'label',
  'libraryTemplateId',
  'orientation',
  'pacing',
  'replicationRecipe',
  'replicationRecipeFingerprint',
  'revision',
  'styleProfile',
  'targetDurationSeconds',
]
const blendedProjectBindingKeys = [...projectBindingKeys, 'blendSources']
const legacyRecipeProjectBindingKeys = projectBindingKeys.filter(
  (key) => key !== 'replicationRecipeFingerprint',
)
const styleOnlyProjectBindingKeys = projectBindingKeys.filter(
  (key) => !['replicationRecipe', 'replicationRecipeFingerprint'].includes(key),
)
const legacyProjectBindingKeys = projectBindingKeys.filter(
  (key) => !['replicationRecipe', 'replicationRecipeFingerprint', 'styleProfile'].includes(key),
)
const projectBindingDraftKeys = [
  'baseTemplateRef',
  'draftId',
  'rules',
  'slots',
  'targetDurationMs',
]

/** @template T @param {T} value @returns {T} */
const clone = (value) => structuredClone(value)
/** @param {unknown} value @returns {value is Record<string, any>} */
const record = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value */
const id = (value) =>
  typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/u.test(value)
/** @param {unknown} value */
const opaqueId = id
/** @param {unknown} value */
const timestamp = (value) =>
  typeof value === 'string' &&
  Number.isFinite(Date.parse(value)) &&
  new Date(value).toISOString() === value
/** @param {unknown} value */
const safeLabel = (value) =>
  typeof value === 'string' &&
  value === value.trim() &&
  value.length > 0 &&
  value.length <= 120 &&
  !value.includes(String.fromCharCode(92)) &&
  !value.includes('/') &&
  !/[\u0000-\u001f]/u.test(value) &&
  !/^(?:[a-z]:|file:|https?:|%2f|%5c|%3a)/iu.test(value) &&
  !/\.(?:mp4|mov|mkv|avi|webm|wmv|m4v)(?:\b|$)/iu.test(value)
export const isReusableTemplateLabel = safeLabel

/** @param {unknown} value Keep a user-visible draft/video title, never a path. */
export const sanitizeReusableTemplateSourceLabel = (value) => {
  if (typeof value !== 'string') return null
  const cleaned = value
    .replace(/[\u0000-\u001f\\/:*?"<>|]+/gu, ' ')
    .replace(/\s+/gu, ' ')
    .trim()
    .slice(0, 120)
  return safeLabel(cleaned) ? cleaned : null
}
/** @param {unknown} value @param {string[]} keys @returns {value is Record<string, any>} */
const exact = (value, keys) =>
  record(value) &&
  Object.keys(value).sort().join('\u0000') === [...keys].sort().join('\u0000')

/**
 * The browser needs template facts, not the private blueprint credential used
 * by the controlled Jianying writer. Keep this deliberately narrower than the
 * persisted ReplicationRecipe: `source` contains provenance only.
 * @param {unknown} value
 */
export const isPublicReplicationRecipe = (value) =>
  record(value) &&
  exact(value, [
    'audioCues', 'canvas', 'capabilities', 'durationUs', 'packaging',
    'packagingSegments', 'schemaVersion', 'source', 'textSegments', 'videoSlots',
    'voiceProfileId',
  ]) &&
  value.schemaVersion === 1 &&
  record(value.source) &&
  exact(value.source, ['fidelity', 'kind']) &&
  templateSourceKinds.has(value.source.kind) &&
  ['structural', 'estimated'].includes(value.source.fidelity) &&
  Number.isSafeInteger(value.durationUs) && value.durationUs > 0 &&
  exact(value.canvas, ['height', 'width']) &&
  Number.isSafeInteger(value.canvas.width) && value.canvas.width > 0 &&
  Number.isSafeInteger(value.canvas.height) && value.canvas.height > 0 &&
  Array.isArray(value.videoSlots) &&
  Array.isArray(value.textSegments) &&
  Array.isArray(value.audioCues) &&
  Array.isArray(value.packagingSegments) &&
  exact(value.packaging, ['effectCount', 'flowerTextCount', 'stickerCount']) &&
  Array.isArray(value.capabilities) &&
  (value.voiceProfileId === null || opaqueId(value.voiceProfileId))

/**
 * Public projection of an internally validated recipe. Opaque asset and
 * packaging tokens are not useful to the browser and must not become replayable
 * capability inputs. This must only be called after isReplicationRecipe().
 * @param {Record<string, any>} recipe
 */
export const toPublicReplicationRecipe = (recipe) => ({
  schemaVersion: recipe.schemaVersion,
  source: { kind: recipe.source.kind, fidelity: recipe.source.fidelity },
  durationUs: recipe.durationUs,
  canvas: clone(recipe.canvas),
  videoSlots: clone(recipe.videoSlots),
  textSegments: recipe.textSegments.map((/** @type {Record<string, any>} */ segment) => {
    const { packagingToken: _packagingToken, ...safe } = segment
    return safe
  }),
  audioCues: recipe.audioCues.map((/** @type {Record<string, any>} */ { audioToken: _audioToken, ...safe }) => safe),
  packaging: clone(recipe.packaging),
  packagingSegments: Array.isArray(recipe.packagingSegments)
    ? recipe.packagingSegments.map(({ packagingToken: _packagingToken, ...safe }) => safe)
    : [],
  voiceProfileId: recipe.voiceProfileId ?? null,
  capabilities: clone(recipe.capabilities),
})
/** @param {unknown} value */
const validCaptionCadence = (value) => {
  if (!record(value) || !captionModes.has(value.mode)) return false
  const keys = Object.keys(value).sort().join('\u0000')
  if (keys === 'mode') return true
  if (keys !== ['cards_per_minute', 'max_chars_per_card', 'mode'].join('\u0000')) return false
  if (
    !Number.isSafeInteger(value.max_chars_per_card) ||
    !Number.isSafeInteger(value.cards_per_minute)
  ) return false
  return value.mode === 'none'
    ? value.max_chars_per_card === 0 && value.cards_per_minute === 0
    : value.max_chars_per_card >= 1 &&
      value.max_chars_per_card <= 200 &&
      value.cards_per_minute >= 1 &&
      value.cards_per_minute <= 240
}
/** @param {unknown} value */
const validPackaging = (value) =>
  exact(value, ['intro', 'outro', 'subtitle_style']) &&
  packagingCards.has(value.intro) &&
  packagingCards.has(value.outro) &&
  subtitleStyles.has(value.subtitle_style)
/** @param {unknown} value */
const validAudioEmphasis = (value) =>
  Array.isArray(value) &&
  value.every((entry) =>
    exact(entry, ['kind', 'position_ratio_ppm']) &&
    Number.isSafeInteger(entry.position_ratio_ppm) &&
    entry.position_ratio_ppm >= 0 &&
    entry.position_ratio_ppm <= 1_000_000 &&
    audioEmphasisKinds.has(entry.kind))
/** @param {unknown} value @param {string} pacing */
const validRules = (value, pacing) => {
  if (!record(value)) return false
  const keys = Object.keys(value)
  if (
    !keys.includes('pacing') ||
    !keys.includes('caption_cadence') ||
    keys.some((key) => !['audio_emphasis', 'caption_cadence', 'packaging', 'pacing'].includes(key))
  ) return false
  return value.pacing === pacing &&
    pacingValues.has(value.pacing) &&
    validCaptionCadence(value.caption_cadence) &&
    (value.audio_emphasis === undefined || validAudioEmphasis(value.audio_emphasis)) &&
    (value.packaging === undefined || validPackaging(value.packaging))
}
/** @param {unknown} value */
const validBaseTemplateRef = (value) =>
  exact(value, ['template_id', 'version']) &&
  id(value.template_id) &&
  Number.isSafeInteger(value.version) &&
  value.version >= 1
/** @param {unknown} value @param {number} targetDurationMs */
const validSlots = (value, targetDurationMs) => {
  if (!Array.isArray(value) || value.length < 1 || value.length > 30) return false
  const slotIds = new Set()
  let durationTotal = 0
  let ratioTotal = 0
  const valid = value.every((slot, index) => {
    const baseKeys = [
      'duration_ratio_ppm',
      'order',
      'recommended_duration_ms',
      'role',
      'slot_id',
      'transition_out',
    ]
    if (
      !record(slot) ||
      !(exact(slot, baseKeys) || exact(slot, [...baseKeys, 'evidence_shot_ids'])) ||
      !id(slot.slot_id) ||
      slotIds.has(slot.slot_id) ||
      slot.order !== index + 1 ||
      !slotRoles.has(slot.role) ||
      !Number.isSafeInteger(slot.duration_ratio_ppm) ||
      slot.duration_ratio_ppm < 1 ||
      !Number.isSafeInteger(slot.recommended_duration_ms) ||
      slot.recommended_duration_ms < 1 ||
      !transitions.has(slot.transition_out) ||
      (index === value.length - 1
        ? slot.transition_out !== 'none'
        : slot.transition_out === 'none') ||
      (
        slot.evidence_shot_ids !== undefined &&
        (
          !Array.isArray(slot.evidence_shot_ids) ||
          slot.evidence_shot_ids.length < 1 ||
          new Set(slot.evidence_shot_ids).size !== slot.evidence_shot_ids.length ||
          !slot.evidence_shot_ids.every(id)
        )
      )
    ) return false
    slotIds.add(slot.slot_id)
    durationTotal += slot.recommended_duration_ms
    ratioTotal += slot.duration_ratio_ppm
    return true
  })
  return valid && durationTotal === targetDurationMs && ratioTotal === 1_000_000
}
/** @param {unknown} value @returns {boolean} */
const containsPrivateData = (value) => {
  if (typeof value === 'string') {
    const backslash = String.fromCharCode(92)
    const lower = value.toLowerCase()
    const windowsDrive =
      value.length >= 3 &&
      /[a-z]/iu.test(value[0]) &&
      value[1] === ':' &&
      (value[2] === backslash || value[2] === '/')
    return windowsDrive ||
      lower.includes(`file:${'/'.repeat(2)}`) ||
      ['home', 'users', 'private', 'var', 'tmp', 'mnt', 'volumes'].some(
        (segment) => lower.includes(`/${segment}/`),
      )
  }
  if (Array.isArray(value)) return value.some(containsPrivateData)
  if (!record(value)) return false
  return Object.entries(value).some(([key, entry]) =>
    /(?:^|_)(?:path|transcript|media|media_content|thumbnail|provider|credential|secret|token)(?:_|$)/iu.test(key) ||
    containsPrivateData(entry))
}

/**
 * @param {{
 *   canvas?: { width?: number, height?: number } | null,
 *   durationUs?: number,
 *   slotCount?: number,
 * }} input
 */
export const deriveTemplateProfileFromSource = ({
  canvas,
  durationUs,
  slotCount,
}) => {
  const width = Number(canvas?.width)
  const height = Number(canvas?.height)
  const orientation = Number.isFinite(width) && Number.isFinite(height) && width > 0 && height > 0
    ? (width > height * 1.15 ? 'landscape' : height > width * 1.15 ? 'portrait' : 'square')
    : 'portrait'
  const safeDurationUs = typeof durationUs === 'number' && Number.isSafeInteger(durationUs) && durationUs > 0
    ? durationUs
    : 30_000_000
  const targetDurationSeconds = Math.max(1, Math.min(180, Math.round(safeDurationUs / 1_000_000)))
  const minutes = Math.max(safeDurationUs / 60_000_000, 1 / 60)
  const cutsPerMinute = (typeof slotCount === 'number' && Number.isSafeInteger(slotCount) ? slotCount : 0) / minutes
  const pacing = cutsPerMinute >= 8 ? 'dynamic' : cutsPerMinute <= 3 ? 'calm' : 'balanced'
  return { orientation, pacing, targetDurationSeconds }
}

export class ReusableTemplateContractError extends Error {
  /** @param {string} code @param {number} [status] */
  constructor(code = 'REUSABLE_TEMPLATE_CONTRACT_INVALID', status = 500) {
    super(code)
    this.name = 'ReusableTemplateContractError'
    this.code = code
    this.status = status
  }
}

/** @param {any} value */
export const isReusableTemplateCreateCommand = (value) => {
  if (!record(value)) return false
  const allowed = new Set([
    'audioPolicy',
    'label',
    'orientation',
    'pacing',
    'referenceAuthorizationId',
    'sourceAuthorizationId',
    'sourceKind',
    'targetDurationSeconds',
  ])
  if (Object.keys(value).some((key) => !allowed.has(key))) return false
  const hasLegacy = id(value.referenceAuthorizationId)
  const hasSource = id(value.sourceAuthorizationId) && templateSourceKinds.has(value.sourceKind)
  if (hasLegacy === hasSource) return false
  if (value.audioPolicy !== undefined &&
    !(value.sourceKind === 'video_analysis' &&
      (value.audioPolicy === 'analyze_only' || value.audioPolicy === 'reuse_as_bgm'))) {
    return false
  }
  if (value.label !== undefined && !safeLabel(value.label)) return false
  if (value.orientation !== undefined && !orientations.has(value.orientation)) return false
  if (value.pacing !== undefined && !pacingValues.has(value.pacing)) return false
  if (value.targetDurationSeconds !== undefined &&
    (!Number.isSafeInteger(value.targetDurationSeconds) ||
      value.targetDurationSeconds < 1 ||
      value.targetDurationSeconds > 180)) {
    return false
  }
  if (hasLegacy) {
    return safeLabel(value.label) &&
      orientations.has(value.orientation) &&
      pacingValues.has(value.pacing) &&
      Number.isSafeInteger(value.targetDurationSeconds) &&
      value.sourceKind === undefined &&
      value.sourceAuthorizationId === undefined &&
      value.audioPolicy === undefined
  }
  return true
}

/** @param {unknown} generated */
export const isReusableTemplateArtifact = (generated) =>
  record(generated) &&
  exact(generated, [
    'adapterRequest',
    'analysis',
    'draft',
    'preflight',
    'templateSelectionRequest',
  ]) &&
  record(generated.templateSelectionRequest) &&
  record(generated.adapterRequest) &&
  record(generated.analysis) &&
  record(generated.draft) &&
  record(generated.preflight) &&
  generated.preflight.ready === true &&
  orientations.has(generated.templateSelectionRequest.orientation) &&
  pacingValues.has(generated.templateSelectionRequest.pacing) &&
  Number.isSafeInteger(generated.templateSelectionRequest.target_duration_seconds) &&
  generated.templateSelectionRequest.target_duration_seconds >= 1 &&
  generated.templateSelectionRequest.target_duration_seconds <= 180 &&
  Number.isSafeInteger(generated.draft.target_duration_ms) &&
  generated.draft.target_duration_ms ===
    generated.templateSelectionRequest.target_duration_seconds * 1_000 &&
  validBaseTemplateRef(generated.draft.base_template_ref) &&
  validSlots(generated.draft.slots, generated.draft.target_duration_ms) &&
  validRules(generated.draft.rules, generated.templateSelectionRequest.pacing)

/** @param {Record<string, any>} generated */
export const reusableTemplateFingerprint = (generated) => {
  if (!isReusableTemplateArtifact(generated)) throw new ReusableTemplateContractError()
  const draft = generated.draft
  const canonical = {
    baseTemplate: draft.base_template_ref,
    orientation: generated.templateSelectionRequest.orientation,
    pacing: generated.templateSelectionRequest.pacing,
    targetDurationSeconds: generated.templateSelectionRequest.target_duration_seconds,
    slots: Array.isArray(draft.slots)
      ? draft.slots.map((/** @type {Record<string, any>} */ slot) => ({
          order: slot.order,
          role: slot.role,
          durationRatioPpm: slot.duration_ratio_ppm,
          recommendedDurationMs: slot.recommended_duration_ms,
          transitionOut: slot.transition_out,
        }))
      : [],
    rules: draft.rules,
  }
  return createHash('sha256').update(JSON.stringify(canonical)).digest('hex')
}

/** @param {Record<string, any>} binding */
export const projectTemplateBindingFingerprint = (binding) => {
  const draft = binding?.draft
  if (
    !record(binding) ||
    !record(draft) ||
    !Array.isArray(draft.slots) ||
    !record(draft.rules)
  ) return null
  const canonical = {
    baseTemplate: draft.baseTemplateRef,
    orientation: binding.orientation,
    pacing: binding.pacing,
    targetDurationSeconds: binding.targetDurationSeconds,
    slots: draft.slots.map((/** @type {Record<string, any>} */ slot) => ({
      order: slot.order,
      role: slot.role,
      durationRatioPpm: slot.duration_ratio_ppm,
      recommendedDurationMs: slot.recommended_duration_ms,
      transitionOut: slot.transition_out,
    })),
    rules: draft.rules,
    ...(Array.isArray(binding.blendSources)
      ? {
          blendSources: binding.blendSources.map((source) => ({
            libraryTemplateId: source.libraryTemplateId,
            revision: source.revision,
            fingerprint: source.fingerprint,
          })),
        }
      : {}),
  }
  return createHash('sha256').update(JSON.stringify(canonical)).digest('hex')
}

/** @param {Record<string, any>} generated */
export const summarizeReusableTemplateArtifact = (generated) => {
  if (!isReusableTemplateArtifact(generated)) throw new ReusableTemplateContractError()
  const slots = Array.isArray(generated.draft.slots) ? generated.draft.slots : []
  const captionMode = generated.draft.rules?.caption_cadence?.mode
  return {
    draftSummary: {
      draftId: generated.draft.draft_id,
      slotCount: slots.length,
    },
    rulesSummary: {
      captionMode: typeof captionMode === 'string' ? captionMode : 'none',
      transitionCount: slots.filter(
        (/** @type {Record<string, any>} */ slot) => slot.transition_out !== 'none',
      ).length,
    },
  }
}

/** @param {any} value */
export const isReusableTemplatePublicSummary = (value) =>
  exact(value, publicKeys) &&
  typeof value.bindable === 'boolean' &&
  ['current', 'legacy_read_only'].includes(value.compatibility) &&
  id(value.libraryTemplateId) &&
  safeLabel(value.label) &&
  statuses.has(value.status) &&
  Number.isSafeInteger(value.revision) &&
  value.revision >= 1 &&
  typeof value.fingerprint === 'string' &&
  /^[a-f0-9]{64}$/u.test(value.fingerprint) &&
  orientations.has(value.orientation) &&
  pacingValues.has(value.pacing) &&
  Number.isSafeInteger(value.targetDurationSeconds) &&
  value.targetDurationSeconds >= 1 &&
  value.targetDurationSeconds <= 180 &&
  exact(value.draftSummary, ['draftId', 'slotCount']) &&
  id(value.draftSummary.draftId) &&
  Number.isSafeInteger(value.draftSummary.slotCount) &&
  value.draftSummary.slotCount >= 1 &&
  exact(value.rulesSummary, ['captionMode', 'transitionCount']) &&
  ['none', 'steady', 'burst'].includes(value.rulesSummary.captionMode) &&
  Number.isSafeInteger(value.rulesSummary.transitionCount) &&
  value.rulesSummary.transitionCount >= 0 &&
  isStyleSummary(value.styleSummary) &&
  (value.replicationRecipe === null || isPublicReplicationRecipe(value.replicationRecipe)) &&
  isPreviewAvailability(value.previewAvailability) &&
  value.bindable === (
    value.compatibility === 'current' &&
    value.status === 'approved' &&
    value.previewAvailability.demoPlayable === true &&
    value.previewAvailability.demoAuthentic === true &&
    value.previewAvailability.styleAnalysisComplete === true &&
    value.previewAvailability.approveReady === true &&
    isPublicReplicationRecipe(value.replicationRecipe)
  ) &&
  timestamp(value.createdAt) &&
  timestamp(value.updatedAt)

/** @param {unknown} value */
export const isReusableTemplatePublicDetail = isReusableTemplatePublicSummary

/** @param {unknown} value */
export const assertReusableTemplatePublicDetail = (value) => {
  if (!isReusableTemplatePublicDetail(value)) throw new ReusableTemplateContractError()
  return clone(/** @type {Record<string, any>} */ (value))
}

/**
 * @param {Record<string, any>} stored
 * @param {{
 *   previewAvailability?: Record<string, any>,
 *   styleSummary?: Record<string, any>,
 *   replicationRecipe?: Record<string, any> | null,
 *   recipeIdentityVerified?: boolean,
 *   recipeIdentityVerificationAttempted?: boolean,
 * }} [options]
 */
export const toReusableTemplatePublicDetail = (stored, options = {}) => {
  let styleSummary = options.styleSummary
  if (!styleSummary) {
    if (record(stored.artifact)) {
      styleSummary = buildStyleSummaryFromArtifact(stored.artifact, {
        analysisComplete: false,
      })
    } else {
      styleSummary = {
        schemaVersion: 4,
        analyzerVersion: 'unavailable',
        analysisComplete: false,
        editing: {
          detected: false,
          confidence: 0,
          evidenceRanges: [],
          previewStatus: 'unavailable',
          jianyingStatus: 'unavailable',
          slotCount: Number(stored.draftSummary?.slotCount) || 0,
          transitionCount: Number(stored.rulesSummary?.transitionCount) || 0,
          pacing: stored.pacing || 'balanced',
          roles: [],
        },
        visual: {
          detected: false,
          confidence: 0,
          evidenceRanges: [],
          previewStatus: 'unavailable',
          jianyingStatus: 'unavailable',
          palette: [],
          brightnessLabel: null,
          contrastLabel: null,
          saturationLabel: null,
          colorTempLabel: null,
          motionLabel: null,
          frameFingerprints: [],
        },
        text: {
          detected: false,
          confidence: 0,
          evidenceRanges: [],
          previewStatus: 'unavailable',
          jianyingStatus: 'unavailable',
          captionMode: stored.rulesSummary?.captionMode || 'none',
          titleCard: false,
          subtitleStyle: 'default',
          ocrSamples: [],
        },
        packaging: {
          detected: false,
          confidence: 0,
          evidenceRanges: [],
          previewStatus: 'unavailable',
          jianyingStatus: 'unavailable',
          intro: 'none',
          outro: 'none',
        },
        audio: {
          detected: false,
          confidence: 0,
          evidenceRanges: [],
          previewStatus: 'unavailable',
          jianyingStatus: 'unavailable',
          emphasisCount: 0,
          voiceStyle: null,
          speechRateLabel: null,
          bgmBpm: null,
          cloneForbidden: true,
        },
        templateDemoCapabilities: [
          { id: 'transition.cut', status: 'unsupported' },
          { id: 'text.rich', status: 'unsupported', note: '花字尚未真实写入' },
        ],
      }
    }
  }
  styleSummary = normalizeStyleSummary(styleSummary) || styleSummary
  const previewAvailability = /** @type {Record<string, any>} */ (
    options.previewAvailability ?? {
      referencePlayable: false,
      demoPlayable: false,
      demoStatus: 'unavailable',
      demoRenderer: null,
      demoAuthentic: false,
      demoMeaningful: false,
      demoAppliedCapabilities: [],
      styleAnalysisComplete: false,
      approveReady: false,
    }
  )
  const verifiedReplicationRecipe = isReplicationRecipe(options.replicationRecipe)
    ? clone(options.replicationRecipe)
    : null
  const recipeReady = verifiedReplicationRecipe !== null && options.recipeIdentityVerified === true
  const replicationRecipe = verifiedReplicationRecipe &&
    (recipeReady || options.recipeIdentityVerificationAttempted === true)
    ? toPublicReplicationRecipe(/** @type {Record<string, any>} */ (verifiedReplicationRecipe))
    : null
  const meaningfulVideoEvidence = hasMeaningfulVideoLearningEvidence(replicationRecipe ?? null, styleSummary)
  const truthfulPreviewAvailability = /** @type {Record<string, any>} */ ({
    ...clone(previewAvailability),
    approveReady: previewAvailability.approveReady === true && recipeReady && meaningfulVideoEvidence,
  })
  if (
    authoredJianyingDraftHasVerifiableLook(replicationRecipe) &&
    truthfulPreviewAvailability.referencePlayable === true
  ) {
    truthfulPreviewAvailability.demoMeaningful = true
  }
  return assertReusableTemplatePublicDetail({
    libraryTemplateId: stored.libraryTemplateId,
    bindable: stored.contractVersion === 2 &&
      stored.status === 'approved' &&
      truthfulPreviewAvailability.demoPlayable === true &&
      truthfulPreviewAvailability.demoAuthentic === true &&
      truthfulPreviewAvailability.styleAnalysisComplete === true &&
      truthfulPreviewAvailability.approveReady === true &&
      recipeReady,
    compatibility: stored.contractVersion === 2 ? 'current' : 'legacy_read_only',
    label: stored.label,
    status: stored.status,
    revision: stored.revision,
    fingerprint: stored.fingerprint,
    orientation: stored.orientation,
    targetDurationSeconds: stored.targetDurationSeconds,
    pacing: stored.pacing,
    draftSummary: clone(stored.draftSummary),
    rulesSummary: clone(stored.rulesSummary),
    styleSummary: clone(styleSummary),
    replicationRecipe,
    previewAvailability: truthfulPreviewAvailability,
    createdAt: stored.createdAt,
    updatedAt: stored.updatedAt,
  })
}

/** @param {unknown} value */
export const isProjectTemplateBinding = (value) => {
  if (
    !exact(value, projectBindingKeys) &&
    !exact(value, blendedProjectBindingKeys) &&
    !exact(value, legacyRecipeProjectBindingKeys) &&
    !exact(value, styleOnlyProjectBindingKeys) &&
    !exact(value, legacyProjectBindingKeys)
  ) return false
  const binding = /** @type {Record<string, any>} */ (value)
  const draft = binding.draft
  // Bindings saved before the project-binding fingerprint was introduced may
  // carry the library artifact fingerprint instead.  They remain read-only:
  // their unsealed recipe is never eligible for execution (see
  // template-binding-consumption), while the complete structural and private
  // data checks below still apply.
  const legacyUnsealedRecipeBinding =
    exact(binding, legacyRecipeProjectBindingKeys) &&
    binding.replicationRecipe !== undefined &&
    binding.replicationRecipeFingerprint === undefined
  return (
    id(binding.libraryTemplateId) &&
    safeLabel(binding.label) &&
    Number.isSafeInteger(binding.revision) &&
    binding.revision >= 1 &&
    typeof binding.fingerprint === 'string' &&
    /^[a-f0-9]{64}$/u.test(binding.fingerprint) &&
    orientations.has(binding.orientation) &&
    pacingValues.has(binding.pacing) &&
    Number.isSafeInteger(binding.targetDurationSeconds) &&
    binding.targetDurationSeconds >= 1 &&
    binding.targetDurationSeconds <= 180 &&
    exact(draft, projectBindingDraftKeys) &&
    id(draft.draftId) &&
    validBaseTemplateRef(draft.baseTemplateRef) &&
    Number.isSafeInteger(draft.targetDurationMs) &&
    draft.targetDurationMs >= 1_000 &&
    draft.targetDurationMs <= 180_000 &&
    draft.targetDurationMs === binding.targetDurationSeconds * 1_000 &&
    validSlots(draft.slots, draft.targetDurationMs) &&
    validRules(draft.rules, binding.pacing) &&
    (
      binding.styleProfile === undefined ||
      isStyleSummary(binding.styleProfile)
    ) &&
    (
      binding.replicationRecipe === undefined ||
      isReplicationRecipe(binding.replicationRecipe)
    ) &&
    (
      binding.replicationRecipeFingerprint === undefined ||
      (
        typeof binding.replicationRecipeFingerprint === 'string' &&
        /^[a-f0-9]{64}$/u.test(binding.replicationRecipeFingerprint) &&
        isReplicationRecipe(binding.replicationRecipe) &&
        binding.replicationRecipeFingerprint ===
          replicationRecipeFingerprint(binding.replicationRecipe)
      )
    ) &&
    (
      binding.blendSources === undefined ||
      (
        Array.isArray(binding.blendSources) &&
        binding.blendSources.length === 1 &&
        binding.blendSources.every((source) =>
          exact(source, ['fingerprint', 'label', 'libraryTemplateId', 'revision']) &&
          id(source.libraryTemplateId) &&
          source.libraryTemplateId !== binding.libraryTemplateId &&
          safeLabel(source.label) &&
          Number.isSafeInteger(source.revision) &&
          source.revision >= 1 &&
          typeof source.fingerprint === 'string' &&
          /^[a-f0-9]{64}$/u.test(source.fingerprint))
      )
    ) &&
    JSON.stringify(draft).length <= 100_000 &&
    (
      binding.fingerprint === projectTemplateBindingFingerprint(binding) ||
      legacyUnsealedRecipeBinding
    ) &&
    !containsPrivateData(binding)
  )
}

/** @param {Record<string, any>} stored */
export const createProjectTemplateBinding = (stored) => {
  const sourceDraft = stored?.artifact?.draft
  if (
    stored?.status !== 'approved' ||
    typeof stored?.fingerprint !== 'string' ||
    !/^[a-f0-9]{64}$/u.test(stored.fingerprint) ||
    !record(sourceDraft)
  ) {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_NOT_APPROVED', 409)
  }
  const analyzed = normalizeStyleSummary(stored.styleSummary)
  const styleProfile = analyzed && analyzed.analysisComplete === true
    ? analyzed
    : buildStyleSummaryFromArtifact({
      draft: {
        slots: sourceDraft.slots,
        rules: sourceDraft.rules,
      },
      analysis: record(stored.artifact?.analysis) ? stored.artifact.analysis : {},
    }, {
      analysisComplete: false,
    })
  const draft = {
    draftId: sourceDraft.draft_id,
    baseTemplateRef: clone(sourceDraft.base_template_ref),
    targetDurationMs: sourceDraft.target_duration_ms,
    slots: clone(sourceDraft.slots),
    rules: clone(sourceDraft.rules),
  }
  const recipe = isReplicationRecipe(stored.replicationRecipe)
    ? clone(stored.replicationRecipe)
    : null
  const recipeFingerprint = recipe ? replicationRecipeFingerprint(recipe) : null
  if (
    recipe &&
    (
      typeof stored.approvedRecipeFingerprint !== 'string' ||
      stored.approvedRecipeFingerprint !== recipeFingerprint
    )
  ) {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_RECIPE_CHANGED', 409)
  }
  // The template library fingerprints the full approved artifact, whereas a
  // project binding derives its own fingerprint after any private recipe is attached.
  let artifactFingerprint
  try {
    artifactFingerprint = reusableTemplateFingerprint(stored.artifact)
  } catch {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_BINDING_INVALID', 500)
  }
  const bindingFingerprint = projectTemplateBindingFingerprint({
    orientation: stored.orientation,
    pacing: stored.pacing,
    targetDurationSeconds: stored.targetDurationSeconds,
    ...(recipe ? { replicationRecipe: recipe } : {}),
    draft: {
      baseTemplateRef: draft.baseTemplateRef,
      targetDurationMs: draft.targetDurationMs,
      slots: draft.slots,
      rules: draft.rules,
    },
  })
  if (
    typeof artifactFingerprint !== 'string' ||
    typeof bindingFingerprint !== 'string' ||
    (
      stored.fingerprint !== artifactFingerprint
    )
  ) {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_BINDING_INVALID', 500)
  }
  const binding = {
    libraryTemplateId: stored.libraryTemplateId,
    revision: stored.revision,
    fingerprint: bindingFingerprint,
    label: stored.label,
    orientation: stored.orientation,
    targetDurationSeconds: stored.targetDurationSeconds,
    pacing: stored.pacing,
    styleProfile,
    ...(recipe
      ? {
          replicationRecipe: recipe,
          replicationRecipeFingerprint: recipeFingerprint,
        }
      : {}),
    draft,
  }
  if (!isProjectTemplateBinding(binding)) {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_BINDING_INVALID', 500)
  }
  return clone(binding)
}

/**
 * Creates one immutable binding from a rhythm-owning primary template and one
 * visual companion. The companion cannot replace video timing or audio.
 * @param {Record<string, any>} primaryStored
 * @param {Record<string, any>} companionStored
 */
export const createBlendedProjectTemplateBinding = (primaryStored, companionStored) => {
  const primary = createProjectTemplateBinding(primaryStored)
  const companion = createProjectTemplateBinding(companionStored)
  if (
    primary.libraryTemplateId === companion.libraryTemplateId ||
    primary.orientation !== companion.orientation ||
    !isReplicationRecipe(primary.replicationRecipe) ||
    !isReplicationRecipe(companion.replicationRecipe)
  ) {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_BLEND_INCOMPATIBLE', 409)
  }
  const replicationRecipe = blendReplicationRecipeVisuals(
    primary.replicationRecipe,
    companion.replicationRecipe,
  )
  const blendSources = [{
    libraryTemplateId: companion.libraryTemplateId,
    revision: companion.revision,
    fingerprint: companionStored.fingerprint,
    label: companion.label,
  }]
  const binding = {
    ...primary,
    label: `${primary.label} + ${companion.label}`,
    blendSources,
    replicationRecipe,
    replicationRecipeFingerprint: replicationRecipeFingerprint(replicationRecipe),
  }
  const bindingFingerprint = projectTemplateBindingFingerprint(binding)
  if (typeof bindingFingerprint !== 'string') {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_BLEND_INVALID', 500)
  }
  binding.fingerprint = bindingFingerprint
  if (!isProjectTemplateBinding(binding)) {
    throw new ReusableTemplateContractError('REUSABLE_TEMPLATE_BLEND_INVALID', 500)
  }
  return clone(binding)
}
