import { isCreativeBeatIntent } from './creative-retrieval.mjs'
import { isSafeCreativeText } from './creative-text-safety.mjs'

const schemaVersion = 1
const maxRecipes = 5
const maxTerms = 10
const safeIdPattern = /^[A-Za-z0-9._:-]{1,180}$/u
const allowedStrategies = new Set(['basic_cut', 'basic_title', 'scene_order_and_hold'])
const dualOutputCapabilityIds = new Set([
  'transition.cut',
  'transition.none',
  'caption.basic',
  'caption.bottom_safe',
  'title.card',
  'audio.sfx.local',
])
const contextKeys = [
  'schema_version', 'sentence_id', 'beat_intent', 'recipes', 'search_terms',
  'desired_duration_us', 'realization',
]
const recipeKeys = [
  'recipe_id', 'shot_role', 'energy', 'duration_range_us', 'creative_intents',
  'required_asset_kinds', 'preferred_scene_attributes', 'avoid_conditions',
]
const realizationKeys = ['strategy', 'required_capability_ids', 'degradation_reason']

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
/** @param {unknown} value @param {string[]} keys @returns {value is Record<string, any>} */
const exactKeys = (value, keys) => isRecord(value) && Object.keys(value).length === keys.length &&
  keys.every((key) => Object.hasOwn(value, key))
/** @param {unknown} value @param {number} max */
const safeText = (value, max) => isSafeCreativeText(value, max, { trimmed: true })
/** @param {unknown} value @param {number} maxItems @param {number} maxLength */
const safeTextList = (value, maxItems, maxLength) => Array.isArray(value) &&
  value.length <= maxItems && new Set(value).size === value.length &&
  value.every((entry) => safeText(entry, maxLength))
/** @param {unknown} value @param {number} maxItems */
const safeIdList = (value, maxItems) => Array.isArray(value) && value.length <= maxItems &&
  new Set(value).size === value.length && value.every((entry) =>
    typeof entry === 'string' && safeIdPattern.test(entry))
/** @param {unknown} values @param {number} maxItems @param {number} maxLength */
const boundedSafeTextList = (values, maxItems, maxLength) => Array.isArray(values)
  ? [...new Set(values
      .map((value) => typeof value === 'string' ? value.trim() : '')
      .filter((value) => safeText(value, maxLength)))]
      .slice(0, maxItems)
  : []

/** @param {unknown} value */
const isRecipeContext = (value) => exactKeys(value, recipeKeys) &&
  typeof value.recipe_id === 'string' && /^shotcraft-v1-[a-z0-9-]{2,120}$/u.test(value.recipe_id) &&
  safeText(value.shot_role, 80) && ['low', 'medium', 'high'].includes(value.energy) &&
  exactKeys(value.duration_range_us, ['min_us', 'max_us']) &&
  Number.isSafeInteger(value.duration_range_us.min_us) && Number.isSafeInteger(value.duration_range_us.max_us) &&
  value.duration_range_us.min_us > 0 && value.duration_range_us.min_us <= value.duration_range_us.max_us &&
  safeTextList(value.creative_intents, 4, 80) &&
  safeTextList(value.required_asset_kinds, 4, 40) &&
  safeTextList(value.preferred_scene_attributes, 4, 80) &&
  safeTextList(value.avoid_conditions, 4, 120)

/** @param {unknown} value @returns {value is Record<string, any>} */
export const isCreativePlanningContext = (value) => exactKeys(value, contextKeys) &&
  value.schema_version === schemaVersion && typeof value.sentence_id === 'string' &&
  safeIdPattern.test(value.sentence_id) && isCreativeBeatIntent(value.beat_intent) &&
  Array.isArray(value.recipes) && value.recipes.length >= 3 && value.recipes.length <= maxRecipes &&
  value.recipes.every(isRecipeContext) &&
  new Set(value.recipes.map((recipe) => recipe.recipe_id)).size === value.recipes.length &&
  safeTextList(value.search_terms, maxTerms, 80) && value.search_terms.length > 0 &&
  Number.isSafeInteger(value.desired_duration_us) &&
  value.desired_duration_us >= 500_000 && value.desired_duration_us <= 30_000_000 &&
  exactKeys(value.realization, realizationKeys) && allowedStrategies.has(value.realization.strategy) &&
  safeIdList(value.realization.required_capability_ids, 3) &&
  (value.realization.degradation_reason === null || safeText(value.realization.degradation_reason, 120))

/** @param {unknown} capabilities */
export const allowedCreativeCapabilityIds = (capabilities) => {
  if (!Array.isArray(capabilities)) return Object.freeze([])
  return Object.freeze(capabilities
    .filter((entry) => isRecord(entry) &&
      dualOutputCapabilityIds.has(entry.capabilityId) &&
      entry.agentAuthorization === 'allowed' &&
      entry.effectiveStatus !== 'unsupported' &&
      entry.targets?.preview?.status !== 'unsupported' &&
      entry.targets?.jianying?.status !== 'unsupported')
    .map((entry) => entry.capabilityId)
    .filter((value, index, values) => values.indexOf(value) === index)
    .sort())
}

/** @param {string} role @param {Set<string>} capabilities */
const realizationFor = (role, capabilities) => {
  if (role === 'transition' && capabilities.has('transition.cut')) {
    return { strategy: 'basic_cut', required_capability_ids: ['transition.cut'], degradation_reason: null }
  }
  if (role === 'typography' && capabilities.has('title.card')) {
    return { strategy: 'basic_title', required_capability_ids: ['title.card'], degradation_reason: null }
  }
  return {
    strategy: 'scene_order_and_hold',
    required_capability_ids: [],
    degradation_reason: role === 'transition' || role === 'typography'
      ? 'preferred_capability_unavailable'
      : null,
  }
}

/** @param {string[]} values */
const boundedTerms = (values) => [...new Set(values
  .map((value) => typeof value === 'string' ? value.trim() : '')
  .filter((value) => safeText(value, 80)))]
  .slice(0, maxTerms)

/**
 * @param {{sentenceId: string, intent: Record<string, any>, recipes: Record<string, any>[], allowedCapabilityIds?: string[]}} input
 */
export const createCreativePlanningContext = ({
  sentenceId,
  intent,
  recipes,
  allowedCapabilityIds = [],
}) => {
  if (!safeIdPattern.test(sentenceId) || !isCreativeBeatIntent(intent) ||
      !Array.isArray(recipes) || recipes.length < 3 || recipes.length > maxRecipes) {
    throw new Error('CREATIVE_REALIZATION_INPUT_INVALID')
  }
  const capabilities = new Set(allowedCapabilityIds.filter((id) => dualOutputCapabilityIds.has(id)))
  const projectedRecipes = recipes.map((recipe) => ({
    recipe_id: recipe.recipeId,
    shot_role: recipe.shotRole,
    energy: recipe.energy,
    duration_range_us: {
      min_us: recipe.durationRangeUs?.minUs,
      max_us: recipe.durationRangeUs?.maxUs,
    },
    creative_intents: boundedSafeTextList(recipe.creativeIntents, 4, 80),
    required_asset_kinds: boundedSafeTextList(recipe.requiredAssetKinds, 4, 40),
    preferred_scene_attributes: boundedSafeTextList(recipe.preferredSceneAttributes, 4, 80),
    avoid_conditions: boundedSafeTextList(recipe.avoidConditions, 4, 120),
  }))
  const context = {
    schema_version: schemaVersion,
    sentence_id: sentenceId,
    beat_intent: structuredClone(intent),
    recipes: projectedRecipes,
    search_terms: boundedTerms([
      ...intent.intent_terms,
      ...projectedRecipes.flatMap((recipe) => recipe.preferred_scene_attributes),
      ...projectedRecipes.flatMap((recipe) => recipe.creative_intents),
    ]),
    desired_duration_us: intent.desired_duration_us,
    realization: realizationFor(intent.shot_role, capabilities),
  }
  if (!isCreativePlanningContext(context)) throw new Error('CREATIVE_REALIZATION_OUTPUT_INVALID')
  return Object.freeze(structuredClone(context))
}

/** @param {string} sentenceText @param {unknown} context @param {number} [maximumLength] */
export const createCreativeMaterialQuery = (sentenceText, context, maximumLength = 1_000) => {
  const normalizedSentenceText = typeof sentenceText === 'string'
    ? sentenceText.replace(/[\t\n\r]+/gu, ' ').trim()
    : sentenceText
  if (!safeText(normalizedSentenceText, maximumLength) || !isCreativePlanningContext(context)) {
    throw new Error('CREATIVE_MATERIAL_QUERY_INVALID')
  }
  const suffix = [
    `镜头意图:${context.beat_intent.shot_role}`,
    `画面要素:${context.search_terms.join('、')}`,
    `素材类型:${context.beat_intent.required_asset_kinds.join('、')}`,
  ].join('；')
  const available = maximumLength - normalizedSentenceText.length - 1
  if (available <= 0) return normalizedSentenceText.slice(0, maximumLength)
  return `${normalizedSentenceText}\n${suffix.slice(0, available)}`
}

export const creativeRealizationPolicyContract = Object.freeze({
  schemaVersion,
  maxRecipes,
  maxTerms,
  dualOutputCapabilityIds: Object.freeze([...dualOutputCapabilityIds].sort()),
})
