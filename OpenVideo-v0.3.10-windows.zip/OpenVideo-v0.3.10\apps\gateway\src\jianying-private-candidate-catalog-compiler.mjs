import { execFile } from 'node:child_process'
import { createRequire } from 'node:module'
import { promisify } from 'node:util'

import {
  PACKAGING_RESOURCE_FAMILIES,
  assertBoundedPrivatePackagingValue,
  assertSafePackagingText,
  computePackagingCatalogFingerprint,
  normalizeJianyingDesktopBinding,
  parsePrivatePackagingResourceIndex,
  serializePrivatePackagingResourceIndex,
} from './jianying-packaging-resource-index.mjs'
import { inspectPyJianyingUpstream } from './jianying-local-environment.mjs'

const runExecFile = promisify(execFile)
const require = createRequire(import.meta.url)
const pyJianYingDraftUpstreamManifest = require('../../../config/pyjianyingdraft-upstream.json')
const metadataKind = 'jy149_pyjianyingdraft_packaging_metadata'
export const pinnedPyJianYingDraftCommit = 'c3318066d964744e2bfc66f75c71745fe8cea52a'
const PY_METADATA_PROBE_TIMEOUT_MS = 7_000
const pyJianYingDraftFamilyAliases = {
  flower: ['TextEffectType'],
  bubble: ['TextShapeType', 'BubbleType', 'TextBubbleType'],
  sticker: ['StickerType'],
  filter: ['FilterType'],
  video_effect: ['EffectType', 'VideoEffectType', 'VideoSceneEffectType', 'VideoCharacterEffectType'],
  video_animation: ['IntroType', 'OutroType', 'GroupAnimationType'],
  mask: ['MaskType'],
  blend: ['MixModeType'],
  transition: ['TransitionType'],
  audio_effect: ['AudioEffectType', 'AudioSceneEffectType', 'ToneEffectType', 'SpeechToSongType'],
  text_animation: ['TextAnimationType', 'TextIntro', 'TextOutro', 'TextLoopAnim'],
  bgm: ['BgmType', 'MusicType'],
  sfx: ['SoundEffectType', 'SfxType'],
}

const familySet = new Set(PACKAGING_RESOURCE_FAMILIES)

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/** @param {unknown} value */
const safeTags = (value) => {
  if (!Array.isArray(value)) return []
  const accepted = []
  for (const raw of value) {
    try {
      accepted.push(assertSafePackagingText(raw, 'catalog_tag', 48))
    } catch {
      // Ignore unsafe metadata tags instead of letting one bad tag drop a candidate.
    }
  }
  return [...new Set(accepted)].slice(0, 16)
}

/** @param {string} family @param {Record<string, any>} binding */
const bindingIdentity = (family, binding) => {
  const resourceId = typeof binding.resourceId === 'string' ? binding.resourceId : null
  if (!familySet.has(family) || !resourceId) return null
  if (family === 'flower' || family === 'bubble') {
    return typeof binding.effectId === 'string' ? `${family}\u0000${resourceId}\u0000${binding.effectId}` : null
  }
  if (family === 'video_effect') {
    return typeof binding.effectId === 'string' && ['scene', 'character', 'generic'].includes(binding.entity)
      ? `${family}\u0000${binding.entity}\u0000${resourceId}\u0000${binding.effectId}`
      : null
  }
  return `${family}\u0000${resourceId}`
}

/** @param {string} family @param {Record<string, any>} localBinding @param {Record<string, any>} metadataBinding */
const privateBindingMatches = (family, localBinding, metadataBinding) => {
  if (bindingIdentity(family, localBinding) !== bindingIdentity(family, metadataBinding)) return false
  if (family === 'video_animation') return localBinding?.durationUs === metadataBinding?.durationUs
  if (family === 'mask') return JSON.stringify(localBinding?.commonMaskTemplate) === JSON.stringify(metadataBinding?.commonMaskTemplate)
  return true
}

/** @param {Record<string, any>} entry */
const normalizeMetadataBinding = (entry) => {
  if (isRecord(entry.private_binding)) return structuredClone(entry.private_binding)
  const resourceId = entry.resource_id ?? entry.resourceId
  if (typeof resourceId !== 'string') return null
  /** @type {Record<string, any>} */
  const binding = { resourceId }
  const effectId = entry.effect_id ?? entry.effectId
  if (typeof effectId === 'string') binding.effectId = effectId
  const durationUs = Number(entry.duration_us ?? entry.durationUs)
  if (Number.isSafeInteger(durationUs) && durationUs > 0) binding.durationUs = durationUs
  const commonMaskTemplate = entry.common_mask_template ?? entry.commonMaskTemplate
  if (isRecord(commonMaskTemplate)) binding.commonMaskTemplate = structuredClone(commonMaskTemplate)
  return binding
}

/** @param {unknown} snapshot */
export const parsePyJianYingDraftPackagingMetadataSnapshot = (snapshot) => {
  if (
    !isRecord(snapshot) ||
    snapshot.schema_version !== 1 ||
    snapshot.kind !== metadataKind ||
    snapshot.source !== 'pyjianyingdraft-metadata' ||
    snapshot.upstream_commit !== pinnedPyJianYingDraftCommit ||
    !Array.isArray(snapshot.entries)
  ) {
    throw new Error('JY149_METADATA_SNAPSHOT_INVALID')
  }
  const entries = snapshot.entries.map((entry, index) => {
    if (!isRecord(entry) || typeof entry.family !== 'string' || !familySet.has(entry.family)) {
      throw new Error('JY149_METADATA_ENTRY_INVALID')
    }
    const privateBinding = normalizeMetadataBinding(entry)
    if (!privateBinding) throw new Error('JY149_METADATA_ENTRY_INVALID')
    assertBoundedPrivatePackagingValue(privateBinding)
    const label = assertSafePackagingText(
      entry.label ?? entry.display_name ?? entry.name ?? `${entry.family} ${index + 1}`,
      'catalog_label',
      160,
    )
    const parameterSchema = isRecord(entry.parameter_schema)
      ? assertBoundedPrivatePackagingValue(structuredClone(entry.parameter_schema))
      : {}
    return Object.freeze({
      family: entry.family,
      label,
      tags: Object.freeze(safeTags(entry.tags)),
      parameter_schema: /** @type {Record<string, any>} */ (structuredClone(parameterSchema)),
      private_binding: structuredClone(privateBinding),
      identity: bindingIdentity(entry.family, privateBinding),
    })
  })
  if (entries.some((entry) => typeof entry.identity !== 'string')) {
    throw new Error('JY149_METADATA_ENTRY_INVALID')
  }
  return Object.freeze({
    schemaVersion: 1,
    kind: metadataKind,
    upstreamCommit: pinnedPyJianYingDraftCommit,
    entries: Object.freeze(entries),
  })
}

/**
 * Load a bounded private metadata snapshot from the pinned pyJianYingDraft
 * module. The snapshot stays server-private and must never be returned to a
 * browser or model prompt without later catalog projection.
 * @param {{
 *   moduleRoot: string,
 *   pythonExecutable?: string,
 *   execFileImpl?: typeof runExecFile,
 *   inspectUpstream?: typeof inspectPyJianyingUpstream,
 *   upstreamManifest?: unknown,
 * }} input
 */
export const loadPyJianYingDraftPackagingMetadataSnapshot = async ({
  moduleRoot,
  pythonExecutable = 'python',
  execFileImpl = runExecFile,
  inspectUpstream = inspectPyJianyingUpstream,
  upstreamManifest = pyJianYingDraftUpstreamManifest,
}) => {
  if (typeof moduleRoot !== 'string' || moduleRoot.trim().length === 0) throw new Error('JY149_METADATA_MODULE_ROOT_REQUIRED')
  await inspectUpstream({
    upstreamRoot: moduleRoot,
    manifest: upstreamManifest,
  })
  const script = [
    'import json',
    'import pyJianYingDraft as d',
    `FAMILIES = ${JSON.stringify(pyJianYingDraftFamilyAliases)}`,
    'entries = []',
    'seen = set()',
    'for family, aliases in FAMILIES.items():',
    '  for alias in aliases:',
    '    enum_value = getattr(d, alias, None)',
    '    if enum_value is None:',
    '      continue',
    '    try:',
    '      members = list(enum_value)',
    '    except Exception:',
    '      continue',
    '    for member in members:',
    '      value = getattr(member, "value", None)',
    '      payload = getattr(value, "__dict__", {}) if value is not None else {}',
    '      resource_id = payload.get("resource_id")',
    '      if not isinstance(resource_id, str) or not resource_id:',
    '        continue',
    '      effect_id = payload.get("effect_id") if family in ("flower", "bubble", "video_effect") else None',
    '      entity = "scene" if alias == "VideoSceneEffectType" else ("character" if alias in ("VideoCharacterEffectType", "FaceEffectType") else ("generic" if family == "video_effect" else None))',
    '      identity = (family, entity or "", resource_id, effect_id if isinstance(effect_id, str) else "")',
    '      if identity in seen:',
    '        continue',
    '      seen.add(identity)',
    '      label = payload.get("title") or payload.get("name") or getattr(member, "name", family)',
    '      binding = {"resourceId": resource_id}',
    '      if isinstance(effect_id, str) and effect_id:',
    '        binding["effectId"] = effect_id',
    '      if isinstance(entity, str):',
    '        binding["entity"] = entity',
    '      duration = payload.get("duration_us", payload.get("duration"))',
    '      if isinstance(duration, int) and duration > 0:',
    '        binding["durationUs"] = duration',
    '      common_mask_template = payload.get("common_mask_template")',
    '      if isinstance(common_mask_template, dict):',
    '        binding["commonMaskTemplate"] = common_mask_template',
    '      entries.append({"family": family, "label": str(label), "private_binding": binding})',
    `print(json.dumps({"schema_version": 1, "kind": "${metadataKind}", "source": "pyjianyingdraft-metadata", "upstream_commit": "${pinnedPyJianYingDraftCommit}", "entries": entries}, ensure_ascii=False))`,
  ].join('\n')
  const { stdout } = await execFileImpl(pythonExecutable, ['-c', script], {
    cwd: moduleRoot,
    env: {
      ...process.env,
      PYTHONPATH: [moduleRoot, process.env.PYTHONPATH].filter(Boolean).join(';'),
    },
    windowsHide: true,
    timeout: PY_METADATA_PROBE_TIMEOUT_MS,
    maxBuffer: 8 * 1024 * 1024,
  })
  return parsePyJianYingDraftPackagingMetadataSnapshot(JSON.parse(stdout))
}

/** @param {unknown} metadataSnapshot */
const parseRawOrNormalizedMetadataSnapshot = (metadataSnapshot) => {
  const rawMetadataSnapshot = isRecord(metadataSnapshot) && metadataSnapshot.schemaVersion === 1 &&
    metadataSnapshot.kind === metadataKind && metadataSnapshot.upstreamCommit === pinnedPyJianYingDraftCommit &&
    Array.isArray(metadataSnapshot.entries)
    ? {
        schema_version: 1,
        kind: metadataKind,
        source: 'pyjianyingdraft-metadata',
        upstream_commit: pinnedPyJianYingDraftCommit,
        entries: metadataSnapshot.entries,
      }
    : metadataSnapshot
  return parsePyJianYingDraftPackagingMetadataSnapshot(rawMetadataSnapshot)
}

/**
 * Classify a locally observed resource ID only when the pinned metadata maps it
 * to exactly one family. Values remain private and this never grants admission.
 * @param {unknown} metadataSnapshot
 */
export const createPyJianYingDraftResourceFamilyClassifier = (metadataSnapshot) => {
  const metadata = parseRawOrNormalizedMetadataSnapshot(metadataSnapshot)
  const familiesByResource = new Map()
  for (const entry of metadata.entries) {
    const resourceId = entry.private_binding?.resourceId
    if (typeof resourceId !== 'string') continue
    const families = familiesByResource.get(resourceId) ?? new Set()
    families.add(entry.family)
    familiesByResource.set(resourceId, families)
  }
  return (/** @type {Record<string, any>} */ candidate) => {
    const resourceId = candidate?.resource_id ?? candidate?.resourceId ?? candidate?.id
    if (typeof resourceId !== 'string') return null
    const families = familiesByResource.get(resourceId)
    if (!families || families.size !== 1) return null
    return [...families][0]
  }
}

/**
 * Describe a local candidate only when its resource ID has one pinned family
 * and one safe pinned label. This is private scan enrichment, never admission.
 * @param {unknown} metadataSnapshot
 */
export const createPyJianYingDraftResourceCandidateDescriptor = (metadataSnapshot) => {
  const metadata = parseRawOrNormalizedMetadataSnapshot(metadataSnapshot)
  /** @type {Map<string, {families: Set<string>, labels: Set<string>, entities: Set<string>, effectIds: Set<string>}>} */
  const descriptorsByIdentity = new Map()
  /** @type {Map<string, Set<string>>} */
  const familiesByResource = new Map()
  /** @param {string} key @param {Record<string, any>} entry */
  const addDescriptor = (key, entry) => {
    const descriptor = descriptorsByIdentity.get(key) ?? { families: new Set(), labels: new Set(), entities: new Set(), effectIds: new Set() }
    descriptor.families.add(entry.family)
    descriptor.labels.add(entry.label)
    if (typeof entry.private_binding?.entity === 'string') descriptor.entities.add(entry.private_binding.entity)
    if (typeof entry.private_binding?.effectId === 'string') descriptor.effectIds.add(entry.private_binding.effectId)
    descriptorsByIdentity.set(key, descriptor)
  }
  for (const entry of metadata.entries) {
    const resourceId = entry.private_binding?.resourceId
    if (typeof resourceId !== 'string') continue
    const resourceFamilies = familiesByResource.get(resourceId) ?? new Set()
    resourceFamilies.add(entry.family)
    familiesByResource.set(resourceId, resourceFamilies)
    addDescriptor(`resource\u0000${resourceId}`, entry)
    if (entry.family === 'video_effect') {
      addDescriptor(`pair\u0000${resourceId}\u0000${entry.private_binding?.effectId ?? ''}`, entry)
    }
  }
  return (/** @type {Record<string, any>} */ candidate) => {
    const resourceId = candidate?.resource_id ?? candidate?.resourceId ?? candidate?.id
    if (typeof resourceId !== 'string') return null
    if (familiesByResource.get(resourceId)?.size !== 1) return null
    const effectId = candidate?.effect_id ?? candidate?.effectId
    const descriptor = typeof effectId === 'string'
      ? descriptorsByIdentity.get(`pair\u0000${resourceId}\u0000${effectId}`) ?? descriptorsByIdentity.get(`resource\u0000${resourceId}`)
      : descriptorsByIdentity.get(`resource\u0000${resourceId}`)
    if (!descriptor || descriptor.families.size !== 1 || descriptor.labels.size !== 1 || descriptor.entities.size > 1) return null
    const family = [...descriptor.families][0]
    if (family === 'video_effect' && (descriptor.entities.size !== 1 || descriptor.effectIds.size !== 1)) return null
    const entity = descriptor.entities.size === 1 ? [...descriptor.entities][0] : null
    return Object.freeze({
      family,
      label: [...descriptor.labels][0],
      ...(entity ? { entity } : {}),
      ...(descriptor.effectIds.size === 1 ? { effectId: [...descriptor.effectIds][0] } : {}),
    })
  }
}

/**
 * Compile a profile/version-bound private candidate catalog from the pinned
 * pyJianYingDraft metadata snapshot plus the local safe scanner output.
 * Scanner-discovered bindings remain authoritative for the private binding and
 * opaque token. Metadata only enriches safe labels/tags/schema and can block
 * local-only bindings that the pinned upstream metadata does not recognize.
 * @param {{
 *   metadataSnapshot: unknown,
 *   scannedCatalog: unknown,
 *   profileId: string,
 *   appVersion: string,
 *   desktopBinding?: Record<string, any>,
 * }} input
 */
export const compileJianYingPrivateCandidateCatalog = ({
  metadataSnapshot,
  scannedCatalog,
  profileId,
  appVersion,
  desktopBinding = undefined,
}) => {
  const metadata = parseRawOrNormalizedMetadataSnapshot(metadataSnapshot)
  const scanned = parsePrivatePackagingResourceIndex(scannedCatalog, { profileId, appVersion })
  const normalizedDesktopBinding = desktopBinding === undefined
    ? scanned.desktopBinding
    : normalizeJianyingDesktopBinding(desktopBinding)
  /** @type {Map<string, {label: string, tags: readonly string[], parameter_schema: Record<string, any>, private_binding: Record<string, any>, ambiguous: boolean}>} */
  const metadataByIdentity = new Map()
  for (const entry of metadata.entries) {
    if (typeof entry.identity !== 'string') continue
    const existing = metadataByIdentity.get(entry.identity)
    if (!existing) {
      metadataByIdentity.set(entry.identity, {
        label: entry.label,
        tags: entry.tags,
        parameter_schema: structuredClone(entry.parameter_schema),
        private_binding: structuredClone(entry.private_binding),
        ambiguous: false,
      })
      continue
    }
    const conflict = existing.label !== entry.label || JSON.stringify(existing.private_binding) !== JSON.stringify(entry.private_binding)
    metadataByIdentity.set(entry.identity, {
      label: existing.label,
      tags: Object.freeze([...new Set([...existing.tags, ...entry.tags])].slice(0, 16)),
      parameter_schema: Object.keys(existing.parameter_schema).length > 0
        ? existing.parameter_schema
        : structuredClone(entry.parameter_schema),
      private_binding: structuredClone(existing.private_binding),
      ambiguous: existing.ambiguous || conflict,
    })
  }
  const entries = scanned.entries.map((entry) => {
    const identity = bindingIdentity(entry.family, entry.private_binding)
    const metadataEntry = typeof identity === 'string' ? metadataByIdentity.get(identity) : null
    const exactMetadataEntry = metadataEntry && !metadataEntry.ambiguous && privateBindingMatches(entry.family, entry.private_binding, metadataEntry.private_binding)
      ? metadataEntry
      : null
    const tags = exactMetadataEntry
      ? [...new Set(['local-scan', 'pyjianyingdraft-metadata', ...entry.tags, ...exactMetadataEntry.tags])].slice(0, 16)
      : [...new Set(['local-scan', 'metadata-miss', ...entry.tags])].slice(0, 16)
    return {
      packaging_token: entry.packaging_token,
      family: entry.family,
      label: exactMetadataEntry?.label ?? entry.label,
      tags,
      state: entry.state === 'blocked' || !exactMetadataEntry ? 'blocked' : 'discoverable',
      writer_eligible: false,
      parameter_schema: exactMetadataEntry?.parameter_schema ?? entry.parameter_schema ?? {},
      private_binding: structuredClone(entry.private_binding),
    }
  })
  const compiled = parsePrivatePackagingResourceIndex({
    schema_version: 1,
    profile_id: profileId,
    app_version: appVersion,
    ...(normalizedDesktopBinding ? { desktop_binding: normalizedDesktopBinding } : {}),
    ...(scanned.privateRootSetFingerprint ? { private_root_set_fingerprint: scanned.privateRootSetFingerprint } : {}),
    catalog_fingerprint: computePackagingCatalogFingerprint({
      profileId,
      appVersion,
      entries,
      desktopBinding: normalizedDesktopBinding,
      privateRootSetFingerprint: scanned.privateRootSetFingerprint,
    }),
    entries,
  }, { profileId, appVersion })
  return serializePrivatePackagingResourceIndex(compiled)
}
