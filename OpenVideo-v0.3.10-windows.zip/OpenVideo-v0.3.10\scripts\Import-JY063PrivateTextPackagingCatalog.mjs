import { createHash } from 'node:crypto'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { createJianyingTextPackagingCatalog } from '../apps/gateway/src/jianying-text-packaging-catalog.mjs'
import { createJianyingDraftDecryptor } from '../apps/gateway/src/jianying-draft-decrypt.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig, securePrivateRuntimeRoot } from '../apps/gateway/src/local-runtime.mjs'
import manifest from '../config/jianying-compatibility.json' with { type: 'json' }

const tokenFor = (kind, resourceId) => `ovjpack_v1_${createHash('sha256').update(`${kind}\0${resourceId}`).digest('base64url')}`
const uniqueByResource = (items) => [...new Map(items.map((item) => [item.resource_id, item])).values()]

// Intake is deliberately bound to one user-named local Jianying draft. Decrypted
// content, resource IDs, names and paths never leave the private runtime boundary.
const main = async () => {
  const draftName = process.argv[2]
  if (!draftName || draftName !== path.basename(draftName) || draftName.includes('/') || draftName.includes('\\')) throw new Error('JY063_PRIVATE_INTAKE_REQUIRED')
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.profileId !== 'jianying-11-1-provisional') throw new Error('JY063_PROFILE_UNSUPPORTED')
  const draftFolder = path.resolve(desktop.draftRoot, draftName)
  if (path.dirname(draftFolder) !== path.resolve(desktop.draftRoot)) throw new Error('JY063_PRIVATE_INTAKE_REQUIRED')
  const temporary = await mkdtemp(path.join(tmpdir(), 'openvideo-jy063-intake-'))
  let content
  try {
    const plaintext = path.join(temporary, 'draft_content.json')
    const decryptor = createJianyingDraftDecryptor({ installRoot: desktop.installRoot, appVersion: desktop.version })
    const meta = await decryptor.ensurePlaintextFile(path.join(draftFolder, 'draft_content.json'), plaintext)
    if (meta.scheme !== 'encrypt_v2' && meta.decryptedFrom !== 'encrypt_v2') throw new Error('JY063_ENCRYPT_V2_REQUIRED')
    content = JSON.parse(await readFile(plaintext, 'utf8'))
  } finally { await rm(temporary, { recursive: true, force: true }) }
  const stickers = uniqueByResource((content?.materials?.stickers ?? []).filter((item) => item?.type === 'sticker' && typeof item.resource_id === 'string'))
  const flowers = uniqueByResource((content?.materials?.effects ?? []).filter((item) => item?.type === 'text_effect' && typeof item.resource_id === 'string' && item.effect_id === item.resource_id))
  const bubbles = uniqueByResource((content?.materials?.text_templates ?? []).filter((item) => item?.type === 'text_template' && typeof item.resource_id === 'string' && typeof item.effect_id === 'string'))
  if (stickers.length !== 1 || flowers.length !== 1 || bubbles.length !== 1) throw new Error('JY063_PRIVATE_INTAKE_AMBIGUOUS')
  const catalog = createJianyingTextPackagingCatalog([
    { kind: 'sticker', capability_id: 'sticker.named', packaging_token: tokenFor('sticker', stickers[0].resource_id), resource_id: stickers[0].resource_id },
    { kind: 'flower', capability_id: 'text.flower.private', packaging_token: tokenFor('flower', flowers[0].resource_id), resource_id: flowers[0].resource_id, effect_id: flowers[0].effect_id },
    { kind: 'bubble', capability_id: 'text.bubble.private', packaging_token: tokenFor('bubble', bubbles[0].resource_id), resource_id: bubbles[0].resource_id, effect_id: bubbles[0].effect_id },
  ])
  const root = path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs')
  await mkdir(root, { recursive: true, mode: 0o700 })
  await securePrivateRuntimeRoot(root)
  await writeFile(path.join(root, 'jy063-text-packaging-catalog.json'), `${JSON.stringify(catalog)}\n`, { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(`${JSON.stringify({ ok: true, entry_count: catalog.entries.length, fingerprint: catalog.fingerprint })}\n`)
}
main().catch((error) => { process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY063_IMPORT_FAILED' })}\n`); process.exitCode = 1 })
