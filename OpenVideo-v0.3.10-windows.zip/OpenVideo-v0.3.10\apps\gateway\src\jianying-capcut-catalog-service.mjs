import { createHash, randomUUID } from 'node:crypto'
import { lstat, mkdir, realpath, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'

import {
  CAPCUT_MATE_PINNED_COMMIT,
  CAPCUT_MATE_RIGHTS_MODE,
  importCapCutMateCatalog,
} from './jianying-capcut-catalog-importer.mjs'
import {
  createCapCutCatalogBackup,
  createCapCutCatalogReleaseStore,
  restoreCapCutCatalogBackup,
} from './jianying-capcut-catalog-release-store.mjs'
import { projectCapCutDirectIdWriterEntry } from './jianying-capcut-direct-id.mjs'

export const CAPCUT_MATE_PINNED_SOURCE_CHECKSUMS = Object.freeze({
  'config/sticker.json': 'dcb4770cf9ece231eda69243cec866fbddf19cce095b19bfc2f3d428b2224550',
  'config/huazi.json': 'a10ec5a36d5d907a33f8802e2feb1ba9b857927c644c6c6b80262e3663dba47c',
  'src/pyJianYingDraft/metadata/video_scene_effect.py': 'cb0d3591b883bf9b4a3f21474741fe4b73a42dffc1ccd02afc6aefde8d239427',
  'src/pyJianYingDraft/metadata/video_character_effect.py': 'e5657b0db2ddfda2f00d97e02ab6a7385c22c5060436c65a90ec2c54762e2817',
})

const familySet = new Set(['flower', 'sticker', 'video_effect'])
const cursorPattern = /^ovcpcursor_v1_([0-9]{9})$/u
const queryPrivatePattern = /(?:[A-Za-z]:[\\/]|\\\\|(?:https?|file):\/\/|\b[a-f0-9]{32,64}\b|(?:resource|effect|material|sticker)[_-]?id\s*[:=])/iu

/** @param {unknown} value @returns {value is Record<string, any>} */
const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value)

/**
 * @typedef {{family: string, total: number}} PublicFamilySummary
 * @typedef {{manifestFingerprint: string, families: PublicFamilySummary[]}} PublicReleaseSummary
 * @typedef {{manifest: Record<string, any> & {manifestFingerprint: string}}} ReleaseMetadata
 * @typedef {{entries: Record<string, any>[]}} ShardDocument
 */

/** @param {string} code @param {number} [status] @returns {never} */
const fail = (code, status = 409) => {
  const error = /** @type {Error & {code?: string, status?: number}} */ (new Error(code))
  error.code = code
  error.status = status
  throw error
}

/** @param {string | Buffer} value @returns {string} */
const sha256 = (value) => createHash('sha256').update(value).digest('hex')

/** @param {string} root @param {string} child @returns {boolean} */
const within = (root, child) => {
  const relative = path.relative(path.resolve(root), path.resolve(child))
  return relative === '' || (!!relative && !relative.startsWith('..') && !path.isAbsolute(relative))
}

/** Windows realpath can normalize drive/path casing without traversing a reparse point. */
/** @param {string} left @param {string} right @returns {boolean} */
const sameFilesystemPath = (left, right) => process.platform === 'win32'
  ? path.resolve(left).toLocaleLowerCase() === path.resolve(right).toLocaleLowerCase()
  : path.resolve(left) === path.resolve(right)

/** @param {unknown} metadata */
const objectIdentity = (metadata) => {
  if (!metadata || typeof metadata !== 'object' ||
      (typeof /** @type {any} */ (metadata).dev !== 'number' && typeof /** @type {any} */ (metadata).dev !== 'bigint') ||
      (typeof /** @type {any} */ (metadata).ino !== 'number' && typeof /** @type {any} */ (metadata).ino !== 'bigint')) return null
  return `${/** @type {any} */ (metadata).dev}:${/** @type {any} */ (metadata).ino}`
}

/**
 * Windows realpath may return an 8.3 alias. A different spelling is safe only
 * when both names still identify the same filesystem object.
 * @param {string} requested
 * @param {string} actual
 * @param {import('node:fs').Stats|import('node:fs').BigIntStats|Record<string, any>} requestedMetadata
 */
const sameResolvedObject = async (requested, actual, requestedMetadata) => {
  if (sameFilesystemPath(requested, actual)) return true
  if (process.platform !== 'win32') return false
  const actualMetadata = await lstat(actual, { bigint: true }).catch(() => null)
  const expectedIdentity = objectIdentity(requestedMetadata)
  return expectedIdentity !== null && expectedIdentity === objectIdentity(actualMetadata)
}

/** @param {unknown} value @returns {number} */
const parseCursor = (value) => {
  if (value === null || value === undefined || value === '') return 0
  if (typeof value !== 'string') fail('PACKAGING_CATALOG_CURSOR_INVALID', 400)
  const match = value.match(cursorPattern)
  if (!match) fail('PACKAGING_CATALOG_CURSOR_INVALID', 400)
  return Number(match[1])
}

/** @param {number} value @returns {string} */
const encodeCursor = (value) => `ovcpcursor_v1_${String(value).padStart(9, '0')}`

/** @param {unknown} value @returns {string} */
const safeQuery = (value) => {
  if (value === null || value === undefined || value === '') return ''
  if (typeof value !== 'string' || value.length > 120 || /[\u0000-\u001f]/u.test(value) || queryPrivatePattern.test(value)) {
    fail('PACKAGING_CATALOG_QUERY_INVALID', 400)
  }
  return value.trim().toLocaleLowerCase()
}

/** @param {Record<string, any>} entry @param {string} manifestFingerprint */
const publicCandidate = (entry, manifestFingerprint) => {
  const family = entry.family
  if (!familySet.has(family) || !isRecord(entry.private_binding)) fail('PACKAGING_CATALOG_ENTRY_INVALID')
  const token = `ovj${family}_v1_${sha256(JSON.stringify({
    manifest_fingerprint: manifestFingerprint,
    family,
    entity: entry.private_binding.entity ?? null,
    raw_identity: entry.private_binding.raw_identity,
  })).slice(0, 24)}`
  return Object.freeze({
    packagingToken: token,
    family,
    label: typeof entry.label === 'string' && entry.label ? entry.label : '未命名包装资源',
    tags: Array.isArray(entry.tags) ? entry.tags.slice(0, 16) : [],
    state: 'discoverable',
    writerEligible: false,
  })
}

/**
 * Installer-owned CapCut Mate catalog service. The source path and backup
 * payload never cross HTTP; public methods project only safe aggregate state.
 * @param {{
 *   dataRoot: string,
 *   sourceRoot?: string | null,
 *   expectedSourceChecksums?: Record<string, string>,
 *   detectDesktop?: (() => Promise<Record<string, any>> | Record<string, any>) | null,
 *   signBackup?: ((payload: Buffer) => string | Promise<string>) | null,
 *   verifyBackup?: ((payload: Buffer, signature: string) => boolean | Promise<boolean>) | null,
 *   exactBindingDiagnostics?: (() => Promise<Record<string, any>> | Record<string, any>) | null,
 * }} input
 */
export const createCapCutCatalogService = ({
  dataRoot,
  sourceRoot = null,
  expectedSourceChecksums = CAPCUT_MATE_PINNED_SOURCE_CHECKSUMS,
  detectDesktop = null,
  signBackup = null,
  verifyBackup = null,
  exactBindingDiagnostics = null,
}) => {
  if (typeof dataRoot !== 'string' || !path.isAbsolute(dataRoot) ||
      (sourceRoot !== null && (typeof sourceRoot !== 'string' || !path.isAbsolute(sourceRoot)))) {
    fail('PACKAGING_CATALOG_SERVICE_CONFIG_INVALID', 500)
  }
  const releaseRoot = path.join(path.resolve(dataRoot), 'catalogs', 'capcut-mate')
  const importWorkRoot = path.join(path.resolve(dataRoot), 'tmp', 'capcut-mate-import')
  const installReceiptPath = path.join(releaseRoot, 'install-receipt.json')
  if (!within(dataRoot, releaseRoot) || !within(dataRoot, importWorkRoot)) fail('PACKAGING_CATALOG_SERVICE_CONFIG_INVALID', 500)
  const store = createCapCutCatalogReleaseStore({ releaseRoot })
  /** @type {Map<string, Readonly<Record<string, any>>>} */
  const privateCandidateCache = new Map()
  const cachePrivateCandidate = (/** @type {string} */ key, /** @type {Readonly<Record<string, any>>} */ entry) => {
    privateCandidateCache.delete(key)
    privateCandidateCache.set(key, entry)
    while (privateCandidateCache.size > 128) {
      const oldest = privateCandidateCache.keys().next().value
      if (typeof oldest !== 'string') break
      privateCandidateCache.delete(oldest)
    }
  }

  const readDesktop = async () => {
    if (typeof detectDesktop !== 'function') return { profileId: 'jianying-capcut-mate-import', version: '0.0.0' }
    const desktop = await detectDesktop()
    if (!isRecord(desktop) || desktop.available !== true || typeof desktop.profileId !== 'string' || typeof desktop.version !== 'string') {
      fail('PACKAGING_CATALOG_DESKTOP_UNAVAILABLE', 503)
    }
    return desktop
  }

  const service = {
    /** Owner-private release identity. Never expose this method through HTTP. */
    async currentPrivateIdentity() {
      const current = /** @type {ReleaseMetadata} */ (/** @type {unknown} */ (await store.readCurrentMetadata({ verifyShards: true })))
      return Object.freeze({
        manifestFingerprint: current.manifest.manifestFingerprint,
        sourceCommit: current.manifest.sourceCommit,
      })
    },
    async summary() {
      try {
        const current = /** @type {PublicReleaseSummary} */ (await store.readPublicCurrent())
        return Object.freeze({
          schema_version: 1,
          status: 'ready',
          rights_mode: CAPCUT_MATE_RIGHTS_MODE,
          source: 'capcut_mate_snapshot',
          catalog_revision_token: `ovcapcut_v1_${current.manifestFingerprint.slice(0, 24)}`,
          entries: current.families.reduce((/** @type {number} */ sum, /** @type {PublicFamilySummary} */ family) => sum + family.total, 0),
          families: current.families.map((/** @type {PublicFamilySummary} */ family) => Object.freeze({ family: family.family, discoverable: family.total })),
          writer_eligible: 0,
        })
      } catch (error) {
        if (/** @type {{code?: unknown}} */ (error)?.code === 'CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED') {
          return Object.freeze({
            schema_version: 1,
            status: 'needs_reimport',
            rights_mode: CAPCUT_MATE_RIGHTS_MODE,
            source: 'capcut_mate_snapshot',
            catalog_revision_token: null,
            entries: 0,
            families: [],
            writer_eligible: 0,
          })
        }
        if (/** @type {{code?: unknown}} */ (error)?.code === 'ENOENT') {
          return Object.freeze({
            schema_version: 1,
            status: sourceRoot ? 'not_installed' : 'source_unavailable',
            rights_mode: CAPCUT_MATE_RIGHTS_MODE,
            source: 'capcut_mate_snapshot',
            catalog_revision_token: null,
            entries: 0,
            families: [],
            writer_eligible: 0,
          })
        }
        throw error
      }
    },
    async install() {
      if (!sourceRoot) fail('PACKAGING_CATALOG_SOURCE_UNAVAILABLE', 503)
      const sourceStats = await lstat(sourceRoot, { bigint: true }).catch(() => null)
      if (!sourceStats?.isDirectory() || sourceStats.isSymbolicLink()) fail('PACKAGING_CATALOG_SOURCE_UNAVAILABLE', 503)
      const canonicalSource = await realpath(sourceRoot).catch(() => null)
      if (typeof canonicalSource !== 'string' || !await sameResolvedObject(sourceRoot, canonicalSource, sourceStats)) {
        fail('PACKAGING_CATALOG_SOURCE_REPARSE_REJECTED', 409)
      }
      const desktop = await readDesktop()
      const imported = await importCapCutMateCatalog({
        sourceRoot: canonicalSource,
        sourceCommit: CAPCUT_MATE_PINNED_COMMIT,
        expectedCommit: CAPCUT_MATE_PINNED_COMMIT,
        expectedSourceChecksums,
        profileId: desktop.profileId,
        appVersion: desktop.version,
        workRoot: importWorkRoot,
      })
      try {
        await store.publish({ manifest: imported.manifest, shards: imported.shards() })
      } finally {
        await imported.dispose()
      }
      return service.summary()
    },
    /**
     * Installer-only audit receipt. The persisted record intentionally contains
     * only aggregate catalog state and fingerprints; source paths, raw IDs and
     * backup payloads never cross this private boundary.
     */
    async installAudit() {
      const summary = await service.install()
      const publicSummary = /** @type {Record<string, any>} */ (summary)
      /** @type {{available: boolean, payload_fingerprint?: string | null, signature_present?: boolean}} */
      let backup = { available: false }
      if (typeof signBackup === 'function') {
        const signed = await service.createBackup()
        backup = {
          available: true,
          payload_fingerprint: typeof signed.payloadFingerprint === 'string' ? signed.payloadFingerprint : null,
          signature_present: typeof signed.signature === 'string' && signed.signature.length > 0,
        }
      }
      const receipt = Object.freeze({
        schema_version: 1,
        status: publicSummary.status,
        source: 'capcut_mate_snapshot',
        rights_mode: CAPCUT_MATE_RIGHTS_MODE,
        source_commit: CAPCUT_MATE_PINNED_COMMIT,
        catalog_revision_token: publicSummary.catalog_revision_token,
        entries: publicSummary.entries,
        families: publicSummary.families,
        writer_eligible: 0,
        backup: Object.freeze(backup),
      })
      await mkdir(path.dirname(installReceiptPath), { recursive: true })
      const tempPath = path.join(path.dirname(installReceiptPath), `.${path.basename(installReceiptPath)}.${randomUUID()}.tmp`)
      await writeFile(tempPath, `${JSON.stringify(receipt)}\n`, 'utf8')
      await rename(tempPath, installReceiptPath)
      return receipt
    },
    /** @param {{query?: string, family?: string | null, limit?: number, cursor?: string | null}} [input] */
    async search({ query = '', family = null, limit = 20, cursor = null } = {}) {
      const normalizedQuery = safeQuery(query)
      if (family !== null && !familySet.has(family)) fail('PACKAGING_CATALOG_FAMILY_INVALID', 400)
      if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) fail('PACKAGING_CATALOG_LIMIT_INVALID', 400)
      const offset = parseCursor(cursor)
      const current = /** @type {ReleaseMetadata} */ (/** @type {unknown} */ (await store.readCurrentMetadata()))
      /** @type {Array<Readonly<Record<string, any>>>} */
      const candidates = []
      let ordinal = 0
      let hasMore = false
      for await (const shard of /** @type {AsyncIterable<ShardDocument>} */ (store.readCurrentShards())) {
        for (const entry of shard.entries) {
          const candidate = publicCandidate(entry, current.manifest.manifestFingerprint)
          const matches = (family === null || candidate.family === family) &&
            (!normalizedQuery || `${candidate.label}\n${candidate.tags.join('\n')}`.toLocaleLowerCase().includes(normalizedQuery))
          if (!matches) continue
          if (ordinal++ < offset) continue
          if (candidates.length < limit) candidates.push(candidate)
          else { hasMore = true; break }
        }
        if (hasMore) break
      }
      return Object.freeze({
        schema_version: 1,
        catalog_revision_token: `ovcapcut_v1_${current.manifest.manifestFingerprint.slice(0, 24)}`,
        candidates: Object.freeze(candidates),
        next_cursor: hasMore ? encodeCursor(offset + candidates.length) : null,
      })
    },
    /**
     * Return an aggregate-only qualification report. CapCut Mate remains an
     * import-only discovery source: this report deliberately never exposes a
     * raw identity, path, URL or admission handle, and it never promotes a
     * discovery row to writer eligibility. The rescan action is explicit so
     * an operator can refresh a user-owned snapshot and retry qualification.
     */
    async diagnostics() {
      try {
        const current = /** @type {PublicReleaseSummary} */ (await store.readPublicCurrent())
        const total = current.families.reduce((/** @type {number} */ sum, /** @type {PublicFamilySummary} */ family) => sum + family.total, 0)
        const qualification = typeof exactBindingDiagnostics === 'function'
          ? await exactBindingDiagnostics().catch(() => null)
          : null
        return Object.freeze({
          schema_version: 1,
          status: 'ready',
          rights_mode: CAPCUT_MATE_RIGHTS_MODE,
          discovery: Object.freeze({
            entries: total,
            families: Object.freeze(current.families.map((family) => Object.freeze({ family: family.family, entries: family.total }))),
          }),
          exact_binding: Object.freeze(qualification && isRecord(qualification)
            ? {
                examined: Number.isSafeInteger(qualification.examined) ? qualification.examined : total,
                qualified: Number.isSafeInteger(qualification.qualified) ? qualification.qualified : 0,
                writer_eligible: 0,
                reasons: Object.freeze(isRecord(qualification.reasons) ? { ...qualification.reasons } : { diagnostic_unavailable: 1 }),
              }
            : {
                examined: total,
                qualified: 0,
                writer_eligible: 0,
                reasons: Object.freeze({ diagnostic_unavailable: 1 }),
              }),
          rescan: Object.freeze({
            available: Boolean(sourceRoot),
            method: 'POST',
            action: 'install',
            requires_user_local_snapshot: true,
          }),
        })
      } catch (error) {
        const code = /** @type {{code?: unknown}} */ (error)?.code
        if (code === 'CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED') {
          return Object.freeze({
            schema_version: 1,
            status: 'needs_reimport',
            rights_mode: CAPCUT_MATE_RIGHTS_MODE,
            discovery: Object.freeze({ entries: 0, families: Object.freeze([]) }),
            exact_binding: Object.freeze({ examined: 0, qualified: 0, writer_eligible: 0, reasons: Object.freeze({ catalog_reimport_required: 1 }) }),
            rescan: Object.freeze({ available: Boolean(sourceRoot), method: 'POST', action: 'install', requires_user_local_snapshot: true }),
          })
        }
        if (code === 'ENOENT') {
          return Object.freeze({
            schema_version: 1,
            status: sourceRoot ? 'not_installed' : 'source_unavailable',
            rights_mode: CAPCUT_MATE_RIGHTS_MODE,
            discovery: Object.freeze({ entries: 0, families: Object.freeze([]) }),
            exact_binding: Object.freeze({ examined: 0, qualified: 0, writer_eligible: 0, reasons: Object.freeze({ catalog_unavailable: 1 }) }),
            rescan: Object.freeze({ available: Boolean(sourceRoot), method: 'POST', action: 'install', requires_user_local_snapshot: true }),
          })
        }
        throw error
      }
    },
    /**
     * Count CapCut entries that match a current, server-owned Native binding.
     * The matcher receives private entries only inside the Gateway and the
     * result is aggregate-only; this never changes discovery or admission
     * state and never crosses the HTTP boundary.
     * @param {{match?: (entry: Record<string, any>) => Promise<boolean> | boolean}} [input]
     */
    async exactBindingDiagnostics({ match = undefined } = {}) {
      if (typeof match !== 'function') {
        return Object.freeze({ examined: 0, qualified: 0, reasons: Object.freeze({ matcher_unavailable: 1 }) })
      }
      try {
        const current = /** @type {ReleaseMetadata} */ (/** @type {unknown} */ (await store.readCurrentMetadata()))
        let examined = 0
        let qualified = 0
        for await (const shard of /** @type {AsyncIterable<ShardDocument>} */ (store.readCurrentShards())) {
          for (const entry of shard.entries) {
            examined += 1
            if (await match(entry)) qualified += 1
          }
        }
        return Object.freeze({
          examined,
          qualified,
          reasons: Object.freeze(qualified > 0
            ? { exact_current_native_intersection: qualified }
            : { current_native_intersection_unavailable: 1 }),
          catalog_revision_token: `ovcapcut_v1_${current.manifest.manifestFingerprint.slice(0, 24)}`,
        })
      } catch (error) {
        if (/** @type {{code?: unknown}} */ (error)?.code === 'CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED' ||
            /** @type {{code?: unknown}} */ (error)?.code === 'ENOENT') {
          return Object.freeze({ examined: 0, qualified: 0, reasons: Object.freeze({ catalog_unavailable: 1 }) })
        }
        throw error
      }
    },
    async resolvePrivateCandidate(/** @type {unknown} */ packagingToken) {
      if (typeof packagingToken !== 'string' || !/^ovj(?:flower|sticker|video_effect)_v1_[a-f0-9]{24}$/u.test(packagingToken)) return null
      const current = /** @type {ReleaseMetadata} */ (/** @type {unknown} */ (await store.readCurrentMetadata()))
      const cacheKey = `${current.manifest.manifestFingerprint}:${packagingToken}`
      const cached = privateCandidateCache.get(cacheKey)
      if (cached) {
        cachePrivateCandidate(cacheKey, cached)
        return cached
      }
      for await (const shard of /** @type {AsyncIterable<ShardDocument>} */ (store.readCurrentShards())) {
        for (const entry of shard.entries) {
          const candidate = publicCandidate(entry, current.manifest.manifestFingerprint)
          if (candidate.packagingToken === packagingToken) {
            const resolved = Object.freeze({ ...entry, packaging_token: packagingToken })
            cachePrivateCandidate(cacheKey, resolved)
            return resolved
          }
        }
      }
      return null
    },
    /** Resolve a bounded Top-N set in one verified shard pass. Gateway-private only. */
    async resolvePrivateCandidates(/** @type {unknown} */ packagingTokens) {
      if (!Array.isArray(packagingTokens) || packagingTokens.length < 1 || packagingTokens.length > 24 ||
          packagingTokens.some((token) => typeof token !== 'string' || !/^ovj(?:flower|sticker|video_effect)_v1_[a-f0-9]{24}$/u.test(token)) ||
          new Set(packagingTokens).size !== packagingTokens.length) return null
      const current = /** @type {ReleaseMetadata} */ (/** @type {unknown} */ (await store.readCurrentMetadata()))
      const resolved = new Map()
      const missing = new Set()
      for (const token of packagingTokens) {
        const cacheKey = `${current.manifest.manifestFingerprint}:${token}`
        const cached = privateCandidateCache.get(cacheKey)
        if (cached) {
          cachePrivateCandidate(cacheKey, cached)
          resolved.set(token, cached)
        } else {
          missing.add(token)
        }
      }
      if (missing.size > 0) {
        for await (const shard of /** @type {AsyncIterable<ShardDocument>} */ (store.readCurrentShards())) {
          for (const entry of shard.entries) {
            const candidate = publicCandidate(entry, current.manifest.manifestFingerprint)
            if (!missing.has(candidate.packagingToken)) continue
            if (resolved.has(candidate.packagingToken)) return null
            const privateEntry = Object.freeze({ ...entry, packaging_token: candidate.packagingToken })
            resolved.set(candidate.packagingToken, privateEntry)
            cachePrivateCandidate(`${current.manifest.manifestFingerprint}:${candidate.packagingToken}`, privateEntry)
            missing.delete(candidate.packagingToken)
          }
          if (missing.size === 0) break
        }
      }
      if (resolved.size !== packagingTokens.length) return null
      return Object.freeze(packagingTokens.map((token) => resolved.get(token)))
    },
    /**
     * Rebuild only selected Direct-ID bindings from the current private
     * release. This method never crosses the HTTP boundary; callers retain
     * only the opaque Writer tokens in RichTimeline.
     * @param {{packagingTokens: unknown, profileId: unknown, appVersion: unknown}} input
     */
    async resolvePrivateWriterCandidates({ packagingTokens, profileId, appVersion }) {
      if (!Array.isArray(packagingTokens) || packagingTokens.length < 1 || packagingTokens.length > 24 ||
          packagingTokens.some((token) => typeof token !== 'string' || !/^ovj(?:flower|sticker|video_effect)_v1_[a-f0-9]{24}$/u.test(token)) ||
          new Set(packagingTokens).size !== packagingTokens.length ||
          typeof profileId !== 'string' || !/^jianying-[a-z0-9-]{1,60}$/u.test(profileId) ||
          typeof appVersion !== 'string' || !/^\d{1,3}(?:\.\d{1,8}){1,4}$/u.test(appVersion)) {
        return null
      }
      const requested = new Set(packagingTokens)
      const resolved = new Map()
      try {
        for await (const shard of /** @type {AsyncIterable<ShardDocument>} */ (store.readCurrentShards())) {
          for (const sourceEntry of shard.entries) {
            const writerEntry = projectCapCutDirectIdWriterEntry({ sourceEntry, profileId, appVersion })
            if (!writerEntry || !requested.has(writerEntry.packaging_token)) continue
            if (resolved.has(writerEntry.packaging_token)) return null
            resolved.set(writerEntry.packaging_token, writerEntry)
          }
          if (resolved.size === requested.size) break
        }
      } catch (error) {
        if (/** @type {{code?: unknown}} */ (error)?.code === 'CAPCUT_CATALOG_SCHEMA_REIMPORT_REQUIRED' ||
            /** @type {{code?: unknown}} */ (error)?.code === 'ENOENT') return null
        throw error
      }
      if (resolved.size !== requested.size) return null
      return Object.freeze(packagingTokens.map((token) => resolved.get(token)))
    },
    async createBackup() {
      if (typeof signBackup !== 'function') fail('PACKAGING_CATALOG_BACKUP_UNAVAILABLE', 503)
      return createCapCutCatalogBackup({ store, sign: signBackup })
    },
    async restoreBackup(/** @type {Record<string, any>} */ backup, /** @type {string} */ targetDataRoot = dataRoot) {
      if (typeof verifyBackup !== 'function' || typeof targetDataRoot !== 'string' || !path.isAbsolute(targetDataRoot)) {
        fail('PACKAGING_CATALOG_BACKUP_UNAVAILABLE', 503)
      }
      const targetReleaseRoot = path.join(path.resolve(targetDataRoot), 'catalogs', 'capcut-mate')
      if (!within(targetDataRoot, targetReleaseRoot)) fail('PACKAGING_CATALOG_BACKUP_INVALID', 400)
      return restoreCapCutCatalogBackup({ backup, releaseRoot: targetReleaseRoot, verify: verifyBackup })
    },
  }
  return Object.freeze(service)
}

/** Public HTTP boundary accepts no source path, raw ID or backup payload. */
/** @param {{service: {summary: () => Promise<unknown>, diagnostics?: () => Promise<unknown>, install: () => Promise<unknown>, installAudit?: () => Promise<unknown>, search: (input: {query: string, family: string | null, limit: number, cursor: string | null}) => Promise<unknown>}}} input */
export const createCapCutCatalogHandler = ({ service }) => async (/** @type {Request} */ request) => {
  try {
    if (request.method === 'GET') {
      const params = new URL(request.url).searchParams
      if (params.get('view') === 'diagnostics') {
        if (typeof service.diagnostics !== 'function') fail('PACKAGING_CATALOG_DIAGNOSTICS_UNAVAILABLE', 503)
        return Response.json(await service.diagnostics(), { headers: { 'cache-control': 'no-store' } })
      }
      if (params.get('view') === 'search') {
        const limit = params.get('limit') === null ? 20 : Number(params.get('limit'))
        return Response.json(await service.search(/** @type {{query: string, family: string | null, limit: number, cursor: string | null}} */ ({
          query: params.get('query') ?? '',
          family: params.get('family'),
          limit,
          cursor: params.get('cursor'),
        })), { headers: { 'cache-control': 'no-store' } })
      }
      return Response.json(await service.summary(), { headers: { 'cache-control': 'no-store' } })
    }
    if (request.method === 'POST') {
      let input = {}
      if (request.body) {
        if ((request.headers.get('content-type') ?? '').split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
          fail('UNSUPPORTED_MEDIA_TYPE', 415)
        }
        try { input = await request.json() } catch { fail('PACKAGING_CATALOG_INPUT_INVALID', 400) }
      }
      if (!isRecord(input) || Object.keys(input).some((key) => key !== 'action') ||
          (input.action !== undefined && input.action !== 'install' && input.action !== 'install_audit')) fail('PACKAGING_CATALOG_INPUT_INVALID', 400)
      if (input.action === 'install_audit') {
        if (typeof service.installAudit !== 'function') fail('PACKAGING_CATALOG_AUDIT_UNAVAILABLE', 503)
        return Response.json(await service.installAudit(), { status: 201, headers: { 'cache-control': 'no-store' } })
      }
      return Response.json(await service.install(), { status: 201, headers: { 'cache-control': 'no-store' } })
    }
    return Response.json({ error: { code: 'METHOD_NOT_ALLOWED' } }, { status: 405, headers: { allow: 'GET, POST' } })
  } catch (error) {
    const candidate = /** @type {{code?: unknown, status?: unknown}} */ (error)
    const code = typeof candidate?.code === 'string' && /^[A-Z][A-Z0-9_]{2,159}$/u.test(candidate.code)
      ? candidate.code
      : 'PACKAGING_CATALOG_UNAVAILABLE'
    const status = Number.isInteger(candidate?.status) ? Number(candidate.status) : code === 'ENOENT' ? 404 : 503
    return Response.json({ error: { code } }, { status, headers: { 'cache-control': 'no-store' } })
  }
}
