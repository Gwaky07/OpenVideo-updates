import { createRequire } from 'node:module'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { promisify } from 'node:util'

import { createPyJianyingDraftWriter } from '../apps/gateway/src/jianying-draft-writer.mjs'
import { detectJianyingDesktop } from '../apps/gateway/src/jianying-local-environment.mjs'
import { loadLocalRuntimeConfig } from '../apps/gateway/src/local-runtime.mjs'
import { createScaleEvidenceTimeline, projectScaleEvidenceTimeline } from './New-JY027ScaleEvidenceDraft.mjs'

const execFileAsync = promisify(execFile)
const require = createRequire(import.meta.url)
const manifest = require('../config/jianying-compatibility.json')
const capabilityId = process.env.OPENVIDEO_FILTER_EVIDENCE_CAPABILITY ?? 'filter.video.named'
if (!['filter.video.named', 'filter.video.track_named'].includes(capabilityId)) throw new Error('FILTER_EVIDENCE_CAPABILITY_INVALID')
const trackMode = capabilityId === 'filter.video.track_named'
const catalogPath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'catalogs', trackMode ? 'jy042-filter-track-catalog.json' : 'jy041-filter-catalog.json')
const leasePath = () => path.join(loadLocalRuntimeConfig().dataRoot, 'evidence', trackMode ? 'jy042-filter-track' : 'jy041-filter', 'pending.json')

const main = async () => {
  const desktop = await detectJianyingDesktop({ compatibilityManifest: manifest })
  if (desktop?.available !== true || desktop.profileId !== 'jianying-11-1-provisional') throw new Error('JY041_PROFILE_UNSUPPORTED')
  const catalog = JSON.parse(await readFile(catalogPath(), 'utf8'))
  const entry = catalog.entries?.find((item) => item.capability_id === capabilityId)
  if (!entry?.filter_token || !entry.resource_id) throw new Error('JY041_PRIVATE_CATALOG_MISSING')
  const mediaRoot = await mkdtemp(path.join(tmpdir(), 'openvideo-jy041-filter-'))
  const videoPath = path.join(mediaRoot, 'video.mp4')
  const audioPath = path.join(mediaRoot, 'voice.wav')
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=360x640:r=30', '-t', '4', '-pix_fmt', 'yuv420p', videoPath])
  await execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=16000:cl=mono', '-t', '4', '-ac', '1', audioPath])
  const projected = projectScaleEvidenceTimeline(desktop.profileId, createScaleEvidenceTimeline())
  const draftPrefix = trackMode ? 'OpenVideo-JY042-filter-track-' : 'OpenVideo-JY041-filter-'
  const draftId = `${draftPrefix}${Date.now()}`
  const packaging = {
    ...projected.packaging,
    filter_segments: [{ resource_id: entry.resource_id, capability_id: capabilityId, target_start_us: 0, target_duration_us: 4_000_000, intensity: 50 }],
    sfx_segments: [], effect_segments: [], sticker_segments: [], voiceover_segments: [], bgm: { fade_in_us: 0, fade_out_us: 0 },
  }
  const writer = createPyJianyingDraftWriter({
    draftRoot: desktop.draftRoot,
    pythonExecutable: process.env.OPENVIDEO_JY002_PYTHON_EXECUTABLE ?? 'python',
    pythonModuleRoot: process.env.OPENVIDEO_JY002_PYTHON_MODULE_ROOT,
    getRenderOptions: () => ({ captions: false, bgmPath: null, subtitleStyle: 'default', keywordHighlights: [], captionSegments: [], titleSegments: [], timelinePackaging: packaging }),
  })
  const request = { job_id: `job-${draftId}`, request_id: `request-${draftId}`, output_policy: { draft_id: draftId }, export_request: { preparation: projected.preparation }, orientation: 'portrait', materials: [{ path: videoPath }], voiceovers: [{ path: audioPath }] }
  const result = await writer.writeDraft(request)
  if (await writer.verifyDraft({ job_id: request.job_id, request: { export_request: request.export_request }, write_result: result }) !== true) throw new Error('JY041_WRITER_VERIFY_FAILED')
  if (await writer.releaseDraft({ job_id: request.job_id, write_result: result }) !== true) throw new Error('JY041_WRITER_RELEASE_FAILED')
  const runtime = loadLocalRuntimeConfig()
  await (await import('node:fs/promises')).mkdir(path.dirname(leasePath()), { recursive: true })
  if (typeof result?.output_fingerprint !== 'string' || !/^[a-f0-9]{64}$/u.test(result.output_fingerprint)) throw new Error('JY041_WRITER_FINGERPRINT_MISSING')
  await writeFile(leasePath(), JSON.stringify({ schema_version: 1, capabilityId, catalogVersion: catalog.catalog_version, catalogFingerprint: catalog.catalog_fingerprint, draftFingerprint: result.output_fingerprint, draftId, profileId: desktop.profileId, draftRoot: desktop.draftRoot, mediaRoot, filterToken: entry.filter_token }), { encoding: 'utf8', mode: 0o600 })
  process.stdout.write(JSON.stringify({ ok: true, manual_open_required: true, draft_prefix: draftPrefix, capability: capabilityId, profile: desktop.profileId, version: desktop.version }) + '\n')
}

main().catch((error) => { process.stdout.write(JSON.stringify({ ok: false, code: error?.code ?? error?.message ?? 'JY041_WRITER_FAILED' }) + '\n'); process.exitCode = 1 })
